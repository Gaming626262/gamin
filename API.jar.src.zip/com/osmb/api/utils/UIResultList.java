/*     */ package com.osmb.api.utils;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ThreadLocalRandom;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UIResultList<T>
/*     */   implements Result<T>, Iterable<T>
/*     */ {
/*     */   private final State state;
/*     */   private final List<T> values;
/*     */   
/*     */   private UIResultList(State state, List<T> values) {
/*  29 */     this.state = state;
/*  30 */     this.values = (values != null && !values.isEmpty()) ? new ArrayList<>(values) : Collections.<T>emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> UIResultList<T> notVisible() {
/*  40 */     return new UIResultList<>(State.NOT_VISIBLE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> UIResultList<T> of(List<T> values) {
/*  51 */     return new UIResultList<>(State.FOUND, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotVisible() {
/*  61 */     return (this.state == State.NOT_VISIBLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotFound() {
/*  70 */     return (this.values == null || this.values.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFound() {
/*  80 */     return (this.state == State.FOUND && !this.values.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get(int index) {
/*  91 */     if (!isFound()) {
/*  92 */       throw new IllegalStateException("No values present, state is: " + this.state);
/*     */     }
/*  94 */     return this.values.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getRandom() {
/* 104 */     if (!isFound()) {
/* 105 */       throw new IllegalStateException("No values present, state is: " + this.state);
/*     */     }
/* 107 */     int randomIndex = ThreadLocalRandom.current().nextInt(this.values.size());
/* 108 */     return this.values.get(randomIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 117 */     return this.values.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 126 */     return this.values.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> asList() {
/* 135 */     return Collections.unmodifiableList(this.values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shuffleResults() {
/* 142 */     Random random = new Random();
/* 143 */     for (int i = this.values.size() - 1; i > 0; i--) {
/* 144 */       int j = random.nextInt(i + 1);
/*     */       
/* 146 */       T temp = this.values.get(i);
/* 147 */       this.values.set(i, this.values.get(j));
/* 148 */       this.values.set(j, temp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getOrDefault(int index, T defaultValue) {
/* 160 */     return (isFound() && index >= 0 && index < this.values.size()) ? this.values.get(index) : defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ifFound(Consumer<List<T>> consumer) {
/* 169 */     if (isFound()) {
/* 170 */       consumer.accept(Collections.unmodifiableList(this.values));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forEach(Consumer<? super T> action) {
/* 180 */     if (isFound()) {
/* 181 */       this.values.forEach(action);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 192 */     switch (this.state) { default: throw new IncompatibleClassChangeError();
/*     */       case NOT_VISIBLE: 
/* 194 */       case FOUND: break; }  return "UIResultList[FOUND: " + this.values + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/* 205 */     return isFound() ? this.values.iterator() : Collections.<T>emptyIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 211 */     NOT_VISIBLE,
/* 212 */     FOUND;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\UIResultList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */