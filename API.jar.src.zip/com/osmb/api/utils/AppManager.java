package com.osmb.api.utils;

public interface AppManager {
  boolean restart();
  
  void kill();
  
  boolean open();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\AppManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */