package com.osmb.api.utils;

import javafx.scene.Scene;

public interface StageController {
  void show(Scene paramScene, String paramString, boolean paramBoolean);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\StageController.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */