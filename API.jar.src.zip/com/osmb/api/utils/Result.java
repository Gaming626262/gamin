package com.osmb.api.utils;

public interface Result<T> {
  boolean isNotVisible();
  
  boolean isNotFound();
  
  boolean isFound();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\Result.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */