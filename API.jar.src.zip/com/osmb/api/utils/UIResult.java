/*     */ package com.osmb.api.utils;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UIResult<T>
/*     */   implements Result<T>
/*     */ {
/*     */   private final State state;
/*     */   private final T value;
/*     */   
/*     */   private UIResult(State state, T value) {
/*  31 */     this.state = state;
/*  32 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> UIResult<T> notVisible() {
/*  42 */     return new UIResult<>(State.NOT_VISIBLE, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> UIResult<T> of(T value) {
/*  53 */     return new UIResult<>(State.FOUND, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getIfFound() {
/*  62 */     return (this.state == State.FOUND && this.value != null) ? this.value : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotVisible() {
/*  72 */     return (this.state == State.NOT_VISIBLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNotFound() {
/*  81 */     return (this.value == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFound() {
/*  91 */     return (this.state == State.FOUND && this.value != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() {
/* 104 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T orElse(T other) {
/* 114 */     return isFound() ? this.value : other;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T orElseGet(Function<State, T> stateFallback) {
/* 124 */     return isFound() ? this.value : stateFallback.apply(this.state);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ifFound(Consumer<T> consumer) {
/* 133 */     if (isFound()) {
/* 134 */       consumer.accept(this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 145 */     switch (this.state) { default: throw new IncompatibleClassChangeError();
/*     */       case NOT_VISIBLE: 
/* 147 */       case FOUND: break; }  return "ThreeStateOptional[FOUND: " + this.value + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private enum State
/*     */   {
/* 155 */     NOT_VISIBLE,
/* 156 */     FOUND;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\UIResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */