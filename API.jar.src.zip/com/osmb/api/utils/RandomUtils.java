/*     */ package com.osmb.api.utils;
/*     */ 
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import java.awt.Point;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class RandomUtils
/*     */ {
/*   9 */   private static final Random random = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point generateRandomPoint(Rectangle rectangle, double stdDev) {
/*  21 */     double centerX = rectangle.x + rectangle.width / 2.0D;
/*  22 */     double centerY = rectangle.y + rectangle.height / 2.0D;
/*     */ 
/*     */     
/*  25 */     double offsetX = random.nextGaussian() * stdDev;
/*  26 */     double offsetY = random.nextGaussian() * stdDev;
/*     */ 
/*     */     
/*  29 */     double randomX = centerX + offsetX;
/*  30 */     double randomY = centerY + offsetY;
/*     */ 
/*     */     
/*  33 */     randomX = clamp(randomX, rectangle.x, (rectangle.x + rectangle.width));
/*  34 */     randomY = clamp(randomY, rectangle.y, (rectangle.y + rectangle.height));
/*     */     
/*  36 */     return new Point((int)randomX, (int)randomY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double clamp(double value, double min, double max) {
/*  48 */     return Math.max(min, Math.min(max, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int weightedRandom(int min, int max, double lambda) {
/*  59 */     double expRandom = -Math.log(1.0D - random.nextDouble()) / lambda;
/*  60 */     int result = (int)(min + expRandom % (max - min + 1));
/*  61 */     return Math.min(result, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int weightedRandom(int min, int max) {
/*  72 */     double lambda = 0.01D;
/*  73 */     double expRandom = -Math.log(1.0D - random.nextDouble()) / lambda;
/*  74 */     int result = (int)(min + expRandom % (max - min + 1));
/*  75 */     return Math.min(result, max);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int inverseWeightedRandom(int min, int max) {
/*  86 */     double lambda = 0.5D;
/*  87 */     return inverseWeightedRandom(min, max, lambda);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  91 */     for (int i = 0; i < 2011; i++) {
/*  92 */       int random = inverseWeightedRandom(0, 20, 0.3D);
/*     */       
/*  94 */       System.out.println(random);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int inverseWeightedRandom(int min, int max, double lambda) {
/* 109 */     double expRandom = -Math.log(random.nextDouble()) / lambda;
/* 110 */     int result = (int)(max - expRandom % (max - min + 1));
/* 111 */     return Math.max(result, min);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int gaussianRandom(int min, int max, double mean, double stdev) {
/*     */     while (true) {
/* 126 */       double gaussianValue = random.nextGaussian() * stdev + mean;
/* 127 */       if (gaussianValue >= min && gaussianValue <= max) {
/* 128 */         return (int)gaussianValue;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int triangularRandom(int min, int max, double midpoint) {
/* 140 */     double result, u = random.nextDouble();
/*     */     
/* 142 */     if (u < (midpoint - min) / (max - min)) {
/* 143 */       result = min + Math.sqrt(u * (max - min) * (midpoint - min));
/*     */     } else {
/* 145 */       result = max - Math.sqrt((1.0D - u) * (max - min) * (max - midpoint));
/*     */     } 
/* 147 */     return (int)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int uniformRandom(int min, int max) {
/* 158 */     return random.nextInt(max - min + 1) + min;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean generateRandomProbability(double minProbability, double maxProbability) {
/* 169 */     double probability = minProbability + (maxProbability - minProbability) * random.nextDouble();
/* 170 */     return (random.nextDouble() < probability);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\RandomUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */