/*    */ package com.osmb.api.utils;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.image.BufferedImage;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ public class ImagePanel extends JPanel {
/*    */   private JLabel imageLabel;
/*    */   
/*    */   public ImagePanel(BufferedImage image) {
/* 14 */     this.imageLabel = new JLabel(new ImageIcon(image));
/*    */ 
/*    */     
/* 17 */     JScrollPane scrollPane = new JScrollPane(this.imageLabel);
/* 18 */     scrollPane.setPreferredSize(new Dimension(500, 500));
/*    */ 
/*    */     
/* 21 */     setLayout(new BorderLayout());
/* 22 */     add(scrollPane, "Center");
/*    */   } private DrawableAwt customPainter;
/*    */   public ImagePanel(DrawableAwt customPainter, int width, int height) {
/* 25 */     this.customPainter = customPainter;
/* 26 */     setPreferredSize(new Dimension(width, height));
/*    */   }
/*    */   
/*    */   public void setImage(BufferedImage image) {
/* 30 */     this.imageLabel.setIcon(new ImageIcon(image));
/* 31 */     this.imageLabel.repaint();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void paintComponent(Graphics g) {
/* 36 */     super.paintComponent(g);
/*    */     
/* 38 */     if (this.customPainter != null) {
/* 39 */       this.customPainter.draw(g);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void showInFrame(String frameTitle) {
/* 45 */     JFrame frame = new JFrame(frameTitle);
/* 46 */     frame.setDefaultCloseOperation(2);
/*    */ 
/*    */     
/* 49 */     frame.add(this);
/*    */ 
/*    */     
/* 52 */     frame.pack();
/* 53 */     frame.setVisible(true);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\ImagePanel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */