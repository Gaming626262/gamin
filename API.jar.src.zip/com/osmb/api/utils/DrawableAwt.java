package com.osmb.api.utils;

import java.awt.Graphics;

public interface DrawableAwt {
  void draw(Graphics paramGraphics);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\DrawableAwt.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */