/*    */ package com.osmb.api.utils;
/*    */ 
/*    */ public enum TileSide {
/*  4 */   NW,
/*  5 */   N,
/*  6 */   NE,
/*  7 */   E,
/*  8 */   SE,
/*  9 */   S,
/* 10 */   SW,
/* 11 */   W;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\TileSide.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */