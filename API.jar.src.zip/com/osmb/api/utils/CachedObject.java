/*    */ package com.osmb.api.utils;
/*    */ 
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class CachedObject<T>
/*    */ {
/*    */   private final UUID screenUUID;
/*    */   private final T object;
/*    */   
/*    */   public CachedObject(UUID screenUUID, T object) {
/* 11 */     this.screenUUID = screenUUID;
/* 12 */     this.object = object;
/*    */   }
/*    */   
/*    */   public T getObject() {
/* 16 */     return this.object;
/*    */   }
/*    */   
/*    */   public UUID getScreenUUID() {
/* 20 */     return this.screenUUID;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 25 */     return "CachedObject{screenUUID=" + this.screenUUID + ", object=" + this.object + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\CachedObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */