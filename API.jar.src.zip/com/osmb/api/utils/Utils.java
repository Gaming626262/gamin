/*     */ package com.osmb.api.utils;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.location.Location3D;
/*     */ import com.osmb.api.location.position.Position;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.location.position.types.WorldPosition;
/*     */ import com.osmb.api.shape.Line;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.visual.SearchablePixel;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.ColorUtils;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javafx.embed.swing.SwingFXUtils;
/*     */ import javafx.scene.image.Image;
/*     */ import javafx.scene.image.ImageView;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ public class Utils {
/*  33 */   private static final Random random = new Random();
/*     */   
/*     */   private final ScriptCore core;
/*     */   
/*     */   public Utils(ScriptCore core) {
/*  38 */     this.core = core;
/*     */   }
/*     */   
/*     */   public static int random(int num) {
/*  42 */     return random.nextInt(num);
/*     */   }
/*     */   
/*     */   public static int random(int low, int high) {
/*  46 */     return low + random.nextInt(high - low - 1);
/*     */   }
/*     */   
/*     */   private static String replaceAfterLast(String input, String delimiter, String replacement, String missingDelimiterValue) {
/*  50 */     if (input == null || delimiter == null) {
/*  51 */       throw new IllegalArgumentException("Input and delimiter must not be null");
/*     */     }
/*     */     
/*  54 */     int index = input.lastIndexOf(delimiter);
/*  55 */     if (index == -1) {
/*  56 */       return missingDelimiterValue;
/*     */     }
/*  58 */     return input.substring(0, index + delimiter.length()) + input.substring(0, index + delimiter.length());
/*     */   }
/*     */ 
/*     */   
/*     */   private static String replaceAfterLast(String input, String delimiter, String replacement) {
/*  63 */     return replaceAfterLast(input, delimiter, replacement, input);
/*     */   }
/*     */   
/*     */   public static boolean lineIntersectsRectangle(Line line, Rectangle rectangle) {
/*  67 */     Point topLeft = new Point(rectangle.x, rectangle.y);
/*  68 */     Point topRight = new Point(rectangle.x + rectangle.width, rectangle.y);
/*  69 */     Point bottomLeft = new Point(rectangle.x, rectangle.y + rectangle.height);
/*  70 */     Point bottomRight = new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height);
/*     */     
/*  72 */     Line topEdge = new Line(topLeft, topRight);
/*  73 */     Line rightEdge = new Line(topRight, bottomRight);
/*  74 */     Line bottomEdge = new Line(bottomRight, bottomLeft);
/*  75 */     Line leftEdge = new Line(bottomLeft, topLeft);
/*     */ 
/*     */ 
/*     */     
/*  79 */     return (linesIntersect(line, topEdge) || linesIntersect(line, rightEdge) || linesIntersect(line, bottomEdge) || linesIntersect(line, leftEdge));
/*     */   }
/*     */   
/*     */   public static LocalDateTime stringToTimestamp(String input) {
/*  83 */     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss");
/*  84 */     String time = input.replace("T", " ");
/*  85 */     time = replaceAfterLast(time, ".", "");
/*  86 */     return LocalDateTime.parse(removeLastLetter(time), formatter);
/*     */   }
/*     */   
/*     */   private static String removeLastLetter(String str) {
/*  90 */     if (str == null || str.length() == 0) {
/*  91 */       return str;
/*     */     }
/*  93 */     return str.substring(0, str.length() - 1);
/*     */   }
/*     */   
/*     */   public static Point randomisePointByRadius(Point point, int radius) {
/*  97 */     int centerX = point.x;
/*  98 */     int centerY = point.y;
/*     */ 
/*     */     
/* 101 */     Random random = new Random();
/*     */     
/* 103 */     double angle = 6.283185307179586D * random.nextDouble();
/* 104 */     double randomRadius = radius * Math.sqrt(random.nextDouble());
/*     */ 
/*     */     
/* 107 */     int newX = centerX + (int)(randomRadius * Math.cos(angle));
/* 108 */     int newY = centerY + (int)(randomRadius * Math.sin(angle));
/*     */     
/* 110 */     return new Point(newX, newY);
/*     */   }
/*     */   
/*     */   public static byte[] BufferedImageToByteArray(BufferedImage bi, String format) throws IOException {
/* 114 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 115 */     ImageIO.write(bi, format, baos);
/* 116 */     byte[] bytes = baos.toByteArray();
/* 117 */     return bytes;
/*     */   }
/*     */   
/*     */   public static <T> T[] combineArray(T[] array1, T[] array2) {
/* 121 */     T[] result = Arrays.copyOf(array1, array1.length + array2.length);
/* 122 */     System.arraycopy(array2, 0, result, array1.length, array2.length);
/* 123 */     return result;
/*     */   }
/*     */   
/*     */   public static Position getClosestPosition(Position mainPosition, Position... positions) {
/* 127 */     return getClosestPosition(mainPosition, 2147483647, positions);
/*     */   }
/*     */   
/*     */   public static Position getClosestPosition(Position mainPosition, int maxDistance, Position... positions) {
/* 131 */     int lowestDistance = maxDistance;
/* 132 */     Position closestSpott = null;
/* 133 */     for (Position pos : positions) {
/* 134 */       int distance = mainPosition.distanceTo(pos.getX(), pos.getY());
/* 135 */       if (distance < lowestDistance) {
/* 136 */         lowestDistance = distance;
/* 137 */         closestSpott = pos;
/*     */       } 
/*     */     } 
/* 140 */     return closestSpott;
/*     */   }
/*     */   
/*     */   public static List<Point> generateHumanLikePath(Rectangle screenBounds, Point start, Point end) {
/* 144 */     List<Point> path = new ArrayList<>();
/*     */ 
/*     */     
/* 147 */     int controlX = clamp((start.x + end.x) / 2 + random.nextInt(100) - 50, screenBounds.x, screenBounds.x + screenBounds.width);
/* 148 */     int controlY = clamp((start.y + end.y) / 2 + random.nextInt(100) - 50, screenBounds.y, screenBounds.y + screenBounds.height);
/*     */ 
/*     */     
/* 151 */     double distance = start.distance(end);
/* 152 */     double stepSize = 20.0D / distance;
/*     */     
/*     */     double t;
/* 155 */     for (t = 0.0D; t <= 1.0D; t += stepSize) {
/* 156 */       int x = (int)((1.0D - t) * (1.0D - t) * start.x + 2.0D * (1.0D - t) * t * controlX + t * t * end.x);
/* 157 */       int y = (int)((1.0D - t) * (1.0D - t) * start.y + 2.0D * (1.0D - t) * t * controlY + t * t * end.y);
/*     */ 
/*     */       
/* 160 */       x += random.nextInt(3) - 1;
/* 161 */       y += random.nextInt(3) - 1;
/*     */ 
/*     */       
/* 164 */       x = clamp(x, screenBounds.x, screenBounds.x + screenBounds.width - 1);
/* 165 */       y = clamp(y, screenBounds.y, screenBounds.y + screenBounds.height - 1);
/*     */ 
/*     */       
/* 168 */       if (path.isEmpty() || !((Point)path.get(path.size() - 1)).equals(new Point(x, y))) {
/* 169 */         path.add(new Point(x, y));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 174 */     if (screenBounds.contains(end) && !path.contains(end)) {
/* 175 */       path.add(end);
/*     */     }
/*     */     
/* 178 */     return path;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int clamp(int value, int min, int max) {
/* 183 */     return Math.max(min, Math.min(max, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle createBoundingRectangle(List<Point> points) {
/* 202 */     if (points == null || points.isEmpty()) {
/* 203 */       throw new IllegalArgumentException("Point list cannot be null or empty.");
/*     */     }
/*     */ 
/*     */     
/* 207 */     int minX = Integer.MAX_VALUE;
/* 208 */     int minY = Integer.MAX_VALUE;
/* 209 */     int maxX = Integer.MIN_VALUE;
/* 210 */     int maxY = Integer.MIN_VALUE;
/*     */ 
/*     */     
/* 213 */     for (Point point : points) {
/* 214 */       minX = Math.min(minX, point.x);
/* 215 */       minY = Math.min(minY, point.y);
/* 216 */       maxX = Math.max(maxX, point.x);
/* 217 */       maxY = Math.max(maxY, point.y);
/*     */     } 
/*     */ 
/*     */     
/* 221 */     return new Rectangle(minX, minY, maxX - minX, maxY - minY);
/*     */   }
/*     */   
/*     */   public static List<LocalPosition> getPositionsWithinRadius(LocalPosition position, int radius) {
/* 225 */     List<LocalPosition> positions = new ArrayList<>();
/* 226 */     int startX = position.getX() - radius;
/* 227 */     int endX = position.getX() + radius;
/* 228 */     int startY = position.getY() - radius;
/* 229 */     int endY = position.getY() + radius;
/*     */     
/* 231 */     for (int x = startX; x <= endX; x++) {
/* 232 */       for (int y = startY; y <= endY; y++) {
/*     */         
/* 234 */         int dx = x - position.getX();
/* 235 */         int dy = y - position.getY();
/* 236 */         if (x >= 0 && y >= 0 && x < 128 && y < 128)
/*     */         {
/*     */           
/* 239 */           if (dx * dx + dy * dy <= radius * radius)
/* 240 */             positions.add(new LocalPosition(x, y, position.getPlane())); 
/*     */         }
/*     */       } 
/*     */     } 
/* 244 */     return positions;
/*     */   }
/*     */   
/*     */   public static List<WorldPosition> getPositionsWithinRadius(WorldPosition position, int radius) {
/* 248 */     List<WorldPosition> positions = new ArrayList<>();
/* 249 */     int startX = position.getX() - radius;
/* 250 */     int endX = position.getX() + radius;
/* 251 */     int startY = position.getY() - radius;
/* 252 */     int endY = position.getY() + radius;
/*     */     
/* 254 */     for (int x = startX; x <= endX; x++) {
/* 255 */       for (int y = startY; y <= endY; y++) {
/*     */         
/* 257 */         int dx = x - position.getX();
/* 258 */         int dy = y - position.getY();
/* 259 */         if (dx * dx + dy * dy <= radius * radius) {
/* 260 */           positions.add(new WorldPosition(x, y, position.getPlane()));
/*     */         }
/*     */       } 
/*     */     } 
/* 264 */     return positions;
/*     */   }
/*     */   
/*     */   private static boolean linesIntersect(Line line1, Line line2) {
/* 268 */     Point a = line1.getStart();
/* 269 */     Point b = line1.getEnd();
/* 270 */     Point c = line2.getStart();
/* 271 */     Point d = line2.getEnd();
/*     */ 
/*     */     
/* 274 */     int det1 = orientation(a, b, c);
/* 275 */     int det2 = orientation(a, b, d);
/* 276 */     int det3 = orientation(c, d, a);
/* 277 */     int det4 = orientation(c, d, b);
/*     */ 
/*     */     
/* 280 */     if (det1 != det2 && det3 != det4) {
/* 281 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 285 */     return ((det1 == 0 && onSegment(a, c, b)) || (det2 == 0 && onSegment(a, d, b)) || (det3 == 0 && onSegment(c, a, d)) || (det4 == 0 && onSegment(c, b, d)));
/*     */   }
/*     */   
/*     */   private static int orientation(Point p, Point q, Point r) {
/* 289 */     int val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
/* 290 */     if (val == 0) return 0; 
/* 291 */     return (val > 0) ? 1 : -1;
/*     */   }
/*     */   
/*     */   private static boolean onSegment(Point p, Point q, Point r) {
/* 295 */     return (q.getX() >= Math.min(p.getX(), r.getX()) && q.getX() <= Math.max(p.getX(), r.getX()) && q.getY() >= Math.min(p.getY(), r.getY()) && q.getY() <= Math.max(p.getY(), r.getY()));
/*     */   }
/*     */   
/*     */   public Rectangle getHighlightBounds(Shape shape, SearchablePixel... highlightColors) {
/* 299 */     Image screenImage = this.core.getScreen().getImage();
/* 300 */     int screenWidth = screenImage.getWidth();
/* 301 */     int screenHeight = screenImage.getHeight();
/*     */     
/* 303 */     Rectangle bounds = null;
/* 304 */     if (shape != null) {
/* 305 */       bounds = shape.getBounds();
/*     */     }
/*     */     
/* 308 */     int startX = Math.max(0, bounds.x);
/* 309 */     int startY = Math.max(0, bounds.y);
/* 310 */     int endX = Math.min(bounds.x + bounds.width, screenWidth);
/* 311 */     int endY = Math.min(bounds.y + bounds.height, screenHeight);
/*     */ 
/*     */     
/* 314 */     int minX = Integer.MAX_VALUE;
/* 315 */     int minY = Integer.MAX_VALUE;
/* 316 */     int maxX = Integer.MIN_VALUE;
/* 317 */     int maxY = Integer.MIN_VALUE;
/*     */     
/* 319 */     boolean isRect = shape instanceof Rectangle;
/*     */ 
/*     */     
/* 322 */     for (int x = startX; x < endX; x++) {
/* 323 */       for (int y = startY; y < endY; y++) {
/* 324 */         if (shape == null || isRect || 
/* 325 */           shape.contains(x, y)) {
/*     */           
/* 327 */           int pixelColor = screenImage.getRGB(x, y);
/* 328 */           boolean match = false;
/* 329 */           for (SearchablePixel highlightColor : highlightColors) {
/* 330 */             switch (highlightColor.getColorModel()) {
/*     */               case RGB:
/* 332 */                 match = ColorUtils.isRGBinsideThreshold(highlightColor.getToleranceComparator(), pixelColor, highlightColor.getRgb()); break;
/*     */               case HSL:
/* 334 */                 match = ColorUtils.isHSLinsideThreshold(highlightColor.getToleranceComparator(), pixelColor, highlightColor.getRgb()); break;
/*     */             } 
/* 336 */             if (match)
/*     */               break; 
/* 338 */           }  if (match) {
/*     */             
/* 340 */             minX = Math.min(minX, x);
/* 341 */             minY = Math.min(minY, y);
/* 342 */             maxX = Math.max(maxX, x);
/* 343 */             maxY = Math.max(maxY, y);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 349 */     if (minX == Integer.MAX_VALUE || minY == Integer.MAX_VALUE)
/*     */     {
/* 351 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 355 */     return new Rectangle(minX, minY, maxX - minX + 1, maxY - minY + 1);
/*     */   }
/*     */   
/*     */   public Location3D getClosest(List<? extends Location3D> objects) {
/* 359 */     WorldPosition myPosition = this.core.getWorldPosition();
/* 360 */     int lowestDistance = Integer.MAX_VALUE;
/* 361 */     Location3D closest = null;
/* 362 */     for (Location3D obj : objects) {
/* 363 */       int distance = obj.getWorldPosition().distanceTo((Position)myPosition);
/* 364 */       if (distance < lowestDistance) {
/* 365 */         lowestDistance = distance;
/* 366 */         closest = obj;
/*     */       } 
/*     */     } 
/* 369 */     return closest;
/*     */   }
/*     */   
/*     */   public BufferedImage getImageResource(String name) throws IOException {
/* 373 */     InputStream in = this.core.getClass().getResourceAsStream("/script/images/" + name + ".png");
/*     */     try {
/* 375 */       BufferedImage image = ImageIO.read(in);
/* 376 */       in.close();
/* 377 */       BufferedImage bufferedImage1 = image;
/* 378 */       if (in != null) in.close();
/*     */       
/*     */       return bufferedImage1;
/*     */     } catch (Throwable throwable) {
/*     */       if (in != null) {
/*     */         try {
/*     */           in.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */       }
/*     */       throw throwable;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle[] getTextBounds(Rectangle bounds, int maxHeight, int textColor) {
/* 397 */     List<Rectangle> textBounds = new ArrayList<>();
/* 398 */     Image screenImage = this.core.getScreen().getImage();
/* 399 */     int startY = -1;
/* 400 */     for (int y = bounds.y; y < bounds.y + bounds.height; y++) {
/* 401 */       boolean found = false;
/* 402 */       for (int x = bounds.x; x < bounds.x + bounds.width; x++) {
/* 403 */         int rgb = screenImage.getRGB(x, y);
/* 404 */         if (rgb == textColor) {
/* 405 */           found = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 409 */       if (found && startY == -1) {
/* 410 */         startY = y;
/* 411 */       } else if (startY != -1 && (!found || y - startY >= maxHeight)) {
/* 412 */         textBounds.add(new Rectangle(bounds.x, startY, bounds.width, y - startY));
/* 413 */         startY = -1;
/*     */       } 
/*     */     } 
/* 416 */     return textBounds.<Rectangle>toArray(new Rectangle[0]);
/*     */   }
/*     */   
/*     */   public static Point getRandomPointOutside(Rectangle rectangle, Rectangle parent, int maxDistance) {
/* 420 */     Random random = new Random();
/*     */     
/* 422 */     int leftAreaWidth = Math.min(rectangle.x - parent.x, maxDistance);
/* 423 */     int rightAreaWidth = Math.min(parent.x + parent.width - rectangle.x + rectangle.width, maxDistance);
/* 424 */     int topAreaHeight = Math.min(rectangle.y - parent.y, maxDistance);
/* 425 */     int bottomAreaHeight = Math.min(parent.y + parent.height - rectangle.y + rectangle.height, maxDistance);
/*     */     
/* 427 */     Rectangle[] areas = { new Rectangle(rectangle.x - leftAreaWidth, rectangle.y, leftAreaWidth, rectangle.height), new Rectangle(rectangle.x + rectangle.width, rectangle.y, rightAreaWidth, rectangle.height), new Rectangle(rectangle.x - leftAreaWidth, rectangle.y - topAreaHeight, rectangle.width + leftAreaWidth + rightAreaWidth, topAreaHeight), new Rectangle(rectangle.x - leftAreaWidth, rectangle.y + rectangle.height, rectangle.width + leftAreaWidth + rightAreaWidth, bottomAreaHeight) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     Rectangle[] validAreas = (Rectangle[])Arrays.<Rectangle>stream(areas).filter(r -> (r.width > 0 && r.height > 0)).toArray(x$0 -> new Rectangle[x$0]);
/*     */     
/* 439 */     if (validAreas.length == 0) {
/* 440 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 444 */     Rectangle randomArea = validAreas[random.nextInt(validAreas.length)];
/*     */     
/* 446 */     int randomX = randomArea.x + random.nextInt(Math.max(1, randomArea.width));
/* 447 */     int randomY = randomArea.y + random.nextInt(Math.max(1, randomArea.height));
/*     */     
/* 449 */     return new Point(randomX, randomY);
/*     */   }
/*     */   
/*     */   public static ImageView imageToImageView(Image image) {
/* 453 */     BufferedImage itemBufferedImage = image.toBufferedImage();
/* 454 */     WritableImage writableImage = SwingFXUtils.toFXImage(itemBufferedImage, null);
/* 455 */     return new ImageView((Image)writableImage);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\Utils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */