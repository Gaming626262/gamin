/*    */ package com.osmb.api.utils.timing;
/*    */ 
/*    */ public class Stopwatch
/*    */ {
/*    */   public long stopTime;
/*    */   
/*    */   public Stopwatch(long time) {
/*  8 */     reset(time);
/*    */   }
/*    */   
/*    */   public Stopwatch() {
/* 12 */     this.stopTime = 0L;
/*    */   }
/*    */   
/*    */   public void reset(long time) {
/* 16 */     this.stopTime = System.currentTimeMillis() + time;
/*    */   }
/*    */   
/*    */   public long timeLeft() {
/* 20 */     return this.stopTime - System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public boolean hasFinished() {
/* 24 */     return (System.currentTimeMillis() >= this.stopTime);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\timing\Stopwatch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */