/*    */ package com.osmb.api.utils.timing;
/*    */ 
/*    */ public class Timer
/*    */ {
/*    */   public long startTime;
/*    */   
/*    */   public Timer(long time) {
/*  8 */     this.startTime = time;
/*    */   }
/*    */   
/*    */   public Timer() {
/* 12 */     this.startTime = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset() {
/* 19 */     this.startTime = System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public long timeElapsed() {
/* 28 */     return System.currentTimeMillis() - this.startTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\timing\Timer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */