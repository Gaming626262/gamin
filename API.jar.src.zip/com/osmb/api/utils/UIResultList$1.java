/*     */ package com.osmb.api.utils;


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\utils\UIResultList$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */