/*    */ package com.osmb.api.location;
/*    */ 
/*    */ import com.osmb.api.location.position.types.LocalPosition;
/*    */ import com.osmb.api.location.position.types.WorldPosition;
/*    */ 
/*    */ public interface Location3D {
/*    */   int getWorldX();
/*    */   
/*    */   int getWorldY();
/*    */   
/*    */   int getPlane();
/*    */   
/*    */   int getLocalX();
/*    */   
/*    */   int getLocalY();
/*    */   
/*    */   int getSceneX();
/*    */   
/*    */   int getSceneY();
/*    */   
/*    */   int getSceneZ();
/*    */   
/*    */   default WorldPosition getWorldPosition() {
/* 24 */     return new WorldPosition(getWorldX(), getWorldY(), getPlane());
/*    */   }
/*    */   
/*    */   default LocalPosition getLocalPosition() {
/* 28 */     return new LocalPosition(getLocalX(), getLocalY(), getPlane());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\Location3D.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */