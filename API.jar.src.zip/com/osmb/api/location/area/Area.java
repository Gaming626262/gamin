package com.osmb.api.location.area;

import com.osmb.api.location.position.Position;
import java.awt.Point;
import java.awt.Rectangle;

public interface Area {
  boolean contains(int paramInt1, int paramInt2, int paramInt3);
  
  boolean contains(Position paramPosition);
  
  Point getCenter();
  
  Position getRandomPosition();
  
  Rectangle getBounds();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\area\Area.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */