/*    */ package com.osmb.api.location.area.impl;
/*    */ 
/*    */ import com.osmb.api.location.area.Area;
/*    */ import com.osmb.api.location.position.Position;
/*    */ import com.osmb.api.utils.Utils;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PolyArea
/*    */   implements Area {
/*    */   private final List<Point> vertices;
/*    */   private final int plane;
/*    */   
/*    */   public PolyArea(List<Point> vertices, int plane) {
/* 17 */     this.vertices = vertices;
/* 18 */     this.plane = plane;
/*    */   }
/*    */   
/*    */   public PolyArea(int[][] xyPoints, int plane) {
/* 22 */     this.vertices = new ArrayList<>();
/* 23 */     for (int i = 0; i < xyPoints.length; i++) {
/* 24 */       this.vertices.add(new Point(xyPoints[i][0], xyPoints[i][1]));
/*    */     }
/* 26 */     this.plane = plane;
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getBounds() {
/* 31 */     int minX = Integer.MAX_VALUE;
/* 32 */     int minY = Integer.MAX_VALUE;
/* 33 */     int maxX = Integer.MIN_VALUE;
/* 34 */     int maxY = Integer.MIN_VALUE;
/*    */     
/* 36 */     for (Point vertex : this.vertices) {
/* 37 */       minX = Math.min(minX, vertex.x);
/* 38 */       minY = Math.min(minY, vertex.y);
/* 39 */       maxX = Math.max(maxX, vertex.x);
/* 40 */       maxY = Math.max(maxY, vertex.y);
/*    */     } 
/*    */     
/* 43 */     return new Rectangle(minX, minY, maxX - minX, maxY - minY);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(Position position) {
/* 48 */     return contains(position.getX(), position.getY(), this.plane);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(int x, int y, int plane) {
/* 53 */     int n = this.vertices.size();
/* 54 */     boolean inside = false;
/*    */     int j;
/* 56 */     for (int i = 0; i < n; j = i++) {
/* 57 */       Point p1 = this.vertices.get(i);
/* 58 */       Point p2 = this.vertices.get(j);
/*    */       
/* 60 */       if (((p1.y <= y && y < p2.y) || (p2.y <= y && y < p1.y)) && x < p1.x + (y - p1.y) * (p2.x - p1.x) / (p2.y - p1.y)) {
/* 61 */         inside = !inside;
/*    */       }
/*    */     } 
/*    */     
/* 65 */     return (inside && plane == this.plane);
/*    */   }
/*    */   
/*    */   public Point getCenter() {
/* 69 */     int totalX = 0;
/* 70 */     int totalY = 0;
/*    */     
/* 72 */     for (Point vertex : this.vertices) {
/* 73 */       totalX += vertex.x;
/* 74 */       totalY += vertex.y;
/*    */     } 
/*    */     
/* 77 */     int centerX = totalX / this.vertices.size();
/* 78 */     int centerY = totalY / this.vertices.size();
/*    */     
/* 80 */     return new Point(centerX, centerY);
/*    */   }
/*    */   
/*    */   public Position getRandomPosition() {
/*    */     Point randomPoint;
/* 85 */     Rectangle bounds = getBounds();
/*    */     
/*    */     do {
/* 88 */       int randomX = bounds.x + Utils.random(bounds.width);
/* 89 */       int randomY = bounds.y + Utils.random(bounds.height);
/*    */       
/* 91 */       randomPoint = new Point(randomX, randomY);
/*    */     }
/* 93 */     while (!contains(randomPoint.x, randomPoint.y, this.plane));
/*    */ 
/*    */ 
/*    */     
/* 97 */     return new Position(randomPoint.x, randomPoint.y, this.plane);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\area\impl\PolyArea.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */