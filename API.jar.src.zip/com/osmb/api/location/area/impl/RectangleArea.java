/*    */ package com.osmb.api.location.area.impl;
/*    */ 
/*    */ import com.osmb.api.location.area.Area;
/*    */ import com.osmb.api.location.position.Position;
/*    */ import com.osmb.api.location.position.types.WorldPosition;
/*    */ import com.osmb.api.utils.Utils;
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ public class RectangleArea implements Area {
/*    */   private final int x;
/*    */   private final int y;
/*    */   private final int width;
/*    */   private final int height;
/*    */   private final int plane;
/*    */   
/*    */   public RectangleArea(int x, int y, int width, int height, int plane) {
/* 18 */     this.x = x;
/* 19 */     this.y = y;
/* 20 */     this.width = width;
/* 21 */     this.height = height;
/* 22 */     this.plane = plane;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 26 */     return this.height;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 30 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 34 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 38 */     return this.width;
/*    */   }
/*    */   
/*    */   public int getPlane() {
/* 42 */     return this.plane;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(int x, int y, int plane) {
/* 47 */     return (x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height && this.plane == plane);
/*    */   }
/*    */ 
/*    */   
/*    */   public WorldPosition getRandomPosition() {
/* 52 */     int x = this.x;
/* 53 */     int y = this.y;
/* 54 */     int w = Math.abs(this.width);
/* 55 */     int h = Math.abs(this.height);
/*    */     
/* 57 */     int randomX = (w == 0) ? 0 : Utils.random(w);
/* 58 */     int randomY = (h == 0) ? 0 : Utils.random(h);
/*    */     
/* 60 */     if (this.width < 0) {
/* 61 */       x += this.width;
/*    */     }
/* 63 */     if (this.height < 0) {
/* 64 */       y += this.height;
/*    */     }
/*    */     
/* 67 */     return new WorldPosition(x + randomX, y + randomY, this.plane);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(Position position) {
/* 72 */     return contains(position.getX(), position.getY(), position.getPlane());
/*    */   }
/*    */ 
/*    */   
/*    */   public Point getCenter() {
/* 77 */     int centerX = this.x + this.width / 2;
/* 78 */     int centerY = this.y + this.height / 2;
/* 79 */     return new Point(centerX, centerY);
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getBounds() {
/* 84 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\area\impl\RectangleArea.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */