/*    */ package com.osmb.api.location.position.types;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.location.position.Position;
/*    */ import com.osmb.api.scene.SceneManager;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class WorldPosition
/*    */   extends Position {
/*    */   public WorldPosition(int x, int y, int plane) {
/* 12 */     super(x, y, plane);
/*    */   }
/*    */   
/*    */   public WorldPosition(int x, int y, int plane, double remainderX, double remainderY) {
/* 16 */     super(x, y, plane, remainderX, remainderY);
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 20 */     int baseX = 2245;
/* 21 */     int baseY = 4672;
/* 22 */     int regionX = baseX >> 6;
/* 23 */     int regionY = baseY >> 6;
/*    */ 
/*    */     
/* 26 */     int regionID = regionX << 8 | regionY;
/*    */   }
/*    */   
/*    */   public LocalPosition toLocalPosition(ScriptCore scriptCoreService) {
/* 30 */     SceneManager sceneManager = scriptCoreService.getSceneManager();
/* 31 */     int x = getX() - sceneManager.getSceneBaseTileX();
/* 32 */     int y = getY() - sceneManager.getSceneBaseTileY();
/* 33 */     if (x > 128 || y > 128) {
/* 34 */       return null;
/*    */     }
/* 36 */     return new LocalPosition(getX() - sceneManager.getSceneBaseTileX(), getY() - sceneManager.getSceneBaseTileY(), getPlane(), getRemainderX(), getRemainderY());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<WorldPosition> createLine(double angle, int lineLength) {
/* 48 */     List<WorldPosition> line = new ArrayList<>();
/*    */ 
/*    */     
/* 51 */     double radians = Math.toRadians(angle);
/*    */ 
/*    */     
/* 54 */     double dx = Math.cos(radians);
/* 55 */     double dy = Math.sin(radians);
/*    */ 
/*    */     
/* 58 */     double currentX = getX();
/* 59 */     double currentY = getY();
/* 60 */     for (int i = 0; i < lineLength; i++) {
/* 61 */       currentX += dx;
/* 62 */       currentY += dy;
/*    */ 
/*    */       
/* 65 */       line.add(new WorldPosition((int)Math.round(currentX), (int)Math.round(currentY), getPlane()));
/*    */     } 
/* 67 */     return line;
/*    */   }
/*    */   
/*    */   public int getRegionID() {
/* 71 */     int regionX = getX() >> 6;
/* 72 */     int regionY = getY() >> 6;
/*    */ 
/*    */     
/* 75 */     return regionX << 8 | regionY;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\position\types\WorldPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */