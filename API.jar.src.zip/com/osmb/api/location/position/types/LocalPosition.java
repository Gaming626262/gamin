/*    */ package com.osmb.api.location.position.types;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.location.position.Position;
/*    */ import com.osmb.api.scene.SceneManager;
/*    */ 
/*    */ public class LocalPosition extends Position {
/*    */   public LocalPosition(int x, int y, int plane) {
/*  9 */     super(x, y, plane);
/*    */   }
/*    */   
/*    */   public LocalPosition(int x, int y, int plane, double remainderX, double remainderY) {
/* 13 */     super(x, y, plane, remainderX, remainderY);
/*    */   }
/*    */   
/*    */   public boolean isValid() {
/* 17 */     return (getX() > 0 && getY() > 0 && getX() < 128 && getY() < 128);
/*    */   }
/*    */   
/*    */   public WorldPosition toWorldPosition(ScriptCore scriptCoreService) {
/* 21 */     SceneManager sceneManager = scriptCoreService.getSceneManager();
/* 22 */     return new WorldPosition(getX() + sceneManager.getSceneBaseTileX(), getY() + sceneManager.getSceneBaseTileY(), getPlane(), getRemainderX(), getRemainderY());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\position\types\LocalPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */