/*     */ package com.osmb.api.location.position;
/*     */ 
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.walker.pathing.WalkDirection;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Position
/*     */ {
/*     */   private final int x;
/*     */   private final int y;
/*     */   private final int plane;
/*     */   private final double remainderX;
/*     */   private final double remainderY;
/*     */   
/*     */   public Position(int x, int y, int plane) {
/*  21 */     this.x = x;
/*  22 */     this.y = y;
/*  23 */     this.plane = plane;
/*  24 */     this.remainderX = 0.0D;
/*  25 */     this.remainderY = 0.0D;
/*     */   }
/*     */   
/*     */   public Position(int x, int y, int plane, double remainderX, double remainderY) {
/*  29 */     this.x = x;
/*  30 */     this.y = y;
/*  31 */     this.plane = plane;
/*  32 */     this.remainderX = remainderX;
/*  33 */     this.remainderY = remainderY;
/*     */   }
/*     */   
/*     */   public int getX() {
/*  37 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getY() {
/*  41 */     return this.y;
/*     */   }
/*     */   
/*     */   public int getPlane() {
/*  45 */     return this.plane;
/*     */   }
/*     */   
/*     */   public int distanceTo(int x, int y) {
/*  49 */     int deltaX = x - this.x;
/*  50 */     int deltaY = y - this.y;
/*     */ 
/*     */     
/*  53 */     return (int)Math.sqrt((deltaX * deltaX + deltaY * deltaY));
/*     */   }
/*     */   
/*     */   public int distanceTo(Position position) {
/*  57 */     int deltaX = position.getX() - this.x;
/*  58 */     int deltaY = position.getY() - this.y;
/*     */ 
/*     */     
/*  61 */     return (int)Math.sqrt((deltaX * deltaX + deltaY * deltaY));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  66 */     return getClass().getSimpleName() + ": x=" + getClass().getSimpleName() + ", y=" + this.x + ", plane=" + this.y;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  71 */     if (this == o) return true; 
/*  72 */     if (o == null || getClass() != o.getClass()) return false; 
/*  73 */     Position position = (Position)o;
/*  74 */     return (this.x == position.x && this.y == position.y && this.plane == position.plane);
/*     */   }
/*     */   
/*     */   public boolean equalsIgnorePlane(Position position) {
/*  78 */     if (position == null) return false; 
/*  79 */     return (this.x == position.x && this.y == position.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalPosition step(int num, WalkDirection walkDirection) {
/*  90 */     return new LocalPosition(getX() + num * walkDirection.deltaX(), getY() + num * walkDirection.deltaY(), getPlane());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double angleTo(Position other) {
/* 101 */     int deltaX = other.getX() - this.x;
/* 102 */     int deltaY = other.getY() - this.y;
/*     */ 
/*     */     
/* 105 */     double radians = Math.atan2(deltaY, deltaX);
/*     */ 
/*     */     
/* 108 */     double degrees = Math.toDegrees(radians);
/*     */ 
/*     */     
/* 111 */     if (degrees < 0.0D) {
/* 112 */       degrees += 360.0D;
/*     */     }
/*     */     
/* 115 */     return degrees;
/*     */   }
/*     */   public double getRemainderY() {
/* 118 */     return this.remainderY;
/*     */   }
/*     */   
/*     */   public double getRemainderX() {
/* 122 */     return this.remainderX;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 127 */     return Objects.hash(new Object[] { Integer.valueOf(this.x), Integer.valueOf(this.y), Integer.valueOf(this.plane) });
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\location\position\Position.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */