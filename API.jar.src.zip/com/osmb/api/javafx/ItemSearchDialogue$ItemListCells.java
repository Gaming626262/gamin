/*    */ package com.osmb.api.javafx;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.definition.ItemDefinition;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.ListCell;
/*    */ import javafx.scene.image.ImageView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ItemListCells
/*    */   extends ListCell<ItemDefinition>
/*    */ {
/*    */   private final ScriptCore core;
/*    */   
/*    */   public ItemListCells(ScriptCore core) {
/* 78 */     this.core = core;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateItem(ItemDefinition itemDefinition, boolean empty) {
/* 83 */     super.updateItem(itemDefinition, empty);
/*    */     
/* 85 */     if (!empty) {
/* 86 */       ImageView itemImageView = JavaFXUtils.getItemImageView(this.core, itemDefinition.id);
/* 87 */       setGraphic((Node)itemImageView);
/* 88 */       setText(itemDefinition.name + " [ID: " + itemDefinition.name + "]");
/*    */     } else {
/* 90 */       setGraphic(null);
/* 91 */       setText(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\ItemSearchDialogue$ItemListCells.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */