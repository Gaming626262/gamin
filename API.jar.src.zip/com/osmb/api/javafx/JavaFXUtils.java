/*    */ package com.osmb.api.javafx;
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.definition.ItemDefinition;
/*    */ import com.osmb.api.item.ZoomType;
/*    */ import com.osmb.api.visual.color.ColorUtils;
/*    */ import com.osmb.api.visual.image.Image;
/*    */ import java.awt.image.BufferedImage;
/*    */ import javafx.embed.swing.SwingFXUtils;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.ComboBox;
/*    */ import javafx.scene.control.ListCell;
/*    */ import javafx.scene.control.ListView;
/*    */ import javafx.scene.image.Image;
/*    */ import javafx.scene.image.ImageView;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ public class JavaFXUtils {
/*    */   public static ComboBox<Integer> createItemCombobox(final ScriptCore core, int[] values) {
/* 20 */     ComboBox<Integer> productComboBox = new ComboBox();
/* 21 */     productComboBox.setConverter(new StringConverter<Integer>()
/*    */         {
/*    */           public String toString(Integer item) {
/* 24 */             if (item == null) {
/* 25 */               return null;
/*    */             }
/* 27 */             return (item.intValue() >= 0) ? JavaFXUtils.getItemName(core, item.intValue()) : null;
/*    */           }
/*    */ 
/*    */ 
/*    */           
/*    */           public Integer fromString(String string) {
/* 33 */             return null;
/*    */           }
/*    */         });
/* 36 */     productComboBox.setCellFactory(param -> new ListCell<Integer>()
/*    */         {
/*    */           protected void updateItem(Integer item, boolean empty) {
/* 39 */             super.updateItem(item, empty);
/* 40 */             if (item != null && !empty) {
/* 41 */               String name = JavaFXUtils.getItemName(core, item.intValue());
/* 42 */               ImageView itemImage = JavaFXUtils.getItemImageView(core, item.intValue());
/* 43 */               setGraphic((Node)itemImage);
/* 44 */               setText(name);
/*    */             } else {
/* 46 */               setText(null);
/* 47 */               setGraphic(null);
/*    */             } 
/*    */           }
/*    */         });
/* 51 */     Integer[] integers = new Integer[values.length];
/* 52 */     for (int i = 0; i < values.length; i++) {
/* 53 */       integers[i] = Integer.valueOf(values[i]);
/*    */     }
/* 55 */     productComboBox.getItems().addAll((Object[])integers);
/* 56 */     return productComboBox;
/*    */   }
/*    */   
/*    */   private static String getItemName(ScriptCore core, int itemID) {
/* 60 */     ItemDefinition def = core.getItemManager().getItemDefinition(itemID);
/* 61 */     String name = null;
/* 62 */     if (def != null && def.name != null) {
/* 63 */       name = def.name;
/*    */     }
/* 65 */     return name;
/*    */   }
/*    */   
/*    */   public static ImageView getItemImageView(ScriptCore core, int itemID) {
/* 69 */     Image itemImage = core.getItemManager().getItemImage(itemID, 1, ZoomType.SIZE_1, 16711935);
/*    */     
/* 71 */     BufferedImage bufferedImage = itemImage.toBufferedImage();
/*    */ 
/*    */     
/* 74 */     for (int y = 0; y < bufferedImage.getHeight(); y++) {
/* 75 */       for (int x = 0; x < bufferedImage.getWidth(); x++) {
/* 76 */         int pixel = ColorUtils.removeAlphaChannel(bufferedImage.getRGB(x, y));
/* 77 */         if (pixel == 16711935)
/*    */         {
/* 79 */           bufferedImage.setRGB(x, y, 16777215);
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 84 */     return new ImageView((Image)SwingFXUtils.toFXImage(bufferedImage, null));
/*    */   }
/*    */ 
/*    */   
/*    */   public static void centerPopupStage(Stage mainStage, Stage popupStage) {
/* 89 */     double mainX = mainStage.getX() + mainStage.getWidth() / 2.0D;
/* 90 */     double mainY = mainStage.getY() + mainStage.getHeight() / 2.0D;
/*    */ 
/*    */     
/* 93 */     double popupX = mainX - popupStage.getWidth() / 2.0D;
/* 94 */     double popupY = mainY - popupStage.getHeight() / 2.0D;
/*    */ 
/*    */     
/* 97 */     popupStage.setX(popupX);
/* 98 */     popupStage.setY(popupY);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\JavaFXUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */