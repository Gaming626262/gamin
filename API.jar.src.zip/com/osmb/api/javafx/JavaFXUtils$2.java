/*    */ package com.osmb.api.javafx;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.control.ListCell;
/*    */ import javafx.scene.image.ImageView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends ListCell<Integer>
/*    */ {
/*    */   protected void updateItem(Integer item, boolean empty) {
/* 39 */     super.updateItem(item, empty);
/* 40 */     if (item != null && !empty) {
/* 41 */       String name = JavaFXUtils.getItemName(core, item.intValue());
/* 42 */       ImageView itemImage = JavaFXUtils.getItemImageView(core, item.intValue());
/* 43 */       setGraphic((Node)itemImage);
/* 44 */       setText(name);
/*    */     } else {
/* 46 */       setText(null);
/* 47 */       setGraphic(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\JavaFXUtils$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */