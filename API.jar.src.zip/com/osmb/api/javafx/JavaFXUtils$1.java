/*    */ package com.osmb.api.javafx;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import javafx.util.StringConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends StringConverter<Integer>
/*    */ {
/*    */   public String toString(Integer item) {
/* 24 */     if (item == null) {
/* 25 */       return null;
/*    */     }
/* 27 */     return (item.intValue() >= 0) ? JavaFXUtils.getItemName(core, item.intValue()) : null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Integer fromString(String string) {
/* 33 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\JavaFXUtils$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */