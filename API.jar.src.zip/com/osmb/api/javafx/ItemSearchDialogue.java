/*    */ package com.osmb.api.javafx;
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.definition.ItemDefinition;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import javafx.collections.FXCollections;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.Button;
/*    */ import javafx.scene.control.ListCell;
/*    */ import javafx.scene.control.ListView;
/*    */ import javafx.scene.control.TextField;
/*    */ import javafx.scene.image.ImageView;
/*    */ import javafx.scene.layout.VBox;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.Window;
/*    */ import javafx.stage.WindowEvent;
/*    */ 
/*    */ public class ItemSearchDialogue {
/* 24 */   private static ObservableList<ItemDefinition> dataList = FXCollections.observableArrayList();
/* 25 */   private static ObservableList<ItemDefinition> filteredList = FXCollections.observableArrayList();
/*    */   
/*    */   public static int show(ScriptCore core, Stage primaryStage) {
/* 28 */     if (dataList.isEmpty()) {
/* 29 */       List<ItemDefinition> itemDefinitions = new ArrayList<>(core.getItemManager().getItemDefinitions());
/* 30 */       itemDefinitions.removeIf(itemDefinition -> (itemDefinition.name == null || itemDefinition.name.equalsIgnoreCase("null")));
/* 31 */       dataList.addAll(itemDefinitions);
/*    */     } 
/*    */     
/* 34 */     TextField searchBox = new TextField();
/* 35 */     searchBox.setPromptText("Type item name here...");
/*    */     
/* 37 */     ListView<ItemDefinition> listView = new ListView(filteredList);
/* 38 */     listView.setCellFactory(param -> new ItemListCells(core));
/*    */     
/* 40 */     filteredList.addAll((Collection)dataList);
/*    */ 
/*    */     
/* 43 */     searchBox.textProperty().addListener((observable, oldValue, newValue) -> {
/*    */           filteredList.clear();
/*    */           
/*    */           String searchText = newValue.toLowerCase();
/*    */           if (searchText.isEmpty()) {
/*    */             filteredList.addAll((Collection)dataList);
/*    */           } else {
/*    */             Objects.requireNonNull(filteredList);
/*    */             dataList.stream().filter(()).forEach(filteredList::add);
/*    */           } 
/*    */         });
/* 54 */     Button confirmButton = new Button("Confirm");
/*    */     
/* 56 */     confirmButton.setOnAction(actionEvent -> ((Stage)confirmButton.getScene().getWindow()).close());
/* 57 */     VBox root = new VBox(10.0D, new Node[] { (Node)searchBox, (Node)listView, (Node)confirmButton });
/* 58 */     root.setStyle("-fx-background-color: #636E72;-fx-padding: 15; -fx-font-size: 14px;");
/*    */     
/* 60 */     Scene scene = new Scene((Parent)root, 300.0D, 400.0D);
/* 61 */     scene.getStylesheets().add(ScriptCore.class.getResource("/style.css").toExternalForm());
/* 62 */     Stage stage = new Stage();
/* 63 */     stage.setScene(scene);
/* 64 */     stage.initOwner((Window)primaryStage);
/* 65 */     stage.setOnShown(windowEvent -> JavaFXUtils.centerPopupStage(primaryStage, stage));
/* 66 */     stage.showAndWait();
/* 67 */     ItemDefinition selectedItem = (ItemDefinition)listView.getSelectionModel().getSelectedItem();
/*    */     
/* 69 */     return (selectedItem == null) ? -1 : selectedItem.id;
/*    */   }
/*    */   
/*    */   private static class ItemListCells
/*    */     extends ListCell<ItemDefinition>
/*    */   {
/*    */     private final ScriptCore core;
/*    */     
/*    */     public ItemListCells(ScriptCore core) {
/* 78 */       this.core = core;
/*    */     }
/*    */ 
/*    */     
/*    */     protected void updateItem(ItemDefinition itemDefinition, boolean empty) {
/* 83 */       super.updateItem(itemDefinition, empty);
/*    */       
/* 85 */       if (!empty) {
/* 86 */         ImageView itemImageView = JavaFXUtils.getItemImageView(this.core, itemDefinition.id);
/* 87 */         setGraphic((Node)itemImageView);
/* 88 */         setText(itemDefinition.name + " [ID: " + itemDefinition.name + "]");
/*    */       } else {
/* 90 */         setGraphic(null);
/* 91 */         setText(null);
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\ItemSearchDialogue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */