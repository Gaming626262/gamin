/*     */ package com.osmb.api.javafx;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import java.nio.IntBuffer;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.canvas.Canvas;
/*     */ import javafx.scene.canvas.GraphicsContext;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.image.Image;
/*     */ import javafx.scene.image.ImageView;
/*     */ import javafx.scene.image.PixelFormat;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.AnchorPane;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.scene.paint.Paint;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ public class ColorPickerPanel {
/*  26 */   private static final PixelFormat<IntBuffer> INT_ARGB_PRE_INSTANCE = (PixelFormat<IntBuffer>)PixelFormat.getIntArgbPreInstance();
/*     */   private static final int ZOOM_RECT_WIDTH = 150;
/*     */   private static final int ZOOM_RECT_HEIGHT = 150;
/*     */   
/*     */   public static int show(ScriptCore core, Stage primaryStage) {
/*  31 */     VBox vBox = new VBox();
/*  32 */     vBox.setStyle("-fx-alignment: center; -fx-spacing: 10px");
/*     */ 
/*     */     
/*  35 */     Image screenImage = core.getScreen().getImage();
/*     */ 
/*     */     
/*  38 */     ImageView imageView = new ImageView();
/*  39 */     WritableImage writableImage = new WritableImage(screenImage.getWidth(), screenImage.getHeight());
/*  40 */     writableImage.getPixelWriter().setPixels(0, 0, screenImage.getWidth(), screenImage.getHeight(), INT_ARGB_PRE_INSTANCE, screenImage.getPixels(), 0, screenImage.getWidth());
/*  41 */     imageView.setImage((Image)writableImage);
/*     */ 
/*     */     
/*  44 */     Label colorLabel = new Label("Pick a color");
/*  45 */     colorLabel.setFont(new Font(16.0D));
/*     */ 
/*     */     
/*  48 */     Canvas magnifier = new Canvas(150.0D, 150.0D);
/*     */ 
/*     */     
/*  51 */     imageView.setOnMouseMoved(event -> {
/*     */           int x = (int)event.getX();
/*     */           
/*     */           int y = (int)event.getY();
/*     */           
/*     */           handleMagnifiedCanvas(core, magnifier, colorLabel, x, y);
/*     */         });
/*  58 */     int[] pickedColor = { 0 };
/*  59 */     imageView.setOnMouseClicked(event -> {
/*     */           int x = (int)event.getX();
/*     */           
/*     */           int y = (int)event.getY();
/*     */           
/*     */           Image screenImage_ = core.getScreen().getImage();
/*     */           if (x >= 0 && x < screenImage_.getWidth() && y >= 0 && y < screenImage_.getHeight()) {
/*     */             pickedColor[0] = screenImage_.getPixels()[y * screenImage_.getWidth() + x];
/*     */             ((Stage)imageView.getScene().getWindow()).close();
/*     */           } 
/*     */         });
/*  70 */     Button refreshScreenButton = new Button("Refresh screen");
/*  71 */     refreshScreenButton.setOnAction(actionEvent -> {
/*     */           core.submitTask((), 0, false, true, true);
/*     */           Image screenImage_ = core.getScreen().getImage();
/*     */           WritableImage writableImage_ = new WritableImage(screenImage_.getWidth(), screenImage_.getHeight());
/*     */           writableImage_.getPixelWriter().setPixels(0, 0, screenImage_.getWidth(), screenImage_.getHeight(), INT_ARGB_PRE_INSTANCE, screenImage_.getPixels(), 0, screenImage_.getWidth());
/*     */           imageView.setImage((Image)writableImage_);
/*     */         });
/*  78 */     HBox bottomRow = new HBox(new Node[] { (Node)refreshScreenButton, (Node)colorLabel });
/*  79 */     bottomRow.setStyle("-fx-alignment: center; -fx-spacing: 10px; -fx-padding: 10");
/*  80 */     AnchorPane stackPane = new AnchorPane(new Node[] { (Node)imageView, (Node)magnifier });
/*  81 */     vBox.getChildren().addAll((Object[])new Node[] { (Node)stackPane, (Node)bottomRow });
/*  82 */     Scene scene = new Scene((Parent)vBox);
/*  83 */     Stage stage = new Stage();
/*  84 */     stage.setScene(scene);
/*  85 */     stage.initOwner((Window)primaryStage);
/*  86 */     stage.showAndWait();
/*  87 */     return pickedColor[0];
/*     */   }
/*     */ 
/*     */   
/*     */   private static void handleMagnifiedCanvas(ScriptCore core, Canvas magnifierCanvas, Label colorLabel, int x, int y) {
/*     */     try {
/*  93 */       double padding = 5.0D;
/*  94 */       Rectangle screenBounds = core.getScreen().getImage().getBounds();
/*     */       
/*  96 */       if (x > screenBounds.getWidth() / 2) {
/*     */         
/*  98 */         double layoutX = x - magnifierCanvas.getWidth() - padding;
/*  99 */         magnifierCanvas.setLayoutX(layoutX);
/*     */       } else {
/*     */         
/* 102 */         double layoutX = x + padding;
/* 103 */         magnifierCanvas.setLayoutX(layoutX);
/*     */       } 
/*     */       
/* 106 */       if (y > screenBounds.getHeight() / 2) {
/*     */         
/* 108 */         magnifierCanvas.setLayoutY(y - magnifierCanvas.getHeight() - padding);
/*     */       } else {
/*     */         
/* 111 */         magnifierCanvas.setLayoutY(y + padding);
/*     */       } 
/*     */       
/* 114 */       GraphicsContext gc = magnifierCanvas.getGraphicsContext2D();
/* 115 */       gc.clearRect(0.0D, 0.0D, magnifierCanvas.getWidth(), magnifierCanvas.getHeight());
/*     */       
/* 117 */       Image screenImage = core.getScreen().getImage();
/* 118 */       int zoomFactor = 8;
/*     */       
/* 120 */       for (int zoomX = 0; zoomX < 150; zoomX++) {
/* 121 */         for (int zoomY = 0; zoomY < 150; zoomY++) {
/* 122 */           int originalPixelX = x - 150 / zoomFactor + zoomX + 75 / zoomFactor;
/* 123 */           int originalPixelY = y - 150 / zoomFactor + zoomY + 75 / zoomFactor;
/*     */ 
/*     */           
/* 126 */           int magnifiedX = zoomX * zoomFactor;
/* 127 */           int magnifiedY = zoomY * zoomFactor;
/* 128 */           if (magnifiedX >= 0 && magnifiedY >= 0 && (magnifiedX + zoomFactor) < magnifierCanvas.getWidth() && (magnifiedY + zoomFactor) < magnifierCanvas.getHeight())
/*     */           {
/*     */ 
/*     */             
/* 132 */             if (originalPixelX < 0 || originalPixelX >= screenBounds.getWidth() || originalPixelY < 0 || originalPixelY >= screenBounds.getHeight()) {
/* 133 */               Color color = Color.BLACK;
/* 134 */               gc.setFill((Paint)color);
/* 135 */               gc.fillRect(magnifiedX, magnifiedY, zoomFactor, zoomFactor);
/*     */             }
/*     */             else {
/*     */               
/* 139 */               Color color = argbToColor(screenImage.getRGB(originalPixelX, originalPixelY));
/*     */               
/* 141 */               gc.setFill((Paint)color);
/* 142 */               gc.fillRect((zoomX * zoomFactor), (zoomY * zoomFactor), zoomFactor, zoomFactor);
/*     */             }  } 
/*     */         } 
/* 145 */       }  int rgb = screenImage.getRGB(x, y);
/* 146 */       double[] hsl = HSLPalette.rgbToHsl(rgb);
/* 147 */       int r = rgb >> 16 & 0xFF;
/* 148 */       int g = rgb >> 8 & 0xFF;
/* 149 */       int b = rgb & 0xFF;
/*     */       
/* 151 */       colorLabel.setText("R: " + r + " G: " + g + " B: " + b + "    H: " + hsl[0] + " S: " + hsl[1] + " L: " + hsl[2]);
/* 152 */       gc.setStroke((Paint)Color.RED);
/* 153 */       gc.strokeText("X: " + x + " Y: " + y, 5.0D, 15.0D);
/* 154 */       int y_ = 140;
/* 155 */       gc.strokeText("H: " + hsl[0] + " S: " + hsl[1] + " L: " + hsl[2], 5.0D, y_);
/* 156 */       y_ -= 20;
/* 157 */       gc.strokeText("R: " + r + " G: " + g + " B: " + b, 5.0D, y_);
/*     */       
/* 159 */       double centerX = magnifierCanvas.getWidth() / 2.0D;
/* 160 */       double centerY = magnifierCanvas.getHeight() / 2.0D;
/*     */       
/* 162 */       gc.setStroke((Paint)Color.RED);
/* 163 */       int half = zoomFactor / 2;
/* 164 */       gc.strokeRect(centerX - half, centerY - half, zoomFactor, zoomFactor);
/* 165 */       if (!magnifierCanvas.isVisible()) {
/* 166 */         magnifierCanvas.setVisible(true);
/*     */       }
/* 168 */     } catch (Exception e) {
/* 169 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Color argbToColor(int argb) {
/* 174 */     int red = argb >> 16 & 0xFF;
/* 175 */     int green = argb >> 8 & 0xFF;
/* 176 */     int blue = argb & 0xFF;
/*     */     
/* 178 */     return new Color(red / 255.0D, green / 255.0D, blue / 255.0D, 1.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\javafx\ColorPickerPanel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */