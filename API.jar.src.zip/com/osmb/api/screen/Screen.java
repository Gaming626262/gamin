package com.osmb.api.screen;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.visual.drawing.Canvas;
import com.osmb.api.visual.image.Image;
import java.util.UUID;

public interface Screen {
  UUID getUUID();
  
  void queueCanvasDrawable(String paramString, CanvasDrawable paramCanvasDrawable);
  
  Canvas getDrawableCanvas();
  
  void removeCanvasDrawable(String paramString);
  
  Rectangle getBounds();
  
  Image getImage();
  
  Image getPreviousImage();
  
  void setSceneUpdating(boolean paramBoolean);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\screen\Screen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */