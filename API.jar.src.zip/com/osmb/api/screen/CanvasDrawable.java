package com.osmb.api.screen;

import com.osmb.api.visual.drawing.Canvas;

public interface CanvasDrawable {
  void draw(Canvas paramCanvas);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\screen\CanvasDrawable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */