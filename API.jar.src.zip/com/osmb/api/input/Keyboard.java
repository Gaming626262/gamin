package com.osmb.api.input;

public interface Keyboard {
  void type(String paramString);
  
  void pressKey(TouchType paramTouchType, PhysicalKey paramPhysicalKey);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\Keyboard.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */