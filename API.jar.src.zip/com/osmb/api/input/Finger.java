package com.osmb.api.input;

import com.osmb.api.item.ItemSearchResult;
import com.osmb.api.shape.Shape;
import java.awt.Point;

public interface Finger {
  int getLastTapX();
  
  int getLastTapY();
  
  boolean tap(int paramInt1, int paramInt2);
  
  boolean tap(int paramInt1, int paramInt2, String... paramVarArgs);
  
  boolean tap(boolean paramBoolean, int paramInt1, int paramInt2);
  
  boolean tap(Point paramPoint);
  
  boolean tap(boolean paramBoolean, int paramInt1, int paramInt2, String... paramVarArgs);
  
  boolean tap(boolean paramBoolean, int paramInt1, int paramInt2, String paramString, String... paramVarArgs);
  
  boolean tap(Point paramPoint, String... paramVarArgs);
  
  boolean tap(ItemSearchResult paramItemSearchResult);
  
  boolean tap(boolean paramBoolean, ItemSearchResult paramItemSearchResult);
  
  boolean tap(boolean paramBoolean, ItemSearchResult paramItemSearchResult, String... paramVarArgs);
  
  boolean tap(ItemSearchResult paramItemSearchResult, String... paramVarArgs);
  
  boolean tap(Shape paramShape);
  
  boolean tap(Shape paramShape, String... paramVarArgs);
  
  boolean tap(int paramInt1, int paramInt2, String paramString, String... paramVarArgs);
  
  boolean tapGameScreen(Shape paramShape, String... paramVarArgs);
  
  boolean tapGameScreen(String paramString, Shape paramShape, String... paramVarArgs);
  
  boolean tapGameScreen(int paramInt1, int paramInt2, String paramString, String... paramVarArgs);
  
  String tapReturnOption(int paramInt1, int paramInt2, String paramString, String... paramVarArgs);
  
  String tapReturnOption(int paramInt1, int paramInt2, MenuHandle paramMenuHandle, String... paramVarArgs);
  
  String tapReturnOption(Shape paramShape, MenuHandle paramMenuHandle, String... paramVarArgs);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\Finger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */