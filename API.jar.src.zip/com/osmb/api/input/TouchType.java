/*    */ package com.osmb.api.input;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TouchType
/*    */ {
/* 19 */   DOWN("down"),
/* 20 */   UP("up"),
/* 21 */   DOWN_AND_UP("tap");
/*    */   
/*    */   private String monkeyIdentifier;
/*    */ 
/*    */   
/*    */   TouchType(String monkeyIdentifier) {
/* 27 */     this.monkeyIdentifier = monkeyIdentifier;
/*    */   }
/*    */   
/*    */   public String getMonkeyIdentifier() {
/* 31 */     return this.monkeyIdentifier;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\TouchType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */