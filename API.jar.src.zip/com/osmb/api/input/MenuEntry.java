/*    */ package com.osmb.api.input;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ 
/*    */ 
/*    */ public class MenuEntry
/*    */ {
/*    */   private final String action;
/*    */   private final String entityName;
/*    */   
/*    */   public MenuEntry(String rawText, String action, String entityName, EntityType entityType, Rectangle entryBounds) {
/* 12 */     this.rawText = rawText;
/* 13 */     this.action = action;
/* 14 */     this.entityName = entityName;
/* 15 */     this.entityType = entityType;
/* 16 */     this.entryBounds = entryBounds;
/*    */   }
/*    */   private final String rawText; private final EntityType entityType; private final Rectangle entryBounds;
/*    */   public String getRawText() {
/* 20 */     return this.rawText;
/*    */   }
/*    */   
/*    */   public Rectangle getEntryBounds() {
/* 24 */     return this.entryBounds;
/*    */   }
/*    */   
/*    */   public EntityType getEntityType() {
/* 28 */     return this.entityType;
/*    */   }
/*    */   
/*    */   public String getAction() {
/* 32 */     return this.action;
/*    */   }
/*    */   
/*    */   public String getEntityName() {
/* 36 */     return this.entityName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 42 */     return "MenuEntry{action='" + this.action + "', entityName='" + this.entityName + "', rawText='" + this.rawText + "', entityType=" + this.entityType + ", entryBounds=" + this.entryBounds + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\MenuEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */