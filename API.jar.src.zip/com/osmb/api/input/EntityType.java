/*   */ package com.osmb.api.input;
/*   */ 
/*   */ public enum EntityType {
/* 4 */   NPC, OBJECT, PLAYER, ITEM;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\EntityType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */