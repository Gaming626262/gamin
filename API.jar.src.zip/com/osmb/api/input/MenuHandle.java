package com.osmb.api.input;

import java.util.Set;

public interface MenuHandle {
  String handle(Set<String> paramSet);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\MenuHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */