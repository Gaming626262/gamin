/*    */ package com.osmb.api.input;
/*    */ 
/*    */ public enum PhysicalKey {
/*  4 */   HOME("KEYCODE_HOME", null),
/*  5 */   MENU("KEYCODE_MENU", null),
/*  6 */   BACK("KEYCODE_BACK", null),
/*  7 */   DPAD_UP("DPAD_UP", Integer.valueOf(38)),
/*  8 */   DPAD_DOWN("DPAD_DOWN", Integer.valueOf(40)),
/*  9 */   DPAD_LEFT("DPAD_LEFT", Integer.valueOf(37)),
/* 10 */   DPAD_RIGHT("DPAD_RIGHT", Integer.valueOf(39)),
/* 11 */   DPAD_CENTER("DPAD_CENTER", null),
/* 12 */   ENTER("KEYCODE_ENTER", Integer.valueOf(13)),
/* 13 */   TAB("KEYCODE_TAB", Integer.valueOf(9)),
/* 14 */   BACKSPACE("KEYCODE_DEL", Integer.valueOf(8)),
/* 15 */   SPACE("KEYCODE_SPACE", Integer.valueOf(32));
/*    */   
/*    */   private String keyName;
/*    */   private Integer windowsKeyCode;
/*    */   
/*    */   PhysicalKey(String androidKeyCode, Integer windowsKeyCode) {
/* 21 */     this.keyName = androidKeyCode;
/* 22 */     this.windowsKeyCode = windowsKeyCode;
/*    */   }
/*    */   
/*    */   public String getAndroidKeyCode() {
/* 26 */     return this.keyName;
/*    */   }
/*    */   
/*    */   public Integer getWindowsKeyCode() {
/* 30 */     return this.windowsKeyCode;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\input\PhysicalKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */