/*    */ package com.osmb.api.scene;
/*    */ 
/*    */ public enum ObjectType {
/*  4 */   CENTREPIECE(10),
/*  5 */   WALL(0),
/*  6 */   WALLDECOR(4),
/*  7 */   GROUND_DECOR(22),
/*  8 */   WALL_CORNER_DIAGONAL(1),
/*  9 */   WALL_L(2),
/* 10 */   WALL_SQUARE_CORNER(3),
/* 11 */   WALLDECOR_STRAIGHT_OFFSET(5),
/* 12 */   WALLDECOR_DIAGONAL_NOOFFSET(6),
/* 13 */   WALLDECOR_DIAGONAL_OFFSET(7),
/* 14 */   WALLDECOR_DIAGONAL_BOTH(8),
/* 15 */   WALL_DIAGONAL(9),
/* 16 */   CENTREPIECE_DIAGONAL(11),
/* 17 */   ROOF_STRAIGHT(12),
/* 18 */   ROOF_DIAGONAL(13),
/* 19 */   ROOF_DIAGONAL_WITH_ROOFEDGE(14),
/* 20 */   ROOF_L_CONCAVE(15),
/* 21 */   ROOF_L_CONVEX(16),
/* 22 */   ROOF_FLAT(17),
/* 23 */   ROOFEDGE_STRAIGHT(18),
/* 24 */   ROOFEDGE_DIAGONALCORNER(19),
/* 25 */   ROOFEDGE_L(20),
/* 26 */   ROOFEDGE_SQUARECORNER(21);
/*    */   private final int id;
/*    */   
/*    */   ObjectType(int id) {
/* 30 */     this.id = id;
/*    */   }
/*    */   
/*    */   public static ObjectType forId(int id) {
/* 34 */     for (ObjectType type : values()) {
/* 35 */       if (type.getId() == id) {
/* 36 */         return type;
/*    */       }
/*    */     } 
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 43 */     return this.id;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\ObjectType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */