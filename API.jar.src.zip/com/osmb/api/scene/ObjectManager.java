package com.osmb.api.scene;

import com.osmb.api.location.position.types.WorldPosition;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public interface ObjectManager {
  Optional<RSObject> getObject(Predicate<RSObject> paramPredicate);
  
  List<RSObject> getObjects(Predicate<RSObject> paramPredicate);
  
  RSObject getClosestObject(String... paramVarArgs);
  
  void removeObject(String paramString, WorldPosition paramWorldPosition);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\ObjectManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */