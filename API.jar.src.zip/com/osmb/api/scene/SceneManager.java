package com.osmb.api.scene;

import com.osmb.api.location.position.Position;
import java.util.List;
import java.util.UUID;

public interface SceneManager {
  public static final int SCENE_TILE_SIZE = 128;
  
  UUID getUUID();
  
  RSTile[][][] getTiles();
  
  CollisionMap[] getLevelCollisionMap();
  
  CollisionMap getLevelCollisionMap(int paramInt);
  
  byte[][][] getLevelTileFlags();
  
  int[][][] getLevelHeightmap();
  
  int getSceneBaseTileX();
  
  int getSceneBaseTileY();
  
  int getSceneEndTileX();
  
  int getSceneEndTileY();
  
  int getSceneCenterZoneX();
  
  int getSceneCenterZoneY();
  
  List<SceneObjectDefinition> getObjectsToAdd();
  
  List<Object> getObjectsToRemove();
  
  void refresh();
  
  int getTileCollisionFlag(Position paramPosition);
  
  int getTileSettingFlag(Position paramPosition);
  
  RSTile getTile(Position paramPosition);
  
  boolean inScene(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\SceneManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */