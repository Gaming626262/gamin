/*    */ package com.osmb.api.scene;
/*    */ 
/*    */ 
/*    */ public class SceneObjectDefinition
/*    */ {
/*    */   private final int level;
/*    */   private final int id;
/*    */   private final ObjectType type;
/*    */   private final int x;
/*    */   private final int y;
/*    */   private int rotation;
/*    */   
/*    */   public SceneObjectDefinition(int id, int x, int y, int level, int rotation, ObjectType type) {
/* 14 */     this.level = level;
/* 15 */     this.id = id;
/* 16 */     this.type = type;
/* 17 */     this.rotation = rotation;
/* 18 */     this.x = x;
/* 19 */     this.y = y;
/*    */   }
/*    */   public SceneObjectDefinition(int id, int x, int y, int level, int rotation, int type) {
/* 22 */     ObjectType type1 = null;
/* 23 */     for (ObjectType t : ObjectType.values()) {
/* 24 */       if (t.getId() == type) {
/* 25 */         type1 = t;
/*    */         break;
/*    */       } 
/*    */     } 
/* 29 */     if (type1 == null) {
/* 30 */       System.out.println("Null for type id: " + id + " x: " + x + " y: " + y + " level: " + level + " rotation: " + rotation + " type: " + type);
/* 31 */       throw new IllegalArgumentException("Invalid object type: " + type);
/*    */     } 
/* 33 */     this.type = type1;
/* 34 */     this.level = level;
/* 35 */     this.id = id;
/* 36 */     this.rotation = rotation;
/* 37 */     this.x = x;
/* 38 */     this.y = y;
/*    */   }
/*    */   public int getPlane() {
/* 41 */     return this.level;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 45 */     return this.id;
/*    */   }
/*    */   
/*    */   public ObjectType getType() {
/* 49 */     return this.type;
/*    */   }
/*    */   
/*    */   public int getRotation() {
/* 53 */     return this.rotation;
/*    */   }
/*    */   
/*    */   public void setRotation(int rotation) {
/* 57 */     this.rotation = rotation;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 61 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 65 */     return this.y;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     return "RSObject{id=" + this.id + ", x=" + this.x + ", y=" + this.y + ", level=" + this.level + ", rotation=" + this.rotation + ", type=" + this.type + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\SceneObjectDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */