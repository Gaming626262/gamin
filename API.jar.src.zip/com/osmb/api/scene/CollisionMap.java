/*     */ package com.osmb.api.scene;
/*     */ 
/*     */ 
/*     */ public final class CollisionMap
/*     */ {
/*     */   public static final int FLAG_BLOCK_ENTITY_NW = 1;
/*     */   public static final int FLAG_BLOCK_ENTITY_N = 2;
/*     */   public static final int FLAG_BLOCK_ENTITY_NE = 4;
/*     */   public static final int FLAG_BLOCK_ENTITY_E = 8;
/*     */   public static final int FLAG_BLOCK_ENTITY_SE = 16;
/*     */   public static final int FLAG_BLOCK_ENTITY_S = 32;
/*     */   public static final int FLAG_BLOCK_ENTITY_SW = 64;
/*     */   public static final int FLAG_BLOCK_ENTITY_W = 128;
/*     */   public static final int FLAG_BLOCK_ENTITY = 256;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_NW = 512;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_N = 1024;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_NE = 2048;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_E = 4096;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_SE = 8192;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_S = 16384;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_SW = 32768;
/*     */   public static final int FLAG_BLOCK_PROJECTILE_W = 65536;
/*     */   public static final int FLAG_BLOCK_PROJECTILE = 131072;
/*     */   public static final int FLAG_UNINITIALIZED = 16777216;
/*     */   public static final int FLAG_CLOSED = 16777215;
/*     */   public static final int WEST_INTERACTION_MASK = 8;
/*     */   public static final int SOUTH_INTERACTION_MASK = 4;
/*     */   public static final int EAST_INTERACTION_MASK = 2;
/*     */   public static final int NORTH_INTERACTION_MASK = 1;
/*     */   public final int[][] flags;
/*     */   private final int width;
/*     */   private final int height;
/*     */   
/*     */   public CollisionMap(int width, int height) {
/*  35 */     this.width = width;
/*  36 */     this.height = height;
/*  37 */     this.flags = new int[width][height];
/*  38 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ 
/*     */   
/*     */   public void reset() {
/*  46 */     for (int x = 0; x < this.width; x++) {
/*  47 */       for (int z = 0; z < this.height; z++) {
/*  48 */         if (x == 0 || z == 0 || x == this.width - 1 || z == this.height - 1) { this.flags[x][z] = 16777215; }
/*  49 */         else { this.flags[x][z] = 16777216; }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addWall(int x, int y, int type, int rotation, boolean projectiles) {
/*  56 */     if (type == 0) {
/*  57 */       if (rotation == 0) {
/*  58 */         add(x, y, 128);
/*  59 */         add(x - 1, y, 8);
/*  60 */       } else if (rotation == 1) {
/*  61 */         add(x, y, 2);
/*  62 */         add(x, y + 1, 32);
/*  63 */       } else if (rotation == 2) {
/*  64 */         add(x, y, 8);
/*  65 */         add(x + 1, y, 128);
/*  66 */       } else if (rotation == 3) {
/*  67 */         add(x, y, 32);
/*  68 */         add(x, y - 1, 2);
/*     */       } 
/*  70 */     } else if (type == 1 || type == 3) {
/*  71 */       if (rotation == 0) {
/*  72 */         add(x, y, 1);
/*  73 */         add(x - 1, y + 1, 16);
/*  74 */       } else if (rotation == 1) {
/*  75 */         add(x, y, 4);
/*  76 */         add(x + 1, y + 1, 64);
/*  77 */       } else if (rotation == 2) {
/*  78 */         add(x, y, 16);
/*  79 */         add(x + 1, y - 1, 1);
/*  80 */       } else if (rotation == 3) {
/*  81 */         add(x, y, 64);
/*  82 */         add(x - 1, y - 1, 4);
/*     */       } 
/*  84 */     } else if (type == 2) {
/*  85 */       if (rotation == 0) {
/*  86 */         add(x, y, 130);
/*  87 */         add(x - 1, y, 8);
/*  88 */         add(x, y + 1, 32);
/*  89 */       } else if (rotation == 1) {
/*  90 */         add(x, y, 10);
/*  91 */         add(x, y + 1, 32);
/*  92 */         add(x + 1, y, 128);
/*  93 */       } else if (rotation == 2) {
/*  94 */         add(x, y, 40);
/*  95 */         add(x + 1, y, 128);
/*  96 */         add(x, y - 1, 2);
/*  97 */       } else if (rotation == 3) {
/*  98 */         add(x, y, 160);
/*  99 */         add(x, y - 1, 2);
/* 100 */         add(x - 1, y, 8);
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     if (projectiles) {
/* 105 */       if (type == 0) {
/* 106 */         if (rotation == 0) {
/* 107 */           add(x, y, 65536);
/* 108 */           add(x - 1, y, 4096);
/* 109 */         } else if (rotation == 1) {
/* 110 */           add(x, y, 1024);
/* 111 */           add(x, y + 1, 16384);
/* 112 */         } else if (rotation == 2) {
/* 113 */           add(x, y, 4096);
/* 114 */           add(x + 1, y, 65536);
/* 115 */         } else if (rotation == 3) {
/* 116 */           add(x, y, 16384);
/* 117 */           add(x, y - 1, 1024);
/*     */         } 
/* 119 */       } else if (type == 1 || type == 3) {
/* 120 */         if (rotation == 0) {
/* 121 */           add(x, y, 512);
/* 122 */           add(x - 1, y + 1, 8192);
/* 123 */         } else if (rotation == 1) {
/* 124 */           add(x, y, 2048);
/* 125 */           add(x + 1, y + 1, 32768);
/* 126 */         } else if (rotation == 2) {
/* 127 */           add(x, y, 8192);
/* 128 */           add(x + 1, y - 1, 512);
/* 129 */         } else if (rotation == 3) {
/* 130 */           add(x, y, 32768);
/* 131 */           add(x - 1, y - 1, 2048);
/*     */         } 
/* 133 */       } else if (type == 2) {
/* 134 */         if (rotation == 0) {
/* 135 */           add(x, y, 66560);
/* 136 */           add(x - 1, y, 4096);
/* 137 */           add(x, y + 1, 16384);
/* 138 */         } else if (rotation == 1) {
/* 139 */           add(x, y, 5120);
/* 140 */           add(x, y + 1, 16384);
/* 141 */           add(x + 1, y, 65536);
/* 142 */         } else if (rotation == 2) {
/* 143 */           add(x, y, 20480);
/* 144 */           add(x + 1, y, 65536);
/* 145 */           add(x, y - 1, 1024);
/* 146 */         } else if (rotation == 3) {
/* 147 */           add(x, y, 81920);
/* 148 */           add(x, y - 1, 1024);
/* 149 */           add(x - 1, y, 4096);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void add(boolean blocksProjectiles, int sizeX, int sizeZ, int x, int y, int rotation) {
/* 156 */     int flags = 256;
/*     */     
/* 158 */     if (blocksProjectiles) {
/* 159 */       flags += 131072;
/*     */     }
/*     */     
/* 162 */     if (rotation == 1 || rotation == 3) {
/* 163 */       int tmp = sizeX;
/* 164 */       sizeX = sizeZ;
/* 165 */       sizeZ = tmp;
/*     */     } 
/*     */     
/* 168 */     for (int tx = x; tx < x + sizeX; tx++) {
/* 169 */       if (tx >= 0 && tx < this.width) {
/* 170 */         for (int tz = y; tz < y + sizeZ; tz++) {
/* 171 */           if (tz >= 0 && tz < this.height) {
/* 172 */             add(tx, tz, flags);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addSolid(int x, int y) {
/* 180 */     this.flags[x][y] = this.flags[x][y] | 0x1000000;
/*     */   }
/*     */   
/*     */   public void add(int x, int y, int flags) {
/* 184 */     this.flags[x][y] = this.flags[x][y] | flags;
/*     */   }
/*     */   
/*     */   public void remove(int x, int y, int rotation, int type, boolean projectiles) {
/* 188 */     if (type == 0) {
/* 189 */       if (rotation == 0) {
/* 190 */         remove(x, y, 128);
/* 191 */         remove(x - 1, y, 8);
/* 192 */       } else if (rotation == 1) {
/* 193 */         remove(x, y, 2);
/* 194 */         remove(x, y + 1, 32);
/* 195 */       } else if (rotation == 2) {
/* 196 */         remove(x, y, 8);
/* 197 */         remove(x + 1, y, 128);
/* 198 */       } else if (rotation == 3) {
/* 199 */         remove(x, y, 32);
/* 200 */         remove(x, y - 1, 2);
/*     */       } 
/* 202 */     } else if (type == 1 || type == 3) {
/* 203 */       if (rotation == 0) {
/* 204 */         remove(x, y, 1);
/* 205 */         remove(x - 1, y + 1, 16);
/* 206 */       } else if (rotation == 1) {
/* 207 */         remove(x, y, 4);
/* 208 */         remove(x + 1, y + 1, 64);
/* 209 */       } else if (rotation == 2) {
/* 210 */         remove(x, y, 16);
/* 211 */         remove(x + 1, y - 1, 1);
/* 212 */       } else if (rotation == 3) {
/* 213 */         remove(x, y, 64);
/* 214 */         remove(x - 1, y - 1, 4);
/*     */       } 
/* 216 */     } else if (type == 2) {
/* 217 */       if (rotation == 0) {
/* 218 */         remove(x, y, 130);
/* 219 */         remove(x - 1, y, 8);
/* 220 */         remove(x, y + 1, 32);
/* 221 */       } else if (rotation == 1) {
/* 222 */         remove(x, y, 10);
/* 223 */         remove(x, y + 1, 32);
/* 224 */         remove(x + 1, y, 128);
/* 225 */       } else if (rotation == 2) {
/* 226 */         remove(x, y, 40);
/* 227 */         remove(x + 1, y, 128);
/* 228 */         remove(x, y - 1, 2);
/* 229 */       } else if (rotation == 3) {
/* 230 */         remove(x, y, 160);
/* 231 */         remove(x, y - 1, 2);
/* 232 */         remove(x - 1, y, 8);
/*     */       } 
/*     */     } 
/* 235 */     if (projectiles) {
/* 236 */       if (type == 0) {
/* 237 */         if (rotation == 0) {
/* 238 */           remove(x, y, 65536);
/* 239 */           remove(x - 1, y, 4096);
/* 240 */         } else if (rotation == 1) {
/* 241 */           remove(x, y, 1024);
/* 242 */           remove(x, y + 1, 16384);
/* 243 */         } else if (rotation == 2) {
/* 244 */           remove(x, y, 4096);
/* 245 */           remove(x + 1, y, 65536);
/* 246 */         } else if (rotation == 3) {
/* 247 */           remove(x, y, 16384);
/* 248 */           remove(x, y - 1, 1024);
/*     */         } 
/* 250 */       } else if (type == 1 || type == 3) {
/* 251 */         if (rotation == 0) {
/* 252 */           remove(x, y, 512);
/* 253 */           remove(x - 1, y + 1, 8192);
/* 254 */         } else if (rotation == 1) {
/* 255 */           remove(x, y, 2048);
/* 256 */           remove(x + 1, y + 1, 32768);
/* 257 */         } else if (rotation == 2) {
/* 258 */           remove(x, y, 8192);
/* 259 */           remove(x + 1, y - 1, 512);
/* 260 */         } else if (rotation == 3) {
/* 261 */           remove(x, y, 32768);
/* 262 */           remove(x - 1, y - 1, 2048);
/*     */         } 
/* 264 */       } else if (type == 2) {
/* 265 */         if (rotation == 0) {
/* 266 */           remove(x, y, 66560);
/* 267 */           remove(x - 1, y, 4096);
/* 268 */           remove(x, y + 1, 16384);
/* 269 */         } else if (rotation == 1) {
/* 270 */           remove(x, y, 5120);
/* 271 */           remove(x, y + 1, 16384);
/* 272 */           remove(x + 1, y, 65536);
/* 273 */         } else if (rotation == 2) {
/* 274 */           remove(x, y, 20480);
/* 275 */           remove(x + 1, y, 65536);
/* 276 */           remove(x, y - 1, 1024);
/* 277 */         } else if (rotation == 3) {
/* 278 */           remove(x, y, 81920);
/* 279 */           remove(x, y - 1, 1024);
/* 280 */           remove(x - 1, y, 4096);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(int x, int y, int width, int height, int rotation, boolean projectiles) {
/* 287 */     int flags = 256;
/*     */     
/* 289 */     if (projectiles) {
/* 290 */       flags += 131072;
/*     */     }
/*     */     
/* 293 */     if (rotation == 1 || rotation == 3) {
/* 294 */       int tmp = width;
/* 295 */       width = height;
/* 296 */       height = tmp;
/*     */     } 
/* 298 */     for (int tx = x; tx < x + width; tx++) {
/* 299 */       if (tx >= 0 && tx < this.width) {
/* 300 */         for (int ty = y; ty < y + height; ty++) {
/* 301 */           if (ty >= 0 && ty < this.height) {
/* 302 */             remove(tx, ty, flags);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void remove(int x, int y, int flags) {
/* 310 */     this.flags[x][y] = this.flags[x][y] & 16777215 - flags;
/*     */   }
/*     */   
/*     */   public void removeSolid(int x, int y) {
/* 314 */     this.flags[x][y] = this.flags[x][y] & 0xDFFFFF;
/*     */   }
/*     */   
/*     */   public boolean reachedDestination(int sx, int sz, int dx, int dz, int rotation, int type) {
/* 318 */     if (sx == dx && sz == dz) {
/* 319 */       return true;
/*     */     }
/*     */     
/* 322 */     if (type == 0) {
/* 323 */       if (rotation == 0) {
/* 324 */         if (sx == dx - 1 && sz == dz)
/* 325 */           return true; 
/* 326 */         if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x1280120) == 0) {
/* 327 */           return true;
/*     */         }
/* 329 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x1280102) == 0);
/*     */       } 
/* 331 */       if (rotation == 1) {
/* 332 */         if (sx == dx && sz == dz + 1)
/* 333 */           return true; 
/* 334 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x1280108) == 0) {
/* 335 */           return true;
/*     */         }
/* 337 */         return (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x1280180) == 0);
/*     */       } 
/* 339 */       if (rotation == 2) {
/* 340 */         if (sx == dx + 1 && sz == dz)
/* 341 */           return true; 
/* 342 */         if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x1280120) == 0) {
/* 343 */           return true;
/*     */         }
/* 345 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x1280102) == 0);
/*     */       } 
/* 347 */       if (rotation == 3) {
/* 348 */         if (sx == dx && sz == dz - 1)
/* 349 */           return true; 
/* 350 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x1280108) == 0) {
/* 351 */           return true;
/*     */         }
/* 353 */         return (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x1280180) == 0);
/*     */       }
/*     */     
/* 356 */     } else if (type == 2) {
/* 357 */       if (rotation == 0) {
/* 358 */         if (sx == dx - 1 && sz == dz)
/* 359 */           return true; 
/* 360 */         if (sx == dx && sz == dz + 1)
/* 361 */           return true; 
/* 362 */         if (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x1280180) == 0) {
/* 363 */           return true;
/*     */         }
/* 365 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x1280102) == 0);
/*     */       } 
/* 367 */       if (rotation == 1) {
/* 368 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x1280108) == 0)
/* 369 */           return true; 
/* 370 */         if (sx == dx && sz == dz + 1)
/* 371 */           return true; 
/* 372 */         if (sx == dx + 1 && sz == dz) {
/* 373 */           return true;
/*     */         }
/* 375 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x1280102) == 0);
/*     */       } 
/* 377 */       if (rotation == 2) {
/* 378 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x1280108) == 0)
/* 379 */           return true; 
/* 380 */         if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x1280120) == 0)
/* 381 */           return true; 
/* 382 */         if (sx == dx + 1 && sz == dz) {
/* 383 */           return true;
/*     */         }
/* 385 */         return (sx == dx && sz == dz - 1);
/*     */       } 
/* 387 */       if (rotation == 3) {
/* 388 */         if (sx == dx - 1 && sz == dz)
/* 389 */           return true; 
/* 390 */         if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x1280120) == 0)
/* 391 */           return true; 
/* 392 */         if (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x1280180) == 0) {
/* 393 */           return true;
/*     */         }
/* 395 */         return (sx == dx && sz == dz - 1);
/*     */       }
/*     */     
/* 398 */     } else if (type == 9) {
/* 399 */       if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x20) == 0)
/* 400 */         return true; 
/* 401 */       if (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x2) == 0)
/* 402 */         return true; 
/* 403 */       if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x8) == 0) {
/* 404 */         return true;
/*     */       }
/* 406 */       return (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x80) == 0);
/*     */     } 
/* 408 */     return false;
/*     */   }
/*     */   
/*     */   public boolean reachedWall(int sx, int sz, int dx, int dz, int type, int rotation) {
/* 412 */     if (sx == dx && sz == dz) {
/* 413 */       return true;
/*     */     }
/* 415 */     if (type == 6 || type == 7) {
/* 416 */       if (type == 7) {
/* 417 */         rotation = rotation + 2 & 0x3;
/*     */       }
/* 419 */       if (rotation == 0) {
/* 420 */         if (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x80) == 0) {
/* 421 */           return true;
/*     */         }
/* 423 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x2) == 0);
/*     */       } 
/* 425 */       if (rotation == 1) {
/* 426 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x8) == 0) {
/* 427 */           return true;
/*     */         }
/* 429 */         return (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x2) == 0);
/*     */       } 
/* 431 */       if (rotation == 2) {
/* 432 */         if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x8) == 0) {
/* 433 */           return true;
/*     */         }
/* 435 */         return (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x20) == 0);
/*     */       } 
/* 437 */       if (rotation == 3) {
/* 438 */         if (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x80) == 0) {
/* 439 */           return true;
/*     */         }
/* 441 */         return (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x20) == 0);
/*     */       }
/*     */     
/* 444 */     } else if (type == 8) {
/* 445 */       if (sx == dx && sz == dz + 1 && (this.flags[sx][sz] & 0x20) == 0)
/* 446 */         return true; 
/* 447 */       if (sx == dx && sz == dz - 1 && (this.flags[sx][sz] & 0x2) == 0)
/* 448 */         return true; 
/* 449 */       if (sx == dx - 1 && sz == dz && (this.flags[sx][sz] & 0x8) == 0) {
/* 450 */         return true;
/*     */       }
/* 452 */       return (sx == dx + 1 && sz == dz && (this.flags[sx][sz] & 0x80) == 0);
/*     */     } 
/* 454 */     return false;
/*     */   }
/*     */   
/*     */   public boolean reachedLoc(int srcX, int srcY, int dstX, int dstY, int dstSizeX, int dstSizeZ, int interactionSides) {
/* 458 */     System.out.println("Start x: " + srcX + " y: " + srcY + " dstX: " + dstX + " dstY: " + dstY);
/* 459 */     System.out.println("Size x: " + dstSizeX + " y: " + dstSizeZ);
/* 460 */     System.out.println("Interaction Sides: " + Integer.toBinaryString(interactionSides));
/*     */     
/* 462 */     int maxX = dstX + dstSizeX - 1;
/* 463 */     int maxY = dstY + dstSizeZ - 1;
/*     */ 
/*     */     
/* 466 */     if (srcX >= dstX && srcX <= maxX && srcY >= dstY && srcY <= maxY) {
/* 467 */       return true;
/*     */     }
/*     */     
/* 470 */     if (srcX == maxX - 1 && srcY >= dstY && srcY <= maxY && (this.flags[srcX][srcY] & 0x8) == 0 && (interactionSides & 0x8) == 0) {
/* 471 */       System.out.println(getClass().getSimpleName() + ": Reached west loc side");
/* 472 */       return true;
/*     */     } 
/*     */     
/* 475 */     if (srcY == maxY - 1 && srcX >= dstX && srcX <= maxX && (this.flags[srcX][srcY] & 0x2) == 0 && (interactionSides & 0x4) == 0) {
/* 476 */       System.out.println(getClass().getSimpleName() + ": Reached south loc side");
/* 477 */       return true;
/*     */     } 
/*     */     
/* 480 */     if (srcX == dstX - 1 && srcY >= dstY && srcY <= maxY && (this.flags[srcX][srcY] & 0x80) == 0 && (interactionSides & 0x2) == 0) {
/* 481 */       System.out.println(getClass().getSimpleName() + ": Reached east loc side");
/* 482 */       return true;
/*     */     } 
/*     */     
/* 485 */     if (srcY == dstY + 1 && srcX >= dstX && srcX <= maxX && (this.flags[srcX][srcY] & 0x20) == 0 && (interactionSides & 0x1) == 0) {
/* 486 */       System.out.println(getClass().getSimpleName() + ": Reached north loc side");
/* 487 */       return true;
/*     */     } 
/*     */     
/* 490 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\CollisionMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */