package com.osmb.api.scene;

import com.osmb.api.location.Location3D;
import com.osmb.api.shape.Polygon;
import java.util.List;

public interface RSTile extends Location3D {
  int getCollisionFlag();
  
  int getHeight();
  
  boolean isOnMinimap();
  
  boolean isOnGameScreen();
  
  Polygon getTilePoly();
  
  Polygon getTileCube(int paramInt);
  
  boolean canReach();
  
  double distance();
  
  boolean interact(String paramString);
  
  List<RSObject> getObjects();
  
  RSTile getBridgeTile();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\RSTile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */