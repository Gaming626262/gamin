/*     */ package com.osmb.api.scene;
/*     */ 
/*     */ import com.osmb.api.location.Location3D;
/*     */ import com.osmb.api.visual.VisualVerifier;
/*     */ import com.osmb.api.walker.pathing.WalkDirection;
/*     */ 
/*     */ public interface RSObject
/*     */   extends Location3D, Drawable
/*     */ {
/*     */   boolean interactableFrom(WalkDirection paramWalkDirection);
/*     */   
/*     */   int getInteractionSideFlags();
/*     */   
/*     */   ObjectType getObjectType();
/*     */   
/*     */   Object getSceneEntity();
/*     */   
/*     */   String getName();
/*     */   
/*     */   int getId();
/*     */   
/*     */   int getRotation();
/*     */   
/*     */   String[] getActions();
/*     */   
/*     */   Object getModel();
/*     */   
/*     */   Object getSecondaryModel();
/*     */   
/*     */   boolean isBlocksProjectiles();
/*     */   
/*     */   boolean isInteractable();
/*     */   
/*     */   default int getMaxWorldX() {
/*  35 */     return getWorldX();
/*     */   }
/*     */   
/*     */   default int getMaxWorldY() {
/*  39 */     return getWorldY();
/*     */   }
/*     */   
/*     */   default int getMaxLocalX() {
/*  43 */     return getLocalX();
/*     */   }
/*     */   
/*     */   default int getMaxLocalY() {
/*  47 */     return getLocalY();
/*     */   }
/*     */   
/*     */   default int getYaw() {
/*  51 */     return getRotation();
/*     */   }
/*     */ 
/*     */   
/*     */   default int getSequenceId() {
/*  56 */     return -1;
/*     */   }
/*     */   
/*     */   default int getSequenceFrame() {
/*  60 */     return -1;
/*     */   }
/*     */   
/*     */   boolean interact(String... menuItemNames) {
/*  64 */     return interact((VisualVerifier)null, menuItemNames);
/*     */   }
/*     */   
/*     */   default int getTileWidth() {
/*  68 */     return 1;
/*     */   }
/*     */   
/*     */   default int getTileHeight() {
/*  72 */     return 1;
/*     */   }
/*     */   
/*     */   default boolean interact(int interactDistance, String[] menuItemNames) {
/*  76 */     return interact(interactDistance, (VisualVerifier)null, menuItemNames);
/*     */   }
/*     */   
/*     */   boolean interact(VisualVerifier visualVerifier, String... menuItemNames) {
/*  80 */     return interact(1, visualVerifier, menuItemNames);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean interact(int paramInt, VisualVerifier paramVisualVerifier, String... paramVarArgs);
/*     */ 
/*     */   
/*     */   boolean isInteractableOnScreen();
/*     */   
/*     */   boolean interact(int paramInt, String paramString, VisualVerifier paramVisualVerifier, String... paramVarArgs);
/*     */   
/*     */   RSTile getTile();
/*     */   
/*     */   int getTileDistance();
/*     */   
/*     */   int getLocalX();
/*     */   
/*     */   int getLocalY();
/*     */   
/*     */   default boolean canReach() {
/* 100 */     return canReach(1);
/*     */   }
/*     */   
/*     */   boolean canReach(int paramInt);
/*     */   
/*     */   double distance();
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\RSObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */