package com.osmb.api.scene;

import com.osmb.api.shape.Polygon;
import com.osmb.api.shape.triangle.Triangle;
import java.util.List;

public interface Drawable {
  Polygon getConvexHull();
  
  List<Triangle> getFaces();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\Drawable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */