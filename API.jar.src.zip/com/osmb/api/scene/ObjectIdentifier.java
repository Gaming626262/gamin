/*    */ package com.osmb.api.scene;
/*    */ 
/*    */ import com.osmb.api.location.position.types.WorldPosition;
/*    */ 
/*    */ public class ObjectIdentifier
/*    */ {
/*    */   private final String name;
/*    */   private final WorldPosition position;
/*    */   private final int id;
/*    */   
/*    */   public ObjectIdentifier(String name, WorldPosition position) {
/* 12 */     this.name = name;
/* 13 */     this.position = position;
/* 14 */     this.id = -1;
/*    */   }
/*    */   
/*    */   public ObjectIdentifier(int id, WorldPosition position) {
/* 18 */     this.name = null;
/* 19 */     this.position = position;
/* 20 */     this.id = id;
/*    */   }
/*    */   
/*    */   public WorldPosition getPosition() {
/* 24 */     return this.position;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 28 */     return this.name;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 32 */     return this.id;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\scene\ObjectIdentifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */