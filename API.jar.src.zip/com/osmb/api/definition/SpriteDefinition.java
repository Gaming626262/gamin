/*    */ package com.osmb.api.definition;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ public class SpriteDefinition
/*    */ {
/*    */   public int id;
/*    */   public int frame;
/*    */   public int offsetX;
/*    */   public int offsetY;
/*    */   public int width;
/*    */   public int height;
/*    */   public int[] pixels;
/*    */   public int maxWidth;
/*    */   public int maxHeight;
/*    */   public transient byte[] pixelIdx;
/*    */   public transient int[] palette;
/*    */   
/*    */   public int getMaxWidth() {
/* 23 */     return this.maxWidth;
/*    */   }
/*    */   
/*    */   public int getMaxHeight() {
/* 27 */     return this.maxHeight;
/*    */   }
/*    */   
/*    */   public void normalize() {
/* 31 */     if (this.width != this.maxWidth || this.height != this.maxHeight) {
/* 32 */       byte[] pixels = new byte[this.maxWidth * this.maxHeight];
/* 33 */       int var2 = 0;
/*    */       
/* 35 */       for (int var3 = 0; var3 < this.height; var3++) {
/* 36 */         for (int var4 = 0; var4 < this.width; var4++) {
/* 37 */           pixels[var4 + (var3 + this.offsetY) * this.maxWidth + this.offsetX] = this.pixelIdx[var2++];
/*    */         }
/*    */       } 
/*    */       
/* 41 */       this.pixelIdx = pixels;
/* 42 */       this.width = this.maxWidth;
/* 43 */       this.height = this.maxHeight;
/* 44 */       this.offsetX = 0;
/* 45 */       this.offsetY = 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public BufferedImage toBufferedImage() {
/* 50 */     if (this.width == 0 && this.height == 0) {
/* 51 */       throw new IllegalArgumentException("Width and height must not be 0.. ID:" + this.id);
/*    */     }
/* 53 */     BufferedImage bi = new BufferedImage(this.width, this.height, 2);
/* 54 */     bi.setRGB(0, 0, this.width, this.height, this.pixels, 0, this.width);
/* 55 */     return bi;
/*    */   }
/*    */   
/*    */   public void save(File file) throws IOException {
/* 59 */     BufferedImage image = toBufferedImage();
/* 60 */     ImageIO.write(image, "png", file);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 65 */     return "SpriteDefinition{id=" + this.id + ", frame=" + this.frame + ", offsetX=" + this.offsetX + ", offsetY=" + this.offsetY + ", width=" + this.width + ", height=" + this.height + ", maxWidth=" + this.maxWidth + ", maxHeight=" + this.maxHeight + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\definition\SpriteDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */