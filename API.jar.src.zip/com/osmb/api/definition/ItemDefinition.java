/*    */ package com.osmb.api.definition;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public class ItemDefinition
/*    */ {
/*    */   public final int id;
/*  9 */   public String name = "null";
/* 10 */   public String examine = "null";
/*    */   
/*    */   public String unknown1;
/* 13 */   public int resizeX = 128;
/* 14 */   public int resizeY = 128;
/* 15 */   public int resizeZ = 128;
/*    */   
/* 17 */   public int xan2d = 0;
/* 18 */   public int yan2d = 0;
/* 19 */   public int zan2d = 0;
/*    */   
/* 21 */   public int cost = 1;
/*    */   public boolean isTradeable;
/* 23 */   public int stackable = 0;
/*    */   
/*    */   public int inventoryModel;
/*    */   
/*    */   public int wearPos1;
/*    */   
/*    */   public int wearPos2;
/*    */   
/*    */   public int wearPos3;
/*    */   public boolean members = false;
/*    */   public short[] colorFind;
/*    */   public short[] colorReplace;
/*    */   public short[] textureFind;
/*    */   public short[] textureReplace;
/* 37 */   public int zoom2d = 2000;
/* 38 */   public int xOffset2d = 0;
/* 39 */   public int yOffset2d = 0;
/*    */   
/*    */   public int ambient;
/*    */   
/*    */   public int contrast;
/*    */   
/*    */   public int[] countCo;
/*    */   public int[] countObj;
/* 47 */   public String[] options = new String[] { null, null, "Take", null, null };
/*    */   
/* 49 */   public String[] interfaceOptions = new String[] { null, null, null, null, "Drop" };
/*    */   
/* 51 */   public int maleModel0 = -1;
/* 52 */   public int maleModel1 = -1;
/* 53 */   public int maleModel2 = -1;
/*    */   public int maleOffset;
/* 55 */   public int maleHeadModel = -1;
/* 56 */   public int maleHeadModel2 = -1;
/*    */   
/* 58 */   public int femaleModel0 = -1;
/* 59 */   public int femaleModel1 = -1;
/* 60 */   public int femaleModel2 = -1;
/*    */   public int femaleOffset;
/* 62 */   public int femaleHeadModel = -1;
/* 63 */   public int femaleHeadModel2 = -1;
/*    */   
/*    */   public int category;
/*    */   
/* 67 */   public int notedID = -1;
/* 68 */   public int notedTemplate = -1;
/*    */   
/*    */   public int team;
/*    */   
/*    */   public int weight;
/* 73 */   public int shiftClickDropIndex = -2;
/*    */   
/* 75 */   public int boughtId = -1;
/* 76 */   public int boughtTemplateId = -1;
/*    */   
/* 78 */   public int placeholderId = -1;
/* 79 */   public int placeholderTemplateId = -1;
/*    */   
/* 81 */   public Map<Integer, Object> params = null;
/*    */   
/*    */   public ItemDefinition(int id) {
/* 84 */     this.id = id;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\definition\ItemDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */