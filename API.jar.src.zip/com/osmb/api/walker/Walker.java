package com.osmb.api.walker;

import com.osmb.api.location.position.Position;
import com.osmb.api.location.position.types.WorldPosition;
import com.osmb.api.scene.RSObject;
import com.osmb.api.walker.pathing.CollisionManager;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public interface Walker {
  WalkSettings getSettings();
  
  boolean walkTo(Position paramPosition, BooleanSupplier paramBooleanSupplier);
  
  boolean walkTo(RSObject paramRSObject, BooleanSupplier paramBooleanSupplier);
  
  boolean walkTo(int paramInt1, int paramInt2, BooleanSupplier paramBooleanSupplier);
  
  boolean walkTo(int paramInt1, int paramInt2, BooleanSupplier paramBooleanSupplier, Supplier<Void> paramSupplier);
  
  boolean walkTo(RSObject paramRSObject);
  
  boolean walkTo(RSObject paramRSObject, BooleanSupplier paramBooleanSupplier, Supplier<Void> paramSupplier);
  
  boolean walkTo(Position paramPosition);
  
  boolean walkTo(Position paramPosition, BooleanSupplier paramBooleanSupplier, Supplier<Void> paramSupplier);
  
  boolean walkTo(int paramInt1, int paramInt2);
  
  boolean walkPath(List<WorldPosition> paramList, BooleanSupplier paramBooleanSupplier);
  
  boolean walkPath(List<WorldPosition> paramList, BooleanSupplier paramBooleanSupplier, Supplier<Void> paramSupplier);
  
  CollisionManager getCollisionManager();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\Walker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */