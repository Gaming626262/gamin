/*     */ package com.osmb.api.walker;
/*     */ 
/*     */ public class WalkSettings {
/*     */   private long timeout;
/*     */   private int breakDistance;
/*     */   private long minimapTapDelayMin;
/*     */   private long minimapTapDelayMax;
/*     */   private long screenTapDelayMin;
/*     */   private long screenTapDelayMax;
/*     */   private int tileRandomisationRadius;
/*     */   private boolean afkInterrupt;
/*     */   private boolean breakInterrupt;
/*     */   private boolean hopInterrupt;
/*     */   
/*     */   public WalkSettings(long minimapTapDelayMin, long minimapTapDelayMax, long screenTapDelayMin, long screenTapDelayMax, long timeout, int breakDistance) {
/*  16 */     this.minimapTapDelayMin = minimapTapDelayMin;
/*  17 */     this.minimapTapDelayMax = minimapTapDelayMax;
/*  18 */     this.screenTapDelayMin = screenTapDelayMin;
/*  19 */     this.screenTapDelayMax = screenTapDelayMax;
/*  20 */     this.timeout = timeout;
/*  21 */     this.breakDistance = breakDistance;
/*  22 */     this.tileRandomisationRadius = 2;
/*  23 */     this.hopInterrupt = true;
/*  24 */     this.breakInterrupt = true;
/*  25 */     this.afkInterrupt = true;
/*     */   }
/*     */   public WalkSettings(long minimapTapDelayMin, long minimapTapDelayMax, long screenTapDelayMin, long screenTapDelayMax, long timeout, int tileRandomisationRadius, int breakDistance) {
/*  28 */     this.minimapTapDelayMin = minimapTapDelayMin;
/*  29 */     this.minimapTapDelayMax = minimapTapDelayMax;
/*  30 */     this.screenTapDelayMin = screenTapDelayMin;
/*  31 */     this.screenTapDelayMax = screenTapDelayMax;
/*  32 */     this.timeout = timeout;
/*  33 */     this.tileRandomisationRadius = tileRandomisationRadius;
/*  34 */     this.breakDistance = breakDistance;
/*  35 */     this.hopInterrupt = true;
/*  36 */     this.breakInterrupt = true;
/*  37 */     this.afkInterrupt = true;
/*     */   }
/*     */   public WalkSettings(long timeout, int breakDistance) {
/*  40 */     this.breakDistance = breakDistance;
/*  41 */     this.minimapTapDelayMin = 2000L;
/*  42 */     this.minimapTapDelayMax = 6000L;
/*  43 */     this.screenTapDelayMin = 500L;
/*  44 */     this.screenTapDelayMax = 2000L;
/*  45 */     this.tileRandomisationRadius = 1;
/*  46 */     this.timeout = timeout;
/*  47 */     this.hopInterrupt = true;
/*  48 */     this.breakInterrupt = true;
/*  49 */     this.afkInterrupt = true;
/*     */   }
/*     */   
/*     */   public long getScreenTapDelayMin() {
/*  53 */     return this.screenTapDelayMin;
/*     */   }
/*     */   
/*     */   public void setScreenTapDelayMin(long screenTapDelayMin) {
/*  57 */     this.screenTapDelayMin = screenTapDelayMin;
/*     */   }
/*     */   
/*     */   public long getScreenTapDelayMax() {
/*  61 */     return this.screenTapDelayMax;
/*     */   }
/*     */   
/*     */   public void setScreenTapDelayMax(long screenTapDelayMax) {
/*  65 */     this.screenTapDelayMax = screenTapDelayMax;
/*     */   }
/*     */   
/*     */   public boolean isBreakInterrupt() {
/*  69 */     return this.breakInterrupt;
/*     */   }
/*     */   
/*     */   public void setBreakInterrupt(boolean breakInterrupt) {
/*  73 */     this.breakInterrupt = breakInterrupt;
/*     */   }
/*     */   
/*     */   public boolean isHopInterrupt() {
/*  77 */     return this.hopInterrupt;
/*     */   }
/*     */   
/*     */   public void setHopInterrupt(boolean hopInterrupt) {
/*  81 */     this.hopInterrupt = hopInterrupt;
/*     */   }
/*     */   
/*     */   public boolean isAfkInterrupt() {
/*  85 */     return this.afkInterrupt;
/*     */   }
/*     */   
/*     */   public void setAfkInterrupt(boolean afkInterrupt) {
/*  89 */     this.afkInterrupt = afkInterrupt;
/*     */   }
/*     */   
/*     */   public int getTileRandomisationRadius() {
/*  93 */     return this.tileRandomisationRadius;
/*     */   }
/*     */   
/*     */   public void setTileRandomisationRadius(int tileRandomisationRadius) {
/*  97 */     this.tileRandomisationRadius = tileRandomisationRadius;
/*     */   }
/*     */   
/*     */   public int getBreakDistance() {
/* 101 */     return this.breakDistance;
/*     */   }
/*     */   
/*     */   public void setBreakDistance(int breakDistance) {
/* 105 */     this.breakDistance = breakDistance;
/*     */   }
/*     */   
/*     */   public long getMinimapTapDelayMin() {
/* 109 */     return this.minimapTapDelayMin;
/*     */   }
/*     */   
/*     */   public void setMinimapTapDelayMin(long minimapTapDelayMin) {
/* 113 */     this.minimapTapDelayMin = minimapTapDelayMin;
/*     */   }
/*     */   
/*     */   public long getMinimapTapDelayMax() {
/* 117 */     return this.minimapTapDelayMax;
/*     */   }
/*     */   
/*     */   public void setMinimapTapDelayMax(long minimapTapDelayMax) {
/* 121 */     this.minimapTapDelayMax = minimapTapDelayMax;
/*     */   }
/*     */   
/*     */   public long getTimeout() {
/* 125 */     return this.timeout;
/*     */   }
/*     */   
/*     */   public void setTimeout(long timeout) {
/* 129 */     this.timeout = timeout;
/*     */   }
/*     */   
/*     */   public void setTapDelay(long min, long max) {
/* 133 */     this.minimapTapDelayMax = max;
/* 134 */     this.minimapTapDelayMin = min;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\WalkSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */