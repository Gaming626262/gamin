/*     */ package com.osmb.api.walker.pathing;
/*     */ import com.osmb.api.location.position.Position;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.scene.SceneManager;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CollisionManager {
/*     */   public CollisionManager(SceneManager sceneManager) {
/*  14 */     this.sceneManager = sceneManager;
/*     */   }
/*     */   private final SceneManager sceneManager;
/*     */   public static boolean isBlocked(WalkDirection walkDirection, int collisionData) {
/*  18 */     if (CollisionFlags.checkFlag(collisionData, 2097152)) {
/*  19 */       return true;
/*     */     }
/*  21 */     if (CollisionFlags.checkFlag(collisionData, 256)) {
/*  22 */       return true;
/*     */     }
/*  24 */     if (CollisionFlags.checkFlag(collisionData, 16777216)) {
/*  25 */       return true;
/*     */     }
/*  27 */     switch (walkDirection) {
/*     */       case NORTH:
/*  29 */         return CollisionFlags.blockedNorth(collisionData);
/*     */       case EAST:
/*  31 */         return CollisionFlags.blockedEast(collisionData);
/*     */       case SOUTH:
/*  33 */         return CollisionFlags.blockedSouth(collisionData);
/*     */       case WEST:
/*  35 */         return CollisionFlags.blockedWest(collisionData);
/*     */       case NORTH_EAST:
/*  37 */         return (CollisionFlags.blockedNorth(collisionData) || CollisionFlags.blockedEast(collisionData));
/*     */       case NORTH_WEST:
/*  39 */         return (CollisionFlags.blockedNorth(collisionData) || CollisionFlags.blockedWest(collisionData));
/*     */       case SOUTH_EAST:
/*  41 */         return (CollisionFlags.blockedSouth(collisionData) || CollisionFlags.blockedEast(collisionData));
/*     */       case SOUTH_WEST:
/*  43 */         return (CollisionFlags.blockedSouth(collisionData) || CollisionFlags.blockedWest(collisionData));
/*     */     } 
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean accessibleFromDirection(int collisionFlag) {
/*  50 */     boolean accessibleFromDirection = false;
/*  51 */     for (WalkDirection walkDirection : WalkDirection.values()) {
/*  52 */       if (!isBlocked(walkDirection, collisionFlag)) {
/*  53 */         accessibleFromDirection = true;
/*     */         break;
/*     */       } 
/*     */     } 
/*  57 */     return accessibleFromDirection;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNeighbourReachable(LocalPosition current, LocalPosition adjacent) {
/*  62 */     if (!isAdjacent(current, adjacent)) {
/*  63 */       throw new IllegalArgumentException("The position 'adjacent' is not adjacent to 'current'.");
/*     */     }
/*     */     
/*  66 */     int flag = this.sceneManager.getTileCollisionFlag((Position)adjacent);
/*  67 */     WalkDirection walkDirectionTowardsCurrent = WalkDirection.between((Position)adjacent, (Position)current);
/*     */     
/*  69 */     boolean blocked = isBlocked(walkDirectionTowardsCurrent, flag);
/*     */     
/*  71 */     if (walkDirectionTowardsCurrent.isDiagonal() && !blocked) {
/*  72 */       WalkDirection[] walkDirections = WalkDirection.diagonalComponents(walkDirectionTowardsCurrent.opposite());
/*  73 */       for (WalkDirection dir : walkDirections) {
/*  74 */         LocalPosition dirPos = current.step(1, dir);
/*  75 */         if (isBlocked(dir.opposite(), this.sceneManager.getTileCollisionFlag((Position)dirPos))) {
/*  76 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*  80 */     return !blocked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAdjacent(LocalPosition current, LocalPosition adjacent) {
/*  91 */     int dx = Math.abs(current.getX() - adjacent.getX());
/*  92 */     int dy = Math.abs(current.getY() - adjacent.getY());
/*  93 */     int dz = Math.abs(current.getPlane() - adjacent.getPlane());
/*     */ 
/*     */     
/*  96 */     return (dx <= 1 && dy <= 1 && dz == 0);
/*     */   }
/*     */   
/*     */   public List<LocalPosition> findReachableTiles(LocalPosition origin, int radius) {
/* 100 */     List<LocalPosition> reachableTiles = new ArrayList<>();
/*     */ 
/*     */     
/* 103 */     Queue<LocalPosition> queue = new LinkedList<>();
/* 104 */     queue.add(origin);
/*     */ 
/*     */     
/* 107 */     Set<LocalPosition> visited = new HashSet<>();
/* 108 */     visited.add(origin);
/*     */ 
/*     */     
/* 111 */     while (!queue.isEmpty()) {
/* 112 */       LocalPosition current = queue.poll();
/* 113 */       reachableTiles.add(current);
/*     */       
/* 115 */       int x = current.getX(), y = current.getY();
/*     */ 
/*     */       
/* 118 */       for (int nextX = x - 1; nextX <= x + 1; nextX++) {
/* 119 */         for (int nextY = y - 1; nextY <= y + 1; nextY++) {
/* 120 */           if (nextX != x || nextY != y) {
/*     */ 
/*     */ 
/*     */             
/* 124 */             LocalPosition neighbor = new LocalPosition(nextX, nextY, current.getPlane());
/*     */ 
/*     */             
/* 127 */             if (neighbor.isValid() && !visited.contains(neighbor))
/*     */             {
/*     */ 
/*     */ 
/*     */               
/* 132 */               if (neighbor.distanceTo((Position)origin) <= radius) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 137 */                 int flag = this.sceneManager.getTileCollisionFlag((Position)neighbor);
/* 138 */                 WalkDirection walkDirection = WalkDirection.between((Position)neighbor, (Position)current);
/*     */                 
/* 140 */                 boolean blocked = isBlocked(walkDirection, flag);
/*     */ 
/*     */                 
/* 143 */                 if (walkDirection.isDiagonal() && !blocked) {
/* 144 */                   WalkDirection[] components = WalkDirection.diagonalComponents(walkDirection.opposite());
/* 145 */                   for (WalkDirection dir : components) {
/* 146 */                     LocalPosition componentPos = current.step(1, dir);
/* 147 */                     if (isBlocked(dir.opposite(), this.sceneManager.getTileCollisionFlag((Position)componentPos))) {
/* 148 */                       blocked = true;
/*     */                       
/*     */                       break;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */                 
/* 155 */                 if (!blocked) {
/* 156 */                   queue.add(neighbor);
/* 157 */                   visited.add(neighbor);
/*     */                 } 
/*     */               }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 163 */     }  return reachableTiles;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\CollisionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */