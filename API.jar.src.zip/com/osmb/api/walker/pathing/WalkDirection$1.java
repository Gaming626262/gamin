/*    */ package com.osmb.api.walker.pathing;


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\WalkDirection$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */