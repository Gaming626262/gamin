/*     */ package com.osmb.api.walker.pathing;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollisionFlags
/*     */ {
/*     */   public static final int OPEN = 0;
/*     */   public static final int OCCUPIED = 256;
/*     */   public static final int SOLID = 131072;
/*     */   public static final int BLOCKED = 2097152;
/*     */   public static final int BLOCKED_FLOOR_DECORATION = 262144;
/*     */   public static final int CLOSED = 16777215;
/*     */   public static final int INITIALIZED = 16777216;
/*     */   public static final int NORTH = 2;
/*     */   public static final int EAST = 8;
/*     */   public static final int SOUTH = 32;
/*     */   public static final int WEST = 128;
/*     */   public static final int NORTHWEST = 1;
/*     */   public static final int NORTHEAST = 4;
/*     */   public static final int SOUTHEAST = 16;
/*     */   public static final int SOUTHWEST = 64;
/*     */   public static final int EAST_NORTH = 10;
/*     */   public static final int EAST_SOUTH = 40;
/*     */   public static final int WEST_SOUTH = 160;
/*     */   public static final int WEST_NORTH = 130;
/*     */   public static final int BLOCKED_NORTH_WALL = 1024;
/*     */   public static final int BLOCKED_EAST_WALL = 4096;
/*     */   public static final int BLOCKED_SOUTH_WALL = 16384;
/*     */   public static final int BLOCKED_WEST_WALL = 65536;
/*     */   public static final int BLOCKED_NORTHEAST = 2048;
/*     */   public static final int BLOCKED_SOUTHEAST = 8192;
/*     */   public static final int BLOCKED_NORTHWEST = 512;
/*     */   public static final int BLOCKED_SOUTHWEST = 32768;
/*     */   public static final int BLOCKED_EAST_NORTH = 5120;
/*     */   public static final int BLOCKED_EAST_SOUTH = 20480;
/*     */   public static final int BLOCKED_WEST_SOUTH = 81920;
/*     */   public static final int BLOCKED_WEST_NORTH = 66560;
/*     */   
/*     */   public static boolean blockedNorth(int collisionData) {
/* 217 */     return (checkFlag(collisionData, 2) || 
/* 218 */       checkFlag(collisionData, 1024));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean blockedEast(int collisionData) {
/* 227 */     return (checkFlag(collisionData, 8) || 
/* 228 */       checkFlag(collisionData, 4096));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean blockedSouth(int collisionData) {
/* 237 */     return (checkFlag(collisionData, 32) || 
/* 238 */       checkFlag(collisionData, 16384));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean blockedWest(int collisionData) {
/* 247 */     return (checkFlag(collisionData, 128) || 
/* 248 */       checkFlag(collisionData, 65536));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWalkable(int collisionData) {
/* 257 */     return (!checkFlag(collisionData, 256) && 
/* 258 */       !checkFlag(collisionData, 131072) && 
/* 259 */       !checkFlag(collisionData, 2097152) && 
/* 260 */       !checkFlag(collisionData, 262144) && 
/* 261 */       !checkFlag(collisionData, 16777215));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInitialized(int collisionData) {
/* 270 */     return checkFlag(collisionData, 16777216);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkFlag(int flag, int checkFlag) {
/* 280 */     return ((flag & checkFlag) == checkFlag);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\CollisionFlags.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */