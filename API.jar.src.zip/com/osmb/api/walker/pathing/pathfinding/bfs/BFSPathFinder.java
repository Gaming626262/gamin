/*     */ package com.osmb.api.walker.pathing.pathfinding.bfs;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.scene.CollisionMap;
/*     */ import com.osmb.api.scene.RSObject;
/*     */ import com.osmb.api.walker.pathing.CollisionManager;
/*     */ import com.osmb.api.walker.pathing.WalkDirection;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Arrays;
/*     */ import java.util.Deque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class BFSPathFinder
/*     */ {
/*     */   private final ScriptCore scriptCoreService;
/*     */   
/*     */   public BFSPathFinder(ScriptCore scriptCoreService) {
/*  22 */     this.scriptCoreService = scriptCoreService;
/*     */   }
/*     */ 
/*     */   
/*     */   public Deque<LocalPosition> find(LocalPosition currentPosition, RSObject object, boolean tryNearest) {
/*  27 */     int locWidth = object.getTileWidth();
/*  28 */     int locLength = object.getTileHeight();
/*  29 */     int locType = object.getObjectType().getId();
/*  30 */     int locAngle = object.getRotation();
/*  31 */     int dx = object.getLocalX();
/*  32 */     int dy = object.getLocalY();
/*     */     
/*  34 */     int interactionFlags = object.getInteractionSideFlags();
/*     */     
/*  36 */     int[] bfsStepX = new int[4000];
/*  37 */     int[] bfsStepY = new int[4000];
/*  38 */     int[][] bfsDirection = new int[128][128];
/*  39 */     int[][] bfsCost = new int[128][128];
/*  40 */     for (int x = 0; x < 128; x++) {
/*  41 */       for (int j = 0; j < 128; j++) {
/*  42 */         bfsDirection[x][j] = 0;
/*  43 */         bfsCost[x][j] = Integer.MAX_VALUE;
/*     */       } 
/*     */     } 
/*     */     
/*  47 */     int srcX = currentPosition.getX();
/*  48 */     int srcY = currentPosition.getY();
/*  49 */     int currentLevel = currentPosition.getPlane();
/*  50 */     int i = srcX;
/*  51 */     int y = srcY;
/*     */     
/*  53 */     bfsDirection[srcX][srcY] = 99;
/*  54 */     bfsCost[srcX][srcY] = 0;
/*     */     
/*  56 */     int steps = 0;
/*  57 */     int length = 0;
/*     */     
/*  59 */     bfsStepX[steps] = srcX;
/*  60 */     bfsStepY[steps++] = srcY;
/*     */     
/*  62 */     boolean arrived = false;
/*  63 */     int bufferSize = bfsStepX.length;
/*  64 */     CollisionMap collisionMap = this.scriptCoreService.getSceneManager().getLevelCollisionMap()[currentLevel];
/*  65 */     int[][] flags = collisionMap.flags;
/*     */     
/*  67 */     while (length != steps) {
/*  68 */       i = bfsStepX[length];
/*  69 */       y = bfsStepY[length];
/*  70 */       length = (length + 1) % bufferSize;
/*     */       
/*  72 */       if (i == dx && y == dy) {
/*  73 */         arrived = true;
/*     */         
/*     */         break;
/*     */       } 
/*  77 */       if (locType != 0) {
/*     */         
/*  79 */         if ((locType < 5 || locType == 10) && collisionMap.reachedDestination(i, y, dx, dy, locAngle, locType - 1)) {
/*  80 */           arrived = true;
/*     */           break;
/*     */         } 
/*  83 */         if (locType < 10 && collisionMap.reachedWall(i, y, dx, dy, locType - 1, locAngle)) {
/*  84 */           arrived = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*  89 */       if (locWidth != 0 && locLength != 0 && collisionMap.reachedLoc(i, y, dx, dy, locWidth, locLength, interactionFlags)) {
/*  90 */         arrived = true;
/*     */         
/*     */         break;
/*     */       } 
/*  94 */       int nextCost = bfsCost[i][y] + 1;
/*     */       
/*  96 */       if (i > 0 && bfsDirection[i - 1][y] == 0 && !CollisionManager.isBlocked(WalkDirection.WEST, flags[i - 1][y])) {
/*  97 */         bfsStepX[steps] = i - 1;
/*  98 */         bfsStepY[steps] = y;
/*  99 */         steps = (steps + 1) % bufferSize;
/* 100 */         bfsDirection[i - 1][y] = 2;
/* 101 */         bfsCost[i - 1][y] = nextCost;
/*     */       } 
/*     */       
/* 104 */       if (i < 127 && bfsDirection[i + 1][y] == 0 && !CollisionManager.isBlocked(WalkDirection.EAST, flags[i + 1][y])) {
/* 105 */         bfsStepX[steps] = i + 1;
/* 106 */         bfsStepY[steps] = y;
/* 107 */         steps = (steps + 1) % bufferSize;
/* 108 */         bfsDirection[i + 1][y] = 8;
/* 109 */         bfsCost[i + 1][y] = nextCost;
/*     */       } 
/*     */       
/* 112 */       if (y > 0 && bfsDirection[i][y - 1] == 0 && !CollisionManager.isBlocked(WalkDirection.SOUTH, flags[i][y - 1])) {
/* 113 */         bfsStepX[steps] = i;
/* 114 */         bfsStepY[steps] = y - 1;
/* 115 */         steps = (steps + 1) % bufferSize;
/* 116 */         bfsDirection[i][y - 1] = 1;
/* 117 */         bfsCost[i][y - 1] = nextCost;
/*     */       } 
/*     */       
/* 120 */       if (y < 127 && bfsDirection[i][y + 1] == 0 && !CollisionManager.isBlocked(WalkDirection.NORTH, flags[i][y + 1])) {
/* 121 */         bfsStepX[steps] = i;
/* 122 */         bfsStepY[steps] = y + 1;
/* 123 */         steps = (steps + 1) % bufferSize;
/* 124 */         bfsDirection[i][y + 1] = 4;
/* 125 */         bfsCost[i][y + 1] = nextCost;
/*     */       } 
/*     */       
/* 128 */       if (i > 0 && y > 0 && bfsDirection[i - 1][y - 1] == 0 && !CollisionManager.isBlocked(WalkDirection.SOUTH, flags[i][y - 1]) && !CollisionManager.isBlocked(WalkDirection.WEST, flags[i - 1][y]) && !CollisionManager.isBlocked(WalkDirection.SOUTH_WEST, flags[i - 1][y - 1])) {
/* 129 */         bfsStepX[steps] = i - 1;
/* 130 */         bfsStepY[steps] = y - 1;
/* 131 */         steps = (steps + 1) % bufferSize;
/* 132 */         bfsDirection[i - 1][y - 1] = 3;
/* 133 */         bfsCost[i - 1][y - 1] = nextCost;
/*     */       } 
/*     */       
/* 136 */       if (i < 127 && y > 0 && bfsDirection[i + 1][y - 1] == 0 && !CollisionManager.isBlocked(WalkDirection.SOUTH_EAST, flags[i + 1][y - 1]) && !CollisionManager.isBlocked(WalkDirection.EAST, flags[i + 1][y]) && !CollisionManager.isBlocked(WalkDirection.SOUTH, flags[i][y - 1])) {
/*     */         
/* 138 */         bfsStepX[steps] = i + 1;
/* 139 */         bfsStepY[steps] = y - 1;
/* 140 */         steps = (steps + 1) % bufferSize;
/* 141 */         bfsDirection[i + 1][y - 1] = 9;
/* 142 */         bfsCost[i + 1][y - 1] = nextCost;
/*     */       } 
/*     */       
/* 145 */       if (i > 0 && y < 127 && bfsDirection[i - 1][y + 1] == 0 && !CollisionManager.isBlocked(WalkDirection.NORTH_WEST, flags[i - 1][y + 1]) && !CollisionManager.isBlocked(WalkDirection.WEST, flags[i - 1][y]) && !CollisionManager.isBlocked(WalkDirection.NORTH, flags[i][y + 1])) {
/* 146 */         bfsStepX[steps] = i - 1;
/* 147 */         bfsStepY[steps] = y + 1;
/* 148 */         steps = (steps + 1) % bufferSize;
/* 149 */         bfsDirection[i - 1][y + 1] = 6;
/* 150 */         bfsCost[i - 1][y + 1] = nextCost;
/*     */       } 
/*     */       
/* 153 */       if (i < 127 && y < 127 && bfsDirection[i + 1][y + 1] == 0 && !CollisionManager.isBlocked(WalkDirection.NORTH_EAST, flags[i + 1][y + 1]) && !CollisionManager.isBlocked(WalkDirection.EAST, flags[i + 1][y]) && !CollisionManager.isBlocked(WalkDirection.NORTH, flags[i][y + 1])) {
/* 154 */         bfsStepX[steps] = i + 1;
/* 155 */         bfsStepY[steps] = y + 1;
/* 156 */         steps = (steps + 1) % bufferSize;
/* 157 */         bfsDirection[i + 1][y + 1] = 12;
/* 158 */         bfsCost[i + 1][y + 1] = nextCost;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 163 */     if (!arrived) {
/* 164 */       if (tryNearest) {
/* 165 */         int min = 100;
/* 166 */         for (int padding = 1; padding < 2; padding++) {
/* 167 */           for (int px = dx - padding; px <= dx + padding; px++) {
/* 168 */             for (int pz = dy - padding; pz <= dy + padding; pz++) {
/* 169 */               if (px >= 0 && pz >= 0 && px < 128 && pz < 128 && bfsCost[px][pz] < min) {
/* 170 */                 min = bfsCost[px][pz];
/* 171 */                 i = px;
/* 172 */                 y = pz;
/* 173 */                 arrived = true;
/*     */               } 
/*     */             } 
/*     */           } 
/* 177 */           if (arrived) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/* 182 */       if (!arrived) {
/* 183 */         return null;
/*     */       }
/*     */     } 
/*     */     
/* 187 */     length = 0;
/* 188 */     bfsStepX[length] = i;
/* 189 */     bfsStepY[length++] = y;
/*     */     
/* 191 */     int dir = bfsDirection[i][y];
/* 192 */     int next = dir;
/*     */ 
/*     */ 
/*     */     
/* 196 */     while (i != srcX || y != srcY) {
/* 197 */       if (next != dir) {
/* 198 */         dir = next;
/* 199 */         bfsStepX[length] = i;
/* 200 */         bfsStepY[length++] = y;
/*     */       } 
/*     */       
/* 203 */       if ((next & 0x2) != 0) {
/*     */         
/* 205 */         i++;
/* 206 */       } else if ((next & 0x8) != 0) {
/*     */         
/* 208 */         i--;
/*     */       } 
/*     */       
/* 211 */       if ((next & 0x1) != 0) {
/*     */         
/* 213 */         y++;
/* 214 */       } else if ((next & 0x4) != 0) {
/*     */         
/* 216 */         y--;
/*     */       } 
/*     */       
/* 219 */       next = bfsDirection[i][y];
/*     */     } 
/*     */     
/* 222 */     if (length > 0) {
/* 223 */       System.out.println("X: " + Arrays.toString(bfsStepX));
/* 224 */       System.out.println("Y: " + Arrays.toString(bfsStepY));
/*     */       
/* 226 */       Deque<LocalPosition> pathQueue = new ArrayDeque<>();
/* 227 */       for (int j = 0; j < length - 1; j++) {
/* 228 */         if (bfsStepX[j] == 0 && bfsStepY[j] == 0) {
/* 229 */           return pathQueue;
/*     */         }
/* 231 */         pathQueue.addFirst(new LocalPosition(bfsStepX[j], bfsStepY[j], currentLevel));
/*     */       } 
/* 233 */       System.out.println("Start x:" + srcX + " y:" + srcY);
/* 234 */       System.out.println("Path queue: " + pathQueue.size());
/* 235 */       return pathQueue;
/*     */     } 
/* 237 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\pathfinding\bfs\BFSPathFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */