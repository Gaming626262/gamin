/*     */ package com.osmb.api.walker.pathing.pathfinding.astar;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.location.position.Position;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.location.position.types.WorldPosition;
/*     */ import com.osmb.api.scene.RSObject;
/*     */ import com.osmb.api.scene.RSTile;
/*     */ import com.osmb.api.shape.Polygon;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.walker.pathing.CollisionManager;
/*     */ import com.osmb.api.walker.pathing.WalkDirection;
/*     */ import com.osmb.api.walker.pathing.pathfinding.Node;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class AStarPathFinder {
/*     */   public AStarPathFinder(ScriptCore core) {
/*  26 */     this.core = core;
/*     */   }
/*     */   private final ScriptCore core;
/*     */   public Deque<WorldPosition> find(LocalPosition origin, LocalPosition target, boolean tryNearest) {
/*  30 */     Map<LocalPosition, Node> nodes = new HashMap<>();
/*  31 */     Node start = new Node(origin);
/*  32 */     Node end = new Node(target);
/*  33 */     nodes.put(origin, start);
/*  34 */     nodes.put(target, end);
/*     */     
/*  36 */     Set<Node> open = new HashSet<>();
/*  37 */     Queue<Node> sorted = new PriorityQueue<>();
/*  38 */     open.add(start);
/*  39 */     sorted.add(start);
/*     */     
/*  41 */     Node closest = start;
/*  42 */     double shortestDistance = Double.MAX_VALUE;
/*     */     do {
/*  44 */       Node node = getCheapest(sorted);
/*  45 */       LocalPosition position = node.getPosition();
/*     */       
/*  47 */       open.remove(node);
/*  48 */       node.close();
/*  49 */       int x = position.getX(), y = position.getY();
/*  50 */       for (int nextX = x - 1; nextX <= x + 1; nextX++) {
/*  51 */         for (int nextY = y - 1; nextY <= y + 1; nextY++) {
/*  52 */           if (nextX != x || nextY != y) {
/*     */ 
/*     */ 
/*     */             
/*  56 */             LocalPosition adjacent = new LocalPosition(nextX, nextY, position.getPlane());
/*  57 */             if (adjacent.isValid()) {
/*     */ 
/*     */               
/*  60 */               int flag = this.core.getSceneManager().getTileCollisionFlag((Position)adjacent);
/*  61 */               WalkDirection walkDirectionTowardsCurrent = WalkDirection.between((Position)adjacent, (Position)position);
/*     */               
/*  63 */               boolean blocked = CollisionManager.isBlocked(walkDirectionTowardsCurrent, flag);
/*     */               
/*  65 */               if (walkDirectionTowardsCurrent.isDiagonal() && !blocked) {
/*  66 */                 WalkDirection[] walkDirections = WalkDirection.diagonalComponents(walkDirectionTowardsCurrent.opposite());
/*  67 */                 for (WalkDirection dir : walkDirections) {
/*  68 */                   LocalPosition dirPos = position.step(1, dir);
/*  69 */                   if (CollisionManager.isBlocked(dir.opposite(), this.core.getSceneManager().getTileCollisionFlag((Position)dirPos))) {
/*  70 */                     blocked = true;
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               } 
/*  75 */               if (!blocked)
/*  76 */               { Node node1 = nodes.computeIfAbsent(adjacent, Node::new);
/*  77 */                 compare(node, node1, open, sorted);
/*     */                 
/*  79 */                 double distance = node1.getPosition().distanceTo((Position)target);
/*     */ 
/*     */                 
/*  82 */                 if (distance < shortestDistance)
/*  83 */                 { closest = node1;
/*  84 */                   shortestDistance = distance; }  } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*  89 */     } while (!open.isEmpty());
/*     */     
/*  91 */     Deque<WorldPosition> shortest = new ArrayDeque<>();
/*  92 */     Node active = end.hasParent() ? end : (tryNearest ? closest : null);
/*  93 */     if (active == null) return null;
/*     */     
/*  95 */     if (active.hasParent()) {
/*  96 */       LocalPosition position = active.getPosition();
/*     */       
/*  98 */       while (!origin.equals(position)) {
/*  99 */         shortest.addFirst(position.toWorldPosition(this.core));
/* 100 */         active = active.getParent();
/* 101 */         position = active.getPosition();
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     return shortest;
/*     */   }
/*     */   
/*     */   public Deque<WorldPosition> find(LocalPosition origin, RSObject object, int interactDistance, boolean tryNearest) {
/* 109 */     int baseX = object.getLocalX();
/* 110 */     int baseY = object.getLocalY();
/* 111 */     int maxX = baseX + object.getTileWidth() - 1;
/* 112 */     int maxY = baseY + object.getTileHeight() - 1;
/* 113 */     int[][] flags = (this.core.getSceneManager().getLevelCollisionMap()[origin.getPlane()]).flags;
/* 114 */     int negativeInteractDistance = interactDistance * -1;
/* 115 */     int truePlane = object.getPlane();
/*     */ 
/*     */     
/* 118 */     List<LocalPosition> targetTiles = new ArrayList<>();
/* 119 */     if (object.interactableFrom(WalkDirection.NORTH))
/*     */     {
/* 121 */       for (int x = baseX; x <= maxX; x++) {
/* 122 */         if (x >= 0 && x < 128 && maxY + 1 >= 0 && maxY + 1 < 128 && (
/* 123 */           flags[x][maxY + 1] & 0x20) == 0) {
/* 124 */           for (int yOffset = 1; yOffset <= interactDistance; yOffset++) {
/* 125 */             targetTiles.add(new LocalPosition(x, maxY + yOffset, truePlane));
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 131 */     if (object.interactableFrom(WalkDirection.SOUTH))
/*     */     {
/* 133 */       for (int x = baseX; x <= maxX; x++) {
/* 134 */         if (x >= 0 && x < 128 && baseY - 1 >= 0 && baseY - 1 < 128 && (
/* 135 */           flags[x][maxY - 1] & 0x2) == 0) {
/* 136 */           for (int yOffset = -1; yOffset >= negativeInteractDistance; yOffset--) {
/* 137 */             targetTiles.add(new LocalPosition(x, baseY + yOffset, truePlane));
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 143 */     if (object.interactableFrom(WalkDirection.EAST))
/*     */     {
/* 145 */       for (int y = baseY; y <= maxY; y++) {
/* 146 */         if (maxX + 1 >= 0 && maxX + 1 < 128 && y >= 0 && y < 128 && (
/* 147 */           flags[maxX + 1][y] & 0x80) == 0) {
/* 148 */           for (int xOffset = 1; xOffset <= interactDistance; xOffset++) {
/* 149 */             targetTiles.add(new LocalPosition(maxX + xOffset, y, truePlane));
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 155 */     if (object.interactableFrom(WalkDirection.WEST))
/*     */     {
/* 157 */       for (int y = baseY; y <= maxY; y++) {
/* 158 */         if (baseX - 1 >= 0 && baseX - 1 < 128 && y >= 0 && y < 128 && (
/* 159 */           flags[baseX - 1][y] & 0x8) == 0) {
/* 160 */           for (int xOffset = -1; xOffset >= negativeInteractDistance; xOffset--) {
/* 161 */             targetTiles.add(new LocalPosition(baseX + xOffset, y, truePlane));
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 167 */     if (targetTiles.isEmpty()) {
/* 168 */       return null;
/*     */     }
/*     */     
/* 171 */     return find(origin, targetTiles, tryNearest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Deque<WorldPosition> find(LocalPosition origin, List<LocalPosition> targets, boolean tryNearest) {
/* 189 */     this.core.getScreen().queueCanvasDrawable("walk", canvas -> {
/*     */           for (LocalPosition target : targets) {
/*     */             RSTile tile = this.core.getSceneManager().getTile((Position)target);
/*     */             
/*     */             Polygon poly = tile.getTilePoly();
/*     */             if (poly != null) {
/*     */               canvas.fillPolygon(poly.getXPoints(), poly.getYPoints(), poly.numVertices(), Color.RED.getRGB(), 0.6D);
/*     */             }
/*     */           } 
/*     */         });
/* 199 */     boolean isOriginInTargets = false;
/* 200 */     for (LocalPosition target : targets) {
/* 201 */       if (origin.equals(target)) {
/* 202 */         isOriginInTargets = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 206 */     if (isOriginInTargets) {
/* 207 */       return new ArrayDeque<>(Collections.singletonList(origin.toWorldPosition(this.core)));
/*     */     }
/* 209 */     Map<LocalPosition, Node> nodes = new HashMap<>();
/* 210 */     Node start = new Node(origin);
/* 211 */     nodes.put(origin, start);
/*     */     
/* 213 */     List<Node> targetNodes = new ArrayList<>();
/* 214 */     for (LocalPosition target : targets) {
/* 215 */       Node end = new Node(target);
/* 216 */       targetNodes.add(end);
/* 217 */       nodes.put(target, end);
/*     */     } 
/*     */     
/* 220 */     Set<Node> open = new HashSet<>();
/* 221 */     Queue<Node> sorted = new PriorityQueue<>();
/* 222 */     open.add(start);
/* 223 */     sorted.add(start);
/* 224 */     Node closest = start;
/* 225 */     double shortestDistance = Double.MAX_VALUE;
/*     */     do {
/* 227 */       Node node = getCheapest(sorted);
/* 228 */       LocalPosition position = node.getPosition();
/* 229 */       open.remove(node);
/* 230 */       node.close();
/* 231 */       int x = position.getX(), y = position.getY();
/* 232 */       for (int nextX = x - 1; nextX <= x + 1; nextX++) {
/* 233 */         for (int nextY = y - 1; nextY <= y + 1; nextY++) {
/* 234 */           if (nextX != x || nextY != y) {
/*     */ 
/*     */ 
/*     */             
/* 238 */             LocalPosition adjacent = new LocalPosition(nextX, nextY, position.getPlane());
/* 239 */             if (adjacent.isValid())
/*     */             {
/*     */               
/* 242 */               if (this.core.getWalker().getCollisionManager().isNeighbourReachable(position, adjacent)) {
/*     */ 
/*     */                 
/* 245 */                 Node node1 = nodes.computeIfAbsent(adjacent, Node::new);
/* 246 */                 compare(node, node1, open, sorted);
/*     */                 
/* 248 */                 for (Node target : targetNodes) {
/* 249 */                   double distance = node1.getPosition().distanceTo((Position)target.getPosition());
/*     */ 
/*     */                   
/* 252 */                   if (distance < shortestDistance)
/* 253 */                   { closest = node1;
/* 254 */                     shortestDistance = distance; } 
/*     */                 } 
/*     */               }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 260 */     } while (!open.isEmpty());
/*     */     
/* 262 */     List<Node> nodesWithParents = new ArrayList<>();
/* 263 */     for (Node targetNode : targetNodes) {
/* 264 */       if (targetNode.hasParent()) {
/* 265 */         nodesWithParents.add(targetNode);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 270 */     Deque<WorldPosition> shortest = new ArrayDeque<>();
/*     */     
/* 272 */     Node active = null;
/* 273 */     if (!targetNodes.isEmpty()) {
/*     */       
/* 275 */       targetNodes.sort(Comparator.comparingInt(o -> o.getPosition().distanceTo((Position)origin)));
/* 276 */       for (int i = 0; i < targetNodes.size(); i++) {
/* 277 */         Node node = targetNodes.get(i);
/* 278 */         if (node.hasParent()) {
/* 279 */           active = node;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 284 */     if (active == null && tryNearest) {
/* 285 */       active = closest;
/*     */     }
/* 287 */     if (active == null) {
/* 288 */       return null;
/*     */     }
/*     */     
/* 291 */     if (active.hasParent()) {
/* 292 */       LocalPosition position = active.getPosition();
/*     */       
/* 294 */       while (!origin.equals(position)) {
/* 295 */         shortest.addFirst(position.toWorldPosition(this.core));
/* 296 */         active = active.getParent();
/* 297 */         position = active.getPosition();
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     return shortest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compare(Node active, Node other, Set<Node> open, Queue<Node> sorted) {
/* 317 */     int heuristicCost, dx = Math.abs(other.getPosition().getX() - active.getPosition().getX());
/* 318 */     int dy = Math.abs(other.getPosition().getY() - active.getPosition().getY());
/*     */ 
/*     */     
/* 321 */     int straightCost = 10;
/*     */     
/* 323 */     int diagonalCost = 14;
/*     */ 
/*     */ 
/*     */     
/* 327 */     if (dx > dy) {
/* 328 */       heuristicCost = diagonalCost * dy + straightCost * (dx - dy);
/*     */     } else {
/* 330 */       heuristicCost = diagonalCost * dx + straightCost * (dy - dx);
/*     */     } 
/*     */ 
/*     */     
/* 334 */     int cost = active.getCost() + heuristicCost;
/*     */ 
/*     */     
/* 337 */     if (other.getCost() > cost) {
/* 338 */       open.remove(other);
/* 339 */       other.close();
/* 340 */     } else if (other.isOpen() && !open.contains(other)) {
/* 341 */       other.setCost(cost);
/* 342 */       other.setParent(active);
/* 343 */       open.add(other);
/* 344 */       sorted.add(other);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getCheapest(Queue<Node> nodes) {
/* 356 */     Node node = nodes.peek();
/* 357 */     while (!node.isOpen()) {
/* 358 */       nodes.poll();
/* 359 */       node = nodes.peek();
/*     */     } 
/* 361 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\pathfinding\astar\AStarPathFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */