/*     */ package com.osmb.api.walker.pathing.pathfinding;
/*     */ 
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Node
/*     */   implements Comparable<Node>
/*     */ {
/*     */   private int cost;
/*     */   private boolean open = true;
/*  30 */   private Optional<Node> parent = Optional.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final LocalPosition position;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node(LocalPosition position) {
/*  43 */     this(position, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node(LocalPosition position, int cost) {
/*  53 */     this.position = position;
/*  54 */     this.cost = cost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  61 */     this.open = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Node other) {
/*  66 */     return Integer.compare(this.cost, other.cost);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  71 */     if (obj instanceof Node) {
/*  72 */       Node other = (Node)obj;
/*     */       
/*  74 */       return this.position.equals(other.position);
/*     */     } 
/*     */     
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCost() {
/*  86 */     return this.cost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getParent() {
/*  96 */     return this.parent.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalPosition getPosition() {
/* 105 */     return this.position;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 110 */     return this.position.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasParent() {
/* 119 */     return this.parent.isPresent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 128 */     return this.open;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCost(int cost) {
/* 137 */     this.cost = cost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(Node parent) {
/* 146 */     this.parent = Optional.ofNullable(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return this.position.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\pathfinding\Node.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */