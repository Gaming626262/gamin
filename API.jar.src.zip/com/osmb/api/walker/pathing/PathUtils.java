/*    */ package com.osmb.api.walker.pathing;
/*    */ 
/*    */ import com.osmb.api.location.position.types.WorldPosition;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class PathUtils {
/*    */   public static List<WorldPosition> smoothPath(List<WorldPosition> path, int smoothingWindow) {
/* 10 */     WorldPosition endPoint = path.get(path.size() - 1);
/* 11 */     List<WorldPosition> smoothedPath = new ArrayList<>();
/*    */     
/* 13 */     for (int i = 0; i < path.size(); i++) {
/* 14 */       int start = Math.max(0, i - smoothingWindow);
/* 15 */       int end = Math.min(path.size() - 1, i + smoothingWindow);
/*    */       
/* 17 */       int sumX = 0, sumY = 0;
/* 18 */       for (int j = start; j <= end; j++) {
/* 19 */         sumX += ((WorldPosition)path.get(j)).getX();
/* 20 */         sumY += ((WorldPosition)path.get(j)).getY();
/*    */       } 
/*    */       
/* 23 */       int avgX = sumX / (end - start + 1);
/* 24 */       int avgY = sumY / (end - start + 1);
/* 25 */       smoothedPath.add(new WorldPosition(avgX, avgY, ((WorldPosition)path.get(i)).getPlane()));
/*    */     } 
/*    */     
/* 28 */     if (!smoothedPath.contains(endPoint)) {
/* 29 */       smoothedPath.add(endPoint);
/*    */     }
/* 31 */     return smoothedPath;
/*    */   }
/*    */ 
/*    */   
/*    */   public static List<WorldPosition> addDetours(List<WorldPosition> path, int maxDetourDistance) {
/* 36 */     List<WorldPosition> detouredPath = new ArrayList<>();
/* 37 */     Random random = new Random();
/*    */     
/* 39 */     WorldPosition previous = null;
/* 40 */     for (WorldPosition current : path) {
/* 41 */       if (previous != null) {
/*    */         
/* 43 */         detouredPath.add(current);
/*    */ 
/*    */         
/* 46 */         if (random.nextDouble() < 0.2D) {
/* 47 */           int detourX = current.getX() + random.nextInt(maxDetourDistance * 2) - maxDetourDistance;
/* 48 */           int detourY = current.getY() + random.nextInt(maxDetourDistance * 2) - maxDetourDistance;
/* 49 */           WorldPosition detour = new WorldPosition(detourX, detourY, current.getPlane());
/* 50 */           detouredPath.add(detour);
/*    */         } 
/*    */       } 
/* 53 */       previous = current;
/*    */     } 
/*    */     
/* 56 */     return detouredPath;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\PathUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */