/*     */ package com.osmb.api.walker.pathing;
/*     */ 
/*     */ import com.osmb.api.location.position.Position;
/*     */ 
/*     */ public enum WalkDirection {
/*   6 */   NORTH("N"),
/*   7 */   SOUTH("S"),
/*   8 */   EAST("E"),
/*   9 */   WEST("W"),
/*  10 */   NORTH_EAST("NE"),
/*  11 */   NORTH_WEST("NW"),
/*  12 */   SOUTH_EAST("SE"),
/*  13 */   SOUTH_WEST("SW"),
/*  14 */   NONE("");
/*     */ 
/*     */   
/*     */   private final String shortName;
/*     */ 
/*     */   
/*     */   WalkDirection(String shortName) {
/*  21 */     this.shortName = shortName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getShortName() {
/*  26 */     return this.shortName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WalkDirection[] diagonalComponents(WalkDirection walkDirection) {
/*  36 */     switch (walkDirection) {
/*     */       case NORTH_EAST:
/*  38 */         return new WalkDirection[] { NORTH, EAST };
/*     */       case NORTH_WEST:
/*  40 */         return new WalkDirection[] { NORTH, WEST };
/*     */       case SOUTH_EAST:
/*  42 */         return new WalkDirection[] { SOUTH, EAST };
/*     */       case SOUTH_WEST:
/*  44 */         return new WalkDirection[] { SOUTH, WEST };
/*     */     } 
/*     */     
/*  47 */     throw new IllegalArgumentException("Must provide a diagonal direction.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WalkDirection fromDeltas(int deltaX, int deltaY) {
/*  58 */     if (deltaY == 1) {
/*  59 */       if (deltaX == 1)
/*  60 */         return NORTH_EAST; 
/*  61 */       if (deltaX == 0)
/*  62 */         return NORTH; 
/*  63 */       if (deltaX == -1) {
/*  64 */         return NORTH_WEST;
/*     */       }
/*  66 */     } else if (deltaY == -1) {
/*  67 */       if (deltaX == 1)
/*  68 */         return SOUTH_EAST; 
/*  69 */       if (deltaX == 0)
/*  70 */         return SOUTH; 
/*  71 */       if (deltaX == -1) {
/*  72 */         return SOUTH_WEST;
/*     */       }
/*  74 */     } else if (deltaY == 0) {
/*  75 */       if (deltaX == 1)
/*  76 */         return EAST; 
/*  77 */       if (deltaX == 0)
/*  78 */         return NONE; 
/*  79 */       if (deltaX == -1) {
/*  80 */         return WEST;
/*     */       }
/*     */     } 
/*     */     
/*  84 */     throw new IllegalArgumentException("Difference between Positions must be [-1, 1].");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WalkDirection between(Position current, Position next) {
/*  95 */     int deltaX = next.getX() - current.getX();
/*  96 */     int deltaY = next.getY() - current.getY();
/*     */     
/*  98 */     return fromDeltas(Integer.signum(deltaX), Integer.signum(deltaY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int deltaX() {
/* 108 */     switch (this) {
/*     */       case NORTH_EAST:
/*     */       case SOUTH_EAST:
/*     */       case EAST:
/* 112 */         return 1;
/*     */       case NORTH_WEST:
/*     */       case SOUTH_WEST:
/*     */       case WEST:
/* 116 */         return -1;
/*     */     } 
/*     */     
/* 119 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int deltaY() {
/* 128 */     switch (this) {
/*     */       case NORTH_EAST:
/*     */       case NORTH_WEST:
/*     */       case NORTH:
/* 132 */         return 1;
/*     */       case SOUTH_EAST:
/*     */       case SOUTH_WEST:
/*     */       case SOUTH:
/* 136 */         return -1;
/*     */     } 
/*     */     
/* 139 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDiagonal() {
/* 148 */     return (this == SOUTH_EAST || this == SOUTH_WEST || this == NORTH_EAST || this == NORTH_WEST);
/*     */   }
/*     */   
/*     */   public boolean isValidDirection(int x, int y, int[][] collisionData) {
/*     */     try {
/* 153 */       switch (this) {
/*     */         case NORTH:
/* 155 */           return !CollisionFlags.blockedNorth(collisionData[x][y]);
/*     */         case EAST:
/* 157 */           return !CollisionFlags.blockedEast(collisionData[x][y]);
/*     */         case SOUTH:
/* 159 */           return !CollisionFlags.blockedSouth(collisionData[x][y]);
/*     */         case WEST:
/* 161 */           return !CollisionFlags.blockedWest(collisionData[x][y]);
/*     */         case NORTH_EAST:
/* 163 */           if (CollisionFlags.blockedNorth(collisionData[x][y]) || CollisionFlags.blockedEast(collisionData[x][y])) {
/* 164 */             return false;
/*     */           }
/* 166 */           if (!CollisionFlags.isWalkable(collisionData[x + 1][y])) {
/* 167 */             return false;
/*     */           }
/* 169 */           if (!CollisionFlags.isWalkable(collisionData[x][y + 1])) {
/* 170 */             return false;
/*     */           }
/* 172 */           if (CollisionFlags.blockedNorth(collisionData[x + 1][y])) {
/* 173 */             return false;
/*     */           }
/* 175 */           return !CollisionFlags.blockedEast(collisionData[x][y + 1]);
/*     */         case NORTH_WEST:
/* 177 */           if (CollisionFlags.blockedNorth(collisionData[x][y]) || CollisionFlags.blockedWest(collisionData[x][y])) {
/* 178 */             return false;
/*     */           }
/* 180 */           if (!CollisionFlags.isWalkable(collisionData[x - 1][y])) {
/* 181 */             return false;
/*     */           }
/* 183 */           if (!CollisionFlags.isWalkable(collisionData[x][y + 1])) {
/* 184 */             return false;
/*     */           }
/* 186 */           if (CollisionFlags.blockedNorth(collisionData[x - 1][y])) {
/* 187 */             return false;
/*     */           }
/* 189 */           return !CollisionFlags.blockedWest(collisionData[x][y + 1]);
/*     */         case SOUTH_EAST:
/* 191 */           if (CollisionFlags.blockedSouth(collisionData[x][y]) || CollisionFlags.blockedEast(collisionData[x][y])) {
/* 192 */             return false;
/*     */           }
/* 194 */           if (!CollisionFlags.isWalkable(collisionData[x + 1][y])) {
/* 195 */             return false;
/*     */           }
/* 197 */           if (!CollisionFlags.isWalkable(collisionData[x][y - 1])) {
/* 198 */             return false;
/*     */           }
/* 200 */           if (CollisionFlags.blockedSouth(collisionData[x + 1][y])) {
/* 201 */             return false;
/*     */           }
/* 203 */           return !CollisionFlags.blockedEast(collisionData[x][y - 1]);
/*     */         case SOUTH_WEST:
/* 205 */           if (CollisionFlags.blockedSouth(collisionData[x][y]) || CollisionFlags.blockedWest(collisionData[x][y])) {
/* 206 */             return false;
/*     */           }
/* 208 */           if (!CollisionFlags.isWalkable(collisionData[x - 1][y])) {
/* 209 */             return false;
/*     */           }
/* 211 */           if (!CollisionFlags.isWalkable(collisionData[x][y - 1])) {
/* 212 */             return false;
/*     */           }
/* 214 */           if (CollisionFlags.blockedSouth(collisionData[x - 1][y])) {
/* 215 */             return false;
/*     */           }
/* 217 */           return !CollisionFlags.blockedWest(collisionData[x][y - 1]);
/*     */       } 
/* 219 */       return false;
/*     */     }
/* 221 */     catch (ArrayIndexOutOfBoundsException e) {
/* 222 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WalkDirection opposite() {
/* 232 */     switch (this) {
/*     */       case NORTH:
/* 234 */         return SOUTH;
/*     */       case SOUTH:
/* 236 */         return NORTH;
/*     */       case EAST:
/* 238 */         return WEST;
/*     */       case WEST:
/* 240 */         return EAST;
/*     */       case NORTH_EAST:
/* 242 */         return SOUTH_WEST;
/*     */       case NORTH_WEST:
/* 244 */         return SOUTH_EAST;
/*     */       case SOUTH_EAST:
/* 246 */         return NORTH_WEST;
/*     */       case SOUTH_WEST:
/* 248 */         return NORTH_EAST;
/*     */       case NONE:
/* 250 */         return NONE;
/*     */     } 
/* 252 */     throw new IllegalStateException("Unexpected direction: " + this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\walker\pathing\WalkDirection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */