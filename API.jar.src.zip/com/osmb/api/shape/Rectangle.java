/*     */ package com.osmb.api.shape;
/*     */ 
/*     */ import com.osmb.api.utils.Utils;
/*     */ import java.awt.Point;
/*     */ 
/*     */ public class Rectangle
/*     */   implements Shape {
/*     */   public int x;
/*     */   public int y;
/*     */   
/*     */   public Rectangle(int x, int y, int width, int height) {
/*  12 */     this.x = x;
/*  13 */     this.y = y;
/*  14 */     this.width = width;
/*  15 */     this.height = height;
/*     */   }
/*     */   public int width; public int height;
/*     */   public Rectangle(java.awt.Rectangle rectangle) {
/*  19 */     this.x = rectangle.x;
/*  20 */     this.y = rectangle.y;
/*  21 */     this.width = rectangle.width;
/*  22 */     this.height = rectangle.height;
/*     */   }
/*     */   
/*     */   public boolean contains(Rectangle child) {
/*  26 */     return (child.x >= this.x && child.x + child.width <= this.x + this.width && child.y >= this.y && child.y + child.height <= this.y + this.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle intersection(Rectangle rect) {
/*  34 */     int x1 = Math.max(this.x, rect.x);
/*  35 */     int y1 = Math.max(this.y, rect.y);
/*  36 */     int x2 = Math.min(this.x + this.width, rect.x + rect.width);
/*  37 */     int y2 = Math.min(this.y + this.height, rect.y + rect.height);
/*     */ 
/*     */     
/*  40 */     if (x2 > x1 && y2 > y1) {
/*  41 */       return new Rectangle(x1, y1, x2 - x1, y2 - y1);
/*     */     }
/*  43 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle union(java.awt.Rectangle other) {
/*  48 */     int minX = Math.min(this.x, other.x);
/*  49 */     int minY = Math.min(this.y, other.y);
/*     */ 
/*     */     
/*  52 */     int maxX = Math.max(this.x + this.width, other.x + other.width);
/*  53 */     int maxY = Math.max(this.y + this.height, other.y + other.height);
/*     */ 
/*     */     
/*  56 */     int unionWidth = maxX - minX;
/*  57 */     int unionHeight = maxY - minY;
/*     */ 
/*     */     
/*  60 */     return new Rectangle(minX, minY, unionWidth, unionHeight);
/*     */   }
/*     */   
/*     */   public Rectangle getPadding(int padding) {
/*  64 */     int newX = this.x + padding;
/*  65 */     int newY = this.y + padding;
/*  66 */     int newWidth = this.width - 2 * padding;
/*  67 */     int newHeight = this.height - 2 * padding;
/*     */ 
/*     */     
/*  70 */     newWidth = Math.max(newWidth, 0);
/*  71 */     newHeight = Math.max(newHeight, 0);
/*     */     
/*  73 */     return new Rectangle(newX, newY, newWidth, newHeight);
/*     */   }
/*     */   
/*     */   public Rectangle getPadding(int top, int left, int bottom, int right) {
/*  77 */     int newX = this.x + left;
/*  78 */     int newY = this.y + top;
/*  79 */     int newWidth = this.width - left + right;
/*  80 */     int newHeight = this.height - top + bottom;
/*     */ 
/*     */     
/*  83 */     newWidth = Math.max(newWidth, 0);
/*  84 */     newHeight = Math.max(newHeight, 0);
/*     */     
/*  86 */     return new Rectangle(newX, newY, newWidth, newHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle union(Rectangle other) {
/*  91 */     int minX = Math.min(this.x, other.x);
/*  92 */     int minY = Math.min(this.y, other.y);
/*     */ 
/*     */     
/*  95 */     int maxX = Math.max(this.x + this.width, other.x + other.width);
/*  96 */     int maxY = Math.max(this.y + this.height, other.y + other.height);
/*     */ 
/*     */     
/*  99 */     int unionWidth = maxX - minX;
/* 100 */     int unionHeight = maxY - minY;
/*     */ 
/*     */     
/* 103 */     return new Rectangle(minX, minY, unionWidth, unionHeight);
/*     */   }
/*     */   
/*     */   public boolean intersects(Rectangle other) {
/* 107 */     return (this.x < other.x + other.width && this.x + this.width > other.x && this.y < other.y + other.height && this.y + this.height > other.y);
/*     */   }
/*     */   
/*     */   public Point getCenter() {
/* 111 */     int centerX = this.x + this.width / 2;
/* 112 */     int centerY = this.y + this.height / 2;
/* 113 */     return new Point(centerX, centerY);
/*     */   }
/*     */   
/*     */   public int getX() {
/* 117 */     return this.x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 121 */     return this.y;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 125 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 129 */     return this.height;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(int x, int y) {
/* 134 */     return (x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height);
/*     */   }
/*     */   public boolean contains(double x, double y) {
/* 137 */     return (x >= this.x && x <= (this.x + this.width) && y >= this.y && y <= (this.y + this.height));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Point point) {
/* 142 */     return contains(point.x, point.y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getRandomPoint() {
/* 153 */     int x = this.x;
/* 154 */     int y = this.y;
/* 155 */     int w = Math.abs(this.width);
/* 156 */     int h = Math.abs(this.height);
/*     */     
/* 158 */     int randomX = (w == 0) ? 0 : Utils.random(w);
/* 159 */     int randomY = (h == 0) ? 0 : Utils.random(h);
/*     */     
/* 161 */     if (this.width < 0) {
/* 162 */       x += this.width;
/*     */     }
/* 164 */     if (this.height < 0) {
/* 165 */       y += this.height;
/*     */     }
/* 167 */     return new Point(x + randomX, y + randomY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getResized(double factor) {
/* 173 */     int newWidth = (int)(this.width * factor);
/* 174 */     int newHeight = (int)(this.height * factor);
/*     */ 
/*     */     
/* 177 */     int dx = (this.width - newWidth) / 2;
/* 178 */     int dy = (this.height - newHeight) / 2;
/*     */ 
/*     */     
/* 181 */     int newX = this.x + dx - dx / 2;
/* 182 */     int newY = this.y + dy - dy / 2;
/*     */ 
/*     */     
/* 185 */     return new Rectangle(newX, newY, newWidth, newHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getSubRectangle(Rectangle rectangle) {
/* 190 */     return new Rectangle(this.x + rectangle.x, this.y + rectangle.y, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     return "x=" + this.x + ", y=" + this.y + ", width=" + this.width + ", height=" + this.height;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\shape\Rectangle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */