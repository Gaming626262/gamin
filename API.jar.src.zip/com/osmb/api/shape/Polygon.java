/*     */ package com.osmb.api.shape;
/*     */ 
/*     */ import com.osmb.api.utils.Utils;
/*     */ import java.awt.Point;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ public class Polygon
/*     */   implements Shape
/*     */ {
/*     */   private int[] xPoints;
/*     */   private int[] yPoints;
/*     */   private int numVertices;
/*     */   
/*     */   public Polygon() {
/*  16 */     this.xPoints = new int[0];
/*  17 */     this.yPoints = new int[0];
/*  18 */     this.numVertices = 0;
/*     */   }
/*     */   
/*     */   public Polygon(int[] xPoints, int[] yPoints) {
/*  22 */     if (xPoints.length != yPoints.length) {
/*  23 */       throw new IllegalArgumentException("xPoints and yPoints must have the same length");
/*     */     }
/*  25 */     this.xPoints = Arrays.copyOf(xPoints, xPoints.length);
/*  26 */     this.yPoints = Arrays.copyOf(yPoints, yPoints.length);
/*  27 */     this.numVertices = xPoints.length;
/*     */   }
/*     */   
/*     */   public void addVertex(int x, int y) {
/*  31 */     this.xPoints = Arrays.copyOf(this.xPoints, this.numVertices + 1);
/*  32 */     this.yPoints = Arrays.copyOf(this.yPoints, this.numVertices + 1);
/*  33 */     this.xPoints[this.numVertices] = x;
/*  34 */     this.yPoints[this.numVertices] = y;
/*  35 */     this.numVertices++;
/*     */   }
/*     */   
/*     */   public int numVertices() {
/*  39 */     return this.numVertices;
/*     */   }
/*     */   
/*     */   public double perimeter() {
/*  43 */     double perimeter = 0.0D;
/*  44 */     for (int i = 0; i < this.numVertices; i++) {
/*  45 */       int nextIndex = (i + 1) % this.numVertices;
/*  46 */       double dx = (this.xPoints[nextIndex] - this.xPoints[i]);
/*  47 */       double dy = (this.yPoints[nextIndex] - this.yPoints[i]);
/*  48 */       perimeter += Math.sqrt(dx * dx + dy * dy);
/*     */     } 
/*  50 */     return perimeter;
/*     */   }
/*     */   
/*     */   public double calculateArea() {
/*  54 */     double area = 0.0D;
/*  55 */     for (int i = 0; i < this.numVertices; i++) {
/*  56 */       int j = (i + 1) % this.numVertices;
/*  57 */       area += (this.xPoints[i] * this.yPoints[j] - this.yPoints[i] * this.xPoints[j]);
/*     */     } 
/*  59 */     return Math.abs(area) / 2.0D;
/*     */   }
/*     */   
/*     */   public Polygon convexHull() {
/*  63 */     if (this.numVertices < 3) return null;
/*     */ 
/*     */     
/*  66 */     Integer[] indices = new Integer[this.numVertices];
/*  67 */     for (int i = 0; i < this.numVertices; i++) {
/*  68 */       indices[i] = Integer.valueOf(i);
/*     */     }
/*     */ 
/*     */     
/*  72 */     Arrays.sort(indices, (i, j) -> (this.xPoints[i.intValue()] == this.xPoints[j.intValue()]) ? Integer.compare(this.yPoints[i.intValue()], this.yPoints[j.intValue()]) : Integer.compare(this.xPoints[i.intValue()], this.xPoints[j.intValue()]));
/*     */ 
/*     */     
/*  75 */     int[] lower = new int[this.numVertices];
/*  76 */     int lowerSize = 0;
/*  77 */     for (int j = 0; j < this.numVertices; j++) {
/*  78 */       while (lowerSize >= 2 && ccw(lower[lowerSize - 2], lower[lowerSize - 1], indices[j].intValue()) <= 0) {
/*  79 */         lowerSize--;
/*     */       }
/*  81 */       lower[lowerSize++] = indices[j].intValue();
/*     */     } 
/*     */ 
/*     */     
/*  85 */     int[] upper = new int[this.numVertices];
/*  86 */     int upperSize = 0;
/*  87 */     for (int k = this.numVertices - 1; k >= 0; k--) {
/*  88 */       while (upperSize >= 2 && ccw(upper[upperSize - 2], upper[upperSize - 1], indices[k].intValue()) <= 0) {
/*  89 */         upperSize--;
/*     */       }
/*  91 */       upper[upperSize++] = indices[k].intValue();
/*     */     } 
/*     */ 
/*     */     
/*  95 */     int hullSize = lowerSize + upperSize - 2;
/*  96 */     int[] hullX = new int[hullSize];
/*  97 */     int[] hullY = new int[hullSize]; int m;
/*  98 */     for (m = 0; m < lowerSize - 1; m++) {
/*  99 */       hullX[m] = this.xPoints[lower[m]];
/* 100 */       hullY[m] = this.yPoints[lower[m]];
/*     */     } 
/* 102 */     for (m = 0; m < upperSize - 1; m++) {
/* 103 */       hullX[lowerSize - 1 + m] = this.xPoints[upper[m]];
/* 104 */       hullY[lowerSize - 1 + m] = this.yPoints[upper[m]];
/*     */     } 
/*     */     
/* 107 */     return new Polygon(hullX, hullY);
/*     */   }
/*     */ 
/*     */   
/*     */   private int ccw(int p1, int p2, int p3) {
/* 112 */     long cross = (this.xPoints[p2] - this.xPoints[p1]) * (this.yPoints[p3] - this.yPoints[p1]) - (this.yPoints[p2] - this.yPoints[p1]) * (this.xPoints[p3] - this.xPoints[p1]);
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (cross > 0L) return 1; 
/* 117 */     if (cross < 0L) return -1; 
/* 118 */     return 0;
/*     */   }
/*     */   
/*     */   public int[] getXPoints() {
/* 122 */     return Arrays.copyOf(this.xPoints, this.numVertices);
/*     */   }
/*     */   
/*     */   public int[] getYPoints() {
/* 126 */     return Arrays.copyOf(this.yPoints, this.numVertices);
/*     */   }
/*     */   
/*     */   public Point getCenter() {
/* 130 */     int totalX = 0;
/* 131 */     int totalY = 0;
/* 132 */     for (int i = 0; i < this.numVertices; i++) {
/* 133 */       totalX += this.xPoints[i];
/* 134 */       totalY += this.yPoints[i];
/*     */     } 
/* 136 */     return new Point(totalX / this.numVertices, totalY / this.numVertices);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(int x, int y) {
/* 141 */     boolean inside = false; int j;
/* 142 */     for (int i = 0; i < this.numVertices; j = i++) {
/* 143 */       if (((this.yPoints[i] > y) ? true : false) != ((this.yPoints[j] > y) ? true : false) && x < (this.xPoints[j] - this.xPoints[i]) * (y - this.yPoints[i]) / (this.yPoints[j] - this.yPoints[i]) + this.xPoints[i]) {
/* 144 */         inside = !inside;
/*     */       }
/*     */     } 
/* 147 */     return inside;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Point point) {
/* 152 */     return contains(point.x, point.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/* 157 */     int minX = Arrays.stream(this.xPoints).min().orElse(0);
/* 158 */     int minY = Arrays.stream(this.yPoints).min().orElse(0);
/* 159 */     int maxX = Arrays.stream(this.xPoints).max().orElse(0);
/* 160 */     int maxY = Arrays.stream(this.yPoints).max().orElse(0);
/* 161 */     return new Rectangle(minX, minY, maxX - minX, maxY - minY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getRandomPoint() {
/* 166 */     Rectangle bounds = getBounds();
/*     */     
/*     */     while (true) {
/* 169 */       int randomX = bounds.x + Utils.random(bounds.width);
/* 170 */       int randomY = bounds.y + Utils.random(bounds.height);
/*     */       
/* 172 */       Point randomPoint = new Point(randomX, randomY);
/*     */       
/* 174 */       if (contains(randomPoint.x, randomPoint.y)) {
/* 175 */         return randomPoint;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Polygon getResized(double factor) {
/* 182 */     Point center = getCenter();
/* 183 */     int[] resizedX = new int[this.numVertices];
/* 184 */     int[] resizedY = new int[this.numVertices];
/*     */     
/* 186 */     for (int i = 0; i < this.numVertices; i++) {
/* 187 */       resizedX[i] = (int)(center.x + (this.xPoints[i] - center.x) * factor);
/* 188 */       resizedY[i] = (int)(center.y + (this.yPoints[i] - center.y) * factor);
/*     */     } 
/*     */     
/* 191 */     return new Polygon(resizedX, resizedY);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 196 */     StringBuilder sb = new StringBuilder("Polygon{");
/* 197 */     for (int i = 0; i < this.numVertices; i++) {
/* 198 */       sb.append("(").append(this.xPoints[i]).append(", ").append(this.yPoints[i]).append(")");
/* 199 */       if (i < this.numVertices - 1) sb.append(", "); 
/*     */     } 
/* 201 */     sb.append("}");
/* 202 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double area() {
/* 208 */     double area = 0.0D;
/* 209 */     int n = this.xPoints.length;
/*     */     
/* 211 */     for (int i = 0; i < n; i++) {
/* 212 */       int currentX = this.xPoints[i];
/* 213 */       int currentY = this.yPoints[i];
/* 214 */       int nextX = this.xPoints[(i + 1) % n];
/* 215 */       int nextY = this.yPoints[(i + 1) % n];
/* 216 */       area += (currentX * nextY - currentY * nextX);
/*     */     } 
/*     */     
/* 219 */     return Math.abs(area) / 2.0D;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\shape\Polygon.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */