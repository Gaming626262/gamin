package com.osmb.api.shape;

import java.awt.Point;

public interface Shape {
  boolean contains(int paramInt1, int paramInt2);
  
  boolean contains(Point paramPoint);
  
  Rectangle getBounds();
  
  Point getRandomPoint();
  
  Point getCenter();
  
  Shape getResized(double paramDouble);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\shape\Shape.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */