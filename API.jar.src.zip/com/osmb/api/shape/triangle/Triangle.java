/*     */ package com.osmb.api.shape.triangle;
/*     */ 
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Triangle
/*     */   implements Shape
/*     */ {
/*     */   private final Point p1;
/*     */   private final Point p2;
/*     */   private final Point p3;
/*     */   
/*     */   public Triangle(Point p1, Point p2, Point p3) {
/*  17 */     this.p1 = p1;
/*  18 */     this.p2 = p2;
/*  19 */     this.p3 = p3;
/*     */   }
/*     */   
/*     */   public int[] getXPoints() {
/*  23 */     return new int[] { this.p1.x, this.p2.x, this.p3.x };
/*     */   }
/*     */   
/*     */   public int[] getYPoints() {
/*  27 */     return new int[] { this.p1.y, this.p2.y, this.p3.y };
/*     */   }
/*     */ 
/*     */   
/*     */   private double area(Point p1, Point p2, Point p3) {
/*  32 */     return Math.abs((p1.x * (p2.y - p3.y) + p2.x * (p3.y - p1.y) + p3.x * (p1.y - p2.y)) / 2.0D);
/*     */   }
/*     */   
/*     */   public boolean contains(int x, int y) {
/*  36 */     Point p = new Point(x, y);
/*     */ 
/*     */     
/*  39 */     double A = area(this.p1, this.p2, this.p3);
/*     */ 
/*     */     
/*  42 */     double A1 = area(p, this.p2, this.p3);
/*     */ 
/*     */     
/*  45 */     double A2 = area(this.p1, p, this.p3);
/*     */ 
/*     */     
/*  48 */     double A3 = area(this.p1, this.p2, p);
/*     */ 
/*     */     
/*  51 */     return (A == A1 + A2 + A3);
/*     */   }
/*     */   
/*     */   public Point[] getPoints() {
/*  55 */     return new Point[] { this.p1, this.p2, this.p3 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Point point) {
/*  60 */     return contains(point.x, point.y);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/*  65 */     int minX = Math.min(this.p1.x, Math.min(this.p2.x, this.p3.x));
/*  66 */     int minY = Math.min(this.p1.y, Math.min(this.p2.y, this.p3.y));
/*  67 */     int maxX = Math.max(this.p1.x, Math.max(this.p2.x, this.p3.x));
/*  68 */     int maxY = Math.max(this.p1.y, Math.max(this.p2.y, this.p3.y));
/*     */     
/*  70 */     return new Rectangle(minX, minY, maxX - minX, maxY - minY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getRandomPoint() {
/*  75 */     double r1 = Math.random();
/*  76 */     double r2 = Math.random();
/*     */     
/*  78 */     double x = (1.0D - Math.sqrt(r1)) * this.p1.x + Math.sqrt(r1) * (1.0D - r2) * this.p2.x + Math.sqrt(r1) * r2 * this.p3.x;
/*  79 */     double y = (1.0D - Math.sqrt(r1)) * this.p1.y + Math.sqrt(r1) * (1.0D - r2) * this.p2.y + Math.sqrt(r1) * r2 * this.p3.y;
/*     */     
/*  81 */     return new Point((int)x, (int)y);
/*     */   }
/*     */ 
/*     */   
/*     */   public Point getCenter() {
/*  86 */     int centerX = (this.p1.x + this.p2.x + this.p3.x) / 3;
/*  87 */     int centerY = (this.p1.y + this.p2.y + this.p3.y) / 3;
/*     */     
/*  89 */     return new Point(centerX, centerY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Triangle getResized(double factor) {
/*  94 */     Point center = getCenter();
/*     */     
/*  96 */     int newP1X = (int)(center.x + factor * (this.p1.x - center.x));
/*  97 */     int newP1Y = (int)(center.y + factor * (this.p1.y - center.y));
/*     */     
/*  99 */     int newP2X = (int)(center.x + factor * (this.p2.x - center.x));
/* 100 */     int newP2Y = (int)(center.y + factor * (this.p2.y - center.y));
/*     */     
/* 102 */     int newP3X = (int)(center.x + factor * (this.p3.x - center.x));
/* 103 */     int newP3Y = (int)(center.y + factor * (this.p3.y - center.y));
/*     */     
/* 105 */     Point newP1 = new Point(newP1X, newP1Y);
/* 106 */     Point newP2 = new Point(newP2X, newP2Y);
/* 107 */     Point newP3 = new Point(newP3X, newP3Y);
/*     */     
/* 109 */     return new Triangle(newP1, newP2, newP3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\shape\triangle\Triangle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */