/*    */ package com.osmb.api.shape;
/*    */ 
/*    */ import com.osmb.api.utils.Utils;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ public class Line
/*    */ {
/*    */   private final Point start;
/*    */   private final Point end;
/*    */   
/*    */   public Line(Point start, Point end) {
/* 13 */     this.start = start;
/* 14 */     this.end = end;
/*    */   }
/*    */   
/*    */   public Point getStart() {
/* 18 */     return this.start;
/*    */   }
/*    */   
/*    */   public Point getEnd() {
/* 22 */     return this.end;
/*    */   }
/*    */   
/*    */   public Point getRandomPoint() {
/* 26 */     return new Point(Utils.random(this.start.x, this.end.x), Utils.random(this.start.y, this.end.y));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\shape\Line.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */