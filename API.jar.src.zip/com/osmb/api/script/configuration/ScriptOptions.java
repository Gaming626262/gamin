/*    */ package com.osmb.api.script.configuration;
/*    */ 
/*    */ import com.osmb.api.trackers.experiencetracker.Skill;
/*    */ import com.osmb.api.trackers.experiencetracker.XPTracker;
/*    */ import com.osmb.api.visual.image.ImageImport;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ public interface ScriptOptions
/*    */ {
/*    */   default boolean canBreak() {
/* 13 */     return true;
/*    */   }
/*    */   
/*    */   default boolean canHopWorlds() {
/* 17 */     return true;
/*    */   }
/*    */   
/*    */   default boolean promptBankTabDialogue() {
/* 21 */     return false;
/*    */   }
/*    */   
/*    */   default int onRelog() {
/* 25 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   default void onStart() {}
/*    */ 
/*    */ 
/*    */   
/*    */   default void importImages(Set<ImageImport> imageImportSet) {}
/*    */ 
/*    */   
/*    */   default void skillsToTrack(Map<Skill, XPTracker> skillsToTrack) {}
/*    */ 
/*    */   
/*    */   default int[] regionsToPrioritise() {
/* 41 */     return new int[0];
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\configuration\ScriptOptions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */