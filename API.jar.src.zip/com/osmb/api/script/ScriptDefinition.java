package com.osmb.api.script;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface ScriptDefinition {
  String name();
  
  String author();
  
  double version();
  
  String description();
  
  SkillCategory skillCategory();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\ScriptDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */