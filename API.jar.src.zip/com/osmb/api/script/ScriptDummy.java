/*    */ package com.osmb.api.script;
/*    */ 
/*    */ 
/*    */ @ScriptDefinition(name = "", author = "", version = 0.0D, description = "", skillCategory = SkillCategory.AGILITY)
/*    */ class ScriptDummy
/*    */   extends Script
/*    */ {
/*    */   public ScriptDummy(Object scriptCore) {
/*  9 */     super(scriptCore);
/*    */   }
/*    */ 
/*    */   
/*    */   public int poll() {
/* 14 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\ScriptDummy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */