/*   */ package com.osmb.api.script.task.exception;
/*   */ 
/*   */ public class HaltScriptException extends TaskInterruptedException {
/*   */   public HaltScriptException() {
/* 5 */     super("Script stopped/paused.");
/*   */   }
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\task\exception\HaltScriptException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */