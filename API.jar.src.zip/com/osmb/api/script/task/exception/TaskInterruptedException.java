/*    */ package com.osmb.api.script.task.exception;
/*    */ 
/*    */ public class TaskInterruptedException extends RuntimeException {
/*    */   private final String reason;
/*    */   
/*    */   public TaskInterruptedException(String reason) {
/*  7 */     super("Task interrupted: " + reason);
/*  8 */     this.reason = reason;
/*    */   }
/*    */   
/*    */   public String getReason() {
/* 12 */     return this.reason;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\task\exception\TaskInterruptedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */