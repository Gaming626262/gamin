/*   */ package com.osmb.api.script.task.exception;
/*   */ 
/*   */ public class PriorityTaskException
/*   */   extends TaskInterruptedException {
/*   */   public PriorityTaskException() {
/* 6 */     super("Due to execute priority task");
/*   */   }
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\task\exception\PriorityTaskException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */