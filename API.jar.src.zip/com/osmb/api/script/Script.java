/*     */ package com.osmb.api.script;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.input.Finger;
/*     */ import com.osmb.api.input.Keyboard;
/*     */ import com.osmb.api.item.ItemManager;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.location.position.types.WorldPosition;
/*     */ import com.osmb.api.scene.ObjectManager;
/*     */ import com.osmb.api.scene.SceneManager;
/*     */ import com.osmb.api.screen.Screen;
/*     */ import com.osmb.api.script.configuration.ScriptOptions;
/*     */ import com.osmb.api.ui.SpriteManager;
/*     */ import com.osmb.api.ui.WidgetManager;
/*     */ import com.osmb.api.utils.AppManager;
/*     */ import com.osmb.api.utils.StageController;
/*     */ import com.osmb.api.utils.Utils;
/*     */ import com.osmb.api.visual.ImageAnalyzer;
/*     */ import com.osmb.api.visual.PixelAnalyzer;
/*     */ import com.osmb.api.visual.drawing.SceneProjector;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import com.osmb.api.visual.ocr.OCR;
/*     */ import com.osmb.api.walker.Walker;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.function.BooleanSupplier;
/*     */ 
/*     */ 
/*     */ public abstract class Script
/*     */   implements ScriptCore, ScriptOptions
/*     */ {
/*     */   private final ScriptCore scriptCore;
/*  33 */   private final Map<String, SearchableImage> importedImages = new HashMap<>();
/*     */   protected long startTime;
/*     */   
/*     */   public Script(Object scriptCore) {
/*  37 */     this.scriptCore = (ScriptCore)scriptCore;
/*  38 */     this.startTime = System.currentTimeMillis();
/*  39 */     if (!getClass().isAnnotationPresent((Class)ScriptDefinition.class)) {
/*  40 */       throw new IllegalStateException("The class " + getClass().getName() + " must be annotated with @" + ScriptDefinition.class.getSimpleName());
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, SearchableImage> getImportedImages() {
/*  45 */     return this.importedImages;
/*     */   }
/*     */   
/*     */   public abstract int poll();
/*     */   
/*     */   public long getStartTime() {
/*  51 */     return this.startTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDueToAFK() {
/*  56 */     return this.scriptCore.isDueToAFK();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDueToBreak() {
/*  61 */     return this.scriptCore.isDueToBreak();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDueToHop() {
/*  66 */     return this.scriptCore.isDueToHop();
/*     */   }
/*     */ 
/*     */   
/*     */   public SceneManager getSceneManager() {
/*  71 */     return this.scriptCore.getSceneManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public Finger getFinger() {
/*  76 */     return this.scriptCore.getFinger();
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String message) {
/*  81 */     this.scriptCore.log(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public Screen getScreen() {
/*  86 */     return this.scriptCore.getScreen();
/*     */   }
/*     */ 
/*     */   
/*     */   public LocalPosition getLocalPosition() {
/*  91 */     return this.scriptCore.getLocalPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public WidgetManager getWidgetManager() {
/*  96 */     return this.scriptCore.getWidgetManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public SpriteManager getSpriteManager() {
/* 101 */     return this.scriptCore.getSpriteManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectManager getObjectManager() {
/* 106 */     return this.scriptCore.getObjectManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public OCR getOCR() {
/* 111 */     return this.scriptCore.getOCR();
/*     */   }
/*     */ 
/*     */   
/*     */   public ImageAnalyzer getImageAnalyzer() {
/* 116 */     return this.scriptCore.getImageAnalyzer();
/*     */   }
/*     */ 
/*     */   
/*     */   public AppManager getAppManager() {
/* 121 */     return this.scriptCore.getAppManager();
/*     */   }
/*     */ 
/*     */   
/*     */   public Keyboard getKeyboard() {
/* 126 */     return this.scriptCore.getKeyboard();
/*     */   }
/*     */ 
/*     */   
/*     */   public PixelAnalyzer getPixelAnalyzer() {
/* 131 */     return this.scriptCore.getPixelAnalyzer();
/*     */   }
/*     */ 
/*     */   
/*     */   public SceneProjector getSceneProjector() {
/* 136 */     return this.scriptCore.getSceneProjector();
/*     */   }
/*     */ 
/*     */   
/*     */   public StageController getStageController() {
/* 141 */     return this.scriptCore.getStageController();
/*     */   }
/*     */ 
/*     */   
/*     */   public Walker getWalker() {
/* 146 */     return this.scriptCore.getWalker();
/*     */   }
/*     */ 
/*     */   
/*     */   public Utils getUtils() {
/* 151 */     return this.scriptCore.getUtils();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPause(boolean pause) {
/* 156 */     this.scriptCore.setPause(pause);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Class tag, String msg) {
/* 161 */     this.scriptCore.log(tag, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(String tag, String message) {
/* 166 */     this.scriptCore.log(tag, message);
/*     */   }
/*     */ 
/*     */   
/*     */   public WorldPosition getWorldPosition() {
/* 171 */     return this.scriptCore.getWorldPosition();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitTask(BooleanSupplier task, int timeout) {
/* 176 */     return this.scriptCore.submitTask(task, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitHumanTask(BooleanSupplier condition, int timeout, boolean updateScene, boolean ignoreGamestate, boolean ignoreTasks) {
/* 181 */     return this.scriptCore.submitHumanTask(condition, timeout, updateScene, ignoreGamestate, ignoreTasks);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitTask(BooleanSupplier condition, int timeout, boolean updateScene) {
/* 186 */     return this.scriptCore.submitTask(condition, timeout, updateScene);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitTask(BooleanSupplier condition, int timeout, boolean updateScene, boolean ignoreGamestate) {
/* 191 */     return this.scriptCore.submitTask(condition, timeout, updateScene, ignoreGamestate);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitHumanTask(BooleanSupplier condition, int timeout) {
/* 196 */     return this.scriptCore.submitHumanTask(condition, timeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean submitTask(BooleanSupplier condition, int timeout, boolean updateScene, boolean ignoreGamestate, boolean ignoreTasks) {
/* 201 */     return this.scriptCore.submitTask(condition, timeout, updateScene, ignoreGamestate, ignoreTasks);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean stopped() {
/* 206 */     return this.scriptCore.stopped();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean paused() {
/* 211 */     return this.scriptCore.paused();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() {
/* 216 */     this.scriptCore.stop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void sleep(int millis) {
/* 221 */     this.scriptCore.sleep(millis);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sleep(long millis) {
/* 226 */     this.scriptCore.sleep(millis);
/*     */   }
/*     */ 
/*     */   
/*     */   public int random(int num) {
/* 231 */     return this.scriptCore.random(num);
/*     */   }
/*     */ 
/*     */   
/*     */   public int random(int low, int high) {
/* 236 */     return this.scriptCore.random(low, high);
/*     */   }
/*     */ 
/*     */   
/*     */   public int random(long low, long high) {
/* 241 */     return this.scriptCore.random(low, high);
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemManager getItemManager() {
/* 246 */     return this.scriptCore.getItemManager();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\Script.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */