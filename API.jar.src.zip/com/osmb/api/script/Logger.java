package com.osmb.api.script;

public interface Logger {
  void log(String paramString);
  
  void log(String paramString1, String paramString2);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\Logger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */