/*    */ package com.osmb.api.script;
/*    */ 
/*    */ public enum SkillCategory
/*    */ {
/*  5 */   AGILITY("Agility", "agility.png", 1),
/*  6 */   COMBAT("Combat", "combat.png", 2),
/*  7 */   MAGIC("Magic", "magic.png", 17),
/*  8 */   PRAYER("Prayer", "prayer.png", 19),
/*  9 */   CONSTRUCTION("Construction", "construction.png", 15),
/* 10 */   COOKING("Cooking", "cooking.png", 3),
/* 11 */   CRAFTING("Crafting", "crafting.png", 4),
/* 12 */   FARMING("Farming", "farming.png", 16),
/* 13 */   FIREMAKING("Firemaking", "firemaking.png", 5),
/* 14 */   FISHING("Fishing", "fishing.png", 6),
/* 15 */   FLETCHING("Fletching", "fletching.png", 7),
/* 16 */   HUNTER("Hunter", "hunter.png", 18),
/* 17 */   HERBLORE("Herblore", "herblore.png", 8),
/* 18 */   MINING("Mining", "mining.png", 9),
/* 19 */   RUNECRAFTING("Runecrafting", "runecrafting.png", 11),
/* 20 */   SMITHING("Smithing", "smithing.png", 12),
/* 21 */   THIEVING("Thieving", "thieving.png", 13),
/* 22 */   WOODCUTTING("Woodcutting", "woodcutting.png", 14),
/* 23 */   OTHER("Other", "other.png", 10);
/*    */   
/*    */   private final String fileName;
/*    */   private final String name;
/*    */   private final int id;
/*    */   
/*    */   SkillCategory(String name, String fileName, int categoryId) {
/* 30 */     this.fileName = fileName;
/* 31 */     this.name = name;
/* 32 */     this.id = categoryId;
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 36 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 40 */     return this.name;
/*    */   }
/*    */   
/*    */   public static SkillCategory getById(int id) {
/* 44 */     for (SkillCategory c : values()) {
/* 45 */       if (c.id == id)
/* 46 */         return c; 
/*    */     } 
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public static String[] getNames() {
/* 52 */     SkillCategory[] categories = values();
/* 53 */     String[] names = new String[categories.length];
/* 54 */     for (int i = 0; i < categories.length; i++) {
/* 55 */       names[i] = (categories[i]).name;
/*    */     }
/* 57 */     return names;
/*    */   }
/*    */   
/*    */   public static SkillCategory getScriptTypeForString(String categoryName) {
/* 61 */     for (SkillCategory s : values()) {
/* 62 */       if (s.getName().equals(categoryName))
/* 63 */         return s; 
/*    */     } 
/* 65 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\script\SkillCategory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */