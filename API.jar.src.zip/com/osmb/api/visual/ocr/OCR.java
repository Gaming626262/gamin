package com.osmb.api.visual.ocr;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.visual.image.Image;
import com.osmb.api.visual.ocr.fonts.Font;

public interface OCR {
  String getText(Font paramFont, Rectangle paramRectangle, int... paramVarArgs);
  
  String getText(Font paramFont, int[][] paramArrayOfint, boolean paramBoolean);
  
  String getText(Font paramFont, Image paramImage, Rectangle paramRectangle, int... paramVarArgs);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ocr\OCR.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */