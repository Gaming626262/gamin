/*     */ package com.osmb.api.visual.ocr.fonts;
/*     */ 
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class RSFont
/*     */ {
/*     */   private final List<RSFontChar> characters;
/*     */   
/*     */   public RSFont(SpriteDefinition[] spriteDefinitions) {
/*  14 */     List<RSFontChar> characters = new ArrayList<>();
/*  15 */     for (SpriteDefinition spriteDefinition : spriteDefinitions) {
/*  16 */       if (spriteDefinition.pixels != null && spriteDefinition.pixels.length != 0) {
/*  17 */         int id = spriteDefinition.frame;
/*  18 */         Character c = getChar(id);
/*  19 */         if (c != null)
/*     */         
/*     */         { 
/*  22 */           int offsetY = spriteDefinition.offsetY;
/*  23 */           int height = spriteDefinition.height + offsetY;
/*  24 */           int[][] columns = new int[spriteDefinition.width][height];
/*  25 */           for (int y = 0; y < height; y++) {
/*  26 */             if (y >= offsetY)
/*     */             {
/*     */               
/*  29 */               for (int x = 0; x < spriteDefinition.width; x++) {
/*  30 */                 if (spriteDefinition.pixels[x + (y - offsetY) * spriteDefinition.width] != 16711935)
/*  31 */                   columns[x][y] = 1; 
/*     */               } 
/*     */             }
/*     */           } 
/*  35 */           RSFontChar rsChar = new RSFontChar(c.charValue(), columns);
/*  36 */           characters.add(rsChar); } 
/*     */       } 
/*  38 */     }  this.characters = Collections.unmodifiableList(characters);
/*     */   }
/*     */   
/*     */   public List<RSFontChar> getCharacters() {
/*  42 */     return this.characters;
/*     */   }
/*     */   
/*     */   private Character getChar(int id) {
/*  46 */     switch (id) {
/*     */       case 33:
/*  48 */         return Character.valueOf('!');
/*     */       case 34:
/*  50 */         return Character.valueOf('"');
/*     */       case 35:
/*  52 */         return Character.valueOf('#');
/*     */       case 36:
/*  54 */         return Character.valueOf('$');
/*     */       case 37:
/*  56 */         return Character.valueOf('%');
/*     */       case 38:
/*  58 */         return Character.valueOf('&');
/*     */       case 39:
/*  60 */         return Character.valueOf('\'');
/*     */       case 40:
/*  62 */         return Character.valueOf('(');
/*     */       case 41:
/*  64 */         return Character.valueOf(')');
/*     */       case 42:
/*  66 */         return Character.valueOf('*');
/*     */       case 43:
/*  68 */         return Character.valueOf('+');
/*     */       case 44:
/*  70 */         return Character.valueOf(',');
/*     */       case 45:
/*  72 */         return Character.valueOf('-');
/*     */       case 46:
/*  74 */         return Character.valueOf('.');
/*     */       case 47:
/*  76 */         return Character.valueOf('/');
/*     */       case 48:
/*  78 */         return Character.valueOf('0');
/*     */       case 49:
/*  80 */         return Character.valueOf('1');
/*     */       case 50:
/*  82 */         return Character.valueOf('2');
/*     */       case 51:
/*  84 */         return Character.valueOf('3');
/*     */       case 52:
/*  86 */         return Character.valueOf('4');
/*     */       case 53:
/*  88 */         return Character.valueOf('5');
/*     */       case 54:
/*  90 */         return Character.valueOf('6');
/*     */       case 55:
/*  92 */         return Character.valueOf('7');
/*     */       case 56:
/*  94 */         return Character.valueOf('8');
/*     */       case 57:
/*  96 */         return Character.valueOf('9');
/*     */       case 58:
/*  98 */         return Character.valueOf(':');
/*     */       case 59:
/* 100 */         return Character.valueOf(';');
/*     */       case 60:
/* 102 */         return Character.valueOf('<');
/*     */       case 61:
/* 104 */         return Character.valueOf('=');
/*     */       case 62:
/* 106 */         return Character.valueOf('>');
/*     */       case 63:
/* 108 */         return Character.valueOf('?');
/*     */       case 64:
/* 110 */         return Character.valueOf('@');
/*     */       case 65:
/* 112 */         return Character.valueOf('A');
/*     */       case 66:
/* 114 */         return Character.valueOf('B');
/*     */       case 67:
/* 116 */         return Character.valueOf('C');
/*     */       case 68:
/* 118 */         return Character.valueOf('D');
/*     */       case 69:
/* 120 */         return Character.valueOf('E');
/*     */       case 70:
/* 122 */         return Character.valueOf('F');
/*     */       case 71:
/* 124 */         return Character.valueOf('G');
/*     */       case 72:
/* 126 */         return Character.valueOf('H');
/*     */       case 73:
/* 128 */         return Character.valueOf('I');
/*     */       case 74:
/* 130 */         return Character.valueOf('J');
/*     */       case 75:
/* 132 */         return Character.valueOf('K');
/*     */       case 76:
/* 134 */         return Character.valueOf('L');
/*     */       case 77:
/* 136 */         return Character.valueOf('M');
/*     */       case 78:
/* 138 */         return Character.valueOf('N');
/*     */       case 79:
/* 140 */         return Character.valueOf('O');
/*     */       case 80:
/* 142 */         return Character.valueOf('P');
/*     */       case 81:
/* 144 */         return Character.valueOf('Q');
/*     */       case 82:
/* 146 */         return Character.valueOf('R');
/*     */       case 83:
/* 148 */         return Character.valueOf('S');
/*     */       case 84:
/* 150 */         return Character.valueOf('T');
/*     */       case 85:
/* 152 */         return Character.valueOf('U');
/*     */       case 86:
/* 154 */         return Character.valueOf('V');
/*     */       case 87:
/* 156 */         return Character.valueOf('W');
/*     */       case 88:
/* 158 */         return Character.valueOf('X');
/*     */       case 89:
/* 160 */         return Character.valueOf('Y');
/*     */       case 90:
/* 162 */         return Character.valueOf('Z');
/*     */       case 91:
/* 164 */         return Character.valueOf('[');
/*     */       case 92:
/* 166 */         return Character.valueOf('\\');
/*     */       case 93:
/* 168 */         return Character.valueOf(']');
/*     */       case 94:
/* 170 */         return Character.valueOf('^');
/*     */       case 95:
/* 172 */         return Character.valueOf('-');
/*     */       case 96:
/* 174 */         return Character.valueOf('‘');
/*     */       case 97:
/* 176 */         return Character.valueOf('a');
/*     */       case 98:
/* 178 */         return Character.valueOf('b');
/*     */       case 99:
/* 180 */         return Character.valueOf('c');
/*     */       case 100:
/* 182 */         return Character.valueOf('d');
/*     */       case 101:
/* 184 */         return Character.valueOf('e');
/*     */       case 102:
/* 186 */         return Character.valueOf('f');
/*     */       case 103:
/* 188 */         return Character.valueOf('g');
/*     */       case 104:
/* 190 */         return Character.valueOf('h');
/*     */       case 105:
/* 192 */         return Character.valueOf('i');
/*     */       case 106:
/* 194 */         return Character.valueOf('j');
/*     */       case 107:
/* 196 */         return Character.valueOf('k');
/*     */       case 108:
/* 198 */         return Character.valueOf('l');
/*     */       case 109:
/* 200 */         return Character.valueOf('m');
/*     */       case 110:
/* 202 */         return Character.valueOf('n');
/*     */       case 111:
/* 204 */         return Character.valueOf('o');
/*     */       case 112:
/* 206 */         return Character.valueOf('p');
/*     */       case 113:
/* 208 */         return Character.valueOf('q');
/*     */       case 114:
/* 210 */         return Character.valueOf('r');
/*     */       case 115:
/* 212 */         return Character.valueOf('s');
/*     */       case 116:
/* 214 */         return Character.valueOf('t');
/*     */       case 117:
/* 216 */         return Character.valueOf('u');
/*     */       case 118:
/* 218 */         return Character.valueOf('v');
/*     */       case 119:
/* 220 */         return Character.valueOf('w');
/*     */       case 120:
/* 222 */         return Character.valueOf('x');
/*     */       case 121:
/* 224 */         return Character.valueOf('y');
/*     */       case 122:
/* 226 */         return Character.valueOf('z');
/*     */       case 123:
/* 228 */         return Character.valueOf('{');
/*     */       case 124:
/* 230 */         return Character.valueOf('|');
/*     */       case 125:
/* 232 */         return Character.valueOf('}');
/*     */       case 126:
/* 234 */         return Character.valueOf('~');
/*     */       case 128:
/* 236 */         return Character.valueOf('€');
/*     */     } 
/* 238 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ocr\fonts\RSFont.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */