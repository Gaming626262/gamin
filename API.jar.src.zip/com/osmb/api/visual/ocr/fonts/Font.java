/*    */ package com.osmb.api.visual.ocr.fonts;
/*    */ 
/*    */ import com.osmb.api.definition.SpriteDefinition;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ public enum Font
/*    */ {
/* 10 */   STANDARD_FONT(495),
/* 11 */   STANDARD_FONT_BOLD(496),
/* 12 */   FANCY_STANDARD_FONT(497),
/* 13 */   SMALL_FONT(494),
/* 14 */   FANCY_BOLD_FONT_645(645),
/* 15 */   FANCY_BOLD_BIG_FONT_646(646),
/* 16 */   FONT_764(764),
/* 17 */   FONT_1442(1442),
/* 18 */   FONT_1443(1443),
/* 19 */   FONT_1444(1444),
/* 20 */   FONT_1445(1445),
/* 21 */   FONT_1446(1446),
/* 22 */   FONT_1447(1447),
/* 23 */   FONT_5607(5607),
/* 24 */   FONT_5608(5608),
/* 25 */   FONT_5675(5675),
/* 26 */   FONT_5676(5676); private static final Map<Font, RSFont> FONTS; static {
/* 27 */     FONTS = new HashMap<>();
/*    */   }
/*    */   private final int archiveID;
/*    */   Font(int archiveID) {
/* 31 */     this.archiveID = archiveID;
/*    */   }
/*    */   
/*    */   public static RSFont get(Font font) {
/* 35 */     return FONTS.get(font);
/*    */   }
/*    */   
/*    */   public static void init(Loader loader) {
/* 39 */     for (Font font : values()) {
/* 40 */       SpriteDefinition[] spriteDefinitions = loader.get(font.archiveID);
/* 41 */       FONTS.put(font, new RSFont(spriteDefinitions));
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getArchiveID() {
/* 46 */     return this.archiveID;
/*    */   }
/*    */   
/*    */   public static interface Loader {
/*    */     SpriteDefinition[] get(int param1Int);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ocr\fonts\Font.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */