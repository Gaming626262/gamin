/*    */ package com.osmb.api.visual.ocr.fonts;
/*    */ 
/*    */ public class RSFontChar
/*    */ {
/*    */   private final int[][] flags;
/*    */   private final char character;
/*    */   private final int totalPixels;
/*    */   
/*    */   public RSFontChar(char character, int[][] flags) {
/* 10 */     this.flags = flags;
/* 11 */     this.character = character;
/* 12 */     int pixelCount = 0;
/* 13 */     for (int columnIndex = 0; columnIndex < flags.length; columnIndex++) {
/* 14 */       int[] column = flags[columnIndex];
/* 15 */       for (int rowIndex = 0; rowIndex < column.length; rowIndex++) {
/* 16 */         if (column[rowIndex] == 1) {
/* 17 */           pixelCount++;
/*    */         }
/*    */       } 
/*    */     } 
/* 21 */     this.totalPixels = pixelCount;
/*    */   }
/*    */   
/*    */   public int getTotalPixels() {
/* 25 */     return this.totalPixels;
/*    */   }
/*    */   
/*    */   public int[][] getFlags() {
/* 29 */     return this.flags;
/*    */   }
/*    */   
/*    */   public char getCharacter() {
/* 33 */     return this.character;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 37 */     StringBuilder sb = new StringBuilder();
/*    */ 
/*    */     
/* 40 */     for (int rowIndex = 0; rowIndex < (this.flags[0]).length; rowIndex++) {
/*    */       
/* 42 */       for (int columnIndex = 0; columnIndex < this.flags.length; columnIndex++)
/*    */       {
/* 44 */         sb.append((this.flags[columnIndex][rowIndex] == 1) ? 49 : 48);
/*    */       }
/*    */       
/* 47 */       sb.append('\n');
/*    */     } 
/*    */     
/* 50 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ocr\fonts\RSFontChar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */