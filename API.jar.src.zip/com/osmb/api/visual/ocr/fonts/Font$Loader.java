package com.osmb.api.visual.ocr.fonts;

import com.osmb.api.definition.SpriteDefinition;

public interface Loader {
  SpriteDefinition[] get(int paramInt);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ocr\fonts\Font$Loader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */