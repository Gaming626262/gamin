package com.osmb.api.visual;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.visual.image.Image;
import com.osmb.api.visual.image.ImageSearchResult;
import com.osmb.api.visual.image.SearchableImage;
import java.awt.Point;
import java.util.List;

public interface ImageAnalyzer {
  List<ImageSearchResult> findLocationsParallel(Image paramImage, SearchableImage paramSearchableImage);
  
  List<ImageSearchResult> findLocations(Image paramImage, SearchableImage... paramVarArgs);
  
  List<ImageSearchResult> findLocations(SearchableImage... paramVarArgs);
  
  List<ImageSearchResult> findLocations(List<SearchableImage> paramList);
  
  List<ImageSearchResult> findLocations(Rectangle paramRectangle, SearchableImage... paramVarArgs);
  
  List<Rectangle> findContainers(Rectangle paramRectangle, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  List<ImageSearchResult> findLocations(Image paramImage, Rectangle paramRectangle, SearchableImage... paramVarArgs);
  
  ImageSearchResult findLocation(SearchableImage... paramVarArgs);
  
  ImageSearchResult findLocation(List<SearchableImage> paramList);
  
  ImageSearchResult findLocation(Rectangle paramRectangle, SearchableImage... paramVarArgs);
  
  boolean preCheck(Image paramImage, int paramInt1, int paramInt2, SearchableImage paramSearchableImage);
  
  ImageSearchResult isSubImageAt(Point paramPoint, SearchableImage paramSearchableImage);
  
  ImageSearchResult isSubImageAt(int paramInt1, int paramInt2, SearchableImage paramSearchableImage);
  
  ImageSearchResult isSubImageAt(Image paramImage, SearchableImage paramSearchableImage, int paramInt1, int paramInt2);
  
  ImageSearchResult isSubImageAt(Image paramImage, SearchableImage paramSearchableImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ImageAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */