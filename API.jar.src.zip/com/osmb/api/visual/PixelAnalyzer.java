package com.osmb.api.visual;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.shape.Shape;
import com.osmb.api.visual.image.Image;
import java.awt.Point;
import java.util.List;

public interface PixelAnalyzer {
  Point findPixel(Shape paramShape, SearchablePixel... paramVarArgs);
  
  Point findPixel(Image paramImage, Shape paramShape, SearchablePixel... paramVarArgs);
  
  List<Point> findPixels(Shape paramShape, SearchablePixel... paramVarArgs);
  
  List<Point> findPixels(Image paramImage, Shape paramShape, SearchablePixel... paramVarArgs);
  
  int getPixelAt(int paramInt1, int paramInt2);
  
  boolean isPixelAt(int paramInt1, int paramInt2, SearchablePixel... paramVarArgs);
  
  boolean isPixelAt(int paramInt1, int paramInt2, SearchablePixel paramSearchablePixel);
  
  List<Point> findPixelsOnGameScreen(Shape paramShape, SearchablePixel... paramVarArgs);
  
  List<List<Point>> findClusterEntities(ClusterEntity paramClusterEntity);
  
  List<List<Point>> findClusterEntities(Shape paramShape, ClusterEntity paramClusterEntity);
  
  Point getClusterCenter(List<Point> paramList);
  
  List<List<Point>> groupPixels(List<Point> paramList, int paramInt1, int paramInt2);
  
  boolean isAnimating(int paramInt);
  
  boolean isAnimating(int paramInt, Shape paramShape);
  
  boolean isAnimating(double paramDouble, Shape paramShape);
  
  Rectangle getClusterBounds(List<Point> paramList);
  
  List<Rectangle> findRespawnCircles(Image paramImage);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\PixelAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */