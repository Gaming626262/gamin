/*     */ package com.osmb.api.visual.color;
/*     */ 
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorUtils
/*     */ {
/*     */   public static final int ORANGE_UI_TEXT = -26593;
/*     */   public static final int TRANSPARENT_PIXEL = 16711935;
/*     */   public static final int DIALOGUE_COLOR = -5071493;
/*     */   public static final int BLACK_ITEM_BORDER_COLOR = -16777216;
/*     */   public static final int BLACK_TEXT_COLOR = -16777215;
/*     */   public static final int YELLOW_TEXT_COLOR = -256;
/*     */   public static final int COMPONENT_TITLE_COLOR = -26593;
/*     */   
/*     */   public static void setAlpha(int[] pixels, int alpha) {
/*  28 */     for (int i = 0; i < pixels.length; i++) {
/*  29 */       pixels[i] = pixels[i] & (alpha << 24 | pixels[i] & 0xFFFFFF);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] getRGBDifferences(int rgb0, int rgb1) {
/*  42 */     int r0 = rgb0 >> 16 & 0xFF;
/*  43 */     int g0 = rgb0 >> 8 & 0xFF;
/*  44 */     int b0 = rgb0 & 0xFF;
/*     */     
/*  46 */     int r1 = rgb1 >> 16 & 0xFF;
/*  47 */     int g1 = rgb1 >> 8 & 0xFF;
/*  48 */     int b1 = rgb1 & 0xFF;
/*     */ 
/*     */     
/*  51 */     int dr = Math.abs(r0 - r1);
/*  52 */     int dg = Math.abs(g0 - g1);
/*  53 */     int db = Math.abs(b0 - b1);
/*  54 */     return new int[] { dr, dg, db };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRGBinsideThreshold(ToleranceComparator toleranceComparator, int rgb0, int rgb1) {
/*  66 */     int[] diff = getRGBDifferences(rgb0, rgb1);
/*  67 */     return toleranceComparator.isWithinTolerance(diff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double[] getHSLDifferences(int rgb0, int rgb1) {
/*  79 */     rgb0 &= 0xFFFFFF;
/*  80 */     rgb1 &= 0xFFFFFF;
/*     */ 
/*     */     
/*  83 */     long hslValues0 = HSLPalette.rgbToHSLLookupTable[rgb0];
/*  84 */     long hslValues1 = HSLPalette.rgbToHSLLookupTable[rgb1];
/*     */     
/*  86 */     double[] hsl0 = HSLPalette.unpackHsl(hslValues0);
/*  87 */     double[] hsl1 = HSLPalette.unpackHsl(hslValues1);
/*     */ 
/*     */     
/*  90 */     double dh = Math.abs(hsl0[0] - hsl1[0]);
/*  91 */     if (dh > 180.0D) {
/*  92 */       dh = 360.0D - dh;
/*     */     }
/*     */     
/*  95 */     double ds = Math.abs(hsl0[1] - hsl1[1]);
/*  96 */     double dl = Math.abs(hsl0[2] - hsl1[2]);
/*     */     
/*  98 */     return new double[] { dh, ds, dl };
/*     */   }
/*     */   
/*     */   public static boolean isTransparent(int rgb) {
/* 102 */     return ((rgb & 0xFFFFFF) == 16711935 || rgb == -130818 || rgb == -65282 || rgb == 16646399 || rgb == -65025 || rgb == -130562);
/*     */   }
/*     */   
/*     */   public static boolean isHSLinsideThreshold(ToleranceComparator toleranceComparator, int rgb0, int rgb1) {
/* 106 */     double[] differences = getHSLDifferences(rgb0, rgb1);
/* 107 */     return toleranceComparator.isWithinTolerance(differences);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHSLInDistanceThreshold(int maxDistance, int rgb0, int rgb1) {
/* 113 */     rgb0 &= 0xFFFFFF;
/* 114 */     rgb1 &= 0xFFFFFF;
/*     */     
/* 116 */     double[] hsl0 = HSLPalette.unpackHsl(HSLPalette.rgbToHSLLookupTable[rgb0]);
/* 117 */     double[] hsl1 = HSLPalette.unpackHsl(HSLPalette.rgbToHSLLookupTable[rgb1]);
/*     */     
/* 119 */     double dist = calculateHSLDistance(hsl0, hsl1);
/*     */     
/* 121 */     return (dist <= maxDistance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateHSLDistance(double[] hslColor1, double[] hslColor2) {
/* 144 */     double hueDifference = Math.abs(hslColor1[0] - hslColor2[0]);
/* 145 */     double circularHueDifference = Math.min(hueDifference, 360.0D - hueDifference);
/*     */     
/* 147 */     double saturationDifference = hslColor1[1] - hslColor2[1];
/* 148 */     double lightnessDifference = hslColor1[2] - hslColor2[2];
/*     */     
/* 150 */     return Math.sqrt(circularHueDifference * circularHueDifference + saturationDifference * saturationDifference + lightnessDifference * lightnessDifference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double calculateHSLSquaredDistance(double[] hslColor1, double[] hslColor2) {
/* 172 */     double hueDifference = Math.abs(hslColor1[0] - hslColor2[0]);
/* 173 */     double circularHueDifference = Math.min(hueDifference, 360.0D - hueDifference);
/*     */     
/* 175 */     double saturationDifference = hslColor1[1] - hslColor2[1];
/* 176 */     double lightnessDifference = hslColor1[2] - hslColor2[2];
/*     */ 
/*     */     
/* 179 */     return circularHueDifference * circularHueDifference + saturationDifference * saturationDifference + lightnessDifference * lightnessDifference;
/*     */   }
/*     */   
/*     */   public static int removeAlphaChannel(int color) {
/* 183 */     return color & 0xFFFFFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\ColorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */