/*    */ package com.osmb.api.visual.color;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class Pixel {
/*    */   protected final int rgb;
/*    */   
/*    */   public Pixel(int rgb) {
/*  9 */     this.rgb = rgb;
/*    */   }
/*    */   
/*    */   public int getRgb() {
/* 13 */     return this.rgb;
/*    */   }
/*    */   
/*    */   public Color getColor() {
/* 17 */     return new Color(this.rgb);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\Pixel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */