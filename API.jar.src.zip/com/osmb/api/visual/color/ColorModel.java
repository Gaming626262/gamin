/*   */ package com.osmb.api.visual.color;
/*   */ 
/*   */ public enum ColorModel {
/* 4 */   RGB,
/* 5 */   HSL;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\ColorModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */