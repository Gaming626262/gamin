/*     */ package com.osmb.api.visual.color;
/*     */ 
/*     */ 
/*     */ public final class HSLPalette
/*     */ {
/*     */   public static final double MAX = 0.5D;
/*     */   public static final double HIGH = 0.6D;
/*     */   public static final double MID = 0.7D;
/*     */   public static final double LOW = 0.8D;
/*     */   public static final double MIN = 0.9D;
/*     */   public static final int MAX_RGB_VALUE = 255;
/*     */   public static final int LOOKUP_TABLE_SIZE = 16777216;
/*  13 */   public static long[] rgbToHSLLookupTable = new long[16777216];
/*     */   private static final double HUE_OFFSET = 0.0078125D;
/*     */   
/*     */   public static void initializeLookupTable() {
/*  17 */     for (int r = 0; r <= 255; r++) {
/*  18 */       for (int g = 0; g <= 255; g++) {
/*  19 */         for (int b = 0; b <= 255; b++) {
/*  20 */           int rgb = (r << 16) + (g << 8) + b;
/*     */           
/*  22 */           double[] hsl = rgbToHsl(rgb);
/*  23 */           long hslPacked = packHsl(hsl[0], hsl[1], hsl[2]);
/*  24 */           rgbToHSLLookupTable[rgb] = hslPacked;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private static final double SATURATION_OFFSET = 0.0625D;
/*     */   public static int[] create(double brightness) {
/*  31 */     int[] colorPalette = new int[65536];
/*  32 */     for (int i = 0; i < colorPalette.length; i++) {
/*  33 */       colorPalette[i] = HSLtoRGB((short)i, brightness);
/*     */     }
/*  35 */     return colorPalette;
/*     */   }
/*     */   private static int adjustForBrightness(int rgb, double brightness) {
/*  38 */     double r = (rgb >> 16) / 256.0D;
/*  39 */     double g = (rgb >> 8 & 0xFF) / 256.0D;
/*  40 */     double b = (rgb & 0xFF) / 256.0D;
/*     */     
/*  42 */     r = Math.pow(r, brightness);
/*  43 */     g = Math.pow(g, brightness);
/*  44 */     b = Math.pow(b, brightness);
/*     */     
/*  46 */     return (int)(r * 256.0D) << 16 | (int)(g * 256.0D) << 8 | (int)(b * 256.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int retrieveHue(short hsl) {
/*  52 */     return hsl >> 10 & 0x3F;
/*     */   }
/*     */   
/*     */   private static int retrieveSaturation(short hsl) {
/*  56 */     return hsl >> 7 & 0x7;
/*     */   }
/*     */   
/*     */   private static int retrieveLuminance(short hsl) {
/*  60 */     return hsl & 0x7F;
/*     */   }
/*     */   
/*     */   private static int HSLtoRGB(short hsl, double brightness) {
/*  64 */     double hue = retrieveHue(hsl) / 64.0D + 0.0078125D;
/*  65 */     double saturation = retrieveSaturation(hsl) / 8.0D + 0.0625D;
/*  66 */     double luminance = retrieveLuminance(hsl) / 128.0D;
/*     */     
/*  68 */     double chroma = (1.0D - Math.abs(2.0D * luminance - 1.0D)) * saturation;
/*  69 */     double x = chroma * (1.0D - Math.abs(hue * 6.0D % 2.0D - 1.0D));
/*  70 */     double lightness = luminance - chroma / 2.0D;
/*     */     
/*  72 */     double r = lightness, g = lightness, b = lightness;
/*  73 */     switch ((int)(hue * 6.0D)) {
/*     */       case 0:
/*  75 */         r += chroma;
/*  76 */         g += x;
/*     */         break;
/*     */       case 1:
/*  79 */         g += chroma;
/*  80 */         r += x;
/*     */         break;
/*     */       case 2:
/*  83 */         g += chroma;
/*  84 */         b += x;
/*     */         break;
/*     */       case 3:
/*  87 */         b += chroma;
/*  88 */         g += x;
/*     */         break;
/*     */       case 4:
/*  91 */         b += chroma;
/*  92 */         r += x;
/*     */         break;
/*     */       default:
/*  95 */         r += chroma;
/*  96 */         b += x;
/*     */         break;
/*     */     } 
/*     */     
/* 100 */     int rgb = (int)(r * 256.0D) << 16 | (int)(g * 256.0D) << 8 | (int)(b * 256.0D);
/*     */     
/* 102 */     rgb = adjustForBrightness(rgb, brightness);
/*     */     
/* 104 */     if (rgb == 0) {
/* 105 */       rgb = 1;
/*     */     }
/* 107 */     return rgb;
/*     */   }
/*     */   public static double[] rgbToHsl(int rgb) {
/* 110 */     double r = (rgb >> 16 & 0xFF) / 255.0D;
/* 111 */     double g = (rgb >> 8 & 0xFF) / 255.0D;
/* 112 */     double b = (rgb & 0xFF) / 255.0D;
/*     */     
/* 114 */     double cMax = Math.max(r, Math.max(g, b));
/* 115 */     double cMin = Math.min(r, Math.min(g, b));
/* 116 */     double delta = cMax - cMin;
/*     */     
/* 118 */     double h = 0.0D;
/* 119 */     if (delta == 0.0D) {
/* 120 */       h = 0.0D;
/* 121 */     } else if (cMax == r) {
/* 122 */       h = 60.0D * (g - b) / delta;
/* 123 */     } else if (cMax == g) {
/* 124 */       h = 60.0D * ((b - r) / delta + 2.0D);
/* 125 */     } else if (cMax == b) {
/* 126 */       h = 60.0D * ((r - g) / delta + 4.0D);
/*     */     } 
/*     */     
/* 129 */     h = (h + 360.0D) % 360.0D;
/*     */     
/* 131 */     double l = (cMax + cMin) / 2.0D;
/*     */     
/* 133 */     double s = 0.0D;
/* 134 */     if (delta != 0.0D) {
/* 135 */       s = delta / (1.0D - Math.abs(2.0D * l - 1.0D));
/*     */     }
/*     */ 
/*     */     
/* 139 */     double[] hsl = new double[3];
/* 140 */     hsl[0] = Math.round(h * 100.0D) / 100.0D;
/* 141 */     hsl[1] = Math.round(s * 1000.0D) / 10.0D;
/* 142 */     hsl[2] = Math.round(l * 1000.0D) / 10.0D;
/*     */     
/* 144 */     return hsl;
/*     */   }
/*     */   
/*     */   public static long packHsl(double h, double s, double l) {
/* 148 */     long hPacked = Math.round(h * 100.0D);
/* 149 */     long sPacked = Math.round(s * 10.0D);
/* 150 */     long lPacked = Math.round(l * 10.0D);
/*     */     
/* 152 */     return (hPacked & 0xFFFFL) << 32L | (sPacked & 0x3FFL) << 22L | (lPacked & 0x3FFL) << 12L;
/*     */   }
/*     */   
/*     */   public static double[] unpackHsl(long packedValue) {
/* 156 */     int hPacked = (int)(packedValue >> 32L & 0xFFFFL);
/* 157 */     int sPacked = (int)(packedValue >> 22L & 0x3FFL);
/* 158 */     int lPacked = (int)(packedValue >> 12L & 0x3FFL);
/*     */     
/* 160 */     double h = hPacked / 100.0D;
/* 161 */     double s = sPacked / 10.0D;
/* 162 */     double l = lPacked / 10.0D;
/*     */     
/* 164 */     return new double[] { h, s, l };
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\HSLPalette.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */