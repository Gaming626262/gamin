/*    */ package com.osmb.api.visual.color.tolerance.impl;
/*    */ 
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelThresholdComparator
/*    */   implements ToleranceComparator
/*    */ {
/*    */   private final int channel1;
/*    */   private final int channel2;
/*    */   private final int channel3;
/*    */   
/*    */   public ChannelThresholdComparator(int channel1, int channel2, int channel3) {
/* 26 */     this.channel1 = channel1;
/* 27 */     this.channel2 = channel2;
/* 28 */     this.channel3 = channel3;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isWithinTolerance(double[] diff) {
/* 42 */     return (diff[0] <= this.channel1 && diff[1] <= this.channel2 && diff[2] <= this.channel3);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isWithinTolerance(int[] diff) {
/* 47 */     return (diff[0] <= this.channel1 && diff[1] <= this.channel2 && diff[2] <= this.channel3);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isZero() {
/* 52 */     return (this.channel1 == 0 && this.channel2 == 0 && this.channel3 == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\tolerance\impl\ChannelThresholdComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */