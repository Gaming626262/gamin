/*    */ package com.osmb.api.visual.color.tolerance.impl;
/*    */ 
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SingleThresholdComparator
/*    */   implements ToleranceComparator
/*    */ {
/*    */   private final int threshold;
/*    */   
/*    */   public SingleThresholdComparator(int threshold) {
/* 22 */     this.threshold = threshold;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isWithinTolerance(int[] diff) {
/* 36 */     return (diff[0] <= this.threshold && diff[1] <= this.threshold && diff[2] <= this.threshold);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isWithinTolerance(double[] diff) {
/* 49 */     return (diff[0] <= this.threshold && diff[1] <= this.threshold && diff[2] <= this.threshold);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isZero() {
/* 54 */     return (this.threshold == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\tolerance\impl\SingleThresholdComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */