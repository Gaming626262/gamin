/*   */ package com.osmb.api.visual.color.tolerance;
/*   */ 
/*   */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*   */ 
/*   */ public interface ToleranceComparator {
/* 6 */   public static final SingleThresholdComparator ZERO_TOLERANCE = new SingleThresholdComparator(0);
/*   */   
/*   */   boolean isWithinTolerance(double[] paramArrayOfdouble);
/*   */   
/*   */   boolean isWithinTolerance(int[] paramArrayOfint);
/*   */   
/*   */   boolean isZero();
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\color\tolerance\ToleranceComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */