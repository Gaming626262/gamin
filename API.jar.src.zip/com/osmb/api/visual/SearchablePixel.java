/*    */ package com.osmb.api.visual;
/*    */ 
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.Pixel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ 
/*    */ public class SearchablePixel
/*    */   extends Pixel {
/*    */   private final ToleranceComparator toleranceComparator;
/*    */   private final ColorModel colorModel;
/*    */   
/*    */   public SearchablePixel(int rgb, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 13 */     super(rgb);
/* 14 */     this.toleranceComparator = toleranceComparator;
/* 15 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public ToleranceComparator getToleranceComparator() {
/* 19 */     return this.toleranceComparator;
/*    */   }
/*    */   
/*    */   public ColorModel getColorModel() {
/* 23 */     return this.colorModel;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 28 */     return "Pixel = " + this.rgb + ", Tolerance = " + this.toleranceComparator + ", ColorModel = " + this.colorModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\SearchablePixel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */