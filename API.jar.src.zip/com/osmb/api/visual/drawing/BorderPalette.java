/*    */ package com.osmb.api.visual.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BorderPalette
/*    */ {
/* 13 */   public static final BorderPalette MODERN_BORDER = new BorderPalette(5814, 5816, 5820, 5822, 5815, 5821, 5817, 5819);
/* 14 */   public static final BorderPalette STEEL_BORDER = new BorderPalette(310, 311, 312, 313, 314, 173, 172, 315);
/* 15 */   public static final BorderPalette STONE_BORDER = new BorderPalette(824, 825, 826, 827, 820, 822, 821, 823);
/*    */   
/*    */   private final int topLeftBorderID;
/*    */   private final int topRightBorderID;
/*    */   private final int bottomLeftBorderID;
/*    */   private final int bottomRightBorderID;
/*    */   private final int topBorderID;
/*    */   private final int bottomBorderID;
/*    */   private final int leftBorderID;
/*    */   private final int rightBorderID;
/*    */   
/*    */   public BorderPalette(int topLeftBorderID, int topRightBorderID, int bottomLeftBorderID, int bottomRightBorderID, int topBorderID, int bottomBorderID, int leftBorderID, int rightBorderID) {
/* 27 */     this.topLeftBorderID = topLeftBorderID;
/* 28 */     this.topRightBorderID = topRightBorderID;
/* 29 */     this.bottomLeftBorderID = bottomLeftBorderID;
/* 30 */     this.bottomRightBorderID = bottomRightBorderID;
/* 31 */     this.topBorderID = topBorderID;
/* 32 */     this.bottomBorderID = bottomBorderID;
/* 33 */     this.leftBorderID = leftBorderID;
/* 34 */     this.rightBorderID = rightBorderID;
/*    */   }
/*    */   
/*    */   public int getTopRightBorderID() {
/* 38 */     return this.topRightBorderID;
/*    */   }
/*    */   
/*    */   public int getTopLeftBorderID() {
/* 42 */     return this.topLeftBorderID;
/*    */   }
/*    */   
/*    */   public int getBottomLeftBorderID() {
/* 46 */     return this.bottomLeftBorderID;
/*    */   }
/*    */   
/*    */   public int getBottomRightBorderID() {
/* 50 */     return this.bottomRightBorderID;
/*    */   }
/*    */   
/*    */   public int getTopBorderID() {
/* 54 */     return this.topBorderID;
/*    */   }
/*    */   
/*    */   public int getBottomBorderID() {
/* 58 */     return this.bottomBorderID;
/*    */   }
/*    */   
/*    */   public int getLeftBorderID() {
/* 62 */     return this.leftBorderID;
/*    */   }
/*    */   
/*    */   public int getRightBorderID() {
/* 66 */     return this.rightBorderID;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\drawing\BorderPalette.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */