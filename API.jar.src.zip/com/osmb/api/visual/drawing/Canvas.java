/*     */ package com.osmb.api.visual.drawing;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import com.osmb.api.visual.image.VersionedImage;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Canvas
/*     */ {
/*     */   public int[] pixels;
/*     */   public int canvasWidth;
/*     */   public int canvasHeight;
/*     */   public int drawingAreaLeft;
/*     */   
/*     */   public Canvas(int canvasWidth, int height, int backgroundColor) {
/*  33 */     this.canvasWidth = canvasWidth;
/*  34 */     this.canvasHeight = height;
/*  35 */     this.pixels = new int[canvasWidth * height];
/*  36 */     reset(backgroundColor);
/*  37 */     setDrawArea(0, 0, canvasWidth, height);
/*     */   }
/*     */   public int drawingAreaTop; public int drawingAreaRight; public int drawingAreaBottom; public int drawAreaWidth; public int drawAreaHeight;
/*     */   public Canvas(int backgroundSpriteID, ScriptCore core) {
/*  41 */     SpriteDefinition backgroundSprite = core.getSpriteManager().getSprite(backgroundSpriteID);
/*  42 */     this.canvasWidth = backgroundSprite.width;
/*  43 */     this.canvasHeight = backgroundSprite.height;
/*  44 */     this.pixels = Arrays.copyOf(backgroundSprite.pixels, backgroundSprite.pixels.length);
/*  45 */     setDrawArea(0, 0, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public Canvas(Image image) {
/*  50 */     this.canvasWidth = image.width;
/*  51 */     this.canvasHeight = image.height;
/*  52 */     this.pixels = image.pixels;
/*  53 */     setDrawArea(0, 0, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public Canvas(int[] pixels, int width, int height, int backgroundColor) {
/*  58 */     this.pixels = pixels;
/*  59 */     this.canvasWidth = width;
/*  60 */     this.canvasHeight = height;
/*  61 */     reset(backgroundColor);
/*  62 */     setDrawArea(0, 0, width, height);
/*     */   }
/*     */   
/*     */   public Canvas(int[] pixels, int width, int height) {
/*  66 */     this.pixels = pixels;
/*  67 */     this.canvasWidth = width;
/*  68 */     this.canvasHeight = height;
/*  69 */     setDrawArea(0, 0, width, height);
/*     */   }
/*     */   
/*     */   public Canvas(int width, int height) {
/*  73 */     this.pixels = new int[width * height];
/*  74 */     this.canvasWidth = width;
/*  75 */     this.canvasHeight = height;
/*  76 */     reset(16711935);
/*  77 */     setDrawArea(0, 0, width, height);
/*     */   }
/*     */   
/*     */   public Canvas(SpriteDefinition sprite) {
/*  81 */     this.pixels = Arrays.copyOf(sprite.pixels, sprite.pixels.length);
/*  82 */     this.canvasWidth = sprite.width;
/*  83 */     this.canvasHeight = sprite.height;
/*  84 */     setDrawArea(0, 0, sprite.width, sprite.height);
/*     */   }
/*     */   
/*     */   public void replaceAllPixels(int colorToReplace, int replaceWith) {
/*  88 */     for (int i = 0; i < this.pixels.length; i++) {
/*  89 */       if (this.pixels[i] == colorToReplace) {
/*  90 */         this.pixels[i] = replaceWith;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void drawLine(int x1, int y1, int x2, int y2, int rgb) {
/*  96 */     drawLine(x1, y1, x2, y2, rgb, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawLine(int x1, int y1, int x2, int y2, int rgb, double opacity) {
/* 110 */     int dx = Math.abs(x2 - x1);
/* 111 */     int dy = Math.abs(y2 - y1);
/*     */     
/* 113 */     int sx = (x1 < x2) ? 1 : -1;
/* 114 */     int sy = (y1 < y2) ? 1 : -1;
/*     */     
/* 116 */     int err = dx - dy;
/*     */     
/*     */     while (true) {
/* 119 */       if (x1 >= this.drawingAreaLeft && x1 < this.drawingAreaRight && y1 >= this.drawingAreaTop && y1 < this.drawingAreaBottom) {
/* 120 */         int index = x1 + y1 * this.canvasWidth;
/* 121 */         int bgColor = this.pixels[index];
/*     */ 
/*     */         
/* 124 */         int blendedColor = blendColors(rgb, bgColor, opacity);
/*     */ 
/*     */         
/* 127 */         this.pixels[index] = blendedColor;
/*     */       } 
/*     */       
/* 130 */       if (x1 == x2 && y1 == y2) {
/*     */         break;
/*     */       }
/*     */       
/* 134 */       int e2 = 2 * err;
/*     */       
/* 136 */       if (e2 > -dy) {
/* 137 */         err -= dy;
/* 138 */         x1 += sx;
/*     */       } 
/*     */       
/* 141 */       if (e2 < dx) {
/* 142 */         err += dx;
/* 143 */         y1 += sy;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int blendColors(int fgColor, int bgColor, double opacity) {
/* 158 */     int fgRed = fgColor >> 16 & 0xFF;
/* 159 */     int fgGreen = fgColor >> 8 & 0xFF;
/* 160 */     int fgBlue = fgColor & 0xFF;
/*     */ 
/*     */     
/* 163 */     int bgRed = bgColor >> 16 & 0xFF;
/* 164 */     int bgGreen = bgColor >> 8 & 0xFF;
/* 165 */     int bgBlue = bgColor & 0xFF;
/*     */ 
/*     */     
/* 168 */     int red = (int)(opacity * fgRed + (1.0D - opacity) * bgRed);
/* 169 */     int green = (int)(opacity * fgGreen + (1.0D - opacity) * bgGreen);
/* 170 */     int blue = (int)(opacity * fgBlue + (1.0D - opacity) * bgBlue);
/*     */ 
/*     */     
/* 173 */     return 0xFF000000 | red << 16 | green << 8 | blue;
/*     */   }
/*     */   
/*     */   public void drawLineX(int x, int y, int length, int rgb) {
/* 177 */     drawLineX(x, y, length, rgb, 1.0D);
/*     */   }
/*     */   
/*     */   public void drawLineX(int x, int y, int length, int rgb, double opacity) {
/* 181 */     if (y < this.drawingAreaTop || y >= this.drawingAreaBottom) {
/*     */       return;
/*     */     }
/*     */     
/* 185 */     if (x < this.drawingAreaLeft) {
/* 186 */       length -= this.drawingAreaLeft - x;
/* 187 */       x = this.drawingAreaLeft;
/*     */     } 
/*     */     
/* 190 */     if (x + length > this.drawingAreaRight) {
/* 191 */       length = this.drawingAreaRight - x;
/*     */     }
/*     */     
/* 194 */     int offset = x + y * this.canvasWidth;
/*     */     
/* 196 */     for (int i = 0; i < length; i++) {
/* 197 */       this.pixels[offset + i] = blendColors(rgb, this.pixels[offset + i], opacity);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawLineY(int x, int y, int length, int rgb) {
/* 203 */     drawLineY(x, y, length, rgb, 1.0D);
/*     */   }
/*     */   
/*     */   public void drawLineY(int x, int y, int length, int rgb, double opacity) {
/* 207 */     if (x < this.drawingAreaLeft || x >= this.drawingAreaRight) {
/*     */       return;
/*     */     }
/*     */     
/* 211 */     if (y < this.drawingAreaTop) {
/* 212 */       length -= this.drawingAreaTop - y;
/* 213 */       y = this.drawingAreaTop;
/*     */     } 
/*     */     
/* 216 */     if (y + length > this.drawingAreaBottom) {
/* 217 */       length = this.drawingAreaBottom - y;
/*     */     }
/*     */     
/* 220 */     int offset = x + y * this.canvasWidth;
/*     */     
/* 222 */     for (int i = 0; i < length; i++) {
/* 223 */       this.pixels[offset + i * this.canvasWidth] = blendColors(rgb, this.pixels[offset + i * this.canvasWidth], opacity);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawText(String text, int x, int y, int color, Font font) {
/* 229 */     BufferedImage textImage = new BufferedImage(this.canvasWidth, this.canvasHeight, 2);
/* 230 */     Graphics2D g2d = textImage.createGraphics();
/*     */     
/* 232 */     g2d.setFont(font);
/*     */ 
/*     */     
/* 235 */     g2d.setColor(new Color(color, true));
/*     */ 
/*     */     
/* 238 */     g2d.drawString(text, x, y);
/*     */     
/* 240 */     g2d.dispose();
/*     */ 
/*     */     
/* 243 */     int[] textPixels = ((DataBufferInt)textImage.getRaster().getDataBuffer()).getData();
/* 244 */     for (int py = 0; py < this.canvasHeight; py++) {
/* 245 */       for (int px = 0; px < this.canvasWidth; px++) {
/* 246 */         int index = py * this.canvasWidth + px;
/* 247 */         if ((textPixels[index] & 0xFF000000) != 0) {
/* 248 */           this.pixels[index] = textPixels[index];
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void drawRect(int x, int y, int width, int height, int rgb) {
/* 255 */     drawRect(x, y, width, height, rgb, 1.0D);
/*     */   }
/*     */   
/*     */   public void drawRect(int x, int y, int width, int height, int rgb, double opacity) {
/* 259 */     drawLineX(x, y, width, rgb, opacity);
/* 260 */     drawLineX(x, y + height - 1, width, rgb, opacity);
/* 261 */     drawLineY(x, y, height, rgb, opacity);
/* 262 */     drawLineY(x + width - 1, y, height, rgb, opacity);
/*     */   }
/*     */   
/*     */   public void drawRect(Rectangle rectangle, int rgb) {
/* 266 */     drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height, rgb);
/*     */   }
/*     */   
/*     */   public void drawRect(Rectangle rectangle, int rgb, double opacity) {
/* 270 */     drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height, rgb, opacity);
/*     */   }
/*     */   
/*     */   public void fillRect(Rectangle rectangle, int rgb) {
/* 274 */     fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height, rgb, 1.0D);
/*     */   }
/*     */   
/*     */   public void fillRect(Rectangle rectangle, int rgb, double opacity) {
/* 278 */     fillRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height, rgb, opacity);
/*     */   }
/*     */   
/*     */   public void fillRect(int x, int y, int width, int height, int rgb) {
/* 282 */     fillRect(x, y, width, height, rgb, 1.0D);
/*     */   }
/*     */   
/*     */   public void fillRect(int x, int y, int width, int height, int rgb, double opacity) {
/* 286 */     if (x < this.drawingAreaLeft) {
/* 287 */       width -= this.drawingAreaLeft - x;
/* 288 */       x = this.drawingAreaLeft;
/*     */     } 
/*     */     
/* 291 */     if (y < this.drawingAreaTop) {
/* 292 */       height -= this.drawingAreaTop - y;
/* 293 */       y = this.drawingAreaTop;
/*     */     } 
/*     */     
/* 296 */     if (x + width > this.drawingAreaRight) {
/* 297 */       width = this.drawingAreaRight - x;
/*     */     }
/*     */     
/* 300 */     if (y + height > this.drawingAreaBottom) {
/* 301 */       height = this.drawingAreaBottom - y;
/*     */     }
/*     */     
/* 304 */     int step = this.canvasWidth - width;
/* 305 */     int offset = x + y * this.canvasWidth;
/*     */     
/* 307 */     for (int i = -height; i < 0; i++) {
/* 308 */       for (int j = -width; j < 0; j++) {
/* 309 */         this.pixels[offset] = blendColors(rgb, this.pixels[offset], opacity);
/* 310 */         offset++;
/*     */       } 
/* 312 */       offset += step;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawSpritePixelsCentered(SpriteDefinition spriteDefinition) {
/* 323 */     int centerX = this.drawAreaWidth / 2 - spriteDefinition.width / 2;
/* 324 */     int centerY = this.drawAreaHeight / 2 - spriteDefinition.height / 2;
/* 325 */     drawSpritePixels(spriteDefinition, centerX, centerY);
/*     */   }
/*     */   
/*     */   public void drawSpritePixelsCentered(int spriteID, ScriptCore core) {
/* 329 */     drawSpritePixelsCentered(core.getSpriteManager().getSprite(spriteID));
/*     */   }
/*     */   
/*     */   public void createBackground(ScriptCore core, BorderPalette spritePalette, SpriteDefinition fill) {
/* 333 */     if (fill != null) {
/*     */       
/* 335 */       setDrawArea(this.drawingAreaLeft + 1, this.drawingAreaTop + 1, this.drawingAreaRight - 1, this.drawingAreaBottom - 1); int i;
/* 336 */       for (i = 0; i < this.canvasWidth; i += fill.width) {
/* 337 */         int j; for (j = 0; j < this.canvasHeight; j += fill.height) {
/* 338 */           drawSpritePixels(fill, i, j);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 343 */     setDrawArea(this.drawingAreaLeft - 1, this.drawingAreaTop - 1, this.drawingAreaRight + 1, this.drawingAreaBottom + 1);
/*     */     
/* 345 */     SpriteDefinition topLeft = core.getSpriteManager().getSprite(spritePalette.getTopLeftBorderID());
/* 346 */     SpriteDefinition topRight = core.getSpriteManager().getSprite(spritePalette.getTopRightBorderID());
/* 347 */     SpriteDefinition bottomLeft = core.getSpriteManager().getSprite(spritePalette.getBottomLeftBorderID());
/* 348 */     SpriteDefinition bottomRight = core.getSpriteManager().getSprite(spritePalette.getBottomRightBorderID());
/*     */ 
/*     */     
/* 351 */     drawSpritePixels(topLeft, 0, 0);
/* 352 */     drawSpritePixels(topRight, this.canvasWidth - topRight.width, 0);
/* 353 */     drawSpritePixels(bottomLeft, 0, this.canvasHeight - bottomLeft.height);
/* 354 */     drawSpritePixels(bottomRight, this.canvasWidth - bottomRight.width, this.canvasHeight - bottomRight.height);
/*     */ 
/*     */     
/* 357 */     int topStartX = topLeft.width;
/* 358 */     int topEndX = this.canvasWidth - topRight.width;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 363 */     int leftStartY = topLeft.height;
/* 364 */     int leftEndY = this.canvasHeight - bottomLeft.height;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 370 */     setDrawArea(topStartX, 0, topEndX, this.canvasHeight);
/* 371 */     SpriteDefinition top = core.getSpriteManager().getSprite(spritePalette.getTopBorderID());
/* 372 */     SpriteDefinition bottom = core.getSpriteManager().getSprite(spritePalette.getBottomBorderID()); int x;
/* 373 */     for (x = 0; x < this.drawAreaWidth; x += top.width) {
/* 374 */       drawSpritePixels(top, x, 0);
/* 375 */       drawSpritePixels(bottom, x, this.drawAreaHeight - bottom.height);
/*     */     } 
/*     */ 
/*     */     
/* 379 */     setDrawArea(0, leftStartY, this.canvasWidth, leftEndY);
/* 380 */     SpriteDefinition left = core.getSpriteManager().getSprite(spritePalette.getLeftBorderID());
/* 381 */     SpriteDefinition right = core.getSpriteManager().getSprite(spritePalette.getRightBorderID()); int y;
/* 382 */     for (y = 0; y < this.drawAreaHeight; y += left.height) {
/* 383 */       drawSpritePixels(left, 0, y);
/* 384 */       drawSpritePixels(right, this.drawAreaWidth - right.width, y);
/*     */     } 
/* 386 */     setDrawArea(0, 0, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */   
/*     */   public void drawSpritePixels(ScriptCore core, int spriteID, int x, int y) {
/* 390 */     drawSpritePixels(core.getSpriteManager().getSprite(spriteID), x, y);
/*     */   }
/*     */   
/*     */   public void drawSpritePixels(SpriteDefinition spriteDefinition, int x, int y) {
/* 394 */     drawPixels(spriteDefinition.pixels, x, y, spriteDefinition.width, spriteDefinition.height);
/*     */   }
/*     */   
/*     */   public void drawSpritePixels(SpriteDefinition spriteDefinition, int x, int y, boolean flipHorizontal, boolean flipVertical) {
/* 398 */     drawPixels(spriteDefinition.pixels, x, y, spriteDefinition.width, spriteDefinition.height, flipHorizontal, flipVertical);
/*     */   }
/*     */   
/*     */   public void drawPixels(int[] pixelsToDraw, int x, int y, int width, int height) {
/* 402 */     drawPixels(pixelsToDraw, x, y, width, height, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPixels(int[] pixelsToDraw, int x, int y, int width, int height, boolean flipHorizontal, boolean flipVertical) {
/* 407 */     int maxWidth = Math.min(width, this.drawingAreaRight - this.drawingAreaLeft + x);
/* 408 */     int maxHeight = Math.min(height, this.drawingAreaBottom - this.drawingAreaTop + y);
/* 409 */     int startX = this.drawingAreaLeft + x;
/* 410 */     int startY = this.drawingAreaTop + y;
/*     */ 
/*     */     
/* 413 */     for (int dy = 0; dy < maxHeight; dy++) {
/* 414 */       for (int dx = 0; dx < maxWidth; dx++) {
/* 415 */         int baseX = startX + (flipHorizontal ? (maxWidth - dx - 1) : dx);
/* 416 */         int baseY = startY + (flipVertical ? (maxHeight - dy - 1) : dy);
/* 417 */         int sourceIndex = dx + dy * width;
/*     */         
/* 419 */         if (baseX >= 0 && baseY >= 0) {
/*     */           
/* 421 */           int destIndex = baseX + baseY * this.canvasWidth;
/* 422 */           int rgb = pixelsToDraw[sourceIndex];
/*     */           
/* 424 */           if (rgb != 0 && rgb != 16711935)
/*     */           {
/*     */             
/* 427 */             this.pixels[destIndex] = rgb;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawBorder(int color) {
/* 438 */     int[] newPixels = new int[this.canvasWidth * this.canvasHeight];
/* 439 */     int pixelIndex = 0;
/*     */     
/* 441 */     for (int y = 0; y < this.canvasHeight; y++) {
/* 442 */       for (int x = 0; x < this.canvasWidth; x++) {
/* 443 */         int pixel = this.pixels[pixelIndex];
/* 444 */         if (pixel == 0)
/*     */         {
/* 446 */           if (x > 0 && this.pixels[pixelIndex - 1] != 0) {
/* 447 */             pixel = color;
/*     */           
/*     */           }
/* 450 */           else if (y > 0 && this.pixels[pixelIndex - this.canvasWidth] != 0) {
/* 451 */             pixel = color;
/*     */           
/*     */           }
/* 454 */           else if (x < this.canvasWidth - 1 && this.pixels[pixelIndex + 1] != 0) {
/* 455 */             pixel = color;
/*     */           
/*     */           }
/* 458 */           else if (y < this.canvasHeight - 1 && this.pixels[pixelIndex + this.canvasWidth] != 0) {
/* 459 */             pixel = color;
/*     */           } 
/*     */         }
/*     */         
/* 463 */         newPixels[pixelIndex++] = pixel;
/*     */       } 
/*     */     } 
/*     */     
/* 467 */     this.pixels = newPixels;
/*     */   }
/*     */   
/*     */   public void drawShadow(int color) {
/* 471 */     for (int y = this.canvasHeight - 1; y > 0; y--) {
/* 472 */       int rowOffset = y * this.canvasWidth;
/*     */       
/* 474 */       for (int x = this.canvasWidth - 1; x > 0; x--) {
/*     */         
/* 476 */         if (this.pixels[x + rowOffset] == 0 && this.pixels[x + rowOffset - 1 - this.canvasWidth] != 0) {
/* 477 */           this.pixels[x + rowOffset] = color;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPixel(int x, int y, int rgb) {
/* 485 */     if (x < 0 || x >= this.canvasWidth || y < 0 || y >= this.canvasHeight) {
/* 486 */       throw new IllegalArgumentException("Coordinates out of bounds: " + x + ", " + y + " [Image w: " + this.canvasWidth + " h: " + this.canvasHeight + "]");
/*     */     }
/* 488 */     this.pixels[y * this.canvasWidth + x] = rgb;
/*     */   }
/*     */   
/*     */   public void setDrawArea(int left, int top, int right, int bottom) {
/* 492 */     if (left < 0) {
/* 493 */       left = 0;
/*     */     }
/*     */     
/* 496 */     if (top < 0) {
/* 497 */       top = 0;
/*     */     }
/*     */ 
/*     */     
/* 501 */     if (right > this.canvasWidth) {
/* 502 */       right = this.canvasWidth;
/*     */     }
/*     */     
/* 505 */     if (bottom > this.canvasHeight) {
/* 506 */       bottom = this.canvasHeight;
/*     */     }
/*     */     
/* 509 */     this.drawingAreaLeft = left;
/* 510 */     this.drawingAreaTop = top;
/* 511 */     this.drawingAreaRight = right;
/* 512 */     this.drawingAreaBottom = bottom;
/* 513 */     this.drawAreaWidth = this.drawingAreaRight - this.drawingAreaLeft;
/* 514 */     this.drawAreaHeight = this.drawingAreaBottom - this.drawingAreaTop;
/*     */   }
/*     */   
/*     */   public void reset(int baseColor) {
/* 518 */     Arrays.fill(this.pixels, baseColor);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image toImage() {
/* 523 */     int[] pixels = this.pixels;
/* 524 */     return new Image(pixels, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */   
/*     */   public VersionedImage toVersionedImage(UUID uuid) {
/* 528 */     return new VersionedImage(uuid, this.pixels, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */   
/*     */   public Image toImageCopy() {
/* 532 */     int[] pixels = Arrays.copyOf(this.pixels, this.pixels.length);
/* 533 */     return new Image(pixels, this.canvasWidth, this.canvasHeight);
/*     */   }
/*     */   
/*     */   public SearchableImage toSearchableImage(ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 537 */     return new SearchableImage(this.pixels, this.canvasWidth, this.canvasHeight, toleranceComparator, colorModel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawOval(int x, int y, int width, int height, int rgb) {
/* 551 */     int centerX = x + width / 2;
/* 552 */     int centerY = y + height / 2;
/* 553 */     int radiusX = width / 2;
/* 554 */     int radiusY = height / 2;
/*     */     
/* 556 */     int rxSq = radiusX * radiusX;
/* 557 */     int rySq = radiusY * radiusY;
/*     */     
/* 559 */     int x1 = 0;
/* 560 */     int y1 = radiusY;
/*     */     
/* 562 */     int px = 0;
/* 563 */     int py = 2 * rxSq * y1;
/*     */ 
/*     */     
/* 566 */     int p = (int)((rySq - rxSq * radiusY) + 0.25D * rxSq);
/* 567 */     while (px < py) {
/* 568 */       plotEllipsePoints(centerX, centerY, x1, y1, rgb);
/*     */       
/* 570 */       x1++;
/* 571 */       px += 2 * rySq;
/* 572 */       if (p < 0) {
/* 573 */         p += rySq + px; continue;
/*     */       } 
/* 575 */       y1--;
/* 576 */       py -= 2 * rxSq;
/* 577 */       p += rySq + px - py;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 582 */     p = (int)(rySq * (x1 + 0.5D) * (x1 + 0.5D) + (rxSq * (y1 - 1) * (y1 - 1)) - (rxSq * rySq));
/* 583 */     while (y1 >= 0) {
/* 584 */       plotEllipsePoints(centerX, centerY, x1, y1, rgb);
/*     */       
/* 586 */       y1--;
/* 587 */       py -= 2 * rxSq;
/* 588 */       if (p > 0) {
/* 589 */         p += rxSq - py; continue;
/*     */       } 
/* 591 */       x1++;
/* 592 */       px += 2 * rySq;
/* 593 */       p += rxSq - py + px;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void plotEllipsePoints(int centerX, int centerY, int offsetX, int offsetY, int rgb) {
/* 608 */     setPixel(centerX + offsetX, centerY + offsetY, rgb);
/* 609 */     setPixel(centerX - offsetX, centerY + offsetY, rgb);
/* 610 */     setPixel(centerX + offsetX, centerY - offsetY, rgb);
/* 611 */     setPixel(centerX - offsetX, centerY - offsetY, rgb);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRGB(int x, int y, int rgb, double opacity) {
/* 616 */     if (x < this.drawingAreaLeft || x >= this.drawAreaWidth || y < this.drawingAreaTop || y >= this.drawAreaHeight) {
/*     */       return;
/*     */     }
/* 619 */     x += this.drawingAreaLeft;
/* 620 */     y += this.drawingAreaTop;
/*     */     
/* 622 */     this.pixels[y * this.canvasWidth + x] = blendColors(rgb, this.pixels[y * this.canvasWidth + x], opacity);
/*     */   }
/*     */   
/*     */   public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints, int rgb, double opacity) {
/* 626 */     for (int i = 0; i < nPoints; i++) {
/* 627 */       int next = (i + 1) % nPoints;
/* 628 */       drawLine(xPoints[i], yPoints[i], xPoints[next], yPoints[next], rgb, opacity);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawPolygon(int[] xPoints, int[] yPoints, int nPoints, int rgb) {
/* 634 */     drawPolygon(xPoints, yPoints, nPoints, rgb, 1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fillPolygon(int[] xPoints, int[] yPoints, int nPoints, int rgb, double opacity) {
/* 639 */     if (nPoints < 3) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 644 */     int minY = Integer.MAX_VALUE;
/* 645 */     int maxY = Integer.MIN_VALUE;
/*     */     
/* 647 */     for (int i : yPoints) {
/* 648 */       if (i < minY) minY = i; 
/* 649 */       if (i > maxY) maxY = i;
/*     */     
/*     */     } 
/*     */     
/* 653 */     for (int y = minY; y <= maxY; y++) {
/*     */       
/* 655 */       List<Integer> intersections = new ArrayList<>(); int i;
/* 656 */       for (i = 0; i < nPoints; i++) {
/* 657 */         int x1 = xPoints[i];
/* 658 */         int y1 = yPoints[i];
/* 659 */         int x2 = xPoints[(i + 1) % nPoints];
/* 660 */         int y2 = yPoints[(i + 1) % nPoints];
/*     */ 
/*     */         
/* 663 */         if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
/*     */           
/* 665 */           int xIntersect = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
/* 666 */           intersections.add(Integer.valueOf(xIntersect));
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 671 */       Collections.sort(intersections);
/*     */ 
/*     */       
/* 674 */       for (i = 0; i < intersections.size(); i += 2) {
/* 675 */         int xStart = ((Integer)intersections.get(i)).intValue();
/* 676 */         int xEnd = ((Integer)intersections.get(i + 1)).intValue();
/*     */ 
/*     */         
/* 679 */         for (int x = xStart; x <= xEnd; x++)
/* 680 */           setRGB(x, y, rgb, opacity); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\drawing\Canvas.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */