package com.osmb.api.visual.drawing;

import com.osmb.api.location.position.Position;
import com.osmb.api.scene.RSObject;
import com.osmb.api.shape.Polygon;
import com.osmb.api.shape.triangle.Triangle;
import com.osmb.api.utils.TileSide;
import java.awt.Point;
import java.util.List;

public interface SceneProjector {
  public static final int TILE_FLAG_BRIDGE = 2;
  
  Polygon getConvexHull(RSObject paramRSObject);
  
  List<Triangle> getFaceTriangles(RSObject paramRSObject);
  
  void drawModelOutline(RSObject paramRSObject, Canvas paramCanvas, double paramDouble);
  
  Polygon getTilePoly(Position paramPosition);
  
  Polygon getTilePoly(int paramInt1, int paramInt2, int paramInt3);
  
  Polygon getTilePoly(int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2);
  
  Point getTilePoint(int paramInt1, int paramInt2, int paramInt3, TileSide paramTileSide);
  
  Polygon getTilePoly(int paramInt1, int paramInt2, int paramInt3, double paramDouble1, double paramDouble2, int paramInt4, int paramInt5);
  
  Polygon getTileCube(Position paramPosition, int paramInt);
  
  Polygon getTileCube(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  Polygon getTileCube(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double paramDouble1, double paramDouble2);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\drawing\SceneProjector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */