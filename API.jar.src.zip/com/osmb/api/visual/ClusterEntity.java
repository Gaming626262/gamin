/*    */ package com.osmb.api.visual;
/*    */ 
/*    */ public class ClusterEntity
/*    */ {
/*    */   private final SearchablePixel[] searchablePixels;
/*    */   private final int maxDistance;
/*    */   private final int minGroupSize;
/*    */   
/*    */   public ClusterEntity(SearchablePixel[] searchablePixels, int maxDistance, int minGroupSize) {
/* 10 */     this.searchablePixels = searchablePixels;
/* 11 */     this.maxDistance = maxDistance;
/* 12 */     this.minGroupSize = minGroupSize;
/*    */   }
/*    */   
/*    */   public SearchablePixel[] getRegisteredPixels() {
/* 16 */     return this.searchablePixels;
/*    */   }
/*    */   
/*    */   public int getMaxDistance() {
/* 20 */     return this.maxDistance;
/*    */   }
/*    */   
/*    */   public int getMinGroupSize() {
/* 24 */     return this.minGroupSize;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\ClusterEntity.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */