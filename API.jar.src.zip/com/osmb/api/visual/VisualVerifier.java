package com.osmb.api.visual;

import com.osmb.api.ScriptCore;
import com.osmb.api.shape.Shape;

public interface VisualVerifier {
  boolean verify(ScriptCore paramScriptCore, Shape paramShape);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\VisualVerifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */