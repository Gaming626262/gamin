/*     */ package com.osmb.api.visual.image;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.ColorUtils;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class Image {
/*     */   public int width;
/*     */   public int height;
/*     */   public int[] pixels;
/*     */   
/*     */   public Image(SpriteDefinition spriteDefinition) {
/*  27 */     this.pixels = spriteDefinition.pixels;
/*  28 */     this.width = spriteDefinition.width;
/*  29 */     this.height = spriteDefinition.height;
/*  30 */     ColorUtils.setAlpha(this.pixels, 255);
/*     */   }
/*     */   
/*     */   public Image(int spriteID, ScriptCore core) {
/*  34 */     SpriteDefinition spriteDefinition = core.getSpriteManager().getSprite(spriteID);
/*  35 */     this.pixels = spriteDefinition.pixels;
/*  36 */     this.width = spriteDefinition.width;
/*  37 */     this.height = spriteDefinition.height;
/*  38 */     ColorUtils.setAlpha(this.pixels, 255);
/*     */   }
/*     */   
/*     */   public Image(int[] pixels, int width, int height) {
/*  42 */     this.pixels = pixels;
/*  43 */     this.width = width;
/*  44 */     this.height = height;
/*  45 */     ColorUtils.setAlpha(pixels, 255);
/*     */   }
/*     */   
/*     */   public Image(int width, int height) {
/*  49 */     this.pixels = new int[width * height];
/*  50 */     this.width = width;
/*  51 */     this.height = height;
/*  52 */     ColorUtils.setAlpha(this.pixels, 255);
/*     */   }
/*     */   
/*     */   public Image(BufferedImage image) {
/*  56 */     this.pixels = bufferedImageToPixelArray(image);
/*  57 */     this.width = image.getWidth();
/*  58 */     this.height = image.getHeight();
/*  59 */     ColorUtils.setAlpha(this.pixels, 255);
/*     */   }
/*     */   
/*     */   public Image(File pngFile) throws IOException {
/*     */     
/*  64 */     try { FileInputStream fis = new FileInputStream(pngFile); 
/*  65 */       try { byte[] header = new byte[8];
/*  66 */         fis.read(header);
/*  67 */         if (!isPNG(header)) {
/*  68 */           throw new IOException("Not a valid PNG file");
/*     */         }
/*     */ 
/*     */         
/*  72 */         fis.skip(4L);
/*  73 */         byte[] ihdrChunk = new byte[4];
/*  74 */         fis.read(ihdrChunk);
/*  75 */         if (!Arrays.equals(ihdrChunk, new byte[] { 73, 72, 68, 82 })) {
/*  76 */           throw new IOException("IHDR chunk not found");
/*     */         }
/*     */ 
/*     */         
/*  80 */         this.width = readInt(fis);
/*     */         
/*  82 */         this.height = readInt(fis);
/*     */ 
/*     */         
/*  85 */         fis.skip(5L);
/*  86 */         int[] pixels = new int[this.width * this.height];
/*  87 */         for (int i = 0; i < pixels.length; i++) {
/*  88 */           int r = fis.read();
/*  89 */           int g = fis.read();
/*  90 */           int b = fis.read();
/*  91 */           int a = fis.read();
/*  92 */           pixels[i] = a << 24 | r << 16 | g << 8 | b;
/*     */         } 
/*  94 */         this.pixels = pixels;
/*  95 */         fis.close(); } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Exception e)
/*  96 */     { e.printStackTrace(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isPNG(byte[] header) {
/* 102 */     return (header[0] == -119 && header[1] == 80 && header[2] == 78 && header[3] == 71 && header[4] == 13 && header[5] == 10 && header[6] == 26 && header[7] == 10);
/*     */   }
/*     */   
/*     */   private static int readInt(FileInputStream fis) throws IOException {
/* 106 */     int b1 = fis.read();
/* 107 */     int b2 = fis.read();
/* 108 */     int b3 = fis.read();
/* 109 */     int b4 = fis.read();
/* 110 */     return b1 << 24 | b2 << 16 | b3 << 8 | b4;
/*     */   }
/*     */   
/*     */   public static int[] bufferedImageToPixelArray(BufferedImage image) {
/* 114 */     int width = image.getWidth();
/* 115 */     int height = image.getHeight();
/* 116 */     int[] pixels = new int[width * height];
/* 117 */     image.getRGB(0, 0, width, height, pixels, 0, width);
/* 118 */     return pixels;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Image base64ToImage(String base64String) throws IOException {
/* 124 */     String cleanBase64String = base64String.replaceAll("\\s+", "");
/* 125 */     byte[] imageBytes = Base64.getDecoder().decode(cleanBase64String);
/*     */ 
/*     */     
/* 128 */     ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
/*     */ 
/*     */     
/* 131 */     BufferedImage image = ImageIO.read(bis);
/*     */ 
/*     */     
/* 134 */     bis.close();
/*     */     
/* 136 */     return new Image(image);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image resize(int newWidth, int newHeight) {
/* 141 */     int scaleX = (this.width << 16) / newWidth;
/* 142 */     int scaleY = (this.height << 16) / newHeight;
/*     */ 
/*     */     
/* 145 */     int[] scaledPixels = new int[newWidth * newHeight];
/*     */ 
/*     */     
/* 148 */     for (int y = 0; y < newHeight; y++) {
/* 149 */       for (int x = 0; x < newWidth; x++) {
/*     */         
/* 151 */         int srcX = x * scaleX >> 16;
/* 152 */         int srcY = y * scaleY >> 16;
/*     */ 
/*     */         
/* 155 */         if (srcX >= 0 && srcX < this.width && srcY >= 0 && srcY < this.height) {
/* 156 */           scaledPixels[x + y * newWidth] = this.pixels[srcX + srcY * this.width];
/*     */         }
/*     */       } 
/*     */     } 
/* 160 */     return new Image(scaledPixels, newWidth, newHeight);
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/* 164 */     return new Rectangle(0, 0, this.width, this.height);
/*     */   }
/*     */   
/*     */   public int[][] getMask() {
/* 168 */     int[][] mask = new int[this.width][this.height];
/* 169 */     for (int x = 0; x < this.width; x++) {
/* 170 */       for (int y = 0; y < this.height; y++) {
/* 171 */         if (getRGB(x, y) != 16711935)
/* 172 */           mask[x][y] = 1; 
/*     */       } 
/*     */     } 
/* 175 */     return mask;
/*     */   }
/*     */   
/*     */   public void show() {
/* 179 */     final BufferedImage mainImage = toBufferedImage();
/* 180 */     JFrame f = new JFrame();
/* 181 */     f.setDefaultCloseOperation(1);
/*     */     
/* 183 */     f.getContentPane().add(new JPanel()
/*     */         {
/*     */           private static final long serialVersionUID = 1L;
/*     */           
/*     */           protected void paintComponent(Graphics g) {
/* 188 */             super.paintComponent(g);
/* 189 */             g.drawImage(mainImage, 0, 0, null);
/*     */           }
/*     */         });
/* 192 */     f.setSize(mainImage.getWidth() + 50, mainImage.getHeight() + 50);
/* 193 */     f.setLocationRelativeTo(null);
/* 194 */     f.setVisible(true);
/*     */   }
/*     */   
/*     */   public int getRGB(int x, int y) {
/* 198 */     if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
/* 199 */       throw new IllegalArgumentException("Coordinates out of bounds: " + x + ", " + y + " [Image w: " + this.width + " h: " + this.height + "]");
/*     */     }
/* 201 */     return this.pixels[y * this.width + x];
/*     */   }
/*     */   
/*     */   public void setRGB(int x, int y, int rgb) {
/* 205 */     if (x < 0 || x >= this.width || y < 0 || y >= this.height) {
/* 206 */       throw new IllegalArgumentException("Coordinates out of bounds: " + x + ", " + y + " [Image w: " + this.width + " h: " + this.height + "]");
/*     */     }
/* 208 */     this.pixels[y * this.width + x] = rgb;
/*     */   }
/*     */   
/*     */   public SearchableImage toSearchableImage(ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 212 */     return new SearchableImage(this.pixels, this.width, this.height, toleranceComparator, colorModel);
/*     */   }
/*     */   
/*     */   public int[] getPixels() {
/* 216 */     return this.pixels;
/*     */   }
/*     */   
/*     */   public void setPixels(int[] pixels) {
/* 220 */     if (pixels.length != this.pixels.length) {
/* 221 */       throw new IllegalArgumentException("Destination pixels array length does not match the source length.");
/*     */     }
/* 223 */     System.arraycopy(this.pixels, 0, pixels, 0, pixels.length);
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 227 */     return this.width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 231 */     return this.height;
/*     */   }
/*     */   
/*     */   public Image subImage(Rectangle rectangle) {
/* 235 */     return subImage(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
/*     */   }
/*     */   
/*     */   public Image subImage(int x, int y, int subWidth, int subHeight) {
/* 239 */     if (x < 0 || y < 0 || subWidth <= 0 || subHeight <= 0 || x + subWidth > this.width || y + subHeight > this.height) {
/* 240 */       throw new IllegalArgumentException("Invalid subimage dimensions. x: " + x + ", y: " + y + ", subWidth: " + subWidth + ", subHeight: " + subHeight);
/*     */     }
/*     */     
/* 243 */     int[] subPixels = new int[subWidth * subHeight];
/* 244 */     for (int dy = 0; dy < subHeight; dy++) {
/* 245 */       for (int dx = 0; dx < subWidth; dx++) {
/* 246 */         subPixels[dy * subWidth + dx] = this.pixels[(y + dy) * this.width + x + dx];
/*     */       }
/*     */     } 
/*     */     
/* 250 */     return new Image(subPixels, subWidth, subHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image copy() {
/* 255 */     int[] copiedPixels = new int[this.pixels.length];
/* 256 */     System.arraycopy(this.pixels, 0, copiedPixels, 0, this.pixels.length);
/* 257 */     return new Image(copiedPixels, this.width, this.height);
/*     */   }
/*     */   
/*     */   public BufferedImage toBufferedImage() {
/* 261 */     int[] pixelsArray = this.pixels;
/*     */ 
/*     */     
/* 264 */     for (int i = 0; i < this.pixels.length; i++) {
/* 265 */       this.pixels[i] = 0xFF000000 | this.pixels[i] & 0xFFFFFF;
/*     */     }
/*     */     
/* 268 */     BufferedImage bufferedImage = null;
/*     */     try {
/* 270 */       bufferedImage = new BufferedImage(this.width, this.height, 2);
/* 271 */       int[] data = ((DataBufferInt)bufferedImage.getRaster().getDataBuffer()).getData();
/* 272 */       System.arraycopy(pixelsArray, 0, data, 0, pixelsArray.length);
/* 273 */     } catch (Exception e) {
/* 274 */       e.printStackTrace();
/*     */     } 
/* 276 */     return bufferedImage;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\Image.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */