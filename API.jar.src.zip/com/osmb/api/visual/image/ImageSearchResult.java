/*    */ package com.osmb.api.visual.image;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import java.awt.Point;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ public class ImageSearchResult
/*    */ {
/*    */   protected final int x;
/*    */   protected final int y;
/*    */   protected final int width;
/*    */   protected final int height;
/*    */   private final UUID screenUpdateUUID;
/*    */   private final SearchableImage foundImage;
/*    */   private final long searchTime;
/*    */   
/*    */   public ImageSearchResult(ImageSearchResult result) {
/* 19 */     this.x = result.getX();
/* 20 */     this.y = result.getY();
/* 21 */     this.width = result.getWidth();
/* 22 */     this.height = result.getHeight();
/* 23 */     this.screenUpdateUUID = result.getScreenUpdateUUID();
/* 24 */     this.foundImage = result.getFoundImage();
/* 25 */     this.searchTime = result.getSearchTime();
/*    */   }
/*    */   
/*    */   public ImageSearchResult(SearchableImage foundImage, int x, int y, int w, int h, UUID screenUpdateUUID, long searchTime) {
/* 29 */     this.x = x;
/* 30 */     this.y = y;
/* 31 */     this.width = w;
/* 32 */     this.height = h;
/* 33 */     this.screenUpdateUUID = screenUpdateUUID;
/* 34 */     this.foundImage = foundImage;
/* 35 */     this.searchTime = searchTime;
/*    */   }
/*    */   
/*    */   public long getSearchTime() {
/* 39 */     return this.searchTime;
/*    */   }
/*    */   
/*    */   public UUID getScreenUpdateUUID() {
/* 43 */     return this.screenUpdateUUID;
/*    */   }
/*    */   
/*    */   public Point getAsPoint() {
/* 47 */     return new Point(this.x, this.y);
/*    */   }
/*    */   
/*    */   public Rectangle getBounds() {
/* 51 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*    */   }
/*    */   
/*    */   public int getX() {
/* 55 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 59 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getWidth() {
/* 63 */     return this.width;
/*    */   }
/*    */   
/*    */   public int getHeight() {
/* 67 */     return this.height;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return "X: " + this.x + " Y: " + this.y + " Width: " + this.width + " Height: " + this.height;
/*    */   }
/*    */   
/*    */   public SearchableImage getFoundImage() {
/* 76 */     return this.foundImage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\ImageSearchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */