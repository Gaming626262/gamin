/*    */ package com.osmb.api.visual.image;
/*    */ 
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class VersionedImage
/*    */   extends Image {
/*    */   private final UUID uuid;
/*    */   
/*    */   public VersionedImage(UUID uuid, int[] pixels, int width, int height) {
/* 10 */     super(pixels, width, height);
/* 11 */     this.uuid = uuid;
/*    */   }
/*    */   
/*    */   public UUID getUuid() {
/* 15 */     return this.uuid;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\VersionedImage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */