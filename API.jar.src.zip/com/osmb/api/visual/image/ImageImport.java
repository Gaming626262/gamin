/*    */ package com.osmb.api.visual.image;
/*    */ 
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*    */ 
/*    */ public class ImageImport
/*    */ {
/*    */   private final String imageName;
/*    */   private final ToleranceComparator toleranceComparator;
/*    */   private final ColorModel colorModel;
/*    */   
/*    */   public ImageImport(String imageName, ColorModel colorModel) {
/* 14 */     this.imageName = imageName;
/* 15 */     this.toleranceComparator = (ToleranceComparator)new SingleThresholdComparator(0);
/* 16 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public ImageImport(String imageName, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 20 */     this.imageName = imageName;
/* 21 */     this.toleranceComparator = toleranceComparator;
/* 22 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public String getImageName() {
/* 26 */     return this.imageName;
/*    */   }
/*    */ 
/*    */   
/*    */   public ToleranceComparator getToleranceComarator() {
/* 31 */     return this.toleranceComparator;
/*    */   }
/*    */   
/*    */   public ColorModel getColorModel() {
/* 35 */     return this.colorModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\ImageImport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */