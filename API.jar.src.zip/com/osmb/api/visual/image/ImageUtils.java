/*    */ package com.osmb.api.visual.image;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.stream.IntStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageUtils
/*    */ {
/*    */   public static int compareImages(Image image1, Image image2) {
/* 16 */     if (image1 == null || image2 == null) {
/* 17 */       throw new IllegalArgumentException("Both images must not be null.");
/*    */     }
/*    */     
/* 20 */     int width = image1.getWidth();
/* 21 */     int height = image1.getHeight();
/*    */ 
/*    */     
/* 24 */     if (width != image2.getWidth() || height != image2.getHeight()) {
/* 25 */       throw new IllegalArgumentException("Both images must have the same dimensions.");
/*    */     }
/*    */     
/* 28 */     AtomicInteger differentPixels = new AtomicInteger(0);
/*    */ 
/*    */     
/* 31 */     IntStream.range(0, height).parallel().forEach(y -> {
/*    */           for (int x = 0; x < width; x++) {
/*    */             int rgb1 = image1.getRGB(x, y);
/*    */             
/*    */             int rgb2 = image2.getRGB(x, y);
/*    */             
/*    */             if (rgb1 != rgb2) {
/*    */               differentPixels.incrementAndGet();
/*    */             }
/*    */           } 
/*    */         });
/* 42 */     return differentPixels.get();
/*    */   }
/*    */   
/*    */   public static Image rotate(Image image, int yaw) {
/* 46 */     int centerX = image.width / 2;
/* 47 */     int centerY = image.height / 2;
/* 48 */     return rotate(image, centerX, centerY, yaw, 256);
/*    */   }
/*    */   
/*    */   public static Image rotate(Image image, int anchorX, int anchorY, int yaw, int zoom) {
/* 52 */     int width = image.width;
/* 53 */     int height = image.height;
/* 54 */     int[] pixels = image.pixels;
/*    */     
/* 56 */     int[] rotatedPixels = new int[width * height];
/*    */     
/* 58 */     int centerX = -width / 2;
/* 59 */     int centerY = -height / 2;
/* 60 */     int sin = (int)(Math.sin(yaw / 326.11D) * 65536.0D);
/* 61 */     int cos = (int)(Math.cos(yaw / 326.11D) * 65536.0D);
/* 62 */     sin = sin * zoom >> 8;
/* 63 */     cos = cos * zoom >> 8;
/* 64 */     int leftX = (anchorX << 16) + centerY * sin + centerX * cos;
/* 65 */     int leftY = (anchorY << 16) + centerY * cos - centerX * sin;
/*    */     
/* 67 */     for (int y = 0; y < height; y++) {
/* 68 */       int dstX = leftX;
/* 69 */       int dstY = leftY;
/* 70 */       for (int x = 0; x < width; x++) {
/* 71 */         int srcX = dstX >> 16;
/* 72 */         int srcY = dstY >> 16;
/*    */ 
/*    */         
/* 75 */         if (srcX >= 0 && srcX < width && srcY >= 0 && srcY < height) {
/* 76 */           int rgb = pixels[srcX + srcY * width];
/* 77 */           if (rgb != 0) {
/* 78 */             rotatedPixels[x + y * width] = rgb;
/*    */           }
/*    */         } 
/*    */         
/* 82 */         dstX += cos;
/* 83 */         dstY -= sin;
/*    */       } 
/* 85 */       leftX += sin;
/* 86 */       leftY += cos;
/*    */     } 
/*    */     
/* 89 */     Image rotatedImage = new Image(rotatedPixels, width, height);
/* 90 */     return rotatedImage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\ImageUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */