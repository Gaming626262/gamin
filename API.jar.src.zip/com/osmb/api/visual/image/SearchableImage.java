/*    */ package com.osmb.api.visual.image;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.definition.SpriteDefinition;
/*    */ import com.osmb.api.visual.SearchablePixel;
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class SearchableImage
/*    */   extends Image
/*    */ {
/* 15 */   private final List<SearchablePixel> doesNotContainPixels = new ArrayList<>();
/* 16 */   private final List<SearchablePixel> doesContainPixels = new ArrayList<>();
/*    */   private final ColorModel colorModel;
/*    */   private ToleranceComparator toleranceComparator;
/*    */   
/*    */   public SearchableImage(Image image, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 21 */     super(image.pixels, image.width, image.height);
/* 22 */     this.toleranceComparator = toleranceComparator;
/* 23 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public SearchableImage(SpriteDefinition sprite, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 27 */     super(sprite);
/* 28 */     this.toleranceComparator = toleranceComparator;
/* 29 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public SearchableImage(int spriteID, ScriptCore core, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 33 */     super(spriteID, core);
/* 34 */     this.toleranceComparator = toleranceComparator;
/* 35 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public SearchableImage(int[] pixels, int width, int height, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 39 */     super(pixels, width, height);
/* 40 */     this.toleranceComparator = toleranceComparator;
/* 41 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public SearchableImage(int[] pixels, int width, int height, ToleranceComparator toleranceComparator, ColorModel colorModel, List<SearchablePixel> doesNotContainPixels, List<SearchablePixel> doesContainPixels) {
/* 45 */     super(pixels, width, height);
/* 46 */     this.toleranceComparator = toleranceComparator;
/* 47 */     this.colorModel = colorModel;
/* 48 */     this.doesContainPixels.addAll(doesContainPixels);
/* 49 */     this.doesNotContainPixels.addAll(doesNotContainPixels);
/*    */   }
/*    */   
/*    */   public SearchableImage(BufferedImage image, ToleranceComparator toleranceComparator, ColorModel colorModel) {
/* 53 */     super(image);
/* 54 */     this.toleranceComparator = toleranceComparator;
/* 55 */     this.colorModel = colorModel;
/*    */   }
/*    */   
/*    */   public SearchableImage(BufferedImage image, ToleranceComparator toleranceComparator, ColorModel colorModel, List<SearchablePixel> doesNotContainPixels, List<SearchablePixel> doesContainPixels) {
/* 59 */     super(image);
/* 60 */     this.toleranceComparator = toleranceComparator;
/* 61 */     this.colorModel = colorModel;
/* 62 */     this.doesContainPixels.addAll(doesContainPixels);
/* 63 */     this.doesNotContainPixels.addAll(doesNotContainPixels);
/*    */   }
/*    */   
/*    */   public ToleranceComparator getToleranceComparator() {
/* 67 */     return this.toleranceComparator;
/*    */   }
/*    */   
/*    */   public void setToleranceComparator(ToleranceComparator toleranceComparator) {
/* 71 */     this.toleranceComparator = toleranceComparator;
/*    */   }
/*    */   
/*    */   public List<SearchablePixel> getDoesNotContainPixels() {
/* 75 */     return this.doesNotContainPixels;
/*    */   }
/*    */   
/*    */   public List<SearchablePixel> getDoesContainPixels() {
/* 79 */     return this.doesContainPixels;
/*    */   }
/*    */   
/*    */   public ColorModel getColorModel() {
/* 83 */     return this.colorModel;
/*    */   }
/*    */ 
/*    */   
/*    */   public SearchableImage subImage(int x, int y, int subWidth, int subHeight) {
/* 88 */     if (x < 0 || y < 0 || subWidth <= 0 || subHeight <= 0 || x + subWidth > this.width || y + subHeight > this.height) {
/* 89 */       throw new IllegalArgumentException("Invalid subimage dimensions");
/*    */     }
/*    */     
/* 92 */     int[] subPixels = new int[subWidth * subHeight];
/* 93 */     for (int dy = 0; dy < subHeight; dy++) {
/* 94 */       for (int dx = 0; dx < subWidth; dx++) {
/* 95 */         subPixels[dy * subWidth + dx] = this.pixels[(y + dy) * this.width + x + dx];
/*    */       }
/*    */     } 
/*    */     
/* 99 */     return new SearchableImage(subPixels, subWidth, subHeight, this.toleranceComparator, this.colorModel);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\visual\image\SearchableImage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */