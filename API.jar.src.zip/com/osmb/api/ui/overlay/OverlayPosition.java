/*    */ package com.osmb.api.ui.overlay;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum OverlayPosition
/*    */ {
/*  8 */   TOP_LEFT(OverlayShiftDirection.DOWN, HorizontalEdge.LEFT, VerticalEdge.TOP),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 13 */   TOP_CENTER(OverlayShiftDirection.DOWN, HorizontalEdge.LEFT, VerticalEdge.TOP),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 19 */   TOP_RIGHT(OverlayShiftDirection.DOWN, HorizontalEdge.RIGHT, VerticalEdge.TOP),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   BOTTOM_LEFT(OverlayShiftDirection.RIGHT, HorizontalEdge.LEFT, VerticalEdge.BOTTOM),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 30 */   BOTTOM_RIGHT(OverlayShiftDirection.UP, HorizontalEdge.RIGHT, VerticalEdge.BOTTOM),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   BOUNDARY_BOTTOM_RIGHT(OverlayShiftDirection.LEFT, HorizontalEdge.RIGHT, VerticalEdge.BOTTOM),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   BOUNDARY_TOP_RIGHT(OverlayShiftDirection.NONE, HorizontalEdge.RIGHT, VerticalEdge.TOP);
/*    */   private final OverlayShiftDirection overlayShiftDirection;
/*    */   private final HorizontalEdge horizontalEdge;
/*    */   private final VerticalEdge verticalEdge;
/*    */   
/*    */   public HorizontalEdge getHorizontalEdge() {
/* 47 */     return this.horizontalEdge;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   OverlayPosition(OverlayShiftDirection overlayShiftDirection, HorizontalEdge horizontalEdge, VerticalEdge verticalEdge) {
/* 54 */     this.overlayShiftDirection = overlayShiftDirection;
/* 55 */     this.horizontalEdge = horizontalEdge;
/* 56 */     this.verticalEdge = verticalEdge;
/*    */   }
/*    */   
/*    */   public VerticalEdge getVerticalEdge() {
/* 60 */     return this.verticalEdge;
/*    */   }
/*    */   
/*    */   public OverlayShiftDirection getOverlayShiftDirection() {
/* 64 */     return this.overlayShiftDirection;
/*    */   }
/*    */   
/*    */   public enum HorizontalEdge {
/* 68 */     LEFT,
/* 69 */     RIGHT;
/*    */   }
/*    */   
/*    */   public enum VerticalEdge {
/* 73 */     TOP,
/* 74 */     BOTTOM;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\overlay\OverlayPosition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */