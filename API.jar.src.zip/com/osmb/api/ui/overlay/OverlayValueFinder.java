/*    */ package com.osmb.api.ui.overlay;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import java.util.function.Function;
/*    */ 
/*    */ public class OverlayValueFinder<T>
/*    */ {
/*    */   private final String key;
/*    */   private final Function<Rectangle, T> valueFinder;
/*    */   
/*    */   public OverlayValueFinder(String key, Function<Rectangle, T> valueFinder) {
/* 12 */     this.key = key;
/* 13 */     this.valueFinder = valueFinder;
/*    */   }
/*    */   
/*    */   public String key() {
/* 17 */     return this.key;
/*    */   }
/*    */   
/*    */   public T findValue(Rectangle overlayBounds) {
/* 21 */     return this.valueFinder.apply(overlayBounds);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 26 */     return this.key;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\overlay\OverlayValueFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */