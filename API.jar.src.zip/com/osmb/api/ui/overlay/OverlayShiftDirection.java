/*   */ package com.osmb.api.ui.overlay;
/*   */ 
/*   */ public enum OverlayShiftDirection {
/* 4 */   UP,
/* 5 */   DOWN,
/* 6 */   LEFT,
/* 7 */   RIGHT,
/* 8 */   NONE;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\overlay\OverlayShiftDirection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */