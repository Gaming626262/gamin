/*     */ package com.osmb.api.ui.overlay;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.component.chatbox.ChatboxComponent;
/*     */ import com.osmb.api.ui.component.minimap.xpcounter.XPDropsComponent;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.utils.CachedObject;
/*     */ import java.awt.Point;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OverlayBoundary
/*     */ {
/*     */   private final List<OverlayValueFinder> valueFinders;
/*     */   protected ScriptCore core;
/*     */   private CachedObject<Rectangle> result;
/*  21 */   private Map<String, CachedObject> foundValues = new HashMap<>();
/*     */   
/*     */   public OverlayBoundary(ScriptCore core) {
/*  24 */     this.core = core;
/*  25 */     this.valueFinders = applyValueFinders();
/*     */   }
/*     */   
/*     */   public static Rectangle transformOverlayPosition(ScriptCore core, OverlayPosition overlayPosition, Rectangle rectangle) {
/*  29 */     int newX = rectangle.x;
/*  30 */     int newY = rectangle.y;
/*  31 */     if (overlayPosition == OverlayPosition.TOP_RIGHT) {
/*     */       
/*  33 */       XPDropsComponent xpDropsComponent = (XPDropsComponent)core.getWidgetManager().getComponent(XPDropsComponent.class);
/*  34 */       if (xpDropsComponent.isOpen()) {
/*  35 */         newY += 42;
/*     */       }
/*     */     } 
/*     */     
/*  39 */     if (overlayPosition == OverlayPosition.TOP_RIGHT || overlayPosition == OverlayPosition.BOTTOM_RIGHT || overlayPosition == OverlayPosition.BOUNDARY_BOTTOM_RIGHT) {
/*     */       
/*  41 */       Container container = (Container)core.getWidgetManager().getComponent(Container.class);
/*  42 */       Rectangle containerBounds = container.getBounds();
/*     */       
/*  44 */       if (containerBounds != null) {
/*  45 */         int type = ((Integer)container.getResult().getComponentImage().getGameFrameStatusType()).intValue();
/*  46 */         switch (overlayPosition) { case UP:
/*  47 */             newX -= (type == 1) ? 48 : 50; break;
/*  48 */           case DOWN: newX -= containerBounds.width; break;
/*  49 */           case LEFT: newX -= containerBounds.width; break; }
/*     */       
/*     */       } 
/*     */     } 
/*  53 */     ChatboxComponent chatboxComponent = (ChatboxComponent)core.getWidgetManager().getComponent(ChatboxComponent.class);
/*     */     
/*  55 */     if (chatboxComponent.isOpen() && (
/*  56 */       overlayPosition == OverlayPosition.TOP_CENTER || overlayPosition == OverlayPosition.TOP_LEFT))
/*     */     {
/*  58 */       newY += 145;
/*     */     }
/*     */     
/*  61 */     return new Rectangle(newX, newY, rectangle.width, rectangle.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void find() {
/*  78 */     int[] deadzoneBorder = this.core.getWidgetManager().getDeadZoneBorder();
/*  79 */     if (deadzoneBorder == null) {
/*     */       return;
/*     */     }
/*  82 */     OverlayPosition overlayPosition = getOverlayPosition();
/*  83 */     Point overlayOffset = getOverlayOffset();
/*     */     
/*  85 */     int boundaryX = (overlayPosition.getHorizontalEdge() == OverlayPosition.HorizontalEdge.LEFT) ? deadzoneBorder[3] : deadzoneBorder[1];
/*  86 */     int boundaryY = (overlayPosition.getVerticalEdge() == OverlayPosition.VerticalEdge.TOP) ? deadzoneBorder[0] : deadzoneBorder[2];
/*  87 */     Rectangle overlayBounds = new Rectangle(boundaryX + overlayOffset.x, boundaryY + overlayOffset.y, getWidth(), getHeight());
/*  88 */     Rectangle transformedBounds = transformOverlayPosition(this.core, overlayPosition, overlayBounds);
/*     */     
/*  90 */     if (checkVisibility(transformedBounds)) {
/*  91 */       this.result = new CachedObject(this.core.getScreen().getUUID(), transformedBounds);
/*  92 */       onOverlayFound(transformedBounds);
/*  93 */       executeValueFinders(transformedBounds);
/*     */       
/*     */       return;
/*     */     } 
/*  97 */     Rectangle screenBounds = this.core.getScreen().getBounds();
/*     */     while (true) {
/*  99 */       shiftBounds(transformedBounds, overlayPosition.getOverlayShiftDirection(), 1);
/* 100 */       if (!screenBounds.contains(transformedBounds)) {
/* 101 */         this.result = null;
/* 102 */         onOverlayNotFound();
/* 103 */         nullifyValueResults();
/*     */         return;
/*     */       } 
/* 106 */       if (checkVisibility(transformedBounds)) {
/* 107 */         this.result = new CachedObject(this.core.getScreen().getUUID(), transformedBounds);
/* 108 */         onOverlayFound(transformedBounds);
/* 109 */         executeValueFinders(transformedBounds);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getValue(String key) {
/* 116 */     if (this.foundValues == null) {
/* 117 */       return null;
/*     */     }
/* 119 */     CachedObject value = this.foundValues.get(key);
/* 120 */     if (value == null || value.getScreenUUID() != this.core.getScreen().getUUID()) {
/* 121 */       find();
/* 122 */       if (this.foundValues.containsKey(key)) {
/* 123 */         value = this.foundValues.get(key);
/*     */       } else {
/* 125 */         return null;
/*     */       } 
/*     */     } 
/* 128 */     return value.getObject();
/*     */   }
/*     */   
/*     */   private void nullifyValueResults() {
/* 132 */     this.valueFinders.forEach(overlayValueFinder -> {
/*     */           String key = overlayValueFinder.key();
/*     */           CachedObject value = new CachedObject(this.core.getScreen().getUUID(), null);
/*     */           this.foundValues.put(key, value);
/*     */         });
/*     */   }
/*     */   
/*     */   private void executeValueFinders(Rectangle bounds) {
/* 140 */     this.valueFinders.forEach(overlayValueFinder -> {
/*     */           String key = overlayValueFinder.key();
/*     */           CachedObject value = new CachedObject(this.core.getScreen().getUUID(), overlayValueFinder.findValue(bounds));
/*     */           this.foundValues.put(key, value);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 152 */     return (getBounds() != null);
/*     */   }
/*     */   
/*     */   public Rectangle getBounds() {
/* 156 */     if (this.result == null || this.result.getScreenUUID() != this.core.getScreen().getUUID()) {
/* 157 */       find();
/*     */     }
/* 159 */     if (this.result != null && this.result.getObject() != null) {
/* 160 */       return (Rectangle)this.result.getObject();
/*     */     }
/* 162 */     return null;
/*     */   }
/*     */   
/*     */   private void shiftBounds(Rectangle bounds, OverlayShiftDirection direction, int shiftAmount) {
/* 166 */     switch (direction) {
/*     */       case UP:
/* 168 */         bounds.y -= shiftAmount;
/*     */       
/*     */       case DOWN:
/* 171 */         bounds.y += shiftAmount;
/*     */       
/*     */       case LEFT:
/* 174 */         bounds.x -= shiftAmount;
/*     */       
/*     */       case RIGHT:
/* 177 */         bounds.x += shiftAmount;
/*     */       
/*     */       case NONE:
/*     */         return;
/*     */     } 
/*     */     
/* 183 */     throw new IllegalArgumentException("Unknown direction: " + direction);
/*     */   }
/*     */   
/*     */   public abstract int getWidth();
/*     */   
/*     */   public abstract int getHeight();
/*     */   
/*     */   protected abstract boolean checkVisibility(Rectangle paramRectangle);
/*     */   
/*     */   public abstract OverlayPosition getOverlayPosition();
/*     */   
/*     */   public abstract Point getOverlayOffset();
/*     */   
/*     */   public abstract List<OverlayValueFinder> applyValueFinders();
/*     */   
/*     */   public abstract void onOverlayFound(Rectangle paramRectangle);
/*     */   
/*     */   public abstract void onOverlayNotFound();
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\overlay\OverlayBoundary.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */