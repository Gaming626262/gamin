/*    */ package com.osmb.api.ui.bank;
/*    */ 
/*    */ public enum BankButtonType
/*    */   implements BankButtonIdentityType
/*    */ {
/*  6 */   CLOSE(Integer.valueOf(1731)),
/*  7 */   DEPOSIT_EQUIPMENT(Integer.valueOf(1042)),
/*  8 */   DEPOSIT_INVENTORY(Integer.valueOf(1041)),
/*  9 */   SEARCH(Integer.valueOf(1043)),
/* 10 */   WITHDRAW_AS_ITEM("Item"),
/* 11 */   WITHDRAW_AS_NOTE("Note");
/*    */   
/*    */   private final Object identifier;
/*    */   
/*    */   BankButtonType(Object identifier) {
/* 16 */     this.identifier = identifier;
/*    */   }
/*    */   
/*    */   public Object getIdentifier() {
/* 20 */     return this.identifier;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\bank\BankButtonType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */