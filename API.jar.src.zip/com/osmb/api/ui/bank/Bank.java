package com.osmb.api.ui.bank;

import com.osmb.api.item.ItemGroup;
import com.osmb.api.ui.Viewable;
import com.osmb.api.utils.UIResult;

public interface Bank extends Viewable, ItemGroup {
  boolean withdraw(int paramInt1, int paramInt2);
  
  int getFreeBankSlots();
  
  boolean deposit(int paramInt1, int paramInt2);
  
  boolean depositAllIgnoreSlots(int[] paramArrayOfint);
  
  boolean depositAll(int[] paramArrayOfint);
  
  boolean depositAll(int[] paramArrayOfint1, int[] paramArrayOfint2);
  
  UIResult<Integer> getSelectedTabIndex();
  
  boolean setSelectedTabIndex(int paramInt);
  
  boolean close();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\bank\Bank.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */