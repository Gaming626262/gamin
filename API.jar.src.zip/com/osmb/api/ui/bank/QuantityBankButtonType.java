/*    */ package com.osmb.api.ui.bank;
/*    */ 
/*    */ public enum QuantityBankButtonType implements BankButtonIdentityType {
/*  4 */   QUANTITY_1("1", 1),
/*  5 */   QUANTITY_5("5", 5),
/*  6 */   QUANTITY_10("10", 10),
/*  7 */   QUANTITY_X("X", -1),
/*  8 */   QUANTITY_ALL("All", 28);
/*    */   
/*    */   private final String identifier;
/*    */   private final int amount;
/*    */   
/*    */   QuantityBankButtonType(String identifier, int amount) {
/* 14 */     this.identifier = identifier;
/* 15 */     this.amount = amount;
/*    */   }
/*    */   
/*    */   public static QuantityBankButtonType getWithdrawlAmount(int amount) {
/* 19 */     switch (amount) {
/*    */       case 1:
/* 21 */         return QUANTITY_1;
/*    */       
/*    */       case 5:
/* 24 */         return QUANTITY_5;
/*    */       
/*    */       case 10:
/* 27 */         return QUANTITY_10;
/*    */     } 
/*    */     
/* 30 */     return QUANTITY_X;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAmount() {
/* 36 */     return this.amount;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 40 */     return this.identifier;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\bank\QuantityBankButtonType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */