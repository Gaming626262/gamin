/*    */ package com.osmb.api.ui.bank;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ 
/*    */ public class BankButton {
/*    */   private final SearchableImage selectedImage;
/*    */   private final SearchableImage unselectedImage;
/*    */   private final Rectangle bounds;
/*    */   
/*    */   public BankButton(SearchableImage selectedImage, SearchableImage unselectedImage, Rectangle bounds) {
/* 12 */     this.selectedImage = selectedImage;
/* 13 */     this.unselectedImage = unselectedImage;
/* 14 */     this.bounds = bounds;
/*    */   }
/*    */   public SearchableImage getSelectedImage() {
/* 17 */     return this.selectedImage;
/*    */   }
/*    */   
/*    */   public SearchableImage getUnselectedImage() {
/* 21 */     return this.unselectedImage;
/*    */   }
/*    */   
/*    */   public Rectangle getBounds() {
/* 25 */     return this.bounds;
/*    */   }
/*    */   
/*    */   public Rectangle getScreenBounds(Rectangle bankBounds) {
/* 29 */     return new Rectangle(bankBounds.x + this.bounds.x, bankBounds.y + this.bounds.y, this.bounds.width, this.bounds.height);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\bank\BankButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */