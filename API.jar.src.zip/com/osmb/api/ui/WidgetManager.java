package com.osmb.api.ui;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.shape.Shape;
import com.osmb.api.ui.bank.Bank;
import com.osmb.api.ui.chatbox.Chatbox;
import com.osmb.api.ui.chatbox.dialogue.Dialogue;
import com.osmb.api.ui.component.Component;
import com.osmb.api.ui.hotkeys.Hotkeys;
import com.osmb.api.ui.minimap.Compass;
import com.osmb.api.ui.minimap.Minimap;
import com.osmb.api.ui.minimap.MinimapOrbs;
import com.osmb.api.ui.tabs.Equipment;
import com.osmb.api.ui.tabs.Inventory;
import com.osmb.api.ui.tabs.Logout;
import com.osmb.api.ui.tabs.Prayer;
import com.osmb.api.ui.tabs.Settings;
import com.osmb.api.ui.tabs.Spellbook;
import com.osmb.api.ui.tabs.TabManager;
import java.awt.Point;
import java.util.List;
import java.util.Map;

public interface WidgetManager {
  Equipment getEquipment();
  
  Bank getBank();
  
  MinimapOrbs getMinimapOrbs();
  
  Hotkeys getHotkeys();
  
  Settings getSettings();
  
  Minimap getMinimap();
  
  Compass getCompass();
  
  GameState getGameState();
  
  Prayer getPrayerTab();
  
  boolean isGameScreen(Point paramPoint);
  
  boolean isInsideGameFrame(int paramInt1, int paramInt2);
  
  boolean insideGameScreen(Shape paramShape);
  
  List<Rectangle> getGameFrameBoundaries();
  
  List<Rectangle> getGameFrameBoundaries(Class<? extends Component>... paramVarArgs);
  
  TabManager getTabManager();
  
  Inventory getInventory();
  
  Chatbox getChatbox();
  
  Dialogue getDialogue();
  
  Logout getLogoutTab();
  
  Component getComponent(Class<? extends Component> paramClass);
  
  int[] getDeadZoneBorder();
  
  Rectangle getCenterComponentBounds();
  
  void addComponent(Component paramComponent);
  
  Map<Class<? extends Component>, Component> getActiveComponents();
  
  Spellbook getSpellbook();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\WidgetManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */