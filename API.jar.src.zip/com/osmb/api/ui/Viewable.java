package com.osmb.api.ui;

import com.osmb.api.shape.Rectangle;

public interface Viewable {
  boolean isVisible();
  
  Rectangle getBounds();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\Viewable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */