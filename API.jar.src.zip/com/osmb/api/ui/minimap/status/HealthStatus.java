/*    */ package com.osmb.api.ui.minimap.status;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum HealthStatus
/*    */ {
/*  7 */   NORMAL(1060),
/*  8 */   POISONED(1061),
/*  9 */   VENOMED(1102),
/* 10 */   DISEASED(1062);
/*    */   
/*    */   private final int spriteUnderlayID;
/*    */   
/*    */   HealthStatus(int spriteUnderlayID) {
/* 15 */     this.spriteUnderlayID = spriteUnderlayID;
/*    */   }
/*    */   
/*    */   public int getSpriteUnderlayID() {
/* 19 */     return this.spriteUnderlayID;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\minimap\status\HealthStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */