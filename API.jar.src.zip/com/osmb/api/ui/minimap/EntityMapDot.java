/*   */ package com.osmb.api.ui.minimap;
/*   */ 
/*   */ public enum EntityMapDot {
/* 4 */   PLAYER,
/* 5 */   ITEM,
/* 6 */   NPC;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\minimap\EntityMapDot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */