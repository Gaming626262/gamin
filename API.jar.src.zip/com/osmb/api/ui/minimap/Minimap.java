package com.osmb.api.ui.minimap;

import com.osmb.api.location.position.types.WorldPosition;
import com.osmb.api.scene.RSTile;
import com.osmb.api.utils.UIResult;
import com.osmb.api.utils.UIResultList;
import com.osmb.api.visual.image.Image;
import java.awt.Point;

public interface Minimap {
  public static final int RADIUS = 75;
  
  Point toMinimapCoordinates(WorldPosition paramWorldPosition, RSTile paramRSTile);
  
  UIResult<Point> getCenter();
  
  Point clampToMinimap(int paramInt1, int paramInt2);
  
  boolean insideMinimap(int paramInt1, int paramInt2);
  
  Image getMinimapImage(boolean paramBoolean);
  
  UIResultList<WorldPosition> getPlayerPositions();
  
  UIResultList<WorldPosition> getNPCPositions();
  
  UIResultList<WorldPosition> getItemPositions();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\minimap\Minimap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */