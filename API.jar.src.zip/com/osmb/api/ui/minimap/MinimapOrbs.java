package com.osmb.api.ui.minimap;

import com.osmb.api.ui.minimap.status.HealthStatus;
import com.osmb.api.utils.UIResult;

public interface MinimapOrbs {
  UIResult<Integer> getHitpoints();
  
  UIResult<Integer> getHitpointsPercentage();
  
  UIResult<HealthStatus> getHealthStatus();
  
  UIResult<Integer> getPrayerPoints();
  
  UIResult<Integer> getRunEnergy();
  
  UIResult<Boolean> hasStaminaEffect();
  
  UIResult<Boolean> isRunEnabled();
  
  UIResult<Integer> getSpecialAttackPercentage();
  
  UIResult<Boolean> isSpecialAttackActivated();
  
  UIResult<Boolean> isSpecialAttackEnabled();
  
  UIResult<Boolean> isQuickPrayersActivated();
  
  boolean setQuickPrayers(boolean paramBoolean);
  
  boolean setSpecialAttack(boolean paramBoolean);
  
  boolean setRun(boolean paramBoolean);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\minimap\MinimapOrbs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */