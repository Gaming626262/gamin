/*    */ package com.osmb.api.ui.minimap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Direction
/*    */ {
/* 17 */   NORTH,
/* 18 */   EAST,
/* 19 */   SOUTH,
/* 20 */   WEST;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\minimap\Compass$Direction.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */