package com.osmb.api.ui;

import com.osmb.api.definition.SpriteDefinition;
import com.osmb.api.ui.minimap.EntityMapDot;
import com.osmb.api.visual.image.Image;
import com.osmb.api.visual.image.SearchableImage;

public interface SpriteManager {
  SearchableImage[] getEntityMapDot(EntityMapDot paramEntityMapDot);
  
  SpriteDefinition getSprite(int paramInt1, int paramInt2);
  
  SpriteDefinition getSprite(int paramInt);
  
  SpriteDefinition[] getSprites(int paramInt);
  
  Image getResizedSprite(SpriteDefinition paramSpriteDefinition, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\SpriteManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */