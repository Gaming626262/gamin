/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.visual.image.ImageSearchResult;
/*    */ 
/*    */ public class ComponentSearchResult<T>
/*    */   extends ImageSearchResult {
/*    */   private final Rectangle gameFrameBoundsOverride;
/*    */   private final int iconID;
/*    */   private final ComponentImage<T> componentImage;
/*    */   
/*    */   public ComponentSearchResult(ImageSearchResult imageSearchResult, int iconID, ComponentImage<T> componentImage, Rectangle gameFrameBoundsOverride) {
/* 13 */     super(imageSearchResult);
/* 14 */     this.componentImage = componentImage;
/* 15 */     this.gameFrameBoundsOverride = gameFrameBoundsOverride;
/* 16 */     this.iconID = iconID;
/*    */   }
/*    */   
/*    */   public ComponentSearchResult(ImageSearchResult imageSearchResult, int iconID, ComponentImage<T> componentImage) {
/* 20 */     super(imageSearchResult);
/* 21 */     this.componentImage = componentImage;
/* 22 */     this.gameFrameBoundsOverride = null;
/* 23 */     this.iconID = iconID;
/*    */   }
/*    */   
/*    */   public ComponentSearchResult(ImageSearchResult imageSearchResult, ComponentImage<T> componentImage, Rectangle gameFrameBoundsOverride) {
/* 27 */     super(imageSearchResult);
/* 28 */     this.componentImage = componentImage;
/* 29 */     this.gameFrameBoundsOverride = gameFrameBoundsOverride;
/* 30 */     this.iconID = -1;
/*    */   }
/*    */   
/*    */   public ComponentSearchResult(ImageSearchResult imageSearchResult, ComponentImage<T> componentImage) {
/* 34 */     super(imageSearchResult);
/* 35 */     this.componentImage = componentImage;
/* 36 */     this.gameFrameBoundsOverride = null;
/* 37 */     this.iconID = -1;
/*    */   }
/*    */   
/*    */   public int getIconID() {
/* 41 */     return this.iconID;
/*    */   }
/*    */   
/*    */   public ComponentImage<T> getComponentImage() {
/* 45 */     return this.componentImage;
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getBounds() {
/* 50 */     if (this.gameFrameBoundsOverride != null) {
/* 51 */       return this.gameFrameBoundsOverride;
/*    */     }
/* 53 */     return super.getBounds();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentSearchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */