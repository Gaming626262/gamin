/*    */ package com.osmb.api.ui.component.chatbox;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.GameState;
/*    */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*    */ import com.osmb.api.ui.component.ComponentImage;
/*    */ import com.osmb.api.ui.component.ComponentParent;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*    */ import com.osmb.api.visual.drawing.Canvas;
/*    */ import com.osmb.api.visual.image.ImageSearchResult;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChatboxTab
/*    */   extends ComponentParent<ComponentButtonStatus>
/*    */ {
/* 25 */   private static final ToleranceComparator TOLERANCE_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(10);
/*    */   
/*    */   public ChatboxTab(ScriptCore scriptCoreService) {
/* 28 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ComponentImage<ComponentButtonStatus>> buildBackgrounds() {
/* 33 */     Canvas canvas = new Canvas(5773, this.core);
/* 34 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 35 */     SearchableImage normalTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 37 */     canvas = new Canvas(5774, this.core);
/* 38 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 39 */     SearchableImage highlightedTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 41 */     canvas = new Canvas(5775, this.core);
/* 42 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 43 */     SearchableImage redTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 45 */     ComponentImage<ComponentButtonStatus> normalTab = new ComponentImage(normalTabImage, 5773, ComponentButtonStatus.NORMAL);
/* 46 */     ComponentImage<ComponentButtonStatus> highlightedTab = new ComponentImage(highlightedTabImage, 5774, ComponentButtonStatus.HIGHLIGHTED);
/* 47 */     ComponentImage<ComponentButtonStatus> redTab = new ComponentImage(redTabImage, 5775, ComponentButtonStatus.RED);
/* 48 */     return List.of(normalTab, highlightedTab, redTab);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Integer, SearchableImage> buildIcons() {
/* 53 */     int iconID = 664;
/* 54 */     SearchableImage iconImage = new SearchableImage(iconID, this.core, TOLERANCE_COMPARATOR, ColorModel.RGB);
/* 55 */     return Map.of(Integer.valueOf(iconID), iconImage);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/* 61 */     if (containerBounds == null) {
/* 62 */       return UIResult.notVisible();
/*    */     }
/* 64 */     for (Map.Entry<Integer, SearchableImage> iconEntry : (Iterable<Map.Entry<Integer, SearchableImage>>)this.componentIcons.entrySet()) {
/* 65 */       SearchableImage image = iconEntry.getValue();
/* 66 */       int x = containerBounds.width / 2 - image.width / 2;
/* 67 */       int y = containerBounds.height / 2 - image.height / 2;
/*    */       
/* 69 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(containerBounds.x + x, containerBounds.y + y, image);
/* 70 */       if (result != null) {
/* 71 */         return UIResult.of(iconEntry.getKey());
/*    */       }
/*    */     } 
/* 74 */     return UIResult.of(null);
/*    */   }
/*    */ 
/*    */   
/*    */   public GameState getComponentGameState() {
/* 79 */     return GameState.LOGGED_IN;
/*    */   }
/*    */   
/*    */   public int[] getIcons() {
/* 83 */     return new int[] { 664 };
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\chatbox\ChatboxTab.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */