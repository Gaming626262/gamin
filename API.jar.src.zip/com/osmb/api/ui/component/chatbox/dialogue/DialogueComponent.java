/*     */ package com.osmb.api.ui.component.chatbox.dialogue;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.item.ItemManager;
/*     */ import com.osmb.api.item.ZoomType;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.chatbox.dialogue.Dialogue;
/*     */ import com.osmb.api.ui.chatbox.dialogue.DialogueType;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.ComponentParent;
/*     */ import com.osmb.api.utils.CachedObject;
/*     */ import com.osmb.api.visual.SearchablePixel;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import com.osmb.api.visual.ocr.fonts.Font;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DialogueComponent
/*     */   extends ComponentParent<Integer> implements Dialogue {
/*  32 */   private static final Rectangle CLOSE_BUTTON_BOUNDS = new Rectangle(492, 8, 17, 18);
/*  33 */   private static final Rectangle OPTION_DIALOGUE_TITLE_BOUNDS = new Rectangle(200, 17, 125, 19);
/*  34 */   private static final Rectangle ENTER_AMOUNT_TITLE_BOUNDS = new Rectangle(213, 44, 100, 16);
/*  35 */   private static final Rectangle TAP_HERE_TO_CONTINUE_TITLE_BOUNDS = new Rectangle(115, 25, 385, 18);
/*  36 */   private static final Rectangle TAP_HERE_TO_CONTINUE_BOUNDS = new Rectangle(130, 90, 270, 36);
/*  37 */   private static final Point SCROLL_BUTTON_UP_POINT = new Point(494, 28);
/*     */   private static final int TEXT_DIALOGUE_TITLE_COLOR = -8388608;
/*  39 */   private static final SearchablePixel TITLE_PIXEL = new SearchablePixel(-8388608, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */   private static final int TAP_HERE_TO_CONTINUE_COLOR = -16776961;
/*     */   private static final int ITEM_CONTAINER_HEIGHT = 72;
/*  42 */   private static final ToleranceComparator ITEM_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(5);
/*     */   private static final int FANCY_TEXT_MAX_HEIGHT = 18;
/*     */   private final SearchableImage scrollButtonUp;
/*     */   private final SearchableImage closeButtonImage;
/*     */   private int trueHeight;
/*     */   private CachedObject<List<Rectangle>> cachedContainers;
/*     */   private CachedObject<DialogueType> dialogueType;
/*     */   
/*     */   public DialogueComponent(ScriptCore core) {
/*  51 */     super(core);
/*  52 */     SpriteDefinition spriteDefinition = core.getSpriteManager().getSprite(537);
/*  53 */     this.closeButtonImage = core.getSpriteManager().getResizedSprite(spriteDefinition, 19, 18).toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  54 */     SpriteDefinition scrollUpSprite = core.getSpriteManager().getSprite(773);
/*  55 */     this.scrollButtonUp = new SearchableImage(scrollUpSprite, (ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */   }
/*     */   
/*     */   public List<SearchableImage> getItemImages(int... ids) {
/*  59 */     List<SearchableImage> itemImages = new ArrayList<>();
/*  60 */     ZoomType[] zoomTypes = ZoomType.values();
/*  61 */     for (int id : ids) {
/*     */       
/*  63 */       for (int i = zoomTypes.length - 1; i >= 0; i--) {
/*  64 */         Image itemImage = this.core.getItemManager().getItemImage(id, 10000, false, zoomTypes[i], 0, -5071493, 16711935);
/*  65 */         itemImage = itemImage.subImage(0, 2, itemImage.getWidth(), itemImage.getHeight() - 2);
/*     */         
/*  67 */         for (int pixelIndex = 0; pixelIndex < itemImage.pixels.length; pixelIndex++) {
/*  68 */           int pixel = itemImage.pixels[pixelIndex];
/*  69 */           if (pixel == -5071493) {
/*  70 */             itemImage.pixels[pixelIndex] = 16711935;
/*     */           }
/*     */         } 
/*  73 */         itemImage = itemImage.subImage(1, 0, itemImage.width - 1, itemImage.height);
/*  74 */         itemImages.add(itemImage.toSearchableImage(ItemManager.ITEM_TOLERANCE_COMPARATOR, ColorModel.RGB));
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     return itemImages;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<Integer>> buildBackgrounds() {
/*  83 */     SpriteDefinition containerSprite = this.core.getSpriteManager().getSprite(1017);
/*  84 */     Image container = new Image(containerSprite);
/*  85 */     this.trueHeight = container.height;
/*  86 */     container = container.subImage(0, 0, container.width, 6);
/*  87 */     ComponentImage<Integer> img = new ComponentImage(container.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(20), ColorModel.RGB), 1017, Integer.valueOf(0));
/*  88 */     return List.of(img);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/*  93 */     return Map.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/*  98 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 103 */     return super.isVisible();
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/* 108 */     Rectangle bounds = super.getBounds();
/* 109 */     if (bounds == null) return null; 
/* 110 */     return new Rectangle(bounds.x, bounds.y, bounds.width, this.trueHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getOptions() {
/* 115 */     DialogueType dialogueType = getDialogueType();
/* 116 */     if (dialogueType == null || dialogueType != DialogueType.TEXT_OPTION) {
/* 117 */       return null;
/*     */     }
/* 119 */     Rectangle[] lines = getTextLines(18, -16777215);
/* 120 */     if (lines == null) return null; 
/* 121 */     String[] options = new String[lines.length];
/* 122 */     for (int i = 0; i < lines.length; i++) {
/* 123 */       options[i] = this.core.getOCR().getText(Font.FANCY_STANDARD_FONT, lines[i], new int[] { -16777215 });
/*     */     } 
/* 125 */     return options;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 130 */     DialogueType dialogueType = getDialogueType();
/* 131 */     if (dialogueType == null || dialogueType != DialogueType.CHAT_DIALOGUE) {
/* 132 */       return null;
/*     */     }
/* 134 */     Rectangle bounds = getBounds();
/* 135 */     if (bounds == null) return null;
/*     */     
/* 137 */     Rectangle[] lines = getTextLines(bounds, 18, -16777215);
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     for (Rectangle line : lines) {
/* 140 */       String text = this.core.getOCR().getText(Font.FANCY_STANDARD_FONT, line, new int[] { -16777215 });
/* 141 */       sb.append(text + " ");
/*     */     } 
/* 143 */     return sb.toString().trim();
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle[] getTextLines(int maxLineHeight, int textColor) {
/* 148 */     Rectangle bounds = getBounds();
/* 149 */     if (bounds == null) return null; 
/* 150 */     return getTextLines(bounds, maxLineHeight, textColor);
/*     */   }
/*     */   
/*     */   private Rectangle[] getTextLines(Rectangle bounds, int maxHeight, int textColor) {
/* 154 */     List<Rectangle> textBounds = new ArrayList<>();
/* 155 */     Image screenImage = this.core.getScreen().getImage();
/* 156 */     int startY = -1;
/* 157 */     for (int y = bounds.y; y < bounds.y + bounds.height; y++) {
/* 158 */       boolean found = false;
/* 159 */       for (int x = bounds.x; x < bounds.x + bounds.width; x++) {
/* 160 */         int rgb = screenImage.getRGB(x, y);
/* 161 */         if (rgb == textColor) {
/* 162 */           found = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 166 */       if (found && startY == -1) {
/* 167 */         startY = y;
/* 168 */       } else if (startY != -1 && (!found || y - startY >= maxHeight)) {
/* 169 */         int xPad = 20;
/* 170 */         textBounds.add(new Rectangle(bounds.x + xPad, startY, bounds.width - xPad * 2, y - startY));
/* 171 */         startY = -1;
/*     */       } 
/*     */     } 
/* 174 */     return textBounds.<Rectangle>toArray(new Rectangle[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean selectOption(String option) {
/* 179 */     return false;
/*     */   }
/*     */   public boolean findItem(int... itemID) {
/*     */     List<Rectangle> containers;
/* 183 */     DialogueType dialogueType = getDialogueType();
/* 184 */     if (dialogueType == null || dialogueType != DialogueType.ITEM_OPTION) {
/* 185 */       return false;
/*     */     }
/* 187 */     Rectangle bounds = getBounds();
/*     */     
/* 189 */     if (this.cachedContainers != null && this.cachedContainers.getScreenUUID().equals(this.core.getScreen().getUUID())) {
/* 190 */       containers = (List<Rectangle>)this.cachedContainers.getObject();
/*     */     } else {
/* 192 */       containers = this.core.getImageAnalyzer().findContainers(bounds, 1554, 1555, 1556, 1557);
/* 193 */       this.cachedContainers = new CachedObject(this.core.getScreen().getUUID(), containers);
/*     */     } 
/*     */     
/* 196 */     List<SearchableImage> itemImages = getItemImages(itemID);
/*     */ 
/*     */     
/* 199 */     containers.forEach(rectangle -> this.core.getScreen().getDrawableCanvas().drawRect(rectangle, Color.RED.getRGB()));
/*     */     
/* 201 */     for (int i = 0; i < itemImages.size(); i++) {
/* 202 */       SearchableImage itemImage = itemImages.get(i);
/* 203 */       for (Rectangle container : containers) {
/* 204 */         if (container.height < 72 || itemImage.width > container.width)
/*     */           continue; 
/* 206 */         ImageSearchResult result = this.core.getImageAnalyzer().findLocation(container, new SearchableImage[] { itemImage });
/* 207 */         if (result != null) {
/* 208 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 212 */     return false;
/*     */   }
/*     */   
/*     */   public boolean selectItem(int... itemID) {
/*     */     List<Rectangle> containers;
/* 217 */     DialogueType dialogueType = getDialogueType();
/* 218 */     if (dialogueType == null || dialogueType != DialogueType.ITEM_OPTION) {
/* 219 */       return false;
/*     */     }
/* 221 */     Rectangle bounds = getBounds();
/*     */     
/* 223 */     if (this.cachedContainers != null && this.cachedContainers.getScreenUUID().equals(this.core.getScreen().getUUID())) {
/* 224 */       containers = (List<Rectangle>)this.cachedContainers.getObject();
/*     */     } else {
/* 226 */       containers = this.core.getImageAnalyzer().findContainers(bounds, 1554, 1555, 1556, 1557);
/* 227 */       this.cachedContainers = new CachedObject(this.core.getScreen().getUUID(), containers);
/*     */     } 
/*     */     
/* 230 */     List<SearchableImage> itemImages = getItemImages(itemID);
/*     */ 
/*     */     
/* 233 */     containers.forEach(rectangle -> this.core.getScreen().getDrawableCanvas().drawRect(rectangle, Color.RED.getRGB()));
/*     */     
/* 235 */     for (int i = 0; i < itemImages.size(); i++) {
/* 236 */       SearchableImage itemImage = itemImages.get(i);
/* 237 */       for (Rectangle container : containers) {
/* 238 */         if (container.height < 72 || itemImage.width > container.width)
/*     */           continue; 
/* 240 */         ImageSearchResult result = this.core.getImageAnalyzer().findLocation(container, new SearchableImage[] { itemImage });
/* 241 */         if (result != null) {
/* 242 */           this.core.getScreen().queueCanvasDrawable("dialoguesuccess", canvas -> {
/*     */                 if (!this.core.getWidgetManager().getDialogue().isVisible()) {
/*     */                   return;
/*     */                 }
/*     */                 
/*     */                 containers.forEach(());
/*     */                 this.core.getScreen().getDrawableCanvas().drawRect(container, Color.GREEN.getRGB());
/*     */               });
/* 250 */           this.core.getFinger().tap((Shape)result.getBounds().getPadding(3));
/* 251 */           return this.core.submitTask(() -> !isVisible(), 4000);
/*     */         } 
/*     */       } 
/*     */     } 
/* 255 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDialogueTitle() {
/* 260 */     DialogueType dialogueType = getDialogueType();
/* 261 */     if (dialogueType == null || dialogueType != DialogueType.CHAT_DIALOGUE) {
/* 262 */       return null;
/*     */     }
/* 264 */     Rectangle bounds = getBounds();
/* 265 */     if (bounds == null) return null;
/*     */     
/* 267 */     return this.core.getOCR().getText(Font.FANCY_STANDARD_FONT, bounds.getSubRectangle(TAP_HERE_TO_CONTINUE_TITLE_BOUNDS), new int[] { -8388608 });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean continueChatDialogue() {
/* 272 */     DialogueType dialogueType = getDialogueType();
/* 273 */     if (dialogueType == null || (dialogueType != DialogueType.CHAT_DIALOGUE && dialogueType != DialogueType.TAP_HERE_TO_CONTINUE)) {
/* 274 */       return false;
/*     */     }
/* 276 */     Rectangle bounds = getBounds();
/* 277 */     if (bounds == null) return false; 
/* 278 */     String text = getText();
/* 279 */     this.core.getFinger().tap((Shape)bounds.getPadding(22));
/* 280 */     this.core.submitTask(() -> { DialogueType dialogueType1 = getDialogueType(); if (dialogueType1 == null) return true;  if (dialogueType1 != DialogueType.CHAT_DIALOGUE && dialogueType1 != DialogueType.TAP_HERE_TO_CONTINUE) return true;  String text2 = getText(); return (text2 == null) ? false : (!text2.equals(text)); }5000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 290 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DialogueType getDialogueType() {
/* 296 */     if (this.dialogueType != null && this.dialogueType.getScreenUUID().equals(this.core.getScreen().getUUID())) {
/* 297 */       return (DialogueType)this.dialogueType.getObject();
/*     */     }
/* 299 */     Rectangle bounds = getBounds();
/* 300 */     if (bounds == null) return null;
/*     */     
/* 302 */     int closeButtonX = bounds.x + CLOSE_BUTTON_BOUNDS.x;
/* 303 */     int closeButtonY = bounds.y + CLOSE_BUTTON_BOUNDS.y;
/* 304 */     ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(closeButtonX, closeButtonY, this.closeButtonImage);
/* 305 */     if (result != null) {
/*     */       
/* 307 */       int scrollButtonX = SCROLL_BUTTON_UP_POINT.x + bounds.x;
/* 308 */       int scrollButtonY = SCROLL_BUTTON_UP_POINT.y + bounds.y;
/*     */       
/* 310 */       result = this.core.getImageAnalyzer().isSubImageAt(scrollButtonX, scrollButtonY, this.scrollButtonUp);
/* 311 */       if (result != null) {
/* 312 */         this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.ITEM_SEARCH);
/* 313 */         return (DialogueType)this.dialogueType.getObject();
/*     */       } 
/* 315 */       String str = this.core.getOCR().getText(Font.STANDARD_FONT_BOLD, bounds.getSubRectangle(ENTER_AMOUNT_TITLE_BOUNDS), new int[] { -16777215 });
/* 316 */       if (str.equalsIgnoreCase("enter amount:")) {
/* 317 */         this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.ENTER_AMOUNT);
/* 318 */         return (DialogueType)this.dialogueType.getObject();
/*     */       } 
/*     */       
/* 321 */       this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.TEXT_SEARCH);
/* 322 */       return (DialogueType)this.dialogueType.getObject();
/*     */     } 
/*     */     
/* 325 */     String text = this.core.getOCR().getText(Font.FANCY_STANDARD_FONT, bounds.getSubRectangle(OPTION_DIALOGUE_TITLE_BOUNDS), new int[] { -8388608 });
/* 326 */     if (text.equalsIgnoreCase("select an option")) {
/* 327 */       this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.TEXT_OPTION);
/* 328 */       return (DialogueType)this.dialogueType.getObject();
/*     */     } 
/* 330 */     Rectangle textBounds = bounds.getSubRectangle(TAP_HERE_TO_CONTINUE_BOUNDS);
/* 331 */     text = this.core.getOCR().getText(Font.FANCY_STANDARD_FONT, textBounds, new int[] { -16776961 });
/* 332 */     if (text.endsWith("here to continue") || text.equalsIgnoreCase("please wait...")) {
/* 333 */       if (this.core.getPixelAnalyzer().findPixel((Shape)bounds.getSubRectangle(TAP_HERE_TO_CONTINUE_TITLE_BOUNDS), new SearchablePixel[] { TITLE_PIXEL }) != null) {
/* 334 */         this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.CHAT_DIALOGUE);
/* 335 */         return (DialogueType)this.dialogueType.getObject();
/*     */       } 
/* 337 */       this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.TAP_HERE_TO_CONTINUE);
/* 338 */       return (DialogueType)this.dialogueType.getObject();
/*     */     } 
/*     */     
/* 341 */     List<Rectangle> containers = this.core.getImageAnalyzer().findContainers(bounds, 1554, 1555, 1556, 1557);
/* 342 */     if (!containers.isEmpty()) {
/* 343 */       this.cachedContainers = new CachedObject(this.core.getScreen().getUUID(), containers);
/*     */     }
/* 345 */     this.dialogueType = new CachedObject(this.core.getScreen().getUUID(), DialogueType.ITEM_OPTION);
/* 346 */     return (DialogueType)this.dialogueType.getObject();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\chatbox\dialogue\DialogueComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */