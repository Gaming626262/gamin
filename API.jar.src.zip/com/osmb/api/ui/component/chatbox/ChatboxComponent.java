/*     */ package com.osmb.api.ui.component.chatbox;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.chatbox.ChatboxFilterTab;
/*     */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*     */ import com.osmb.api.ui.component.ComponentChild;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.ComponentParent;
/*     */ import com.osmb.api.ui.component.ComponentSearchResult;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import com.osmb.api.visual.ocr.fonts.Font;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ChatboxComponent extends ComponentChild<Integer> implements Chatbox {
/*     */   public static final int CHATBOX_WIDTH = 461;
/*     */   public static final int CHATBOX_HEIGHT = 143;
/*     */   public static final int BUTTON_Y_OFFSET = -41;
/*     */   
/*     */   public ChatboxComponent(ScriptCore scriptCoreService) {
/*  23 */     super(scriptCoreService);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<Integer>> buildBackgrounds() {
/*  28 */     return List.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/*  33 */     return Map.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  38 */     return super.isVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<BooleanSupplier> getVisibilityCondition(ComponentSearchResult parentResult) {
/*  44 */     return UIResult.of(() -> {
/*     */           ComponentButtonStatus status = (ComponentButtonStatus)parentResult.getComponentImage().getGameFrameStatusType();
/*     */           return (status == ComponentButtonStatus.HIGHLIGHTED);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/*  52 */     ComponentParent parent = getParent();
/*  53 */     Rectangle parentBounds = parent.getBounds();
/*  54 */     if (parentBounds == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     ComponentButtonStatus parentStatus = (ComponentButtonStatus)parent.getResult().getComponentImage().getGameFrameStatusType();
/*  58 */     if (parentStatus != ComponentButtonStatus.HIGHLIGHTED)
/*     */     {
/*  60 */       return null;
/*     */     }
/*  62 */     int x = parentBounds.getX() + parentBounds.getWidth() + 1;
/*  63 */     int y = parentBounds.getY() + -41;
/*  64 */     Rectangle chatboxBounds = new Rectangle(x, y, 461, 143);
/*  65 */     if (this.core.getScreen().getBounds().contains(chatboxBounds)) {
/*  66 */       return chatboxBounds;
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ChatboxFilterTab getActiveFilterTab() {
/*  74 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/*  79 */     Rectangle usernameBounds = getUsernameBounds();
/*  80 */     if (usernameBounds == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     String username = this.core.getOCR().getText(Font.STANDARD_FONT, usernameBounds, new int[] { -1 }).replaceAll(":", "");
/*  84 */     return username;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getUsernameBounds() {
/*  89 */     Rectangle chatboxBounds = getBounds();
/*  90 */     if (chatboxBounds == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     int x = chatboxBounds.getX();
/*  94 */     int y = chatboxBounds.getY() + chatboxBounds.getHeight() - 16;
/*  95 */     return new Rectangle(x, y, 150, 16);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 100 */     ComponentSearchResult parentResult = this.parent.getResult();
/* 101 */     if (parentResult == null) {
/* 102 */       return false;
/*     */     }
/* 104 */     ComponentButtonStatus status = (ComponentButtonStatus)parentResult.getComponentImage().getGameFrameStatusType();
/* 105 */     return (status == ComponentButtonStatus.HIGHLIGHTED);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean open() {
/* 110 */     ComponentParent parent = getParent();
/* 111 */     Rectangle parentBounds = parent.getBounds();
/* 112 */     if (parentBounds == null) {
/* 113 */       return false;
/*     */     }
/* 115 */     ComponentButtonStatus parentStatus = (ComponentButtonStatus)parent.getResult().getComponentImage().getGameFrameStatusType();
/* 116 */     if (parentStatus == ComponentButtonStatus.HIGHLIGHTED) {
/* 117 */       return true;
/*     */     }
/* 119 */     this.core.getFinger().tap((Shape)parentBounds);
/* 120 */     return this.core.submitTask(() -> { ComponentSearchResult parentResult = parent.getResult(); if (parentResult == null) return false;  ComponentButtonStatus status = (ComponentButtonStatus)parentResult.getComponentImage().getGameFrameStatusType(); return (status == ComponentButtonStatus.HIGHLIGHTED); }3000);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\chatbox\ChatboxComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */