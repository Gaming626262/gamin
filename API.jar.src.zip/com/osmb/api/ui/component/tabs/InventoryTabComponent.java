/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Inventory;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ import java.awt.Point;
/*    */ 
/*    */ public class InventoryTabComponent
/*    */   extends SquareTabComponent
/*    */   implements Inventory
/*    */ {
/*    */   public InventoryTabComponent(ScriptCore scriptCoreService, Container container) {
/* 15 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 20 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 25 */     return new int[] { 777 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Point getStartPoint() {
/* 30 */     if (!isOpen() && !this.core.getWidgetManager().getBank().isVisible()) return null; 
/* 31 */     Rectangle bounds = getContainer().getInnerBounds();
/* 32 */     if (bounds == null) return null; 
/* 33 */     return new Point(bounds.x + 16, bounds.y + 17);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVisible() {
/* 38 */     return (super.isVisible() || this.core.getWidgetManager().getBank().isVisible());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOpen() {
/* 43 */     return (super.isOpen() || this.core.getWidgetManager().getBank().isVisible());
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 48 */     return Tab.Type.INVENTORY;
/*    */   }
/*    */ 
/*    */   
/*    */   public int groupWidth() {
/* 53 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public int groupHeight() {
/* 58 */     return 7;
/*    */   }
/*    */ 
/*    */   
/*    */   public int xIncrement() {
/* 63 */     return 42;
/*    */   }
/*    */ 
/*    */   
/*    */   public int yIncrement() {
/* 68 */     return 36;
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getGroupBounds() {
/* 73 */     return getContainer().getInnerBounds();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\InventoryTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */