/*     */ package com.osmb.api.ui.component.tabs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Slot
/*     */ {
/* 102 */   HEAD(79, 15),
/* 103 */   CAPE(38, 54),
/* 104 */   NECKLACE(79, 54),
/* 105 */   AMMUNITION(120, 54),
/* 106 */   WEAPON(23, 93),
/* 107 */   BODY(79, 93),
/* 108 */   SHIELD(135, 93),
/* 109 */   LEGS(79, 133),
/* 110 */   GLOVES(23, 173),
/* 111 */   BOOTS(79, 173),
/* 112 */   RING(135, 173);
/*     */   
/*     */   private final int itemPositionX;
/*     */   private final int itemPositionY;
/*     */   
/*     */   Slot(int itemPositionX, int itemPositionY) {
/* 118 */     this.itemPositionX = itemPositionX;
/* 119 */     this.itemPositionY = itemPositionY;
/*     */   }
/*     */   
/*     */   public int getItemPositionY() {
/* 123 */     return this.itemPositionY;
/*     */   }
/*     */   
/*     */   public int getItemPositionX() {
/* 127 */     return this.itemPositionX;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\EquipmentTabComponent$Slot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */