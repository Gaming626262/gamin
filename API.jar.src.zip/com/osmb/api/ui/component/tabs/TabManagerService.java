/*     */ package com.osmb.api.ui.component.tabs;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.ui.component.Component;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.ui.tabs.TabManager;
/*     */ import com.osmb.api.utils.RandomUtils;
/*     */ import com.osmb.api.utils.timing.Stopwatch;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ public class TabManagerService
/*     */   implements TabManager
/*     */ {
/*     */   private final Map<Class<? extends Component>, Tab> tabs;
/*     */   private final ScriptCore core;
/*     */   
/*     */   public TabManagerService(ScriptCore core, Map<Class<? extends Component>, Tab> tabs) {
/*  20 */     this.tabs = tabs;
/*  21 */     this.core = core;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getActiveTab() {
/*  26 */     for (Map.Entry<Class<? extends Component>, Tab> entry : this.tabs.entrySet()) {
/*  27 */       Tab tab = entry.getValue();
/*  28 */       if (tab.isOpen()) return tab.getType(); 
/*     */     } 
/*  30 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab getActiveTabComponent() {
/*  35 */     for (Map.Entry<Class<? extends Component>, Tab> entry : this.tabs.entrySet()) {
/*  36 */       Tab tab = entry.getValue();
/*  37 */       if (tab.isOpen()) return tab; 
/*     */     } 
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean closeContainer() {
/*  45 */     if (this.core.getWidgetManager().getBank().isVisible()) {
/*  46 */       this.core.log(getClass().getSimpleName(), "Cannot close container while bank is visible...");
/*  47 */       return false;
/*     */     } 
/*  49 */     if (!this.core.getWidgetManager().getComponent(Container.class).isVisible()) {
/*  50 */       return true;
/*     */     }
/*  52 */     Tab activeTab = getActiveTabComponent();
/*  53 */     if (activeTab == null) {
/*  54 */       Tab randomTab = null;
/*  55 */       Stopwatch timeout = new Stopwatch(2000L);
/*  56 */       while (randomTab == null && !timeout.hasFinished()) {
/*  57 */         randomTab = this.tabs.get(Integer.valueOf(this.core.random(this.tabs.size())));
/*  58 */         if (!randomTab.isVisible()) {
/*  59 */           randomTab = null;
/*     */         }
/*     */       } 
/*  62 */       if (randomTab == null) {
/*  63 */         return false;
/*     */       }
/*  65 */       Tab finalRandomTab = randomTab;
/*  66 */       if (this.core.submitTask(() -> finalRandomTab.open(), 3000))
/*  67 */         return this.core.submitTask(() -> finalRandomTab.close(), 3000); 
/*     */     } else {
/*  69 */       return activeTab.close();
/*     */     } 
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab getTabComponent(Tab.Type type) {
/*  76 */     for (Tab tab : this.tabs.values()) {
/*  77 */       if (tab.getType() == type) return tab; 
/*     */     } 
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean openTab(Tab.Type type) {
/*  84 */     if (type == null) {
/*  85 */       throw new IllegalArgumentException("Tab must not be null.");
/*     */     }
/*  87 */     boolean openMultiple = RandomUtils.generateRandomProbability(0.05D, 0.2D);
/*  88 */     if (openMultiple) {
/*  89 */       int amountToOpen = RandomUtils.weightedRandom(1, 5, 0.01D);
/*  90 */       AtomicReference<Integer> opened = new AtomicReference<>(Integer.valueOf(0));
/*  91 */       this.core.submitTask(() -> { if (((Integer)opened.get()).intValue() >= amountToOpen) return true;  Tab.Type randomType = Tab.Type.values()[this.core.random((Tab.Type.values()).length)]; Tab randomTab = getTabComponent(randomType); if (randomTab != null && randomTab.open()) opened.set(Integer.valueOf(((Integer)opened.get()).intValue() + 1));  return false; }13000);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     Tab tab = getTabComponent(type);
/* 107 */     if (tab == null) {
/* 108 */       return false;
/*     */     }
/* 110 */     return tab.open();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\TabManagerService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */