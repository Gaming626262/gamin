/*    */ package com.osmb.api.ui.component.tabs.container;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.GameState;
/*    */ import com.osmb.api.ui.component.ComponentChild;
/*    */ import com.osmb.api.ui.component.ComponentImage;
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*    */ import com.osmb.api.visual.drawing.BorderPalette;
/*    */ import com.osmb.api.visual.drawing.Canvas;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.awt.Point;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Container
/*    */   extends ComponentChild<Integer>
/*    */ {
/*    */   public static final int STONE_BORDER = 0;
/*    */   public static final int STEEL_BORDER = 1;
/*    */   private static final int STEEL_BORDER_HEIGHT = 273;
/*    */   private static final int STONE_BORDER_HEIGHT = 275;
/* 25 */   private static final Point STEEL_BORDER_OFFSET = new Point(-202, 3);
/* 26 */   private static final Point STONE_BORDER_OFFSET = new Point(-204, 2);
/*    */   
/*    */   public Container(ScriptCore scriptCoreService) {
/* 29 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ComponentImage<Integer>> buildBackgrounds() {
/* 34 */     Canvas canvas = new Canvas(204, 275, 16711935);
/* 35 */     canvas.createBackground(this.core, BorderPalette.STONE_BORDER, null);
/* 36 */     SearchableImage stoneBorderContainer = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 38 */     ComponentImage<Integer> stoneBorder = new ComponentImage(stoneBorderContainer, -1, Integer.valueOf(0));
/*    */     
/* 40 */     canvas = new Canvas(202, 273, 16711935);
/* 41 */     canvas.createBackground(this.core, BorderPalette.STEEL_BORDER, null);
/* 42 */     SearchableImage steelBorderContainer = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 44 */     ComponentImage<Integer> steelBorder = new ComponentImage(steelBorderContainer, -1, Integer.valueOf(1));
/*    */     
/* 46 */     return List.of(stoneBorder, steelBorder);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Integer, SearchableImage> buildIcons() {
/* 51 */     return Map.of();
/*    */   }
/*    */ 
/*    */   
/*    */   public GameState getComponentGameState() {
/* 56 */     return GameState.LOGGED_IN;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<Integer, Point> getParentOffsets() {
/* 62 */     return Map.of(Integer.valueOf(0), STONE_BORDER_OFFSET, Integer.valueOf(1), STEEL_BORDER_OFFSET);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle getInnerBounds() {
/* 87 */     Rectangle bounds = getBounds();
/* 88 */     if (bounds == null) return null; 
/* 89 */     int type = ((Integer)this.result.getComponentImage().getGameFrameStatusType()).intValue();
/* 90 */     if (type == 1)
/* 91 */       return bounds.getPadding(6); 
/* 92 */     if (type == 0) {
/* 93 */       return bounds.getPadding(7);
/*    */     }
/* 95 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\container\Container.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */