/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ 
/*    */ public class FriendsTabComponent
/*    */   extends SquareTabComponent {
/*    */   public FriendsTabComponent(ScriptCore scriptCoreService, Container container) {
/* 10 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 15 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconXOffset() {
/* 20 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 25 */     return new int[] { 782, 783 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 30 */     return Tab.Type.FRIENDS;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\FriendsTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */