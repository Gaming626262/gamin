/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.component.ComponentContainerStatus;
/*    */ import com.osmb.api.ui.component.ComponentSearchResult;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ 
/*    */ public class ExpandCollapseTabComponent
/*    */   extends SquareTabComponent {
/*    */   public ExpandCollapseTabComponent(ScriptCore scriptCoreService, Container container) {
/* 12 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 17 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconXOffset() {
/* 22 */     TabContainer tabContainer = (TabContainer)this.core.getWidgetManager().getComponent(TabContainer.class);
/* 23 */     ComponentSearchResult<ComponentContainerStatus> result = tabContainer.getResult();
/* 24 */     if (result == null) {
/* 25 */       return 1;
/*    */     }
/* 27 */     return (result.getComponentImage().getGameFrameStatusType() == ComponentContainerStatus.EXPANDED) ? 1 : -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 32 */     return new int[] { 4795, 4796 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 37 */     return Tab.Type.EXPAND_COLLAPSE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\ExpandCollapseTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */