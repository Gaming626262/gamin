/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ 
/*    */ public class MusicTabComponent extends SquareTabComponent {
/*    */   public MusicTabComponent(ScriptCore scriptCoreService, Container container) {
/*  9 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 14 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconXOffset() {
/* 19 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 24 */     return new int[] { 787 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 29 */     return Tab.Type.MUSIC;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\MusicTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */