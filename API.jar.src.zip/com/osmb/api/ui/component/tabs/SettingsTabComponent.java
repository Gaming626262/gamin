/*     */ package com.osmb.api.ui.component.tabs;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.function.Function;
/*     */ 
/*     */ public class SettingsTabComponent extends SquareTabComponent implements Settings {
/*     */   public static final int THUMB_HEIGHT = 15;
/*     */   public static final int DEFAULT_BRIGHTNESS_LEVEL = 47;
/*  25 */   private final Map<SettingsSubTabType, SearchableImage> subTabSprites = new HashMap<>();
/*  26 */   private final Map<SettingsSubTabType, SearchableImage> subTabSpritesHighlighted = new HashMap<>();
/*     */   
/*     */   private final SearchableImage sliderBarLeft;
/*     */   private final SearchableImage sliderBarRight;
/*     */   private final SearchableImage greenSliderThumb;
/*     */   private final SearchableImage blueSliderThumb;
/*     */   
/*     */   public SettingsTabComponent(ScriptCore core, Container container) {
/*  34 */     super(core, container);
/*     */     
/*  36 */     SpriteDefinition sliderBarLeftSprite = core.getSpriteManager().getSprite(2852);
/*  37 */     SpriteDefinition sliderBarRightSprite = core.getSpriteManager().getSprite(2857);
/*  38 */     SpriteDefinition sliderBarGreenThumbSprite = core.getSpriteManager().getSprite(1201);
/*  39 */     SpriteDefinition sliderBarBlueThumbSprite = core.getSpriteManager().getSprite(2858);
/*  40 */     this.sliderBarLeft = new SearchableImage(sliderBarLeftSprite, (ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  41 */     this.sliderBarRight = new SearchableImage(sliderBarRightSprite, (ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  42 */     this.greenSliderThumb = new SearchableImage(sliderBarGreenThumbSprite, (ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  43 */     this.blueSliderThumb = new SearchableImage(sliderBarBlueThumbSprite, (ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  44 */     for (SettingsSubTabType type : SettingsSubTabType.values()) {
/*  45 */       SearchableImage image = buildSprites(type.getIconID(), false);
/*  46 */       SearchableImage highlightedImage = buildSprites(type.getIconID(), true);
/*  47 */       this.subTabSprites.put(type, image);
/*  48 */       this.subTabSpritesHighlighted.put(type, highlightedImage);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hiddenWhenTabContainerCollapsed() {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getIcons() {
/*  59 */     return new int[] { 785 };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFrameRate() {
/*  65 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameRate(int rate) {}
/*     */ 
/*     */   
/*     */   public SettingsSubTabType getActiveSubTab() {
/*  74 */     Rectangle bounds = getBounds();
/*  75 */     if (bounds == null) {
/*  76 */       return null;
/*     */     }
/*  78 */     Rectangle containerBounds = getContainer().getInnerBounds();
/*  79 */     if (containerBounds == null) {
/*  80 */       return null;
/*     */     }
/*  82 */     for (SettingsSubTabType subTab : SettingsSubTabType.values()) {
/*  83 */       if (this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.subTabSprites.get(subTab) }) == null) return subTab; 
/*     */     } 
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   public boolean openSubTab(SettingsSubTabType subTab) {
/*  89 */     if (open()) {
/*  90 */       Rectangle bounds = getBounds();
/*  91 */       if (bounds == null) return false; 
/*  92 */       Rectangle containerBounds = getContainer().getInnerBounds();
/*  93 */       if (containerBounds == null) {
/*  94 */         return false;
/*     */       }
/*     */       
/*  97 */       SettingsSubTabType currentSubTab = getActiveSubTab();
/*  98 */       if (currentSubTab != null && currentSubTab == subTab) {
/*  99 */         return true;
/*     */       }
/* 101 */       ImageSearchResult result = this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.subTabSprites.get(subTab) });
/* 102 */       if (result != null) {
/* 103 */         this.core.getFinger().tap((Shape)result.getBounds());
/* 104 */         this.core.submitTask(() -> (getActiveSubTab() == subTab), 3000);
/* 105 */         return true;
/*     */       } 
/*     */     } 
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setZoomLevel(int zoom) {
/* 113 */     if (zoom > 96) {
/* 114 */       throw new IllegalArgumentException("Zoom level must not exceed 96.");
/*     */     }
/* 116 */     return this.core.submitTask(() -> { if (!openSubTab(SettingsSubTabType.DISPLAY_TAB)) return false;  Rectangle containerBounds = getContainer().getInnerBounds(); if (containerBounds == null) return false;  UIResult<Integer> currentZoom = getZoomLevel(); if (currentZoom.isNotVisible()) return false;  if (currentZoom.isFound() && ((Integer)currentZoom.get()).intValue() == zoom) return true;  List<Slider> sliders = getSliders(containerBounds); Optional<Slider> bottomSlider = sliders.stream().max(Comparator.comparing(Slider::getStartY)); if (bottomSlider.isPresent()) { Slider mbottomSlider = bottomSlider.get(); int xToTap = mbottomSlider.startX + zoom + this.greenSliderThumb.width / 2; int yToTap = mbottomSlider.startY + zoom + this.core.random(15); this.core.getFinger().tap(xToTap, yToTap); return this.core.submitTask((), 2000); }  return false; }10000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setBrightnessLevel() {
/* 146 */     return this.core.submitTask(() -> { if (!openSubTab(SettingsSubTabType.DISPLAY_TAB)) return false;  Rectangle containerBounds = getContainer().getInnerBounds(); if (containerBounds == null) return false;  UIResult<Integer> currentZoom = getBrightnessLevel(); if (currentZoom.isFound() && ((Integer)currentZoom.get()).intValue() == 47) return true;  List<Slider> sliders = getSliders(containerBounds); Optional<Slider> topSlider = sliders.stream().min(Comparator.comparing(Slider::getStartY)); if (topSlider.isPresent()) { Slider mbottomSlider = topSlider.get(); int xToTap = mbottomSlider.startX + 47 + this.blueSliderThumb.width / 2; int yToTap = mbottomSlider.startY + this.core.random(15); this.core.getFinger().tap(xToTap, yToTap); return this.core.submitTask((), 2000); }  return false; }10000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getBrightnessLevel() {
/* 173 */     Rectangle bounds = getBounds();
/* 174 */     if (bounds == null) {
/* 175 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 178 */     if (!isOpen()) {
/* 179 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 182 */     Rectangle continerBounds = getContainer().getInnerBounds();
/*     */     
/* 184 */     if (continerBounds == null) {
/* 185 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 188 */     List<Slider> sliders = getSliders(continerBounds);
/* 189 */     Optional<Slider> topSlider = sliders.stream().min(Comparator.comparing(Slider::getStartY));
/*     */     
/* 191 */     if (topSlider.isPresent()) {
/* 192 */       Slider mbottomSlider = topSlider.get();
/* 193 */       ImageSearchResult result = this.core.getImageAnalyzer().findLocation(continerBounds, new SearchableImage[] { this.blueSliderThumb });
/* 194 */       if (result == null) {
/* 195 */         return UIResult.of(null);
/*     */       }
/* 197 */       return UIResult.of(Integer.valueOf(result.getX() - mbottomSlider.startX));
/*     */     } 
/* 199 */     return UIResult.of(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getZoomLevel() {
/* 204 */     Rectangle bounds = getBounds();
/* 205 */     if (bounds == null) {
/* 206 */       return UIResult.notVisible();
/*     */     }
/* 208 */     if (!isOpen()) {
/* 209 */       return UIResult.notVisible();
/*     */     }
/* 211 */     Rectangle continerBounds = getContainer().getInnerBounds();
/*     */     
/* 213 */     if (continerBounds == null) {
/* 214 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 217 */     List<Slider> sliders = getSliders(continerBounds);
/* 218 */     Optional<Slider> bottomSlider = sliders.stream().max(Comparator.comparing(Slider::getStartY));
/*     */     
/* 220 */     if (bottomSlider.isPresent()) {
/* 221 */       Slider mbottomSlider = bottomSlider.get();
/* 222 */       ImageSearchResult result = this.core.getImageAnalyzer().findLocation(continerBounds, new SearchableImage[] { this.greenSliderThumb });
/* 223 */       if (result == null) {
/* 224 */         return UIResult.of(null);
/*     */       }
/* 226 */       return UIResult.of(Integer.valueOf(result.getX() - mbottomSlider.startX));
/*     */     } 
/* 228 */     return UIResult.of(null);
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Slider> getSliders(Rectangle containerBounds) {
/* 233 */     List<Slider> sliders = new ArrayList<>();
/* 234 */     if (containerBounds == null) return sliders;
/*     */     
/* 236 */     List<ImageSearchResult> leftSliders = this.core.getImageAnalyzer().findLocations(containerBounds, new SearchableImage[] { this.sliderBarLeft });
/* 237 */     List<ImageSearchResult> rightSliders = this.core.getImageAnalyzer().findLocations(containerBounds, new SearchableImage[] { this.sliderBarRight });
/*     */ 
/*     */     
/* 240 */     if (leftSliders.isEmpty() || rightSliders.isEmpty()) {
/* 241 */       return sliders;
/*     */     }
/*     */     
/* 244 */     Map<Integer, ImageSearchResult> rightSlidersMap = (Map<Integer, ImageSearchResult>)rightSliders.stream().collect(Collectors.toMap(ImageSearchResult::getY, Function.identity()));
/*     */     
/* 246 */     for (ImageSearchResult leftSlider : leftSliders) {
/* 247 */       ImageSearchResult rightSlider = rightSlidersMap.get(Integer.valueOf(leftSlider.getY()));
/* 248 */       if (rightSlider != null) {
/* 249 */         sliders.add(new Slider(leftSlider.getX() + leftSlider.getWidth(), leftSlider.getY() - 1, rightSlider.getX() - rightSlider.getWidth(), rightSlider.getY() - 1));
/*     */       }
/*     */     } 
/*     */     
/* 253 */     return sliders;
/*     */   }
/*     */ 
/*     */   
/*     */   private SearchableImage buildSprites(int iconID, boolean highlighted) {
/* 258 */     Canvas canvas = new Canvas(60, 26, 16711935);
/* 259 */     SpriteDefinition backgroundLeft = this.core.getSpriteManager().getSprite(highlighted ? 6325 : 6327);
/* 260 */     SpriteDefinition backgroundCenter = this.core.getSpriteManager().getSprite(highlighted ? 6326 : 6328);
/* 261 */     canvas.drawSpritePixels(backgroundLeft, 0, 0);
/* 262 */     canvas.drawSpritePixels(backgroundLeft, canvas.canvasWidth - backgroundLeft.width, 0, true, false);
/*     */     
/* 264 */     int centerX = canvas.drawAreaWidth / 2 - backgroundCenter.width / 2;
/* 265 */     canvas.drawSpritePixels(backgroundCenter, centerX, 0);
/*     */     
/* 267 */     if (iconID != 2410)
/* 268 */       canvas.setDrawArea(0, 0, canvas.canvasWidth, canvas.canvasHeight - 1); 
/* 269 */     canvas.drawSpritePixelsCentered(iconID, this.core);
/* 270 */     return canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.RGB);
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getType() {
/* 275 */     return Tab.Type.SETTINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public enum SettingsSubTabType
/*     */   {
/* 281 */     DISPLAY_TAB(2933),
/* 282 */     AUDIO_TAB(911),
/* 283 */     CONTROLS_TAB(2410);
/*     */     
/*     */     private int iconID;
/*     */     
/*     */     SettingsSubTabType(int iconID) {
/* 288 */       this.iconID = iconID;
/*     */     }
/*     */     
/*     */     public int getIconID() {
/* 292 */       return this.iconID;
/*     */     }
/*     */   }
/*     */   
/*     */   class Slider {
/*     */     private final int startX;
/*     */     private final int startY;
/*     */     private final int endX;
/*     */     private final int endY;
/*     */     
/*     */     Slider(int startX, int startY, int endX, int endY) {
/* 303 */       this.startX = startX;
/* 304 */       this.startY = startY;
/* 305 */       this.endX = endX;
/* 306 */       this.endY = endY;
/*     */     }
/*     */     
/*     */     public int getStartX() {
/* 310 */       return this.startX;
/*     */     }
/*     */     
/*     */     public int getStartY() {
/* 314 */       return this.startY;
/*     */     }
/*     */     
/*     */     public int getEndX() {
/* 318 */       return this.endX;
/*     */     }
/*     */     
/*     */     public int getEndY() {
/* 322 */       return this.endY;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\SettingsTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */