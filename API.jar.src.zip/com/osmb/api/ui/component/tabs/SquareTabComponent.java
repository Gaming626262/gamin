/*     */ package com.osmb.api.ui.component.tabs;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.Component;
/*     */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*     */ import com.osmb.api.ui.component.ComponentChild;
/*     */ import com.osmb.api.ui.component.ComponentContainerStatus;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.ComponentSearchResult;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.RandomUtils;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Point;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class SquareTabComponent extends ComponentChild<ComponentButtonStatus> implements Tab {
/*  28 */   protected static final ToleranceComparator TOLERANCE_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(10);
/*     */   private final Container container;
/*     */   
/*     */   public SquareTabComponent(ScriptCore scriptCoreService, Container container) {
/*  32 */     super(scriptCoreService);
/*  33 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getComponent() {
/*  40 */     return (Component)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/*  45 */     return super.getBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/*  50 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public Container getContainer() {
/*  55 */     return this.container;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/*  60 */     Map<Integer, SearchableImage> icons = new HashMap<>();
/*  61 */     for (int icon : getIcons()) {
/*  62 */       SearchableImage iconImage = new SearchableImage(icon, this.core, TOLERANCE_COMPARATOR, ColorModel.RGB);
/*  63 */       icons.put(Integer.valueOf(icon), iconImage);
/*     */     } 
/*  65 */     return icons;
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/*  70 */     if (containerBounds == null) {
/*  71 */       return UIResult.notVisible();
/*     */     }
/*  73 */     for (Map.Entry<Integer, SearchableImage> icon : (Iterable<Map.Entry<Integer, SearchableImage>>)this.componentIcons.entrySet()) {
/*  74 */       SearchableImage iconSprite = icon.getValue();
/*  75 */       int centerX = containerBounds.width / 2 - iconSprite.width / 2;
/*  76 */       int centerY = containerBounds.height / 2 - iconSprite.height / 2;
/*     */       
/*  78 */       int x = containerBounds.x + centerX + getIconXOffset();
/*  79 */       int y = containerBounds.y + centerY + getIconYOffset();
/*  80 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(x, y, iconSprite);
/*     */       
/*  82 */       if (result != null) {
/*  83 */         return UIResult.of(icon.getKey());
/*     */       }
/*  85 */       result = this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { iconSprite });
/*  86 */       if (result != null) {
/*  87 */         System.out.println(getClass().getSimpleName() + " - Image found @ " + getClass().getSimpleName() + ", instead of: " + result.getAsPoint() + ", " + x);
/*     */       }
/*     */     } 
/*     */     
/*  91 */     return UIResult.of(null);
/*     */   }
/*     */   
/*     */   protected int getIconXOffset() {
/*  95 */     return 0;
/*     */   }
/*     */   
/*     */   protected int getIconYOffset() {
/*  99 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ComponentImage<ComponentButtonStatus>> buildBackgrounds() {
/* 106 */     Canvas canvas = new Canvas(5767, this.core);
/* 107 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 108 */     SearchableImage normalTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/* 110 */     canvas = new Canvas(5768, this.core);
/* 111 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 112 */     SearchableImage highlightedTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/* 114 */     canvas = new Canvas(5769, this.core);
/* 115 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 116 */     SearchableImage redTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/* 118 */     ComponentImage<ComponentButtonStatus> normalTab = new ComponentImage(normalTabImage, 5767, ComponentButtonStatus.NORMAL);
/* 119 */     ComponentImage<ComponentButtonStatus> highlightedTab = new ComponentImage(highlightedTabImage, 5767, ComponentButtonStatus.HIGHLIGHTED);
/* 120 */     ComponentImage<ComponentButtonStatus> redTab = new ComponentImage(redTabImage, 5767, ComponentButtonStatus.RED);
/* 121 */     return List.of(normalTab, highlightedTab, redTab);
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 125 */     if (this.result == null) return false; 
/* 126 */     return (this.result.getComponentImage().getGameFrameStatusType() == ComponentButtonStatus.RED);
/*     */   }
/*     */   
/*     */   public boolean open() {
/* 130 */     if (isOpen()) return true; 
/* 131 */     if (this.core.getFinger() == null) {
/* 132 */       return false;
/*     */     }
/* 134 */     TabContainer tabContainer = (TabContainer)this.core.getWidgetManager().getComponent(TabContainer.class);
/* 135 */     ComponentSearchResult<ComponentContainerStatus> result = tabContainer.getResult();
/* 136 */     if (result == null) {
/* 137 */       this.core.log(getClass().getSimpleName(), "Tab container not found.");
/* 138 */       return false;
/*     */     } 
/* 140 */     if (hiddenWhenTabContainerCollapsed() && result.getComponentImage().getGameFrameStatusType() == ComponentContainerStatus.COLLAPSED) {
/* 141 */       ExpandCollapseTabComponent expandCollapseTab = (ExpandCollapseTabComponent)this.core.getWidgetManager().getComponent(ExpandCollapseTabComponent.class);
/* 142 */       if (expandCollapseTab.open()) {
/* 143 */         return false;
/*     */       }
/*     */     } 
/* 146 */     Rectangle bounds = getBounds();
/* 147 */     if (bounds == null) return false; 
/* 148 */     this.core.getFinger().tap((Shape)bounds.getPadding(2));
/* 149 */     return this.core.submitTask(() -> isOpen(), 3000, true, false, true);
/*     */   }
/*     */   
/*     */   public boolean close() {
/* 153 */     if (!isOpen()) return true; 
/* 154 */     Rectangle bounds = getBounds();
/* 155 */     if (bounds == null) return false; 
/* 156 */     Point point = RandomUtils.generateRandomPoint(bounds.getPadding(2), 10.0D);
/* 157 */     this.core.getFinger().tap(point);
/* 158 */     return this.core.submitTask(() -> !isOpen(), 3000);
/*     */   }
/*     */   
/*     */   public boolean isVisible() {
/* 162 */     return (getBounds() != null);
/*     */   }
/*     */   
/*     */   public abstract boolean hiddenWhenTabContainerCollapsed();
/*     */   
/*     */   public abstract int[] getIcons();
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\SquareTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */