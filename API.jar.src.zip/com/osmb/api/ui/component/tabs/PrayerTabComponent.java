/*     */ package com.osmb.api.ui.component.tabs;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Prayer;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PrayerTabComponent extends SquareTabComponent implements Prayer {
/*  21 */   private static final Prayer.Type[] UP_OFFSET_PRAYERS = new Prayer.Type[] { Prayer.Type.CLARITY_OF_THOUGHT, Prayer.Type.SHARP_EYE, Prayer.Type.IMPROVED_REFLEXES, Prayer.Type.PROTECT_ITEM, Prayer.Type.HAWK_EYE, Prayer.Type.INCREDIBLE_REFLEXES, Prayer.Type.PROTECT_FROM_MAGIC, Prayer.Type.EAGLE_EYE, Prayer.Type.RIGOUR };
/*  22 */   private static final Prayer.Type[] UP_OFFSET_PRAYERS2 = new Prayer.Type[] { Prayer.Type.PROTECT_FROM_MISSILES, Prayer.Type.MYSTIC_MIGHT, Prayer.Type.MYSTIC_LORE, Prayer.Type.MYSTIC_WILL, Prayer.Type.AUGURY };
/*     */   public final Map<Prayer.Type, SearchableImage> activePrayerImages;
/*     */   public final Map<Prayer.Type, SearchableImage> prayerImages;
/*     */   
/*     */   public PrayerTabComponent(ScriptCore scriptCoreService, Container container) {
/*  27 */     super(scriptCoreService, container);
/*  28 */     this.activePrayerImages = buildActivePrayerImages();
/*  29 */     Map<Prayer.Type, SearchableImage> prayerImages = new HashMap<>();
/*  30 */     for (Prayer.Type prayerType : Prayer.Type.values()) {
/*  31 */       SearchableImage image = new SearchableImage(prayerType.getSpriteID(), this.core, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  32 */       prayerImages.put(prayerType, image);
/*     */     } 
/*  34 */     this.prayerImages = prayerImages;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hiddenWhenTabContainerCollapsed() {
/*  39 */     return false;
/*     */   }
/*     */   
/*     */   private Map<Prayer.Type, SearchableImage> buildActivePrayerImages() {
/*  43 */     Map<Prayer.Type, SearchableImage> activePrayerImages = new HashMap<>();
/*  44 */     for (Prayer.Type prayerType : Prayer.Type.values()) {
/*  45 */       int yOffset = getYOffset(prayerType);
/*  46 */       Canvas canvas = new Canvas(4892, this.core);
/*  47 */       canvas.setDrawArea(0, 0, canvas.canvasWidth, canvas.canvasHeight);
/*  48 */       if (yOffset != 0 || prayerType == Prayer.Type.CHIVALRY || prayerType == Prayer.Type.PROTECT_FROM_MISSILES) {
/*  49 */         SpriteDefinition spriteDefinition = this.core.getSpriteManager().getSprite(prayerType.getSpriteID());
/*  50 */         int centerX = canvas.drawAreaWidth / 2 - spriteDefinition.width / 2;
/*  51 */         if (prayerType == Prayer.Type.CHIVALRY) {
/*  52 */           centerX--;
/*     */         }
/*  54 */         int centerY = canvas.drawAreaHeight / 2 - spriteDefinition.height / 2;
/*  55 */         if (prayerType == Prayer.Type.PROTECT_FROM_MISSILES) {
/*  56 */           centerX++;
/*  57 */           centerY -= 2;
/*     */         } 
/*  59 */         centerY += yOffset;
/*  60 */         canvas.drawSpritePixels(spriteDefinition, centerX, centerY);
/*     */       } else {
/*  62 */         canvas.drawSpritePixelsCentered(prayerType.getSpriteID(), this.core);
/*     */       } 
/*  64 */       activePrayerImages.put(prayerType, canvas.toSearchableImage((ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB));
/*     */     } 
/*  66 */     return activePrayerImages;
/*     */   }
/*     */   
/*     */   private int getYOffset(Prayer.Type prayerType) {
/*  70 */     for (Prayer.Type prayerType1 : UP_OFFSET_PRAYERS) {
/*  71 */       if (prayerType1.equals(prayerType)) {
/*  72 */         return -1;
/*     */       }
/*     */     } 
/*  75 */     for (Prayer.Type prayerType1 : UP_OFFSET_PRAYERS2) {
/*  76 */       if (prayerType1.equals(prayerType)) {
/*  77 */         return 1;
/*     */       }
/*     */     } 
/*  80 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getIcons() {
/*  85 */     return new int[] { 779 };
/*     */   }
/*     */ 
/*     */   
/*     */   public Prayer.Type[] getActivePrayers() {
/*  90 */     if (!this.core.submitTask(() -> open(), 3000)) {
/*  91 */       return null;
/*     */     }
/*  93 */     Container container = getContainer();
/*  94 */     Rectangle containerBounds = container.getInnerBounds();
/*  95 */     if (containerBounds == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     List<Prayer.Type> activePrayers = new ArrayList<>();
/*  99 */     for (Prayer.Type prayerType : Prayer.Type.values()) {
/* 100 */       if (this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.activePrayerImages.get(prayerType) }) != null)
/* 101 */         activePrayers.add(prayerType); 
/*     */     } 
/* 103 */     return activePrayers.<Prayer.Type>toArray(new Prayer.Type[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setActive(Prayer.Type prayer, boolean active) {
/* 108 */     if (!this.core.submitTask(() -> open(), 3000)) {
/* 109 */       return false;
/*     */     }
/* 111 */     Container container = getContainer();
/* 112 */     Rectangle containerBounds = container.getInnerBounds();
/* 113 */     if (containerBounds == null) {
/* 114 */       return false;
/*     */     }
/*     */     
/* 117 */     boolean isActive = (this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.activePrayerImages.get(prayer) }) != null);
/*     */     
/* 119 */     if (isActive == active) {
/* 120 */       return true;
/*     */     }
/* 122 */     ImageSearchResult result = this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.prayerImages.get(prayer) });
/* 123 */     if (result == null) {
/* 124 */       this.core.log(getClass().getSimpleName(), "Failed finding prayer sprite: " + prayer.name());
/* 125 */       return false;
/*     */     } 
/* 127 */     this.core.getFinger().tap((Shape)result.getBounds().getPadding(2));
/* 128 */     this.core.submitTask(() -> { boolean isActive_ = (this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.activePrayerImages.get(prayer) }) != null); return (active == isActive_); }3000);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getPrayerPoints() {
/* 138 */     return this.core.getWidgetManager().getMinimapOrbs().getPrayerPoints();
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getType() {
/* 143 */     return Tab.Type.PRAYER;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\PrayerTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */