/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.GameState;
/*    */ import com.osmb.api.ui.component.ComponentContainerStatus;
/*    */ import com.osmb.api.ui.component.ComponentImage;
/*    */ import com.osmb.api.ui.component.ComponentParent;
/*    */ import com.osmb.api.ui.component.ComponentSearchResult;
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*    */ import com.osmb.api.visual.drawing.BorderPalette;
/*    */ import com.osmb.api.visual.drawing.Canvas;
/*    */ import com.osmb.api.visual.image.ImageSearchResult;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class TabContainer
/*    */   extends ComponentParent<ComponentContainerStatus>
/*    */ {
/*    */   private static final int COLLAPSED_WIDTH = 58;
/*    */   private static final int WIDTH = 85;
/*    */   private static final int HEIGHT = 280;
/*    */   
/*    */   public TabContainer(ScriptCore scriptCoreService) {
/* 28 */     super(scriptCoreService);
/*    */   }
/*    */   
/*    */   private static ComponentImage buildTab(ScriptCore core, int width, ComponentContainerStatus componentContainerStatus) {
/* 32 */     Canvas canvas = new Canvas(width, 280, 16711935);
/* 33 */     canvas.createBackground(core, BorderPalette.MODERN_BORDER, null);
/* 34 */     SearchableImage image = canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.HSL);
/* 35 */     image = image.subImage(0, 0, image.width, 50);
/* 36 */     return new ComponentImage(image, -1, componentContainerStatus);
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentSearchResult onFound(ImageSearchResult result, int iconID, ComponentImage foundImage) {
/* 41 */     Rectangle screenBounds = this.core.getScreen().getBounds();
/* 42 */     if (result.getY() + 280 >= screenBounds.height) {
/* 43 */       return null;
/*    */     }
/* 45 */     return new ComponentSearchResult(result, foundImage, new Rectangle(result.getX(), result.getY(), result.getWidth(), 280));
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ComponentImage<ComponentContainerStatus>> buildBackgrounds() {
/* 50 */     ComponentImage<ComponentContainerStatus> expandedImage = buildTab(this.core, 85, ComponentContainerStatus.EXPANDED);
/* 51 */     ComponentImage<ComponentContainerStatus> collapsedTab = buildTab(this.core, 58, ComponentContainerStatus.COLLAPSED);
/*    */     
/* 53 */     return List.of(expandedImage, collapsedTab);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<Integer, SearchableImage> buildIcons() {
/* 58 */     return Map.of();
/*    */   }
/*    */ 
/*    */   
/*    */   public GameState getComponentGameState() {
/* 63 */     return GameState.LOGGED_IN;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\TabContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */