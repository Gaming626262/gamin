/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ 
/*    */ public class CombatTabComponent extends SquareTabComponent {
/*    */   public CombatTabComponent(ScriptCore scriptCoreService, Container container) {
/*  9 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 14 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 19 */     return new int[] { 774 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 24 */     return Tab.Type.COMBAT;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\CombatTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */