/*    */ package com.osmb.api.ui.component.tabs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.component.tabs.container.Container;
/*    */ import com.osmb.api.ui.tabs.Tab;
/*    */ 
/*    */ public class EmoteTabComponent extends SquareTabComponent {
/*    */   public EmoteTabComponent(ScriptCore scriptCoreService, Container container) {
/*  9 */     super(scriptCoreService, container);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hiddenWhenTabContainerCollapsed() {
/* 14 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconXOffset() {
/* 19 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 24 */     return new int[] { 786 };
/*    */   }
/*    */ 
/*    */   
/*    */   public Tab.Type getType() {
/* 29 */     return Tab.Type.EMOTE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\EmoteTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */