/*     */ package com.osmb.api.ui.component.tabs.chatbox;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.location.position.Position;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.scene.RSTile;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.chatbox.dialogue.DialogueType;
/*     */ import com.osmb.api.ui.component.Component;
/*     */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*     */ import com.osmb.api.ui.component.ComponentChild;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Logout;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.RandomUtils;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.utils.timing.Stopwatch;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Point;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class LogoutTabComponent
/*     */   extends ComponentChild<ComponentButtonStatus>
/*     */   implements Logout, Tab {
/*  36 */   private static final ToleranceComparator TOLERANCE_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(10);
/*     */   private static final int WORLD_HOP_LOGOUT_SPRITE = 1191;
/*     */   private final SearchableImage hopTabLogoutSprite;
/*     */   private Container container;
/*     */   private SearchableImage logoutButton;
/*     */   
/*     */   public LogoutTabComponent(ScriptCore scriptCoreService, Container container) {
/*  43 */     super(scriptCoreService);
/*  44 */     this.container = container;
/*  45 */     this.logoutButton = createLogoutButton();
/*  46 */     this.hopTabLogoutSprite = new SearchableImage(scriptCoreService.getSpriteManager().getSprite(1191), (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */   }
/*     */   
/*     */   private SearchableImage createLogoutButton() {
/*  50 */     SpriteDefinition leftUnderlay = this.core.getSpriteManager().getSprite(177);
/*  51 */     SpriteDefinition rightUnderlay = this.core.getSpriteManager().getSprite(178);
/*  52 */     Canvas canvas = new Canvas(140, 32);
/*  53 */     canvas.drawSpritePixels(leftUnderlay, 0, 0);
/*  54 */     canvas.drawSpritePixels(rightUnderlay, canvas.canvasWidth - rightUnderlay.width, 0);
/*  55 */     canvas.fillRect(3, 3, canvas.canvasWidth - 6, canvas.canvasHeight - 6, 16711935);
/*  56 */     return canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/*  61 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/*  66 */     return super.isVisible();
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getType() {
/*  71 */     return Tab.Type.LOGOUT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Component getComponent() {
/*  76 */     return (Component)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/*  81 */     return super.getBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<ComponentButtonStatus, Point> getParentOffsets() {
/*  86 */     Map<ComponentButtonStatus, Point> parentOffset = new HashMap<>();
/*  87 */     for (ComponentButtonStatus status : ComponentButtonStatus.values()) {
/*  88 */       parentOffset.put(status, new Point(0, -39));
/*     */     }
/*  90 */     return parentOffset;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<ComponentButtonStatus>> buildBackgrounds() {
/*  95 */     Canvas canvas = new Canvas(5773, this.core);
/*  96 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/*  97 */     SearchableImage normalTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/*  99 */     canvas = new Canvas(5774, this.core);
/* 100 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 101 */     SearchableImage highlightedTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/* 103 */     canvas = new Canvas(5775, this.core);
/* 104 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/* 105 */     SearchableImage redTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/* 107 */     ComponentImage<ComponentButtonStatus> normalTab = new ComponentImage(normalTabImage, 5773, ComponentButtonStatus.NORMAL);
/* 108 */     ComponentImage<ComponentButtonStatus> highlightedTab = new ComponentImage(highlightedTabImage, 5774, ComponentButtonStatus.HIGHLIGHTED);
/* 109 */     ComponentImage<ComponentButtonStatus> redTab = new ComponentImage(redTabImage, 5775, ComponentButtonStatus.RED);
/* 110 */     return List.of(normalTab, highlightedTab, redTab);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/* 115 */     int spriteID = 3560;
/* 116 */     SearchableImage iconImage = new SearchableImage(spriteID, this.core, TOLERANCE_COMPARATOR, ColorModel.RGB);
/* 117 */     return Map.of(Integer.valueOf(spriteID), iconImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/* 122 */     if (containerBounds == null) {
/* 123 */       return UIResult.notVisible();
/*     */     }
/* 125 */     for (Map.Entry<Integer, SearchableImage> iconEntry : (Iterable<Map.Entry<Integer, SearchableImage>>)this.componentIcons.entrySet()) {
/* 126 */       SearchableImage image = iconEntry.getValue();
/* 127 */       int x = containerBounds.width / 2 - image.width / 2 + getXOffset();
/* 128 */       int y = containerBounds.height / 2 - image.height / 2;
/*     */       
/* 130 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(containerBounds.x + x, containerBounds.y + y, image);
/* 131 */       if (result != null) {
/* 132 */         return UIResult.of(iconEntry.getKey());
/*     */       }
/*     */     } 
/* 135 */     return UIResult.of(null);
/*     */   }
/*     */   
/*     */   protected int getXOffset() {
/* 139 */     return -1;
/*     */   }
/*     */   
/*     */   public int[] getIcons() {
/* 143 */     return new int[] { 3560 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean logout() {
/* 148 */     Stopwatch blockInput = new Stopwatch();
/* 149 */     this.core.submitTask(() -> { Rectangle bounds = getBounds(); if (bounds == null || this.core.getWidgetManager().getDialogue().getDialogueType() != null) { this.core.log(getClass().getSuperclass(), "Handling dialogue obstruction..."); return handleDialogueObstruction(); }  if (!open()) { this.core.log(getClass().getSuperclass(), "Failed opening tab."); return false; }  Rectangle containerBounds = this.container.getInnerBounds(); if (containerBounds == null) return false;  ImageSearchResult result = this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.logoutButton }); if (result == null) { result = this.core.getImageAnalyzer().findLocation(containerBounds, new SearchableImage[] { this.hopTabLogoutSprite }); if (result == null) { this.core.log(getClass().getSimpleName(), "Can't find logout button."); return false; }  }  if (blockInput.hasFinished()) { this.core.log(getClass().getSuperclass(), "Tapping logout button."); Point point = RandomUtils.generateRandomPoint(result.getBounds().getPadding(4), 10.0D); this.core.getFinger().tap(point); blockInput.reset(this.core.random(700, 3000)); }  this.core.log(getClass().getSuperclass(), "Waiting for game state to change..."); return this.core.submitTask((), 8000, false, true, true); }8000, false, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     return false;
/*     */   }
/*     */   
/*     */   private boolean handleDialogueObstruction() {
/* 185 */     DialogueType dialogueType = this.core.getWidgetManager().getDialogue().getDialogueType();
/*     */     
/* 187 */     if (dialogueType != null) {
/* 188 */       if (this.core.getWorldPosition() != null) {
/* 189 */         List<LocalPosition> nearbyPositions = this.core.getWalker().getCollisionManager().findReachableTiles(this.core.getLocalPosition(), 3);
/* 190 */         if (nearbyPositions.isEmpty()) {
/* 191 */           this.core.log("Break handler", "Can't find nearby positions, restarting app");
/* 192 */           return this.core.getAppManager().restart();
/*     */         } 
/* 194 */         RSTile tile = this.core.getSceneManager().getTile((Position)nearbyPositions.get(this.core.random(nearbyPositions.size())));
/* 195 */         if (!tile.interact("Walk here")) {
/* 196 */           return false;
/*     */         }
/*     */         
/* 199 */         if (!this.core.submitTask(() -> !this.core.getWidgetManager().getDialogue().isVisible(), 3000, false, true, true)) return false;
/*     */       
/*     */       } else {
/* 202 */         return this.core.getAppManager().restart();
/*     */       } 
/* 204 */       return false;
/*     */     } 
/* 206 */     return this.core.getAppManager().restart();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getContainer() {
/* 212 */     return (Component)this.container;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 217 */     if (this.result == null) {
/* 218 */       return false;
/*     */     }
/* 220 */     ComponentImage<ComponentButtonStatus> componentImage = this.result.getComponentImage();
/* 221 */     if (componentImage == null) {
/* 222 */       return false;
/*     */     }
/*     */     
/* 225 */     return (componentImage.getGameFrameStatusType() == ComponentButtonStatus.RED);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean open() {
/* 230 */     if (isOpen()) return true; 
/* 231 */     Rectangle bounds = getBounds();
/* 232 */     if (bounds == null) return false; 
/* 233 */     this.core.getFinger().tap((Shape)bounds);
/* 234 */     return this.core.submitTask(() -> isOpen(), 3000, true, false, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean close() {
/* 239 */     if (!isOpen()) return true; 
/* 240 */     Rectangle bounds = getBounds();
/* 241 */     if (bounds == null) return false; 
/* 242 */     this.core.getFinger().tap((Shape)bounds.getPadding(2));
/* 243 */     return this.core.submitTask(() -> !isOpen(), 3000, true, false, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\chatbox\LogoutTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */