/*     */ package com.osmb.api.ui.component.tabs;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.item.ItemSearchResult;
/*     */ import com.osmb.api.item.SearchableItem;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.tabs.Equipment;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ 
/*     */ public class EquipmentTabComponent
/*     */   extends SquareTabComponent implements Equipment {
/*     */   public EquipmentTabComponent(ScriptCore scriptCoreService, Container container) {
/*  19 */     super(scriptCoreService, container);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hiddenWhenTabContainerCollapsed() {
/*  24 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getIconXOffset() {
/*  29 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getIcons() {
/*  34 */     return new int[] { 778 };
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getType() {
/*  39 */     return Tab.Type.EQUIPMENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<ItemSearchResult> findItem(int itemID) {
/*  44 */     return findItem(new int[] { itemID });
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<ItemSearchResult> findItem(int[] itemIDs) {
/*  49 */     if (this.core.getFinger() != null && 
/*  50 */       !open()) {
/*  51 */       return UIResult.notVisible();
/*     */     }
/*     */     
/*  54 */     Rectangle bounds = getContainer().getInnerBounds();
/*  55 */     Tab.Type activeTab = this.core.getWidgetManager().getTabManager().getActiveTab();
/*  56 */     if (bounds == null || activeTab == null || activeTab != Tab.Type.EQUIPMENT) {
/*  57 */       return UIResult.notVisible();
/*     */     }
/*  59 */     this.core.getScreen().getDrawableCanvas().drawRect(bounds, Color.RED.getRGB());
/*  60 */     for (Slot slot : Slot.values()) {
/*  61 */       for (int itemID : itemIDs) {
/*  62 */         SearchableItem[] arrayOfSearchableItem = this.core.getItemManager().getItem(itemID, true);
/*  63 */         for (SearchableItem searchableItem : arrayOfSearchableItem) {
/*  64 */           int x = bounds.x + slot.itemPositionX;
/*  65 */           int y = bounds.y + slot.itemPositionY;
/*  66 */           ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(x, y, (SearchableImage)searchableItem);
/*  67 */           if (result != null) {
/*  68 */             this.core.getScreen().getDrawableCanvas().drawRect(result.getBounds(), Color.RED.getRGB());
/*  69 */             return UIResult.of(new ItemSearchResult(this.core, itemID, result, slot));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  75 */     return UIResult.of(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> isEquiped(int... itemIDs) {
/*  80 */     for (int itemID : itemIDs) {
/*  81 */       UIResult<ItemSearchResult> result = findItem(itemID);
/*  82 */       if (result.isNotVisible()) return UIResult.notVisible(); 
/*  83 */       if (result.isNotFound()) {
/*  84 */         return UIResult.of(Boolean.valueOf(false));
/*     */       }
/*     */     } 
/*  87 */     return UIResult.of(Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean interact(int itemID, String menuOption) {
/*  92 */     UIResult<ItemSearchResult> result = findItem(itemID);
/*  93 */     if (!result.isFound())
/*  94 */       return false; 
/*  95 */     UIResult<Point> pointToTap = ((ItemSearchResult)result.get()).getRandomPointInSlot();
/*  96 */     if (!pointToTap.isFound()) return false; 
/*  97 */     return this.core.getFinger().tap((Point)pointToTap.get());
/*     */   }
/*     */   
/*     */   public enum Slot
/*     */   {
/* 102 */     HEAD(79, 15),
/* 103 */     CAPE(38, 54),
/* 104 */     NECKLACE(79, 54),
/* 105 */     AMMUNITION(120, 54),
/* 106 */     WEAPON(23, 93),
/* 107 */     BODY(79, 93),
/* 108 */     SHIELD(135, 93),
/* 109 */     LEGS(79, 133),
/* 110 */     GLOVES(23, 173),
/* 111 */     BOOTS(79, 173),
/* 112 */     RING(135, 173);
/*     */     
/*     */     private final int itemPositionX;
/*     */     private final int itemPositionY;
/*     */     
/*     */     Slot(int itemPositionX, int itemPositionY) {
/* 118 */       this.itemPositionX = itemPositionX;
/* 119 */       this.itemPositionY = itemPositionY;
/*     */     }
/*     */     
/*     */     public int getItemPositionY() {
/* 123 */       return this.itemPositionY;
/*     */     }
/*     */     
/*     */     public int getItemPositionX() {
/* 127 */       return this.itemPositionX;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\EquipmentTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */