/*     */ package com.osmb.api.ui.component.tabs;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.tabs.container.Container;
/*     */ import com.osmb.api.ui.spellbook.AncientSpellbook;
/*     */ import com.osmb.api.ui.spellbook.ArceeusSpellbook;
/*     */ import com.osmb.api.ui.spellbook.LunarSpellbook;
/*     */ import com.osmb.api.ui.spellbook.Spell;
/*     */ import com.osmb.api.ui.spellbook.SpellbookType;
/*     */ import com.osmb.api.ui.spellbook.StandardSpellbook;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.SearchablePixel;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Point;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SpellbookTabComponent extends SquareTabComponent implements Spellbook {
/*  25 */   public static final SearchablePixel SELECTED_PIXEL = new SearchablePixel(-1, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */   
/*     */   public SpellbookTabComponent(ScriptCore scriptCoreService, Container container) {
/*  28 */     super(scriptCoreService, container);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hiddenWhenTabContainerCollapsed() {
/*  33 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getIconXOffset() {
/*  38 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] getIcons() {
/*  43 */     return new int[] { 780, 1580, 1708, 1581 };
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> selectSpell(Spell spell) {
/*  48 */     if (!open()) {
/*  49 */       return UIResult.notVisible();
/*     */     }
/*  51 */     if (!isCorrectSpellBook(spell)) {
/*  52 */       this.core.log(getClass().getSimpleName(), "You aren't on the correct spellbook to cast spell: " + spell.getName());
/*  53 */       return UIResult.of(null);
/*     */     } 
/*     */     
/*  56 */     Rectangle containerBounds = getContainer().getInnerBounds();
/*  57 */     if (containerBounds == null) {
/*  58 */       return UIResult.notVisible();
/*     */     }
/*  60 */     UIResult<Spell> selectedSpell = getSelectedSpell();
/*  61 */     if (selectedSpell.isNotVisible()) {
/*  62 */       return UIResult.notVisible();
/*     */     }
/*     */ 
/*     */     
/*  66 */     if (selectedSpell.get() != null)
/*     */     {
/*  68 */       if (!((Spell)selectedSpell.get()).getName().equals(spell.getName())) {
/*     */         
/*  70 */         this.core.getFinger().tap((Shape)containerBounds.getPadding(2));
/*  71 */         this.core.sleep(this.core.random(140, 300));
/*     */       } else {
/*  73 */         return UIResult.of(Boolean.valueOf(true));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  79 */     SearchableImage[] spellImages = getImagesForSpell(spell);
/*  80 */     ImageSearchResult result = this.core.getImageAnalyzer().findLocation(containerBounds, spellImages);
/*  81 */     if (result != null) {
/*  82 */       this.core.getFinger().tap((Shape)result.getBounds().getPadding(2));
/*  83 */       if (this.core.submitTask(() -> (this.core.getPixelAnalyzer().findPixel((Shape)result.getBounds(), new SearchablePixel[] { SELECTED_PIXEL }) != null || this.core.getWidgetManager().getInventory().isOpen()), 3000)) {
/*  84 */         return UIResult.of(Boolean.valueOf(true));
/*     */       }
/*     */     } 
/*  87 */     return UIResult.of(Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> castSpell(Spell spell, Point castTargetPosition, BooleanSupplier successCondition) {
/*  92 */     UIResult<Boolean> selectedSpellResult = selectSpell(spell);
/*  93 */     if (selectedSpellResult.isNotVisible()) {
/*  94 */       return UIResult.notVisible();
/*     */     }
/*  96 */     if (selectedSpellResult.isNotFound()) {
/*  97 */       return UIResult.of(null);
/*     */     }
/*  99 */     if (((Boolean)selectedSpellResult.get()).booleanValue()) {
/* 100 */       this.core.getFinger().tap(castTargetPosition);
/* 101 */       return UIResult.of(Boolean.valueOf(true));
/*     */     } 
/* 103 */     return UIResult.of(Boolean.valueOf(false));
/*     */   }
/*     */   
/*     */   public UIResult<Spell> getSelectedSpell() {
/* 107 */     if (!open()) {
/* 108 */       return UIResult.notVisible();
/*     */     }
/* 110 */     Rectangle containerBounds = getContainer().getInnerBounds();
/* 111 */     if (containerBounds == null) {
/* 112 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 115 */     List<Spell> spells = new ArrayList<>();
/* 116 */     SpellbookType currentSpellbook = getSpellbookType();
/* 117 */     switch (currentSpellbook) {
/*     */       case LUNARS:
/* 119 */         for (LunarSpellbook lunarSpellbook : LunarSpellbook.values()) {
/* 120 */           spells.add(lunarSpellbook);
/*     */         }
/*     */         break;
/*     */       case ARCEUUS:
/* 124 */         for (ArceeusSpellbook arceeusSpellbook : ArceeusSpellbook.values()) {
/* 125 */           spells.add(arceeusSpellbook);
/*     */         }
/*     */         break;
/*     */       case ANCIENT:
/* 129 */         for (AncientSpellbook ancientSpellbook : AncientSpellbook.values()) {
/* 130 */           spells.add(ancientSpellbook);
/*     */         }
/*     */         break;
/*     */       case STANDARD:
/* 134 */         for (StandardSpellbook standardSpellbook : StandardSpellbook.values()) {
/* 135 */           spells.add(standardSpellbook);
/*     */         }
/*     */         break;
/*     */     } 
/* 139 */     List<Point> results = this.core.getPixelAnalyzer().findPixels((Shape)containerBounds, new SearchablePixel[] { SELECTED_PIXEL });
/* 140 */     if (results.isEmpty()) {
/* 141 */       return null;
/*     */     }
/* 143 */     Rectangle selectedBounds = Utils.createBoundingRectangle(results);
/*     */     
/* 145 */     for (Spell spell : spells) {
/* 146 */       SearchableImage[] spellImages = getImagesForSpell(spell);
/* 147 */       ImageSearchResult result = this.core.getImageAnalyzer().findLocation(selectedBounds, spellImages);
/* 148 */       if (result != null) {
/* 149 */         return UIResult.of(spell);
/*     */       }
/*     */     } 
/* 152 */     return UIResult.of(null);
/*     */   }
/*     */   
/*     */   private SearchableImage[] getImagesForSpell(Spell spell) {
/* 156 */     List<SearchableImage> spellSprites = new ArrayList<>();
/* 157 */     for (int spriteID : spell.getSpriteIDs()) {
/* 158 */       SearchableImage searchableImage = new SearchableImage(this.core.getSpriteManager().getSprite(spriteID), (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/* 159 */       spellSprites.add(searchableImage);
/*     */     } 
/* 161 */     return spellSprites.<SearchableImage>toArray(new SearchableImage[0]);
/*     */   }
/*     */   
/*     */   private boolean isCorrectSpellBook(Spell spell) {
/* 165 */     SpellbookType currentSpellbook = getSpellbookType();
/* 166 */     switch (currentSpellbook) {
/*     */       case LUNARS:
/* 168 */         return spell instanceof LunarSpellbook;
/*     */       
/*     */       case ARCEUUS:
/* 171 */         return spell instanceof ArceeusSpellbook;
/*     */       
/*     */       case ANCIENT:
/* 174 */         return spell instanceof AncientSpellbook;
/*     */       
/*     */       case STANDARD:
/* 177 */         return spell instanceof StandardSpellbook;
/*     */     } 
/*     */     
/* 180 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public SpellbookType getSpellbookType() {
/* 185 */     if (this.result == null) return null; 
/* 186 */     switch (this.result.getIconID()) {
/*     */       case 780:
/* 188 */         return SpellbookType.STANDARD;
/*     */       case 1580:
/* 190 */         return SpellbookType.ANCIENT;
/*     */       
/*     */       case 1708:
/* 193 */         return SpellbookType.ARCEUUS;
/*     */       
/*     */       case 1581:
/* 196 */         return SpellbookType.LUNARS;
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/* 203 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public Tab.Type getType() {
/* 208 */     return Tab.Type.SPELLBOOK;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\tabs\SpellbookTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */