/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ 
/*    */ public class ComponentImage<T> {
/*    */   private final SearchableImage searchableImage;
/*    */   private final int backgroundID;
/*    */   private final T gameFrameStatusType;
/*    */   
/*    */   public ComponentImage(SearchableImage searchableImage, int backgroundID, T gameFrameStatusType) {
/* 11 */     this.searchableImage = searchableImage;
/* 12 */     this.backgroundID = backgroundID;
/* 13 */     this.gameFrameStatusType = gameFrameStatusType;
/*    */   }
/*    */   
/*    */   public SearchableImage getSearchableImage() {
/* 17 */     return this.searchableImage;
/*    */   }
/*    */   
/*    */   public int getBackgroundID() {
/* 21 */     return this.backgroundID;
/*    */   }
/*    */   
/*    */   public T getGameFrameStatusType() {
/* 25 */     return this.gameFrameStatusType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentImage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */