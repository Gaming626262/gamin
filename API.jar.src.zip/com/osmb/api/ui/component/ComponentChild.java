/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.ui.GameState;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.awt.Point;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.function.BooleanSupplier;
/*    */ 
/*    */ public abstract class ComponentChild<T>
/*    */   implements ComponentGlobal<T> {
/*    */   protected final ScriptCore core;
/* 17 */   protected final List<ComponentImage<T>> componentImages = new ArrayList<>();
/* 18 */   protected final Map<Integer, SearchableImage> componentIcons = new HashMap<>();
/*    */   protected ComponentParent parent;
/* 20 */   protected ComponentSearchResult<T> result = null;
/*    */   
/*    */   public ComponentChild(ScriptCore core) {
/* 23 */     this.core = core;
/* 24 */     this.componentImages.addAll(buildBackgrounds());
/* 25 */     this.componentIcons.putAll(buildIcons());
/*    */   }
/*    */   
/*    */   public Map<T, Point> getParentOffsets() {
/* 29 */     return null;
/*    */   }
/*    */   
/*    */   public boolean insideParent() {
/* 33 */     return (getParentOffsets() == null);
/*    */   }
/*    */   
/*    */   public UIResult<BooleanSupplier> getVisibilityCondition(ComponentSearchResult<T> parentResult) {
/* 37 */     return UIResult.notVisible();
/*    */   }
/*    */   
/*    */   public ComponentParent getParent() {
/* 41 */     return this.parent;
/*    */   }
/*    */   
/*    */   public void setParent(ComponentParent parent) {
/* 45 */     this.parent = parent;
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateSearchResult(ComponentSearchResult<T> result) {
/* 50 */     this.result = result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ScriptCore getScriptCore() {
/* 55 */     return this.core;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ComponentImage<T>> getComponentImages() {
/* 60 */     return this.componentImages;
/*    */   }
/*    */ 
/*    */   
/*    */   public ComponentSearchResult getResult() {
/* 65 */     if (this.parent == null) {
/* 66 */       throw new IllegalArgumentException("Child component " + getClass().getSimpleName() + " has no parent.");
/*    */     }
/* 68 */     if (this.parent.result == null) {
/* 69 */       return null;
/*    */     }
/* 71 */     if (!this.parent.result.getScreenUpdateUUID().equals(this.core.getScreen().getUUID())) {
/* 72 */       return null;
/*    */     }
/* 74 */     if (this.result == null || !this.result.getScreenUpdateUUID().equals(this.core.getScreen().getUUID())) {
/* 75 */       return null;
/*    */     }
/* 77 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public GameState getComponentGameState() {
/* 82 */     return this.parent.getComponentGameState();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentChild.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */