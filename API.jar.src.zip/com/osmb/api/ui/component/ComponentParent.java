/*     */ package com.osmb.api.ui.component;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.utils.ImagePanel;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.BooleanSupplier;
/*     */ 
/*     */ public abstract class ComponentParent<T> implements ComponentGlobal<T> {
/*     */   protected final ScriptCore core;
/*  20 */   protected final Map<Class<? extends Component>, ComponentChild> childrenComponents = new HashMap<>();
/*  21 */   protected final List<ComponentImage<T>> componentImages = new ArrayList<>();
/*  22 */   protected final Map<Integer, SearchableImage> componentIcons = new HashMap<>();
/*  23 */   protected ComponentSearchResult<T> result = null;
/*     */   
/*     */   public ComponentParent(ScriptCore core) {
/*  26 */     this.core = core;
/*  27 */     this.componentImages.addAll(buildBackgrounds());
/*  28 */     this.componentIcons.putAll(buildIcons());
/*     */   }
/*     */   
/*     */   public Map<Class<? extends Component>, ComponentChild> getChildrenComponents() {
/*  32 */     return this.childrenComponents;
/*     */   }
/*     */   
/*     */   public void addChild(Class<? extends Component> type, ComponentChild child) {
/*  36 */     this.childrenComponents.put(type, child);
/*  37 */     child.setParent(this);
/*     */   }
/*     */   
/*     */   public Map<Class<? extends Component>, ComponentChild> findActiveChildren() {
/*  41 */     Map<Class<? extends Component>, ComponentChild> activeChildrenComponents = new HashMap<>();
/*     */     
/*  43 */     Map<Class<? extends Component>, ComponentChild> childComponents = new HashMap<>(getChildrenComponents());
/*     */     
/*  45 */     Image screenImage = this.core.getScreen().getImage();
/*  46 */     Rectangle parentBounds = getBounds();
/*  47 */     if (parentBounds == null) {
/*  48 */       return Collections.emptyMap();
/*     */     }
/*     */     
/*  51 */     Iterator<Map.Entry<Class<? extends Component>, ComponentChild>> iterator = childComponents.entrySet().iterator();
/*  52 */     label99: while (iterator.hasNext()) {
/*  53 */       Map.Entry<Class<? extends Component>, ComponentChild> entry = iterator.next();
/*  54 */       ComponentChild child = entry.getValue();
/*  55 */       ComponentSearchResult result = child.result;
/*  56 */       if (result != null) {
/*  57 */         List<ComponentImage> componentImages = child.componentImages;
/*  58 */         for (ComponentImage<?> componentImage : componentImages) {
/*  59 */           SearchableImage searchableImage = componentImage.getSearchableImage();
/*  60 */           if (this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage, result.getX(), result.getY(), searchableImage.width / 4, searchableImage.height / 4) != null) {
/*  61 */             ImageSearchResult searchResult = this.core.getImageAnalyzer().isSubImageAt(result.getX(), result.getY(), searchableImage);
/*  62 */             if (searchResult != null) {
/*  63 */               UIResult<Integer> icon = child.findIcon(searchResult.getBounds());
/*  64 */               int iconID = -1;
/*  65 */               if (!icon.isNotVisible()) {
/*  66 */                 if (icon.get() == null) {
/*     */                   continue;
/*     */                 }
/*  69 */                 iconID = ((Integer)icon.get()).intValue();
/*     */                 
/*  71 */                 child.updateSearchResult(new ComponentSearchResult(searchResult, iconID, componentImage));
/*  72 */                 activeChildrenComponents.put(entry.getKey(), child);
/*  73 */                 iterator.remove(); continue;
/*     */               } 
/*     */               continue label99;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  81 */     iterator = childComponents.entrySet().iterator();
/*  82 */     while (iterator.hasNext()) {
/*  83 */       Map.Entry<Class<? extends Component>, ComponentChild> entry = iterator.next();
/*  84 */       ComponentChild<T> child = entry.getValue();
/*  85 */       UIResult<BooleanSupplier> conditionOpt = child.getVisibilityCondition(this.result);
/*  86 */       if (!conditionOpt.isFound()) {
/*     */         continue;
/*     */       }
/*  89 */       BooleanSupplier condition = (BooleanSupplier)conditionOpt.get();
/*  90 */       if (condition.getAsBoolean()) {
/*  91 */         activeChildrenComponents.put(entry.getKey(), child);
/*  92 */         iterator.remove();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  97 */     int parentX = parentBounds.x;
/*  98 */     int parentY = parentBounds.y;
/*  99 */     iterator = childComponents.entrySet().iterator();
/* 100 */     label101: while (iterator.hasNext()) {
/* 101 */       Map.Entry<Class<? extends Component>, ComponentChild> entry = iterator.next();
/* 102 */       ComponentChild<Object> child = entry.getValue();
/* 103 */       if (child.insideParent()) {
/*     */         continue;
/*     */       }
/*     */       
/* 107 */       List<ComponentImage> componentImages = child.componentImages;
/* 108 */       for (ComponentImage<?> componentImage : componentImages) {
/* 109 */         Map<Object, Point> childOffsets = child.getParentOffsets();
/* 110 */         Point childOffset = childOffsets.get(componentImage.getGameFrameStatusType());
/*     */         
/* 112 */         int i = parentX + childOffset.x;
/* 113 */         int y = parentY + childOffset.y;
/*     */         
/* 115 */         SearchableImage searchableImage = componentImage.getSearchableImage();
/*     */         try {
/* 117 */           if (this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage, i, y, searchableImage.width / 4, searchableImage.height / 4) == null) {
/*     */             continue;
/*     */           }
/* 120 */         } catch (Exception e) {
/* 121 */           e.printStackTrace();
/*     */         } 
/* 123 */         ImageSearchResult searchResult = this.core.getImageAnalyzer().isSubImageAt(i, y, searchableImage);
/* 124 */         if (searchResult != null) {
/* 125 */           int iconID = -1;
/* 126 */           UIResult<Integer> icon = child.findIcon(searchResult.getBounds());
/* 127 */           if (icon.isFound()) {
/* 128 */             if (icon.get() == null) {
/*     */               continue;
/*     */             }
/* 131 */             iconID = ((Integer)icon.get()).intValue();
/* 132 */             if (iconID == -1) {
/*     */               continue;
/*     */             }
/*     */             
/* 136 */             child.updateSearchResult(new ComponentSearchResult(searchResult, iconID, componentImage));
/* 137 */             activeChildrenComponents.put(entry.getKey(), child);
/* 138 */             iterator.remove();
/*     */             
/*     */             continue;
/*     */           } 
/*     */           continue label101;
/*     */         } 
/*     */       } 
/*     */     } 
/* 146 */     int w = screenImage.getWidth();
/* 147 */     int h = screenImage.getHeight();
/*     */     
/* 149 */     int startX = parentBounds.x;
/* 150 */     int startY = parentBounds.y;
/* 151 */     int endX = parentBounds.x + parentBounds.width;
/* 152 */     int endY = parentBounds.y + parentBounds.height;
/* 153 */     if (endX > screenImage.width || endY > screenImage.height) {
/* 154 */       ImagePanel imagePanel = new ImagePanel(g -> { g.drawImage(screenImage.toBufferedImage(), 0, 0, null); g.setColor(Color.RED); g.drawRect(parentBounds.x, parentBounds.y, parentBounds.width, parentBounds.height); }screenImage.width, screenImage.height);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 159 */       imagePanel.showInFrame("out of bounds parent");
/* 160 */       throw new IllegalArgumentException("Parent " + getClass().getSimpleName() + " bounds exceed the dimensions of the screen image. Parent bounds: " + parentBounds + " Screen bounds: " + screenImage.getBounds());
/*     */     } 
/*     */     
/* 163 */     for (int x = startX; x < endX; x++) {
/* 164 */       for (int y = startY; y < endY; y++) {
/*     */ 
/*     */         
/* 167 */         iterator = childComponents.entrySet().iterator();
/* 168 */         while (iterator.hasNext()) {
/* 169 */           Map.Entry<Class<? extends Component>, ComponentChild> entry = iterator.next();
/* 170 */           ComponentChild child = entry.getValue();
/* 171 */           List<ComponentImage> componentImages = child.componentImages;
/* 172 */           label95: for (ComponentImage<?> componentImage : componentImages) {
/* 173 */             SearchableImage searchableImage = componentImage.getSearchableImage();
/* 174 */             if (x + searchableImage.width > w || y + searchableImage.height > h) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */             
/* 179 */             if (this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage, x, y, searchableImage.width / 4, searchableImage.height / 4) == null) {
/*     */               continue;
/*     */             }
/* 182 */             ImageSearchResult searchResult = this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage, x, y);
/* 183 */             if (searchResult != null) {
/* 184 */               int iconID = -1;
/* 185 */               UIResult<Integer> icon = child.findIcon(searchResult.getBounds());
/* 186 */               if (!icon.isNotVisible()) {
/* 187 */                 if (icon.get() == null) {
/*     */                   continue;
/*     */                 }
/* 190 */                 iconID = ((Integer)icon.get()).intValue();
/*     */                 
/* 192 */                 child.updateSearchResult(new ComponentSearchResult(searchResult, iconID, componentImage));
/* 193 */                 activeChildrenComponents.put(entry.getKey(), child);
/* 194 */                 iterator.remove(); continue;
/*     */               } 
/*     */               break label95;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 202 */     return activeChildrenComponents;
/*     */   }
/*     */ 
/*     */   
/*     */   public ComponentSearchResult<T> getResult() {
/* 207 */     return this.result;
/*     */   }
/*     */   
/*     */   public ComponentSearchResult onFound(ImageSearchResult result, int foundIconID, ComponentImage<?> foundImage) {
/* 211 */     return new ComponentSearchResult(result, foundIconID, foundImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScriptCore getScriptCore() {
/* 216 */     return this.core;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<T>> getComponentImages() {
/* 221 */     return this.componentImages;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateSearchResult(ComponentSearchResult<T> result) {
/* 226 */     this.result = result;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentParent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */