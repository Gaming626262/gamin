/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.GameState;
/*    */ import com.osmb.api.visual.image.Image;
/*    */ import com.osmb.api.visual.image.ImageSearchResult;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ 
/*    */ public abstract class ComponentCentered
/*    */   implements Component {
/*    */   protected final ScriptCore core;
/*    */   protected final ComponentImage backgroundImage;
/* 14 */   protected ComponentSearchResult result = null;
/*    */   
/*    */   public ComponentCentered(ScriptCore core) {
/* 17 */     this.core = core;
/* 18 */     this.backgroundImage = buildBackgroundImage();
/*    */   }
/*    */   
/*    */   public ComponentImage getBackgroundImage() {
/* 22 */     return this.backgroundImage;
/*    */   }
/*    */ 
/*    */   
/*    */   protected abstract ComponentImage buildBackgroundImage();
/*    */   
/*    */   public ComponentSearchResult getResult() {
/* 29 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public GameState getComponentGameState() {
/* 34 */     return GameState.LOGGED_IN;
/*    */   }
/*    */ 
/*    */   
/*    */   public void updateSearchResult(ComponentSearchResult result) {
/* 39 */     this.result = result;
/*    */   }
/*    */ 
/*    */   
/*    */   public ScriptCore getScriptCore() {
/* 44 */     return this.core;
/*    */   }
/*    */   
/*    */   public ComponentSearchResult find() {
/* 48 */     Rectangle centerBounds = this.core.getWidgetManager().getCenterComponentBounds();
/* 49 */     if (centerBounds == null) {
/* 50 */       return null;
/*    */     }
/*    */     
/* 53 */     Image screenImage = this.core.getScreen().getImage();
/*    */ 
/*    */ 
/*    */     
/* 57 */     if (this.result != null) {
/* 58 */       SearchableImage searchableImage1 = this.backgroundImage.getSearchableImage();
/* 59 */       if (this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage1, this.result.getX(), this.result.getY(), searchableImage1.width / 3, searchableImage1.height / 3) != null) {
/* 60 */         ImageSearchResult searchResult = this.core.getImageAnalyzer().isSubImageAt(this.result.getX(), this.result.getY(), searchableImage1);
/* 61 */         if (searchResult != null) {
/* 62 */           ComponentSearchResult result = new ComponentSearchResult(searchResult, this.backgroundImage);
/* 63 */           updateSearchResult(result);
/* 64 */           this.core.getWidgetManager().getActiveComponents().put(getClass(), this);
/* 65 */           return result;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 71 */     SearchableImage searchableImage = this.backgroundImage.getSearchableImage();
/* 72 */     int maxX = centerBounds.x + centerBounds.width - searchableImage.width;
/* 73 */     int maxY = centerBounds.y + centerBounds.height - searchableImage.height;
/*    */     
/* 75 */     for (int x = centerBounds.x; x <= maxX; x++) {
/* 76 */       for (int y = centerBounds.y; y <= maxY; y++) {
/*    */         
/* 78 */         if (this.core.getImageAnalyzer().isSubImageAt(screenImage, searchableImage, x, y, searchableImage.width / 4, searchableImage.height / 4) != null) {
/*    */ 
/*    */ 
/*    */           
/* 82 */           ImageSearchResult searchResult = this.core.getImageAnalyzer().isSubImageAt(x, y, searchableImage);
/* 83 */           if (searchResult != null) {
/* 84 */             ComponentSearchResult result = new ComponentSearchResult(searchResult, this.backgroundImage);
/* 85 */             updateSearchResult(result);
/* 86 */             this.core.getWidgetManager().getActiveComponents().put(getClass(), this);
/* 87 */             return result;
/*    */           } 
/*    */         } 
/*    */       } 
/* 91 */     }  return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getBounds() {
/* 96 */     if ((this.result == null || !getResult().getScreenUpdateUUID().equals(getScriptCore().getScreen().getUUID())) && 
/* 97 */       find() == null) return null;
/*    */     
/* 99 */     return this.result.getBounds();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentCentered.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */