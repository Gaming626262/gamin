/*     */ package com.osmb.api.ui.component.minimap;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.location.position.types.LocalPosition;
/*     */ import com.osmb.api.location.position.types.WorldPosition;
/*     */ import com.osmb.api.scene.RSTile;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.ComponentParent;
/*     */ import com.osmb.api.ui.component.ComponentSearchResult;
/*     */ import com.osmb.api.ui.minimap.Compass;
/*     */ import com.osmb.api.ui.minimap.EntityMapDot;
/*     */ import com.osmb.api.ui.minimap.Minimap;
/*     */ import com.osmb.api.utils.ImagePanel;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.utils.UIResultList;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.ImageUtils;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.awt.Point;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ public class MinimapComponent
/*     */   extends ComponentParent<Integer>
/*     */   implements Minimap, Compass
/*     */ {
/*     */   public static final int IMAGE_OFFSET_X = 45;
/*     */   public static final int IMAGE_OFFSET_Y = 29;
/*     */   public static final int IMAGE_SIZE = 108;
/*     */   public static final int BLACK_PIXEL = -16777215;
/*     */   private static final int MINIMAP_RADIUS = 75;
/*     */   private static final int COMPASS_RADIUS = 16;
/*  46 */   private static final Rectangle CENTER_DOT_BOUNDS = new Rectangle(53, 53, 3, 3);
/*     */   private int originalHeight;
/*  48 */   private ImagePanel minimapImagePanel = null;
/*     */   
/*     */   public MinimapComponent(ScriptCore core) {
/*  51 */     super(core);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws IOException {
/*  55 */     BufferedImage image = ImageIO.read(new File("C:/Users/joeta/Desktop/minimap.png"));
/*  56 */     Image minimap = new Image(image);
/*  57 */     removeDynamicElements(minimap);
/*  58 */     ImagePanel imagePanel = new ImagePanel(minimap.toBufferedImage());
/*  59 */     imagePanel.showInFrame("");
/*     */   }
/*     */   
/*     */   private static void markTrailTransparent(Canvas canvas, int x, int startY, int currentY) {
/*  63 */     for (int y = startY; y >= currentY; y--) {
/*  64 */       canvas.setPixel(x, y, 16711935);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void removeDynamicElements(Image minimapImage) {
/*  69 */     Canvas canvas = new Canvas(minimapImage.pixels, minimapImage.width, minimapImage.height);
/*     */ 
/*     */     
/*  72 */     int transparentRgb = 16711935;
/*     */ 
/*     */ 
/*     */     
/*  76 */     int w = minimapImage.getWidth();
/*  77 */     int h = minimapImage.getHeight();
/*  78 */     int[] whiteDotPallet = { -65794, -1907998, -1250068, -3815995, -2960686 };
/*  79 */     int[] yellowDotPallet = { -69376, -1911296, -1253632, -3819008, -2963712 };
/*  80 */     int[] redDotPallet = { -131072, -1966080, -1310720, -3866624, -3014656 };
/*     */     
/*  82 */     int[] orangeDotPallet = { -5894169, -6680874, -7795265, -7074099, -8319821 };
/*  83 */     int[] greenDotPallet = { -15674093, -15743470, -15814640, -15745775, -15882993 };
/*  84 */     int[] purpleDotPallet = { -1399288, -2516472, -4093689, -3107833, -4882170 };
/*  85 */     int[] flagPixels = { -65536, -3779068, -10669295 };
/*  86 */     int[] highlights = { -52706, -52707, -53220 };
/*  87 */     int[][] pallets = { whiteDotPallet, yellowDotPallet, redDotPallet, orangeDotPallet, greenDotPallet, purpleDotPallet, highlights, flagPixels };
/*  88 */     cleanBlackPixels(minimapImage, pallets);
/*     */     
/*  90 */     for (int x = 0; x < w; x++) {
/*  91 */       for (int y = h - 1; y >= 0; y--) {
/*  92 */         int focusedPixel = minimapImage.getRGB(x, y);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  97 */         if ((focusedPixel == -131072 || focusedPixel == -1310720) && y > 0) {
/*  98 */           int pixelAbove = minimapImage.getRGB(x, y - 1);
/*  99 */           boolean bool = false;
/* 100 */           for (int p : redDotPallet) {
/* 101 */             if (p == pixelAbove) {
/* 102 */               bool = true;
/*     */               break;
/*     */             } 
/*     */           } 
/* 106 */           if (!bool) {
/* 107 */             canvas.setPixel(x, y - 1, transparentRgb);
/*     */           }
/*     */         } 
/* 110 */         boolean found = false;
/* 111 */         for (int[] pallete : pallets) {
/* 112 */           for (int p : pallete) {
/* 113 */             if (focusedPixel == p) {
/* 114 */               canvas.setPixel(x, y, transparentRgb);
/* 115 */               found = true;
/*     */               break;
/*     */             } 
/*     */           } 
/* 119 */           if (found)
/*     */             break; 
/*     */         } 
/* 122 */         if (!found) {
/* 123 */           for (int flagPixel : flagPixels) {
/* 124 */             if (focusedPixel == flagPixel) {
/* 125 */               canvas.setPixel(x, y, transparentRgb);
/*     */             }
/*     */           } 
/* 128 */           if (focusedPixel == -1179648) {
/* 129 */             canvas.setPixel(x, y, transparentRgb);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 136 */     int centerX = minimapImage.width / 2 - 1;
/* 137 */     int centerY = minimapImage.height / 2 - 2;
/* 138 */     for (int ix = centerX; ix < centerX + 3; ix++) {
/* 139 */       for (int iy = centerY; iy < centerY + 6; iy++) {
/* 140 */         canvas.setPixel(ix, iy, transparentRgb);
/*     */       }
/*     */     } 
/*     */     int i;
/* 144 */     for (i = 0; i < 6; i++) {
/* 145 */       canvas.drawLine(i, 0, 0, i, 16711935);
/*     */     }
/*     */     
/* 148 */     for (i = w; i > w - 7; i--) {
/* 149 */       canvas.drawLine(i, 0, w, w - i, 16711935);
/*     */     }
/*     */     
/* 152 */     for (i = 0; i < 7; i++) {
/* 153 */       canvas.drawLine(i, h, 0, h - i, 16711935);
/*     */     }
/*     */ 
/*     */     
/* 157 */     for (i = w; i > w - 7; i--) {
/* 158 */       canvas.drawLine(i, h - 1, w, h - w - i - 1, 16711935);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void cleanBlackPixels(Image minimapImage, int[][] pallettes) {
/* 164 */     int[][] mask = new int[minimapImage.width][minimapImage.height]; int x;
/* 165 */     for (x = 0; x < minimapImage.width; x++) {
/* 166 */       for (int y = 0; y < minimapImage.height; y++) {
/* 167 */         int pixel = minimapImage.getRGB(x, y);
/* 168 */         if (pixel == -16777215 && (
/* 169 */           isPixelNearEdge(minimapImage, x, y, 4) || isBlackPixelEntity(minimapImage, x, y, pallettes))) {
/* 170 */           mask[x][y] = 1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 175 */     for (x = 0; x < minimapImage.width; x++) {
/* 176 */       for (int y = 0; y < minimapImage.height; y++) {
/* 177 */         if (mask[x][y] == 1) {
/* 178 */           minimapImage.setRGB(x, y, 16711935);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isPixelNearEdge(Image minimapImage, int x, int y, int distance) {
/* 185 */     return (x < distance || x >= minimapImage.width - distance || y < distance || y >= minimapImage.height - distance);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isBlackPixelEntity(Image minimapImage, int x, int y, int[][] pallettes) {
/* 190 */     int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 }, { -1, 1 }, { 1, -1 }, { 1, 1 }, { -1, -1 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 202 */     for (int[] dir : directions) {
/*     */       
/* 204 */       for (int i = 1; i <= 6; ) {
/* 205 */         int newX = x + dir[0] * i;
/* 206 */         int newY = y + dir[1] * i;
/*     */ 
/*     */         
/* 209 */         if (newX >= 0 && newX < minimapImage.width && newY >= 0 && newY < minimapImage.height) {
/* 210 */           int neighborPixel = minimapImage.getRGB(newX, newY);
/*     */           
/* 212 */           if (neighborPixel != -16777215) {
/*     */ 
/*     */             
/* 215 */             boolean paletteFound = false;
/* 216 */             for (int[] palette : pallettes) {
/* 217 */               for (int color : palette) {
/* 218 */                 if (color == neighborPixel) {
/* 219 */                   paletteFound = true;
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 223 */               if (paletteFound)
/*     */                 break; 
/* 225 */             }  if (paletteFound) {
/* 226 */               return true;
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/*     */           i++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Point toMinimapCoordinates(WorldPosition pos, RSTile tileToInteract) {
/* 242 */     UIResult<Point> mapCenterResult = this.core.getWidgetManager().getMinimap().getCenter();
/* 243 */     if (mapCenterResult.isNotVisible()) {
/* 244 */       this.core.log(getClass().getSimpleName(), "Map is not visible.");
/* 245 */       return null;
/*     */     } 
/* 247 */     Point mapCenter = (Point)mapCenterResult.get();
/* 248 */     if (mapCenter == null) {
/* 249 */       this.core.log(getClass().getSimpleName(), "Map center is null");
/* 250 */       return null;
/*     */     } 
/*     */     
/* 253 */     WorldPosition tilePosition = tileToInteract.getWorldPosition();
/* 254 */     int absoluteTargetX = tilePosition.getX() - pos.getX();
/* 255 */     int absoluteTargetY = pos.getY() - tilePosition.getY();
/* 256 */     absoluteTargetX *= 4;
/* 257 */     absoluteTargetY *= 4;
/*     */ 
/*     */     
/* 260 */     absoluteTargetX += this.core.random(4);
/* 261 */     absoluteTargetY += this.core.random(4);
/*     */     
/* 263 */     int minimapX = mapCenter.x + absoluteTargetX;
/* 264 */     int minimapY = mapCenter.y + absoluteTargetY;
/*     */     
/* 266 */     Point result = new Point(minimapX, minimapY);
/*     */     
/* 268 */     if (!insideMinimap(minimapX, minimapY)) {
/* 269 */       result = clampToMinimap(result.x, result.y);
/*     */     }
/*     */     
/* 272 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<Integer>> buildBackgrounds() {
/* 277 */     Canvas canvas = new Canvas(5832, this.core);
/* 278 */     this.originalHeight = canvas.canvasHeight;
/* 279 */     SearchableImage image = canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.HSL);
/*     */     
/* 281 */     image = image.subImage(0, 0, 181, 143);
/* 282 */     ComponentImage<Integer> componentImage = new ComponentImage(image, 5832, Integer.valueOf(1));
/* 283 */     return List.of(componentImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/* 288 */     return Map.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/* 293 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public ComponentSearchResult onFound(ImageSearchResult result, int iconID, ComponentImage foundImage) {
/* 298 */     return new ComponentSearchResult(result, foundImage, new Rectangle(result.getX(), result.getY(), result.getWidth(), this.originalHeight));
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Point> getCenter() {
/* 303 */     Rectangle bounds = getBounds();
/* 304 */     if (bounds == null) return UIResult.notVisible(); 
/* 305 */     return UIResult.of(new Point(bounds.x + 45 + 54, bounds.y + 29 + 54));
/*     */   }
/*     */ 
/*     */   
/*     */   public Point clampToMinimap(int x, int y) {
/* 310 */     UIResult<Point> centerResult = this.core.getWidgetManager().getMinimap().getCenter();
/*     */     
/* 312 */     if (!centerResult.isFound())
/*     */     {
/* 314 */       return new Point(x, y);
/*     */     }
/*     */     
/* 317 */     Point center = (Point)centerResult.get();
/* 318 */     int centerX = center.x;
/* 319 */     int centerY = center.y;
/*     */ 
/*     */     
/* 322 */     double distance = center.distance(x, y);
/*     */ 
/*     */     
/* 325 */     if (distance > 75.0D) {
/* 326 */       int radiusOffset = this.core.random(4);
/*     */       
/* 328 */       double angle = Math.atan2((y - centerY), (x - centerX));
/*     */       
/* 330 */       int radius = 75 - radiusOffset;
/*     */       
/* 332 */       int clampedX = (int)(centerX + radius * Math.cos(angle));
/* 333 */       int clampedY = (int)(centerY + radius * Math.sin(angle));
/*     */       
/* 335 */       return new Point(clampedX, clampedY);
/*     */     } 
/*     */ 
/*     */     
/* 339 */     return new Point(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean insideMinimap(int x, int y) {
/* 344 */     UIResult<Point> center = this.core.getWidgetManager().getMinimap().getCenter();
/* 345 */     return (center.isFound() && ((Point)center.get()).distance(x, y) <= 75.0D);
/*     */   }
/*     */   
/*     */   public boolean insideMinimap(Point center, int x, int y) {
/* 349 */     return (center.distance(x, y) <= 75.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image getMinimapImage(boolean cleanDynamicEntities) {
/* 354 */     Rectangle overriddenBounds = getMinimapBounds();
/* 355 */     Image cropped = this.core.getScreen().getImage().subImage(overriddenBounds);
/* 356 */     if (cleanDynamicEntities) removeDynamicElements(cropped);
/*     */     
/* 358 */     return cropped;
/*     */   }
/*     */   
/*     */   private Rectangle getMinimapBounds() {
/* 362 */     Rectangle bounds = getBounds();
/* 363 */     if (bounds == null) {
/* 364 */       return null;
/*     */     }
/* 366 */     return new Rectangle(bounds.x + 45, bounds.y + 29, 108, 108);
/*     */   }
/*     */   
/*     */   public void updatePreview(Image image) {
/* 370 */     if (this.minimapImagePanel == null) {
/* 371 */       this.minimapImagePanel = new ImagePanel(image.toBufferedImage());
/* 372 */       this.minimapImagePanel.showInFrame("minimap");
/*     */     } else {
/* 374 */       this.minimapImagePanel.setImage(image.toBufferedImage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResultList<WorldPosition> getPlayerPositions() {
/* 380 */     if (!isVisible()) {
/* 381 */       return UIResultList.notVisible();
/*     */     }
/* 383 */     return findMinimapDot(this.core.getSpriteManager().getEntityMapDot(EntityMapDot.PLAYER));
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResultList<WorldPosition> getNPCPositions() {
/* 388 */     if (!isVisible()) {
/* 389 */       return UIResultList.notVisible();
/*     */     }
/* 391 */     return findMinimapDot(this.core.getSpriteManager().getEntityMapDot(EntityMapDot.NPC));
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResultList<WorldPosition> getItemPositions() {
/* 396 */     if (!isVisible()) {
/* 397 */       return UIResultList.notVisible();
/*     */     }
/* 399 */     return findMinimapDot(this.core.getSpriteManager().getEntityMapDot(EntityMapDot.ITEM));
/*     */   }
/*     */   
/*     */   private UIResultList<WorldPosition> findMinimapDot(SearchableImage[] dotImages) {
/* 403 */     SearchableImage[] dots = new SearchableImage[dotImages.length];
/* 404 */     for (int i = 0; i < dotImages.length; i++) {
/* 405 */       dots[i] = dotImages[i].subImage(0, 1, 1, 3);
/*     */     }
/* 407 */     List<WorldPosition> dotPositions = new ArrayList<>();
/*     */     
/* 409 */     Rectangle bounds = getBounds();
/* 410 */     if (bounds == null) {
/* 411 */       return UIResultList.notVisible();
/*     */     }
/* 413 */     Rectangle mapBounds = getMinimapBounds();
/*     */     
/* 415 */     List<ImageSearchResult> miniMapDots = this.core.getImageAnalyzer().findLocations(mapBounds, dots);
/* 416 */     if (miniMapDots != null && !miniMapDots.isEmpty()) {
/* 417 */       UIResult<Point> mapCenterOpt = getCenter();
/* 418 */       if (mapCenterOpt.isNotVisible()) {
/* 419 */         System.out.println("@ not visi");
/* 420 */         return UIResultList.notVisible();
/*     */       } 
/* 422 */       Point mapCenter = (Point)mapCenterOpt.get();
/* 423 */       for (ImageSearchResult image : miniMapDots) {
/* 424 */         LocalPosition position = this.core.getLocalPosition();
/*     */         
/* 426 */         double diffX = (image.getX() - mapCenter.x);
/* 427 */         double diffY = (image.getY() - mapCenter.y);
/* 428 */         diffX += 2.0D;
/* 429 */         diffY++;
/* 430 */         double tileDiffX = diffX / 4.0D;
/* 431 */         double tileDiffY = diffY / 4.0D;
/*     */         
/* 433 */         double remainderX = tileDiffX - Math.floor(tileDiffX);
/* 434 */         double remainderY = tileDiffY - Math.floor(tileDiffY);
/*     */ 
/*     */         
/* 437 */         double playerRemainderX = position.getRemainderX();
/* 438 */         double playerRemainderY = position.getRemainderY();
/*     */         
/* 440 */         remainderX += playerRemainderX;
/* 441 */         remainderY += playerRemainderY;
/*     */         
/* 443 */         int x = (int)(position.getX() + diffX / 4.0D) + this.core.getSceneManager().getSceneBaseTileX();
/* 444 */         int y = (int)(position.getY() - diffY / 4.0D) + this.core.getSceneManager().getSceneBaseTileY();
/* 445 */         dotPositions.add(new WorldPosition(x, y, position.getPlane(), remainderX, remainderY));
/*     */       } 
/*     */     } 
/* 448 */     return UIResultList.of(dotPositions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getRotation() {
/* 456 */     UIResult<Point> centerOpt = getCompassCenter();
/* 457 */     if (centerOpt.isNotVisible()) {
/* 458 */       return UIResult.notVisible();
/*     */     }
/* 460 */     Point compassCenter = (Point)centerOpt.get();
/*     */     
/* 462 */     int x = compassCenter.x - 16;
/* 463 */     int y = compassCenter.y - 16;
/* 464 */     for (int i = 0; i <= 2047; i++) {
/* 465 */       SearchableImage compassImage = getCompassImage(i).toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/* 466 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(x, y, compassImage);
/* 467 */       if (result != null) {
/* 468 */         return UIResult.of(Integer.valueOf(i));
/*     */       }
/*     */     } 
/* 471 */     return UIResult.of(null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirection(Compass.Direction direction) {}
/*     */ 
/*     */   
/*     */   public Image getCompassImage(int angle) {
/* 480 */     SpriteDefinition compass = this.core.getSpriteManager().getSprite(169);
/* 481 */     Image compassImage = new Image(compass);
/* 482 */     Image rotatedImage = ImageUtils.rotate(compassImage, 25, 25, angle, 256);
/* 483 */     int centerX = compassImage.getWidth() / 2;
/* 484 */     int centerY = compassImage.getHeight() / 2;
/* 485 */     Point centerPoint = new Point(centerX, centerY);
/* 486 */     int topY = Integer.MAX_VALUE;
/* 487 */     int rightX = Integer.MIN_VALUE;
/* 488 */     int bottomY = Integer.MIN_VALUE;
/* 489 */     int leftX = Integer.MAX_VALUE;
/* 490 */     for (int x = 0; x < rotatedImage.width; x++) {
/* 491 */       for (int y = 0; y < rotatedImage.height; y++) {
/* 492 */         double dist = centerPoint.distance(x, y);
/* 493 */         if (dist > 16.0D) {
/* 494 */           rotatedImage.setRGB(x, y, 16711935);
/*     */         } else {
/* 496 */           if (x < leftX) {
/* 497 */             leftX = x;
/*     */           }
/* 499 */           if (x > rightX) {
/* 500 */             rightX = x;
/*     */           }
/* 502 */           if (y < topY) {
/* 503 */             topY = y;
/*     */           }
/* 505 */           if (y > bottomY) {
/* 506 */             bottomY = y;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 511 */     return rotatedImage.subImage(leftX, topY, rightX - leftX + 1, bottomY - topY + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Point> getCompassCenter() {
/* 516 */     UIResult<Point> minimapCenterOpt = this.core.getWidgetManager().getMinimap().getCenter();
/* 517 */     if (minimapCenterOpt.isNotVisible()) {
/* 518 */       return UIResult.notVisible();
/*     */     }
/* 520 */     if (minimapCenterOpt.isNotVisible()) {
/* 521 */       return UIResult.notVisible();
/*     */     }
/* 523 */     Point minimapCenter = (Point)minimapCenterOpt.get();
/* 524 */     return UIResult.of(new Point(minimapCenter.x - 78, minimapCenter.y - 62));
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\MinimapComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */