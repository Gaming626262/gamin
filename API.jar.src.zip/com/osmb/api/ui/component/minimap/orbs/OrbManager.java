/*     */ package com.osmb.api.ui.component.minimap.orbs;
/*     */ 
/*     */ import com.osmb.api.ui.component.Component;
/*     */ import com.osmb.api.ui.minimap.MinimapOrbs;
/*     */ import com.osmb.api.ui.minimap.status.HealthStatus;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class OrbManager
/*     */   implements MinimapOrbs
/*     */ {
/*     */   private final Map<Class<? extends Component>, MinimapOrb> orbs;
/*     */   
/*     */   public OrbManager(Map<Class<? extends Component>, MinimapOrb> orbs) {
/*  15 */     this.orbs = orbs;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getHitpoints() {
/*  21 */     MinimapOrb healthOrb = this.orbs.get(HealthOrb.class);
/*  22 */     return healthOrb.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getHitpointsPercentage() {
/*  27 */     MinimapOrb healthOrb = this.orbs.get(HealthOrb.class);
/*  28 */     return healthOrb.getPercentage();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<HealthStatus> getHealthStatus() {
/*  34 */     return UIResult.notVisible();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getPrayerPoints() {
/*  39 */     MinimapOrb prayerOrb = this.orbs.get(PrayerOrb.class);
/*  40 */     return prayerOrb.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getRunEnergy() {
/*  45 */     MinimapOrb runOrb = this.orbs.get(RunOrb.class);
/*  46 */     return runOrb.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> hasStaminaEffect() {
/*  51 */     RunOrb runOrb = (RunOrb)this.orbs.get(RunOrb.class);
/*  52 */     return runOrb.hasStaminaEffect();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> isRunEnabled() {
/*  57 */     MinimapOrb runOrb = this.orbs.get(RunOrb.class);
/*  58 */     return runOrb.isActivated();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> getSpecialAttackPercentage() {
/*  63 */     MinimapOrb specOrb = this.orbs.get(SpecialAttackOrb.class);
/*  64 */     return specOrb.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> isSpecialAttackActivated() {
/*  69 */     MinimapOrb specialAttackOrb = this.orbs.get(SpecialAttackOrb.class);
/*  70 */     return specialAttackOrb.isActivated();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> isSpecialAttackEnabled() {
/*  76 */     return UIResult.notVisible();
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Boolean> isQuickPrayersActivated() {
/*  81 */     MinimapOrb prayerOrb = this.orbs.get(PrayerOrb.class);
/*  82 */     return prayerOrb.isActivated();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setQuickPrayers(boolean activated) {
/*  87 */     MinimapOrb prayerOrb = this.orbs.get(PrayerOrb.class);
/*  88 */     return prayerOrb.setActivated(activated);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setSpecialAttack(boolean activated) {
/*  93 */     MinimapOrb specialAttackOrb = this.orbs.get(SpecialAttackOrb.class);
/*  94 */     return specialAttackOrb.setActivated(activated);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setRun(boolean enabled) {
/*  99 */     MinimapOrb runOrb = this.orbs.get(RunOrb.class);
/* 100 */     return runOrb.setActivated(enabled);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\OrbManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */