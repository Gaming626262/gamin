/*    */ package com.osmb.api.ui.component.minimap.orbs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import java.awt.Point;
/*    */ 
/*    */ public class RunOrb
/*    */   extends MinimapOrb
/*    */ {
/*    */   public RunOrb(ScriptCore scriptCoreService) {
/* 11 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 16 */     return new int[] { 1069, 1070, 1092 };
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getActivatedUnderlay() {
/* 21 */     return 1065;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Point getMinimapOffset() {
/* 26 */     return new Point(-37, 111);
/*    */   }
/*    */   
/*    */   public UIResult<Boolean> hasStaminaEffect() {
/* 30 */     if (!isVisible()) {
/* 31 */       return UIResult.notVisible();
/*    */     }
/* 33 */     return UIResult.of(Boolean.valueOf((getResult().getIconID() == 1092)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\RunOrb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */