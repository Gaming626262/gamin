/*    */ package com.osmb.api.ui.component.minimap.orbs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ public class SpecialAttackOrb
/*    */   extends MinimapOrb
/*    */ {
/*    */   public SpecialAttackOrb(ScriptCore scriptCoreService) {
/* 11 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 16 */     return new int[] { 1610 };
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getActivatedUnderlay() {
/* 21 */     return 1608;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Point getMinimapOffset() {
/* 26 */     return new Point(-9, 143);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\SpecialAttackOrb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */