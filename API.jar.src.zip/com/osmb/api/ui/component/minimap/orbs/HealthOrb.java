/*    */ package com.osmb.api.ui.component.minimap.orbs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HealthOrb
/*    */   extends MinimapOrb
/*    */ {
/*    */   public HealthOrb(ScriptCore scriptCoreService) {
/* 12 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 17 */     return new int[] { 1067 };
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getActivatedUnderlay() {
/* 22 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Point getMinimapOffset() {
/* 27 */     return new Point(-44, 39);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\HealthOrb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */