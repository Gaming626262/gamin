/*     */ package com.osmb.api.ui.component.minimap.orbs;
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.definition.SpriteDefinition;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*     */ import com.osmb.api.ui.component.ComponentChild;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.ColorUtils;
/*     */ import com.osmb.api.visual.color.HSLPalette;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.ChannelThresholdComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.Image;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import com.osmb.api.visual.ocr.fonts.Font;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class MinimapOrb extends ComponentChild<ComponentButtonStatus> {
/*  30 */   private static final Rectangle TEXT_AREA = new Rectangle(8, 13, 27, 9);
/*  31 */   private static final Rectangle ORB_UNDERLAY_BOUNDS = new Rectangle(35, 4, 26, 26);
/*     */   private static final int BASE_ORB_UNDERLAY_COLOR = -15066598;
/*  33 */   private static final ToleranceComparator ORB_COMPARATOR = (ToleranceComparator)new ChannelThresholdComparator(8, 12, 8);
/*  34 */   private static final ToleranceComparator ICON_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(10);
/*     */   private final Image orbBaseUnderlay;
/*     */   private final Image activatedUnderlay;
/*     */   private final int[][] iconMask;
/*     */   private final List<Image> orbContainerImages;
/*     */   
/*     */   public MinimapOrb(ScriptCore core) {
/*  41 */     super(core);
/*  42 */     this.orbContainerImages = getOrbContainerImages();
/*  43 */     SpriteDefinition blackOrbUnderlaySprite = core.getSpriteManager().getSprite(1059);
/*  44 */     this.orbBaseUnderlay = new Image(blackOrbUnderlaySprite);
/*  45 */     SpriteDefinition activatedUnderlay = core.getSpriteManager().getSprite(getActivatedUnderlay());
/*  46 */     this.activatedUnderlay = new Image(activatedUnderlay);
/*  47 */     SpriteDefinition iconSprite = core.getSpriteManager().getSprite(getIcons()[0]);
/*  48 */     this.iconMask = (new Image(iconSprite)).getMask();
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  52 */     HSLPalette.initializeLookupTable();
/*  53 */     new Color(-8822270);
/*  54 */     new Color(-8033536);
/*  55 */     int[] diff = ColorUtils.getRGBDifferences(-8822270, -8033536);
/*  56 */     double[] diff2 = ColorUtils.getHSLDifferences(-8822270, -8033536);
/*  57 */     System.out.println(Arrays.toString(diff));
/*  58 */     System.out.println(Arrays.toString(diff2));
/*     */   }
/*     */   
/*     */   private List<Image> getOrbContainerImages() {
/*  62 */     SpriteDefinition minimapOrbNormal = this.core.getSpriteManager().getSprite(5791);
/*  63 */     SpriteDefinition minimapOrbRed = this.core.getSpriteManager().getSprite(5793);
/*  64 */     SpriteDefinition minimapOrbHighlighted = this.core.getSpriteManager().getSprite(5792);
/*     */     
/*  66 */     return List.of(new Image(minimapOrbNormal), new Image(minimapOrbRed), new Image(minimapOrbHighlighted));
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/*  71 */     if (containerBounds == null) {
/*  72 */       return UIResult.notVisible();
/*     */     }
/*  74 */     for (Map.Entry<Integer, SearchableImage> iconEntry : (Iterable<Map.Entry<Integer, SearchableImage>>)this.componentIcons.entrySet()) {
/*  75 */       SearchableImage icon = iconEntry.getValue();
/*  76 */       int x = containerBounds.x + ORB_UNDERLAY_BOUNDS.x + ORB_UNDERLAY_BOUNDS.width / 2 - icon.width / 2;
/*  77 */       int y = containerBounds.y + ORB_UNDERLAY_BOUNDS.y + ORB_UNDERLAY_BOUNDS.height / 2 - icon.height / 2;
/*  78 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(x, y, icon);
/*  79 */       if (result != null) {
/*  80 */         return UIResult.of(iconEntry.getKey());
/*     */       }
/*     */     } 
/*  83 */     return UIResult.of(null);
/*     */   }
/*     */   
/*     */   private ComponentImage buildMinimapOrb(int orbID, ComponentButtonStatus componentButtonStatus) {
/*  87 */     Canvas canvas = new Canvas(orbID, this.core);
/*  88 */     canvas.replaceAllPixels(-15066598, 16711935);
/*     */     
/*  90 */     canvas.fillRect(TEXT_AREA.x, TEXT_AREA.y, TEXT_AREA.width, TEXT_AREA.height, 16711935);
/*     */     
/*  92 */     SearchableImage image = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*  93 */     return new ComponentImage(image, orbID, componentButtonStatus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/* 104 */     Map<Integer, SearchableImage> icons = new HashMap<>();
/* 105 */     for (int icon : getIcons()) {
/* 106 */       icons.put(Integer.valueOf(icon), new SearchableImage(icon, this.core, ICON_COMPARATOR, ColorModel.RGB));
/*     */     }
/* 108 */     return icons;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<ComponentButtonStatus>> buildBackgrounds() {
/* 113 */     ComponentImage<ComponentButtonStatus> orbNormalComponent = buildMinimapOrb(5791, ComponentButtonStatus.NORMAL);
/* 114 */     ComponentImage<ComponentButtonStatus> orbRedComponent = buildMinimapOrb(5793, ComponentButtonStatus.RED);
/* 115 */     ComponentImage<ComponentButtonStatus> orbHighlightedComponent = buildMinimapOrb(5792, ComponentButtonStatus.HIGHLIGHTED);
/*     */     
/* 117 */     return List.of(orbRedComponent, orbNormalComponent, orbHighlightedComponent);
/*     */   }
/*     */   
/*     */   public UIResult<Integer> getValue() {
/* 121 */     Rectangle bounds = getBounds();
/* 122 */     if (bounds == null)
/*     */     {
/* 124 */       return UIResult.notVisible();
/*     */     }
/*     */     
/* 127 */     Image screenImage = this.core.getScreen().getImage();
/* 128 */     int[][] valueFlags = new int[TEXT_AREA.width][TEXT_AREA.height];
/* 129 */     for (int y = TEXT_AREA.y; y < TEXT_AREA.y + TEXT_AREA.height; y++) {
/* 130 */       for (int x = TEXT_AREA.x; x < TEXT_AREA.x + TEXT_AREA.width; x++) {
/*     */         
/* 132 */         boolean match = false;
/* 133 */         int screenRGB = screenImage.getRGB(bounds.x + x, bounds.y + y);
/*     */         
/* 135 */         if (screenRGB != -16777215) {
/*     */ 
/*     */ 
/*     */           
/* 139 */           for (Image container : this.orbContainerImages) {
/* 140 */             int containerRGB = container.getRGB(x, y);
/* 141 */             if (containerRGB == 16711935) {
/*     */               break;
/*     */             }
/*     */             
/* 145 */             if (containerRGB == screenRGB) {
/* 146 */               match = true;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 151 */           if (!match) valueFlags[x - TEXT_AREA.x][y - TEXT_AREA.y] = 1; 
/*     */         } 
/*     */       } 
/* 154 */     }  String result = this.core.getOCR().getText(Font.SMALL_FONT, valueFlags, false);
/* 155 */     String numberResult = result.replaceAll("[^0-9]", "");
/* 156 */     if (numberResult.isEmpty()) {
/* 157 */       return UIResult.of(Integer.valueOf(-1));
/*     */     }
/* 159 */     return UIResult.of(Integer.valueOf(Integer.parseInt(numberResult)));
/*     */   }
/*     */   
/*     */   public UIResult<Integer> getPercentage() {
/* 163 */     Rectangle bounds = getBounds();
/* 164 */     if (bounds == null)
/*     */     {
/* 166 */       return UIResult.notVisible();
/*     */     }
/* 168 */     int iconX = ORB_UNDERLAY_BOUNDS.width / 2 - this.iconMask.length / 2;
/* 169 */     int iconY = ORB_UNDERLAY_BOUNDS.height / 2 - (this.iconMask[0]).length / 2;
/* 170 */     Image screenImage = this.core.getScreen().getImage();
/* 171 */     for (int y = 0; y < this.orbBaseUnderlay.height; y++) {
/* 172 */       for (int x = 0; x < this.orbBaseUnderlay.width; x++) {
/*     */         
/* 174 */         if (x < iconX || x >= iconX + this.iconMask.length || y < iconY || y >= iconY + (this.iconMask[0]).length || 
/* 175 */           this.iconMask[x - iconX][y - iconY] != 1) {
/*     */ 
/*     */ 
/*     */           
/* 179 */           int underlayRGB = this.orbBaseUnderlay.getRGB(x, y);
/* 180 */           if (underlayRGB != 16711935) {
/* 181 */             int screenRGB = screenImage.getRGB(bounds.x + ORB_UNDERLAY_BOUNDS.x + x, bounds.y + ORB_UNDERLAY_BOUNDS.y + y);
/* 182 */             if (screenRGB != underlayRGB)
/* 183 */               return UIResult.of(Integer.valueOf(100 - y * 4)); 
/*     */           } 
/*     */         } 
/*     */       } 
/* 187 */     }  return UIResult.of(Integer.valueOf(0));
/*     */   }
/*     */   
/*     */   public UIResult<Boolean> isActivated() {
/* 191 */     Rectangle bounds = getBounds();
/* 192 */     if (bounds == null)
/*     */     {
/* 194 */       return UIResult.notVisible();
/*     */     }
/* 196 */     Image screenImage = this.core.getScreen().getImage();
/*     */     
/* 198 */     int iconX = ORB_UNDERLAY_BOUNDS.width / 2 - this.iconMask.length / 2;
/* 199 */     int iconY = ORB_UNDERLAY_BOUNDS.height / 2 - (this.iconMask[0]).length / 2;
/* 200 */     boolean startedTrail = false;
/* 201 */     for (int y = 0; y < this.orbBaseUnderlay.height; y++) {
/* 202 */       for (int x = 0; x < this.orbBaseUnderlay.width; x++) {
/*     */         
/* 204 */         if (x < iconX || x >= iconX + this.iconMask.length || y < iconY || y >= iconY + (this.iconMask[0]).length || 
/* 205 */           this.iconMask[x - iconX][y - iconY] != 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 211 */           int baseUnderlayRGB = this.orbBaseUnderlay.getRGB(x, y);
/* 212 */           if (baseUnderlayRGB != 16711935) {
/*     */             
/* 214 */             int screenRGB = screenImage.getRGB(bounds.x + ORB_UNDERLAY_BOUNDS.x + x, bounds.y + ORB_UNDERLAY_BOUNDS.y + y);
/* 215 */             if (screenRGB != baseUnderlayRGB)
/*     */             
/*     */             { 
/*     */               
/* 219 */               int activatedUnderlayRGB = this.activatedUnderlay.getRGB(x, y);
/*     */               
/* 221 */               if (!ColorUtils.isHSLinsideThreshold(ORB_COMPARATOR, activatedUnderlayRGB, screenRGB))
/* 222 */                 return UIResult.of(Boolean.valueOf(false)); 
/* 223 */               if (!startedTrail)
/* 224 */                 startedTrail = true;  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 228 */     }  return UIResult.of(Boolean.valueOf(startedTrail));
/*     */   }
/*     */   
/*     */   public boolean setActivated(boolean activated) {
/* 232 */     UIResult<Boolean> isEnabled = isActivated();
/*     */     
/* 234 */     if (isEnabled.isFound() && ((Boolean)isEnabled.get()).booleanValue() == activated) {
/* 235 */       return true;
/*     */     }
/* 237 */     UIResult<Rectangle> tapBounds = getTappableBounds();
/* 238 */     if (!tapBounds.isFound()) {
/* 239 */       return false;
/*     */     }
/* 241 */     this.core.getFinger().tap((Shape)tapBounds.get());
/*     */     
/* 243 */     this.core.submitTask(() -> {
/*     */           UIResult<Boolean> isEnabled_ = isActivated();
/* 245 */           return (isEnabled_.isFound() && ((Boolean)isEnabled_.get()).booleanValue() == activated);
/*     */         }4000);
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<ComponentButtonStatus, Point> getParentOffsets() {
/* 252 */     Map<ComponentButtonStatus, Point> parentOffset = new HashMap<>();
/* 253 */     for (ComponentButtonStatus status : ComponentButtonStatus.values()) {
/* 254 */       parentOffset.put(status, getMinimapOffset());
/*     */     }
/* 256 */     return parentOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIResult<Rectangle> getTappableBounds() {
/* 275 */     Rectangle bounds = getBounds();
/* 276 */     if (bounds == null) return UIResult.notVisible();
/*     */     
/* 278 */     return UIResult.of(new Rectangle(bounds.x + 5, bounds.y + 5, bounds.width - 12, bounds.height - 8));
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/* 283 */     return GameState.LOGGED_IN;
/*     */   }
/*     */   
/*     */   protected abstract int[] getIcons();
/*     */   
/*     */   protected abstract int getActivatedUnderlay();
/*     */   
/*     */   protected abstract Point getMinimapOffset();
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\MinimapOrb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */