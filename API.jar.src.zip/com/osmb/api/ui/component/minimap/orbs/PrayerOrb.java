/*    */ package com.osmb.api.ui.component.minimap.orbs;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ public class PrayerOrb
/*    */   extends MinimapOrb
/*    */ {
/*    */   public PrayerOrb(ScriptCore scriptCoreService) {
/* 12 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 17 */     return new int[] { 1068, 1058 };
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getActivatedUnderlay() {
/* 22 */     return 1066;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Point getMinimapOffset() {
/* 27 */     return new Point(-47, 75);
/*    */   }
/*    */ 
/*    */   
/*    */   public UIResult<Boolean> isActivated() {
/* 32 */     if (!isVisible()) return UIResult.notVisible(); 
/* 33 */     return UIResult.of(Boolean.valueOf((this.result.getIconID() == 1058)));
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\orbs\PrayerOrb.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */