/*    */ package com.osmb.api.ui.component.minimap.xpcounter;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.shape.Shape;
/*    */ import com.osmb.api.ui.Expandable;
/*    */ import com.osmb.api.ui.component.ComponentChild;
/*    */ import com.osmb.api.ui.component.ComponentImage;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import com.osmb.api.visual.color.ColorModel;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.awt.Point;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class XPDropsComponent
/*    */   extends ComponentChild<Integer>
/*    */   implements Expandable {
/*    */   public XPDropsComponent(ScriptCore core) {
/* 22 */     super(core);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<Integer, Point> getParentOffsets() {
/* 28 */     Map<Integer, Point> parentOffsets = new HashMap<>();
/* 29 */     Point offset = new Point(-33, 4);
/* 30 */     parentOffsets.put(Integer.valueOf(0), offset);
/* 31 */     parentOffsets.put(Integer.valueOf(1), offset);
/* 32 */     return parentOffsets;
/*    */   }
/*    */ 
/*    */   
/*    */   public List<ComponentImage<Integer>> buildBackgrounds() {
/* 37 */     SearchableImage xpDropsImage = new SearchableImage(1196, this.core, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/* 38 */     SearchableImage xpDropsImageHighlighted = new SearchableImage(1198, this.core, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 40 */     SearchableImage xpDropsEnabledImage = new SearchableImage(1197, this.core, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/* 41 */     SearchableImage xpDropsEnabledImageHighlighted = new SearchableImage(1199, this.core, (ToleranceComparator)ToleranceComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*    */     
/* 43 */     ComponentImage<Integer> xpDrops = new ComponentImage(xpDropsImage, 1196, Integer.valueOf(0));
/* 44 */     ComponentImage<Integer> xpDropsHighlighted = new ComponentImage(xpDropsImageHighlighted, 1198, Integer.valueOf(0));
/*    */     
/* 46 */     ComponentImage<Integer> xpDropsEnabled = new ComponentImage(xpDropsEnabledImage, 1197, Integer.valueOf(1));
/* 47 */     ComponentImage<Integer> xpDropsEnabledHighlighted = new ComponentImage(xpDropsEnabledImageHighlighted, 1199, Integer.valueOf(1));
/* 48 */     return List.of(xpDrops, xpDropsHighlighted, xpDropsEnabled, xpDropsEnabledHighlighted);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<Integer, SearchableImage> buildIcons() {
/* 54 */     return Map.of();
/*    */   }
/*    */ 
/*    */   
/*    */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/* 59 */     return super.findIcon(containerBounds);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isOpen() {
/* 64 */     Rectangle bounds = getBounds();
/* 65 */     if (bounds == null) {
/* 66 */       return false;
/*    */     }
/* 68 */     return (((Integer)this.result.getComponentImage().getGameFrameStatusType()).intValue() == 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean open() {
/* 73 */     if (isOpen()) return true; 
/* 74 */     Rectangle bounds = getBounds();
/* 75 */     if (bounds == null) return false; 
/* 76 */     this.core.getFinger().tap((Shape)bounds.getPadding(2));
/* 77 */     return this.core.submitTask(() -> isOpen(), 3000);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isVisible() {
/* 82 */     return super.isVisible();
/*    */   }
/*    */ 
/*    */   
/*    */   public Rectangle getBounds() {
/* 87 */     return super.getBounds();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\minimap\xpcounter\XPDropsComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */