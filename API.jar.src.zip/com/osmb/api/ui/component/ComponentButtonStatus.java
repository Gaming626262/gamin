/*   */ package com.osmb.api.ui.component;
/*   */ 
/*   */ public enum ComponentButtonStatus {
/* 4 */   RED,
/* 5 */   NORMAL,
/* 6 */   HIGHLIGHTED;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentButtonStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */