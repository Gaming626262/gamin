/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.ui.GameState;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Component<T>
/*    */ {
/*    */   ComponentSearchResult<T> getResult();
/*    */   
/*    */   GameState getComponentGameState();
/*    */   
/*    */   default boolean isVisible() {
/* 18 */     Rectangle bounds = getBounds();
/* 19 */     if (bounds != null) {
/* 20 */       return true;
/*    */     }
/* 22 */     return false;
/*    */   }
/*    */   
/*    */   void updateSearchResult(ComponentSearchResult<T> paramComponentSearchResult);
/*    */   
/*    */   ScriptCore getScriptCore();
/*    */   
/*    */   default Rectangle getBounds() {
/* 30 */     ComponentSearchResult<T> result = getResult();
/* 31 */     if (result == null || !getResult().getScreenUpdateUUID().equals(getScriptCore().getScreen().getUUID())) {
/* 32 */       return null;
/*    */     }
/* 34 */     return result.getBounds();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\Component.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */