/*    */ package com.osmb.api.ui.component.hotkeys;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.shape.Shape;
/*    */ import com.osmb.api.ui.component.Component;
/*    */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*    */ import com.osmb.api.ui.component.ComponentSearchResult;
/*    */ import com.osmb.api.ui.component.hotkeys.functions.HotKeyTabComponent;
/*    */ import com.osmb.api.ui.component.hotkeys.functions.TapToDrop;
/*    */ import com.osmb.api.ui.hotkeys.Hotkeys;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class HotKeyManager implements Hotkeys {
/*    */   private final Map<Class<? extends Component>, HotKeyTabComponent> hotkeys;
/*    */   private final ScriptCore core;
/*    */   
/*    */   public HotKeyManager(ScriptCore core, Map<Class<? extends Component>, HotKeyTabComponent> hotkeys) {
/* 20 */     this.core = core;
/* 21 */     this.hotkeys = hotkeys;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public UIResult<Boolean> isTapToDropEnabled() {
/* 27 */     HotKeyTabComponent hotKeyTabComponent = this.hotkeys.get(TapToDrop.class);
/* 28 */     if (!hotKeyTabComponent.isVisible()) {
/* 29 */       return UIResult.notVisible();
/*    */     }
/* 31 */     ComponentSearchResult result = hotKeyTabComponent.getResult();
/* 32 */     if (result == null) {
/* 33 */       return UIResult.notVisible();
/*    */     }
/* 35 */     ComponentButtonStatus buttonStatus = (ComponentButtonStatus)result.getComponentImage().getGameFrameStatusType();
/* 36 */     if (buttonStatus == ComponentButtonStatus.RED) {
/* 37 */       return UIResult.of(Boolean.valueOf(true));
/*    */     }
/* 39 */     return UIResult.of(Boolean.valueOf(false));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setTapToDropEnabled(boolean enabled) {
/* 44 */     HotKeyTabComponent hotKeyTabComponent = this.hotkeys.get(TapToDrop.class);
/* 45 */     Rectangle bounds = hotKeyTabComponent.getBounds();
/* 46 */     if (bounds == null) {
/* 47 */       return false;
/*    */     }
/* 49 */     ComponentSearchResult result = hotKeyTabComponent.getResult();
/* 50 */     if (result == null) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     ComponentButtonStatus buttonStatus = (ComponentButtonStatus)result.getComponentImage().getGameFrameStatusType();
/*    */     
/* 56 */     boolean selected = (buttonStatus == ComponentButtonStatus.RED);
/* 57 */     if (selected == enabled) {
/* 58 */       return true;
/*    */     }
/*    */     
/* 61 */     this.core.getFinger().tap((Shape)bounds.getPadding(2));
/* 62 */     return this.core.submitTask(() -> { UIResult<Boolean> result_ = isTapToDropEnabled(); return result_.isFound() ? ((Boolean)result_.get()).booleanValue() : false; }3000);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\hotkeys\HotKeyManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */