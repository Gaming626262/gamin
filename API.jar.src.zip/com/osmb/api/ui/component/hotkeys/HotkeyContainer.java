/*     */ package com.osmb.api.ui.component.hotkeys;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.ComponentContainerStatus;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.ui.component.ComponentParent;
/*     */ import com.osmb.api.ui.component.ComponentSearchResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ public class HotkeyContainer
/*     */   extends ComponentParent<ComponentContainerStatus>
/*     */ {
/*     */   public HotkeyContainer(ScriptCore scriptCoreService) {
/*  25 */     super(scriptCoreService);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ComponentSearchResult onFound(ImageSearchResult result, int iconID, ComponentImage foundImage) {
/*  31 */     if (foundImage.getGameFrameStatusType() == ComponentContainerStatus.EXPANDED) {
/*  32 */       int backgroundID = foundImage.getBackgroundID();
/*  33 */       int x = result.getX();
/*  34 */       int y = result.getY();
/*  35 */       if (backgroundID == 5784) {
/*  36 */         ComponentImage<ComponentContainerStatus> bottomContainer = getComponentImages().stream().filter(gameFrameContainer -> (gameFrameContainer.getBackgroundID() == 5783)).findFirst().get();
/*     */ 
/*     */         
/*  39 */         ImageSearchResult otherResult = null;
/*  40 */         for (int y_ = result.getY(); y_ < y + 210; y_++) {
/*  41 */           otherResult = this.core.getImageAnalyzer().isSubImageAt(x, y_, bottomContainer.getSearchableImage());
/*  42 */           if (otherResult != null)
/*     */             break; 
/*  44 */         }  if (otherResult == null) {
/*  45 */           this.core.log(getClass().getSimpleName(), "Cannot find bottom half of hotkey tab");
/*  46 */           return null;
/*     */         } 
/*  48 */         int bottomY = otherResult.getY() + otherResult.getHeight();
/*  49 */         int finalHeight = bottomY - y;
/*  50 */         return new ComponentSearchResult(result, foundImage, new Rectangle(x, y, result.getWidth(), finalHeight));
/*  51 */       }  if (backgroundID == 5783) {
/*  52 */         ComponentImage<ComponentContainerStatus> topContainer = getComponentImages().stream().filter(gameFrameContainer -> (gameFrameContainer.getBackgroundID() == 5784)).findFirst().get();
/*     */         
/*  54 */         ImageSearchResult otherResult = null;
/*  55 */         for (int y_ = result.getY(); y_ < y - 210; y_--) {
/*  56 */           otherResult = this.core.getImageAnalyzer().isSubImageAt(x, y_, topContainer.getSearchableImage());
/*  57 */           if (otherResult != null)
/*     */             break; 
/*  59 */         }  if (otherResult == null) {
/*  60 */           this.core.log(getClass().getSimpleName(), "Cannot find top half of hotkey tab");
/*  61 */           return null;
/*     */         } 
/*  63 */         int topY = otherResult.getY();
/*  64 */         int bottomY = y + result.getHeight();
/*  65 */         int finalHeight = bottomY - y;
/*  66 */         return new ComponentSearchResult(result, foundImage, new Rectangle(x, topY, result.getWidth(), finalHeight));
/*     */       } 
/*     */     } 
/*  69 */     return new ComponentSearchResult(result, foundImage);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ComponentImage<ComponentContainerStatus>> buildBackgrounds() {
/*  74 */     List<ComponentImage<ComponentContainerStatus>> images = new ArrayList<>();
/*     */ 
/*     */     
/*  77 */     Canvas canvas = new Canvas(5782, this.core);
/*  78 */     canvas.fillRect(10, 15, 39, 26, 16711935);
/*  79 */     SearchableImage closed = canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.HSL);
/*  80 */     images.add(new ComponentImage(closed, 5782, ComponentContainerStatus.COLLAPSED));
/*     */     
/*  82 */     canvas = new Canvas(5784, this.core);
/*  83 */     canvas.fillRect(0, 0, canvas.canvasWidth, 1, 16711935);
/*  84 */     SearchableImage topImage = canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.HSL);
/*  85 */     images.add(new ComponentImage(topImage, 5784, ComponentContainerStatus.EXPANDED));
/*     */     
/*  87 */     canvas = new Canvas(5783, this.core);
/*  88 */     canvas.fillRect(10, 5, 39, 26, 16711935);
/*  89 */     SearchableImage bottomImage = canvas.toSearchableImage((ToleranceComparator)new SingleThresholdComparator(5), ColorModel.HSL);
/*  90 */     images.add(new ComponentImage(bottomImage, 5783, ComponentContainerStatus.EXPANDED));
/*  91 */     return images;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/*  96 */     return Map.of();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/* 101 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\hotkeys\HotkeyContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */