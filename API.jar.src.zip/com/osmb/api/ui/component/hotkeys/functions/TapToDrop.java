/*    */ package com.osmb.api.ui.component.hotkeys.functions;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ 
/*    */ public class TapToDrop
/*    */   extends HotKeyTabComponent
/*    */ {
/*    */   public TapToDrop(ScriptCore scriptCoreService) {
/*  9 */     super(scriptCoreService);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconXOffset() {
/* 14 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getIconYOffset() {
/* 19 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getIcons() {
/* 24 */     return new int[] { 4799 };
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\hotkeys\functions\TapToDrop.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */