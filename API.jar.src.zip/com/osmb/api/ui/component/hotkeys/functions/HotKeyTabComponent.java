/*     */ package com.osmb.api.ui.component.hotkeys.functions;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.shape.Shape;
/*     */ import com.osmb.api.ui.GameState;
/*     */ import com.osmb.api.ui.component.ComponentButtonStatus;
/*     */ import com.osmb.api.ui.component.ComponentChild;
/*     */ import com.osmb.api.ui.component.ComponentImage;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.visual.color.ColorModel;
/*     */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*     */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*     */ import com.osmb.api.visual.drawing.Canvas;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.image.SearchableImage;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ public abstract class HotKeyTabComponent
/*     */   extends ComponentChild<ComponentButtonStatus>
/*     */ {
/*  25 */   protected static final ToleranceComparator TOLERANCE_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(10);
/*     */   
/*     */   public HotKeyTabComponent(ScriptCore scriptCoreService) {
/*  28 */     super(scriptCoreService);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getBounds() {
/*  33 */     return super.getBounds();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameState getComponentGameState() {
/*  38 */     return GameState.LOGGED_IN;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Integer, SearchableImage> buildIcons() {
/*  43 */     Map<Integer, SearchableImage> icons = new HashMap<>();
/*  44 */     for (int icon : getIcons()) {
/*  45 */       SearchableImage iconImage = new SearchableImage(icon, this.core, TOLERANCE_COMPARATOR, ColorModel.RGB);
/*  46 */       icons.put(Integer.valueOf(icon), iconImage);
/*     */     } 
/*  48 */     return icons;
/*     */   }
/*     */ 
/*     */   
/*     */   public UIResult<Integer> findIcon(Rectangle containerBounds) {
/*  53 */     if (containerBounds == null) {
/*  54 */       return UIResult.notVisible();
/*     */     }
/*  56 */     for (Map.Entry<Integer, SearchableImage> icon : (Iterable<Map.Entry<Integer, SearchableImage>>)this.componentIcons.entrySet()) {
/*  57 */       SearchableImage image = icon.getValue();
/*  58 */       int centerX = containerBounds.width / 2 - image.width / 2;
/*  59 */       int centerY = containerBounds.height / 2 - image.height / 2;
/*     */       
/*  61 */       ImageSearchResult result = this.core.getImageAnalyzer().isSubImageAt(containerBounds.x + centerX + getIconXOffset(), containerBounds.y + centerY + getIconYOffset(), image);
/*     */       
/*  63 */       if (result != null) {
/*  64 */         return UIResult.of(icon.getKey());
/*     */       }
/*     */     } 
/*  67 */     return UIResult.of(null);
/*     */   }
/*     */   
/*     */   protected int getIconXOffset() {
/*  71 */     return 0;
/*     */   }
/*     */   
/*     */   protected int getIconYOffset() {
/*  75 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ComponentImage<ComponentButtonStatus>> buildBackgrounds() {
/*  81 */     Canvas canvas = new Canvas(5767, this.core);
/*  82 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/*  83 */     SearchableImage normalTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/*  85 */     canvas = new Canvas(5768, this.core);
/*  86 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/*  87 */     SearchableImage highlightedTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/*  89 */     canvas = new Canvas(5769, this.core);
/*  90 */     canvas.fillRect(2, 2, canvas.canvasWidth - 4, canvas.canvasHeight - 4, 16711935);
/*  91 */     SearchableImage redTabImage = canvas.toSearchableImage((ToleranceComparator)SingleThresholdComparator.ZERO_TOLERANCE, ColorModel.RGB);
/*     */     
/*  93 */     ComponentImage<ComponentButtonStatus> normalTab = new ComponentImage(normalTabImage, 5767, ComponentButtonStatus.NORMAL);
/*  94 */     ComponentImage<ComponentButtonStatus> highlightedTab = new ComponentImage(highlightedTabImage, 5767, ComponentButtonStatus.HIGHLIGHTED);
/*  95 */     ComponentImage<ComponentButtonStatus> redTab = new ComponentImage(redTabImage, 5767, ComponentButtonStatus.RED);
/*  96 */     return List.of(normalTab, highlightedTab, redTab);
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 100 */     if (this.result == null) return false; 
/* 101 */     return (this.result.getComponentImage().getGameFrameStatusType() == ComponentButtonStatus.RED);
/*     */   }
/*     */   
/*     */   public boolean open() {
/* 105 */     if (isOpen()) return true; 
/* 106 */     Rectangle bounds = getBounds();
/* 107 */     if (bounds == null) return false; 
/* 108 */     this.core.getFinger().tap((Shape)bounds.getPadding(2));
/* 109 */     return this.core.submitTask(() -> isOpen(), 3000);
/*     */   }
/*     */   
/*     */   public boolean isVisible() {
/* 113 */     return (getBounds() != null);
/*     */   }
/*     */   
/*     */   public abstract int[] getIcons();
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\hotkeys\functions\HotKeyTabComponent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */