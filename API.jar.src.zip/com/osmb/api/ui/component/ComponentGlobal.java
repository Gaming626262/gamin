/*    */ package com.osmb.api.ui.component;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import com.osmb.api.visual.image.SearchableImage;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public interface ComponentGlobal<T>
/*    */   extends Component<T> {
/*    */   List<ComponentImage<T>> buildBackgrounds();
/*    */   
/*    */   Map<Integer, SearchableImage> buildIcons();
/*    */   
/*    */   List<ComponentImage<T>> getComponentImages();
/*    */   
/*    */   default UIResult<Integer> findIcon(Rectangle containerBounds) {
/* 18 */     return UIResult.notVisible();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\component\ComponentGlobal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */