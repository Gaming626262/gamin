/*    */ package com.osmb.api.ui.spellbook;
/*    */ 
/*    */ public enum ArceeusSpellbook
/*    */   implements Spell {
/*  5 */   HOME_TELEPORT("Home teleport", new int[] { 1251, 2056 }),
/*  6 */   LIBRARY_TELEPORT("Library teleport", new int[] { 1252, 2057 }),
/*  7 */   BASIC_REANIMATION("Basic reanimation", new int[] { 1247, 2052 }),
/*  8 */   DRAYNOR_MANOR_TELEPORT("Draynor manor teleport", new int[] { 1253, 2058 }),
/*  9 */   BATTLEFRONT_TELEPORT("Battlefront teleport", new int[] { 1255, 2060 }),
/* 10 */   MIND_ALTAR_TELEPORT("Mind altar teleport", new int[] { 1256, 2061 }),
/* 11 */   RESPAWN_TELEPORT("Respawn teleport", new int[] { 1257, 2062 }),
/* 12 */   GHOSTLY_GRASP("Ghostly grasp", new int[] { 1267, 2072 }),
/* 13 */   RESURRECT_LESSER_GHOST("Resurrect Lesser ghost", new int[] { 1270, 2075 }),
/* 14 */   RESURRECT_LESSER_SKELETON("Resurrect Lesser skeleton", new int[] { 1271, 2076 }),
/* 15 */   RESURRECT_LESSER_ZOMBIE("Resurrect Lesser zombie", new int[] { 1300, 2077 }),
/* 16 */   SALVE_GRAVEYARD_TELEPORT("Salve teleport", new int[] { 1258, 2063 }),
/* 17 */   ADEPT_REANIMATION("Adept reanimation", new int[] { 1248, 2053 }),
/* 18 */   INFERIOR_DEMONBANE("Inferior demonbane", new int[] { 1302, 2079 }),
/* 19 */   SHADOW_VEIL("Shadow veil", new int[] { 1315, 2991 }),
/* 20 */   FENKENSTRAINS_CASTLE_TELEPORT("Fenkenstrains castle teleport", new int[] { 1259, 2074 }),
/* 21 */   DARK_LURE("Dark lure", new int[] { 1316, 2992 }),
/* 22 */   SKELETAL_GRASP("Skeletal grasp", new int[] { 1268, 2073 }),
/* 23 */   RESURRECT_SUPERIOR_GHOST("Resurrect Superior ghost", new int[] { 2979, 2995 }),
/* 24 */   RESURRECT_SUPERIOR_SKELETON("Resurrect Superior skeleton", new int[] { 2981, 2997 }),
/* 25 */   RESURRECT_SUPERIOR_ZOMBIE("Resurrect Superior zombie", new int[] { 2983, 2999 }),
/* 26 */   MARK_OF_DARKNESS("Mark of darkness", new int[] { 1305, 2082 }),
/* 27 */   WEST_ARDOUGNE_TELEPORT("West Ardougne teleport", new int[] { 1260, 2065 }),
/* 28 */   SUPERIOR_DEMONBANE("Superior demonbane", new int[] { 1303, 2080 }),
/* 29 */   LESSER_CORRUPTION("Lesser corruption", new int[] { 1307, 2084 }),
/* 30 */   HARMONY_ISLAND_TELEPORT("Harmony Island teleport", new int[] { 1261, 2066 }),
/* 31 */   VILE_VIGOUR("Vile vigour", new int[] { 1317, 2993 }),
/* 32 */   DEGRIME("Degrime", new int[] { 1318, 2994 }),
/* 33 */   CEMETERY_TELEPORT("Cemetery teleport", new int[] { 1264, 2069 }),
/* 34 */   EXPERT_REANIMATION("Expert reanimation", new int[] { 1249, 2054 }),
/* 35 */   WARD_OF_ARCEUUS("Ward of Arceuus", new int[] { 1306, 2083 }),
/* 36 */   RESURRECT_GREATER_GHOST("Resurrect Greater ghost", new int[] { 2980, 2996 }),
/* 37 */   RESURRECT_GREATER_SKELETON("Resurrect Greater skeleton", new int[] { 2982, 2998 }),
/* 38 */   RESURRECT_GREATER_ZOMBIE("Resurrect Greater zombie", new int[] { 2984, 3000 }),
/* 39 */   RESURRECT_CROPS("Resurrect crops", new int[] { 1266, 2071 }),
/* 40 */   UNDEAD_GRASP("Undead grasp", new int[] { 1269, 2074 }),
/* 41 */   DEATH_CHARGE("Death charge", new int[] { 1310, 2087 }),
/* 42 */   DARK_DEMONBANE("Dark demonbane", new int[] { 1304, 2081 }),
/* 43 */   BARROWS_TELEPORT("Barrows teleport", new int[] { 1262, 2067 }),
/* 44 */   DEMONIC_OFFERING("Demonic offering", new int[] { 1311, 2088 }),
/* 45 */   GREATER_CORRUPTION("Greater corruption", new int[] { 1308, 2085 }),
/* 46 */   MASTER_REANIMATION("Master reanimation", new int[] { 1250, 2055 }),
/* 47 */   APE_ATOLL_TELEPORT("Ape Atoll teleport", new int[] { 1263, 2068 }),
/* 48 */   SINISTER_OFFERING("Sinister offering", new int[] { 1312, 2089 });
/*    */   
/*    */   private final String name;
/*    */   private final int[] spriteIDs;
/*    */   
/*    */   ArceeusSpellbook(String name, int[] spriteIDs) {
/* 54 */     this.name = name;
/* 55 */     this.spriteIDs = spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getSpriteIDs() {
/* 60 */     return this.spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 65 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\spellbook\ArceeusSpellbook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */