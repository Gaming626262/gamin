/*    */ package com.osmb.api.ui.spellbook;
/*    */ 
/*    */ public enum AncientSpellbook
/*    */   implements Spell {
/*    */   private final String name;
/*    */   private final int[] spriteIDs;
/*    */   
/*    */   AncientSpellbook(String name, int[] spriteIDs) {
/*  9 */     this.name = name;
/* 10 */     this.spriteIDs = spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getSpriteIDs() {
/* 15 */     return this.spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 20 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\spellbook\AncientSpellbook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */