/*    */ package com.osmb.api.ui.spellbook;
/*    */ 
/*    */ public enum LunarSpellbook implements Spell {
/*  4 */   HOME_TELEPORT("Home teleport", new int[] { 356, 1802 }),
/*  5 */   BAKE_PIE("Bake pie", new int[] { 543, 1952 }),
/*  6 */   GEOMANCY("Geomancy", new int[] { 563, 1967 }),
/*  7 */   CURE_PLANT("Cure plant", new int[] { 567, 1968 }),
/*  8 */   MONSTER_EXAMINE("Monster examine", new int[] { 577, 1971 }),
/*  9 */   NPC_CONTACT("NPC contact", new int[] { 568, 1969 }),
/* 10 */   CURE_OTHER("Cure other", new int[] { 559, 1962 }),
/* 11 */   HUMIDIFY("Humidify", new int[] { 578, 1972 }),
/* 12 */   MOONCLAN_TELEPORT("Moonclan teleport", new int[] { 544, 1980 }),
/* 13 */   TELE_GROUP_MOONCLAN("Tele group moonclan", new int[] { 569, 1988 }),
/* 14 */   CURE_ME("Cure me", new int[] { 562, 1964 }),
/* 15 */   OURANIA_TELEPORT("Ourania teleport", new int[] { 586, 1981 }),
/* 16 */   HUNTER_KIT("Hunter kit", new int[] { 579, 1973 }),
/* 17 */   WATERBIRTH_TELEPORT("Waterbirth teleport", new int[] { 545, 1982 }),
/* 18 */   TELE_GROUP_WATERBIRTH("Tele group Waterbirth", new int[] { 570, 1989 }),
/* 19 */   CURE_GROUP("Cure group", new int[] { 565, 1965 }),
/* 20 */   STAT_SPY("Stat spy", new int[] { 576, 1970 }),
/* 21 */   BARBARIAN_TELEPORT("Barbarian teleport", new int[] { 547, 1983 }),
/* 22 */   TELE_GROUP_BARBARIAN("Tele group barbarian", new int[] { 571, 1990 }),
/* 23 */   SPIN_FLAX("Spin flax", new int[] { 585, 1979 }),
/* 24 */   SUPERGLASS_MAKE("Superglass make", new int[] { 548, 1953 }),
/* 25 */   TAN_LEATHER("Tan leather", new int[] { 583, 1977 }),
/* 26 */   KHAZARD_TELEPORT("Khazard teleport", new int[] { 549, 1984 }),
/* 27 */   TELE_GROUP_KHAZARD("Tele group Khazard", new int[] { 572, 1991 }),
/* 28 */   DREAM("Dream", new int[] { 580, 1974 }),
/* 29 */   STRING_JEWELLERY("String Jewellery", new int[] { 550, 1954 }),
/* 30 */   STAT_RESTORE_POT_SHARE("Stat restore pot share", new int[] { 554, 1955 }),
/* 31 */   MAGIC_IMBUE("Magic imbue", new int[] { 552, 1957 }),
/* 32 */   FERTILE_SOIL("Fertile soil", new int[] { 553, 1958 }),
/* 33 */   BOOST_POTION_SHARE("Boost potion share", new int[] { 551, 1956 }),
/* 34 */   FISHING_GUILD_TELEPORT("Fishing guild teleport", new int[] { 555, 1985 }),
/* 35 */   TELEPORT_TO_TARGET("Teleport to target", new int[] { 555 }),
/* 36 */   TELE_GROUP_FISHING_GUILD("Tele group Fishing guild", new int[] { 573, 1992 }),
/* 37 */   PLANK_MAKE("Plank make", new int[] { 581, 1975 }),
/* 38 */   CATHERBY_TELEPORT("Catherby teleport", new int[] { 556, 1986 }),
/* 39 */   TELE_GROUP_CATHERBY("Tele group Catherby", new int[] { 574, 1993 }),
/* 40 */   RECHARGE_DRAGONSTONE("Recharge Dragonstone", new int[] { 584, 1978 }),
/* 41 */   ICE_PLATEAU_TELEPORT("Ice plateau teleport", new int[] { 557, 1987 }),
/* 42 */   TELE_GROUP_ICE_PLATEAU("Tele group Ice plateau", new int[] { 575, 1994 }),
/* 43 */   ENERGY_TRANSFER("Energy transfer", new int[] { 558, 1959 }),
/* 44 */   HEAL_OTHER("Heal other", new int[] { 560, 1963 }),
/* 45 */   VENGEANCE_OTHER("Vengeance other", new int[] { 561, 1960 }),
/* 46 */   VENGEANCE("Vengeance", new int[] { 564, 1961 }),
/* 47 */   HEAL_GROUP("Heal group", new int[] { 566, 1966 }),
/* 48 */   SPELLBOOK_SWAP("Spellbook swap", new int[] { 582, 1976 });
/*    */   
/*    */   private final String name;
/*    */   private final int[] spriteIDs;
/*    */   
/*    */   LunarSpellbook(String name, int[] spriteIDs) {
/* 54 */     this.name = name;
/* 55 */     this.spriteIDs = spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 60 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getSpriteIDs() {
/* 65 */     return this.spriteIDs;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\spellbook\LunarSpellbook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */