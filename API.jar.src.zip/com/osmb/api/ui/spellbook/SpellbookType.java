/*    */ package com.osmb.api.ui.spellbook;
/*    */ 
/*    */ public enum SpellbookType {
/*  4 */   STANDARD((Spell[])StandardSpellbook.values()),
/*  5 */   LUNARS((Spell[])LunarSpellbook.values()),
/*  6 */   ANCIENT((Spell[])AncientSpellbook.values()),
/*  7 */   ARCEUUS((Spell[])ArceeusSpellbook.values());
/*    */   
/*    */   private final Spell[] spells;
/*    */   
/*    */   SpellbookType(Spell[] spells) {
/* 12 */     this.spells = spells;
/*    */   }
/*    */   
/*    */   public Spell[] getSpells() {
/* 16 */     return this.spells;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\spellbook\SpellbookType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */