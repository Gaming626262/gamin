/*    */ package com.osmb.api.ui.spellbook;
/*    */ 
/*    */ public enum StandardSpellbook implements Spell {
/*  4 */   WIND_STRIKE("Wind strike", new int[] { 15, 0 }),
/*  5 */   CONFUSE("Confuse", new int[] { 16, 1782 }),
/*  6 */   WATER_STRIKE("Water strike", new int[] { 17, 1 }),
/*  7 */   JEWELLERY_ENCHANTMENTS("Jewellery enchantments", new int[] { 366, 1803 }),
/*  8 */   EARTH_STRIKE("Earth strike", new int[] { 19, 2 }),
/*  9 */   WEAKEN("Weaken", new int[] { 20, 1783 }),
/* 10 */   FIRE_STRIKE("Fire strike", new int[] { 21, 3 }),
/* 11 */   BONES_TO_BANANAS("Bones to bananas", new int[] { 22, 1777 }),
/* 12 */   WIND_BOLT("Wind bolt", new int[] { 23, 5 }),
/* 13 */   CURSE("Curse", new int[] { 24, 1784 }),
/* 14 */   BIND("Bind", new int[] { 319, 1788 }),
/* 15 */   LOW_ALCHEMY("Low alchemy", new int[] { 25, 1780 }),
/* 16 */   WATER_BOLT("Water bolt", new int[] { 26, 6 }),
/* 17 */   VARROCK_TELEPORT("Varrock teleport", new int[] { 27, 1752 }),
/* 18 */   EARTH_BOLT("Earth bolt", new int[] { 29, 7 }),
/* 19 */   LUMBRIDGE_TELEPORT("Lumbridge teleport", new int[] { 30, 1753 }),
/* 20 */   TELEKINETIC_GRAB("Telekinetic grab", new int[] { 31, 1778 }),
/* 21 */   FIRE_BOLT("Fire bolt", new int[] { 32, 8 }),
/* 22 */   FALADOR_TELEPORT("Falador teleport", new int[] { 33, 1754 }),
/* 23 */   CRUMBLE_UNDEAD("Crumble undead", new int[] { 34, 1779 }),
/* 24 */   TELEPORT_TO_HOUSE("Teleport to house", new int[] { 355, 1755 }),
/* 25 */   WIND_BLAST("Wind blast", new int[] { 35, 9 }),
/* 26 */   SUPERHEAT_ITEM("Superheat item", new int[] { 36, 1800 }),
/* 27 */   CAMELOT_TELEPORT("Camelot teleport", new int[] { 37, 1756 }),
/* 28 */   WATER_BLAST("Water blast", new int[] { 38, 10 }),
/* 29 */   KOUREND_TELEPORT("Kourend teleport", new int[] { 39, 1754 }),
/* 30 */   IBAN_BLAST("Iban blast", new int[] { 53, 1772 }),
/* 31 */   SNARE("Snare", new int[] { 320, 1789 }),
/* 32 */   MAGIC_DART("Magic dart", new int[] { 324, 1798 }),
/* 33 */   ARDOUGNE_TELEPORT("Ardougne teleport", new int[] { 54, 1757 }),
/* 34 */   EARTH_BLAST("Earth blast", new int[] { 40, 11 }),
/* 35 */   CIVITAS_ILLA_FORTIS_TELEPORT("Civitas Illa Fortis teleport", new int[0]),
/* 36 */   HIGH_LEVEL_ALCHEMY("High level alchemy", new int[] { 41, 1781 }),
/* 37 */   CHARGE_WATER_ORB("Charge water orb", new int[] { 42, 1793 }),
/* 38 */   WATCHTOWER_TELEPORT("Watchtower teleport", new int[] { 55, 1758 }),
/* 39 */   FIRE_BLAST("Fire blast", new int[] { 44, 13 }),
/* 40 */   CHARGE_EARTH_ORB("Charge earth orb", new int[] { 45, 1794 }),
/* 41 */   BONES_TO_PEACHES("Bones to peaches", new int[] { 22, 1777 }),
/* 42 */   SARADOMIN_STRIKE("Saradomin strike", new int[] { 61, 1775 }),
/* 43 */   CLAWS_OF_GUTHIX("Claws of Guthix", new int[] { 60, 1774 }),
/* 44 */   FLAMES_OF_ZAMORAK("Flames of Zamorak", new int[] { 59, 1773 }),
/* 45 */   TROLLHEIM_TELEPORT("Trollheim teleport", new int[] { 323, 1750 }),
/* 46 */   WIND_WAVE("Wind wave", new int[] { 46, 14 }),
/* 47 */   CHARGE_FIRE_ORB("Charge fire orb", new int[] { 47, 1795 }),
/* 48 */   APE_ATOLL_TELEPORT("Ape Atoll teleport", new int[] { 54, 1757 }),
/* 49 */   WATER_WAVE("Water wave", new int[] { 48, 305 }),
/* 50 */   CHARGE_AIR_ORB("Charge air orb", new int[] { 49, 1796 }),
/* 51 */   VULNERABILITY("Vulnerability", new int[] { 56, 1785 }),
/* 52 */   EARTH_WAVE("Earth wave", new int[] { 51, 306 }),
/* 53 */   ENFEEBLE("Enfeeble", new int[] { 57, 1786 }),
/* 54 */   TELEOTHER_LUMBRIDGE("Teleother Lumbridge", new int[] { 349, 1762 }),
/* 55 */   FIRE_WAVE("Fire wave", new int[] { 52, 307 }),
/* 56 */   ENTANGLE("Entangle", new int[] { 321, 1790 }),
/* 57 */   STUN("Stun", new int[] { 58, 1787 }),
/* 58 */   CHARGE("Charge", new int[] { 322, 1776 }),
/* 59 */   WIND_SURGE("Wind surge", new int[] { 362, 1098 }),
/* 60 */   TELEOTHER_FALADOR("Teleother Falador", new int[] { 350, 1763 }),
/* 61 */   WATER_SURGE("Water surge", new int[] { 360, 1098 }),
/* 62 */   TELE_BLOCK("Tele block", new int[] { 352, 1792 }),
/* 63 */   TELEPORT_TO_TARGET("Teleport to target", new int[0]),
/* 64 */   TELEOTHER_CAMELOT("Teleother Camelot", new int[] { 351, 1764 }),
/* 65 */   EARTH_SURGE("Earth surge", new int[] { 364, 1100 }),
/* 66 */   FIRE_SURGE("Fire surge", new int[] { 365, 1751 });
/*    */   
/*    */   private final String name;
/*    */   private final int[] spriteIDs;
/*    */   
/*    */   StandardSpellbook(String name, int[] spriteIDs) {
/* 72 */     this.name = name;
/* 73 */     this.spriteIDs = spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] getSpriteIDs() {
/* 78 */     return this.spriteIDs;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 83 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\spellbook\StandardSpellbook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */