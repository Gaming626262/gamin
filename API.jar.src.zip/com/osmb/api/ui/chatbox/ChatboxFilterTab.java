/*    */ package com.osmb.api.ui.chatbox;
/*    */ 
/*    */ public enum ChatboxFilterTab {
/*  4 */   ALL,
/*  5 */   GAME,
/*  6 */   PUBLIC,
/*  7 */   PRIVATE,
/*  8 */   CHANNEL,
/*  9 */   CLAN,
/* 10 */   TRADE;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\chatbox\ChatboxFilterTab.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */