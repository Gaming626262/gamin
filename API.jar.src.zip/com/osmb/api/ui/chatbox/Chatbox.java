package com.osmb.api.ui.chatbox;

import com.osmb.api.shape.Rectangle;
import com.osmb.api.ui.Expandable;

public interface Chatbox extends Expandable {
  ChatboxFilterTab getActiveFilterTab();
  
  String getUsername();
  
  Rectangle getUsernameBounds();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\chatbox\Chatbox.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */