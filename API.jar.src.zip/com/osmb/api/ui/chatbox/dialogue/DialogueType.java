/*    */ package com.osmb.api.ui.chatbox.dialogue;
/*    */ 
/*    */ public enum DialogueType {
/*  4 */   ITEM_OPTION,
/*  5 */   TEXT_OPTION,
/*  6 */   CHAT_DIALOGUE,
/*  7 */   TAP_HERE_TO_CONTINUE,
/*  8 */   TEXT_SEARCH,
/*  9 */   ENTER_AMOUNT,
/* 10 */   ITEM_SEARCH;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\chatbox\dialogue\DialogueType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */