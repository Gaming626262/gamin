package com.osmb.api.ui.chatbox.dialogue;

import com.osmb.api.shape.Rectangle;

public interface Dialogue {
  DialogueType getDialogueType();
  
  Rectangle getBounds();
  
  String[] getOptions();
  
  String getText();
  
  Rectangle[] getTextLines(int paramInt1, int paramInt2);
  
  boolean selectOption(String paramString);
  
  boolean selectItem(int... paramVarArgs);
  
  String getDialogueTitle();
  
  boolean isVisible();
  
  boolean continueChatDialogue();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\chatbox\dialogue\Dialogue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */