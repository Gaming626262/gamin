package com.osmb.api.ui.hotkeys;

import com.osmb.api.utils.UIResult;

public interface Hotkeys {
  UIResult<Boolean> isTapToDropEnabled();
  
  boolean setTapToDropEnabled(boolean paramBoolean);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\hotkeys\Hotkeys.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */