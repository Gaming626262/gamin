package com.osmb.api.ui;

public class SpriteID {
  public static final int EXAPND_POPOUT_ICON = 4797;
  
  public static final int CLOSE_POPOUT_ICON = 4806;
  
  public static final int HOTKEY_ARROW_UP = 4802;
  
  public static final int HOTKEY_ARROW_DOWN = 4803;
  
  public static final int HOTKEY_CONTAINER_CLOSED = 5782;
  
  public static final int HOTKEY_CONTAINER_TOP = 5784;
  
  public static final int HOTKEY_CONTAINER_BOTTOM = 5783;
  
  public static final int TAP_TO_DROP_ICON = 4799;
  
  public static final int DISABLE_ENTITY_OPTIONS_ICON = 4807;
  
  public static final int TILE_HIGHLIGHTS_ICON = 4800;
  
  public static final int ENTITY_HIGHLIGHTS_ICON = 5797;
  
  public static final int EDIT_GROUND_ITEMS_ICON = 4825;
  
  public static final int STEEL_BORDER_NW = 310;
  
  public static final int STEEL_BORDER_NE = 311;
  
  public static final int STEEL_BORDER_SW = 312;
  
  public static final int STEEL_BORDER_SE = 313;
  
  public static final int ITEM_DIALOGUE_BORDER_NW = 1554;
  
  public static final int ITEM_DIALOGUE_BORDER_NE = 1555;
  
  public static final int ITEM_DIALOGUE_BORDER_SW = 1556;
  
  public static final int ITEM_DIALOGUE_BORDER_SE = 1557;
  
  public static final int ITEM_DIALOGUE_BORDER_HIGHLIGHTED_NW = 1546;
  
  public static final int ITEM_DIALOGUE_BORDER_HIGHLIGHTED_NE = 1547;
  
  public static final int ITEM_DIALOGUE_BORDER_HIGHLIGHTED_SW = 1548;
  
  public static final int ITEM_DIALOGUE_BORDER_HIGHLIGHTED_SE = 1549;
  
  public static final int STEEL_BORDER_TOP = 314;
  
  public static final int STEEL_BORDER_BOTTOM = 173;
  
  public static final int STEEL_BORDER_LEFT = 172;
  
  public static final int STEEL_BORDER_RIGHT = 315;
  
  public static final int STONE_BORDER_NW = 824;
  
  public static final int STONE_BORDER_NE = 825;
  
  public static final int STONE_BORDER_SW = 826;
  
  public static final int STONE_BORDER_SE = 827;
  
  public static final int STONE_BORDER_TOP = 820;
  
  public static final int STONE_BORDER_BOTTOM = 822;
  
  public static final int STONE_BORDER_LEFT = 821;
  
  public static final int STONE_BORDER_RIGHT = 823;
  
  public static final int MODERN_BORDER_NW = 5814;
  
  public static final int MODERN_BORDER_NE = 5816;
  
  public static final int MODERN_BORDER_SW = 5820;
  
  public static final int MODERN_BORDER_SE = 5822;
  
  public static final int MODERN_BORDER_TOP = 5815;
  
  public static final int MODERN_BORDER_BOTTOM = 5821;
  
  public static final int MODERN_BORDER_LEFT = 5817;
  
  public static final int MODERN_BORDER_RIGHT = 5819;
  
  public static final int TAB_NORMAL = 5767;
  
  public static final int TAB_HIHGLIGHTED = 5768;
  
  public static final int TAB_RED = 5769;
  
  public static final int CHATBOX_FILTER_TAB_NORMAL = 5779;
  
  public static final int CHATBOX_FILTER_TAB_HIGHLIGHTED = 5780;
  
  public static final int CHATBOX_FILTER_TAB_RED = 5781;
  
  public static final int CHATBOX_ICON = 664;
  
  public static final int KEYBOARD_ICON = 4794;
  
  public static final int LOG_OUT_ICON = 3560;
  
  public static final int COLLAPSE_TAB_ICON = 4795;
  
  public static final int EXPAND_TAB_ICON = 4796;
  
  public static final int INVENTORY_TAB_ICON = 777;
  
  public static final int SKILLS_TAB_ICON = 775;
  
  public static final int EQUIPMENT_TAB_ICON = 778;
  
  public static final int EMOTE_TAB_ICON = 786;
  
  public static final int PRAYER_TAB_ICON = 779;
  
  public static final int MUSIC_TAB_ICON = 787;
  
  public static final int NORMAL_SPELLBOOK_TAB_ICON = 780;
  
  public static final int ANCIENT_SPELLBOOK_TAB_ICON = 1580;
  
  public static final int LUNAR_SPELLBOOK_TAB_ICON = 1581;
  
  public static final int ARCEUUS_SPELLBOOK_TAB_ICON = 1708;
  
  public static final int CLAN_TAB_ICON = 781;
  
  public static final int CLAN_TAB_BLUE_ICON = 2299;
  
  public static final int CLAN_TAB_CYAN_ICON = 2300;
  
  public static final int GROUPING_TAB_ICON = 3555;
  
  public static final int COMBAT_TAB_ICON = 774;
  
  public static final int FRIENDS_TAB_ICON = 782;
  
  public static final int IGNORE_TAB_ICON = 783;
  
  public static final int QUEST_TAB_ICON = 776;
  
  public static final int ACCOUNT_SETTINGS_TAB_ICON = 1709;
  
  public static final int SETTINGS_TAB_ICON = 785;
  
  public static final int SETTINGS_SUB_TAB_LEFT = 2285;
  
  public static final int SETTINGS_SUB_TAB_LEFT_TRANSPARENT = 6327;
  
  public static final int SETTINGS_SUB_TAB_CENTER = 2286;
  
  public static final int SETTINGS_SUB_TAB_CENTER_TRANSPARENT = 6328;
  
  public static final int SETTINGS_SUB_TAB_LEFT_SELECTED = 2283;
  
  public static final int SETTINGS_SUB_TAB_LEFT_SELECTED_TRANSPARENT = 6325;
  
  public static final int SETTINGS_SUB_TAB_CENTER_SELECTED = 2284;
  
  public static final int SETTINGS_SUB_TAB_CENTER_SELECTED_TRANSPARENT = 6326;
  
  public static final int SETTINGS_DISPLAY_ICON = 2933;
  
  public static final int SETTINGS_CONTROLS_ICON = 2410;
  
  public static final int SETTINGS_AUDIO_ICON = 911;
  
  public static final int CHATBOX_SIDE_TAB_NORMAL = 5773;
  
  public static final int CHATBOX_SIDE_TAB_HIHGLIGHTED = 5774;
  
  public static final int CHATBOX_SIDE_TAB_RED = 5775;
  
  public static final int HOTKEYS_TAB_COLLAPSED = 5782;
  
  public static final int HOTKEYS_TAB_OPEN_BOTTOM = 5783;
  
  public static final int HOTKEYS_TAB_OPEN_TOP = 5784;
  
  public static final int MINIMAP_ORB_NORMAL = 5791;
  
  public static final int MINIMAP_ORB_HIGHLIGHTED = 5792;
  
  public static final int MINIMAP_ORB_RED = 5793;
  
  public static final int CIRCLE_ORB_NORMAL = 5794;
  
  public static final int CIRCLE_ORB_HIGHLIGHTED = 5795;
  
  public static final int CIRCLE_ORB_RED = 5796;
  
  public static final int HEALTH_ORB_ICON = 1067;
  
  public static final int PRAYER_ORB_ICON = 1068;
  
  public static final int PRAYER_ORB_SELECTED_ICON = 1058;
  
  public static final int RUN_ORB_ICON = 1069;
  
  public static final int RUN_ORB_HIGHLIGHTED_ICON = 1070;
  
  public static final int RUN_ORB_BOOSTED_ICON = 1092;
  
  public static final int SPECIAL_ATTACK_ICON = 1610;
  
  public static final int ORB_BLACK_UNDERLAY = 1059;
  
  public static final int HEALTH_ORB_RED_UNDERLAY = 1060;
  
  public static final int HEALTH_ORB_POISON_UNDERLAY = 1061;
  
  public static final int HEALTH_ORB_DISEASED_UNDERLAY = 1062;
  
  public static final int HEALTH_ORB_VENOM_UNDERLAY = 1102;
  
  public static final int SPECIAL_ATTACK_ORB_UNDERLAY = 1607;
  
  public static final int SPECIAL_ATTACK_ORB_ACTIVATED_UNDERLAY = 1608;
  
  public static final int SPECIAL_ATTACK_ORB_DISABLED_UNDERLAY = 1064;
  
  public static final int RUN_ORB_UNDERLAY = 1064;
  
  public static final int RUN_ORB_ACTIVATED_UNDERLAY = 1065;
  
  public static final int PRAYER_ORB_UNDERLAY = 1063;
  
  public static final int PRAYER_ORB_ACTIVATED_UNDERLAY = 1066;
  
  public static final int MAP_AND_COMPASS = 5832;
  
  public static final int XP_DROPS_BUTTON = 1196;
  
  public static final int XP_DROPS_BUTTON_HIGHLIGHTED = 1198;
  
  public static final int XP_DROPS_BUTTON_ENABLED = 1197;
  
  public static final int XP_DROPS_BUTTON_ENABLED_HIGHLIGHTED = 1199;
  
  public static final int OLD_SCHOOL_BANNER = 2132;
  
  public static final int WELCOME_SCREEN_BANNER_TOP = 436;
  
  public static final int SLIDER_BAR_LEFT = 2852;
  
  public static final int SLIDER_BAR_RIGHT = 2857;
  
  public static final int GREEN_SLIDER_THUMB = 1201;
  
  public static final int BLUE_SLIDER_THUMB = 2858;
  
  public static final int DIALOGUE_CONTAINER = 1017;
  
  public static final int DIALOGUE_EXIT_BUTTON = 537;
  
  public static final int DIALOGUE_EXIT_BUTTON_HIGHLIGHTED = 538;
  
  public static final int SCROLL_BUTTON_UP = 773;
  
  public static final int LOGIN_CONTAINER = 499;
  
  public static final int LOGIN_CONTAINER_BUTTON = 500;
  
  public static final int LOGIN_CONTAINER_BUTTON_BIG = 1649;
  
  public static final int WORLD_SELECTION_MENU_BUTTON = 818;
  
  public static final int TAP_HERE_TO_PLAY = 429;
  
  public static final int BANK_TAB_INFINITY_ICON = 1081;
  
  public static final int BANK_TAB_PLUS_ICON = 1082;
  
  public static final int BANK_DEPOSIT_INVENTORY_ICON = 1041;
  
  public static final int BANK_DEPOSIT_EQUIPMENT_ICON = 1042;
  
  public static final int BANK_SEARCH_ICON = 1043;
  
  public static final int BANK_TAB_ACTIVE = 1077;
  
  public static final int BANK_TAB_ACTIVE_HIGHLIGHTED = 1078;
  
  public static final int BANK_TAB_ACTIVE_SELECTED = 1079;
  
  public static final int BANK_TAB_NEW = 1080;
  
  public static final int BANK_SQUARE_BUTTON = 170;
  
  public static final int BANK_SQUARE_BUTTON_RED = 179;
  
  public static final int BANK_TEXT_BUTTON_NW = 1141;
  
  public static final int BANK_TEXT_BUTTON_NE = 1143;
  
  public static final int BANK_TEXT_BUTTON_SW = 1147;
  
  public static final int BANK_TEXT_BUTTON_SE = 1149;
  
  public static final int BANK_TEXT_BUTTON_RED_NW = 1150;
  
  public static final int BANK_TEXT_BUTTON_RED_NE = 1152;
  
  public static final int BANK_TEXT_BUTTON_RED_SW = 1156;
  
  public static final int BANK_TEXT_BUTTON_RED_SE = 1158;
  
  public static final int BANK_CLOSE_BUTTON = 1731;
  
  public static final int PRAYER_ACTIVE_UNDERLAY = 4892;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\SpriteID.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */