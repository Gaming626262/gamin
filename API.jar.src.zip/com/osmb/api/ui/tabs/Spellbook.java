package com.osmb.api.ui.tabs;

import com.osmb.api.ui.Expandable;
import com.osmb.api.ui.spellbook.Spell;
import com.osmb.api.ui.spellbook.SpellbookType;
import com.osmb.api.utils.UIResult;
import java.awt.Point;
import java.util.function.BooleanSupplier;

public interface Spellbook extends Expandable {
  UIResult<Boolean> selectSpell(Spell paramSpell);
  
  UIResult<Boolean> castSpell(Spell paramSpell, Point paramPoint, BooleanSupplier paramBooleanSupplier);
  
  SpellbookType getSpellbookType();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\Spellbook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */