package com.osmb.api.ui.tabs;

public interface TabManager {
  Tab getActiveTabComponent();
  
  Tab.Type getActiveTab();
  
  Tab getTabComponent(Tab.Type paramType);
  
  boolean closeContainer();
  
  boolean openTab(Tab.Type paramType);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\TabManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */