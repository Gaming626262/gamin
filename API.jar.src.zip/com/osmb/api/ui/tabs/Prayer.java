/*    */ package com.osmb.api.ui.tabs;
/*    */ 
/*    */ import com.osmb.api.utils.UIResult;
/*    */ 
/*    */ 
/*    */ public interface Prayer
/*    */ {
/*    */   Type[] getActivePrayers();
/*    */   
/*    */   boolean setActive(Type paramType, boolean paramBoolean);
/*    */   
/*    */   UIResult<Integer> getPrayerPoints();
/*    */   
/*    */   public enum Type
/*    */   {
/* 16 */     THICK_SKIN(115),
/* 17 */     BURST_OF_STRENGTH(116),
/* 18 */     CLARITY_OF_THOUGHT(117),
/* 19 */     SHARP_EYE(133),
/* 20 */     MYSTIC_WILL(134),
/* 21 */     ROCK_SKIN(118),
/* 22 */     SUPERHUMAN_STRENGTH(119),
/* 23 */     IMPROVED_REFLEXES(120),
/* 24 */     RAPID_RESTORE(121),
/* 25 */     RAPID_HEAL(122),
/* 26 */     PROTECT_ITEM(123),
/* 27 */     HAWK_EYE(502),
/* 28 */     MYSTIC_LORE(503),
/* 29 */     STEEL_SKIN(124),
/* 30 */     ULTIMATE_STRENGTH(125),
/* 31 */     INCREDIBLE_REFLEXES(126),
/* 32 */     PROTECT_FROM_MAGIC(127),
/* 33 */     PROTECT_FROM_MISSILES(128),
/* 34 */     PROTECT_FROM_MELEE(129),
/* 35 */     EAGLE_EYE(504),
/* 36 */     MYSTIC_MIGHT(505),
/* 37 */     RETRIBUTION(131),
/* 38 */     REDEMPTION(130),
/* 39 */     SMITE(132),
/* 40 */     PRESERVE(947),
/* 41 */     CHIVALRY(945),
/* 42 */     PIETY(946),
/* 43 */     RIGOUR(1420),
/* 44 */     AUGURY(1421);
/*    */     
/*    */     private final int spriteID;
/*    */     
/*    */     Type(int spriteID) {
/* 49 */       this.spriteID = spriteID;
/*    */     }
/*    */     
/*    */     public int getSpriteID() {
/* 53 */       return this.spriteID;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\Prayer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */