/*    */ package com.osmb.api.ui.tabs;
/*    */ 
/*    */ import com.osmb.api.ui.component.Component;
/*    */ 
/*    */ public interface Tab
/*    */ {
/*    */   Component getContainer();
/*    */   
/*    */   boolean isOpen();
/*    */   
/*    */   boolean isVisible();
/*    */   
/*    */   Type getType();
/*    */   
/*    */   Component getComponent();
/*    */   
/*    */   boolean open();
/*    */   
/*    */   boolean close();
/*    */   
/*    */   public enum Type {
/* 22 */     INVENTORY,
/* 23 */     LOGOUT,
/* 24 */     SKILLS,
/* 25 */     EQUIPMENT,
/* 26 */     EMOTE,
/* 27 */     PRAYER,
/* 28 */     MUSIC,
/* 29 */     SPELLBOOK,
/* 30 */     CLAN,
/* 31 */     COMBAT,
/* 32 */     FRIENDS,
/* 33 */     QUEST,
/* 34 */     SETTINGS,
/* 35 */     ACCOUNT_SETTINGS,
/* 36 */     EXPAND_COLLAPSE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\Tab.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */