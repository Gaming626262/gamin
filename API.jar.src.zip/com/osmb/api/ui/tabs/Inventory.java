package com.osmb.api.ui.tabs;

import com.osmb.api.item.ItemGroup;
import com.osmb.api.ui.Expandable;

public interface Inventory extends Expandable, ItemGroup {}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\Inventory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */