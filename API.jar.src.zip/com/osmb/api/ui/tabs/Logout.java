package com.osmb.api.ui.tabs;

import com.osmb.api.ui.Expandable;

public interface Logout extends Expandable {
  boolean logout();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\tabs\Logout.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */