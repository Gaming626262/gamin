/*   */ package com.osmb.api.ui;
/*   */ 
/*   */ public enum GameState
/*   */ {
/* 5 */   LOGGED_IN,
/* 6 */   LOGGED_OUT,
/* 7 */   WELCOME_SCREEN,
/* 8 */   WORLD_SELECTION_MENU,
/* 9 */   APP_NOT_OPEN;
/*   */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\ap\\ui\GameState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */