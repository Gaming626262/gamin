/*    */ package com.osmb.api.item;
/*    */ 
/*    */ import com.osmb.api.definition.ItemDefinition;
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import com.osmb.api.utils.UIResult;
/*    */ import com.osmb.api.utils.UIResultList;
/*    */ import com.osmb.api.visual.color.tolerance.ToleranceComparator;
/*    */ import com.osmb.api.visual.color.tolerance.impl.SingleThresholdComparator;
/*    */ import com.osmb.api.visual.image.Image;
/*    */ import java.awt.Point;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ItemManager
/*    */ {
/* 21 */   public static final ToleranceComparator ITEM_TOLERANCE_COMPARATOR = (ToleranceComparator)new SingleThresholdComparator(22);
/*    */   
/*    */   boolean unSelectItemIfSelected();
/*    */   
/*    */   ItemDefinition getItemDefinition(int paramInt);
/*    */   
/*    */   List<ItemDefinition> getItemDefinitions();
/*    */   
/*    */   UIResultList<ItemSearchResult> findOneOfEachItem(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   UIResultList<Integer> getFreeSlots(ItemGroup paramItemGroup);
/*    */   
/*    */   Optional<Integer> getFreeSlotsInteger(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   Optional<Integer> getFreeSlotsInteger(ItemGroup paramItemGroup);
/*    */   
/*    */   UIResultList<Integer> getFreeSlots(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   UIResultList<ItemSearchResult> findAllOfItem(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   UIResult<Integer> getSlotForItem(ItemGroup paramItemGroup, int paramInt);
/*    */   
/*    */   UIResult<Integer> getItemSlotForPoint(ItemGroup paramItemGroup, Point paramPoint);
/*    */   
/*    */   UIResult<ItemSearchResult> findItem(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   UIResult<ItemSearchResult> findItem(ItemGroup paramItemGroup, boolean paramBoolean, int... paramVarArgs);
/*    */   
/*    */   UIResult<Integer> getSelectedItemSlot(ItemGroup paramItemGroup);
/*    */   
/*    */   UIResult<Rectangle> getBoundsForSlot(int paramInt, ItemGroup paramItemGroup);
/*    */   
/*    */   Optional<Integer> getTakenSlotsInteger(ItemGroup paramItemGroup);
/*    */   
/*    */   UIResultList<Integer> getTakenSlots(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   UIResultList<Integer> getTakenSlots(ItemGroup paramItemGroup);
/*    */   
/*    */   UIResult<ItemSearchResult> searchSlot(ItemGroup paramItemGroup, int paramInt, int... paramVarArgs);
/*    */   
/*    */   Image getItemImage(int paramInt1, int paramInt2, boolean paramBoolean, ZoomType paramZoomType, int paramInt3, int paramInt4, int paramInt5);
/*    */   
/*    */   SearchableItem[] getItems(boolean paramBoolean, int... paramVarArgs);
/*    */   
/*    */   SearchableItem[] getItem(int paramInt, boolean paramBoolean);
/*    */   
/*    */   UIResult<Boolean> isItemInSlot(ItemGroup paramItemGroup, int paramInt);
/*    */   
/*    */   Image getItemImage(int paramInt1, int paramInt2, ZoomType paramZoomType, int paramInt3);
/*    */   
/*    */   Image getItemImage(ItemDefinition paramItemDefinition, ZoomType paramZoomType, int paramInt);
/*    */   
/*    */   boolean dropItems(ItemGroup paramItemGroup, int... paramVarArgs);
/*    */   
/*    */   SearchableItem[] getItem(int paramInt, boolean paramBoolean, ToleranceComparator paramToleranceComparator);
/*    */   
/*    */   SearchableItem[] getItem(int paramInt, boolean paramBoolean, ToleranceComparator paramToleranceComparator, ZoomType paramZoomType);
/*    */   
/*    */   SearchableItem[] getItem(int paramInt1, boolean paramBoolean, ToleranceComparator paramToleranceComparator, ZoomType paramZoomType, int paramInt2);
/*    */   
/*    */   boolean dropItem(ItemGroup paramItemGroup, int paramInt1, int paramInt2);
/*    */   
/*    */   String getItemName(int paramInt);
/*    */   
/*    */   boolean isStackable(int paramInt);
/*    */   
/*    */   String getNameForItemID(int paramInt);
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\item\ItemManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */