/*    */ package com.osmb.api.item;
/*    */ 
/*    */ import com.osmb.api.shape.Rectangle;
/*    */ import java.awt.Point;
/*    */ 
/*    */ 
/*    */ public interface ItemGroup
/*    */ {
/*    */   public static final int TAPPABLE_ITEM_WIDTH = 36;
/*    */   public static final int TAPPABLE_ITEM_HEIGHT = 29;
/*    */   
/*    */   Point getStartPoint();
/*    */   
/*    */   int groupWidth();
/*    */   
/*    */   int groupHeight();
/*    */   
/*    */   int xIncrement();
/*    */   
/*    */   int yIncrement();
/*    */   
/*    */   default int getGroupSize() {
/* 23 */     return groupWidth() * groupHeight();
/*    */   }
/*    */   
/*    */   Rectangle getGroupBounds();
/*    */   
/*    */   default int getItemXGap() {
/* 29 */     return xIncrement() - 36;
/*    */   }
/*    */   
/*    */   default int getItemYGap() {
/* 33 */     return yIncrement() - 29;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\item\ItemGroup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */