/*     */ package com.osmb.api.item;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import com.osmb.api.shape.Rectangle;
/*     */ import com.osmb.api.ui.component.tabs.EquipmentTabComponent;
/*     */ import com.osmb.api.ui.tabs.Tab;
/*     */ import com.osmb.api.utils.RandomUtils;
/*     */ import com.osmb.api.utils.UIResult;
/*     */ import com.osmb.api.utils.Utils;
/*     */ import com.osmb.api.visual.image.ImageSearchResult;
/*     */ import com.osmb.api.visual.ocr.fonts.Font;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemSearchResult
/*     */   extends ImageSearchResult
/*     */ {
/*     */   public static final int M_TEXT_COLOR = -16712065;
/*     */   public static final int K_TEXT_COLOR = -65794;
/*     */   public static final int YELLOW_TEXT_COLOR = -66048;
/*     */   public static final int ITEM_Y_OFFSET = 9;
/*     */   private final ItemGroup itemGroup;
/*     */   
/*     */   public ItemSearchResult(ScriptCore core, int id, ImageSearchResult imageSearchResult, ItemGroup itemGroup, int slot) {
/*  27 */     super(imageSearchResult);
/*  28 */     this.itemGroup = itemGroup;
/*  29 */     this.id = id;
/*  30 */     this.slot = slot;
/*  31 */     this.core = core;
/*  32 */     this.equipmentSlot = null;
/*     */     
/*  34 */     Rectangle amountBounds = new Rectangle(imageSearchResult.getX() - 1, imageSearchResult.getY() - 9, 35, 9);
/*  35 */     String amountResult = core.getOCR().getText(Font.SMALL_FONT, amountBounds, new int[] { -66048, -65794, -16712065 });
/*  36 */     int stackAmount = 1;
/*  37 */     if (amountResult != null && !amountResult.isEmpty()) {
/*  38 */       amountResult.replaceAll("K", "000").replaceAll("M", "000000");
/*  39 */       if (amountResult.matches("[0-9]+") && amountResult.length() <= 9) {
/*  40 */         stackAmount = Integer.parseInt(amountResult);
/*     */       }
/*     */     } 
/*  43 */     this.stackAmount = stackAmount;
/*     */   }
/*     */   private final int id; private final int stackAmount; private final int slot; private final ScriptCore core; private final EquipmentTabComponent.Slot equipmentSlot;
/*     */   public ItemSearchResult(ScriptCore core, int id, ImageSearchResult imageSearchResult, EquipmentTabComponent.Slot equipmentSlot) {
/*  47 */     super(imageSearchResult);
/*  48 */     this.itemGroup = null;
/*  49 */     this.id = id;
/*  50 */     this.slot = -1;
/*  51 */     this.equipmentSlot = equipmentSlot;
/*  52 */     this.core = core;
/*     */     
/*  54 */     Rectangle amountBounds = new Rectangle(imageSearchResult.getX() - 1, imageSearchResult.getY() - 9, 35, 9);
/*  55 */     String amountResult = core.getOCR().getText(Font.SMALL_FONT, amountBounds, new int[] { -66048, -65794, -16712065 });
/*  56 */     int stackAmount = 1;
/*  57 */     if (amountResult != null && !amountResult.isEmpty()) {
/*  58 */       amountResult.replaceAll("K", "000").replaceAll("M", "000000");
/*  59 */       if (amountResult.matches("[0-9]+") && amountResult.length() <= 9) {
/*  60 */         stackAmount = Integer.parseInt(amountResult);
/*     */       }
/*     */     } 
/*  63 */     this.stackAmount = stackAmount;
/*     */   }
/*     */   
/*     */   public int getSlot() {
/*  67 */     return this.slot;
/*     */   }
/*     */   
/*     */   public EquipmentTabComponent.Slot getEquipmentSlot() {
/*  71 */     return this.equipmentSlot;
/*     */   }
/*     */   
/*     */   public int getId() {
/*  75 */     return this.id;
/*     */   }
/*     */   
/*     */   public UIResult<Point> getRandomPointInSlot() {
/*  79 */     UIResult<Rectangle> result = getTappableBounds();
/*  80 */     if (result.isNotVisible()) {
/*  81 */       return UIResult.notVisible();
/*     */     }
/*  83 */     if (result.isNotFound()) return UIResult.of(null);
/*     */     
/*  85 */     return UIResult.of(((Rectangle)result.get()).getRandomPoint());
/*     */   }
/*     */   
/*     */   public UIResult<Rectangle> getTappableBounds() {
/*  89 */     if (this.equipmentSlot != null) {
/*  90 */       Tab activeTab = this.core.getWidgetManager().getTabManager().getActiveTabComponent();
/*  91 */       Rectangle bounds = activeTab.getComponent().getBounds();
/*  92 */       if (bounds == null || activeTab.getType() != Tab.Type.EQUIPMENT) {
/*  93 */         return UIResult.notVisible();
/*     */       }
/*  95 */       return UIResult.of(new Rectangle(this.x, this.y - 9, 36, 31));
/*     */     } 
/*  97 */     return this.core.getItemManager().getBoundsForSlot(this.slot, this.itemGroup);
/*     */   }
/*     */   
/*     */   public ItemGroup getItemGroup() {
/* 101 */     return this.itemGroup;
/*     */   }
/*     */   
/*     */   public int getStackAmount() {
/* 105 */     return this.stackAmount;
/*     */   }
/*     */   
/*     */   public int getItemSlot() {
/* 109 */     return this.slot;
/*     */   }
/*     */   
/*     */   public boolean interact(String... options) {
/* 113 */     if (this.itemGroup != null && handleMissclick()) {
/* 114 */       return false;
/*     */     }
/* 116 */     return this.core.getFinger().tap(this, options);
/*     */   }
/*     */   
/*     */   public boolean interact() {
/* 120 */     if (this.itemGroup != null && handleMissclick()) {
/* 121 */       return false;
/*     */     }
/* 123 */     this.core.getFinger().tap(this);
/* 124 */     return this.core.submitTask(() -> true, 5000);
/*     */   }
/*     */   
/*     */   private boolean handleMissclick() {
/* 128 */     boolean shouldmissclick = RandomUtils.generateRandomProbability(0.03D, 0.1D);
/* 129 */     if (shouldmissclick) {
/* 130 */       this.core.log(getClass().getSimpleName(), "Oops, we missclicked!");
/* 131 */       Rectangle bounds = this.itemGroup.getGroupBounds();
/* 132 */       if (bounds == null) {
/* 133 */         this.core.log(getClass().getSimpleName(), "Can't interact, bounds for item group is null.");
/* 134 */         return false;
/*     */       } 
/* 136 */       UIResult<Rectangle> tappableBounds = getTappableBounds();
/* 137 */       if (tappableBounds.isNotVisible()) {
/* 138 */         return false;
/*     */       }
/* 140 */       Rectangle missclickBounds = ((Rectangle)tappableBounds.get()).getPadding(-this.itemGroup.getItemYGap() + 1, -this.itemGroup.getItemXGap() + 1, this.itemGroup.getItemYGap() - 1, this.itemGroup.getItemXGap() - 1);
/* 141 */       this.core.getScreen().getDrawableCanvas().drawRect(missclickBounds, Color.RED.getRGB());
/* 142 */       Point missclickPoint = Utils.getRandomPointOutside((Rectangle)tappableBounds.get(), missclickBounds, 200);
/* 143 */       this.core.getFinger().tap(missclickPoint);
/* 144 */       this.core.sleep(RandomUtils.weightedRandom(200, 1000, 0.005D));
/* 145 */       return true;
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\item\ItemSearchResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */