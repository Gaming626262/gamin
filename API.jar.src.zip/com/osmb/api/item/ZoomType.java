/*    */ package com.osmb.api.item;
/*    */ 
/*    */ public enum ZoomType {
/*  4 */   SIZE_1(36, 32, 16, 16),
/*  5 */   SIZE_2(41, 41, 22, 22),
/*  6 */   SIZE_3(48, 48, 25, 25),
/*  7 */   SIZE_4(57, 57, 31, 31),
/*  8 */   SIZE_5(62, 62, 34, 34),
/*  9 */   SIZE_6(65, 65, 36, 36);
/*    */   
/*    */   private final int rasterW;
/*    */   private final int rasterY;
/*    */   private final int offsetX;
/*    */   private final int offsetY;
/*    */   
/*    */   ZoomType(int rasterW, int rasterY, int offsetX, int offsetY) {
/* 17 */     this.rasterY = rasterY;
/* 18 */     this.rasterW = rasterW;
/* 19 */     this.offsetX = offsetX;
/* 20 */     this.offsetY = offsetY;
/*    */   }
/*    */   
/*    */   public int rasterH() {
/* 24 */     return this.rasterY;
/*    */   }
/*    */   
/*    */   public int rasterW() {
/* 28 */     return this.rasterW;
/*    */   }
/*    */   
/*    */   public int offsetX() {
/* 32 */     return this.offsetX;
/*    */   }
/*    */   
/*    */   public int offsetY() {
/* 36 */     return this.offsetY;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\item\ZoomType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */