package com.osmb.api.item;

public final class ItemID {
  public static final int DWARF_REMAINS = 0;
  
  public static final int TOOLKIT = 1;
  
  public static final int CANNONBALL = 2;
  
  public static final int NULODIONS_NOTES = 3;
  
  public static final int AMMO_MOULD = 4;
  
  public static final int INSTRUCTION_MANUAL = 5;
  
  public static final int CANNON_BASE = 6;
  
  public static final int CANNON_STAND = 8;
  
  public static final int CANNON_BARRELS = 10;
  
  public static final int CANNON_FURNACE = 12;
  
  public static final int RAILING = 14;
  
  public static final int HOLY_TABLE_NAPKIN = 15;
  
  public static final int MAGIC_WHISTLE = 16;
  
  public static final int GRAIL_BELL = 17;
  
  public static final int MAGIC_GOLD_FEATHER = 18;
  
  public static final int HOLY_GRAIL = 19;
  
  public static final int WHITE_COG = 20;
  
  public static final int BLACK_COG = 21;
  
  public static final int BLUE_COG = 22;
  
  public static final int RED_COG = 23;
  
  public static final int RAT_POISON = 24;
  
  public static final int RED_VINE_WORM = 25;
  
  public static final int FISHING_TROPHY = 26;
  
  public static final int FISHING_PASS = 27;
  
  public static final int INSECT_REPELLENT = 28;
  
  public static final int BUCKET_OF_WAX = 30;
  
  public static final int LIT_BLACK_CANDLE = 32;
  
  public static final int LIT_CANDLE = 33;
  
  public static final int EXCALIBUR = 35;
  
  public static final int CANDLE = 36;
  
  public static final int BLACK_CANDLE = 38;
  
  public static final int BRONZE_ARROWTIPS = 39;
  
  public static final int IRON_ARROWTIPS = 40;
  
  public static final int STEEL_ARROWTIPS = 41;
  
  public static final int MITHRIL_ARROWTIPS = 42;
  
  public static final int ADAMANT_ARROWTIPS = 43;
  
  public static final int RUNE_ARROWTIPS = 44;
  
  public static final int OPAL_BOLT_TIPS = 45;
  
  public static final int PEARL_BOLT_TIPS = 46;
  
  public static final int BARB_BOLTTIPS = 47;
  
  public static final int LONGBOW_U = 48;
  
  public static final int SHORTBOW_U = 50;
  
  public static final int ARROW_SHAFT = 52;
  
  public static final int HEADLESS_ARROW = 53;
  
  public static final int OAK_SHORTBOW_U = 54;
  
  public static final int OAK_LONGBOW_U = 56;
  
  public static final int WILLOW_LONGBOW_U = 58;
  
  public static final int WILLOW_SHORTBOW_U = 60;
  
  public static final int MAPLE_LONGBOW_U = 62;
  
  public static final int MAPLE_SHORTBOW_U = 64;
  
  public static final int YEW_LONGBOW_U = 66;
  
  public static final int YEW_SHORTBOW_U = 68;
  
  public static final int MAGIC_LONGBOW_U = 70;
  
  public static final int MAGIC_SHORTBOW_U = 72;
  
  public static final int KHAZARD_HELMET = 74;
  
  public static final int KHAZARD_ARMOUR = 75;
  
  public static final int KHAZARD_CELL_KEYS = 76;
  
  public static final int KHALI_BREW = 77;
  
  public static final int ICE_ARROWS = 78;
  
  public static final int LEVER = 83;
  
  public static final int STAFF_OF_ARMADYL = 84;
  
  public static final int SHINY_KEY = 85;
  
  public static final int PENDANT_OF_LUCIEN = 86;
  
  public static final int ARMADYL_PENDANT = 87;
  
  public static final int BOOTS_OF_LIGHTNESS = 88;
  
  public static final int BOOTS_OF_LIGHTNESS_89 = 89;
  
  public static final int CHILDS_BLANKET = 90;
  
  public static final int GUAM_POTION_UNF = 91;
  
  public static final int MARRENTILL_POTION_UNF = 93;
  
  public static final int TARROMIN_POTION_UNF = 95;
  
  public static final int HARRALANDER_POTION_UNF = 97;
  
  public static final int RANARR_POTION_UNF = 99;
  
  public static final int IRIT_POTION_UNF = 101;
  
  public static final int AVANTOE_POTION_UNF = 103;
  
  public static final int KWUARM_POTION_UNF = 105;
  
  public static final int CADANTINE_POTION_UNF = 107;
  
  public static final int DWARF_WEED_POTION_UNF = 109;
  
  public static final int TORSTOL_POTION_UNF = 111;
  
  public static final int STRENGTH_POTION4 = 113;
  
  public static final int STRENGTH_POTION3 = 115;
  
  public static final int STRENGTH_POTION2 = 117;
  
  public static final int STRENGTH_POTION1 = 119;
  
  public static final int ATTACK_POTION3 = 121;
  
  public static final int ATTACK_POTION2 = 123;
  
  public static final int ATTACK_POTION1 = 125;
  
  public static final int RESTORE_POTION3 = 127;
  
  public static final int RESTORE_POTION2 = 129;
  
  public static final int RESTORE_POTION1 = 131;
  
  public static final int DEFENCE_POTION3 = 133;
  
  public static final int DEFENCE_POTION2 = 135;
  
  public static final int DEFENCE_POTION1 = 137;
  
  public static final int PRAYER_POTION3 = 139;
  
  public static final int PRAYER_POTION2 = 141;
  
  public static final int PRAYER_POTION1 = 143;
  
  public static final int SUPER_ATTACK3 = 145;
  
  public static final int SUPER_ATTACK2 = 147;
  
  public static final int SUPER_ATTACK1 = 149;
  
  public static final int FISHING_POTION3 = 151;
  
  public static final int FISHING_POTION2 = 153;
  
  public static final int FISHING_POTION1 = 155;
  
  public static final int SUPER_STRENGTH3 = 157;
  
  public static final int SUPER_STRENGTH2 = 159;
  
  public static final int SUPER_STRENGTH1 = 161;
  
  public static final int SUPER_DEFENCE3 = 163;
  
  public static final int SUPER_DEFENCE2 = 165;
  
  public static final int SUPER_DEFENCE1 = 167;
  
  public static final int RANGING_POTION3 = 169;
  
  public static final int RANGING_POTION2 = 171;
  
  public static final int RANGING_POTION1 = 173;
  
  public static final int ANTIPOISON3 = 175;
  
  public static final int ANTIPOISON2 = 177;
  
  public static final int ANTIPOISON1 = 179;
  
  public static final int SUPERANTIPOISON3 = 181;
  
  public static final int SUPERANTIPOISON2 = 183;
  
  public static final int SUPERANTIPOISON1 = 185;
  
  public static final int WEAPON_POISON = 187;
  
  public static final int ZAMORAK_BREW3 = 189;
  
  public static final int ZAMORAK_BREW2 = 191;
  
  public static final int ZAMORAK_BREW1 = 193;
  
  public static final int POTION = 195;
  
  public static final int POISON_CHALICE = 197;
  
  public static final int GRIMY_GUAM_LEAF = 199;
  
  public static final int GRIMY_MARRENTILL = 201;
  
  public static final int GRIMY_TARROMIN = 203;
  
  public static final int GRIMY_HARRALANDER = 205;
  
  public static final int GRIMY_RANARR_WEED = 207;
  
  public static final int GRIMY_IRIT_LEAF = 209;
  
  public static final int GRIMY_AVANTOE = 211;
  
  public static final int GRIMY_KWUARM = 213;
  
  public static final int GRIMY_CADANTINE = 215;
  
  public static final int GRIMY_DWARF_WEED = 217;
  
  public static final int GRIMY_TORSTOL = 219;
  
  public static final int EYE_OF_NEWT = 221;
  
  public static final int RED_SPIDERS_EGGS = 223;
  
  public static final int LIMPWURT_ROOT = 225;
  
  public static final int VIAL_OF_WATER = 227;
  
  public static final int VIAL = 229;
  
  public static final int SNAPE_GRASS = 231;
  
  public static final int PESTLE_AND_MORTAR = 233;
  
  public static final int UNICORN_HORN_DUST = 235;
  
  public static final int UNICORN_HORN = 237;
  
  public static final int WHITE_BERRIES = 239;
  
  public static final int DRAGON_SCALE_DUST = 241;
  
  public static final int BLUE_DRAGON_SCALE = 243;
  
  public static final int WINE_OF_ZAMORAK = 245;
  
  public static final int JANGERBERRIES = 247;
  
  public static final int GUAM_LEAF = 249;
  
  public static final int MARRENTILL = 251;
  
  public static final int TARROMIN = 253;
  
  public static final int HARRALANDER = 255;
  
  public static final int RANARR_WEED = 257;
  
  public static final int IRIT_LEAF = 259;
  
  public static final int AVANTOE = 261;
  
  public static final int KWUARM = 263;
  
  public static final int CADANTINE = 265;
  
  public static final int DWARF_WEED = 267;
  
  public static final int TORSTOL = 269;
  
  public static final int PRESSURE_GAUGE = 271;
  
  public static final int FISH_FOOD = 272;
  
  public static final int POISON = 273;
  
  public static final int POISONED_FISH_FOOD = 274;
  
  public static final int KEY = 275;
  
  public static final int RUBBER_TUBE = 276;
  
  public static final int OIL_CAN = 277;
  
  public static final int CATTLEPROD = 278;
  
  public static final int SHEEP_FEED = 279;
  
  public static final int SHEEP_BONES_1 = 280;
  
  public static final int SHEEP_BONES_2 = 281;
  
  public static final int SHEEP_BONES_3 = 282;
  
  public static final int SHEEP_BONES_4 = 283;
  
  public static final int PLAGUE_JACKET = 284;
  
  public static final int PLAGUE_TROUSERS = 285;
  
  public static final int ORANGE_GOBLIN_MAIL = 286;
  
  public static final int BLUE_GOBLIN_MAIL = 287;
  
  public static final int GOBLIN_MAIL = 288;
  
  public static final int RESEARCH_PACKAGE = 290;
  
  public static final int RESEARCH_NOTES = 291;
  
  public static final int BOOK_ON_BAXTORIAN = 292;
  
  public static final int KEY_293 = 293;
  
  public static final int GLARIALS_PEBBLE = 294;
  
  public static final int GLARIALS_AMULET = 295;
  
  public static final int GLARIALS_URN = 296;
  
  public static final int GLARIALS_URN_EMPTY = 297;
  
  public static final int KEY_298 = 298;
  
  public static final int MITHRIL_SEEDS = 299;
  
  public static final int RATS_TAIL = 300;
  
  public static final int LOBSTER_POT = 301;
  
  public static final int SMALL_FISHING_NET = 303;
  
  public static final int BIG_FISHING_NET = 305;
  
  public static final int FISHING_ROD = 307;
  
  public static final int FLY_FISHING_ROD = 309;
  
  public static final int HARPOON = 311;
  
  public static final int FISHING_BAIT = 313;
  
  public static final int FEATHER = 314;
  
  public static final int SHRIMPS = 315;
  
  public static final int RAW_SHRIMPS = 317;
  
  public static final int ANCHOVIES = 319;
  
  public static final int RAW_ANCHOVIES = 321;
  
  public static final int BURNT_FISH = 323;
  
  public static final int SARDINE = 325;
  
  public static final int RAW_SARDINE = 327;
  
  public static final int SALMON = 329;
  
  public static final int RAW_SALMON = 331;
  
  public static final int TROUT = 333;
  
  public static final int RAW_TROUT = 335;
  
  public static final int GIANT_CARP = 337;
  
  public static final int RAW_GIANT_CARP = 338;
  
  public static final int COD = 339;
  
  public static final int RAW_COD = 341;
  
  public static final int BURNT_FISH_343 = 343;
  
  public static final int RAW_HERRING = 345;
  
  public static final int HERRING = 347;
  
  public static final int RAW_PIKE = 349;
  
  public static final int PIKE = 351;
  
  public static final int RAW_MACKEREL = 353;
  
  public static final int MACKEREL = 355;
  
  public static final int BURNT_FISH_357 = 357;
  
  public static final int RAW_TUNA = 359;
  
  public static final int TUNA = 361;
  
  public static final int RAW_BASS = 363;
  
  public static final int BASS = 365;
  
  public static final int BURNT_FISH_367 = 367;
  
  public static final int BURNT_FISH_369 = 369;
  
  public static final int RAW_SWORDFISH = 371;
  
  public static final int SWORDFISH = 373;
  
  public static final int BURNT_SWORDFISH = 375;
  
  public static final int RAW_LOBSTER = 377;
  
  public static final int LOBSTER = 379;
  
  public static final int BURNT_LOBSTER = 381;
  
  public static final int RAW_SHARK = 383;
  
  public static final int SHARK = 385;
  
  public static final int BURNT_SHARK = 387;
  
  public static final int RAW_MANTA_RAY = 389;
  
  public static final int MANTA_RAY = 391;
  
  public static final int BURNT_MANTA_RAY = 393;
  
  public static final int RAW_SEA_TURTLE = 395;
  
  public static final int SEA_TURTLE = 397;
  
  public static final int BURNT_SEA_TURTLE = 399;
  
  public static final int SEAWEED = 401;
  
  public static final int EDIBLE_SEAWEED = 403;
  
  public static final int CASKET = 405;
  
  public static final int OYSTER = 407;
  
  public static final int EMPTY_OYSTER = 409;
  
  public static final int OYSTER_PEARL = 411;
  
  public static final int OYSTER_PEARLS = 413;
  
  public static final int ETHENEA = 415;
  
  public static final int LIQUID_HONEY = 416;
  
  public static final int SULPHURIC_BROLINE = 417;
  
  public static final int PLAGUE_SAMPLE = 418;
  
  public static final int TOUCH_PAPER = 419;
  
  public static final int DISTILLATOR = 420;
  
  public static final int LATHAS_AMULET = 421;
  
  public static final int BIRD_FEED = 422;
  
  public static final int KEY_423 = 423;
  
  public static final int PIGEON_CAGE = 424;
  
  public static final int PIGEON_CAGE_425 = 425;
  
  public static final int PRIEST_GOWN = 426;
  
  public static final int PRIEST_GOWN_428 = 428;
  
  public static final int MEDICAL_GOWN = 430;
  
  public static final int KARAMJAN_RUM = 431;
  
  public static final int CHEST_KEY = 432;
  
  public static final int PIRATE_MESSAGE = 433;
  
  public static final int CLAY = 434;
  
  public static final int COPPER_ORE = 436;
  
  public static final int TIN_ORE = 438;
  
  public static final int IRON_ORE = 440;
  
  public static final int SILVER_ORE = 442;
  
  public static final int GOLD_ORE = 444;
  
  public static final int PERFECT_GOLD_ORE = 446;
  
  public static final int MITHRIL_ORE = 447;
  
  public static final int ADAMANTITE_ORE = 449;
  
  public static final int RUNITE_ORE = 451;
  
  public static final int COAL = 453;
  
  public static final int BARCRAWL_CARD = 455;
  
  public static final int SCORPION_CAGE = 456;
  
  public static final int SCORPION_CAGE_457 = 457;
  
  public static final int SCORPION_CAGE_458 = 458;
  
  public static final int SCORPION_CAGE_459 = 459;
  
  public static final int SCORPION_CAGE_460 = 460;
  
  public static final int SCORPION_CAGE_461 = 461;
  
  public static final int SCORPION_CAGE_462 = 462;
  
  public static final int SCORPION_CAGE_463 = 463;
  
  public static final int STRANGE_FRUIT = 464;
  
  public static final int PICKAXE_HANDLE = 466;
  
  public static final int BROKEN_PICKAXE = 468;
  
  public static final int BROKEN_PICKAXE_470 = 470;
  
  public static final int BROKEN_PICKAXE_472 = 472;
  
  public static final int BROKEN_PICKAXE_474 = 474;
  
  public static final int BROKEN_PICKAXE_476 = 476;
  
  public static final int BROKEN_PICKAXE_478 = 478;
  
  public static final int BRONZE_PICK_HEAD = 480;
  
  public static final int IRON_PICK_HEAD = 482;
  
  public static final int STEEL_PICK_HEAD = 484;
  
  public static final int MITHRIL_PICK_HEAD = 486;
  
  public static final int ADAMANT_PICK_HEAD = 488;
  
  public static final int RUNE_PICK_HEAD = 490;
  
  public static final int AXE_HANDLE = 492;
  
  public static final int BROKEN_AXE = 494;
  
  public static final int BROKEN_AXE_496 = 496;
  
  public static final int BROKEN_AXE_498 = 498;
  
  public static final int BROKEN_AXE_500 = 500;
  
  public static final int BROKEN_AXE_502 = 502;
  
  public static final int BROKEN_AXE_504 = 504;
  
  public static final int BROKEN_AXE_506 = 506;
  
  public static final int BRONZE_AXE_HEAD = 508;
  
  public static final int IRON_AXE_HEAD = 510;
  
  public static final int STEEL_AXE_HEAD = 512;
  
  public static final int BLACK_AXE_HEAD = 514;
  
  public static final int MITHRIL_AXE_HEAD = 516;
  
  public static final int ADAMANT_AXE_HEAD = 518;
  
  public static final int RUNE_AXE_HEAD = 520;
  
  public static final int ENCHANTED_BEEF = 522;
  
  public static final int ENCHANTED_RAT = 523;
  
  public static final int ENCHANTED_BEAR = 524;
  
  public static final int ENCHANTED_CHICKEN = 525;
  
  public static final int BONES = 526;
  
  public static final int BURNT_BONES = 528;
  
  public static final int BAT_BONES = 530;
  
  public static final int BIG_BONES = 532;
  
  public static final int BABYDRAGON_BONES = 534;
  
  public static final int DRAGON_BONES = 536;
  
  public static final int DRUIDS_ROBE = 538;
  
  public static final int DRUIDS_ROBE_TOP = 540;
  
  public static final int MONKS_ROBE = 542;
  
  public static final int MONKS_ROBE_TOP = 544;
  
  public static final int SHADE_ROBE_TOP = 546;
  
  public static final int SHADE_ROBE = 548;
  
  public static final int NEWCOMER_MAP = 550;
  
  public static final int GHOSTSPEAK_AMULET = 552;
  
  public static final int GHOSTS_SKULL = 553;
  
  public static final int FIRE_RUNE = 554;
  
  public static final int WATER_RUNE = 555;
  
  public static final int AIR_RUNE = 556;
  
  public static final int EARTH_RUNE = 557;
  
  public static final int MIND_RUNE = 558;
  
  public static final int BODY_RUNE = 559;
  
  public static final int DEATH_RUNE = 560;
  
  public static final int NATURE_RUNE = 561;
  
  public static final int CHAOS_RUNE = 562;
  
  public static final int LAW_RUNE = 563;
  
  public static final int COSMIC_RUNE = 564;
  
  public static final int BLOOD_RUNE = 565;
  
  public static final int SOUL_RUNE = 566;
  
  public static final int UNPOWERED_ORB = 567;
  
  public static final int FIRE_ORB = 569;
  
  public static final int WATER_ORB = 571;
  
  public static final int AIR_ORB = 573;
  
  public static final int EARTH_ORB = 575;
  
  public static final int BLUE_WIZARD_ROBE = 577;
  
  public static final int BLUE_WIZARD_HAT = 579;
  
  public static final int BLACK_ROBE = 581;
  
  public static final int BAILING_BUCKET = 583;
  
  public static final int BAILING_BUCKET_585 = 585;
  
  public static final int ORB_OF_PROTECTION = 587;
  
  public static final int ORBS_OF_PROTECTION = 588;
  
  public static final int GNOME_AMULET = 589;
  
  public static final int TINDERBOX = 590;
  
  public static final int ASHES = 592;
  
  public static final int LIT_TORCH = 594;
  
  public static final int TORCH = 595;
  
  public static final int UNLIT_TORCH = 596;
  
  public static final int BRONZE_FIRE_ARROW = 598;
  
  public static final int ASTRONOMY_BOOK = 600;
  
  public static final int GOBLIN_KITCHEN_KEY = 601;
  
  public static final int LENS_MOULD = 602;
  
  public static final int OBSERVATORY_LENS = 603;
  
  public static final int BONE_SHARD = 604;
  
  public static final int BONE_KEY = 605;
  
  public static final int STONEPLAQUE = 606;
  
  public static final int TATTERED_SCROLL = 607;
  
  public static final int CRUMPLED_SCROLL = 608;
  
  public static final int RASHILIYIA_CORPSE = 609;
  
  public static final int ZADIMUS_CORPSE = 610;
  
  public static final int LOCATING_CRYSTAL = 611;
  
  public static final int LOCATING_CRYSTAL_612 = 612;
  
  public static final int LOCATING_CRYSTAL_613 = 613;
  
  public static final int LOCATING_CRYSTAL_614 = 614;
  
  public static final int LOCATING_CRYSTAL_615 = 615;
  
  public static final int BEADS_OF_THE_DEAD = 616;
  
  public static final int COINS = 617;
  
  public static final int BONE_BEADS = 618;
  
  public static final int PARAMAYA_TICKET = 619;
  
  public static final int PARAMAYA_TICKET_620 = 620;
  
  public static final int SHIP_TICKET = 621;
  
  public static final int SWORD_POMMEL = 623;
  
  public static final int BERVIRIUS_NOTES = 624;
  
  public static final int WAMPUM_BELT = 625;
  
  public static final int PINK_BOOTS = 626;
  
  public static final int GREEN_BOOTS = 628;
  
  public static final int BLUE_BOOTS = 630;
  
  public static final int CREAM_BOOTS = 632;
  
  public static final int TURQUOISE_BOOTS = 634;
  
  public static final int PINK_ROBE_TOP = 636;
  
  public static final int GREEN_ROBE_TOP = 638;
  
  public static final int BLUE_ROBE_TOP = 640;
  
  public static final int CREAM_ROBE_TOP = 642;
  
  public static final int TURQUOISE_ROBE_TOP = 644;
  
  public static final int PINK_ROBE_BOTTOMS = 646;
  
  public static final int GREEN_ROBE_BOTTOMS = 648;
  
  public static final int BLUE_ROBE_BOTTOMS = 650;
  
  public static final int CREAM_ROBE_BOTTOMS = 652;
  
  public static final int TURQUOISE_ROBE_BOTTOMS = 654;
  
  public static final int PINK_HAT = 656;
  
  public static final int GREEN_HAT = 658;
  
  public static final int BLUE_HAT = 660;
  
  public static final int CREAM_HAT = 662;
  
  public static final int TURQUOISE_HAT = 664;
  
  public static final int PORTRAIT = 666;
  
  public static final int BLURITE_SWORD = 667;
  
  public static final int BLURITE_ORE = 668;
  
  public static final int SPECIMEN_JAR = 669;
  
  public static final int SPECIMEN_BRUSH = 670;
  
  public static final int ANIMAL_SKULL = 671;
  
  public static final int SPECIAL_CUP = 672;
  
  public static final int TEDDY = 673;
  
  public static final int CRACKED_SAMPLE = 674;
  
  public static final int ROCK_PICK = 675;
  
  public static final int TROWEL = 676;
  
  public static final int PANNING_TRAY = 677;
  
  public static final int PANNING_TRAY_678 = 678;
  
  public static final int PANNING_TRAY_679 = 679;
  
  public static final int NUGGETS = 680;
  
  public static final int ANCIENT_TALISMAN = 681;
  
  public static final int UNSTAMPED_LETTER = 682;
  
  public static final int SEALED_LETTER = 683;
  
  public static final int BELT_BUCKLE = 684;
  
  public static final int OLD_BOOT = 685;
  
  public static final int RUSTY_SWORD = 686;
  
  public static final int BROKEN_ARROW = 687;
  
  public static final int BUTTONS = 688;
  
  public static final int BROKEN_STAFF = 689;
  
  public static final int BROKEN_GLASS = 690;
  
  public static final int LEVEL_1_CERTIFICATE = 691;
  
  public static final int LEVEL_2_CERTIFICATE = 692;
  
  public static final int LEVEL_3_CERTIFICATE = 693;
  
  public static final int CERAMIC_REMAINS = 694;
  
  public static final int OLD_TOOTH = 695;
  
  public static final int INVITATION_LETTER = 696;
  
  public static final int DAMAGED_ARMOUR = 697;
  
  public static final int BROKEN_ARMOUR = 698;
  
  public static final int STONE_TABLET = 699;
  
  public static final int CHEMICAL_POWDER = 700;
  
  public static final int AMMONIUM_NITRATE = 701;
  
  public static final int UNIDENTIFIED_LIQUID = 702;
  
  public static final int NITROGLYCERIN = 703;
  
  public static final int GROUND_CHARCOAL = 704;
  
  public static final int MIXED_CHEMICALS = 705;
  
  public static final int MIXED_CHEMICALS_706 = 706;
  
  public static final int CHEMICAL_COMPOUND = 707;
  
  public static final int ARCENIA_ROOT = 708;
  
  public static final int CHEST_KEY_709 = 709;
  
  public static final int VASE = 710;
  
  public static final int BOOK_ON_CHEMICALS = 711;
  
  public static final int CUP_OF_TEA = 712;
  
  public static final int CLUE_SCROLL = 713;
  
  public static final int RADIMUS_NOTES = 714;
  
  public static final int RADIMUS_NOTES_715 = 715;
  
  public static final int BULLROARER = 716;
  
  public static final int SCRAWLED_NOTE = 717;
  
  public static final int A_SCRIBBLED_NOTE = 718;
  
  public static final int SCRUMPLED_NOTE = 719;
  
  public static final int SKETCH = 720;
  
  public static final int GOLD_BOWL = 721;
  
  public static final int BLESSED_GOLD_BOWL = 722;
  
  public static final int GOLDEN_BOWL = 723;
  
  public static final int GOLDEN_BOWL_724 = 724;
  
  public static final int GOLDEN_BOWL_725 = 725;
  
  public static final int GOLDEN_BOWL_726 = 726;
  
  public static final int HOLLOW_REED = 727;
  
  public static final int HOLLOW_REED_728 = 728;
  
  public static final int SHAMANS_TOME = 729;
  
  public static final int BINDING_BOOK = 730;
  
  public static final int ENCHANTED_VIAL = 731;
  
  public static final int HOLY_WATER = 732;
  
  public static final int SMASHED_GLASS = 733;
  
  public static final int YOMMI_TREE_SEEDS = 735;
  
  public static final int YOMMI_TREE_SEEDS_736 = 736;
  
  public static final int SNAKEWEED_MIXTURE = 737;
  
  public static final int ARDRIGAL_MIXTURE = 738;
  
  public static final int BRAVERY_POTION = 739;
  
  public static final int BLUE_HAT_740 = 740;
  
  public static final int CHUNK_OF_CRYSTAL = 741;
  
  public static final int HUNK_OF_CRYSTAL = 742;
  
  public static final int LUMP_OF_CRYSTAL = 743;
  
  public static final int HEART_CRYSTAL = 744;
  
  public static final int HEART_CRYSTAL_745 = 745;
  
  public static final int DARK_DAGGER = 746;
  
  public static final int GLOWING_DAGGER = 747;
  
  public static final int HOLY_FORCE = 748;
  
  public static final int YOMMI_TOTEM = 749;
  
  public static final int GILDED_TOTEM = 750;
  
  public static final int GNOMEBALL = 751;
  
  public static final int CADAVA_BERRIES = 753;
  
  public static final int MESSAGE = 755;
  
  public static final int CADAVA_POTION = 756;
  
  public static final int BOOK = 757;
  
  public static final int PHOENIX_HQ_KEY = 758;
  
  public static final int WEAPON_STORE_KEY = 759;
  
  public static final int INTEL_REPORT = 761;
  
  public static final int FALADOR_SHIELD = 762;
  
  public static final int BROKEN_SHIELD = 763;
  
  public static final int COAL_BAG = 764;
  
  public static final int BROKEN_SHIELD_765 = 765;
  
  public static final int GEM_BAG = 766;
  
  public static final int PHOENIX_CROSSBOW = 767;
  
  public static final int CERTIFICATE = 769;
  
  public static final int ARDOUGNE_CLOAK = 770;
  
  public static final int DRAMEN_BRANCH = 771;
  
  public static final int DRAMEN_STAFF = 772;
  
  public static final int PERFECT_RING = 773;
  
  public static final int PERFECT_NECKLACE = 774;
  
  public static final int COOKING_GAUNTLETS = 775;
  
  public static final int GOLDSMITH_GAUNTLETS = 776;
  
  public static final int CHAOS_GAUNTLETS = 777;
  
  public static final int STEEL_GAUNTLETS = 778;
  
  public static final int CREST_PART = 779;
  
  public static final int CREST_PART_780 = 780;
  
  public static final int CREST_PART_781 = 781;
  
  public static final int FAMILY_CREST = 782;
  
  public static final int BARK_SAMPLE = 783;
  
  public static final int TRANSLATION_BOOK = 784;
  
  public static final int GLOUGHS_JOURNAL = 785;
  
  public static final int HAZELMERES_SCROLL = 786;
  
  public static final int LUMBER_ORDER = 787;
  
  public static final int GLOUGHS_KEY = 788;
  
  public static final int TWIGS = 789;
  
  public static final int TWIGS_790 = 790;
  
  public static final int TWIGS_791 = 791;
  
  public static final int TWIGS_792 = 792;
  
  public static final int DACONIA_ROCK = 793;
  
  public static final int INVASION_PLANS = 794;
  
  public static final int WAR_SHIP = 795;
  
  public static final int BRONZE_THROWNAXE = 800;
  
  public static final int IRON_THROWNAXE = 801;
  
  public static final int STEEL_THROWNAXE = 802;
  
  public static final int MITHRIL_THROWNAXE = 803;
  
  public static final int ADAMANT_THROWNAXE = 804;
  
  public static final int RUNE_THROWNAXE = 805;
  
  public static final int BRONZE_DART = 806;
  
  public static final int IRON_DART = 807;
  
  public static final int STEEL_DART = 808;
  
  public static final int MITHRIL_DART = 809;
  
  public static final int ADAMANT_DART = 810;
  
  public static final int RUNE_DART = 811;
  
  public static final int BRONZE_DARTP = 812;
  
  public static final int IRON_DART_P = 813;
  
  public static final int STEEL_DARTP = 814;
  
  public static final int MITHRIL_DARTP = 815;
  
  public static final int ADAMANT_DARTP = 816;
  
  public static final int RUNE_DARTP = 817;
  
  public static final int POISONED_DARTP = 818;
  
  public static final int BRONZE_DART_TIP = 819;
  
  public static final int IRON_DART_TIP = 820;
  
  public static final int STEEL_DART_TIP = 821;
  
  public static final int MITHRIL_DART_TIP = 822;
  
  public static final int ADAMANT_DART_TIP = 823;
  
  public static final int RUNE_DART_TIP = 824;
  
  public static final int BRONZE_JAVELIN = 825;
  
  public static final int IRON_JAVELIN = 826;
  
  public static final int STEEL_JAVELIN = 827;
  
  public static final int MITHRIL_JAVELIN = 828;
  
  public static final int ADAMANT_JAVELIN = 829;
  
  public static final int RUNE_JAVELIN = 830;
  
  public static final int BRONZE_JAVELINP = 831;
  
  public static final int IRON_JAVELINP = 832;
  
  public static final int STEEL_JAVELINP = 833;
  
  public static final int MITHRIL_JAVELINP = 834;
  
  public static final int ADAMANT_JAVELINP = 835;
  
  public static final int RUNE_JAVELINP = 836;
  
  public static final int CROSSBOW = 837;
  
  public static final int LONGBOW = 839;
  
  public static final int SHORTBOW = 841;
  
  public static final int OAK_SHORTBOW = 843;
  
  public static final int OAK_LONGBOW = 845;
  
  public static final int WILLOW_LONGBOW = 847;
  
  public static final int WILLOW_SHORTBOW = 849;
  
  public static final int MAPLE_LONGBOW = 851;
  
  public static final int MAPLE_SHORTBOW = 853;
  
  public static final int YEW_LONGBOW = 855;
  
  public static final int YEW_SHORTBOW = 857;
  
  public static final int MAGIC_LONGBOW = 859;
  
  public static final int MAGIC_SHORTBOW = 861;
  
  public static final int IRON_KNIFE = 863;
  
  public static final int BRONZE_KNIFE = 864;
  
  public static final int STEEL_KNIFE = 865;
  
  public static final int MITHRIL_KNIFE = 866;
  
  public static final int ADAMANT_KNIFE = 867;
  
  public static final int RUNE_KNIFE = 868;
  
  public static final int BLACK_KNIFE = 869;
  
  public static final int BRONZE_KNIFEP = 870;
  
  public static final int IRON_KNIFEP = 871;
  
  public static final int STEEL_KNIFEP = 872;
  
  public static final int MITHRIL_KNIFEP = 873;
  
  public static final int BLACK_KNIFEP = 874;
  
  public static final int ADAMANT_KNIFEP = 875;
  
  public static final int RUNE_KNIFEP = 876;
  
  public static final int BRONZE_BOLTS = 877;
  
  public static final int BRONZE_BOLTS_P = 878;
  
  public static final int OPAL_BOLTS = 879;
  
  public static final int PEARL_BOLTS = 880;
  
  public static final int BARBED_BOLTS = 881;
  
  public static final int BRONZE_ARROW = 882;
  
  public static final int BRONZE_ARROWP = 883;
  
  public static final int IRON_ARROW = 884;
  
  public static final int IRON_ARROWP = 885;
  
  public static final int STEEL_ARROW = 886;
  
  public static final int STEEL_ARROWP = 887;
  
  public static final int MITHRIL_ARROW = 888;
  
  public static final int MITHRIL_ARROWP = 889;
  
  public static final int ADAMANT_ARROW = 890;
  
  public static final int ADAMANT_ARROWP = 891;
  
  public static final int RUNE_ARROW = 892;
  
  public static final int RUNE_ARROWP = 893;
  
  public static final int BRONZE_FIRE_ARROW_LIT = 942;
  
  public static final int WORM = 943;
  
  public static final int THROWING_ROPE = 945;
  
  public static final int KNIFE = 946;
  
  public static final int BEAR_FUR = 948;
  
  public static final int SILK = 950;
  
  public static final int SPADE = 952;
  
  public static final int ROPE = 954;
  
  public static final int FLYER = 956;
  
  public static final int GREY_WOLF_FUR = 958;
  
  public static final int PLANK = 960;
  
  public static final int CHRISTMAS_CRACKER = 962;
  
  public static final int SKULL = 964;
  
  public static final int SKULL_965 = 965;
  
  public static final int TILE = 966;
  
  public static final int ROCK = 968;
  
  public static final int PAPYRUS = 970;
  
  public static final int PAPYRUS_972 = 972;
  
  public static final int CHARCOAL = 973;
  
  public static final int MACHETE = 975;
  
  public static final int COOKING_POT = 977;
  
  public static final int DISK_OF_RETURNING = 981;
  
  public static final int BRASS_KEY = 983;
  
  public static final int TOOTH_HALF_OF_KEY = 985;
  
  public static final int LOOP_HALF_OF_KEY = 987;
  
  public static final int CRYSTAL_KEY = 989;
  
  public static final int MUDDY_KEY = 991;
  
  public static final int SINISTER_KEY = 993;
  
  public static final int COINS_995 = 995;
  
  public static final int WHITE_APRON = 1005;
  
  public static final int RED_CAPE = 1007;
  
  public static final int BRASS_NECKLACE = 1009;
  
  public static final int BLUE_SKIRT = 1011;
  
  public static final int PINK_SKIRT = 1013;
  
  public static final int BLACK_SKIRT = 1015;
  
  public static final int WIZARD_HAT = 1017;
  
  public static final int BLACK_CAPE = 1019;
  
  public static final int BLUE_CAPE = 1021;
  
  public static final int YELLOW_CAPE = 1023;
  
  public static final int RIGHT_EYE_PATCH = 1025;
  
  public static final int GREEN_CAPE = 1027;
  
  public static final int PURPLE_CAPE = 1029;
  
  public static final int ORANGE_CAPE = 1031;
  
  public static final int ZAMORAK_MONK_BOTTOM = 1033;
  
  public static final int ZAMORAK_MONK_TOP = 1035;
  
  public static final int BUNNY_EARS = 1037;
  
  public static final int RED_PARTYHAT = 1038;
  
  public static final int YELLOW_PARTYHAT = 1040;
  
  public static final int BLUE_PARTYHAT = 1042;
  
  public static final int GREEN_PARTYHAT = 1044;
  
  public static final int PURPLE_PARTYHAT = 1046;
  
  public static final int WHITE_PARTYHAT = 1048;
  
  public static final int SANTA_HAT = 1050;
  
  public static final int CAPE_OF_LEGENDS = 1052;
  
  public static final int GREEN_HALLOWEEN_MASK = 1053;
  
  public static final int BLUE_HALLOWEEN_MASK = 1055;
  
  public static final int RED_HALLOWEEN_MASK = 1057;
  
  public static final int LEATHER_GLOVES = 1059;
  
  public static final int LEATHER_BOOTS = 1061;
  
  public static final int LEATHER_VAMBRACES = 1063;
  
  public static final int GREEN_DHIDE_VAMBRACES = 1065;
  
  public static final int IRON_PLATELEGS = 1067;
  
  public static final int STEEL_PLATELEGS = 1069;
  
  public static final int MITHRIL_PLATELEGS = 1071;
  
  public static final int ADAMANT_PLATELEGS = 1073;
  
  public static final int BRONZE_PLATELEGS = 1075;
  
  public static final int BLACK_PLATELEGS = 1077;
  
  public static final int RUNE_PLATELEGS = 1079;
  
  public static final int IRON_PLATESKIRT = 1081;
  
  public static final int STEEL_PLATESKIRT = 1083;
  
  public static final int MITHRIL_PLATESKIRT = 1085;
  
  public static final int BRONZE_PLATESKIRT = 1087;
  
  public static final int BLACK_PLATESKIRT = 1089;
  
  public static final int ADAMANT_PLATESKIRT = 1091;
  
  public static final int RUNE_PLATESKIRT = 1093;
  
  public static final int LEATHER_CHAPS = 1095;
  
  public static final int STUDDED_CHAPS = 1097;
  
  public static final int GREEN_DHIDE_CHAPS = 1099;
  
  public static final int IRON_CHAINBODY = 1101;
  
  public static final int BRONZE_CHAINBODY = 1103;
  
  public static final int STEEL_CHAINBODY = 1105;
  
  public static final int BLACK_CHAINBODY = 1107;
  
  public static final int MITHRIL_CHAINBODY = 1109;
  
  public static final int ADAMANT_CHAINBODY = 1111;
  
  public static final int RUNE_CHAINBODY = 1113;
  
  public static final int IRON_PLATEBODY = 1115;
  
  public static final int BRONZE_PLATEBODY = 1117;
  
  public static final int STEEL_PLATEBODY = 1119;
  
  public static final int MITHRIL_PLATEBODY = 1121;
  
  public static final int ADAMANT_PLATEBODY = 1123;
  
  public static final int BLACK_PLATEBODY = 1125;
  
  public static final int RUNE_PLATEBODY = 1127;
  
  public static final int LEATHER_BODY = 1129;
  
  public static final int HARDLEATHER_BODY = 1131;
  
  public static final int STUDDED_BODY = 1133;
  
  public static final int GREEN_DHIDE_BODY = 1135;
  
  public static final int IRON_MED_HELM = 1137;
  
  public static final int BRONZE_MED_HELM = 1139;
  
  public static final int STEEL_MED_HELM = 1141;
  
  public static final int MITHRIL_MED_HELM = 1143;
  
  public static final int ADAMANT_MED_HELM = 1145;
  
  public static final int RUNE_MED_HELM = 1147;
  
  public static final int DRAGON_MED_HELM = 1149;
  
  public static final int BLACK_MED_HELM = 1151;
  
  public static final int IRON_FULL_HELM = 1153;
  
  public static final int BRONZE_FULL_HELM = 1155;
  
  public static final int STEEL_FULL_HELM = 1157;
  
  public static final int MITHRIL_FULL_HELM = 1159;
  
  public static final int ADAMANT_FULL_HELM = 1161;
  
  public static final int RUNE_FULL_HELM = 1163;
  
  public static final int BLACK_FULL_HELM = 1165;
  
  public static final int LEATHER_COWL = 1167;
  
  public static final int COIF = 1169;
  
  public static final int WOODEN_SHIELD = 1171;
  
  public static final int BRONZE_SQ_SHIELD = 1173;
  
  public static final int IRON_SQ_SHIELD = 1175;
  
  public static final int STEEL_SQ_SHIELD = 1177;
  
  public static final int BLACK_SQ_SHIELD = 1179;
  
  public static final int MITHRIL_SQ_SHIELD = 1181;
  
  public static final int ADAMANT_SQ_SHIELD = 1183;
  
  public static final int RUNE_SQ_SHIELD = 1185;
  
  public static final int DRAGON_SQ_SHIELD = 1187;
  
  public static final int BRONZE_KITESHIELD = 1189;
  
  public static final int IRON_KITESHIELD = 1191;
  
  public static final int STEEL_KITESHIELD = 1193;
  
  public static final int BLACK_KITESHIELD = 1195;
  
  public static final int MITHRIL_KITESHIELD = 1197;
  
  public static final int ADAMANT_KITESHIELD = 1199;
  
  public static final int RUNE_KITESHIELD = 1201;
  
  public static final int IRON_DAGGER = 1203;
  
  public static final int BRONZE_DAGGER = 1205;
  
  public static final int STEEL_DAGGER = 1207;
  
  public static final int MITHRIL_DAGGER = 1209;
  
  public static final int ADAMANT_DAGGER = 1211;
  
  public static final int RUNE_DAGGER = 1213;
  
  public static final int DRAGON_DAGGER = 1215;
  
  public static final int BLACK_DAGGER = 1217;
  
  public static final int IRON_DAGGERP = 1219;
  
  public static final int BRONZE_DAGGERP = 1221;
  
  public static final int STEEL_DAGGERP = 1223;
  
  public static final int MITHRIL_DAGGERP = 1225;
  
  public static final int ADAMANT_DAGGERP = 1227;
  
  public static final int RUNE_DAGGERP = 1229;
  
  public static final int DRAGON_DAGGERP = 1231;
  
  public static final int BLACK_DAGGERP = 1233;
  
  public static final int POISONED_DAGGERP = 1235;
  
  public static final int BRONZE_SPEAR = 1237;
  
  public static final int IRON_SPEAR = 1239;
  
  public static final int STEEL_SPEAR = 1241;
  
  public static final int MITHRIL_SPEAR = 1243;
  
  public static final int ADAMANT_SPEAR = 1245;
  
  public static final int RUNE_SPEAR = 1247;
  
  public static final int DRAGON_SPEAR = 1249;
  
  public static final int BRONZE_SPEARP = 1251;
  
  public static final int IRON_SPEARP = 1253;
  
  public static final int STEEL_SPEARP = 1255;
  
  public static final int MITHRIL_SPEARP = 1257;
  
  public static final int ADAMANT_SPEARP = 1259;
  
  public static final int RUNE_SPEARP = 1261;
  
  public static final int DRAGON_SPEARP = 1263;
  
  public static final int BRONZE_PICKAXE = 1265;
  
  public static final int IRON_PICKAXE = 1267;
  
  public static final int STEEL_PICKAXE = 1269;
  
  public static final int ADAMANT_PICKAXE = 1271;
  
  public static final int MITHRIL_PICKAXE = 1273;
  
  public static final int RUNE_PICKAXE = 1275;
  
  public static final int BRONZE_SWORD = 1277;
  
  public static final int IRON_SWORD = 1279;
  
  public static final int STEEL_SWORD = 1281;
  
  public static final int BLACK_SWORD = 1283;
  
  public static final int MITHRIL_SWORD = 1285;
  
  public static final int ADAMANT_SWORD = 1287;
  
  public static final int RUNE_SWORD = 1289;
  
  public static final int BRONZE_LONGSWORD = 1291;
  
  public static final int IRON_LONGSWORD = 1293;
  
  public static final int STEEL_LONGSWORD = 1295;
  
  public static final int BLACK_LONGSWORD = 1297;
  
  public static final int MITHRIL_LONGSWORD = 1299;
  
  public static final int ADAMANT_LONGSWORD = 1301;
  
  public static final int RUNE_LONGSWORD = 1303;
  
  public static final int DRAGON_LONGSWORD = 1305;
  
  public static final int BRONZE_2H_SWORD = 1307;
  
  public static final int IRON_2H_SWORD = 1309;
  
  public static final int STEEL_2H_SWORD = 1311;
  
  public static final int BLACK_2H_SWORD = 1313;
  
  public static final int MITHRIL_2H_SWORD = 1315;
  
  public static final int ADAMANT_2H_SWORD = 1317;
  
  public static final int RUNE_2H_SWORD = 1319;
  
  public static final int BRONZE_SCIMITAR = 1321;
  
  public static final int IRON_SCIMITAR = 1323;
  
  public static final int STEEL_SCIMITAR = 1325;
  
  public static final int BLACK_SCIMITAR = 1327;
  
  public static final int MITHRIL_SCIMITAR = 1329;
  
  public static final int ADAMANT_SCIMITAR = 1331;
  
  public static final int RUNE_SCIMITAR = 1333;
  
  public static final int IRON_WARHAMMER = 1335;
  
  public static final int BRONZE_WARHAMMER = 1337;
  
  public static final int STEEL_WARHAMMER = 1339;
  
  public static final int BLACK_WARHAMMER = 1341;
  
  public static final int MITHRIL_WARHAMMER = 1343;
  
  public static final int ADAMANT_WARHAMMER = 1345;
  
  public static final int RUNE_WARHAMMER = 1347;
  
  public static final int IRON_AXE = 1349;
  
  public static final int BRONZE_AXE = 1351;
  
  public static final int STEEL_AXE = 1353;
  
  public static final int MITHRIL_AXE = 1355;
  
  public static final int ADAMANT_AXE = 1357;
  
  public static final int RUNE_AXE = 1359;
  
  public static final int BLACK_AXE = 1361;
  
  public static final int IRON_BATTLEAXE = 1363;
  
  public static final int STEEL_BATTLEAXE = 1365;
  
  public static final int BLACK_BATTLEAXE = 1367;
  
  public static final int MITHRIL_BATTLEAXE = 1369;
  
  public static final int ADAMANT_BATTLEAXE = 1371;
  
  public static final int RUNE_BATTLEAXE = 1373;
  
  public static final int BRONZE_BATTLEAXE = 1375;
  
  public static final int DRAGON_BATTLEAXE = 1377;
  
  public static final int STAFF = 1379;
  
  public static final int STAFF_OF_AIR = 1381;
  
  public static final int STAFF_OF_WATER = 1383;
  
  public static final int STAFF_OF_EARTH = 1385;
  
  public static final int STAFF_OF_FIRE = 1387;
  
  public static final int MAGIC_STAFF = 1389;
  
  public static final int BATTLESTAFF = 1391;
  
  public static final int FIRE_BATTLESTAFF = 1393;
  
  public static final int WATER_BATTLESTAFF = 1395;
  
  public static final int AIR_BATTLESTAFF = 1397;
  
  public static final int EARTH_BATTLESTAFF = 1399;
  
  public static final int MYSTIC_FIRE_STAFF = 1401;
  
  public static final int MYSTIC_WATER_STAFF = 1403;
  
  public static final int MYSTIC_AIR_STAFF = 1405;
  
  public static final int MYSTIC_EARTH_STAFF = 1407;
  
  public static final int IBANS_STAFF = 1409;
  
  public static final int IBANS_STAFF_1410 = 1410;
  
  public static final int FARMERS_FORK = 1411;
  
  public static final int HALBERD = 1413;
  
  public static final int WARHAMMER = 1415;
  
  public static final int JAVELIN = 1417;
  
  public static final int SCYTHE = 1419;
  
  public static final int IRON_MACE = 1420;
  
  public static final int BRONZE_MACE = 1422;
  
  public static final int STEEL_MACE = 1424;
  
  public static final int BLACK_MACE = 1426;
  
  public static final int MITHRIL_MACE = 1428;
  
  public static final int ADAMANT_MACE = 1430;
  
  public static final int RUNE_MACE = 1432;
  
  public static final int DRAGON_MACE = 1434;
  
  public static final int RUNE_ESSENCE = 1436;
  
  public static final int AIR_TALISMAN = 1438;
  
  public static final int EARTH_TALISMAN = 1440;
  
  public static final int FIRE_TALISMAN = 1442;
  
  public static final int WATER_TALISMAN = 1444;
  
  public static final int BODY_TALISMAN = 1446;
  
  public static final int MIND_TALISMAN = 1448;
  
  public static final int BLOOD_TALISMAN = 1450;
  
  public static final int CHAOS_TALISMAN = 1452;
  
  public static final int COSMIC_TALISMAN = 1454;
  
  public static final int DEATH_TALISMAN = 1456;
  
  public static final int LAW_TALISMAN = 1458;
  
  public static final int NATURE_TALISMAN = 1462;
  
  public static final int ARCHERY_TICKET = 1464;
  
  public static final int WEAPON_POISON_1465 = 1465;
  
  public static final int SEA_SLUG = 1466;
  
  public static final int DAMP_STICKS = 1467;
  
  public static final int DRY_STICKS = 1468;
  
  public static final int BROKEN_GLASS_1469 = 1469;
  
  public static final int RED_BEAD = 1470;
  
  public static final int YELLOW_BEAD = 1472;
  
  public static final int BLACK_BEAD = 1474;
  
  public static final int WHITE_BEAD = 1476;
  
  public static final int AMULET_OF_ACCURACY = 1478;
  
  public static final int ROCK_1480 = 1480;
  
  public static final int ORB_OF_LIGHT = 1481;
  
  public static final int ORB_OF_LIGHT_1482 = 1482;
  
  public static final int ORB_OF_LIGHT_1483 = 1483;
  
  public static final int ORB_OF_LIGHT_1484 = 1484;
  
  public static final int OILY_CLOTH = 1485;
  
  public static final int PIECE_OF_RAILING = 1486;
  
  public static final int UNICORN_HORN_1487 = 1487;
  
  public static final int PALADINS_BADGE = 1488;
  
  public static final int PALADINS_BADGE_1489 = 1489;
  
  public static final int PALADINS_BADGE_1490 = 1490;
  
  public static final int WITCHS_CAT = 1491;
  
  public static final int DOLL_OF_IBAN = 1492;
  
  public static final int OLD_JOURNAL = 1493;
  
  public static final int HISTORY_OF_IBAN = 1494;
  
  public static final int KLANKS_GAUNTLETS = 1495;
  
  public static final int IBANS_DOVE = 1496;
  
  public static final int AMULET_OF_OTHANIAN = 1497;
  
  public static final int AMULET_OF_DOOMION = 1498;
  
  public static final int AMULET_OF_HOLTHION = 1499;
  
  public static final int IBANS_SHADOW = 1500;
  
  public static final int DWARF_BREW = 1501;
  
  public static final int IBANS_ASHES = 1502;
  
  public static final int WARRANT = 1503;
  
  public static final int HANGOVER_CURE = 1504;
  
  public static final int ARDOUGNE_TELEPORT_SCROLL = 1505;
  
  public static final int GAS_MASK = 1506;
  
  public static final int A_SMALL_KEY = 1507;
  
  public static final int A_SCRUFFY_NOTE = 1508;
  
  public static final int BOOK_1509 = 1509;
  
  public static final int PICTURE = 1510;
  
  public static final int LOGS = 1511;
  
  public static final int MAGIC_LOGS = 1513;
  
  public static final int YEW_LOGS = 1515;
  
  public static final int MAPLE_LOGS = 1517;
  
  public static final int WILLOW_LOGS = 1519;
  
  public static final int OAK_LOGS = 1521;
  
  public static final int LOCKPICK = 1523;
  
  public static final int GRIMY_SNAKE_WEED = 1525;
  
  public static final int SNAKE_WEED = 1526;
  
  public static final int GRIMY_ARDRIGAL = 1527;
  
  public static final int ARDRIGAL = 1528;
  
  public static final int GRIMY_SITO_FOIL = 1529;
  
  public static final int SITO_FOIL = 1530;
  
  public static final int GRIMY_VOLENCIA_MOSS = 1531;
  
  public static final int VOLENCIA_MOSS = 1532;
  
  public static final int GRIMY_ROGUES_PURSE = 1533;
  
  public static final int ROGUES_PURSE = 1534;
  
  public static final int MAP_PART = 1535;
  
  public static final int MAP_PART_1536 = 1536;
  
  public static final int MAP_PART_1537 = 1537;
  
  public static final int CRANDOR_MAP = 1538;
  
  public static final int STEEL_NAILS = 1539;
  
  public static final int ANTIDRAGON_SHIELD = 1540;
  
  public static final int MAZE_KEY = 1542;
  
  public static final int KEY_1543 = 1543;
  
  public static final int KEY_1544 = 1544;
  
  public static final int KEY_1545 = 1545;
  
  public static final int KEY_1546 = 1546;
  
  public static final int KEY_1547 = 1547;
  
  public static final int KEY_1548 = 1548;
  
  public static final int STAKE = 1549;
  
  public static final int GARLIC = 1550;
  
  public static final int SEASONED_SARDINE = 1552;
  
  public static final int FLUFFS_KITTEN = 1554;
  
  public static final int PET_KITTEN = 1555;
  
  public static final int PET_KITTEN_1556 = 1556;
  
  public static final int PET_KITTEN_1557 = 1557;
  
  public static final int PET_KITTEN_1558 = 1558;
  
  public static final int PET_KITTEN_1559 = 1559;
  
  public static final int PET_KITTEN_1560 = 1560;
  
  public static final int PET_CAT = 1561;
  
  public static final int PET_CAT_1562 = 1562;
  
  public static final int PET_CAT_1563 = 1563;
  
  public static final int PET_CAT_1564 = 1564;
  
  public static final int PET_CAT_1565 = 1565;
  
  public static final int PET_CAT_1566 = 1566;
  
  public static final int PET_CAT_1567 = 1567;
  
  public static final int PET_CAT_1568 = 1568;
  
  public static final int PET_CAT_1569 = 1569;
  
  public static final int PET_CAT_1570 = 1570;
  
  public static final int PET_CAT_1571 = 1571;
  
  public static final int PET_CAT_1572 = 1572;
  
  public static final int DOOGLE_LEAVES = 1573;
  
  public static final int CAT_TRAINING_MEDAL = 1575;
  
  public static final int PETES_CANDLESTICK = 1577;
  
  public static final int THIEVES_ARMBAND = 1579;
  
  public static final int ICE_GLOVES = 1580;
  
  public static final int BLAMISH_SNAIL_SLIME = 1581;
  
  public static final int BLAMISH_OIL = 1582;
  
  public static final int FIRE_FEATHER = 1583;
  
  public static final int ID_PAPERS = 1584;
  
  public static final int OILY_FISHING_ROD = 1585;
  
  public static final int MISCELLANEOUS_KEY = 1586;
  
  public static final int GRIPS_KEYRING = 1588;
  
  public static final int DUSTY_KEY = 1590;
  
  public static final int JAIL_KEY = 1591;
  
  public static final int RING_MOULD = 1592;
  
  public static final int UNHOLY_MOULD = 1594;
  
  public static final int AMULET_MOULD = 1595;
  
  public static final int NECKLACE_MOULD = 1597;
  
  public static final int HOLY_MOULD = 1599;
  
  public static final int DIAMOND = 1601;
  
  public static final int RUBY = 1603;
  
  public static final int EMERALD = 1605;
  
  public static final int SAPPHIRE = 1607;
  
  public static final int OPAL = 1609;
  
  public static final int JADE = 1611;
  
  public static final int RED_TOPAZ = 1613;
  
  public static final int DRAGONSTONE = 1615;
  
  public static final int UNCUT_DIAMOND = 1617;
  
  public static final int UNCUT_RUBY = 1619;
  
  public static final int UNCUT_EMERALD = 1621;
  
  public static final int UNCUT_SAPPHIRE = 1623;
  
  public static final int UNCUT_OPAL = 1625;
  
  public static final int UNCUT_JADE = 1627;
  
  public static final int UNCUT_RED_TOPAZ = 1629;
  
  public static final int UNCUT_DRAGONSTONE = 1631;
  
  public static final int CRUSHED_GEM = 1633;
  
  public static final int GOLD_RING = 1635;
  
  public static final int SAPPHIRE_RING = 1637;
  
  public static final int EMERALD_RING = 1639;
  
  public static final int RUBY_RING = 1641;
  
  public static final int DIAMOND_RING = 1643;
  
  public static final int DRAGONSTONE_RING = 1645;
  
  public static final int GOLD_NECKLACE = 1654;
  
  public static final int SAPPHIRE_NECKLACE = 1656;
  
  public static final int EMERALD_NECKLACE = 1658;
  
  public static final int RUBY_NECKLACE = 1660;
  
  public static final int DIAMOND_NECKLACE = 1662;
  
  public static final int DRAGON_NECKLACE = 1664;
  
  public static final int GOLD_AMULET_U = 1673;
  
  public static final int SAPPHIRE_AMULET_U = 1675;
  
  public static final int EMERALD_AMULET_U = 1677;
  
  public static final int RUBY_AMULET_U = 1679;
  
  public static final int DIAMOND_AMULET_U = 1681;
  
  public static final int DRAGONSTONE_AMULET_U = 1683;
  
  public static final int KARAMJA_GLOVES = 1686;
  
  public static final int GOLD_AMULET = 1692;
  
  public static final int SAPPHIRE_AMULET = 1694;
  
  public static final int EMERALD_AMULET = 1696;
  
  public static final int RUBY_AMULET = 1698;
  
  public static final int DIAMOND_AMULET = 1700;
  
  public static final int DRAGONSTONE_AMULET = 1702;
  
  public static final int AMULET_OF_GLORY = 1704;
  
  public static final int AMULET_OF_GLORY1 = 1706;
  
  public static final int AMULET_OF_GLORY2 = 1708;
  
  public static final int AMULET_OF_GLORY3 = 1710;
  
  public static final int AMULET_OF_GLORY4 = 1712;
  
  public static final int UNSTRUNG_SYMBOL = 1714;
  
  public static final int UNBLESSED_SYMBOL = 1716;
  
  public static final int HOLY_SYMBOL = 1718;
  
  public static final int UNSTRUNG_EMBLEM = 1720;
  
  public static final int UNPOWERED_SYMBOL = 1722;
  
  public static final int UNHOLY_SYMBOL = 1724;
  
  public static final int AMULET_OF_STRENGTH = 1725;
  
  public static final int AMULET_OF_MAGIC = 1727;
  
  public static final int AMULET_OF_DEFENCE = 1729;
  
  public static final int AMULET_OF_POWER = 1731;
  
  public static final int NEEDLE = 1733;
  
  public static final int THREAD = 1734;
  
  public static final int SHEARS = 1735;
  
  public static final int WOOL = 1737;
  
  public static final int COWHIDE = 1739;
  
  public static final int LEATHER = 1741;
  
  public static final int HARD_LEATHER = 1743;
  
  public static final int GREEN_DRAGON_LEATHER = 1745;
  
  public static final int BLACK_DRAGONHIDE = 1747;
  
  public static final int RED_DRAGONHIDE = 1749;
  
  public static final int BLUE_DRAGONHIDE = 1751;
  
  public static final int GREEN_DRAGONHIDE = 1753;
  
  public static final int CHISEL = 1755;
  
  public static final int BROWN_APRON = 1757;
  
  public static final int BALL_OF_WOOL = 1759;
  
  public static final int SOFT_CLAY = 1761;
  
  public static final int RED_DYE = 1763;
  
  public static final int YELLOW_DYE = 1765;
  
  public static final int BLUE_DYE = 1767;
  
  public static final int ORANGE_DYE = 1769;
  
  public static final int GREEN_DYE = 1771;
  
  public static final int PURPLE_DYE = 1773;
  
  public static final int MOLTEN_GLASS = 1775;
  
  public static final int BOW_STRING = 1777;
  
  public static final int FLAX = 1779;
  
  public static final int SODA_ASH = 1781;
  
  public static final int BUCKET_OF_SAND = 1783;
  
  public static final int GLASSBLOWING_PIPE = 1785;
  
  public static final int UNFIRED_POT = 1787;
  
  public static final int UNFIRED_PIE_DISH = 1789;
  
  public static final int UNFIRED_BOWL = 1791;
  
  public static final int WOAD_LEAF = 1793;
  
  public static final int BRONZE_WIRE = 1794;
  
  public static final int SILVER_NECKLACE = 1796;
  
  public static final int SILVER_NECKLACE_1797 = 1797;
  
  public static final int SILVER_CUP = 1798;
  
  public static final int SILVER_CUP_1799 = 1799;
  
  public static final int SILVER_BOTTLE = 1800;
  
  public static final int SILVER_BOTTLE_1801 = 1801;
  
  public static final int SILVER_BOOK = 1802;
  
  public static final int SILVER_BOOK_1803 = 1803;
  
  public static final int SILVER_NEEDLE = 1804;
  
  public static final int SILVER_NEEDLE_1805 = 1805;
  
  public static final int SILVER_POT = 1806;
  
  public static final int SILVER_POT_1807 = 1807;
  
  public static final int CRIMINALS_THREAD = 1808;
  
  public static final int CRIMINALS_THREAD_1809 = 1809;
  
  public static final int CRIMINALS_THREAD_1810 = 1810;
  
  public static final int FLYPAPER = 1811;
  
  public static final int PUNGENT_POT = 1812;
  
  public static final int CRIMINALS_DAGGER = 1813;
  
  public static final int CRIMINALS_DAGGER_1814 = 1814;
  
  public static final int KILLERS_PRINT = 1815;
  
  public static final int ANNAS_PRINT = 1816;
  
  public static final int BOBS_PRINT = 1817;
  
  public static final int CAROLS_PRINT = 1818;
  
  public static final int DAVIDS_PRINT = 1819;
  
  public static final int ELIZABETHS_PRINT = 1820;
  
  public static final int FRANKS_PRINT = 1821;
  
  public static final int UNKNOWN_PRINT = 1822;
  
  public static final int WATERSKIN4 = 1823;
  
  public static final int WATERSKIN3 = 1825;
  
  public static final int WATERSKIN2 = 1827;
  
  public static final int WATERSKIN1 = 1829;
  
  public static final int WATERSKIN0 = 1831;
  
  public static final int DESERT_SHIRT = 1833;
  
  public static final int DESERT_ROBE = 1835;
  
  public static final int DESERT_BOOTS = 1837;
  
  public static final int METAL_KEY = 1839;
  
  public static final int CELL_DOOR_KEY = 1840;
  
  public static final int BARREL = 1841;
  
  public static final int ANA_IN_A_BARREL = 1842;
  
  public static final int WROUGHT_IRON_KEY = 1843;
  
  public static final int SLAVE_SHIRT = 1844;
  
  public static final int SLAVE_ROBE = 1845;
  
  public static final int SLAVE_BOOTS = 1846;
  
  public static final int SCRUMPLED_PAPER = 1847;
  
  public static final int SHANTAY_DISCLAIMER = 1848;
  
  public static final int PROTOTYPE_DART = 1849;
  
  public static final int TECHNICAL_PLANS = 1850;
  
  public static final int TENTI_PINEAPPLE = 1851;
  
  public static final int BEDABIN_KEY = 1852;
  
  public static final int PROTOTYPE_DART_TIP = 1853;
  
  public static final int SHANTAY_PASS = 1854;
  
  public static final int ROCK_1855 = 1855;
  
  public static final int GUIDE_BOOK = 1856;
  
  public static final int TOTEM = 1857;
  
  public static final int ADDRESS_LABEL = 1858;
  
  public static final int RAW_UGTHANKI_MEAT = 1859;
  
  public static final int UGTHANKI_MEAT = 1861;
  
  public static final int PITTA_DOUGH = 1863;
  
  public static final int PITTA_BREAD = 1865;
  
  public static final int BURNT_PITTA_BREAD = 1867;
  
  public static final int CHOPPED_TOMATO = 1869;
  
  public static final int CHOPPED_ONION = 1871;
  
  public static final int CHOPPED_UGTHANKI = 1873;
  
  public static final int ONION__TOMATO = 1875;
  
  public static final int UGTHANKI__ONION = 1877;
  
  public static final int UGTHANKI__TOMATO = 1879;
  
  public static final int KEBAB_MIX = 1881;
  
  public static final int UGTHANKI_KEBAB = 1883;
  
  public static final int UGTHANKI_KEBAB_1885 = 1885;
  
  public static final int CAKE_TIN = 1887;
  
  public static final int UNCOOKED_CAKE = 1889;
  
  public static final int CAKE = 1891;
  
  public static final int _23_CAKE = 1893;
  
  public static final int SLICE_OF_CAKE = 1895;
  
  public static final int CHOCOLATE_CAKE = 1897;
  
  public static final int _23_CHOCOLATE_CAKE = 1899;
  
  public static final int CHOCOLATE_SLICE = 1901;
  
  public static final int BURNT_CAKE = 1903;
  
  public static final int ASGARNIAN_ALE = 1905;
  
  public static final int WIZARDS_MIND_BOMB = 1907;
  
  public static final int GREENMANS_ALE = 1909;
  
  public static final int DRAGON_BITTER = 1911;
  
  public static final int DWARVEN_STOUT = 1913;
  
  public static final int GROG = 1915;
  
  public static final int BEER = 1917;
  
  public static final int BEER_GLASS = 1919;
  
  public static final int BOWL_OF_WATER = 1921;
  
  public static final int BOWL = 1923;
  
  public static final int BUCKET = 1925;
  
  public static final int BUCKET_OF_MILK = 1927;
  
  public static final int BUCKET_OF_WATER = 1929;
  
  public static final int POT = 1931;
  
  public static final int POT_OF_FLOUR = 1933;
  
  public static final int JUG = 1935;
  
  public static final int JUG_OF_WATER = 1937;
  
  public static final int SWAMP_TAR = 1939;
  
  public static final int RAW_SWAMP_PASTE = 1940;
  
  public static final int SWAMP_PASTE = 1941;
  
  public static final int POTATO = 1942;
  
  public static final int EGG = 1944;
  
  public static final int FLOUR = 1946;
  
  public static final int GRAIN = 1947;
  
  public static final int CHEFS_HAT = 1949;
  
  public static final int REDBERRIES = 1951;
  
  public static final int PASTRY_DOUGH = 1953;
  
  public static final int COOKING_APPLE = 1955;
  
  public static final int ONION = 1957;
  
  public static final int PUMPKIN = 1959;
  
  public static final int EASTER_EGG = 1961;
  
  public static final int BANANA = 1963;
  
  public static final int CABBAGE = 1965;
  
  public static final int CABBAGE_1967 = 1967;
  
  public static final int SPINACH_ROLL = 1969;
  
  public static final int KEBAB = 1971;
  
  public static final int CHOCOLATE_BAR = 1973;
  
  public static final int CHOCOLATE_DUST = 1975;
  
  public static final int CHOCOLATEY_MILK = 1977;
  
  public static final int CUP_OF_TEA_1978 = 1978;
  
  public static final int EMPTY_CUP = 1980;
  
  public static final int TOMATO = 1982;
  
  public static final int ROTTEN_APPLE = 1984;
  
  public static final int CHEESE = 1985;
  
  public static final int GRAPES = 1987;
  
  public static final int HALF_FULL_WINE_JUG = 1989;
  
  public static final int JUG_OF_BAD_WINE = 1991;
  
  public static final int JUG_OF_BAD_WINE_1992 = 1992;
  
  public static final int JUG_OF_WINE = 1993;
  
  public static final int UNFERMENTED_WINE = 1995;
  
  public static final int UNFERMENTED_WINE_1996 = 1996;
  
  public static final int INCOMPLETE_STEW = 1997;
  
  public static final int INCOMPLETE_STEW_1999 = 1999;
  
  public static final int UNCOOKED_STEW = 2001;
  
  public static final int STEW = 2003;
  
  public static final int BURNT_STEW = 2005;
  
  public static final int SPICE = 2007;
  
  public static final int UNCOOKED_CURRY = 2009;
  
  public static final int CURRY = 2011;
  
  public static final int BURNT_CURRY = 2013;
  
  public static final int VODKA = 2015;
  
  public static final int WHISKY = 2017;
  
  public static final int GIN = 2019;
  
  public static final int BRANDY = 2021;
  
  public static final int COCKTAIL_GUIDE = 2023;
  
  public static final int COCKTAIL_SHAKER = 2025;
  
  public static final int COCKTAIL_GLASS = 2026;
  
  public static final int PREMADE_BLURB_SP = 2028;
  
  public static final int PREMADE_CHOC_SDY = 2030;
  
  public static final int PREMADE_DR_DRAGON = 2032;
  
  public static final int PREMADE_FR_BLAST = 2034;
  
  public static final int PREMADE_P_PUNCH = 2036;
  
  public static final int PREMADE_SGG = 2038;
  
  public static final int PREMADE_WIZ_BLZD = 2040;
  
  public static final int UNFINISHED_COCKTAIL = 2042;
  
  public static final int UNFINISHED_COCKTAIL_2044 = 2044;
  
  public static final int UNFINISHED_COCKTAIL_2046 = 2046;
  
  public static final int PINEAPPLE_PUNCH = 2048;
  
  public static final int UNFINISHED_COCKTAIL_2050 = 2050;
  
  public static final int UNFINISHED_COCKTAIL_2052 = 2052;
  
  public static final int WIZARD_BLIZZARD = 2054;
  
  public static final int UNFINISHED_COCKTAIL_2056 = 2056;
  
  public static final int UNFINISHED_COCKTAIL_2058 = 2058;
  
  public static final int UNFINISHED_COCKTAIL_2060 = 2060;
  
  public static final int UNFINISHED_COCKTAIL_2062 = 2062;
  
  public static final int BLURBERRY_SPECIAL = 2064;
  
  public static final int UNFINISHED_COCKTAIL_2066 = 2066;
  
  public static final int UNFINISHED_COCKTAIL_2068 = 2068;
  
  public static final int UNFINISHED_COCKTAIL_2070 = 2070;
  
  public static final int UNFINISHED_COCKTAIL_2072 = 2072;
  
  public static final int CHOC_SATURDAY = 2074;
  
  public static final int UNFINISHED_COCKTAIL_2076 = 2076;
  
  public static final int UNFINISHED_COCKTAIL_2078 = 2078;
  
  public static final int SHORT_GREEN_GUY = 2080;
  
  public static final int UNFINISHED_COCKTAIL_2082 = 2082;
  
  public static final int FRUIT_BLAST = 2084;
  
  public static final int UNFINISHED_COCKTAIL_2086 = 2086;
  
  public static final int UNFINISHED_COCKTAIL_2088 = 2088;
  
  public static final int UNFINISHED_COCKTAIL_2090 = 2090;
  
  public static final int DRUNK_DRAGON = 2092;
  
  public static final int ODD_COCKTAIL = 2094;
  
  public static final int ODD_COCKTAIL_2096 = 2096;
  
  public static final int ODD_COCKTAIL_2098 = 2098;
  
  public static final int ODD_COCKTAIL_2100 = 2100;
  
  public static final int LEMON = 2102;
  
  public static final int LEMON_CHUNKS = 2104;
  
  public static final int LEMON_SLICES = 2106;
  
  public static final int ORANGE = 2108;
  
  public static final int ORANGE_CHUNKS = 2110;
  
  public static final int ORANGE_SLICES = 2112;
  
  public static final int PINEAPPLE = 2114;
  
  public static final int PINEAPPLE_CHUNKS = 2116;
  
  public static final int PINEAPPLE_RING = 2118;
  
  public static final int LIME = 2120;
  
  public static final int LIME_CHUNKS = 2122;
  
  public static final int LIME_SLICES = 2124;
  
  public static final int DWELLBERRIES = 2126;
  
  public static final int EQUA_LEAVES = 2128;
  
  public static final int POT_OF_CREAM = 2130;
  
  public static final int RAW_BEEF = 2132;
  
  public static final int RAW_RAT_MEAT = 2134;
  
  public static final int RAW_BEAR_MEAT = 2136;
  
  public static final int RAW_CHICKEN = 2138;
  
  public static final int COOKED_CHICKEN = 2140;
  
  public static final int COOKED_MEAT = 2142;
  
  public static final int BURNT_CHICKEN = 2144;
  
  public static final int BURNT_MEAT = 2146;
  
  public static final int RAW_LAVA_EEL = 2148;
  
  public static final int LAVA_EEL = 2149;
  
  public static final int SWAMP_TOAD = 2150;
  
  public static final int TOADS_LEGS = 2152;
  
  public static final int EQUA_TOADS_LEGS = 2154;
  
  public static final int SPICY_TOADS_LEGS = 2156;
  
  public static final int SEASONED_LEGS = 2158;
  
  public static final int SPICY_WORM = 2160;
  
  public static final int KING_WORM = 2162;
  
  public static final int BATTA_TIN = 2164;
  
  public static final int CRUNCHY_TRAY = 2165;
  
  public static final int GNOMEBOWL_MOULD = 2166;
  
  public static final int GIANNES_COOK_BOOK = 2167;
  
  public static final int GNOME_SPICE = 2169;
  
  public static final int GIANNE_DOUGH = 2171;
  
  public static final int ODD_GNOMEBOWL = 2173;
  
  public static final int BURNT_GNOMEBOWL = 2175;
  
  public static final int HALF_BAKED_BOWL = 2177;
  
  public static final int RAW_GNOMEBOWL = 2178;
  
  public static final int UNFINISHED_BOWL = 2179;
  
  public static final int UNFINISHED_BOWL_2181 = 2181;
  
  public static final int UNFINISHED_BOWL_2183 = 2183;
  
  public static final int CHOCOLATE_BOMB = 2185;
  
  public static final int TANGLED_TOADS_LEGS = 2187;
  
  public static final int UNFINISHED_BOWL_2189 = 2189;
  
  public static final int WORM_HOLE = 2191;
  
  public static final int UNFINISHED_BOWL_2193 = 2193;
  
  public static final int VEG_BALL = 2195;
  
  public static final int ODD_CRUNCHIES = 2197;
  
  public static final int BURNT_CRUNCHIES = 2199;
  
  public static final int HALF_BAKED_CRUNCHY = 2201;
  
  public static final int RAW_CRUNCHIES = 2202;
  
  public static final int ROCKCLIMBING_BOOTS = 2203;
  
  public static final int WORM_CRUNCHIES = 2205;
  
  public static final int UNFINISHED_CRUNCHY = 2207;
  
  public static final int CHOCCHIP_CRUNCHIES = 2209;
  
  public static final int UNFINISHED_CRUNCHY_2211 = 2211;
  
  public static final int SPICY_CRUNCHIES = 2213;
  
  public static final int UNFINISHED_CRUNCHY_2215 = 2215;
  
  public static final int TOAD_CRUNCHIES = 2217;
  
  public static final int PREMADE_WM_BATTA = 2219;
  
  public static final int PREMADE_TD_BATTA = 2221;
  
  public static final int PREMADE_CT_BATTA = 2223;
  
  public static final int PREMADE_FRT_BATTA = 2225;
  
  public static final int PREMADE_VEG_BATTA = 2227;
  
  public static final int PREMADE_CHOC_BOMB = 2229;
  
  public static final int PREMADE_TTL = 2231;
  
  public static final int PREMADE_WORM_HOLE = 2233;
  
  public static final int PREMADE_VEG_BALL = 2235;
  
  public static final int PREMADE_WM_CRUN = 2237;
  
  public static final int PREMADE_CH_CRUNCH = 2239;
  
  public static final int PREMADE_SY_CRUNCH = 2241;
  
  public static final int PREMADE_TD_CRUNCH = 2243;
  
  public static final int ODD_BATTA = 2245;
  
  public static final int BURNT_BATTA = 2247;
  
  public static final int HALF_BAKED_BATTA = 2249;
  
  public static final int RAW_BATTA = 2250;
  
  public static final int UNFINISHED_BATTA = 2251;
  
  public static final int WORM_BATTA = 2253;
  
  public static final int TOAD_BATTA = 2255;
  
  public static final int UNFINISHED_BATTA_2257 = 2257;
  
  public static final int CHEESETOM_BATTA = 2259;
  
  public static final int UNFINISHED_BATTA_2261 = 2261;
  
  public static final int UNFINISHED_BATTA_2263 = 2263;
  
  public static final int UNFINISHED_BATTA_2265 = 2265;
  
  public static final int UNFINISHED_BATTA_2267 = 2267;
  
  public static final int UNFINISHED_BATTA_2269 = 2269;
  
  public static final int UNFINISHED_BATTA_2271 = 2271;
  
  public static final int UNFINISHED_BATTA_2273 = 2273;
  
  public static final int UNFINISHED_BATTA_2275 = 2275;
  
  public static final int FRUIT_BATTA = 2277;
  
  public static final int UNFINISHED_BATTA_2279 = 2279;
  
  public static final int VEGETABLE_BATTA = 2281;
  
  public static final int PIZZA_BASE = 2283;
  
  public static final int INCOMPLETE_PIZZA = 2285;
  
  public static final int UNCOOKED_PIZZA = 2287;
  
  public static final int PLAIN_PIZZA = 2289;
  
  public static final int _12_PLAIN_PIZZA = 2291;
  
  public static final int MEAT_PIZZA = 2293;
  
  public static final int _12_MEAT_PIZZA = 2295;
  
  public static final int ANCHOVY_PIZZA = 2297;
  
  public static final int _12_ANCHOVY_PIZZA = 2299;
  
  public static final int PINEAPPLE_PIZZA = 2301;
  
  public static final int _12_PINEAPPLE_PIZZA = 2303;
  
  public static final int BURNT_PIZZA = 2305;
  
  public static final int BREAD_DOUGH = 2307;
  
  public static final int BREAD = 2309;
  
  public static final int BURNT_BREAD = 2311;
  
  public static final int PIE_DISH = 2313;
  
  public static final int PIE_SHELL = 2315;
  
  public static final int UNCOOKED_APPLE_PIE = 2317;
  
  public static final int UNCOOKED_MEAT_PIE = 2319;
  
  public static final int UNCOOKED_BERRY_PIE = 2321;
  
  public static final int APPLE_PIE = 2323;
  
  public static final int REDBERRY_PIE = 2325;
  
  public static final int MEAT_PIE = 2327;
  
  public static final int BURNT_PIE = 2329;
  
  public static final int HALF_A_MEAT_PIE = 2331;
  
  public static final int HALF_A_REDBERRY_PIE = 2333;
  
  public static final int HALF_AN_APPLE_PIE = 2335;
  
  public static final int RAW_OOMLIE = 2337;
  
  public static final int PALM_LEAF = 2339;
  
  public static final int PALM_LEAF_2340 = 2340;
  
  public static final int WRAPPED_OOMLIE = 2341;
  
  public static final int COOKED_OOMLIE_WRAP = 2343;
  
  public static final int BURNT_OOMLIE_WRAP = 2345;
  
  public static final int HAMMER = 2347;
  
  public static final int BRONZE_BAR = 2349;
  
  public static final int IRON_BAR = 2351;
  
  public static final int STEEL_BAR = 2353;
  
  public static final int SILVER_BAR = 2355;
  
  public static final int GOLD_BAR = 2357;
  
  public static final int MITHRIL_BAR = 2359;
  
  public static final int ADAMANTITE_BAR = 2361;
  
  public static final int RUNITE_BAR = 2363;
  
  public static final int PERFECT_GOLD_BAR = 2365;
  
  public static final int SHIELD_LEFT_HALF = 2366;
  
  public static final int SHIELD_RIGHT_HALF = 2368;
  
  public static final int STEEL_STUDS = 2370;
  
  public static final int OGRE_RELIC = 2372;
  
  public static final int RELIC_PART_1 = 2373;
  
  public static final int RELIC_PART_2 = 2374;
  
  public static final int RELIC_PART_3 = 2375;
  
  public static final int SKAVID_MAP = 2376;
  
  public static final int OGRE_TOOTH = 2377;
  
  public static final int TOBANS_KEY = 2378;
  
  public static final int ROCK_CAKE = 2379;
  
  public static final int CRYSTAL = 2380;
  
  public static final int CRYSTAL_2381 = 2381;
  
  public static final int CRYSTAL_2382 = 2382;
  
  public static final int CRYSTAL_2383 = 2383;
  
  public static final int FINGERNAILS = 2384;
  
  public static final int OLD_ROBE = 2385;
  
  public static final int UNUSUAL_ARMOUR = 2386;
  
  public static final int DAMAGED_DAGGER = 2387;
  
  public static final int TATTERED_EYE_PATCH = 2388;
  
  public static final int VIAL_2389 = 2389;
  
  public static final int VIAL_2390 = 2390;
  
  public static final int GROUND_BAT_BONES = 2391;
  
  public static final int TOBANS_GOLD = 2393;
  
  public static final int POTION_2394 = 2394;
  
  public static final int MAGIC_OGRE_POTION = 2395;
  
  public static final int SPELL_SCROLL = 2396;
  
  public static final int SHAMAN_ROBE = 2397;
  
  public static final int CAVE_NIGHTSHADE = 2398;
  
  public static final int SILVERLIGHT_KEY = 2399;
  
  public static final int SILVERLIGHT_KEY_2400 = 2400;
  
  public static final int SILVERLIGHT_KEY_2401 = 2401;
  
  public static final int SILVERLIGHT = 2402;
  
  public static final int HAZEEL_SCROLL = 2403;
  
  public static final int CHEST_KEY_2404 = 2404;
  
  public static final int CARNILLEAN_ARMOUR = 2405;
  
  public static final int HAZEELS_MARK = 2406;
  
  public static final int BALL = 2407;
  
  public static final int DIARY = 2408;
  
  public static final int DOOR_KEY = 2409;
  
  public static final int MAGNET = 2410;
  
  public static final int KEY_2411 = 2411;
  
  public static final int SARADOMIN_CAPE = 2412;
  
  public static final int GUTHIX_CAPE = 2413;
  
  public static final int ZAMORAK_CAPE = 2414;
  
  public static final int SARADOMIN_STAFF = 2415;
  
  public static final int GUTHIX_STAFF = 2416;
  
  public static final int ZAMORAK_STAFF = 2417;
  
  public static final int BRONZE_KEY = 2418;
  
  public static final int WIG = 2419;
  
  public static final int WIG_2421 = 2421;
  
  public static final int BLUE_PARTYHAT_2422 = 2422;
  
  public static final int KEY_PRINT = 2423;
  
  public static final int PASTE = 2424;
  
  public static final int VORKATHS_HEAD = 2425;
  
  public static final int BURNT_OOMLIE = 2426;
  
  public static final int ATTACK_POTION4 = 2428;
  
  public static final int RESTORE_POTION4 = 2430;
  
  public static final int DEFENCE_POTION4 = 2432;
  
  public static final int PRAYER_POTION4 = 2434;
  
  public static final int SUPER_ATTACK4 = 2436;
  
  public static final int FISHING_POTION4 = 2438;
  
  public static final int SUPER_STRENGTH4 = 2440;
  
  public static final int SUPER_DEFENCE4 = 2442;
  
  public static final int RANGING_POTION4 = 2444;
  
  public static final int ANTIPOISON4 = 2446;
  
  public static final int SUPERANTIPOISON4 = 2448;
  
  public static final int ZAMORAK_BREW4 = 2450;
  
  public static final int ANTIFIRE_POTION4 = 2452;
  
  public static final int ANTIFIRE_POTION3 = 2454;
  
  public static final int ANTIFIRE_POTION2 = 2456;
  
  public static final int ANTIFIRE_POTION1 = 2458;
  
  public static final int ASSORTED_FLOWERS = 2460;
  
  public static final int RED_FLOWERS = 2462;
  
  public static final int BLUE_FLOWERS = 2464;
  
  public static final int YELLOW_FLOWERS = 2466;
  
  public static final int PURPLE_FLOWERS = 2468;
  
  public static final int ORANGE_FLOWERS = 2470;
  
  public static final int MIXED_FLOWERS = 2472;
  
  public static final int WHITE_FLOWERS = 2474;
  
  public static final int BLACK_FLOWERS = 2476;
  
  public static final int LANTADYME = 2481;
  
  public static final int LANTADYME_POTION_UNF = 2483;
  
  public static final int GRIMY_LANTADYME = 2485;
  
  public static final int BLUE_DHIDE_VAMBRACES = 2487;
  
  public static final int RED_DHIDE_VAMBRACES = 2489;
  
  public static final int BLACK_DHIDE_VAMBRACES = 2491;
  
  public static final int BLUE_DHIDE_CHAPS = 2493;
  
  public static final int RED_DHIDE_CHAPS = 2495;
  
  public static final int BLACK_DHIDE_CHAPS = 2497;
  
  public static final int BLUE_DHIDE_BODY = 2499;
  
  public static final int RED_DHIDE_BODY = 2501;
  
  public static final int BLACK_DHIDE_BODY = 2503;
  
  public static final int BLUE_DRAGON_LEATHER = 2505;
  
  public static final int RED_DRAGON_LEATHER = 2507;
  
  public static final int BLACK_DRAGON_LEATHER = 2509;
  
  public static final int LOGS_2511 = 2511;
  
  public static final int DRAGON_CHAINBODY = 2513;
  
  public static final int RAW_SHRIMPS_2514 = 2514;
  
  public static final int POT_OF_FLOUR_2516 = 2516;
  
  public static final int ROTTEN_TOMATO = 2518;
  
  public static final int BROWN_TOY_HORSEY = 2520;
  
  public static final int WHITE_TOY_HORSEY = 2522;
  
  public static final int BLACK_TOY_HORSEY = 2524;
  
  public static final int GREY_TOY_HORSEY = 2526;
  
  public static final int LAMP = 2528;
  
  public static final int DEAD_ORB = 2529;
  
  public static final int BONES_2530 = 2530;
  
  public static final int IRON_FIRE_ARROW = 2532;
  
  public static final int IRON_FIRE_ARROW_LIT = 2533;
  
  public static final int STEEL_FIRE_ARROW = 2534;
  
  public static final int STEEL_FIRE_ARROW_LIT = 2535;
  
  public static final int MITHRIL_FIRE_ARROW = 2536;
  
  public static final int MITHRIL_FIRE_ARROW_LIT = 2537;
  
  public static final int ADAMANT_FIRE_ARROW = 2538;
  
  public static final int ADAMANT_FIRE_ARROW_LIT = 2539;
  
  public static final int RUNE_FIRE_ARROW = 2540;
  
  public static final int RUNE_FIRE_ARROW_LIT = 2541;
  
  public static final int RING_OF_RECOIL = 2550;
  
  public static final int RING_OF_DUELING8 = 2552;
  
  public static final int RING_OF_DUELING7 = 2554;
  
  public static final int RING_OF_DUELING6 = 2556;
  
  public static final int RING_OF_DUELING5 = 2558;
  
  public static final int RING_OF_DUELING4 = 2560;
  
  public static final int RING_OF_DUELING3 = 2562;
  
  public static final int RING_OF_DUELING2 = 2564;
  
  public static final int RING_OF_DUELING1 = 2566;
  
  public static final int RING_OF_FORGING = 2568;
  
  public static final int RING_OF_LIFE = 2570;
  
  public static final int RING_OF_WEALTH = 2572;
  
  public static final int SEXTANT = 2574;
  
  public static final int WATCH = 2575;
  
  public static final int CHART = 2576;
  
  public static final int RANGER_BOOTS = 2577;
  
  public static final int WIZARD_BOOTS = 2579;
  
  public static final int ROBIN_HOOD_HAT = 2581;
  
  public static final int BLACK_PLATEBODY_T = 2583;
  
  public static final int BLACK_PLATELEGS_T = 2585;
  
  public static final int BLACK_FULL_HELM_T = 2587;
  
  public static final int BLACK_KITESHIELD_T = 2589;
  
  public static final int BLACK_PLATEBODY_G = 2591;
  
  public static final int BLACK_PLATELEGS_G = 2593;
  
  public static final int BLACK_FULL_HELM_G = 2595;
  
  public static final int BLACK_KITESHIELD_G = 2597;
  
  public static final int ADAMANT_PLATEBODY_T = 2599;
  
  public static final int ADAMANT_PLATELEGS_T = 2601;
  
  public static final int ADAMANT_KITESHIELD_T = 2603;
  
  public static final int ADAMANT_FULL_HELM_T = 2605;
  
  public static final int ADAMANT_PLATEBODY_G = 2607;
  
  public static final int ADAMANT_PLATELEGS_G = 2609;
  
  public static final int ADAMANT_KITESHIELD_G = 2611;
  
  public static final int ADAMANT_FULL_HELM_G = 2613;
  
  public static final int RUNE_PLATEBODY_G = 2615;
  
  public static final int RUNE_PLATELEGS_G = 2617;
  
  public static final int RUNE_FULL_HELM_G = 2619;
  
  public static final int RUNE_KITESHIELD_G = 2621;
  
  public static final int RUNE_PLATEBODY_T = 2623;
  
  public static final int RUNE_PLATELEGS_T = 2625;
  
  public static final int RUNE_FULL_HELM_T = 2627;
  
  public static final int RUNE_KITESHIELD_T = 2629;
  
  public static final int HIGHWAYMAN_MASK = 2631;
  
  public static final int BLUE_BERET = 2633;
  
  public static final int BLACK_BERET = 2635;
  
  public static final int WHITE_BERET = 2637;
  
  public static final int TAN_CAVALIER = 2639;
  
  public static final int DARK_CAVALIER = 2641;
  
  public static final int BLACK_CAVALIER = 2643;
  
  public static final int RED_HEADBAND = 2645;
  
  public static final int BLACK_HEADBAND = 2647;
  
  public static final int BROWN_HEADBAND = 2649;
  
  public static final int PIRATES_HAT = 2651;
  
  public static final int ZAMORAK_PLATEBODY = 2653;
  
  public static final int ZAMORAK_PLATELEGS = 2655;
  
  public static final int ZAMORAK_FULL_HELM = 2657;
  
  public static final int ZAMORAK_KITESHIELD = 2659;
  
  public static final int SARADOMIN_PLATEBODY = 2661;
  
  public static final int SARADOMIN_PLATELEGS = 2663;
  
  public static final int SARADOMIN_FULL_HELM = 2665;
  
  public static final int SARADOMIN_KITESHIELD = 2667;
  
  public static final int GUTHIX_PLATEBODY = 2669;
  
  public static final int GUTHIX_PLATELEGS = 2671;
  
  public static final int GUTHIX_FULL_HELM = 2673;
  
  public static final int GUTHIX_KITESHIELD = 2675;
  
  public static final int CLUE_SCROLL_EASY = 2677;
  
  public static final int CLUE_SCROLL_EASY_2678 = 2678;
  
  public static final int CLUE_SCROLL_EASY_2679 = 2679;
  
  public static final int CLUE_SCROLL_EASY_2680 = 2680;
  
  public static final int CLUE_SCROLL_EASY_2681 = 2681;
  
  public static final int CLUE_SCROLL_EASY_2682 = 2682;
  
  public static final int CLUE_SCROLL_EASY_2683 = 2683;
  
  public static final int CLUE_SCROLL_EASY_2684 = 2684;
  
  public static final int CLUE_SCROLL_EASY_2685 = 2685;
  
  public static final int CLUE_SCROLL_EASY_2686 = 2686;
  
  public static final int CLUE_SCROLL_EASY_2687 = 2687;
  
  public static final int CLUE_SCROLL_EASY_2688 = 2688;
  
  public static final int CLUE_SCROLL_EASY_2689 = 2689;
  
  public static final int CLUE_SCROLL_EASY_2690 = 2690;
  
  public static final int CLUE_SCROLL_EASY_2691 = 2691;
  
  public static final int CLUE_SCROLL_EASY_2692 = 2692;
  
  public static final int CLUE_SCROLL_EASY_2693 = 2693;
  
  public static final int CLUE_SCROLL_EASY_2694 = 2694;
  
  public static final int CLUE_SCROLL_EASY_2695 = 2695;
  
  public static final int CLUE_SCROLL_EASY_2696 = 2696;
  
  public static final int CLUE_SCROLL_EASY_2697 = 2697;
  
  public static final int CLUE_SCROLL_EASY_2698 = 2698;
  
  public static final int CLUE_SCROLL_EASY_2699 = 2699;
  
  public static final int CLUE_SCROLL_EASY_2700 = 2700;
  
  public static final int CLUE_SCROLL_EASY_2701 = 2701;
  
  public static final int CLUE_SCROLL_EASY_2702 = 2702;
  
  public static final int CLUE_SCROLL_EASY_2703 = 2703;
  
  public static final int CLUE_SCROLL_EASY_2704 = 2704;
  
  public static final int CLUE_SCROLL_EASY_2705 = 2705;
  
  public static final int CLUE_SCROLL_EASY_2706 = 2706;
  
  public static final int CLUE_SCROLL_EASY_2707 = 2707;
  
  public static final int CLUE_SCROLL_EASY_2708 = 2708;
  
  public static final int CLUE_SCROLL_EASY_2709 = 2709;
  
  public static final int CLUE_SCROLL_EASY_2710 = 2710;
  
  public static final int CLUE_SCROLL_EASY_2711 = 2711;
  
  public static final int CLUE_SCROLL_EASY_2712 = 2712;
  
  public static final int CLUE_SCROLL_EASY_2713 = 2713;
  
  public static final int CASKET_EASY = 2714;
  
  public static final int CASKET_EASY_2715 = 2715;
  
  public static final int CLUE_SCROLL_EASY_2716 = 2716;
  
  public static final int CASKET_EASY_2717 = 2717;
  
  public static final int CASKET_EASY_2718 = 2718;
  
  public static final int CLUE_SCROLL_EASY_2719 = 2719;
  
  public static final int CASKET_EASY_2720 = 2720;
  
  public static final int CASKET_EASY_2721 = 2721;
  
  public static final int CLUE_SCROLL_HARD = 2722;
  
  public static final int CLUE_SCROLL_HARD_2723 = 2723;
  
  public static final int CASKET_HARD = 2724;
  
  public static final int CLUE_SCROLL_HARD_2725 = 2725;
  
  public static final int CASKET_HARD_2726 = 2726;
  
  public static final int CLUE_SCROLL_HARD_2727 = 2727;
  
  public static final int CASKET_HARD_2728 = 2728;
  
  public static final int CLUE_SCROLL_HARD_2729 = 2729;
  
  public static final int CASKET_HARD_2730 = 2730;
  
  public static final int CLUE_SCROLL_HARD_2731 = 2731;
  
  public static final int CASKET_HARD_2732 = 2732;
  
  public static final int CLUE_SCROLL_HARD_2733 = 2733;
  
  public static final int CASKET_HARD_2734 = 2734;
  
  public static final int CLUE_SCROLL_HARD_2735 = 2735;
  
  public static final int CASKET_HARD_2736 = 2736;
  
  public static final int CLUE_SCROLL_HARD_2737 = 2737;
  
  public static final int CASKET_HARD_2738 = 2738;
  
  public static final int CLUE_SCROLL_HARD_2739 = 2739;
  
  public static final int CASKET_HARD_2740 = 2740;
  
  public static final int CLUE_SCROLL_HARD_2741 = 2741;
  
  public static final int CASKET_HARD_2742 = 2742;
  
  public static final int CLUE_SCROLL_HARD_2743 = 2743;
  
  public static final int CASKET_HARD_2744 = 2744;
  
  public static final int CLUE_SCROLL_HARD_2745 = 2745;
  
  public static final int CASKET_HARD_2746 = 2746;
  
  public static final int CLUE_SCROLL_HARD_2747 = 2747;
  
  public static final int CASKET_HARD_2748 = 2748;
  
  public static final int CLUE_SCROLL_HARD_2773 = 2773;
  
  public static final int CLUE_SCROLL_HARD_2774 = 2774;
  
  public static final int CASKET_HARD_2775 = 2775;
  
  public static final int CLUE_SCROLL_HARD_2776 = 2776;
  
  public static final int CASKET_HARD_2777 = 2777;
  
  public static final int CLUE_SCROLL_HARD_2778 = 2778;
  
  public static final int CASKET_HARD_2779 = 2779;
  
  public static final int CLUE_SCROLL_HARD_2780 = 2780;
  
  public static final int CASKET_HARD_2781 = 2781;
  
  public static final int CLUE_SCROLL_HARD_2782 = 2782;
  
  public static final int CLUE_SCROLL_HARD_2783 = 2783;
  
  public static final int CASKET_HARD_2784 = 2784;
  
  public static final int CLUE_SCROLL_HARD_2785 = 2785;
  
  public static final int CLUE_SCROLL_HARD_2786 = 2786;
  
  public static final int CASKET_HARD_2787 = 2787;
  
  public static final int CLUE_SCROLL_HARD_2788 = 2788;
  
  public static final int CASKET_HARD_2789 = 2789;
  
  public static final int CLUE_SCROLL_HARD_2790 = 2790;
  
  public static final int CASKET_HARD_2791 = 2791;
  
  public static final int CLUE_SCROLL_HARD_2792 = 2792;
  
  public static final int CLUE_SCROLL_HARD_2793 = 2793;
  
  public static final int CLUE_SCROLL_HARD_2794 = 2794;
  
  public static final int PUZZLE_BOX_HARD = 2795;
  
  public static final int CLUE_SCROLL_HARD_2796 = 2796;
  
  public static final int CLUE_SCROLL_HARD_2797 = 2797;
  
  public static final int PUZZLE_BOX_HARD_2798 = 2798;
  
  public static final int CLUE_SCROLL_HARD_2799 = 2799;
  
  public static final int PUZZLE_BOX_HARD_2800 = 2800;
  
  public static final int CLUE_SCROLL_MEDIUM = 2801;
  
  public static final int CASKET_MEDIUM = 2802;
  
  public static final int CLUE_SCROLL_MEDIUM_2803 = 2803;
  
  public static final int CASKET_MEDIUM_2804 = 2804;
  
  public static final int CLUE_SCROLL_MEDIUM_2805 = 2805;
  
  public static final int CASKET_MEDIUM_2806 = 2806;
  
  public static final int CLUE_SCROLL_MEDIUM_2807 = 2807;
  
  public static final int CASKET_MEDIUM_2808 = 2808;
  
  public static final int CLUE_SCROLL_MEDIUM_2809 = 2809;
  
  public static final int CASKET_MEDIUM_2810 = 2810;
  
  public static final int CLUE_SCROLL_MEDIUM_2811 = 2811;
  
  public static final int CASKET_MEDIUM_2812 = 2812;
  
  public static final int CLUE_SCROLL_MEDIUM_2813 = 2813;
  
  public static final int CASKET_MEDIUM_2814 = 2814;
  
  public static final int CLUE_SCROLL_MEDIUM_2815 = 2815;
  
  public static final int CASKET_MEDIUM_2816 = 2816;
  
  public static final int CLUE_SCROLL_MEDIUM_2817 = 2817;
  
  public static final int CASKET_MEDIUM_2818 = 2818;
  
  public static final int CLUE_SCROLL_MEDIUM_2819 = 2819;
  
  public static final int CASKET_MEDIUM_2820 = 2820;
  
  public static final int CLUE_SCROLL_MEDIUM_2821 = 2821;
  
  public static final int CASKET_MEDIUM_2822 = 2822;
  
  public static final int CLUE_SCROLL_MEDIUM_2823 = 2823;
  
  public static final int CASKET_MEDIUM_2824 = 2824;
  
  public static final int CLUE_SCROLL_MEDIUM_2825 = 2825;
  
  public static final int CASKET_MEDIUM_2826 = 2826;
  
  public static final int CLUE_SCROLL_MEDIUM_2827 = 2827;
  
  public static final int CASKET_MEDIUM_2828 = 2828;
  
  public static final int CLUE_SCROLL_MEDIUM_2829 = 2829;
  
  public static final int CASKET_MEDIUM_2830 = 2830;
  
  public static final int CLUE_SCROLL_MEDIUM_2831 = 2831;
  
  public static final int KEY_MEDIUM = 2832;
  
  public static final int CLUE_SCROLL_MEDIUM_2833 = 2833;
  
  public static final int KEY_MEDIUM_2834 = 2834;
  
  public static final int CLUE_SCROLL_MEDIUM_2835 = 2835;
  
  public static final int KEY_MEDIUM_2836 = 2836;
  
  public static final int CLUE_SCROLL_MEDIUM_2837 = 2837;
  
  public static final int KEY_MEDIUM_2838 = 2838;
  
  public static final int CLUE_SCROLL_MEDIUM_2839 = 2839;
  
  public static final int KEY_MEDIUM_2840 = 2840;
  
  public static final int CLUE_SCROLL_MEDIUM_2841 = 2841;
  
  public static final int CHALLENGE_SCROLL_MEDIUM = 2842;
  
  public static final int CLUE_SCROLL_MEDIUM_2843 = 2843;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_2844 = 2844;
  
  public static final int CLUE_SCROLL_MEDIUM_2845 = 2845;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_2846 = 2846;
  
  public static final int CLUE_SCROLL_MEDIUM_2847 = 2847;
  
  public static final int CLUE_SCROLL_MEDIUM_2848 = 2848;
  
  public static final int CLUE_SCROLL_MEDIUM_2849 = 2849;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_2850 = 2850;
  
  public static final int CLUE_SCROLL_MEDIUM_2851 = 2851;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_2852 = 2852;
  
  public static final int CLUE_SCROLL_MEDIUM_2853 = 2853;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_2854 = 2854;
  
  public static final int CLUE_SCROLL_MEDIUM_2855 = 2855;
  
  public static final int CLUE_SCROLL_MEDIUM_2856 = 2856;
  
  public static final int CLUE_SCROLL_MEDIUM_2857 = 2857;
  
  public static final int CLUE_SCROLL_MEDIUM_2858 = 2858;
  
  public static final int WOLF_BONES = 2859;
  
  public static final int WOLFBONE_ARROWTIPS = 2861;
  
  public static final int ACHEY_TREE_LOGS = 2862;
  
  public static final int OGRE_ARROW_SHAFT = 2864;
  
  public static final int FLIGHTED_OGRE_ARROW = 2865;
  
  public static final int OGRE_ARROW = 2866;
  
  public static final int OGRE_BELLOWS = 2871;
  
  public static final int OGRE_BELLOWS_3 = 2872;
  
  public static final int OGRE_BELLOWS_2 = 2873;
  
  public static final int OGRE_BELLOWS_1 = 2874;
  
  public static final int BLOATED_TOAD = 2875;
  
  public static final int RAW_CHOMPY = 2876;
  
  public static final int COOKED_CHOMPY = 2878;
  
  public static final int RUINED_CHOMPY = 2880;
  
  public static final int SEASONED_CHOMPY = 2882;
  
  public static final int OGRE_BOW = 2883;
  
  public static final int BATTERED_BOOK = 2886;
  
  public static final int BATTERED_KEY = 2887;
  
  public static final int A_STONE_BOWL = 2888;
  
  public static final int A_STONE_BOWL_2889 = 2889;
  
  public static final int ELEMENTAL_SHIELD = 2890;
  
  public static final int ELEMENTAL_ORE = 2892;
  
  public static final int ELEMENTAL_METAL = 2893;
  
  public static final int GREY_BOOTS = 2894;
  
  public static final int GREY_ROBE_TOP = 2896;
  
  public static final int GREY_ROBE_BOTTOMS = 2898;
  
  public static final int GREY_HAT = 2900;
  
  public static final int GREY_GLOVES = 2902;
  
  public static final int RED_BOOTS = 2904;
  
  public static final int RED_ROBE_TOP = 2906;
  
  public static final int RED_ROBE_BOTTOMS = 2908;
  
  public static final int RED_HAT = 2910;
  
  public static final int RED_GLOVES = 2912;
  
  public static final int YELLOW_BOOTS = 2914;
  
  public static final int YELLOW_ROBE_TOP = 2916;
  
  public static final int YELLOW_ROBE_BOTTOMS = 2918;
  
  public static final int YELLOW_HAT = 2920;
  
  public static final int YELLOW_GLOVES = 2922;
  
  public static final int TEAL_BOOTS = 2924;
  
  public static final int TEAL_ROBE_TOP = 2926;
  
  public static final int TEAL_ROBE_BOTTOMS = 2928;
  
  public static final int TEAL_HAT = 2930;
  
  public static final int TEAL_GLOVES = 2932;
  
  public static final int PURPLE_BOOTS = 2934;
  
  public static final int PURPLE_ROBE_TOP = 2936;
  
  public static final int PURPLE_ROBE_BOTTOMS = 2938;
  
  public static final int PURPLE_HAT = 2940;
  
  public static final int PURPLE_GLOVES = 2942;
  
  public static final int GOLDEN_KEY = 2944;
  
  public static final int IRON_KEY = 2945;
  
  public static final int GOLDEN_TINDERBOX = 2946;
  
  public static final int GOLDEN_CANDLE = 2947;
  
  public static final int GOLDEN_POT = 2948;
  
  public static final int GOLDEN_HAMMER = 2949;
  
  public static final int GOLDEN_FEATHER = 2950;
  
  public static final int GOLDEN_NEEDLE = 2951;
  
  public static final int WOLFBANE = 2952;
  
  public static final int MURKY_WATER = 2953;
  
  public static final int BLESSED_WATER = 2954;
  
  public static final int MOONLIGHT_MEAD = 2955;
  
  public static final int DRUID_POUCH = 2957;
  
  public static final int DRUID_POUCH_2958 = 2958;
  
  public static final int ROTTEN_FOOD = 2959;
  
  public static final int SILVER_SICKLE = 2961;
  
  public static final int SILVER_SICKLE_B = 2963;
  
  public static final int WASHING_BOWL = 2964;
  
  public static final int MIRROR = 2966;
  
  public static final int JOURNAL = 2967;
  
  public static final int DRUIDIC_SPELL = 2968;
  
  public static final int A_USED_SPELL = 2969;
  
  public static final int MORT_MYRE_FUNGUS = 2970;
  
  public static final int MORT_MYRE_STEM = 2972;
  
  public static final int MORT_MYRE_PEAR = 2974;
  
  public static final int SICKLE_MOULD = 2976;
  
  public static final int CHOMPY_BIRD_HAT = 2978;
  
  public static final int CHOMPY_BIRD_HAT_2979 = 2979;
  
  public static final int CHOMPY_BIRD_HAT_2980 = 2980;
  
  public static final int CHOMPY_BIRD_HAT_2981 = 2981;
  
  public static final int CHOMPY_BIRD_HAT_2982 = 2982;
  
  public static final int CHOMPY_BIRD_HAT_2983 = 2983;
  
  public static final int CHOMPY_BIRD_HAT_2984 = 2984;
  
  public static final int CHOMPY_BIRD_HAT_2985 = 2985;
  
  public static final int CHOMPY_BIRD_HAT_2986 = 2986;
  
  public static final int CHOMPY_BIRD_HAT_2987 = 2987;
  
  public static final int CHOMPY_BIRD_HAT_2988 = 2988;
  
  public static final int CHOMPY_BIRD_HAT_2989 = 2989;
  
  public static final int CHOMPY_BIRD_HAT_2990 = 2990;
  
  public static final int CHOMPY_BIRD_HAT_2991 = 2991;
  
  public static final int CHOMPY_BIRD_HAT_2992 = 2992;
  
  public static final int CHOMPY_BIRD_HAT_2993 = 2993;
  
  public static final int CHOMPY_BIRD_HAT_2994 = 2994;
  
  public static final int CHOMPY_BIRD_HAT_2995 = 2995;
  
  public static final int AGILITY_ARENA_TICKET = 2996;
  
  public static final int PIRATES_HOOK = 2997;
  
  public static final int TOADFLAX = 2998;
  
  public static final int SNAPDRAGON = 3000;
  
  public static final int TOADFLAX_POTION_UNF = 3002;
  
  public static final int SNAPDRAGON_POTION_UNF = 3004;
  
  public static final int FIREWORK = 3006;
  
  public static final int ENERGY_POTION4 = 3008;
  
  public static final int ENERGY_POTION3 = 3010;
  
  public static final int ENERGY_POTION2 = 3012;
  
  public static final int ENERGY_POTION1 = 3014;
  
  public static final int SUPER_ENERGY4 = 3016;
  
  public static final int SUPER_ENERGY3 = 3018;
  
  public static final int SUPER_ENERGY2 = 3020;
  
  public static final int SUPER_ENERGY1 = 3022;
  
  public static final int SUPER_RESTORE4 = 3024;
  
  public static final int SUPER_RESTORE3 = 3026;
  
  public static final int SUPER_RESTORE2 = 3028;
  
  public static final int SUPER_RESTORE1 = 3030;
  
  public static final int AGILITY_POTION4 = 3032;
  
  public static final int AGILITY_POTION3 = 3034;
  
  public static final int AGILITY_POTION2 = 3036;
  
  public static final int AGILITY_POTION1 = 3038;
  
  public static final int MAGIC_POTION4 = 3040;
  
  public static final int MAGIC_POTION3 = 3042;
  
  public static final int MAGIC_POTION2 = 3044;
  
  public static final int MAGIC_POTION1 = 3046;
  
  public static final int GRIMY_TOADFLAX = 3049;
  
  public static final int GRIMY_SNAPDRAGON = 3051;
  
  public static final int LAVA_BATTLESTAFF = 3053;
  
  public static final int MYSTIC_LAVA_STAFF = 3054;
  
  public static final int MIME_MASK = 3057;
  
  public static final int MIME_TOP = 3058;
  
  public static final int MIME_LEGS = 3059;
  
  public static final int MIME_GLOVES = 3060;
  
  public static final int MIME_BOOTS = 3061;
  
  public static final int STRANGE_BOX = 3062;
  
  public static final int BLACK_DART = 3093;
  
  public static final int BLACK_DARTP = 3094;
  
  public static final int BRONZE_CLAWS = 3095;
  
  public static final int IRON_CLAWS = 3096;
  
  public static final int STEEL_CLAWS = 3097;
  
  public static final int BLACK_CLAWS = 3098;
  
  public static final int MITHRIL_CLAWS = 3099;
  
  public static final int ADAMANT_CLAWS = 3100;
  
  public static final int RUNE_CLAWS = 3101;
  
  public static final int COMBINATION = 3102;
  
  public static final int IOU = 3103;
  
  public static final int SECRET_WAY_MAP = 3104;
  
  public static final int CLIMBING_BOOTS = 3105;
  
  public static final int SPIKED_BOOTS = 3107;
  
  public static final int STONE_BALL = 3109;
  
  public static final int STONE_BALL_3110 = 3110;
  
  public static final int STONE_BALL_3111 = 3111;
  
  public static final int STONE_BALL_3112 = 3112;
  
  public static final int STONE_BALL_3113 = 3113;
  
  public static final int CERTIFICATE_3114 = 3114;
  
  public static final int GRANITE_SHIELD = 3122;
  
  public static final int SHAIKAHAN_BONES = 3123;
  
  public static final int JOGRE_BONES = 3125;
  
  public static final int BURNT_JOGRE_BONES = 3127;
  
  public static final int PASTY_JOGRE_BONES = 3128;
  
  public static final int PASTY_JOGRE_BONES_3129 = 3129;
  
  public static final int MARINATED_J_BONES = 3130;
  
  public static final int PASTY_JOGRE_BONES_3131 = 3131;
  
  public static final int PASTY_JOGRE_BONES_3132 = 3132;
  
  public static final int MARINATED_J_BONES_3133 = 3133;
  
  public static final int PRISON_KEY = 3135;
  
  public static final int CELL_KEY_1 = 3136;
  
  public static final int CELL_KEY_2 = 3137;
  
  public static final int POTATO_CACTUS = 3138;
  
  public static final int DRAGON_CHAINBODY_3140 = 3140;
  
  public static final int RAW_KARAMBWAN = 3142;
  
  public static final int COOKED_KARAMBWAN = 3144;
  
  public static final int POISON_KARAMBWAN = 3146;
  
  public static final int COOKED_KARAMBWAN_3147 = 3147;
  
  public static final int BURNT_KARAMBWAN = 3148;
  
  public static final int RAW_KARAMBWANJI = 3150;
  
  public static final int KARAMBWAN_PASTE = 3152;
  
  public static final int KARAMBWAN_PASTE_3153 = 3153;
  
  public static final int KARAMBWAN_PASTE_3154 = 3154;
  
  public static final int KARAMBWANJI_PASTE = 3155;
  
  public static final int KARAMBWANJI_PASTE_3156 = 3156;
  
  public static final int KARAMBWAN_VESSEL = 3157;
  
  public static final int KARAMBWAN_VESSEL_3159 = 3159;
  
  public static final int CRAFTING_MANUAL = 3161;
  
  public static final int SLICED_BANANA = 3162;
  
  public static final int KARAMJAN_RUM_3164 = 3164;
  
  public static final int KARAMJAN_RUM_3165 = 3165;
  
  public static final int MONKEY_CORPSE = 3166;
  
  public static final int MONKEY_SKIN = 3167;
  
  public static final int SEAWEED_SANDWICH = 3168;
  
  public static final int STUFFED_MONKEY = 3169;
  
  public static final int BRONZE_SPEARKP = 3170;
  
  public static final int IRON_SPEARKP = 3171;
  
  public static final int STEEL_SPEARKP = 3172;
  
  public static final int MITHRIL_SPEARKP = 3173;
  
  public static final int ADAMANT_SPEARKP = 3174;
  
  public static final int RUNE_SPEARKP = 3175;
  
  public static final int DRAGON_SPEARKP = 3176;
  
  public static final int LEFTHANDED_BANANA = 3177;
  
  public static final int SMALL_NINJA_MONKEY_BONES = 3179;
  
  public static final int MEDIUM_NINJA_MONKEY_BONES = 3180;
  
  public static final int GORILLA_BONES = 3181;
  
  public static final int BEARDED_GORILLA_BONES = 3182;
  
  public static final int MONKEY_BONES = 3183;
  
  public static final int SMALL_ZOMBIE_MONKEY_BONES = 3185;
  
  public static final int LARGE_ZOMBIE_MONKEY_BONES = 3186;
  
  public static final int BONES_3187 = 3187;
  
  public static final int CLEANING_CLOTH = 3188;
  
  public static final int BRONZE_HALBERD = 3190;
  
  public static final int IRON_HALBERD = 3192;
  
  public static final int STEEL_HALBERD = 3194;
  
  public static final int BLACK_HALBERD = 3196;
  
  public static final int MITHRIL_HALBERD = 3198;
  
  public static final int ADAMANT_HALBERD = 3200;
  
  public static final int RUNE_HALBERD = 3202;
  
  public static final int DRAGON_HALBERD = 3204;
  
  public static final int KINGS_MESSAGE = 3206;
  
  public static final int IORWERTHS_MESSAGE = 3207;
  
  public static final int CRYSTAL_PENDANT = 3208;
  
  public static final int SULPHUR = 3209;
  
  public static final int LIMESTONE = 3211;
  
  public static final int QUICKLIME = 3213;
  
  public static final int POT_OF_QUICKLIME = 3214;
  
  public static final int GROUND_SULPHUR = 3215;
  
  public static final int BARREL_3216 = 3216;
  
  public static final int BARREL_BOMB = 3218;
  
  public static final int BARREL_BOMB_3219 = 3219;
  
  public static final int BARREL_OF_COAL_TAR = 3220;
  
  public static final int BARREL_OF_NAPHTHA = 3221;
  
  public static final int NAPHTHA_MIX = 3222;
  
  public static final int NAPHTHA_MIX_3223 = 3223;
  
  public static final int STRIP_OF_CLOTH = 3224;
  
  public static final int RAW_RABBIT = 3226;
  
  public static final int COOKED_RABBIT = 3228;
  
  public static final int BIG_BOOK_OF_BANGS = 3230;
  
  public static final int SYMBOL = 3231;
  
  public static final int SYMBOL_3233 = 3233;
  
  public static final int SYMBOL_3235 = 3235;
  
  public static final int SYMBOL_3237 = 3237;
  
  public static final int BARK = 3239;
  
  public static final int MAN = 3241;
  
  public static final int FARMER = 3243;
  
  public static final int WARRIOR_WOMAN = 3245;
  
  public static final int ROGUE = 3247;
  
  public static final int GUARD = 3249;
  
  public static final int KNIGHT = 3251;
  
  public static final int WATCHMAN = 3253;
  
  public static final int PALADIN = 3255;
  
  public static final int GNOME = 3257;
  
  public static final int HERO = 3259;
  
  public static final int GOUTWEED = 3261;
  
  public static final int TROLL_THISTLE = 3262;
  
  public static final int DRIED_THISTLE = 3263;
  
  public static final int GROUND_THISTLE = 3264;
  
  public static final int TROLL_POTION = 3265;
  
  public static final int DRUNK_PARROT = 3266;
  
  public static final int DIRTY_ROBE = 3267;
  
  public static final int FAKE_MAN = 3268;
  
  public static final int STOREROOM_KEY = 3269;
  
  public static final int ALCOCHUNKS = 3270;
  
  public static final int COMPOST_BIN = 3271;
  
  public static final int CAVE_KRAKEN = 3272;
  
  public static final int VAMPYRE_DUST = 3325;
  
  public static final int MYRE_SNELM = 3327;
  
  public static final int BLOODNTAR_SNELM = 3329;
  
  public static final int OCHRE_SNELM = 3331;
  
  public static final int BRUISE_BLUE_SNELM = 3333;
  
  public static final int BROKEN_BARK_SNELM = 3335;
  
  public static final int POINTED_MYRE_SNELM = 3337;
  
  public static final int POINTED_BLOODNTAR_SNELM = 3339;
  
  public static final int POINTED_OCHRE_SNELM = 3341;
  
  public static final int POINTED_BRUISE_BLUE_SNELM = 3343;
  
  public static final int BLAMISH_MYRE_SHELL = 3345;
  
  public static final int BLAMISH_RED_SHELL = 3347;
  
  public static final int BLAMISH_OCHRE_SHELL = 3349;
  
  public static final int BLAMISH_BLUE_SHELL = 3351;
  
  public static final int BLAMISH_BARK_SHELL = 3353;
  
  public static final int BLAMISH_MYRE_SHELL_3355 = 3355;
  
  public static final int BLAMISH_RED_SHELL_3357 = 3357;
  
  public static final int BLAMISH_OCHRE_SHELL_3359 = 3359;
  
  public static final int BLAMISH_BLUE_SHELL_3361 = 3361;
  
  public static final int THIN_SNAIL = 3363;
  
  public static final int LEAN_SNAIL = 3365;
  
  public static final int FAT_SNAIL = 3367;
  
  public static final int THIN_SNAIL_MEAT = 3369;
  
  public static final int LEAN_SNAIL_MEAT = 3371;
  
  public static final int FAT_SNAIL_MEAT = 3373;
  
  public static final int BURNT_SNAIL = 3375;
  
  public static final int SAMPLE_BOTTLE = 3377;
  
  public static final int RAW_SLIMY_EEL = 3379;
  
  public static final int COOKED_SLIMY_EEL = 3381;
  
  public static final int BURNT_EEL = 3383;
  
  public static final int SPLITBARK_HELM = 3385;
  
  public static final int SPLITBARK_BODY = 3387;
  
  public static final int SPLITBARK_LEGS = 3389;
  
  public static final int SPLITBARK_GAUNTLETS = 3391;
  
  public static final int SPLITBARK_BOOTS = 3393;
  
  public static final int DIARY_3395 = 3395;
  
  public static final int LOAR_REMAINS = 3396;
  
  public static final int PHRIN_REMAINS = 3398;
  
  public static final int RIYL_REMAINS = 3400;
  
  public static final int ASYN_REMAINS = 3402;
  
  public static final int FIYR_REMAINS = 3404;
  
  public static final int UNFINISHED_POTION = 3406;
  
  public static final int SERUM_207_4 = 3408;
  
  public static final int SERUM_207_3 = 3410;
  
  public static final int SERUM_207_2 = 3412;
  
  public static final int SERUM_207_1 = 3414;
  
  public static final int SERUM_208_4 = 3416;
  
  public static final int SERUM_208_3 = 3417;
  
  public static final int SERUM_208_2 = 3418;
  
  public static final int SERUM_208_1 = 3419;
  
  public static final int LIMESTONE_BRICK = 3420;
  
  public static final int OLIVE_OIL4 = 3422;
  
  public static final int OLIVE_OIL3 = 3424;
  
  public static final int OLIVE_OIL2 = 3426;
  
  public static final int OLIVE_OIL1 = 3428;
  
  public static final int SACRED_OIL4 = 3430;
  
  public static final int SACRED_OIL3 = 3432;
  
  public static final int SACRED_OIL2 = 3434;
  
  public static final int SACRED_OIL1 = 3436;
  
  public static final int PYRE_LOGS = 3438;
  
  public static final int OAK_PYRE_LOGS = 3440;
  
  public static final int WILLOW_PYRE_LOGS = 3442;
  
  public static final int MAPLE_PYRE_LOGS = 3444;
  
  public static final int YEW_PYRE_LOGS = 3446;
  
  public static final int MAGIC_PYRE_LOGS = 3448;
  
  public static final int BRONZE_KEY_RED = 3450;
  
  public static final int BRONZE_KEY_BROWN = 3451;
  
  public static final int BRONZE_KEY_CRIMSON = 3452;
  
  public static final int BRONZE_KEY_BLACK = 3453;
  
  public static final int BRONZE_KEY_PURPLE = 3454;
  
  public static final int STEEL_KEY_RED = 3455;
  
  public static final int STEEL_KEY_BROWN = 3456;
  
  public static final int STEEL_KEY_CRIMSON = 3457;
  
  public static final int STEEL_KEY_BLACK = 3458;
  
  public static final int STEEL_KEY_PURPLE = 3459;
  
  public static final int BLACK_KEY_RED = 3460;
  
  public static final int BLACK_KEY_BROWN = 3461;
  
  public static final int BLACK_KEY_CRIMSON = 3462;
  
  public static final int BLACK_KEY_BLACK = 3463;
  
  public static final int BLACK_KEY_PURPLE = 3464;
  
  public static final int SILVER_KEY_RED = 3465;
  
  public static final int SILVER_KEY_BROWN = 3466;
  
  public static final int SILVER_KEY_CRIMSON = 3467;
  
  public static final int SILVER_KEY_BLACK = 3468;
  
  public static final int SILVER_KEY_PURPLE = 3469;
  
  public static final int FINE_CLOTH = 3470;
  
  public static final int BLACK_PLATESKIRT_T = 3472;
  
  public static final int BLACK_PLATESKIRT_G = 3473;
  
  public static final int ADAMANT_PLATESKIRT_T = 3474;
  
  public static final int ADAMANT_PLATESKIRT_G = 3475;
  
  public static final int RUNE_PLATESKIRT_G = 3476;
  
  public static final int RUNE_PLATESKIRT_T = 3477;
  
  public static final int ZAMORAK_PLATESKIRT = 3478;
  
  public static final int SARADOMIN_PLATESKIRT = 3479;
  
  public static final int GUTHIX_PLATESKIRT = 3480;
  
  public static final int GILDED_PLATEBODY = 3481;
  
  public static final int GILDED_PLATELEGS = 3483;
  
  public static final int GILDED_PLATESKIRT = 3485;
  
  public static final int GILDED_FULL_HELM = 3486;
  
  public static final int GILDED_KITESHIELD = 3488;
  
  public static final int CLUE_SCROLL_EASY_3490 = 3490;
  
  public static final int CLUE_SCROLL_EASY_3491 = 3491;
  
  public static final int CLUE_SCROLL_EASY_3492 = 3492;
  
  public static final int CLUE_SCROLL_EASY_3493 = 3493;
  
  public static final int CLUE_SCROLL_EASY_3494 = 3494;
  
  public static final int CLUE_SCROLL_EASY_3495 = 3495;
  
  public static final int CLUE_SCROLL_EASY_3496 = 3496;
  
  public static final int CLUE_SCROLL_EASY_3497 = 3497;
  
  public static final int CLUE_SCROLL_EASY_3498 = 3498;
  
  public static final int CLUE_SCROLL_EASY_3499 = 3499;
  
  public static final int CLUE_SCROLL_EASY_3500 = 3500;
  
  public static final int CLUE_SCROLL_EASY_3501 = 3501;
  
  public static final int CLUE_SCROLL_EASY_3502 = 3502;
  
  public static final int CLUE_SCROLL_EASY_3503 = 3503;
  
  public static final int CLUE_SCROLL_EASY_3504 = 3504;
  
  public static final int CLUE_SCROLL_EASY_3505 = 3505;
  
  public static final int CLUE_SCROLL_EASY_3506 = 3506;
  
  public static final int CLUE_SCROLL_EASY_3507 = 3507;
  
  public static final int CLUE_SCROLL_EASY_3508 = 3508;
  
  public static final int CLUE_SCROLL_EASY_3509 = 3509;
  
  public static final int CLUE_SCROLL_EASY_3510 = 3510;
  
  public static final int CASKET_EASY_3511 = 3511;
  
  public static final int CLUE_SCROLL_EASY_3512 = 3512;
  
  public static final int CLUE_SCROLL_EASY_3513 = 3513;
  
  public static final int CLUE_SCROLL_EASY_3514 = 3514;
  
  public static final int CLUE_SCROLL_EASY_3515 = 3515;
  
  public static final int CLUE_SCROLL_EASY_3516 = 3516;
  
  public static final int CASKET_EASY_3517 = 3517;
  
  public static final int CLUE_SCROLL_EASY_3518 = 3518;
  
  public static final int CASKET_EASY_3519 = 3519;
  
  public static final int CLUE_SCROLL_HARD_3520 = 3520;
  
  public static final int CASKET_HARD_3521 = 3521;
  
  public static final int CLUE_SCROLL_HARD_3522 = 3522;
  
  public static final int CASKET_HARD_3523 = 3523;
  
  public static final int CLUE_SCROLL_HARD_3524 = 3524;
  
  public static final int CLUE_SCROLL_HARD_3525 = 3525;
  
  public static final int CLUE_SCROLL_HARD_3526 = 3526;
  
  public static final int CASKET_HARD_3527 = 3527;
  
  public static final int CLUE_SCROLL_HARD_3528 = 3528;
  
  public static final int CASKET_HARD_3529 = 3529;
  
  public static final int CLUE_SCROLL_HARD_3530 = 3530;
  
  public static final int CASKET_HARD_3531 = 3531;
  
  public static final int CLUE_SCROLL_HARD_3532 = 3532;
  
  public static final int CASKET_HARD_3533 = 3533;
  
  public static final int CLUE_SCROLL_HARD_3534 = 3534;
  
  public static final int CASKET_HARD_3535 = 3535;
  
  public static final int CLUE_SCROLL_HARD_3536 = 3536;
  
  public static final int CASKET_HARD_3537 = 3537;
  
  public static final int CLUE_SCROLL_HARD_3538 = 3538;
  
  public static final int CASKET_HARD_3539 = 3539;
  
  public static final int CLUE_SCROLL_HARD_3540 = 3540;
  
  public static final int CASKET_HARD_3541 = 3541;
  
  public static final int CLUE_SCROLL_HARD_3542 = 3542;
  
  public static final int CASKET_HARD_3543 = 3543;
  
  public static final int CLUE_SCROLL_HARD_3544 = 3544;
  
  public static final int CASKET_HARD_3545 = 3545;
  
  public static final int CLUE_SCROLL_HARD_3546 = 3546;
  
  public static final int CASKET_HARD_3547 = 3547;
  
  public static final int CLUE_SCROLL_HARD_3548 = 3548;
  
  public static final int CASKET_HARD_3549 = 3549;
  
  public static final int CLUE_SCROLL_HARD_3550 = 3550;
  
  public static final int CASKET_HARD_3551 = 3551;
  
  public static final int CLUE_SCROLL_HARD_3552 = 3552;
  
  public static final int CASKET_HARD_3553 = 3553;
  
  public static final int CLUE_SCROLL_HARD_3554 = 3554;
  
  public static final int CASKET_HARD_3555 = 3555;
  
  public static final int CLUE_SCROLL_HARD_3556 = 3556;
  
  public static final int CASKET_HARD_3557 = 3557;
  
  public static final int CLUE_SCROLL_HARD_3558 = 3558;
  
  public static final int CASKET_HARD_3559 = 3559;
  
  public static final int CLUE_SCROLL_HARD_3560 = 3560;
  
  public static final int CASKET_HARD_3561 = 3561;
  
  public static final int CLUE_SCROLL_HARD_3562 = 3562;
  
  public static final int CASKET_HARD_3563 = 3563;
  
  public static final int CLUE_SCROLL_HARD_3564 = 3564;
  
  public static final int PUZZLE_BOX_HARD_3565 = 3565;
  
  public static final int CLUE_SCROLL_HARD_3566 = 3566;
  
  public static final int PUZZLE_BOX_HARD_3567 = 3567;
  
  public static final int CLUE_SCROLL_HARD_3568 = 3568;
  
  public static final int PUZZLE_BOX_HARD_3569 = 3569;
  
  public static final int CLUE_SCROLL_HARD_3570 = 3570;
  
  public static final int PUZZLE_BOX_HARD_3571 = 3571;
  
  public static final int CLUE_SCROLL_HARD_3572 = 3572;
  
  public static final int CLUE_SCROLL_HARD_3573 = 3573;
  
  public static final int CLUE_SCROLL_HARD_3574 = 3574;
  
  public static final int CLUE_SCROLL_HARD_3575 = 3575;
  
  public static final int PUZZLE_BOX_HARD_3576 = 3576;
  
  public static final int CLUE_SCROLL_HARD_3577 = 3577;
  
  public static final int PUZZLE_BOX_HARD_3578 = 3578;
  
  public static final int CLUE_SCROLL_HARD_3579 = 3579;
  
  public static final int CLUE_SCROLL_HARD_3580 = 3580;
  
  public static final int CASKET_HARD_3581 = 3581;
  
  public static final int CLUE_SCROLL_MEDIUM_3582 = 3582;
  
  public static final int CASKET_MEDIUM_3583 = 3583;
  
  public static final int CLUE_SCROLL_MEDIUM_3584 = 3584;
  
  public static final int CASKET_MEDIUM_3585 = 3585;
  
  public static final int CLUE_SCROLL_MEDIUM_3586 = 3586;
  
  public static final int CASKET_MEDIUM_3587 = 3587;
  
  public static final int CLUE_SCROLL_MEDIUM_3588 = 3588;
  
  public static final int CASKET_MEDIUM_3589 = 3589;
  
  public static final int CLUE_SCROLL_MEDIUM_3590 = 3590;
  
  public static final int CASKET_MEDIUM_3591 = 3591;
  
  public static final int CLUE_SCROLL_MEDIUM_3592 = 3592;
  
  public static final int CASKET_MEDIUM_3593 = 3593;
  
  public static final int CLUE_SCROLL_MEDIUM_3594 = 3594;
  
  public static final int CASKET_MEDIUM_3595 = 3595;
  
  public static final int CLUE_SCROLL_MEDIUM_3596 = 3596;
  
  public static final int CASKET_MEDIUM_3597 = 3597;
  
  public static final int CLUE_SCROLL_MEDIUM_3598 = 3598;
  
  public static final int CLUE_SCROLL_MEDIUM_3599 = 3599;
  
  public static final int CASKET_MEDIUM_3600 = 3600;
  
  public static final int CLUE_SCROLL_MEDIUM_3601 = 3601;
  
  public static final int CLUE_SCROLL_MEDIUM_3602 = 3602;
  
  public static final int CASKET_MEDIUM_3603 = 3603;
  
  public static final int CLUE_SCROLL_MEDIUM_3604 = 3604;
  
  public static final int CLUE_SCROLL_MEDIUM_3605 = 3605;
  
  public static final int KEY_MEDIUM_3606 = 3606;
  
  public static final int CLUE_SCROLL_MEDIUM_3607 = 3607;
  
  public static final int KEY_MEDIUM_3608 = 3608;
  
  public static final int CLUE_SCROLL_MEDIUM_3609 = 3609;
  
  public static final int CLUE_SCROLL_MEDIUM_3610 = 3610;
  
  public static final int CLUE_SCROLL_MEDIUM_3611 = 3611;
  
  public static final int CLUE_SCROLL_MEDIUM_3612 = 3612;
  
  public static final int CLUE_SCROLL_MEDIUM_3613 = 3613;
  
  public static final int CLUE_SCROLL_MEDIUM_3614 = 3614;
  
  public static final int CLUE_SCROLL_MEDIUM_3615 = 3615;
  
  public static final int CLUE_SCROLL_MEDIUM_3616 = 3616;
  
  public static final int CLUE_SCROLL_MEDIUM_3617 = 3617;
  
  public static final int CLUE_SCROLL_MEDIUM_3618 = 3618;
  
  public static final int BOSS_HELPER_TOOL = 3667;
  
  public static final int FLAMTAER_HAMMER = 3678;
  
  public static final int SHOE = 3680;
  
  public static final int SHOE_3681 = 3681;
  
  public static final int SHOE_3682 = 3682;
  
  public static final int SHOE_3683 = 3683;
  
  public static final int SHOE_3684 = 3684;
  
  public static final int SHOE_3685 = 3685;
  
  public static final int FREMENNIK = 3686;
  
  public static final int UNSTRUNG_LYRE = 3688;
  
  public static final int LYRE = 3689;
  
  public static final int ENCHANTED_LYRE = 3690;
  
  public static final int ENCHANTED_LYRE1 = 3691;
  
  public static final int BRANCH = 3692;
  
  public static final int GOLDEN_FLEECE = 3693;
  
  public static final int GOLDEN_WOOL = 3694;
  
  public static final int PET_ROCK = 3695;
  
  public static final int HUNTERS_TALISMAN = 3696;
  
  public static final int HUNTERS_TALISMAN_3697 = 3697;
  
  public static final int EXOTIC_FLOWER = 3698;
  
  public static final int FREMENNIK_BALLAD = 3699;
  
  public static final int STURDY_BOOTS = 3700;
  
  public static final int TRACKING_MAP = 3701;
  
  public static final int CUSTOM_BOW_STRING = 3702;
  
  public static final int UNUSUAL_FISH = 3703;
  
  public static final int SEA_FISHING_MAP = 3704;
  
  public static final int WEATHER_FORECAST = 3705;
  
  public static final int CHAMPIONS_TOKEN = 3706;
  
  public static final int LEGENDARY_COCKTAIL = 3707;
  
  public static final int FISCAL_STATEMENT = 3708;
  
  public static final int PROMISSORY_NOTE = 3709;
  
  public static final int WARRIORS_CONTRACT = 3710;
  
  public static final int KEG_OF_BEER = 3711;
  
  public static final int LOW_ALCOHOL_KEG = 3712;
  
  public static final int STRANGE_OBJECT = 3713;
  
  public static final int LIT_STRANGE_OBJECT = 3714;
  
  public static final int RED_DISK = 3715;
  
  public static final int RED_DISK_3716 = 3716;
  
  public static final int MAGNET_3718 = 3718;
  
  public static final int BLUE_THREAD = 3719;
  
  public static final int SMALL_PICK = 3720;
  
  public static final int TOY_SHIP = 3721;
  
  public static final int FULL_BUCKET = 3722;
  
  public static final int _45THS_FULL_BUCKET = 3723;
  
  public static final int _35THS_FULL_BUCKET = 3724;
  
  public static final int _25THS_FULL_BUCKET = 3725;
  
  public static final int _15THS_FULL_BUCKET = 3726;
  
  public static final int EMPTY_BUCKET = 3727;
  
  public static final int FROZEN_BUCKET = 3728;
  
  public static final int FULL_JUG = 3729;
  
  public static final int _23RDS_FULL_JUG = 3730;
  
  public static final int _13RDS_FULL_JUG = 3731;
  
  public static final int EMPTY_JUG = 3732;
  
  public static final int FROZEN_JUG = 3733;
  
  public static final int VASE_3734 = 3734;
  
  public static final int VASE_OF_WATER = 3735;
  
  public static final int FROZEN_VASE = 3736;
  
  public static final int VASE_LID = 3737;
  
  public static final int SEALED_VASE = 3738;
  
  public static final int SEALED_VASE_3739 = 3739;
  
  public static final int SEALED_VASE_3740 = 3740;
  
  public static final int FROZEN_KEY = 3741;
  
  public static final int RED_HERRING = 3742;
  
  public static final int RED_DISK_3743 = 3743;
  
  public static final int WOODEN_DISK = 3744;
  
  public static final int SEERS_KEY = 3745;
  
  public static final int STICKY_RED_GOOP = 3746;
  
  public static final int FREMENNIK_HELM = 3748;
  
  public static final int ARCHER_HELM = 3749;
  
  public static final int BERSERKER_HELM = 3751;
  
  public static final int WARRIOR_HELM = 3753;
  
  public static final int FARSEER_HELM = 3755;
  
  public static final int FREMENNIK_BLADE = 3757;
  
  public static final int FREMENNIK_SHIELD = 3758;
  
  public static final int FREMENNIK_CYAN_CLOAK = 3759;
  
  public static final int FREMENNIK_BROWN_CLOAK = 3761;
  
  public static final int FREMENNIK_BLUE_CLOAK = 3763;
  
  public static final int FREMENNIK_GREEN_CLOAK = 3765;
  
  public static final int FREMENNIK_BROWN_SHIRT = 3767;
  
  public static final int FREMENNIK_GREY_SHIRT = 3769;
  
  public static final int FREMENNIK_BEIGE_SHIRT = 3771;
  
  public static final int FREMENNIK_RED_SHIRT = 3773;
  
  public static final int FREMENNIK_BLUE_SHIRT = 3775;
  
  public static final int FREMENNIK_RED_CLOAK = 3777;
  
  public static final int FREMENNIK_GREY_CLOAK = 3779;
  
  public static final int FREMENNIK_YELLOW_CLOAK = 3781;
  
  public static final int FREMENNIK_TEAL_CLOAK = 3783;
  
  public static final int FREMENNIK_PURPLE_CLOAK = 3785;
  
  public static final int FREMENNIK_PINK_CLOAK = 3787;
  
  public static final int FREMENNIK_BLACK_CLOAK = 3789;
  
  public static final int FREMENNIK_BOOTS = 3791;
  
  public static final int FREMENNIK_ROBE = 3793;
  
  public static final int FREMENNIK_SKIRT = 3795;
  
  public static final int FREMENNIK_HAT = 3797;
  
  public static final int FREMENNIK_GLOVES = 3799;
  
  public static final int KEG_OF_BEER_3801 = 3801;
  
  public static final int BEER_TANKARD = 3803;
  
  public static final int TANKARD = 3805;
  
  public static final int SARADOMIN_PAGE_1 = 3827;
  
  public static final int SARADOMIN_PAGE_2 = 3828;
  
  public static final int SARADOMIN_PAGE_3 = 3829;
  
  public static final int SARADOMIN_PAGE_4 = 3830;
  
  public static final int ZAMORAK_PAGE_1 = 3831;
  
  public static final int ZAMORAK_PAGE_2 = 3832;
  
  public static final int ZAMORAK_PAGE_3 = 3833;
  
  public static final int ZAMORAK_PAGE_4 = 3834;
  
  public static final int GUTHIX_PAGE_1 = 3835;
  
  public static final int GUTHIX_PAGE_2 = 3836;
  
  public static final int GUTHIX_PAGE_3 = 3837;
  
  public static final int GUTHIX_PAGE_4 = 3838;
  
  public static final int DAMAGED_BOOK = 3839;
  
  public static final int HOLY_BOOK = 3840;
  
  public static final int DAMAGED_BOOK_3841 = 3841;
  
  public static final int UNHOLY_BOOK = 3842;
  
  public static final int DAMAGED_BOOK_3843 = 3843;
  
  public static final int BOOK_OF_BALANCE = 3844;
  
  public static final int JOURNAL_3845 = 3845;
  
  public static final int DIARY_3846 = 3846;
  
  public static final int MANUAL = 3847;
  
  public static final int LIGHTHOUSE_KEY = 3848;
  
  public static final int RUSTY_CASKET = 3849;
  
  public static final int GAMES_NECKLACE8 = 3853;
  
  public static final int GAMES_NECKLACE7 = 3855;
  
  public static final int GAMES_NECKLACE6 = 3857;
  
  public static final int GAMES_NECKLACE5 = 3859;
  
  public static final int GAMES_NECKLACE4 = 3861;
  
  public static final int GAMES_NECKLACE3 = 3863;
  
  public static final int GAMES_NECKLACE2 = 3865;
  
  public static final int GAMES_NECKLACE1 = 3867;
  
  public static final int BOARD_GAME_PIECE = 3869;
  
  public static final int BOARD_GAME_PIECE_3870 = 3870;
  
  public static final int BOARD_GAME_PIECE_3871 = 3871;
  
  public static final int BOARD_GAME_PIECE_3872 = 3872;
  
  public static final int BOARD_GAME_PIECE_3873 = 3873;
  
  public static final int BOARD_GAME_PIECE_3874 = 3874;
  
  public static final int BOARD_GAME_PIECE_3875 = 3875;
  
  public static final int BOARD_GAME_PIECE_3876 = 3876;
  
  public static final int BOARD_GAME_PIECE_3877 = 3877;
  
  public static final int BOARD_GAME_PIECE_3878 = 3878;
  
  public static final int BOARD_GAME_PIECE_3879 = 3879;
  
  public static final int BOARD_GAME_PIECE_3880 = 3880;
  
  public static final int BOARD_GAME_PIECE_3881 = 3881;
  
  public static final int BOARD_GAME_PIECE_3882 = 3882;
  
  public static final int BOARD_GAME_PIECE_3883 = 3883;
  
  public static final int BOARD_GAME_PIECE_3884 = 3884;
  
  public static final int BOARD_GAME_PIECE_3885 = 3885;
  
  public static final int BOARD_GAME_PIECE_3886 = 3886;
  
  public static final int BOARD_GAME_PIECE_3887 = 3887;
  
  public static final int BOARD_GAME_PIECE_3888 = 3888;
  
  public static final int BOARD_GAME_PIECE_3889 = 3889;
  
  public static final int BOARD_GAME_PIECE_3890 = 3890;
  
  public static final int BOARD_GAME_PIECE_3891 = 3891;
  
  public static final int BOARD_GAME_PIECE_3892 = 3892;
  
  public static final int STOOL = 3893;
  
  public static final int AWFUL_ANTHEM = 3894;
  
  public static final int GOOD_ANTHEM = 3895;
  
  public static final int TREATY = 3896;
  
  public static final int GIANT_NIB = 3897;
  
  public static final int GIANT_PEN = 3898;
  
  public static final int IRON_SICKLE = 3899;
  
  public static final int GHRIMS_BOOK = 3901;
  
  public static final int WILDERNESS_SWORD = 3981;
  
  public static final int WESTERN_BANNER = 3983;
  
  public static final int HARDY_GOUT_TUBER = 4001;
  
  public static final int SPARE_CONTROLS = 4002;
  
  public static final int GNOME_ROYAL_SEAL = 4004;
  
  public static final int NARNODES_ORDERS = 4005;
  
  public static final int MONKEY_DENTURES = 4006;
  
  public static final int ENCHANTED_BAR = 4007;
  
  public static final int EYE_OF_GNOME = 4008;
  
  public static final int EYE_OF_GNOME_4009 = 4009;
  
  public static final int MONKEY_MAGIC = 4010;
  
  public static final int MONKEY_NUTS = 4012;
  
  public static final int MONKEY_BAR = 4014;
  
  public static final int BANANA_STEW = 4016;
  
  public static final int MONKEY_WRENCH = 4018;
  
  public static final int MAMULET_MOULD = 4020;
  
  public static final int MSPEAK_AMULET = 4021;
  
  public static final int MSPEAK_AMULET_4022 = 4022;
  
  public static final int MONKEY_TALISMAN = 4023;
  
  public static final int NINJA_MONKEY_GREEGREE = 4024;
  
  public static final int NINJA_MONKEY_GREEGREE_4025 = 4025;
  
  public static final int GORILLA_GREEGREE = 4026;
  
  public static final int BEARDED_GORILLA_GREEGREE = 4027;
  
  public static final int ANCIENT_GORILLA_GREEGREE = 4028;
  
  public static final int ZOMBIE_MONKEY_GREEGREE = 4029;
  
  public static final int ZOMBIE_MONKEY_GREEGREE_4030 = 4030;
  
  public static final int KARAMJAN_MONKEY_GREEGREE = 4031;
  
  public static final int MONKEY = 4033;
  
  public static final int MONKEY_SKULL = 4034;
  
  public static final int _10TH_SQUAD_SIGIL = 4035;
  
  public static final int SARADOMIN_BANNER = 4037;
  
  public static final int ZAMORAK_BANNER = 4039;
  
  public static final int HOODED_CLOAK = 4041;
  
  public static final int HOODED_CLOAK_4042 = 4042;
  
  public static final int ROCK_4043 = 4043;
  
  public static final int EXPLOSIVE_POTION = 4045;
  
  public static final int CLIMBING_ROPE = 4047;
  
  public static final int BANDAGES = 4049;
  
  public static final int TOOLKIT_4051 = 4051;
  
  public static final int BARRICADE = 4053;
  
  public static final int CASTLEWARS_MANUAL = 4055;
  
  public static final int CASTLE_WARS_TICKET = 4067;
  
  public static final int DECORATIVE_SWORD = 4068;
  
  public static final int DECORATIVE_ARMOUR = 4069;
  
  public static final int DECORATIVE_ARMOUR_4070 = 4070;
  
  public static final int DECORATIVE_HELM = 4071;
  
  public static final int DECORATIVE_SHIELD = 4072;
  
  public static final int DAMP_TINDERBOX = 4073;
  
  public static final int GLOWING_FUNGUS = 4075;
  
  public static final int CRYSTALMINE_KEY = 4077;
  
  public static final int ZEALOTS_KEY = 4078;
  
  public static final int YOYO = 4079;
  
  public static final int SALVE_AMULET = 4081;
  
  public static final int SALVE_SHARD = 4082;
  
  public static final int SLED = 4083;
  
  public static final int SLED_4084 = 4084;
  
  public static final int WAX = 4085;
  
  public static final int TROLLWEISS = 4086;
  
  public static final int DRAGON_PLATELEGS = 4087;
  
  public static final int MYSTIC_HAT = 4089;
  
  public static final int MYSTIC_ROBE_TOP = 4091;
  
  public static final int MYSTIC_ROBE_BOTTOM = 4093;
  
  public static final int MYSTIC_GLOVES = 4095;
  
  public static final int MYSTIC_BOOTS = 4097;
  
  public static final int MYSTIC_HAT_DARK = 4099;
  
  public static final int MYSTIC_ROBE_TOP_DARK = 4101;
  
  public static final int MYSTIC_ROBE_BOTTOM_DARK = 4103;
  
  public static final int MYSTIC_GLOVES_DARK = 4105;
  
  public static final int MYSTIC_BOOTS_DARK = 4107;
  
  public static final int MYSTIC_HAT_LIGHT = 4109;
  
  public static final int MYSTIC_ROBE_TOP_LIGHT = 4111;
  
  public static final int MYSTIC_ROBE_BOTTOM_LIGHT = 4113;
  
  public static final int MYSTIC_GLOVES_LIGHT = 4115;
  
  public static final int MYSTIC_BOOTS_LIGHT = 4117;
  
  public static final int BRONZE_BOOTS = 4119;
  
  public static final int IRON_BOOTS = 4121;
  
  public static final int STEEL_BOOTS = 4123;
  
  public static final int BLACK_BOOTS = 4125;
  
  public static final int MITHRIL_BOOTS = 4127;
  
  public static final int ADAMANT_BOOTS = 4129;
  
  public static final int RUNE_BOOTS = 4131;
  
  public static final int CRAWLING_HAND = 4133;
  
  public static final int CAVE_CRAWLER = 4134;
  
  public static final int BANSHEE = 4135;
  
  public static final int ROCKSLUG = 4136;
  
  public static final int COCKATRICE = 4137;
  
  public static final int PYREFIEND = 4138;
  
  public static final int BASILISK = 4139;
  
  public static final int INFERNAL_MAGE = 4140;
  
  public static final int BLOODVELD = 4141;
  
  public static final int JELLY = 4142;
  
  public static final int TUROTH = 4143;
  
  public static final int ABERRANT_SPECTRE = 4144;
  
  public static final int DUST_DEVIL = 4145;
  
  public static final int KURASK = 4146;
  
  public static final int GARGOYLE = 4147;
  
  public static final int NECHRYAEL = 4148;
  
  public static final int ABYSSAL_DEMON = 4149;
  
  public static final int BROAD_ARROWS = 4150;
  
  public static final int ABYSSAL_WHIP = 4151;
  
  public static final int GRANITE_MAUL = 4153;
  
  public static final int ENCHANTED_GEM = 4155;
  
  public static final int MIRROR_SHIELD = 4156;
  
  public static final int LEAFBLADED_SPEAR = 4158;
  
  public static final int LEAFBLADED_SPEAR_4159 = 4159;
  
  public static final int BROAD_ARROWS_4160 = 4160;
  
  public static final int BAG_OF_SALT = 4161;
  
  public static final int ROCK_HAMMER = 4162;
  
  public static final int FACEMASK = 4164;
  
  public static final int EARMUFFS = 4166;
  
  public static final int NOSE_PEG = 4168;
  
  public static final int SLAYERS_STAFF = 4170;
  
  public static final int ABYSSAL_WHIP_4178 = 4178;
  
  public static final int STICK = 4179;
  
  public static final int DRAGON_PLATELEGS_4180 = 4180;
  
  public static final int MOUTH_GRIP = 4181;
  
  public static final int GOUTWEED_4182 = 4182;
  
  public static final int STAR_AMULET = 4183;
  
  public static final int CAVERN_KEY = 4184;
  
  public static final int TOWER_KEY = 4185;
  
  public static final int SHED_KEY = 4186;
  
  public static final int MARBLE_AMULET = 4187;
  
  public static final int OBSIDIAN_AMULET = 4188;
  
  public static final int GARDEN_CANE = 4189;
  
  public static final int GARDEN_BRUSH = 4190;
  
  public static final int EXTENDED_BRUSH = 4191;
  
  public static final int EXTENDED_BRUSH_4192 = 4192;
  
  public static final int EXTENDED_BRUSH_4193 = 4193;
  
  public static final int TORSO = 4194;
  
  public static final int ARMS = 4195;
  
  public static final int LEGS = 4196;
  
  public static final int DECAPITATED_HEAD = 4197;
  
  public static final int DECAPITATED_HEAD_4198 = 4198;
  
  public static final int PICKLED_BRAIN = 4199;
  
  public static final int CONDUCTOR_MOULD = 4200;
  
  public static final int CONDUCTOR = 4201;
  
  public static final int RING_OF_CHAROS = 4202;
  
  public static final int JOURNAL_4203 = 4203;
  
  public static final int LETTER = 4204;
  
  public static final int CONSECRATION_SEED = 4205;
  
  public static final int CONSECRATION_SEED_4206 = 4206;
  
  public static final int CRYSTAL_WEAPON_SEED = 4207;
  
  public static final int CADARN_LINEAGE = 4209;
  
  public static final int ELF_CRYSTAL = 4211;
  
  public static final int NEW_CRYSTAL_BOW = 4212;
  
  public static final int NEW_CRYSTAL_BOW_4213 = 4213;
  
  public static final int CRYSTAL_BOW_FULL = 4214;
  
  public static final int CRYSTAL_BOW_910 = 4215;
  
  public static final int CRYSTAL_BOW_810 = 4216;
  
  public static final int CRYSTAL_BOW_710 = 4217;
  
  public static final int CRYSTAL_BOW_610 = 4218;
  
  public static final int CRYSTAL_BOW_510 = 4219;
  
  public static final int CRYSTAL_BOW_410 = 4220;
  
  public static final int CRYSTAL_BOW_310 = 4221;
  
  public static final int CRYSTAL_BOW_210 = 4222;
  
  public static final int CRYSTAL_BOW_110 = 4223;
  
  public static final int NEW_CRYSTAL_SHIELD = 4224;
  
  public static final int CRYSTAL_SHIELD_FULL = 4225;
  
  public static final int CRYSTAL_SHIELD_910 = 4226;
  
  public static final int CRYSTAL_SHIELD_810 = 4227;
  
  public static final int CRYSTAL_SHIELD_710 = 4228;
  
  public static final int CRYSTAL_SHIELD_610 = 4229;
  
  public static final int CRYSTAL_SHIELD_510 = 4230;
  
  public static final int CRYSTAL_SHIELD_410 = 4231;
  
  public static final int CRYSTAL_SHIELD_310 = 4232;
  
  public static final int CRYSTAL_SHIELD_210 = 4233;
  
  public static final int CRYSTAL_SHIELD_110 = 4234;
  
  public static final int NEW_CRYSTAL_SHIELD_4235 = 4235;
  
  public static final int SIGNED_OAK_BOW = 4236;
  
  public static final int NETTLEWATER = 4237;
  
  public static final int PUDDLE_OF_SLIME = 4238;
  
  public static final int NETTLE_TEA = 4239;
  
  public static final int NETTLE_TEA_4240 = 4240;
  
  public static final int NETTLES = 4241;
  
  public static final int CUP_OF_TEA_4242 = 4242;
  
  public static final int CUP_OF_TEA_4243 = 4243;
  
  public static final int PORCELAIN_CUP = 4244;
  
  public static final int CUP_OF_TEA_4245 = 4245;
  
  public static final int CUP_OF_TEA_4246 = 4246;
  
  public static final int MYSTICAL_ROBES = 4247;
  
  public static final int BOOK_OF_HARICANTO = 4248;
  
  public static final int TRANSLATION_MANUAL = 4249;
  
  public static final int GHOSTSPEAK_AMULET_4250 = 4250;
  
  public static final int ECTOPHIAL = 4251;
  
  public static final int ECTOPHIAL_4252 = 4252;
  
  public static final int MODEL_SHIP = 4253;
  
  public static final int MODEL_SHIP_4254 = 4254;
  
  public static final int BONEMEAL = 4255;
  
  public static final int BAT_BONEMEAL = 4256;
  
  public static final int BIG_BONEMEAL = 4257;
  
  public static final int BURNT_BONEMEAL = 4258;
  
  public static final int BURNT_JOGRE_BONEMEAL = 4259;
  
  public static final int BABY_DRAGON_BONEMEAL = 4260;
  
  public static final int DRAGON_BONEMEAL = 4261;
  
  public static final int WOLF_BONEMEAL = 4262;
  
  public static final int SMALL_NINJA_BONEMEAL = 4263;
  
  public static final int MEDIUM_NINJA_BONEMEAL = 4264;
  
  public static final int GORILLA_BONEMEAL = 4265;
  
  public static final int BEARDED_GORILLA_BONEMEAL = 4266;
  
  public static final int MONKEY_BONEMEAL = 4267;
  
  public static final int SMALL_ZOMBIE_MONKEY_BONEMEAL = 4268;
  
  public static final int LARGE_ZOMBIE_MONKEY_BONEMEAL = 4269;
  
  public static final int SKELETON_BONEMEAL = 4270;
  
  public static final int JOGRE_BONEMEAL = 4271;
  
  public static final int BONE_KEY_4272 = 4272;
  
  public static final int CHEST_KEY_4273 = 4273;
  
  public static final int MAP_SCRAP = 4274;
  
  public static final int MAP_SCRAP_4275 = 4275;
  
  public static final int MAP_SCRAP_4276 = 4276;
  
  public static final int TREASURE_MAP = 4277;
  
  public static final int ECTOTOKEN = 4278;
  
  public static final int PETITION_FORM = 4283;
  
  public static final int BEDSHEET = 4284;
  
  public static final int BEDSHEET_4285 = 4285;
  
  public static final int BUCKET_OF_SLIME = 4286;
  
  public static final int RAW_BEEF_4287 = 4287;
  
  public static final int RAW_CHICKEN_4289 = 4289;
  
  public static final int COOKED_CHICKEN_4291 = 4291;
  
  public static final int COOKED_MEAT_4293 = 4293;
  
  public static final int FEMALE_HAM = 4295;
  
  public static final int MALE_HAM = 4297;
  
  public static final int HAM_SHIRT = 4298;
  
  public static final int HAM_ROBE = 4300;
  
  public static final int HAM_HOOD = 4302;
  
  public static final int HAM_CLOAK = 4304;
  
  public static final int HAM_LOGO = 4306;
  
  public static final int HAM_GLOVES = 4308;
  
  public static final int HAM_BOOTS = 4310;
  
  public static final int CRYSTAL_SINGING_FOR_BEGINNERS = 4313;
  
  public static final int TEAM1_CAPE = 4315;
  
  public static final int TEAM2_CAPE = 4317;
  
  public static final int TEAM3_CAPE = 4319;
  
  public static final int TEAM4_CAPE = 4321;
  
  public static final int TEAM5_CAPE = 4323;
  
  public static final int TEAM6_CAPE = 4325;
  
  public static final int TEAM7_CAPE = 4327;
  
  public static final int TEAM8_CAPE = 4329;
  
  public static final int TEAM9_CAPE = 4331;
  
  public static final int TEAM10_CAPE = 4333;
  
  public static final int TEAM11_CAPE = 4335;
  
  public static final int TEAM12_CAPE = 4337;
  
  public static final int TEAM13_CAPE = 4339;
  
  public static final int TEAM14_CAPE = 4341;
  
  public static final int TEAM15_CAPE = 4343;
  
  public static final int TEAM16_CAPE = 4345;
  
  public static final int TEAM17_CAPE = 4347;
  
  public static final int TEAM18_CAPE = 4349;
  
  public static final int TEAM19_CAPE = 4351;
  
  public static final int TEAM20_CAPE = 4353;
  
  public static final int TEAM21_CAPE = 4355;
  
  public static final int TEAM22_CAPE = 4357;
  
  public static final int TEAM23_CAPE = 4359;
  
  public static final int TEAM24_CAPE = 4361;
  
  public static final int TEAM25_CAPE = 4363;
  
  public static final int TEAM26_CAPE = 4365;
  
  public static final int TEAM27_CAPE = 4367;
  
  public static final int TEAM28_CAPE = 4369;
  
  public static final int TEAM29_CAPE = 4371;
  
  public static final int TEAM30_CAPE = 4373;
  
  public static final int TEAM31_CAPE = 4375;
  
  public static final int TEAM32_CAPE = 4377;
  
  public static final int TEAM33_CAPE = 4379;
  
  public static final int TEAM34_CAPE = 4381;
  
  public static final int TEAM35_CAPE = 4383;
  
  public static final int TEAM36_CAPE = 4385;
  
  public static final int TEAM37_CAPE = 4387;
  
  public static final int TEAM38_CAPE = 4389;
  
  public static final int TEAM39_CAPE = 4391;
  
  public static final int TEAM40_CAPE = 4393;
  
  public static final int TEAM41_CAPE = 4395;
  
  public static final int TEAM42_CAPE = 4397;
  
  public static final int TEAM43_CAPE = 4399;
  
  public static final int TEAM44_CAPE = 4401;
  
  public static final int TEAM45_CAPE = 4403;
  
  public static final int TEAM46_CAPE = 4405;
  
  public static final int TEAM47_CAPE = 4407;
  
  public static final int TEAM48_CAPE = 4409;
  
  public static final int TEAM49_CAPE = 4411;
  
  public static final int TEAM50_CAPE = 4413;
  
  public static final int BLUNT_AXE = 4415;
  
  public static final int HERBAL_TINCTURE = 4416;
  
  public static final int GUTHIX_REST4 = 4417;
  
  public static final int GUTHIX_REST3 = 4419;
  
  public static final int GUTHIX_REST2 = 4421;
  
  public static final int GUTHIX_REST1 = 4423;
  
  public static final int STODGY_MATTRESS = 4425;
  
  public static final int COMFY_MATTRESS = 4426;
  
  public static final int IRON_OXIDE = 4427;
  
  public static final int ANIMATE_ROCK_SCROLL = 4428;
  
  public static final int BROKEN_VANE_PART = 4429;
  
  public static final int DIRECTIONALS = 4430;
  
  public static final int BROKEN_VANE_PART_4431 = 4431;
  
  public static final int ORNAMENT = 4432;
  
  public static final int BROKEN_VANE_PART_4433 = 4433;
  
  public static final int WEATHERVANE_PILLAR = 4434;
  
  public static final int WEATHER_REPORT = 4435;
  
  public static final int AIRTIGHT_POT = 4436;
  
  public static final int UNFIRED_POT_LID = 4438;
  
  public static final int POT_LID = 4440;
  
  public static final int BREATHING_SALTS = 4442;
  
  public static final int CHICKEN_CAGE = 4443;
  
  public static final int SHARPENED_AXE = 4444;
  
  public static final int RED_MAHOGANY_LOG = 4445;
  
  public static final int STEEL_KEY_RING = 4446;
  
  public static final int ANTIQUE_LAMP = 4447;
  
  public static final int BOWL_OF_HOT_WATER = 4456;
  
  public static final int CUP_OF_WATER = 4458;
  
  public static final int CUP_OF_HOT_WATER = 4460;
  
  public static final int RUINED_HERB_TEA = 4462;
  
  public static final int HERB_TEA_MIX = 4464;
  
  public static final int HERB_TEA_MIX_4466 = 4466;
  
  public static final int HERB_TEA_MIX_4468 = 4468;
  
  public static final int HERB_TEA_MIX_4470 = 4470;
  
  public static final int HERB_TEA_MIX_4472 = 4472;
  
  public static final int HERB_TEA_MIX_4474 = 4474;
  
  public static final int HERB_TEA_MIX_4476 = 4476;
  
  public static final int HERB_TEA_MIX_4478 = 4478;
  
  public static final int HERB_TEA_MIX_4480 = 4480;
  
  public static final int HERB_TEA_MIX_4482 = 4482;
  
  public static final int SAFETY_GUARANTEE = 4484;
  
  public static final int WHITE_PEARL = 4485;
  
  public static final int WHITE_PEARL_SEED = 4486;
  
  public static final int HALF_A_ROCK = 4487;
  
  public static final int CORPSE_OF_WOMAN = 4488;
  
  public static final int ASLEIFS_NECKLACE = 4489;
  
  public static final int MUD = 4490;
  
  public static final int MUDDY_ROCK = 4492;
  
  public static final int POLE = 4494;
  
  public static final int BROKEN_POLE = 4496;
  
  public static final int ROPE_4498 = 4498;
  
  public static final int POLE_4500 = 4500;
  
  public static final int BEARHEAD = 4502;
  
  public static final int DECORATIVE_SWORD_4503 = 4503;
  
  public static final int DECORATIVE_ARMOUR_4504 = 4504;
  
  public static final int DECORATIVE_ARMOUR_4505 = 4505;
  
  public static final int DECORATIVE_HELM_4506 = 4506;
  
  public static final int DECORATIVE_SHIELD_4507 = 4507;
  
  public static final int DECORATIVE_SWORD_4508 = 4508;
  
  public static final int DECORATIVE_ARMOUR_4509 = 4509;
  
  public static final int DECORATIVE_ARMOUR_4510 = 4510;
  
  public static final int DECORATIVE_HELM_4511 = 4511;
  
  public static final int DECORATIVE_SHIELD_4512 = 4512;
  
  public static final int CASTLEWARS_HOOD = 4513;
  
  public static final int CASTLEWARS_CLOAK = 4514;
  
  public static final int CASTLEWARS_HOOD_4515 = 4515;
  
  public static final int CASTLEWARS_CLOAK_4516 = 4516;
  
  public static final int GIANT_FROG_LEGS = 4517;
  
  public static final int SWAMP_WALLBEAST = 4519;
  
  public static final int SWAMP_CAVE_SLIME = 4520;
  
  public static final int SWAMP_CAVE_BUG = 4521;
  
  public static final int OIL_LAMP = 4522;
  
  public static final int OIL_LAMP_4524 = 4524;
  
  public static final int EMPTY_OIL_LAMP = 4525;
  
  public static final int EMPTY_CANDLE_LANTERN = 4527;
  
  public static final int CANDLE_LANTERN = 4529;
  
  public static final int CANDLE_LANTERN_4531 = 4531;
  
  public static final int CANDLE_LANTERN_4532 = 4532;
  
  public static final int CANDLE_LANTERN_4534 = 4534;
  
  public static final int EMPTY_OIL_LANTERN = 4535;
  
  public static final int OIL_LANTERN = 4537;
  
  public static final int OIL_LANTERN_4539 = 4539;
  
  public static final int OIL_LANTERN_FRAME = 4540;
  
  public static final int LANTERN_LENS = 4542;
  
  public static final int BULLSEYE_LANTERN_UNF = 4544;
  
  public static final int BULLSEYE_LANTERN_EMPTY = 4546;
  
  public static final int BULLSEYE_LANTERN = 4548;
  
  public static final int BULLSEYE_LANTERN_4550 = 4550;
  
  public static final int SPINY_HELMET = 4551;
  
  public static final int BLUE_SWEETS = 4558;
  
  public static final int DEEP_BLUE_SWEETS = 4559;
  
  public static final int WHITE_SWEETS = 4560;
  
  public static final int PURPLE_SWEETS = 4561;
  
  public static final int RED_SWEETS = 4562;
  
  public static final int GREEN_SWEETS = 4563;
  
  public static final int PINK_SWEETS = 4564;
  
  public static final int EASTER_BASKET = 4565;
  
  public static final int RUBBER_CHICKEN = 4566;
  
  public static final int GOLD_HELMET = 4567;
  
  public static final int DWARVEN_LORE = 4568;
  
  public static final int BOOK_PAGE_1 = 4569;
  
  public static final int BOOK_PAGE_2 = 4570;
  
  public static final int BOOK_PAGE_3 = 4571;
  
  public static final int PAGES = 4572;
  
  public static final int PAGES_4573 = 4573;
  
  public static final int BASE_SCHEMATICS = 4574;
  
  public static final int SCHEMATIC = 4575;
  
  public static final int SCHEMATICS = 4576;
  
  public static final int SCHEMATICS_4577 = 4577;
  
  public static final int SCHEMATIC_4578 = 4578;
  
  public static final int CANNON_BALL = 4579;
  
  public static final int BLACK_SPEAR = 4580;
  
  public static final int BLACK_SPEARP = 4582;
  
  public static final int BLACK_SPEARKP = 4584;
  
  public static final int DRAGON_PLATESKIRT = 4585;
  
  public static final int DRAGON_SCIMITAR = 4587;
  
  public static final int KEYS = 4589;
  
  public static final int JEWELS = 4590;
  
  public static final int KHARIDIAN_HEADPIECE = 4591;
  
  public static final int FAKE_BEARD = 4593;
  
  public static final int KARIDIAN_DISGUISE = 4595;
  
  public static final int NOTE = 4597;
  
  public static final int NOTE_4598 = 4598;
  
  public static final int OAK_BLACKJACK = 4599;
  
  public static final int WILLOW_BLACKJACK = 4600;
  
  public static final int UGTHANKI_DUNG = 4601;
  
  public static final int UGTHANKI_DUNG_4602 = 4602;
  
  public static final int RECEIPT = 4603;
  
  public static final int HAGS_POISON = 4604;
  
  public static final int SNAKE_CHARM = 4605;
  
  public static final int SNAKE_BASKET = 4606;
  
  public static final int SNAKE_BASKET_FULL = 4607;
  
  public static final int SUPER_KEBAB = 4608;
  
  public static final int RED_HOT_SAUCE = 4610;
  
  public static final int DESERT_DISGUISE = 4611;
  
  public static final int SPINNING_PLATE = 4613;
  
  public static final int BROKEN_PLATE = 4614;
  
  public static final int LETTER_4615 = 4615;
  
  public static final int VARMENS_NOTES = 4616;
  
  public static final int DISPLAY_CABINET_KEY = 4617;
  
  public static final int STATUETTE = 4618;
  
  public static final int STRANGE_IMPLEMENT = 4619;
  
  public static final int BLACK_MUSHROOM = 4620;
  
  public static final int PHOENIX_FEATHER = 4621;
  
  public static final int BLACK_DYE = 4622;
  
  public static final int PHOENIX_QUILL_PEN = 4623;
  
  public static final int GOLEM_PROGRAM = 4624;
  
  public static final int BANDIT = 4625;
  
  public static final int BANDITS_BREW = 4627;
  
  public static final int FIRE = 4653;
  
  public static final int ETCHINGS = 4654;
  
  public static final int TRANSLATION = 4655;
  
  public static final int WARM_KEY = 4656;
  
  public static final int RING_OF_VISIBILITY = 4657;
  
  public static final int SILVER_POT_4658 = 4658;
  
  public static final int BLESSED_POT = 4659;
  
  public static final int SILVER_POT_4660 = 4660;
  
  public static final int BLESSED_POT_4661 = 4661;
  
  public static final int SILVER_POT_4662 = 4662;
  
  public static final int BLESSED_POT_4663 = 4663;
  
  public static final int SILVER_POT_4664 = 4664;
  
  public static final int BLESSED_POT_4665 = 4665;
  
  public static final int SILVER_POT_4666 = 4666;
  
  public static final int BLESSED_POT_4667 = 4667;
  
  public static final int GARLIC_POWDER = 4668;
  
  public static final int BLOOD_DIAMOND = 4670;
  
  public static final int ICE_DIAMOND = 4671;
  
  public static final int SMOKE_DIAMOND = 4672;
  
  public static final int SHADOW_DIAMOND = 4673;
  
  public static final int GILDED_CROSS = 4674;
  
  public static final int ANCIENT_STAFF = 4675;
  
  public static final int CATSPEAK_AMULET = 4677;
  
  public static final int CANOPIC_JAR = 4678;
  
  public static final int CANOPIC_JAR_4679 = 4679;
  
  public static final int CANOPIC_JAR_4680 = 4680;
  
  public static final int CANOPIC_JAR_4681 = 4681;
  
  public static final int HOLY_SYMBOL_4682 = 4682;
  
  public static final int UNHOLY_SYMBOL_4683 = 4683;
  
  public static final int LINEN = 4684;
  
  public static final int EMBALMING_MANUAL = 4686;
  
  public static final int BUCKET_OF_SAP = 4687;
  
  public static final int PILE_OF_SALT = 4689;
  
  public static final int SPHINXS_TOKEN = 4691;
  
  public static final int GOLD_LEAF = 4692;
  
  public static final int BUCKET_OF_SALTWATER = 4693;
  
  public static final int STEAM_RUNE = 4694;
  
  public static final int MIST_RUNE = 4695;
  
  public static final int DUST_RUNE = 4696;
  
  public static final int SMOKE_RUNE = 4697;
  
  public static final int MUD_RUNE = 4698;
  
  public static final int LAVA_RUNE = 4699;
  
  public static final int SAPPHIRE_LANTERN = 4700;
  
  public static final int SAPPHIRE_LANTERN_4701 = 4701;
  
  public static final int SAPPHIRE_LANTERN_4702 = 4702;
  
  public static final int MAGIC_STONE = 4703;
  
  public static final int STONE_BOWL = 4704;
  
  public static final int CRUMBLING_TOME = 4707;
  
  public static final int AHRIMS_HOOD = 4708;
  
  public static final int AHRIMS_STAFF = 4710;
  
  public static final int AHRIMS_ROBETOP = 4712;
  
  public static final int AHRIMS_ROBESKIRT = 4714;
  
  public static final int DHAROKS_HELM = 4716;
  
  public static final int DHAROKS_GREATAXE = 4718;
  
  public static final int DHAROKS_PLATEBODY = 4720;
  
  public static final int DHAROKS_PLATELEGS = 4722;
  
  public static final int GUTHANS_HELM = 4724;
  
  public static final int GUTHANS_WARSPEAR = 4726;
  
  public static final int GUTHANS_PLATEBODY = 4728;
  
  public static final int GUTHANS_CHAINSKIRT = 4730;
  
  public static final int KARILS_COIF = 4732;
  
  public static final int KARILS_CROSSBOW = 4734;
  
  public static final int KARILS_LEATHERTOP = 4736;
  
  public static final int KARILS_LEATHERSKIRT = 4738;
  
  public static final int BOLT_RACK = 4740;
  
  public static final int TORAGS_HELM = 4745;
  
  public static final int TORAGS_HAMMERS = 4747;
  
  public static final int TORAGS_PLATEBODY = 4749;
  
  public static final int TORAGS_PLATELEGS = 4751;
  
  public static final int VERACS_HELM = 4753;
  
  public static final int VERACS_FLAIL = 4755;
  
  public static final int VERACS_BRASSARD = 4757;
  
  public static final int VERACS_PLATESKIRT = 4759;
  
  public static final int BRONZE_BRUTAL = 4773;
  
  public static final int IRON_BRUTAL = 4778;
  
  public static final int STEEL_BRUTAL = 4783;
  
  public static final int BLACK_BRUTAL = 4788;
  
  public static final int MITHRIL_BRUTAL = 4793;
  
  public static final int ADAMANT_BRUTAL = 4798;
  
  public static final int RUNE_BRUTAL = 4803;
  
  public static final int BLACK_PRISM = 4808;
  
  public static final int TORN_PAGE = 4809;
  
  public static final int RUINED_BACKPACK = 4810;
  
  public static final int DRAGON_INN_TANKARD = 4811;
  
  public static final int ZOGRE_BONES = 4812;
  
  public static final int SITHIK_PORTRAIT = 4814;
  
  public static final int SITHIK_PORTRAIT_4815 = 4815;
  
  public static final int SIGNED_PORTRAIT = 4816;
  
  public static final int BOOK_OF_PORTRAITURE = 4817;
  
  public static final int OGRE_ARTEFACT = 4818;
  
  public static final int BRONZE_NAILS = 4819;
  
  public static final int IRON_NAILS = 4820;
  
  public static final int BLACK_NAILS = 4821;
  
  public static final int MITHRIL_NAILS = 4822;
  
  public static final int ADAMANTITE_NAILS = 4823;
  
  public static final int RUNE_NAILS = 4824;
  
  public static final int UNSTRUNG_COMP_BOW = 4825;
  
  public static final int COMP_OGRE_BOW = 4827;
  
  public static final int BOOK_OF_HAM = 4829;
  
  public static final int FAYRG_BONES = 4830;
  
  public static final int RAURG_BONES = 4832;
  
  public static final int OURG_BONES = 4834;
  
  public static final int STRANGE_POTION = 4836;
  
  public static final int NECROMANCY_BOOK = 4837;
  
  public static final int CUP_OF_TEA_4838 = 4838;
  
  public static final int OGRE_GATE_KEY = 4839;
  
  public static final int UNFINISHED_POTION_4840 = 4840;
  
  public static final int RELICYMS_BALM4 = 4842;
  
  public static final int RELICYMS_BALM3 = 4844;
  
  public static final int RELICYMS_BALM2 = 4846;
  
  public static final int RELICYMS_BALM1 = 4848;
  
  public static final int OGRE_COFFIN_KEY = 4850;
  
  public static final int ZOGRE_BONEMEAL = 4852;
  
  public static final int FAYRG_BONEMEAL = 4853;
  
  public static final int RAURG_BONEMEAL = 4854;
  
  public static final int OURG_BONEMEAL = 4855;
  
  public static final int AHRIMS_HOOD_100 = 4856;
  
  public static final int AHRIMS_HOOD_75 = 4857;
  
  public static final int AHRIMS_HOOD_50 = 4858;
  
  public static final int AHRIMS_HOOD_25 = 4859;
  
  public static final int AHRIMS_HOOD_0 = 4860;
  
  public static final int AHRIMS_STAFF_100 = 4862;
  
  public static final int AHRIMS_STAFF_75 = 4863;
  
  public static final int AHRIMS_STAFF_50 = 4864;
  
  public static final int AHRIMS_STAFF_25 = 4865;
  
  public static final int AHRIMS_STAFF_0 = 4866;
  
  public static final int AHRIMS_ROBETOP_100 = 4868;
  
  public static final int AHRIMS_ROBETOP_75 = 4869;
  
  public static final int AHRIMS_ROBETOP_50 = 4870;
  
  public static final int AHRIMS_ROBETOP_25 = 4871;
  
  public static final int AHRIMS_ROBETOP_0 = 4872;
  
  public static final int AHRIMS_ROBESKIRT_100 = 4874;
  
  public static final int AHRIMS_ROBESKIRT_75 = 4875;
  
  public static final int AHRIMS_ROBESKIRT_50 = 4876;
  
  public static final int AHRIMS_ROBESKIRT_25 = 4877;
  
  public static final int AHRIMS_ROBESKIRT_0 = 4878;
  
  public static final int DHAROKS_HELM_100 = 4880;
  
  public static final int DHAROKS_HELM_75 = 4881;
  
  public static final int DHAROKS_HELM_50 = 4882;
  
  public static final int DHAROKS_HELM_25 = 4883;
  
  public static final int DHAROKS_HELM_0 = 4884;
  
  public static final int DHAROKS_GREATAXE_100 = 4886;
  
  public static final int DHAROKS_GREATAXE_75 = 4887;
  
  public static final int DHAROKS_GREATAXE_50 = 4888;
  
  public static final int DHAROKS_GREATAXE_25 = 4889;
  
  public static final int DHAROKS_GREATAXE_0 = 4890;
  
  public static final int DHAROKS_PLATEBODY_100 = 4892;
  
  public static final int DHAROKS_PLATEBODY_75 = 4893;
  
  public static final int DHAROKS_PLATEBODY_50 = 4894;
  
  public static final int DHAROKS_PLATEBODY_25 = 4895;
  
  public static final int DHAROKS_PLATEBODY_0 = 4896;
  
  public static final int DHAROKS_PLATELEGS_100 = 4898;
  
  public static final int DHAROKS_PLATELEGS_75 = 4899;
  
  public static final int DHAROKS_PLATELEGS_50 = 4900;
  
  public static final int DHAROKS_PLATELEGS_25 = 4901;
  
  public static final int DHAROKS_PLATELEGS_0 = 4902;
  
  public static final int GUTHANS_HELM_100 = 4904;
  
  public static final int GUTHANS_HELM_75 = 4905;
  
  public static final int GUTHANS_HELM_50 = 4906;
  
  public static final int GUTHANS_HELM_25 = 4907;
  
  public static final int GUTHANS_HELM_0 = 4908;
  
  public static final int GUTHANS_WARSPEAR_100 = 4910;
  
  public static final int GUTHANS_WARSPEAR_75 = 4911;
  
  public static final int GUTHANS_WARSPEAR_50 = 4912;
  
  public static final int GUTHANS_WARSPEAR_25 = 4913;
  
  public static final int GUTHANS_WARSPEAR_0 = 4914;
  
  public static final int GUTHANS_PLATEBODY_100 = 4916;
  
  public static final int GUTHANS_PLATEBODY_75 = 4917;
  
  public static final int GUTHANS_PLATEBODY_50 = 4918;
  
  public static final int GUTHANS_PLATEBODY_25 = 4919;
  
  public static final int GUTHANS_PLATEBODY_0 = 4920;
  
  public static final int GUTHANS_CHAINSKIRT_100 = 4922;
  
  public static final int GUTHANS_CHAINSKIRT_75 = 4923;
  
  public static final int GUTHANS_CHAINSKIRT_50 = 4924;
  
  public static final int GUTHANS_CHAINSKIRT_25 = 4925;
  
  public static final int GUTHANS_CHAINSKIRT_0 = 4926;
  
  public static final int KARILS_COIF_100 = 4928;
  
  public static final int KARILS_COIF_75 = 4929;
  
  public static final int KARILS_COIF_50 = 4930;
  
  public static final int KARILS_COIF_25 = 4931;
  
  public static final int KARILS_COIF_0 = 4932;
  
  public static final int KARILS_CROSSBOW_100 = 4934;
  
  public static final int KARILS_CROSSBOW_75 = 4935;
  
  public static final int KARILS_CROSSBOW_50 = 4936;
  
  public static final int KARILS_CROSSBOW_25 = 4937;
  
  public static final int KARILS_CROSSBOW_0 = 4938;
  
  public static final int KARILS_LEATHERTOP_100 = 4940;
  
  public static final int KARILS_LEATHERTOP_75 = 4941;
  
  public static final int KARILS_LEATHERTOP_50 = 4942;
  
  public static final int KARILS_LEATHERTOP_25 = 4943;
  
  public static final int KARILS_LEATHERTOP_0 = 4944;
  
  public static final int KARILS_LEATHERSKIRT_100 = 4946;
  
  public static final int KARILS_LEATHERSKIRT_75 = 4947;
  
  public static final int KARILS_LEATHERSKIRT_50 = 4948;
  
  public static final int KARILS_LEATHERSKIRT_25 = 4949;
  
  public static final int KARILS_LEATHERSKIRT_0 = 4950;
  
  public static final int TORAGS_HELM_100 = 4952;
  
  public static final int TORAGS_HELM_75 = 4953;
  
  public static final int TORAGS_HELM_50 = 4954;
  
  public static final int TORAGS_HELM_25 = 4955;
  
  public static final int TORAGS_HELM_0 = 4956;
  
  public static final int TORAGS_HAMMERS_100 = 4958;
  
  public static final int TORAGS_HAMMERS_75 = 4959;
  
  public static final int TORAGS_HAMMERS_50 = 4960;
  
  public static final int TORAGS_HAMMERS_25 = 4961;
  
  public static final int TORAGS_HAMMERS_0 = 4962;
  
  public static final int TORAGS_PLATEBODY_100 = 4964;
  
  public static final int TORAGS_PLATEBODY_75 = 4965;
  
  public static final int TORAGS_PLATEBODY_50 = 4966;
  
  public static final int TORAGS_PLATEBODY_25 = 4967;
  
  public static final int TORAGS_PLATEBODY_0 = 4968;
  
  public static final int TORAGS_PLATELEGS_100 = 4970;
  
  public static final int TORAGS_PLATELEGS_75 = 4971;
  
  public static final int TORAGS_PLATELEGS_50 = 4972;
  
  public static final int TORAGS_PLATELEGS_25 = 4973;
  
  public static final int TORAGS_PLATELEGS_0 = 4974;
  
  public static final int VERACS_HELM_100 = 4976;
  
  public static final int VERACS_HELM_75 = 4977;
  
  public static final int VERACS_HELM_50 = 4978;
  
  public static final int VERACS_HELM_25 = 4979;
  
  public static final int VERACS_HELM_0 = 4980;
  
  public static final int VERACS_FLAIL_100 = 4982;
  
  public static final int VERACS_FLAIL_75 = 4983;
  
  public static final int VERACS_FLAIL_50 = 4984;
  
  public static final int VERACS_FLAIL_25 = 4985;
  
  public static final int VERACS_FLAIL_0 = 4986;
  
  public static final int VERACS_BRASSARD_100 = 4988;
  
  public static final int VERACS_BRASSARD_75 = 4989;
  
  public static final int VERACS_BRASSARD_50 = 4990;
  
  public static final int VERACS_BRASSARD_25 = 4991;
  
  public static final int VERACS_BRASSARD_0 = 4992;
  
  public static final int VERACS_PLATESKIRT_100 = 4994;
  
  public static final int VERACS_PLATESKIRT_75 = 4995;
  
  public static final int VERACS_PLATESKIRT_50 = 4996;
  
  public static final int VERACS_PLATESKIRT_25 = 4997;
  
  public static final int VERACS_PLATESKIRT_0 = 4998;
  
  public static final int RAW_CAVE_EEL = 5001;
  
  public static final int BURNT_CAVE_EEL = 5002;
  
  public static final int CAVE_EEL = 5003;
  
  public static final int FROG_SPAWN = 5004;
  
  public static final int BROOCH = 5008;
  
  public static final int GOBLIN_SYMBOL_BOOK = 5009;
  
  public static final int KEY_5010 = 5010;
  
  public static final int SILVERWARE = 5011;
  
  public static final int PEACE_TREATY = 5012;
  
  public static final int MINING_HELMET = 5013;
  
  public static final int MINING_HELMET_5014 = 5014;
  
  public static final int BONE_SPEAR = 5016;
  
  public static final int BONE_CLUB = 5018;
  
  public static final int MINECART_TICKET = 5020;
  
  public static final int MINECART_TICKET_5021 = 5021;
  
  public static final int MINECART_TICKET_5022 = 5022;
  
  public static final int MINECART_TICKET_5023 = 5023;
  
  public static final int WOVEN_TOP = 5024;
  
  public static final int WOVEN_TOP_5026 = 5026;
  
  public static final int WOVEN_TOP_5028 = 5028;
  
  public static final int SHIRT = 5030;
  
  public static final int SHIRT_5032 = 5032;
  
  public static final int SHIRT_5034 = 5034;
  
  public static final int TROUSERS = 5036;
  
  public static final int TROUSERS_5038 = 5038;
  
  public static final int TROUSERS_5040 = 5040;
  
  public static final int SHORTS = 5042;
  
  public static final int SHORTS_5044 = 5044;
  
  public static final int SHORTS_5046 = 5046;
  
  public static final int SKIRT = 5048;
  
  public static final int SKIRT_5050 = 5050;
  
  public static final int SKIRT_5052 = 5052;
  
  public static final int DWARF = 5054;
  
  public static final int DWARVEN_BATTLEAXE = 5056;
  
  public static final int DWARVEN_BATTLEAXE_5057 = 5057;
  
  public static final int DWARVEN_BATTLEAXE_5058 = 5058;
  
  public static final int DWARVEN_BATTLEAXE_5059 = 5059;
  
  public static final int DWARVEN_BATTLEAXE_5060 = 5060;
  
  public static final int DWARVEN_BATTLEAXE_5061 = 5061;
  
  public static final int LEFT_BOOT = 5062;
  
  public static final int RIGHT_BOOT = 5063;
  
  public static final int EXQUISITE_BOOTS = 5064;
  
  public static final int BOOK_ON_COSTUMES = 5065;
  
  public static final int MEETING_NOTES = 5066;
  
  public static final int EXQUISITE_CLOTHES = 5067;
  
  public static final int MASTER_FARMER = 5068;
  
  public static final int BIRD_NEST = 5070;
  
  public static final int BIRD_NEST_5071 = 5071;
  
  public static final int BIRD_NEST_5072 = 5072;
  
  public static final int BIRD_NEST_5073 = 5073;
  
  public static final int BIRD_NEST_5074 = 5074;
  
  public static final int BIRD_NEST_5075 = 5075;
  
  public static final int BIRDS_EGG = 5076;
  
  public static final int BIRDS_EGG_5077 = 5077;
  
  public static final int BIRDS_EGG_5078 = 5078;
  
  public static final int VARROCK_ARMOUR = 5087;
  
  public static final int SEA_SNAKE = 5089;
  
  public static final int MORYTANIA_LEGS = 5093;
  
  public static final int EXPLORERS_RING = 5095;
  
  public static final int MARIGOLD_SEED = 5096;
  
  public static final int ROSEMARY_SEED = 5097;
  
  public static final int NASTURTIUM_SEED = 5098;
  
  public static final int WOAD_SEED = 5099;
  
  public static final int LIMPWURT_SEED = 5100;
  
  public static final int REDBERRY_SEED = 5101;
  
  public static final int CADAVABERRY_SEED = 5102;
  
  public static final int DWELLBERRY_SEED = 5103;
  
  public static final int JANGERBERRY_SEED = 5104;
  
  public static final int WHITEBERRY_SEED = 5105;
  
  public static final int POISON_IVY_SEED = 5106;
  
  public static final int SEEDS = 5171;
  
  public static final int CACTUS_SEED = 5280;
  
  public static final int BELLADONNA_SEED = 5281;
  
  public static final int MUSHROOM_SPORE = 5282;
  
  public static final int APPLE_TREE_SEED = 5283;
  
  public static final int BANANA_TREE_SEED = 5284;
  
  public static final int ORANGE_TREE_SEED = 5285;
  
  public static final int CURRY_TREE_SEED = 5286;
  
  public static final int PINEAPPLE_SEED = 5287;
  
  public static final int PAPAYA_TREE_SEED = 5288;
  
  public static final int PALM_TREE_SEED = 5289;
  
  public static final int CALQUAT_TREE_SEED = 5290;
  
  public static final int GUAM_SEED = 5291;
  
  public static final int MARRENTILL_SEED = 5292;
  
  public static final int TARROMIN_SEED = 5293;
  
  public static final int HARRALANDER_SEED = 5294;
  
  public static final int RANARR_SEED = 5295;
  
  public static final int TOADFLAX_SEED = 5296;
  
  public static final int IRIT_SEED = 5297;
  
  public static final int AVANTOE_SEED = 5298;
  
  public static final int KWUARM_SEED = 5299;
  
  public static final int SNAPDRAGON_SEED = 5300;
  
  public static final int CADANTINE_SEED = 5301;
  
  public static final int LANTADYME_SEED = 5302;
  
  public static final int DWARF_WEED_SEED = 5303;
  
  public static final int TORSTOL_SEED = 5304;
  
  public static final int BARLEY_SEED = 5305;
  
  public static final int JUTE_SEED = 5306;
  
  public static final int HAMMERSTONE_SEED = 5307;
  
  public static final int ASGARNIAN_SEED = 5308;
  
  public static final int YANILLIAN_SEED = 5309;
  
  public static final int KRANDORIAN_SEED = 5310;
  
  public static final int WILDBLOOD_SEED = 5311;
  
  public static final int ACORN = 5312;
  
  public static final int WILLOW_SEED = 5313;
  
  public static final int MAPLE_SEED = 5314;
  
  public static final int YEW_SEED = 5315;
  
  public static final int MAGIC_SEED = 5316;
  
  public static final int SPIRIT_SEED = 5317;
  
  public static final int POTATO_SEED = 5318;
  
  public static final int ONION_SEED = 5319;
  
  public static final int SWEETCORN_SEED = 5320;
  
  public static final int WATERMELON_SEED = 5321;
  
  public static final int TOMATO_SEED = 5322;
  
  public static final int STRAWBERRY_SEED = 5323;
  
  public static final int CABBAGE_SEED = 5324;
  
  public static final int GARDENING_TROWEL = 5325;
  
  public static final int SPADE_HANDLE = 5327;
  
  public static final int SPADE_HEAD = 5328;
  
  public static final int SECATEURS = 5329;
  
  public static final int WATERING_CAN = 5331;
  
  public static final int WATERING_CAN1 = 5333;
  
  public static final int WATERING_CAN2 = 5334;
  
  public static final int WATERING_CAN3 = 5335;
  
  public static final int WATERING_CAN4 = 5336;
  
  public static final int WATERING_CAN5 = 5337;
  
  public static final int WATERING_CAN6 = 5338;
  
  public static final int WATERING_CAN7 = 5339;
  
  public static final int WATERING_CAN8 = 5340;
  
  public static final int RAKE = 5341;
  
  public static final int SEED_DIBBER = 5343;
  
  public static final int GARDENING_BOOTS = 5345;
  
  public static final int RAKE_HANDLE = 5347;
  
  public static final int RAKE_HEAD = 5348;
  
  public static final int SMOKE_DEVIL = 5349;
  
  public static final int EMPTY_PLANT_POT = 5350;
  
  public static final int UNFIRED_PLANT_POT = 5352;
  
  public static final int FILLED_PLANT_POT = 5354;
  
  public static final int PLANT_POT = 5356;
  
  public static final int OAK_SEEDLING = 5358;
  
  public static final int WILLOW_SEEDLING = 5359;
  
  public static final int MAPLE_SEEDLING = 5360;
  
  public static final int YEW_SEEDLING = 5361;
  
  public static final int MAGIC_SEEDLING = 5362;
  
  public static final int SPIRIT_SEEDLING = 5363;
  
  public static final int OAK_SEEDLING_W = 5364;
  
  public static final int WILLOW_SEEDLING_W = 5365;
  
  public static final int MAPLE_SEEDLING_W = 5366;
  
  public static final int YEW_SEEDLING_W = 5367;
  
  public static final int MAGIC_SEEDLING_W = 5368;
  
  public static final int SPIRIT_SEEDLING_W = 5369;
  
  public static final int OAK_SAPLING = 5370;
  
  public static final int WILLOW_SAPLING = 5371;
  
  public static final int MAPLE_SAPLING = 5372;
  
  public static final int YEW_SAPLING = 5373;
  
  public static final int MAGIC_SAPLING = 5374;
  
  public static final int SPIRIT_SAPLING = 5375;
  
  public static final int BASKET = 5376;
  
  public static final int APPLES1 = 5378;
  
  public static final int APPLES2 = 5380;
  
  public static final int APPLES3 = 5382;
  
  public static final int APPLES4 = 5384;
  
  public static final int APPLES5 = 5386;
  
  public static final int ORANGES1 = 5388;
  
  public static final int ORANGES2 = 5390;
  
  public static final int ORANGES3 = 5392;
  
  public static final int ORANGES4 = 5394;
  
  public static final int ORANGES5 = 5396;
  
  public static final int STRAWBERRIES1 = 5398;
  
  public static final int STRAWBERRIES2 = 5400;
  
  public static final int STRAWBERRIES3 = 5402;
  
  public static final int STRAWBERRIES4 = 5404;
  
  public static final int STRAWBERRIES5 = 5406;
  
  public static final int BANANAS1 = 5408;
  
  public static final int BANANAS2 = 5410;
  
  public static final int BANANAS3 = 5412;
  
  public static final int BANANAS4 = 5414;
  
  public static final int BANANAS5 = 5416;
  
  public static final int EMPTY_SACK = 5418;
  
  public static final int POTATOES1 = 5420;
  
  public static final int POTATOES2 = 5422;
  
  public static final int POTATOES3 = 5424;
  
  public static final int POTATOES4 = 5426;
  
  public static final int POTATOES5 = 5428;
  
  public static final int POTATOES6 = 5430;
  
  public static final int POTATOES7 = 5432;
  
  public static final int POTATOES8 = 5434;
  
  public static final int POTATOES9 = 5436;
  
  public static final int POTATOES10 = 5438;
  
  public static final int ONIONS1 = 5440;
  
  public static final int ONIONS2 = 5442;
  
  public static final int ONIONS3 = 5444;
  
  public static final int ONIONS4 = 5446;
  
  public static final int ONIONS5 = 5448;
  
  public static final int ONIONS6 = 5450;
  
  public static final int ONIONS7 = 5452;
  
  public static final int ONIONS8 = 5454;
  
  public static final int ONIONS9 = 5456;
  
  public static final int ONIONS10 = 5458;
  
  public static final int CABBAGES1 = 5460;
  
  public static final int CABBAGES2 = 5462;
  
  public static final int CABBAGES3 = 5464;
  
  public static final int CABBAGES4 = 5466;
  
  public static final int CABBAGES5 = 5468;
  
  public static final int CABBAGES6 = 5470;
  
  public static final int CABBAGES7 = 5472;
  
  public static final int CABBAGES8 = 5474;
  
  public static final int CABBAGES9 = 5476;
  
  public static final int CABBAGES10 = 5478;
  
  public static final int APPLE_SEEDLING = 5480;
  
  public static final int BANANA_SEEDLING = 5481;
  
  public static final int ORANGE_SEEDLING = 5482;
  
  public static final int CURRY_SEEDLING = 5483;
  
  public static final int PINEAPPLE_SEEDLING = 5484;
  
  public static final int PAPAYA_SEEDLING = 5485;
  
  public static final int PALM_SEEDLING = 5486;
  
  public static final int CALQUAT_SEEDLING = 5487;
  
  public static final int APPLE_SEEDLING_W = 5488;
  
  public static final int BANANA_SEEDLING_W = 5489;
  
  public static final int ORANGE_SEEDLING_W = 5490;
  
  public static final int CURRY_SEEDLING_W = 5491;
  
  public static final int PINEAPPLE_SEEDLING_W = 5492;
  
  public static final int PAPAYA_SEEDLING_W = 5493;
  
  public static final int PALM_SEEDLING_W = 5494;
  
  public static final int CALQUAT_SEEDLING_W = 5495;
  
  public static final int APPLE_SAPLING = 5496;
  
  public static final int BANANA_SAPLING = 5497;
  
  public static final int ORANGE_SAPLING = 5498;
  
  public static final int CURRY_SAPLING = 5499;
  
  public static final int PINEAPPLE_SAPLING = 5500;
  
  public static final int PAPAYA_SAPLING = 5501;
  
  public static final int PALM_SAPLING = 5502;
  
  public static final int CALQUAT_SAPLING = 5503;
  
  public static final int STRAWBERRY = 5504;
  
  public static final int OLD_MANS_MESSAGE = 5506;
  
  public static final int STRANGE_BOOK = 5507;
  
  public static final int BOOK_OF_FOLKLORE = 5508;
  
  public static final int SMALL_POUCH = 5509;
  
  public static final int MEDIUM_POUCH = 5510;
  
  public static final int MEDIUM_POUCH_5511 = 5511;
  
  public static final int LARGE_POUCH = 5512;
  
  public static final int LARGE_POUCH_5513 = 5513;
  
  public static final int GIANT_POUCH = 5514;
  
  public static final int GIANT_POUCH_5515 = 5515;
  
  public static final int ELEMENTAL_TALISMAN = 5516;
  
  public static final int SCRYING_ORB = 5518;
  
  public static final int SCRYING_ORB_5519 = 5519;
  
  public static final int ABYSSAL_BOOK = 5520;
  
  public static final int BINDING_NECKLACE = 5521;
  
  public static final int TIARA_MOULD = 5523;
  
  public static final int TIARA = 5525;
  
  public static final int AIR_TIARA = 5527;
  
  public static final int MIND_TIARA = 5529;
  
  public static final int WATER_TIARA = 5531;
  
  public static final int BODY_TIARA = 5533;
  
  public static final int EARTH_TIARA = 5535;
  
  public static final int FIRE_TIARA = 5537;
  
  public static final int COSMIC_TIARA = 5539;
  
  public static final int NATURE_TIARA = 5541;
  
  public static final int CHAOS_TIARA = 5543;
  
  public static final int LAW_TIARA = 5545;
  
  public static final int DEATH_TIARA = 5547;
  
  public static final int BLOOD_TIARA = 5549;
  
  public static final int ROGUE_TOP = 5553;
  
  public static final int ROGUE_MASK = 5554;
  
  public static final int ROGUE_TROUSERS = 5555;
  
  public static final int ROGUE_GLOVES = 5556;
  
  public static final int ROGUE_BOOTS = 5557;
  
  public static final int ROGUE_KIT = 5558;
  
  public static final int FLASH_POWDER = 5559;
  
  public static final int STETHOSCOPE = 5560;
  
  public static final int MYSTIC_JEWEL = 5561;
  
  public static final int GEAR = 5562;
  
  public static final int GEAR_5563 = 5563;
  
  public static final int GEAR_5564 = 5564;
  
  public static final int GEAR_5565 = 5565;
  
  public static final int GEAR_5566 = 5566;
  
  public static final int GEAR_5567 = 5567;
  
  public static final int TILE_5568 = 5568;
  
  public static final int TILES = 5569;
  
  public static final int TILES_5570 = 5570;
  
  public static final int TILES_5571 = 5571;
  
  public static final int DESERT_AMULET = 5573;
  
  public static final int INITIATE_SALLET = 5574;
  
  public static final int INITIATE_HAUBERK = 5575;
  
  public static final int INITIATE_CUISSE = 5576;
  
  public static final int CUPRIC_SULFATE = 5577;
  
  public static final int ACETIC_ACID = 5578;
  
  public static final int GYPSUM = 5579;
  
  public static final int SODIUM_CHLORIDE = 5580;
  
  public static final int NITROUS_OXIDE = 5581;
  
  public static final int VIAL_OF_LIQUID = 5582;
  
  public static final int TIN_ORE_POWDER = 5583;
  
  public static final int CUPRIC_ORE_POWDER = 5584;
  
  public static final int BRONZE_KEY_5585 = 5585;
  
  public static final int METAL_SPADE = 5586;
  
  public static final int METAL_SPADE_5587 = 5587;
  
  public static final int ALCHEMICAL_NOTES = 5588;
  
  public static final int _MIXTURE = 5589;
  
  public static final int _MIXTURE_5590 = 5590;
  
  public static final int _MIXTURE_5591 = 5591;
  
  public static final int TIN = 5592;
  
  public static final int TIN_5593 = 5593;
  
  public static final int TIN_5594 = 5594;
  
  public static final int TIN_5595 = 5595;
  
  public static final int TIN_5596 = 5596;
  
  public static final int TIN_5597 = 5597;
  
  public static final int TIN_5598 = 5598;
  
  public static final int TIN_5599 = 5599;
  
  public static final int TIN_5600 = 5600;
  
  public static final int CHISEL_5601 = 5601;
  
  public static final int BRONZE_WIRE_5602 = 5602;
  
  public static final int SHEARS_5603 = 5603;
  
  public static final int MAGNET_5604 = 5604;
  
  public static final int KNIFE_5605 = 5605;
  
  public static final int GRAIN_5607 = 5607;
  
  public static final int FOX = 5608;
  
  public static final int CHICKEN = 5609;
  
  public static final int HOURGLASS = 5610;
  
  public static final int MAGIC_CARPET = 5614;
  
  public static final int SHAIKAHAN_BONEMEAL = 5615;
  
  public static final int BRONZE_ARROWP_5616 = 5616;
  
  public static final int IRON_ARROWP_5617 = 5617;
  
  public static final int STEEL_ARROWP_5618 = 5618;
  
  public static final int MITHRIL_ARROWP_5619 = 5619;
  
  public static final int ADAMANT_ARROWP_5620 = 5620;
  
  public static final int RUNE_ARROWP_5621 = 5621;
  
  public static final int BRONZE_ARROWP_5622 = 5622;
  
  public static final int IRON_ARROWP_5623 = 5623;
  
  public static final int STEEL_ARROWP_5624 = 5624;
  
  public static final int MITHRIL_ARROWP_5625 = 5625;
  
  public static final int ADAMANT_ARROWP_5626 = 5626;
  
  public static final int RUNE_ARROWP_5627 = 5627;
  
  public static final int BRONZE_DARTP_5628 = 5628;
  
  public static final int IRON_DARTP = 5629;
  
  public static final int STEEL_DARTP_5630 = 5630;
  
  public static final int BLACK_DARTP_5631 = 5631;
  
  public static final int MITHRIL_DARTP_5632 = 5632;
  
  public static final int ADAMANT_DARTP_5633 = 5633;
  
  public static final int RUNE_DARTP_5634 = 5634;
  
  public static final int BRONZE_DARTP_5635 = 5635;
  
  public static final int IRON_DARTP_5636 = 5636;
  
  public static final int STEEL_DARTP_5637 = 5637;
  
  public static final int BLACK_DARTP_5638 = 5638;
  
  public static final int MITHRIL_DARTP_5639 = 5639;
  
  public static final int ADAMANT_DARTP_5640 = 5640;
  
  public static final int RUNE_DARTP_5641 = 5641;
  
  public static final int BRONZE_JAVELINP_5642 = 5642;
  
  public static final int IRON_JAVELINP_5643 = 5643;
  
  public static final int STEEL_JAVELINP_5644 = 5644;
  
  public static final int MITHRIL_JAVELINP_5645 = 5645;
  
  public static final int ADAMANT_JAVELINP_5646 = 5646;
  
  public static final int RUNE_JAVELINP_5647 = 5647;
  
  public static final int BRONZE_JAVELINP_5648 = 5648;
  
  public static final int IRON_JAVELINP_5649 = 5649;
  
  public static final int STEEL_JAVELINP_5650 = 5650;
  
  public static final int MITHRIL_JAVELINP_5651 = 5651;
  
  public static final int ADAMANT_JAVELINP_5652 = 5652;
  
  public static final int RUNE_JAVELINP_5653 = 5653;
  
  public static final int BRONZE_KNIFEP_5654 = 5654;
  
  public static final int IRON_KNIFEP_5655 = 5655;
  
  public static final int STEEL_KNIFEP_5656 = 5656;
  
  public static final int MITHRIL_KNIFEP_5657 = 5657;
  
  public static final int BLACK_KNIFEP_5658 = 5658;
  
  public static final int ADAMANT_KNIFEP_5659 = 5659;
  
  public static final int RUNE_KNIFEP_5660 = 5660;
  
  public static final int BRONZE_KNIFEP_5661 = 5661;
  
  public static final int IRON_KNIFEP_5662 = 5662;
  
  public static final int STEEL_KNIFEP_5663 = 5663;
  
  public static final int MITHRIL_KNIFEP_5664 = 5664;
  
  public static final int BLACK_KNIFEP_5665 = 5665;
  
  public static final int ADAMANT_KNIFEP_5666 = 5666;
  
  public static final int RUNE_KNIFEP_5667 = 5667;
  
  public static final int IRON_DAGGERP_5668 = 5668;
  
  public static final int BRONZE_DAGGERP_5670 = 5670;
  
  public static final int STEEL_DAGGERP_5672 = 5672;
  
  public static final int MITHRIL_DAGGERP_5674 = 5674;
  
  public static final int ADAMANT_DAGGERP_5676 = 5676;
  
  public static final int RUNE_DAGGERP_5678 = 5678;
  
  public static final int DRAGON_DAGGERP_5680 = 5680;
  
  public static final int BLACK_DAGGERP_5682 = 5682;
  
  public static final int POISON_DAGGERP = 5684;
  
  public static final int IRON_DAGGERP_5686 = 5686;
  
  public static final int BRONZE_DAGGERP_5688 = 5688;
  
  public static final int STEEL_DAGGERP_5690 = 5690;
  
  public static final int MITHRIL_DAGGERP_5692 = 5692;
  
  public static final int ADAMANT_DAGGERP_5694 = 5694;
  
  public static final int RUNE_DAGGERP_5696 = 5696;
  
  public static final int DRAGON_DAGGERP_5698 = 5698;
  
  public static final int BLACK_DAGGERP_5700 = 5700;
  
  public static final int POISON_DAGGERP_5702 = 5702;
  
  public static final int BRONZE_SPEARP_5704 = 5704;
  
  public static final int IRON_SPEARP_5706 = 5706;
  
  public static final int STEEL_SPEARP_5708 = 5708;
  
  public static final int MITHRIL_SPEARP_5710 = 5710;
  
  public static final int ADAMANT_SPEARP_5712 = 5712;
  
  public static final int RUNE_SPEARP_5714 = 5714;
  
  public static final int DRAGON_SPEARP_5716 = 5716;
  
  public static final int BRONZE_SPEARP_5718 = 5718;
  
  public static final int IRON_SPEARP_5720 = 5720;
  
  public static final int STEEL_SPEARP_5722 = 5722;
  
  public static final int MITHRIL_SPEARP_5724 = 5724;
  
  public static final int ADAMANT_SPEARP_5726 = 5726;
  
  public static final int RUNE_SPEARP_5728 = 5728;
  
  public static final int DRAGON_SPEARP_5730 = 5730;
  
  public static final int STOOL_5732 = 5732;
  
  public static final int ROTTEN_POTATO = 5733;
  
  public static final int BLACK_SPEARP_5734 = 5734;
  
  public static final int BLACK_SPEARP_5736 = 5736;
  
  public static final int WOAD_LEAF_5738 = 5738;
  
  public static final int ASGARNIAN_ALEM = 5739;
  
  public static final int MATURE_WMB = 5741;
  
  public static final int GREENMANS_ALEM = 5743;
  
  public static final int DRAGON_BITTERM = 5745;
  
  public static final int DWARVEN_STOUTM = 5747;
  
  public static final int MOONLIGHT_MEADM = 5749;
  
  public static final int AXEMANS_FOLLY = 5751;
  
  public static final int AXEMANS_FOLLYM = 5753;
  
  public static final int CHEFS_DELIGHT = 5755;
  
  public static final int CHEFS_DELIGHTM = 5757;
  
  public static final int SLAYERS_RESPITE = 5759;
  
  public static final int SLAYERS_RESPITEM = 5761;
  
  public static final int CIDER = 5763;
  
  public static final int MATURE_CIDER = 5765;
  
  public static final int ALE_YEAST = 5767;
  
  public static final int CALQUAT_KEG = 5769;
  
  public static final int DWARVEN_STOUT1 = 5771;
  
  public static final int DWARVEN_STOUT2 = 5773;
  
  public static final int DWARVEN_STOUT3 = 5775;
  
  public static final int DWARVEN_STOUT4 = 5777;
  
  public static final int ASGARNIAN_ALE1 = 5779;
  
  public static final int ASGARNIAN_ALE2 = 5781;
  
  public static final int ASGARNIAN_ALE3 = 5783;
  
  public static final int ASGARNIAN_ALE4 = 5785;
  
  public static final int GREENMANS_ALE1 = 5787;
  
  public static final int GREENMANS_ALE2 = 5789;
  
  public static final int GREENMANS_ALE3 = 5791;
  
  public static final int GREENMANS_ALE4 = 5793;
  
  public static final int MIND_BOMB1 = 5795;
  
  public static final int MIND_BOMB2 = 5797;
  
  public static final int MIND_BOMB3 = 5799;
  
  public static final int MIND_BOMB4 = 5801;
  
  public static final int DRAGON_BITTER1 = 5803;
  
  public static final int DRAGON_BITTER2 = 5805;
  
  public static final int DRAGON_BITTER3 = 5807;
  
  public static final int DRAGON_BITTER4 = 5809;
  
  public static final int MOONLIGHT_MEAD1 = 5811;
  
  public static final int MOONLIGHT_MEAD2 = 5813;
  
  public static final int MOONLIGHT_MEAD3 = 5815;
  
  public static final int MOONLIGHT_MEAD4 = 5817;
  
  public static final int AXEMANS_FOLLY1 = 5819;
  
  public static final int AXEMANS_FOLLY2 = 5821;
  
  public static final int AXEMANS_FOLLY3 = 5823;
  
  public static final int AXEMANS_FOLLY4 = 5825;
  
  public static final int CHEFS_DELIGHT1 = 5827;
  
  public static final int CHEFS_DELIGHT2 = 5829;
  
  public static final int CHEFS_DELIGHT3 = 5831;
  
  public static final int CHEFS_DELIGHT4 = 5833;
  
  public static final int SLAYERS_RESPITE1 = 5835;
  
  public static final int SLAYERS_RESPITE2 = 5837;
  
  public static final int SLAYERS_RESPITE3 = 5839;
  
  public static final int SLAYERS_RESPITE4 = 5841;
  
  public static final int CIDER1 = 5843;
  
  public static final int CIDER2 = 5845;
  
  public static final int CIDER3 = 5847;
  
  public static final int CIDER4 = 5849;
  
  public static final int DWARVEN_STOUTM1 = 5851;
  
  public static final int DWARVEN_STOUTM2 = 5853;
  
  public static final int DWARVEN_STOUTM3 = 5855;
  
  public static final int DWARVEN_STOUTM4 = 5857;
  
  public static final int ASGARNIAN_ALEM1 = 5859;
  
  public static final int ASGARNIAN_ALEM2 = 5861;
  
  public static final int ASGARNIAN_ALEM3 = 5863;
  
  public static final int ASGARNIAN_ALEM4 = 5865;
  
  public static final int GREENMANS_ALEM1 = 5867;
  
  public static final int GREENMANS_ALEM2 = 5869;
  
  public static final int GREENMANS_ALEM3 = 5871;
  
  public static final int GREENMANS_ALEM4 = 5873;
  
  public static final int MIND_BOMBM1 = 5875;
  
  public static final int MIND_BOMBM2 = 5877;
  
  public static final int MIND_BOMBM3 = 5879;
  
  public static final int MIND_BOMBM4 = 5881;
  
  public static final int DRAGON_BITTERM1 = 5883;
  
  public static final int DRAGON_BITTERM2 = 5885;
  
  public static final int DRAGON_BITTERM3 = 5887;
  
  public static final int DRAGON_BITTERM4 = 5889;
  
  public static final int MOONLIGHT_MEADM1 = 5891;
  
  public static final int MOONLIGHT_MEADM2 = 5893;
  
  public static final int MOONLIGHT_MEADM3 = 5895;
  
  public static final int MOONLIGHT_MEADM4 = 5897;
  
  public static final int AXEMANS_FOLLYM1 = 5899;
  
  public static final int AXEMANS_FOLLYM2 = 5901;
  
  public static final int AXEMANS_FOLLYM3 = 5903;
  
  public static final int AXEMANS_FOLLYM4 = 5905;
  
  public static final int CHEFS_DELIGHTM1 = 5907;
  
  public static final int CHEFS_DELIGHTM2 = 5909;
  
  public static final int CHEFS_DELIGHTM3 = 5911;
  
  public static final int CHEFS_DELIGHTM4 = 5913;
  
  public static final int SLAYERS_RESPITEM1 = 5915;
  
  public static final int SLAYERS_RESPITEM2 = 5917;
  
  public static final int SLAYERS_RESPITEM3 = 5919;
  
  public static final int SLAYERS_RESPITEM4 = 5921;
  
  public static final int CIDERM1 = 5923;
  
  public static final int CIDERM2 = 5925;
  
  public static final int CIDERM3 = 5927;
  
  public static final int CIDERM4 = 5929;
  
  public static final int JUTE_FIBRE = 5931;
  
  public static final int WILLOW_BRANCH = 5933;
  
  public static final int COCONUT_MILK = 5935;
  
  public static final int WEAPON_POISON_UNF = 5936;
  
  public static final int WEAPON_POISON_5937 = 5937;
  
  public static final int WEAPON_POISON_UNF_5939 = 5939;
  
  public static final int WEAPON_POISON_5940 = 5940;
  
  public static final int ANTIDOTE_UNF = 5942;
  
  public static final int ANTIDOTE4 = 5943;
  
  public static final int ANTIDOTE3 = 5945;
  
  public static final int ANTIDOTE2 = 5947;
  
  public static final int ANTIDOTE1 = 5949;
  
  public static final int ANTIDOTE_UNF_5951 = 5951;
  
  public static final int ANTIDOTE4_5952 = 5952;
  
  public static final int ANTIDOTE3_5954 = 5954;
  
  public static final int ANTIDOTE2_5956 = 5956;
  
  public static final int ANTIDOTE1_5958 = 5958;
  
  public static final int TOMATOES1 = 5960;
  
  public static final int TOMATOES2 = 5962;
  
  public static final int TOMATOES3 = 5964;
  
  public static final int TOMATOES4 = 5966;
  
  public static final int TOMATOES5 = 5968;
  
  public static final int CURRY_LEAF = 5970;
  
  public static final int PAPAYA_FRUIT = 5972;
  
  public static final int COCONUT = 5974;
  
  public static final int HALF_COCONUT = 5976;
  
  public static final int COCONUT_SHELL = 5978;
  
  public static final int CALQUAT_FRUIT = 5980;
  
  public static final int WATERMELON = 5982;
  
  public static final int WATERMELON_SLICE = 5984;
  
  public static final int SWEETCORN = 5986;
  
  public static final int COOKED_SWEETCORN = 5988;
  
  public static final int BURNT_SWEETCORN = 5990;
  
  public static final int APPLE_MUSH = 5992;
  
  public static final int HAMMERSTONE_HOPS = 5994;
  
  public static final int ASGARNIAN_HOPS = 5996;
  
  public static final int YANILLIAN_HOPS = 5998;
  
  public static final int KRANDORIAN_HOPS = 6000;
  
  public static final int WILDBLOOD_HOPS = 6002;
  
  public static final int MUSHROOM = 6004;
  
  public static final int BARLEY = 6006;
  
  public static final int BARLEY_MALT = 6008;
  
  public static final int MARIGOLDS = 6010;
  
  public static final int NASTURTIUMS = 6012;
  
  public static final int ROSEMARY = 6014;
  
  public static final int CACTUS_SPINE = 6016;
  
  public static final int POISON_IVY_BERRIES = 6018;
  
  public static final int LEAVES = 6020;
  
  public static final int OAK_LEAVES = 6022;
  
  public static final int WILLOW_LEAVES = 6024;
  
  public static final int YEW_LEAVES = 6026;
  
  public static final int MAPLE_LEAVES = 6028;
  
  public static final int MAGIC_LEAVES = 6030;
  
  public static final int COMPOST = 6032;
  
  public static final int SUPERCOMPOST = 6034;
  
  public static final int PLANT_CURE = 6036;
  
  public static final int MAGIC_STRING = 6038;
  
  public static final int AMULET_OF_NATURE = 6040;
  
  public static final int PRENATURE_AMULET = 6041;
  
  public static final int OAK_ROOTS = 6043;
  
  public static final int WILLOW_ROOTS = 6045;
  
  public static final int MAPLE_ROOTS = 6047;
  
  public static final int YEW_ROOTS = 6049;
  
  public static final int MAGIC_ROOTS = 6051;
  
  public static final int SPIRIT_ROOTS = 6053;
  
  public static final int WEEDS = 6055;
  
  public static final int HAY_SACK = 6057;
  
  public static final int HAY_SACK_6058 = 6058;
  
  public static final int SCARECROW = 6059;
  
  public static final int BRONZE_BOLTS_P_6061 = 6061;
  
  public static final int BRONZE_BOLTS_P_6062 = 6062;
  
  public static final int SPIRIT_TREE = 6063;
  
  public static final int BLOODY_MOURNER_TOP = 6064;
  
  public static final int MOURNER_TOP = 6065;
  
  public static final int RIPPED_MOURNER_TROUSERS = 6066;
  
  public static final int MOURNER_TROUSERS = 6067;
  
  public static final int MOURNER_GLOVES = 6068;
  
  public static final int MOURNER_BOOTS = 6069;
  
  public static final int MOURNER_CLOAK = 6070;
  
  public static final int MOURNER_LETTER = 6071;
  
  public static final int TEGIDS_SOAP = 6072;
  
  public static final int PRIFDDINAS_HISTORY = 6073;
  
  public static final int EASTERN_DISCOVERY = 6075;
  
  public static final int EASTERN_SETTLEMENT = 6077;
  
  public static final int THE_GREAT_DIVIDE = 6079;
  
  public static final int BROKEN_DEVICE = 6081;
  
  public static final int FIXED_DEVICE = 6082;
  
  public static final int TARNISHED_KEY = 6083;
  
  public static final int WORN_KEY = 6084;
  
  public static final int RED_DYE_BELLOWS = 6085;
  
  public static final int BLUE_DYE_BELLOWS = 6086;
  
  public static final int YELLOW_DYE_BELLOWS = 6087;
  
  public static final int GREEN_DYE_BELLOWS = 6088;
  
  public static final int BLUE_TOAD = 6089;
  
  public static final int RED_TOAD = 6090;
  
  public static final int YELLOW_TOAD = 6091;
  
  public static final int GREEN_TOAD = 6092;
  
  public static final int ROTTEN_APPLES = 6093;
  
  public static final int APPLE_BARREL = 6094;
  
  public static final int NAPHTHA_APPLE_MIX = 6095;
  
  public static final int TOXIC_NAPHTHA = 6096;
  
  public static final int SIEVE = 6097;
  
  public static final int TOXIC_POWDER = 6098;
  
  public static final int TELEPORT_CRYSTAL_4 = 6099;
  
  public static final int TELEPORT_CRYSTAL_3 = 6100;
  
  public static final int TELEPORT_CRYSTAL_2 = 6101;
  
  public static final int TELEPORT_CRYSTAL_1 = 6102;
  
  public static final int CRYSTAL_TELEPORT_SEED = 6103;
  
  public static final int NEW_KEY = 6104;
  
  public static final int ELF = 6105;
  
  public static final int GHOSTLY_BOOTS = 6106;
  
  public static final int GHOSTLY_ROBE = 6107;
  
  public static final int GHOSTLY_ROBE_6108 = 6108;
  
  public static final int GHOSTLY_HOOD = 6109;
  
  public static final int GHOSTLY_GLOVES = 6110;
  
  public static final int GHOSTLY_CLOAK = 6111;
  
  public static final int KELDA_SEED = 6112;
  
  public static final int KELDA_HOPS = 6113;
  
  public static final int KELDA_STOUT = 6118;
  
  public static final int SQUARE_STONE = 6119;
  
  public static final int SQUARE_STONE_6120 = 6120;
  
  public static final int LETTER_6121 = 6121;
  
  public static final int A_CHAIR = 6122;
  
  public static final int BEER_GLASS_6123 = 6123;
  
  public static final int ENCHANTED_LYRE2 = 6125;
  
  public static final int ENCHANTED_LYRE3 = 6126;
  
  public static final int ENCHANTED_LYRE4 = 6127;
  
  public static final int ROCKSHELL_HELM = 6128;
  
  public static final int ROCKSHELL_PLATE = 6129;
  
  public static final int ROCKSHELL_LEGS = 6130;
  
  public static final int SPINED_HELM = 6131;
  
  public static final int SPINED_BODY = 6133;
  
  public static final int SPINED_CHAPS = 6135;
  
  public static final int SKELETAL_HELM = 6137;
  
  public static final int SKELETAL_TOP = 6139;
  
  public static final int SKELETAL_BOTTOMS = 6141;
  
  public static final int SPINED_BOOTS = 6143;
  
  public static final int ROCKSHELL_BOOTS = 6145;
  
  public static final int SKELETAL_BOOTS = 6147;
  
  public static final int SPINED_GLOVES = 6149;
  
  public static final int ROCKSHELL_GLOVES = 6151;
  
  public static final int SKELETAL_GLOVES = 6153;
  
  public static final int DAGANNOTH_HIDE = 6155;
  
  public static final int ROCKSHELL_CHUNK = 6157;
  
  public static final int ROCKSHELL_SHARD = 6159;
  
  public static final int ROCKSHELL_SPLINTER = 6161;
  
  public static final int SKULL_PIECE = 6163;
  
  public static final int RIBCAGE_PIECE = 6165;
  
  public static final int FIBULA_PIECE = 6167;
  
  public static final int CIRCULAR_HIDE = 6169;
  
  public static final int FLATTENED_HIDE = 6171;
  
  public static final int STRETCHED_HIDE = 6173;
  
  public static final int RAW_PHEASANT = 6178;
  
  public static final int RAW_PHEASANT_6179 = 6179;
  
  public static final int LEDERHOSEN_TOP = 6180;
  
  public static final int LEDERHOSEN_SHORTS = 6181;
  
  public static final int LEDERHOSEN_HAT = 6182;
  
  public static final int FROG_TOKEN = 6183;
  
  public static final int ROYAL_FROG_TUNIC = 6184;
  
  public static final int ROYAL_FROG_LEGGINGS = 6185;
  
  public static final int ROYAL_FROG_BLOUSE = 6186;
  
  public static final int ROYAL_FROG_SKIRT = 6187;
  
  public static final int FROG_MASK = 6188;
  
  public static final int MYSTERY_BOX = 6199;
  
  public static final int RAW_FISHLIKE_THING = 6200;
  
  public static final int FISHLIKE_THING = 6202;
  
  public static final int RAW_FISHLIKE_THING_6204 = 6204;
  
  public static final int FISHLIKE_THING_6206 = 6206;
  
  public static final int SMALL_FISHING_NET_6209 = 6209;
  
  public static final int TEAK_PYRE_LOGS = 6211;
  
  public static final int MAHOGANY_PYRE_LOGS = 6213;
  
  public static final int BROODOO_SHIELD_10 = 6215;
  
  public static final int BROODOO_SHIELD_9 = 6217;
  
  public static final int BROODOO_SHIELD_8 = 6219;
  
  public static final int BROODOO_SHIELD_7 = 6221;
  
  public static final int BROODOO_SHIELD_6 = 6223;
  
  public static final int BROODOO_SHIELD_5 = 6225;
  
  public static final int BROODOO_SHIELD_4 = 6227;
  
  public static final int BROODOO_SHIELD_3 = 6229;
  
  public static final int BROODOO_SHIELD_2 = 6231;
  
  public static final int BROODOO_SHIELD_1 = 6233;
  
  public static final int BROODOO_SHIELD = 6235;
  
  public static final int BROODOO_SHIELD_10_6237 = 6237;
  
  public static final int BROODOO_SHIELD_9_6239 = 6239;
  
  public static final int BROODOO_SHIELD_8_6241 = 6241;
  
  public static final int BROODOO_SHIELD_7_6243 = 6243;
  
  public static final int BROODOO_SHIELD_6_6245 = 6245;
  
  public static final int BROODOO_SHIELD_5_6247 = 6247;
  
  public static final int BROODOO_SHIELD_4_6249 = 6249;
  
  public static final int BROODOO_SHIELD_3_6251 = 6251;
  
  public static final int BROODOO_SHIELD_2_6253 = 6253;
  
  public static final int BROODOO_SHIELD_1_6255 = 6255;
  
  public static final int BROODOO_SHIELD_6257 = 6257;
  
  public static final int BROODOO_SHIELD_10_6259 = 6259;
  
  public static final int BROODOO_SHIELD_9_6261 = 6261;
  
  public static final int BROODOO_SHIELD_8_6263 = 6263;
  
  public static final int BROODOO_SHIELD_7_6265 = 6265;
  
  public static final int BROODOO_SHIELD_6_6267 = 6267;
  
  public static final int BROODOO_SHIELD_5_6269 = 6269;
  
  public static final int BROODOO_SHIELD_4_6271 = 6271;
  
  public static final int BROODOO_SHIELD_3_6273 = 6273;
  
  public static final int BROODOO_SHIELD_2_6275 = 6275;
  
  public static final int BROODOO_SHIELD_1_6277 = 6277;
  
  public static final int BROODOO_SHIELD_6279 = 6279;
  
  public static final int THATCH_SPAR_LIGHT = 6281;
  
  public static final int THATCH_SPAR_MED = 6283;
  
  public static final int THATCH_SPAR_DENSE = 6285;
  
  public static final int SNAKE_HIDE = 6287;
  
  public static final int SNAKESKIN = 6289;
  
  public static final int SPIDER_CARCASS = 6291;
  
  public static final int SPIDER_ON_STICK = 6293;
  
  public static final int SPIDER_ON_SHAFT = 6295;
  
  public static final int SPIDER_ON_STICK_6297 = 6297;
  
  public static final int SPIDER_ON_SHAFT_6299 = 6299;
  
  public static final int BURNT_SPIDER = 6301;
  
  public static final int SPIDER_ON_SHAFT_6303 = 6303;
  
  public static final int SKEWER_STICK = 6305;
  
  public static final int TRADING_STICKS = 6306;
  
  public static final int GOUT_TUBER = 6311;
  
  public static final int OPAL_MACHETE = 6313;
  
  public static final int JADE_MACHETE = 6315;
  
  public static final int RED_TOPAZ_MACHETE = 6317;
  
  public static final int PROBOSCIS = 6319;
  
  public static final int SNAKESKIN_BODY = 6322;
  
  public static final int SNAKESKIN_CHAPS = 6324;
  
  public static final int SNAKESKIN_BANDANA = 6326;
  
  public static final int SNAKESKIN_BOOTS = 6328;
  
  public static final int SNAKESKIN_VAMBRACES = 6330;
  
  public static final int MAHOGANY_LOGS = 6332;
  
  public static final int TEAK_LOGS = 6333;
  
  public static final int TRIBAL_MASK = 6335;
  
  public static final int TRIBAL_MASK_6337 = 6337;
  
  public static final int TRIBAL_MASK_6339 = 6339;
  
  public static final int TRIBAL_TOP = 6341;
  
  public static final int VILLAGER_ROBE = 6343;
  
  public static final int VILLAGER_HAT = 6345;
  
  public static final int VILLAGER_ARMBAND = 6347;
  
  public static final int VILLAGER_SANDALS = 6349;
  
  public static final int TRIBAL_TOP_6351 = 6351;
  
  public static final int VILLAGER_ROBE_6353 = 6353;
  
  public static final int VILLAGER_HAT_6355 = 6355;
  
  public static final int VILLAGER_SANDALS_6357 = 6357;
  
  public static final int VILLAGER_ARMBAND_6359 = 6359;
  
  public static final int TRIBAL_TOP_6361 = 6361;
  
  public static final int VILLAGER_ROBE_6363 = 6363;
  
  public static final int VILLAGER_HAT_6365 = 6365;
  
  public static final int VILLAGER_SANDALS_6367 = 6367;
  
  public static final int VILLAGER_ARMBAND_6369 = 6369;
  
  public static final int TRIBAL_TOP_6371 = 6371;
  
  public static final int VILLAGER_ROBE_6373 = 6373;
  
  public static final int VILLAGER_HAT_6375 = 6375;
  
  public static final int VILLAGER_SANDALS_6377 = 6377;
  
  public static final int VILLAGER_ARMBAND_6379 = 6379;
  
  public static final int FEZ = 6382;
  
  public static final int DESERT_TOP = 6384;
  
  public static final int DESERT_ROBES = 6386;
  
  public static final int DESERT_TOP_6388 = 6388;
  
  public static final int DESERT_LEGS = 6390;
  
  public static final int MENAPHITE_PURPLE_HAT = 6392;
  
  public static final int MENAPHITE_PURPLE_TOP = 6394;
  
  public static final int MENAPHITE_PURPLE_ROBE = 6396;
  
  public static final int MENAPHITE_PURPLE_KILT = 6398;
  
  public static final int MENAPHITE_RED_HAT = 6400;
  
  public static final int MENAPHITE_RED_TOP = 6402;
  
  public static final int MENAPHITE_RED_ROBE = 6404;
  
  public static final int MENAPHITE_RED_KILT = 6406;
  
  public static final int OAK_BLACKJACKO = 6408;
  
  public static final int OAK_BLACKJACKD = 6410;
  
  public static final int WILLOW_BLACKJACKO = 6412;
  
  public static final int WILLOW_BLACKJACKD = 6414;
  
  public static final int MAPLE_BLACKJACK = 6416;
  
  public static final int MAPLE_BLACKJACKO = 6418;
  
  public static final int MAPLE_BLACKJACKD = 6420;
  
  public static final int AIR_RUNE_6422 = 6422;
  
  public static final int WATER_RUNE_6424 = 6424;
  
  public static final int EARTH_RUNE_6426 = 6426;
  
  public static final int FIRE_RUNE_6428 = 6428;
  
  public static final int CHAOS_RUNE_6430 = 6430;
  
  public static final int DEATH_RUNE_6432 = 6432;
  
  public static final int LAW_RUNE_6434 = 6434;
  
  public static final int MIND_RUNE_6436 = 6436;
  
  public static final int BODY_RUNE_6438 = 6438;
  
  public static final int SPADEFUL_OF_COKE = 6448;
  
  public static final int KANDARIN_HEADGEAR = 6450;
  
  public static final int MAGE_ARENA_CAPE = 6452;
  
  public static final int WHITE_ROSE_SEED = 6453;
  
  public static final int RED_ROSE_SEED = 6454;
  
  public static final int PINK_ROSE_SEED = 6455;
  
  public static final int VINE_SEED = 6456;
  
  public static final int DELPHINIUM_SEED = 6457;
  
  public static final int ORCHID_SEED = 6458;
  
  public static final int ORCHID_SEED_6459 = 6459;
  
  public static final int SNOWDROP_SEED = 6460;
  
  public static final int WHITE_TREE_SHOOT = 6461;
  
  public static final int WHITE_TREE_SHOOT_6462 = 6462;
  
  public static final int WHITE_TREE_SHOOT_W = 6463;
  
  public static final int WHITE_TREE_SAPLING = 6464;
  
  public static final int RING_OF_CHAROSA = 6465;
  
  public static final int RUNE_SHARDS = 6466;
  
  public static final int RUNE_DUST = 6467;
  
  public static final int PLANT_CURE_6468 = 6468;
  
  public static final int WHITE_TREE_FRUIT = 6469;
  
  public static final int COMPOST_POTION4 = 6470;
  
  public static final int COMPOST_POTION3 = 6472;
  
  public static final int COMPOST_POTION2 = 6474;
  
  public static final int COMPOST_POTION1 = 6476;
  
  public static final int TROLLEY = 6478;
  
  public static final int LIST = 6479;
  
  public static final int AGILITY_JUMP = 6514;
  
  public static final int AGILITY_BALANCE = 6515;
  
  public static final int AGILITY_CONTORTION = 6516;
  
  public static final int AGILITY_CLIMB = 6517;
  
  public static final int AGILITY_JUMP_6518 = 6518;
  
  public static final int AGILITY_BALANCE_6519 = 6519;
  
  public static final int AGILITY_CONTORTION_6520 = 6520;
  
  public static final int AGILITY_CLIMB_6521 = 6521;
  
  public static final int TOKTZXILUL = 6522;
  
  public static final int TOKTZXILAK = 6523;
  
  public static final int TOKTZKETXIL = 6524;
  
  public static final int TOKTZXILEK = 6525;
  
  public static final int TOKTZMEJTAL = 6526;
  
  public static final int TZHAARKETEM = 6527;
  
  public static final int TZHAARKETOM = 6528;
  
  public static final int TOKKUL = 6529;
  
  public static final int MOUSE_TOY = 6541;
  
  public static final int PRESENT = 6542;
  
  public static final int ANTIQUE_LAMP_6543 = 6543;
  
  public static final int CATSPEAK_AMULETE = 6544;
  
  public static final int CHORES = 6545;
  
  public static final int RECIPE = 6546;
  
  public static final int DOCTORS_HAT = 6547;
  
  public static final int NURSE_HAT = 6548;
  
  public static final int LAZY_CAT = 6549;
  
  public static final int LAZY_CAT_6550 = 6550;
  
  public static final int LAZY_CAT_6551 = 6551;
  
  public static final int LAZY_CAT_6552 = 6552;
  
  public static final int LAZY_CAT_6553 = 6553;
  
  public static final int LAZY_CAT_6554 = 6554;
  
  public static final int WILY_CAT = 6555;
  
  public static final int WILY_CAT_6556 = 6556;
  
  public static final int WILY_CAT_6557 = 6557;
  
  public static final int WILY_CAT_6558 = 6558;
  
  public static final int WILY_CAT_6559 = 6559;
  
  public static final int WILY_CAT_6560 = 6560;
  
  public static final int AHABS_BEER = 6561;
  
  public static final int MUD_BATTLESTAFF = 6562;
  
  public static final int MYSTIC_MUD_STAFF = 6563;
  
  public static final int OBSIDIAN_CAPE = 6568;
  
  public static final int FIRE_CAPE = 6570;
  
  public static final int UNCUT_ONYX = 6571;
  
  public static final int ONYX = 6573;
  
  public static final int ONYX_RING = 6575;
  
  public static final int ONYX_NECKLACE = 6577;
  
  public static final int ONYX_AMULET_U = 6579;
  
  public static final int ONYX_AMULET = 6581;
  
  public static final int RING_OF_STONE = 6583;
  
  public static final int AMULET_OF_FURY = 6585;
  
  public static final int WHITE_CLAWS = 6587;
  
  public static final int WHITE_BATTLEAXE = 6589;
  
  public static final int WHITE_DAGGER = 6591;
  
  public static final int WHITE_DAGGERP = 6593;
  
  public static final int WHITE_DAGGERP_6595 = 6595;
  
  public static final int WHITE_DAGGERP_6597 = 6597;
  
  public static final int WHITE_HALBERD = 6599;
  
  public static final int WHITE_MACE = 6601;
  
  public static final int WHITE_MAGIC_STAFF = 6603;
  
  public static final int WHITE_SWORD = 6605;
  
  public static final int WHITE_LONGSWORD = 6607;
  
  public static final int WHITE_2H_SWORD = 6609;
  
  public static final int WHITE_SCIMITAR = 6611;
  
  public static final int WHITE_WARHAMMER = 6613;
  
  public static final int WHITE_CHAINBODY = 6615;
  
  public static final int WHITE_PLATEBODY = 6617;
  
  public static final int WHITE_BOOTS = 6619;
  
  public static final int WHITE_MED_HELM = 6621;
  
  public static final int WHITE_FULL_HELM = 6623;
  
  public static final int WHITE_PLATELEGS = 6625;
  
  public static final int WHITE_PLATESKIRT = 6627;
  
  public static final int WHITE_GLOVES = 6629;
  
  public static final int WHITE_SQ_SHIELD = 6631;
  
  public static final int WHITE_KITESHIELD = 6633;
  
  public static final int COMMORB = 6635;
  
  public static final int SOLUSS_HAT = 6636;
  
  public static final int DARK_BEAST = 6637;
  
  public static final int COLOUR_WHEEL = 6638;
  
  public static final int HAND_MIRROR = 6639;
  
  public static final int RED_CRYSTAL = 6640;
  
  public static final int YELLOW_CRYSTAL = 6641;
  
  public static final int GREEN_CRYSTAL = 6642;
  
  public static final int CYAN_CRYSTAL = 6643;
  
  public static final int BLUE_CRYSTAL = 6644;
  
  public static final int MAGENTA_CRYSTAL = 6645;
  
  public static final int FRACTURED_CRYSTAL = 6646;
  
  public static final int FRACTURED_CRYSTAL_6647 = 6647;
  
  public static final int ITEM_LIST = 6648;
  
  public static final int EDERNS_JOURNAL = 6649;
  
  public static final int BLACKENED_CRYSTAL = 6650;
  
  public static final int NEWLY_MADE_CRYSTAL = 6651;
  
  public static final int NEWLY_MADE_CRYSTAL_6652 = 6652;
  
  public static final int CRYSTAL_TRINKET = 6653;
  
  public static final int CAMO_TOP = 6654;
  
  public static final int CAMO_BOTTOMS = 6655;
  
  public static final int CAMO_HELMET = 6656;
  
  public static final int CAMO_TOP_6657 = 6657;
  
  public static final int CAMO_BOTTOMS_6658 = 6658;
  
  public static final int CAMO_HELMET_6659 = 6659;
  
  public static final int FISHING_EXPLOSIVE = 6660;
  
  public static final int MOGRE = 6661;
  
  public static final int BROKEN_FISHING_ROD = 6662;
  
  public static final int FORLORN_BOOT = 6663;
  
  public static final int FISHING_EXPLOSIVE_6664 = 6664;
  
  public static final int MUDSKIPPER_HAT = 6665;
  
  public static final int FLIPPERS = 6666;
  
  public static final int EMPTY_FISHBOWL = 6667;
  
  public static final int FISHBOWL = 6668;
  
  public static final int FISHBOWL_6669 = 6669;
  
  public static final int FISHBOWL_6670 = 6670;
  
  public static final int FISHBOWL_6671 = 6671;
  
  public static final int FISHBOWL_6672 = 6672;
  
  public static final int FISHBOWL_AND_NET = 6673;
  
  public static final int TINY_NET = 6674;
  
  public static final int AN_EMPTY_BOX = 6675;
  
  public static final int GUAM_IN_A_BOX = 6677;
  
  public static final int GUAM_IN_A_BOX_6678 = 6678;
  
  public static final int SEAWEED_IN_A_BOX = 6679;
  
  public static final int SEAWEED_IN_A_BOX_6680 = 6680;
  
  public static final int GROUND_GUAM = 6681;
  
  public static final int GROUND_SEAWEED = 6683;
  
  public static final int SARADOMIN_BREW4 = 6685;
  
  public static final int SARADOMIN_BREW3 = 6687;
  
  public static final int SARADOMIN_BREW2 = 6689;
  
  public static final int SARADOMIN_BREW1 = 6691;
  
  public static final int CRUSHED_NEST = 6693;
  
  public static final int DESERT_LIZARD = 6695;
  
  public static final int ICE_COOLER = 6696;
  
  public static final int PAT_OF_BUTTER = 6697;
  
  public static final int BURNT_POTATO = 6699;
  
  public static final int BAKED_POTATO = 6701;
  
  public static final int POTATO_WITH_BUTTER = 6703;
  
  public static final int POTATO_WITH_CHEESE = 6705;
  
  public static final int CAMULET = 6707;
  
  public static final int SLAYER_GLOVES = 6708;
  
  public static final int FEVER_SPIDER = 6709;
  
  public static final int BLINDWEED_SEED = 6710;
  
  public static final int BLINDWEED = 6711;
  
  public static final int BUCKET_OF_WATER_6712 = 6712;
  
  public static final int WRENCH = 6713;
  
  public static final int HOLY_WRENCH = 6714;
  
  public static final int SLUGLINGS = 6715;
  
  public static final int KARAMTHULHU = 6716;
  
  public static final int KARAMTHULHU_6717 = 6717;
  
  public static final int FEVER_SPIDER_BODY = 6718;
  
  public static final int UNSANITARY_SWILL = 6719;
  
  public static final int SLAYER_GLOVES_6720 = 6720;
  
  public static final int RUSTY_SCIMITAR = 6721;
  
  public static final int ZOMBIE_HEAD = 6722;
  
  public static final int SEERCULL = 6724;
  
  public static final int DAGANNOTHKING_BONEMEAL = 6728;
  
  public static final int DAGANNOTH_BONES = 6729;
  
  public static final int SEERS_RING = 6731;
  
  public static final int ARCHERS_RING = 6733;
  
  public static final int WARRIOR_RING = 6735;
  
  public static final int BERSERKER_RING = 6737;
  
  public static final int DRAGON_AXE = 6739;
  
  public static final int BROKEN_AXE_6741 = 6741;
  
  public static final int DRAGON_AXE_HEAD = 6743;
  
  public static final int SILVERLIGHT_6745 = 6745;
  
  public static final int DARKLIGHT = 6746;
  
  public static final int DEMONIC_SIGIL_MOULD = 6747;
  
  public static final int DEMONIC_SIGIL = 6748;
  
  public static final int DEMONIC_TOME = 6749;
  
  public static final int BLACK_DESERT_SHIRT = 6750;
  
  public static final int BLACK_DESERT_ROBE = 6752;
  
  public static final int ENCHANTED_KEY = 6754;
  
  public static final int JOURNAL_6755 = 6755;
  
  public static final int LETTER_6756 = 6756;
  
  public static final int LETTER_6757 = 6757;
  
  public static final int SCROLL = 6758;
  
  public static final int CHEST = 6759;
  
  public static final int GUTHIX_MJOLNIR = 6760;
  
  public static final int SARADOMIN_MJOLNIR = 6762;
  
  public static final int ZAMORAK_MJOLNIR = 6764;
  
  public static final int CAT_ANTIPOISON = 6766;
  
  public static final int BOOK_6767 = 6767;
  
  public static final int POISONED_CHEESE = 6768;
  
  public static final int MUSIC_SCROLL = 6769;
  
  public static final int DIRECTIONS = 6770;
  
  public static final int POT_OF_WEEDS = 6771;
  
  public static final int SMOULDERING_POT = 6772;
  
  public static final int RAT_POLE = 6773;
  
  public static final int RAT_POLE_6774 = 6774;
  
  public static final int RAT_POLE_6775 = 6775;
  
  public static final int RAT_POLE_6776 = 6776;
  
  public static final int RAT_POLE_6777 = 6777;
  
  public static final int RAT_POLE_6778 = 6778;
  
  public static final int RAT_POLE_6779 = 6779;
  
  public static final int MENAPHITE_THUG = 6780;
  
  public static final int BANDIT_6781 = 6781;
  
  public static final int BANDIT_6782 = 6782;
  
  public static final int STATUETTE_6785 = 6785;
  
  public static final int ROBE_OF_ELIDINIS = 6786;
  
  public static final int ROBE_OF_ELIDINIS_6787 = 6787;
  
  public static final int TORN_ROBE = 6788;
  
  public static final int TORN_ROBE_6789 = 6789;
  
  public static final int SHOES = 6790;
  
  public static final int SOLE = 6791;
  
  public static final int ANCESTRAL_KEY = 6792;
  
  public static final int BALLAD = 6793;
  
  public static final int CHOCICE = 6794;
  
  public static final int LAMP_6796 = 6796;
  
  public static final int WATERING_CAN_6797 = 6797;
  
  public static final int EARTH_WARRIOR_CHAMPION_SCROLL = 6798;
  
  public static final int GHOUL_CHAMPION_SCROLL = 6799;
  
  public static final int GIANT_CHAMPION_SCROLL = 6800;
  
  public static final int GOBLIN_CHAMPION_SCROLL = 6801;
  
  public static final int HOBGOBLIN_CHAMPION_SCROLL = 6802;
  
  public static final int IMP_CHAMPION_SCROLL = 6803;
  
  public static final int JOGRE_CHAMPION_SCROLL = 6804;
  
  public static final int LESSER_DEMON_CHAMPION_SCROLL = 6805;
  
  public static final int SKELETON_CHAMPION_SCROLL = 6806;
  
  public static final int ZOMBIE_CHAMPION_SCROLL = 6807;
  
  public static final int LEONS_CHAMPION_SCROLL = 6808;
  
  public static final int GRANITE_LEGS = 6809;
  
  public static final int WYVERN_BONEMEAL = 6810;
  
  public static final int SKELETAL_WYVERN = 6811;
  
  public static final int WYVERN_BONES = 6812;
  
  public static final int FUR = 6814;
  
  public static final int SLENDER_BLADE = 6817;
  
  public static final int BOWSWORD = 6818;
  
  public static final int LARGE_POUCH_6819 = 6819;
  
  public static final int RELIC = 6820;
  
  public static final int ORB = 6821;
  
  public static final int STAR_BAUBLE = 6822;
  
  public static final int STAR_BAUBLE_6823 = 6823;
  
  public static final int STAR_BAUBLE_6824 = 6824;
  
  public static final int STAR_BAUBLE_6825 = 6825;
  
  public static final int STAR_BAUBLE_6826 = 6826;
  
  public static final int STAR_BAUBLE_6827 = 6827;
  
  public static final int BOX_BAUBLE = 6828;
  
  public static final int BOX_BAUBLE_6829 = 6829;
  
  public static final int BOX_BAUBLE_6830 = 6830;
  
  public static final int BOX_BAUBLE_6831 = 6831;
  
  public static final int BOX_BAUBLE_6832 = 6832;
  
  public static final int BOX_BAUBLE_6833 = 6833;
  
  public static final int DIAMOND_BAUBLE = 6834;
  
  public static final int DIAMOND_BAUBLE_6835 = 6835;
  
  public static final int DIAMOND_BAUBLE_6836 = 6836;
  
  public static final int DIAMOND_BAUBLE_6837 = 6837;
  
  public static final int DIAMOND_BAUBLE_6838 = 6838;
  
  public static final int DIAMOND_BAUBLE_6839 = 6839;
  
  public static final int TREE_BAUBLE = 6840;
  
  public static final int TREE_BAUBLE_6841 = 6841;
  
  public static final int TREE_BAUBLE_6842 = 6842;
  
  public static final int TREE_BAUBLE_6843 = 6843;
  
  public static final int TREE_BAUBLE_6844 = 6844;
  
  public static final int TREE_BAUBLE_6845 = 6845;
  
  public static final int BELL_BAUBLE = 6846;
  
  public static final int BELL_BAUBLE_6847 = 6847;
  
  public static final int BELL_BAUBLE_6848 = 6848;
  
  public static final int BELL_BAUBLE_6849 = 6849;
  
  public static final int BELL_BAUBLE_6850 = 6850;
  
  public static final int BELL_BAUBLE_6851 = 6851;
  
  public static final int PUPPET_BOX = 6852;
  
  public static final int BAUBLE_BOX = 6853;
  
  public static final int PUPPET_BOX_6854 = 6854;
  
  public static final int BAUBLE_BOX_6855 = 6855;
  
  public static final int BOBBLE_HAT = 6856;
  
  public static final int BOBBLE_SCARF = 6857;
  
  public static final int JESTER_HAT = 6858;
  
  public static final int JESTER_SCARF = 6859;
  
  public static final int TRIJESTER_HAT = 6860;
  
  public static final int TRIJESTER_SCARF = 6861;
  
  public static final int WOOLLY_HAT = 6862;
  
  public static final int WOOLLY_SCARF = 6863;
  
  public static final int MARIONETTE_HANDLE = 6864;
  
  public static final int BLUE_MARIONETTE = 6865;
  
  public static final int GREEN_MARIONETTE = 6866;
  
  public static final int RED_MARIONETTE = 6867;
  
  public static final int BLUE_MARIONETTE_6868 = 6868;
  
  public static final int GREEN_MARIONETTE_6869 = 6869;
  
  public static final int RED_MARIONETTE_6870 = 6870;
  
  public static final int RED_MARIONETTE_6871 = 6871;
  
  public static final int RED_MARIONETTE_6872 = 6872;
  
  public static final int RED_MARIONETTE_6873 = 6873;
  
  public static final int RED_MARIONETTE_6874 = 6874;
  
  public static final int BLUE_MARIONETTE_6875 = 6875;
  
  public static final int BLUE_MARIONETTE_6876 = 6876;
  
  public static final int BLUE_MARIONETTE_6877 = 6877;
  
  public static final int BLUE_MARIONETTE_6878 = 6878;
  
  public static final int GREEN_MARIONETTE_6879 = 6879;
  
  public static final int GREEN_MARIONETTE_6880 = 6880;
  
  public static final int GREEN_MARIONETTE_6881 = 6881;
  
  public static final int GREEN_MARIONETTE_6882 = 6882;
  
  public static final int PEACH = 6883;
  
  public static final int PROGRESS_HAT = 6885;
  
  public static final int PROGRESS_HAT_6886 = 6886;
  
  public static final int PROGRESS_HAT_6887 = 6887;
  
  public static final int MAGES_BOOK = 6889;
  
  public static final int ARENA_BOOK = 6891;
  
  public static final int LEATHER_BOOTS_6893 = 6893;
  
  public static final int ADAMANT_KITESHIELD_6894 = 6894;
  
  public static final int ADAMANT_MED_HELM_6895 = 6895;
  
  public static final int EMERALD_6896 = 6896;
  
  public static final int RUNE_LONGSWORD_6897 = 6897;
  
  public static final int CYLINDER = 6898;
  
  public static final int CUBE = 6899;
  
  public static final int ICOSAHEDRON = 6900;
  
  public static final int PENTAMID = 6901;
  
  public static final int ORB_6902 = 6902;
  
  public static final int DRAGONSTONE_6903 = 6903;
  
  public static final int ANIMALS_BONES = 6904;
  
  public static final int ANIMALS_BONES_6905 = 6905;
  
  public static final int ANIMALS_BONES_6906 = 6906;
  
  public static final int ANIMALS_BONES_6907 = 6907;
  
  public static final int BEGINNER_WAND = 6908;
  
  public static final int APPRENTICE_WAND = 6910;
  
  public static final int TEACHER_WAND = 6912;
  
  public static final int MASTER_WAND = 6914;
  
  public static final int INFINITY_TOP = 6916;
  
  public static final int INFINITY_HAT = 6918;
  
  public static final int INFINITY_BOOTS = 6920;
  
  public static final int INFINITY_GLOVES = 6922;
  
  public static final int INFINITY_BOTTOMS = 6924;
  
  public static final int BONES_TO_PEACHES = 6926;
  
  public static final int SANDY_HAND = 6945;
  
  public static final int BEER_SOAKED_HAND = 6946;
  
  public static final int BERTS_ROTA = 6947;
  
  public static final int SANDYS_ROTA = 6948;
  
  public static final int A_MAGIC_SCROLL = 6949;
  
  public static final int MAGICAL_ORB = 6950;
  
  public static final int MAGICAL_ORB_A = 6951;
  
  public static final int TRUTH_SERUM = 6952;
  
  public static final int BOTTLED_WATER = 6953;
  
  public static final int REDBERRY_JUICE = 6954;
  
  public static final int PINK_DYE = 6955;
  
  public static final int ROSETINTED_LENS = 6956;
  
  public static final int WIZARDS_HEAD = 6957;
  
  public static final int SAND = 6958;
  
  public static final int PINK_CAPE = 6959;
  
  public static final int BAGUETTE = 6961;
  
  public static final int TRIANGLE_SANDWICH = 6962;
  
  public static final int ROLL = 6963;
  
  public static final int COINS_6964 = 6964;
  
  public static final int SQUARE_SANDWICH = 6965;
  
  public static final int PRISON_KEY_6966 = 6966;
  
  public static final int DRAGON_MED_HELM_6967 = 6967;
  
  public static final int SHARK_6969 = 6969;
  
  public static final int PYRAMID_TOP = 6970;
  
  public static final int SANDSTONE_1KG = 6971;
  
  public static final int SANDSTONE_2KG = 6973;
  
  public static final int SANDSTONE_5KG = 6975;
  
  public static final int SANDSTONE_10KG = 6977;
  
  public static final int GRANITE_500G = 6979;
  
  public static final int GRANITE_2KG = 6981;
  
  public static final int GRANITE_5KG = 6983;
  
  public static final int SANDSTONE_20KG = 6985;
  
  public static final int SANDSTONE_32KG = 6986;
  
  public static final int SANDSTONE_BODY = 6987;
  
  public static final int SANDSTONE_BASE = 6988;
  
  public static final int STONE_HEAD = 6989;
  
  public static final int STONE_HEAD_6990 = 6990;
  
  public static final int STONE_HEAD_6991 = 6991;
  
  public static final int STONE_HEAD_6992 = 6992;
  
  public static final int Z_SIGIL = 6993;
  
  public static final int M_SIGIL = 6994;
  
  public static final int R_SIGIL = 6995;
  
  public static final int K_SIGIL = 6996;
  
  public static final int STONE_LEFT_ARM = 6997;
  
  public static final int STONE_RIGHT_ARM = 6998;
  
  public static final int STONE_LEFT_LEG = 6999;
  
  public static final int STONE_RIGHT_LEG = 7000;
  
  public static final int CAMEL_MOULD_P = 7001;
  
  public static final int STONE_HEAD_7002 = 7002;
  
  public static final int CAMEL_MASK = 7003;
  
  public static final int SWARM = 7050;
  
  public static final int UNLIT_BUG_LANTERN = 7051;
  
  public static final int LIT_BUG_LANTERN = 7053;
  
  public static final int CHILLI_POTATO = 7054;
  
  public static final int EGG_POTATO = 7056;
  
  public static final int MUSHROOM_POTATO = 7058;
  
  public static final int TUNA_POTATO = 7060;
  
  public static final int CHILLI_CON_CARNE = 7062;
  
  public static final int EGG_AND_TOMATO = 7064;
  
  public static final int MUSHROOM__ONION = 7066;
  
  public static final int TUNA_AND_CORN = 7068;
  
  public static final int MINCED_MEAT = 7070;
  
  public static final int SPICY_SAUCE = 7072;
  
  public static final int CHOPPED_GARLIC = 7074;
  
  public static final int UNCOOKED_EGG = 7076;
  
  public static final int SCRAMBLED_EGG = 7078;
  
  public static final int SLICED_MUSHROOMS = 7080;
  
  public static final int FRIED_MUSHROOMS = 7082;
  
  public static final int FRIED_ONIONS = 7084;
  
  public static final int CHOPPED_TUNA = 7086;
  
  public static final int SWEETCORN_7088 = 7088;
  
  public static final int BURNT_EGG = 7090;
  
  public static final int BURNT_ONION = 7092;
  
  public static final int BURNT_MUSHROOM = 7094;
  
  public static final int BOARD_GAME_PIECE_7096 = 7096;
  
  public static final int BOARD_GAME_PIECE_7097 = 7097;
  
  public static final int BOARD_GAME_PIECE_7098 = 7098;
  
  public static final int BOARD_GAME_PIECE_7099 = 7099;
  
  public static final int BOARD_GAME_PIECE_7100 = 7100;
  
  public static final int BOARD_GAME_PIECE_7101 = 7101;
  
  public static final int BOARD_GAME_PIECE_7102 = 7102;
  
  public static final int BOARD_GAME_PIECE_7103 = 7103;
  
  public static final int BOARD_GAME_PIECE_7104 = 7104;
  
  public static final int BOARD_GAME_PIECE_7105 = 7105;
  
  public static final int BOARD_GAME_PIECE_7106 = 7106;
  
  public static final int BOARD_GAME_PIECE_7107 = 7107;
  
  public static final int GUNPOWDER = 7108;
  
  public static final int FUSE = 7109;
  
  public static final int STRIPY_PIRATE_SHIRT = 7110;
  
  public static final int PIRATE_BANDANA = 7112;
  
  public static final int PIRATE_BOOTS = 7114;
  
  public static final int PIRATE_LEGGINGS = 7116;
  
  public static final int CANISTER = 7118;
  
  public static final int CANNON_BALL_7119 = 7119;
  
  public static final int RAMROD = 7120;
  
  public static final int REPAIR_PLANK = 7121;
  
  public static final int STRIPY_PIRATE_SHIRT_7122 = 7122;
  
  public static final int PIRATE_BANDANA_7124 = 7124;
  
  public static final int PIRATE_LEGGINGS_7126 = 7126;
  
  public static final int STRIPY_PIRATE_SHIRT_7128 = 7128;
  
  public static final int PIRATE_BANDANA_7130 = 7130;
  
  public static final int PIRATE_LEGGINGS_7132 = 7132;
  
  public static final int STRIPY_PIRATE_SHIRT_7134 = 7134;
  
  public static final int PIRATE_BANDANA_7136 = 7136;
  
  public static final int PIRATE_LEGGINGS_7138 = 7138;
  
  public static final int LUCKY_CUTLASS = 7140;
  
  public static final int HARRYS_CUTLASS = 7141;
  
  public static final int RAPIER = 7142;
  
  public static final int PLUNDER = 7143;
  
  public static final int BOOK_O_PIRACY = 7144;
  
  public static final int CANNON_BARREL = 7145;
  
  public static final int BROKEN_CANNON = 7146;
  
  public static final int CANNON_BALLS = 7147;
  
  public static final int REPAIR_PLANK_7148 = 7148;
  
  public static final int CANISTER_7149 = 7149;
  
  public static final int TACKS = 7150;
  
  public static final int ROPE_7155 = 7155;
  
  public static final int TINDERBOX_7156 = 7156;
  
  public static final int BRAINDEATH_RUM = 7157;
  
  public static final int DRAGON_2H_SWORD = 7158;
  
  public static final int INSULATED_BOOTS = 7159;
  
  public static final int KILLERWATT = 7160;
  
  public static final int PIE_RECIPE_BOOK = 7162;
  
  public static final int PART_MUD_PIE = 7164;
  
  public static final int PART_MUD_PIE_7166 = 7166;
  
  public static final int RAW_MUD_PIE = 7168;
  
  public static final int MUD_PIE = 7170;
  
  public static final int PART_GARDEN_PIE = 7172;
  
  public static final int PART_GARDEN_PIE_7174 = 7174;
  
  public static final int RAW_GARDEN_PIE = 7176;
  
  public static final int GARDEN_PIE = 7178;
  
  public static final int HALF_A_GARDEN_PIE = 7180;
  
  public static final int PART_FISH_PIE = 7182;
  
  public static final int PART_FISH_PIE_7184 = 7184;
  
  public static final int RAW_FISH_PIE = 7186;
  
  public static final int FISH_PIE = 7188;
  
  public static final int HALF_A_FISH_PIE = 7190;
  
  public static final int PART_ADMIRAL_PIE = 7192;
  
  public static final int PART_ADMIRAL_PIE_7194 = 7194;
  
  public static final int RAW_ADMIRAL_PIE = 7196;
  
  public static final int ADMIRAL_PIE = 7198;
  
  public static final int HALF_AN_ADMIRAL_PIE = 7200;
  
  public static final int PART_WILD_PIE = 7202;
  
  public static final int PART_WILD_PIE_7204 = 7204;
  
  public static final int RAW_WILD_PIE = 7206;
  
  public static final int WILD_PIE = 7208;
  
  public static final int HALF_A_WILD_PIE = 7210;
  
  public static final int PART_SUMMER_PIE = 7212;
  
  public static final int PART_SUMMER_PIE_7214 = 7214;
  
  public static final int RAW_SUMMER_PIE = 7216;
  
  public static final int SUMMER_PIE = 7218;
  
  public static final int HALF_A_SUMMER_PIE = 7220;
  
  public static final int BURNT_RABBIT = 7222;
  
  public static final int ROAST_RABBIT = 7223;
  
  public static final int SKEWERED_RABBIT = 7224;
  
  public static final int IRON_SPIT = 7225;
  
  public static final int BURNT_CHOMPY = 7226;
  
  public static final int COOKED_CHOMPY_7228 = 7228;
  
  public static final int SKEWERED_CHOMPY = 7230;
  
  public static final int CLUE_SCROLL_EASY_7236 = 7236;
  
  public static final int CASKET_EASY_7237 = 7237;
  
  public static final int CLUE_SCROLL_EASY_7238 = 7238;
  
  public static final int CLUE_SCROLL_HARD_7239 = 7239;
  
  public static final int CASKET_HARD_7240 = 7240;
  
  public static final int CLUE_SCROLL_HARD_7241 = 7241;
  
  public static final int CASKET_HARD_7242 = 7242;
  
  public static final int CLUE_SCROLL_HARD_7243 = 7243;
  
  public static final int CASKET_HARD_7244 = 7244;
  
  public static final int CLUE_SCROLL_HARD_7245 = 7245;
  
  public static final int CASKET_HARD_7246 = 7246;
  
  public static final int CLUE_SCROLL_HARD_7247 = 7247;
  
  public static final int CLUE_SCROLL_HARD_7248 = 7248;
  
  public static final int CLUE_SCROLL_HARD_7249 = 7249;
  
  public static final int CLUE_SCROLL_HARD_7250 = 7250;
  
  public static final int CLUE_SCROLL_HARD_7251 = 7251;
  
  public static final int CLUE_SCROLL_HARD_7252 = 7252;
  
  public static final int CLUE_SCROLL_HARD_7253 = 7253;
  
  public static final int CLUE_SCROLL_HARD_7254 = 7254;
  
  public static final int CLUE_SCROLL_HARD_7255 = 7255;
  
  public static final int CLUE_SCROLL_HARD_7256 = 7256;
  
  public static final int CASKET_HARD_7257 = 7257;
  
  public static final int CLUE_SCROLL_HARD_7258 = 7258;
  
  public static final int CASKET_HARD_7259 = 7259;
  
  public static final int CLUE_SCROLL_HARD_7260 = 7260;
  
  public static final int CASKET_HARD_7261 = 7261;
  
  public static final int CLUE_SCROLL_HARD_7262 = 7262;
  
  public static final int CASKET_HARD_7263 = 7263;
  
  public static final int CLUE_SCROLL_HARD_7264 = 7264;
  
  public static final int CASKET_HARD_7265 = 7265;
  
  public static final int CLUE_SCROLL_HARD_7266 = 7266;
  
  public static final int CASKET_HARD_7267 = 7267;
  
  public static final int CLUE_SCROLL_HARD_7268 = 7268;
  
  public static final int CHALLENGE_SCROLL_HARD = 7269;
  
  public static final int CLUE_SCROLL_HARD_7270 = 7270;
  
  public static final int CHALLENGE_SCROLL_HARD_7271 = 7271;
  
  public static final int CLUE_SCROLL_HARD_7272 = 7272;
  
  public static final int CHALLENGE_SCROLL_HARD_7273 = 7273;
  
  public static final int CLUE_SCROLL_MEDIUM_7274 = 7274;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7275 = 7275;
  
  public static final int CLUE_SCROLL_MEDIUM_7276 = 7276;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7277 = 7277;
  
  public static final int CLUE_SCROLL_MEDIUM_7278 = 7278;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7279 = 7279;
  
  public static final int CLUE_SCROLL_MEDIUM_7280 = 7280;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7281 = 7281;
  
  public static final int CLUE_SCROLL_MEDIUM_7282 = 7282;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7283 = 7283;
  
  public static final int CLUE_SCROLL_MEDIUM_7284 = 7284;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_7285 = 7285;
  
  public static final int CLUE_SCROLL_MEDIUM_7286 = 7286;
  
  public static final int CASKET_MEDIUM_7287 = 7287;
  
  public static final int CLUE_SCROLL_MEDIUM_7288 = 7288;
  
  public static final int CASKET_MEDIUM_7289 = 7289;
  
  public static final int CLUE_SCROLL_MEDIUM_7290 = 7290;
  
  public static final int CASKET_MEDIUM_7291 = 7291;
  
  public static final int CLUE_SCROLL_MEDIUM_7292 = 7292;
  
  public static final int CASKET_MEDIUM_7293 = 7293;
  
  public static final int CLUE_SCROLL_MEDIUM_7294 = 7294;
  
  public static final int CASKET_MEDIUM_7295 = 7295;
  
  public static final int CLUE_SCROLL_MEDIUM_7296 = 7296;
  
  public static final int KEY_MEDIUM_7297 = 7297;
  
  public static final int CLUE_SCROLL_MEDIUM_7298 = 7298;
  
  public static final int KEY_MEDIUM_7299 = 7299;
  
  public static final int CLUE_SCROLL_MEDIUM_7300 = 7300;
  
  public static final int CLUE_SCROLL_MEDIUM_7301 = 7301;
  
  public static final int KEY_MEDIUM_7302 = 7302;
  
  public static final int CLUE_SCROLL_MEDIUM_7303 = 7303;
  
  public static final int CLUE_SCROLL_MEDIUM_7304 = 7304;
  
  public static final int CLUE_SCROLL_MEDIUM_7305 = 7305;
  
  public static final int CASKET_MEDIUM_7306 = 7306;
  
  public static final int CLUE_SCROLL_MEDIUM_7307 = 7307;
  
  public static final int CASKET_MEDIUM_7308 = 7308;
  
  public static final int CLUE_SCROLL_MEDIUM_7309 = 7309;
  
  public static final int CASKET_MEDIUM_7310 = 7310;
  
  public static final int CLUE_SCROLL_MEDIUM_7311 = 7311;
  
  public static final int CASKET_MEDIUM_7312 = 7312;
  
  public static final int CLUE_SCROLL_MEDIUM_7313 = 7313;
  
  public static final int CASKET_MEDIUM_7314 = 7314;
  
  public static final int CLUE_SCROLL_MEDIUM_7315 = 7315;
  
  public static final int CASKET_MEDIUM_7316 = 7316;
  
  public static final int CLUE_SCROLL_MEDIUM_7317 = 7317;
  
  public static final int CASKET_MEDIUM_7318 = 7318;
  
  public static final int RED_BOATER = 7319;
  
  public static final int ORANGE_BOATER = 7321;
  
  public static final int GREEN_BOATER = 7323;
  
  public static final int BLUE_BOATER = 7325;
  
  public static final int BLACK_BOATER = 7327;
  
  public static final int RED_FIRELIGHTER = 7329;
  
  public static final int GREEN_FIRELIGHTER = 7330;
  
  public static final int BLUE_FIRELIGHTER = 7331;
  
  public static final int BLACK_SHIELD_H1 = 7332;
  
  public static final int ADAMANT_SHIELD_H1 = 7334;
  
  public static final int RUNE_SHIELD_H1 = 7336;
  
  public static final int BLACK_SHIELD_H2 = 7338;
  
  public static final int ADAMANT_SHIELD_H2 = 7340;
  
  public static final int RUNE_SHIELD_H2 = 7342;
  
  public static final int BLACK_SHIELD_H3 = 7344;
  
  public static final int ADAMANT_SHIELD_H3 = 7346;
  
  public static final int RUNE_SHIELD_H3 = 7348;
  
  public static final int BLACK_SHIELD_H4 = 7350;
  
  public static final int ADAMANT_SHIELD_H4 = 7352;
  
  public static final int RUNE_SHIELD_H4 = 7354;
  
  public static final int BLACK_SHIELD_H5 = 7356;
  
  public static final int ADAMANT_SHIELD_H5 = 7358;
  
  public static final int RUNE_SHIELD_H5 = 7360;
  
  public static final int STUDDED_BODY_G = 7362;
  
  public static final int STUDDED_BODY_T = 7364;
  
  public static final int STUDDED_CHAPS_G = 7366;
  
  public static final int STUDDED_CHAPS_T = 7368;
  
  public static final int GREEN_DHIDE_BODY_G = 7370;
  
  public static final int GREEN_DHIDE_BODY_T = 7372;
  
  public static final int BLUE_DHIDE_BODY_G = 7374;
  
  public static final int BLUE_DHIDE_BODY_T = 7376;
  
  public static final int GREEN_DHIDE_CHAPS_G = 7378;
  
  public static final int GREEN_DHIDE_CHAPS_T = 7380;
  
  public static final int BLUE_DHIDE_CHAPS_G = 7382;
  
  public static final int BLUE_DHIDE_CHAPS_T = 7384;
  
  public static final int BLUE_SKIRT_G = 7386;
  
  public static final int BLUE_SKIRT_T = 7388;
  
  public static final int BLUE_WIZARD_ROBE_G = 7390;
  
  public static final int BLUE_WIZARD_ROBE_T = 7392;
  
  public static final int BLUE_WIZARD_HAT_G = 7394;
  
  public static final int BLUE_WIZARD_HAT_T = 7396;
  
  public static final int ENCHANTED_ROBE = 7398;
  
  public static final int ENCHANTED_TOP = 7399;
  
  public static final int ENCHANTED_HAT = 7400;
  
  public static final int RED_LOGS = 7404;
  
  public static final int GREEN_LOGS = 7405;
  
  public static final int BLUE_LOGS = 7406;
  
  public static final int DRAYNOR_SKULL = 7408;
  
  public static final int MAGIC_SECATEURS = 7409;
  
  public static final int QUEENS_SECATEURS = 7410;
  
  public static final int SYMPTOMS_LIST = 7411;
  
  public static final int BIRD_NEST_7413 = 7413;
  
  public static final int PADDLE = 7414;
  
  public static final int MOLE_CLAW = 7416;
  
  public static final int MOLE_SKIN = 7418;
  
  public static final int MUTATED_ZYGOMITE = 7420;
  
  public static final int FUNGICIDE_SPRAY_10 = 7421;
  
  public static final int FUNGICIDE_SPRAY_9 = 7422;
  
  public static final int FUNGICIDE_SPRAY_8 = 7423;
  
  public static final int FUNGICIDE_SPRAY_7 = 7424;
  
  public static final int FUNGICIDE_SPRAY_6 = 7425;
  
  public static final int FUNGICIDE_SPRAY_5 = 7426;
  
  public static final int FUNGICIDE_SPRAY_4 = 7427;
  
  public static final int FUNGICIDE_SPRAY_3 = 7428;
  
  public static final int FUNGICIDE_SPRAY_2 = 7429;
  
  public static final int FUNGICIDE_SPRAY_1 = 7430;
  
  public static final int FUNGICIDE_SPRAY_0 = 7431;
  
  public static final int FUNGICIDE = 7432;
  
  public static final int WOODEN_SPOON = 7433;
  
  public static final int EGG_WHISK = 7435;
  
  public static final int SPORK = 7437;
  
  public static final int SPATULA = 7439;
  
  public static final int FRYING_PAN = 7441;
  
  public static final int SKEWER = 7443;
  
  public static final int ROLLING_PIN = 7445;
  
  public static final int KITCHEN_KNIFE = 7447;
  
  public static final int MEAT_TENDERISER = 7449;
  
  public static final int CLEAVER = 7451;
  
  public static final int HARDLEATHER_GLOVES = 7453;
  
  public static final int BRONZE_GLOVES = 7454;
  
  public static final int IRON_GLOVES = 7455;
  
  public static final int STEEL_GLOVES = 7456;
  
  public static final int BLACK_GLOVES = 7457;
  
  public static final int MITHRIL_GLOVES = 7458;
  
  public static final int ADAMANT_GLOVES = 7459;
  
  public static final int RUNE_GLOVES = 7460;
  
  public static final int DRAGON_GLOVES = 7461;
  
  public static final int BARROWS_GLOVES = 7462;
  
  public static final int CORNFLOUR = 7463;
  
  public static final int BOOK_ON_CHICKENS = 7464;
  
  public static final int VANILLA_POD = 7465;
  
  public static final int CORNFLOUR_7466 = 7466;
  
  public static final int POT_OF_CORNFLOUR = 7468;
  
  public static final int CORNFLOUR_MIXTURE = 7470;
  
  public static final int MILKY_MIXTURE = 7471;
  
  public static final int CINNAMON = 7472;
  
  public static final int BRULEE = 7473;
  
  public static final int BRULEE_7474 = 7474;
  
  public static final int BRULEE_7475 = 7475;
  
  public static final int BRULEE_SUPREME = 7476;
  
  public static final int EVIL_CHICKENS_EGG = 7477;
  
  public static final int DRAGON_TOKEN = 7478;
  
  public static final int SPICY_STEW = 7479;
  
  public static final int RED_SPICE_4 = 7480;
  
  public static final int RED_SPICE_3 = 7481;
  
  public static final int RED_SPICE_2 = 7482;
  
  public static final int RED_SPICE_1 = 7483;
  
  public static final int ORANGE_SPICE_4 = 7484;
  
  public static final int ORANGE_SPICE_3 = 7485;
  
  public static final int ORANGE_SPICE_2 = 7486;
  
  public static final int ORANGE_SPICE_1 = 7487;
  
  public static final int BROWN_SPICE_4 = 7488;
  
  public static final int BROWN_SPICE_3 = 7489;
  
  public static final int BROWN_SPICE_2 = 7490;
  
  public static final int BROWN_SPICE_1 = 7491;
  
  public static final int YELLOW_SPICE_4 = 7492;
  
  public static final int YELLOW_SPICE_3 = 7493;
  
  public static final int YELLOW_SPICE_2 = 7494;
  
  public static final int YELLOW_SPICE_1 = 7495;
  
  public static final int EMPTY_SPICE_SHAKER = 7496;
  
  public static final int DIRTY_BLAST = 7497;
  
  public static final int ANTIQUE_LAMP_7498 = 7498;
  
  public static final int ASGOLDIAN_ALE = 7508;
  
  public static final int DWARVEN_ROCK_CAKE = 7509;
  
  public static final int DWARVEN_ROCK_CAKE_7510 = 7510;
  
  public static final int SLOP_OF_COMPROMISE = 7511;
  
  public static final int SOGGY_BREAD = 7512;
  
  public static final int SPICY_MAGGOTS = 7513;
  
  public static final int DYED_ORANGE = 7514;
  
  public static final int BREADCRUMBS = 7515;
  
  public static final int KELP = 7516;
  
  public static final int GROUND_KELP = 7517;
  
  public static final int CRAB_MEAT = 7518;
  
  public static final int CRAB_MEAT_7519 = 7519;
  
  public static final int BURNT_CRAB_MEAT = 7520;
  
  public static final int COOKED_CRAB_MEAT = 7521;
  
  public static final int COOKED_CRAB_MEAT_7523 = 7523;
  
  public static final int COOKED_CRAB_MEAT_7524 = 7524;
  
  public static final int COOKED_CRAB_MEAT_7525 = 7525;
  
  public static final int COOKED_CRAB_MEAT_7526 = 7526;
  
  public static final int GROUND_CRAB_MEAT = 7527;
  
  public static final int GROUND_COD = 7528;
  
  public static final int RAW_FISHCAKE = 7529;
  
  public static final int COOKED_FISHCAKE = 7530;
  
  public static final int BURNT_FISHCAKE = 7531;
  
  public static final int MUDSKIPPER_HIDE = 7532;
  
  public static final int ROCK_7533 = 7533;
  
  public static final int FISHBOWL_HELMET = 7534;
  
  public static final int DIVING_APPARATUS = 7535;
  
  public static final int FRESH_CRAB_CLAW = 7536;
  
  public static final int CRAB_CLAW = 7537;
  
  public static final int FRESH_CRAB_SHELL = 7538;
  
  public static final int CRAB_HELMET = 7539;
  
  public static final int BROKEN_CRAB_CLAW = 7540;
  
  public static final int BROKEN_CRAB_SHELL = 7541;
  
  public static final int CAKE_OF_GUIDANCE = 7542;
  
  public static final int RAW_GUIDE_CAKE = 7543;
  
  public static final int ENCHANTED_EGG = 7544;
  
  public static final int ENCHANTED_MILK = 7545;
  
  public static final int ENCHANTED_FLOUR = 7546;
  
  public static final int DRUID_POUCH_7547 = 7547;
  
  public static final int POTATO_SEED_7548 = 7548;
  
  public static final int ONION_SEED_7550 = 7550;
  
  public static final int MITHRIL_ARROW_7552 = 7552;
  
  public static final int FIRE_RUNE_7554 = 7554;
  
  public static final int WATER_RUNE_7556 = 7556;
  
  public static final int AIR_RUNE_7558 = 7558;
  
  public static final int CHAOS_RUNE_7560 = 7560;
  
  public static final int TOMATO_SEED_7562 = 7562;
  
  public static final int BALLOON_TOAD = 7564;
  
  public static final int BALLOON_TOAD_7565 = 7565;
  
  public static final int RAW_JUBBLY = 7566;
  
  public static final int COOKED_JUBBLY = 7568;
  
  public static final int BURNT_JUBBLY = 7570;
  
  public static final int RED_BANANA = 7572;
  
  public static final int TCHIKI_MONKEY_NUTS = 7573;
  
  public static final int SLICED_RED_BANANA = 7574;
  
  public static final int TCHIKI_NUT_PASTE = 7575;
  
  public static final int SNAKE_CORPSE = 7576;
  
  public static final int RAW_STUFFED_SNAKE = 7577;
  
  public static final int ODD_STUFFED_SNAKE = 7578;
  
  public static final int STUFFED_SNAKE = 7579;
  
  public static final int SNAKE_OVERCOOKED = 7580;
  
  public static final int OVERGROWN_HELLCAT = 7581;
  
  public static final int HELL_CAT = 7582;
  
  public static final int HELLKITTEN = 7583;
  
  public static final int LAZY_HELL_CAT = 7584;
  
  public static final int WILY_HELLCAT = 7585;
  
  public static final int DUMMY = 7586;
  
  public static final int COFFIN = 7587;
  
  public static final int COFFIN_7588 = 7588;
  
  public static final int COFFIN_7589 = 7589;
  
  public static final int COFFIN_7590 = 7590;
  
  public static final int COFFIN_7591 = 7591;
  
  public static final int ZOMBIE_SHIRT = 7592;
  
  public static final int ZOMBIE_TROUSERS = 7593;
  
  public static final int ZOMBIE_MASK = 7594;
  
  public static final int ZOMBIE_GLOVES = 7595;
  
  public static final int ZOMBIE_BOOTS = 7596;
  
  public static final int ITEM = 7597;
  
  public static final int ITEM_7598 = 7598;
  
  public static final int ITEM_7599 = 7599;
  
  public static final int ITEM_7600 = 7600;
  
  public static final int ITEM_7601 = 7601;
  
  public static final int ITEM_7602 = 7602;
  
  public static final int ITEM_7603 = 7603;
  
  public static final int ITEM_7604 = 7604;
  
  public static final int ITEM_7605 = 7605;
  
  public static final int ITEM_7606 = 7606;
  
  public static final int ITEM_7607 = 7607;
  
  public static final int ITEM_7608 = 7608;
  
  public static final int ITEM_7609 = 7609;
  
  public static final int ITEM_7610 = 7610;
  
  public static final int ITEM_7611 = 7611;
  
  public static final int ITEM_7612 = 7612;
  
  public static final int ITEM_7613 = 7613;
  
  public static final int ITEM_7614 = 7614;
  
  public static final int ITEM_7615 = 7615;
  
  public static final int ITEM_7616 = 7616;
  
  public static final int ITEM_7617 = 7617;
  
  public static final int ITEM_7618 = 7618;
  
  public static final int BUCKET_OF_RUBBLE = 7622;
  
  public static final int BUCKET_OF_RUBBLE_7624 = 7624;
  
  public static final int BUCKET_OF_RUBBLE_7626 = 7626;
  
  public static final int PLASTER_FRAGMENT = 7628;
  
  public static final int DUSTY_SCROLL = 7629;
  
  public static final int CRATE = 7630;
  
  public static final int TEMPLE_LIBRARY_KEY = 7632;
  
  public static final int THE_SLEEPING_SEVEN = 7633;
  
  public static final int HISTORIES_OF_THE_HALLOWLAND = 7634;
  
  public static final int MODERN_DAY_MORYTANIA = 7635;
  
  public static final int ROD_DUST = 7636;
  
  public static final int SILVTHRILL_ROD = 7637;
  
  public static final int SILVTHRILL_ROD_7638 = 7638;
  
  public static final int ROD_OF_IVANDIS_10 = 7639;
  
  public static final int ROD_OF_IVANDIS_9 = 7640;
  
  public static final int ROD_OF_IVANDIS_8 = 7641;
  
  public static final int ROD_OF_IVANDIS_7 = 7642;
  
  public static final int ROD_OF_IVANDIS_6 = 7643;
  
  public static final int ROD_OF_IVANDIS_5 = 7644;
  
  public static final int ROD_OF_IVANDIS_4 = 7645;
  
  public static final int ROD_OF_IVANDIS_3 = 7646;
  
  public static final int ROD_OF_IVANDIS_2 = 7647;
  
  public static final int ROD_OF_IVANDIS_1 = 7648;
  
  public static final int ROD_MOULD = 7649;
  
  public static final int SILVER_DUST = 7650;
  
  public static final int GUTHIX_BALANCE_UNF = 7652;
  
  public static final int GUTHIX_BALANCE_UNF_7654 = 7654;
  
  public static final int GUTHIX_BALANCE_UNF_7656 = 7656;
  
  public static final int GUTHIX_BALANCE_UNF_7658 = 7658;
  
  public static final int GUTHIX_BALANCE4 = 7660;
  
  public static final int GUTHIX_BALANCE3 = 7662;
  
  public static final int GUTHIX_BALANCE2 = 7664;
  
  public static final int GUTHIX_BALANCE1 = 7666;
  
  public static final int GADDERHAMMER = 7668;
  
  public static final int BOXING_GLOVES = 7671;
  
  public static final int BOXING_GLOVES_7673 = 7673;
  
  public static final int WOODEN_SWORD = 7675;
  
  public static final int WOODEN_SHIELD_7676 = 7676;
  
  public static final int TREASURE_STONE = 7677;
  
  public static final int PRIZE_KEY = 7678;
  
  public static final int PUGEL = 7679;
  
  public static final int GAME_BOOK = 7681;
  
  public static final int HOOP = 7682;
  
  public static final int DART = 7684;
  
  public static final int BOW_AND_ARROW = 7686;
  
  public static final int KETTLE = 7688;
  
  public static final int FULL_KETTLE = 7690;
  
  public static final int HOT_KETTLE = 7691;
  
  public static final int POT_OF_TEA_4 = 7692;
  
  public static final int POT_OF_TEA_3 = 7694;
  
  public static final int POT_OF_TEA_2 = 7696;
  
  public static final int POT_OF_TEA_1 = 7698;
  
  public static final int TEAPOT_WITH_LEAVES = 7700;
  
  public static final int TEAPOT = 7702;
  
  public static final int POT_OF_TEA_4_7704 = 7704;
  
  public static final int POT_OF_TEA_3_7706 = 7706;
  
  public static final int POT_OF_TEA_2_7708 = 7708;
  
  public static final int POT_OF_TEA_1_7710 = 7710;
  
  public static final int TEAPOT_WITH_LEAVES_7712 = 7712;
  
  public static final int TEAPOT_7714 = 7714;
  
  public static final int POT_OF_TEA_4_7716 = 7716;
  
  public static final int POT_OF_TEA_3_7718 = 7718;
  
  public static final int POT_OF_TEA_2_7720 = 7720;
  
  public static final int POT_OF_TEA_1_7722 = 7722;
  
  public static final int TEAPOT_WITH_LEAVES_7724 = 7724;
  
  public static final int TEAPOT_7726 = 7726;
  
  public static final int EMPTY_CUP_7728 = 7728;
  
  public static final int CUP_OF_TEA_7730 = 7730;
  
  public static final int CUP_OF_TEA_7731 = 7731;
  
  public static final int PORCELAIN_CUP_7732 = 7732;
  
  public static final int CUP_OF_TEA_7733 = 7733;
  
  public static final int CUP_OF_TEA_7734 = 7734;
  
  public static final int PORCELAIN_CUP_7735 = 7735;
  
  public static final int CUP_OF_TEA_7736 = 7736;
  
  public static final int CUP_OF_TEA_7737 = 7737;
  
  public static final int TEA_LEAVES = 7738;
  
  public static final int BEER_7740 = 7740;
  
  public static final int BEER_GLASS_7742 = 7742;
  
  public static final int ASGARNIAN_ALE_7744 = 7744;
  
  public static final int GREENMANS_ALE_7746 = 7746;
  
  public static final int DRAGON_BITTER_7748 = 7748;
  
  public static final int MOONLIGHT_MEAD_7750 = 7750;
  
  public static final int CIDER_7752 = 7752;
  
  public static final int CHEFS_DELIGHT_7754 = 7754;
  
  public static final int PAINTBRUSH = 7756;
  
  public static final int TOY_SOLDIER = 7759;
  
  public static final int TOY_SOLDIER_WOUND = 7761;
  
  public static final int TOY_DOLL = 7763;
  
  public static final int TOY_DOLL_WOUND = 7765;
  
  public static final int TOY_MOUSE = 7767;
  
  public static final int TOY_MOUSE_WOUND = 7769;
  
  public static final int TOY_CAT = 7771;
  
  public static final int BRANCH_7773 = 7773;
  
  public static final int REWARD_TOKEN = 7774;
  
  public static final int REWARD_TOKEN_7775 = 7775;
  
  public static final int REWARD_TOKEN_7776 = 7776;
  
  public static final int LONG_VINE = 7777;
  
  public static final int SHORT_VINE = 7778;
  
  public static final int FISHING_TOME = 7779;
  
  public static final int FISHING_TOME_7780 = 7780;
  
  public static final int FISHING_TOME_7781 = 7781;
  
  public static final int AGILITY_TOME = 7782;
  
  public static final int AGILITY_TOME_7783 = 7783;
  
  public static final int AGILITY_TOME_7784 = 7784;
  
  public static final int THIEVING_TOME = 7785;
  
  public static final int THIEVING_TOME_7786 = 7786;
  
  public static final int THIEVING_TOME_7787 = 7787;
  
  public static final int SLAYER_TOME = 7788;
  
  public static final int SLAYER_TOME_7789 = 7789;
  
  public static final int SLAYER_TOME_7790 = 7790;
  
  public static final int MINING_TOME = 7791;
  
  public static final int MINING_TOME_7792 = 7792;
  
  public static final int MINING_TOME_7793 = 7793;
  
  public static final int FIREMAKING_TOME = 7794;
  
  public static final int FIREMAKING_TOME_7795 = 7795;
  
  public static final int FIREMAKING_TOME_7796 = 7796;
  
  public static final int WOODCUTTING_TOME = 7797;
  
  public static final int WOODCUTTING_TOME_7798 = 7798;
  
  public static final int WOODCUTTING_TOME_7799 = 7799;
  
  public static final int SNAIL_SHELL = 7800;
  
  public static final int SNAKE_HIDE_7801 = 7801;
  
  public static final int YIN_YANG_AMULET = 7803;
  
  public static final int ANCIENT_MJOLNIR = 7804;
  
  public static final int ANGER_SWORD = 7806;
  
  public static final int ANGER_BATTLEAXE = 7807;
  
  public static final int ANGER_MACE = 7808;
  
  public static final int ANGER_SPEAR = 7809;
  
  public static final int JUG_OF_VINEGAR = 7810;
  
  public static final int POT_OF_VINEGAR = 7811;
  
  public static final int GOBLIN_SKULL = 7812;
  
  public static final int BONE_IN_VINEGAR = 7813;
  
  public static final int GOBLIN_SKULL_7814 = 7814;
  
  public static final int BEAR_RIBS = 7815;
  
  public static final int BONE_IN_VINEGAR_7816 = 7816;
  
  public static final int BEAR_RIBS_7817 = 7817;
  
  public static final int RAM_SKULL = 7818;
  
  public static final int BONE_IN_VINEGAR_7819 = 7819;
  
  public static final int RAM_SKULL_7820 = 7820;
  
  public static final int UNICORN_BONE = 7821;
  
  public static final int BONE_IN_VINEGAR_7822 = 7822;
  
  public static final int UNICORN_BONE_7823 = 7823;
  
  public static final int GIANT_RAT_BONE = 7824;
  
  public static final int BONE_IN_VINEGAR_7825 = 7825;
  
  public static final int GIANT_RAT_BONE_7826 = 7826;
  
  public static final int GIANT_BAT_WING = 7827;
  
  public static final int BONE_IN_VINEGAR_7828 = 7828;
  
  public static final int GIANT_BAT_WING_7829 = 7829;
  
  public static final int WOLF_BONE = 7830;
  
  public static final int BONE_IN_VINEGAR_7831 = 7831;
  
  public static final int WOLF_BONE_7832 = 7832;
  
  public static final int BAT_WING = 7833;
  
  public static final int BONE_IN_VINEGAR_7834 = 7834;
  
  public static final int BAT_WING_7835 = 7835;
  
  public static final int RAT_BONE = 7836;
  
  public static final int BONE_IN_VINEGAR_7837 = 7837;
  
  public static final int RAT_BONE_7838 = 7838;
  
  public static final int BABY_DRAGON_BONE = 7839;
  
  public static final int BONE_IN_VINEGAR_7840 = 7840;
  
  public static final int BABY_DRAGON_BONE_7841 = 7841;
  
  public static final int OGRE_RIBS = 7842;
  
  public static final int BONE_IN_VINEGAR_7843 = 7843;
  
  public static final int OGRE_RIBS_7844 = 7844;
  
  public static final int JOGRE_BONE = 7845;
  
  public static final int BONE_IN_VINEGAR_7846 = 7846;
  
  public static final int JOGRE_BONE_7847 = 7847;
  
  public static final int ZOGRE_BONE = 7848;
  
  public static final int BONE_IN_VINEGAR_7849 = 7849;
  
  public static final int ZOGRE_BONE_7850 = 7850;
  
  public static final int MOGRE_BONE = 7851;
  
  public static final int BONE_IN_VINEGAR_7852 = 7852;
  
  public static final int MOGRE_BONE_7853 = 7853;
  
  public static final int MONKEY_PAW = 7854;
  
  public static final int BONE_IN_VINEGAR_7855 = 7855;
  
  public static final int MONKEY_PAW_7856 = 7856;
  
  public static final int DAGANNOTH_RIBS = 7857;
  
  public static final int BONE_IN_VINEGAR_7858 = 7858;
  
  public static final int DAGANNOTH_RIBS_7859 = 7859;
  
  public static final int SNAKE_SPINE = 7860;
  
  public static final int BONE_IN_VINEGAR_7861 = 7861;
  
  public static final int SNAKE_SPINE_7862 = 7862;
  
  public static final int ZOMBIE_BONE = 7863;
  
  public static final int BONE_IN_VINEGAR_7864 = 7864;
  
  public static final int ZOMBIE_BONE_7865 = 7865;
  
  public static final int WEREWOLF_BONE = 7866;
  
  public static final int BONE_IN_VINEGAR_7867 = 7867;
  
  public static final int WEREWOLF_BONE_7868 = 7868;
  
  public static final int MOSS_GIANT_BONE = 7869;
  
  public static final int BONE_IN_VINEGAR_7870 = 7870;
  
  public static final int MOSS_GIANT_BONE_7871 = 7871;
  
  public static final int FIRE_GIANT_BONE = 7872;
  
  public static final int BONE_IN_VINEGAR_7873 = 7873;
  
  public static final int FIRE_GIANT_BONE_7874 = 7874;
  
  public static final int ICE_GIANT_RIBS = 7875;
  
  public static final int BONE_IN_VINEGAR_7876 = 7876;
  
  public static final int ICE_GIANT_RIBS_7877 = 7877;
  
  public static final int TERRORBIRD_WING = 7878;
  
  public static final int BONE_IN_VINEGAR_7879 = 7879;
  
  public static final int TERRORBIRD_WING_7880 = 7880;
  
  public static final int GHOUL_BONE = 7881;
  
  public static final int BONE_IN_VINEGAR_7882 = 7882;
  
  public static final int GHOUL_BONE_7883 = 7883;
  
  public static final int TROLL_BONE = 7884;
  
  public static final int BONE_IN_VINEGAR_7885 = 7885;
  
  public static final int TROLL_BONE_7886 = 7886;
  
  public static final int SEAGULL_WING = 7887;
  
  public static final int BONE_IN_VINEGAR_7888 = 7888;
  
  public static final int SEAGULL_WING_7889 = 7889;
  
  public static final int UNDEAD_COW_RIBS = 7890;
  
  public static final int BONE_IN_VINEGAR_7891 = 7891;
  
  public static final int UNDEAD_COW_RIBS_7892 = 7892;
  
  public static final int EXPERIMENT_BONE = 7893;
  
  public static final int BONE_IN_VINEGAR_7894 = 7894;
  
  public static final int EXPERIMENT_BONE_7895 = 7895;
  
  public static final int RABBIT_BONE = 7896;
  
  public static final int BONE_IN_VINEGAR_7897 = 7897;
  
  public static final int RABBIT_BONE_7898 = 7898;
  
  public static final int BASILISK_BONE = 7899;
  
  public static final int BONE_IN_VINEGAR_7900 = 7900;
  
  public static final int BASILISK_BONE_7901 = 7901;
  
  public static final int DESERT_LIZARD_BONE = 7902;
  
  public static final int BONE_IN_VINEGAR_7903 = 7903;
  
  public static final int DESERT_LIZARD_BONE_7904 = 7904;
  
  public static final int CAVE_GOBLIN_SKULL = 7905;
  
  public static final int BONE_IN_VINEGAR_7906 = 7906;
  
  public static final int CAVE_GOBLIN_SKULL_7907 = 7907;
  
  public static final int BIG_FROG_LEG = 7908;
  
  public static final int BONE_IN_VINEGAR_7909 = 7909;
  
  public static final int BIG_FROG_LEG_7910 = 7910;
  
  public static final int VULTURE_WING = 7911;
  
  public static final int BONE_IN_VINEGAR_7912 = 7912;
  
  public static final int VULTURE_WING_7913 = 7913;
  
  public static final int JACKAL_BONE = 7914;
  
  public static final int BONE_IN_VINEGAR_7915 = 7915;
  
  public static final int JACKAL_BONE_7916 = 7916;
  
  public static final int RAM_SKULL_HELM = 7917;
  
  public static final int BONESACK = 7918;
  
  public static final int BOTTLE_OF_WINE = 7919;
  
  public static final int EMPTY_WINE_BOTTLE = 7921;
  
  public static final int AL_KHARID_FLYER = 7922;
  
  public static final int EASTER_RING = 7927;
  
  public static final int EASTER_EGG_7928 = 7928;
  
  public static final int EASTER_EGG_7929 = 7929;
  
  public static final int EASTER_EGG_7930 = 7930;
  
  public static final int EASTER_EGG_7931 = 7931;
  
  public static final int EASTER_EGG_7932 = 7932;
  
  public static final int EASTER_EGG_7933 = 7933;
  
  public static final int FIELD_RATION = 7934;
  
  public static final int PURE_ESSENCE = 7936;
  
  public static final int DARK_ESSENCE_FRAGMENTS = 7938;
  
  public static final int TORTOISE_SHELL = 7939;
  
  public static final int IRON_SHEET = 7941;
  
  public static final int FRESH_MONKFISH = 7942;
  
  public static final int FRESH_MONKFISH_7943 = 7943;
  
  public static final int RAW_MONKFISH = 7944;
  
  public static final int MONKFISH = 7946;
  
  public static final int BURNT_MONKFISH = 7948;
  
  public static final int BONE_SEEDS = 7950;
  
  public static final int HERMANS_BOOK = 7951;
  
  public static final int AXE_HANDLE_7952 = 7952;
  
  public static final int BURNT_SHRIMP = 7954;
  
  public static final int CASKET_7956 = 7956;
  
  public static final int WHITE_APRON_7957 = 7957;
  
  public static final int MINING_PROP = 7958;
  
  public static final int HEAVY_BOX = 7959;
  
  public static final int EMPTY_BOX = 7960;
  
  public static final int BURNT_DIARY = 7961;
  
  public static final int BURNT_DIARY_7962 = 7962;
  
  public static final int BURNT_DIARY_7963 = 7963;
  
  public static final int BURNT_DIARY_7964 = 7964;
  
  public static final int BURNT_DIARY_7965 = 7965;
  
  public static final int LETTER_7966 = 7966;
  
  public static final int ENGINE = 7967;
  
  public static final int SCROLL_7968 = 7968;
  
  public static final int PULLEY_BEAM = 7969;
  
  public static final int LONG_PULLEY_BEAM = 7970;
  
  public static final int LONGER_PULLEY_BEAM = 7971;
  
  public static final int LIFT_MANUAL = 7972;
  
  public static final int BEAM = 7973;
  
  public static final int SERVANT_BELL = 7974;
  
  public static final int CRAWLING_HAND_7975 = 7975;
  
  public static final int COCKATRICE_HEAD = 7976;
  
  public static final int BASILISK_HEAD = 7977;
  
  public static final int KURASK_HEAD = 7978;
  
  public static final int ABYSSAL_HEAD = 7979;
  
  public static final int KBD_HEADS = 7980;
  
  public static final int KQ_HEAD = 7981;
  
  public static final int STUFFED_CRAWLING_HAND = 7982;
  
  public static final int STUFFED_COCKATRICE_HEAD = 7983;
  
  public static final int STUFFED_BASILISK_HEAD = 7984;
  
  public static final int STUFFED_KURASK_HEAD = 7985;
  
  public static final int STUFFED_ABYSSAL_HEAD = 7986;
  
  public static final int STUFFED_KBD_HEADS = 7987;
  
  public static final int STUFFED_KQ_HEAD = 7988;
  
  public static final int BIG_BASS = 7989;
  
  public static final int STUFFED_BIG_BASS = 7990;
  
  public static final int BIG_SWORDFISH = 7991;
  
  public static final int STUFFED_BIG_SWORDFISH = 7992;
  
  public static final int BIG_SHARK = 7993;
  
  public static final int STUFFED_BIG_SHARK = 7994;
  
  public static final int ARTHUR_PORTRAIT = 7995;
  
  public static final int ELENA_PORTRAIT = 7996;
  
  public static final int KELDAGRIM_PORTRAIT = 7997;
  
  public static final int MISC_PORTRAIT = 7998;
  
  public static final int DESERT_PAINTING = 7999;
  
  public static final int ISAFDAR_PAINTING = 8000;
  
  public static final int KARAMJA_PAINTING = 8001;
  
  public static final int LUMBRIDGE_PAINTING = 8002;
  
  public static final int MORYTANIA_PAINTING = 8003;
  
  public static final int SMALL_MAP = 8004;
  
  public static final int MEDIUM_MAP = 8005;
  
  public static final int LARGE_MAP = 8006;
  
  public static final int VARROCK_TELEPORT = 8007;
  
  public static final int LUMBRIDGE_TELEPORT = 8008;
  
  public static final int FALADOR_TELEPORT = 8009;
  
  public static final int CAMELOT_TELEPORT = 8010;
  
  public static final int ARDOUGNE_TELEPORT = 8011;
  
  public static final int WATCHTOWER_TELEPORT = 8012;
  
  public static final int TELEPORT_TO_HOUSE = 8013;
  
  public static final int BONES_TO_BANANAS = 8014;
  
  public static final int BONES_TO_PEACHES_8015 = 8015;
  
  public static final int ENCHANT_SAPPHIRE_OR_OPAL = 8016;
  
  public static final int ENCHANT_EMERALD_OR_JADE = 8017;
  
  public static final int ENCHANT_RUBY_OR_TOPAZ = 8018;
  
  public static final int ENCHANT_DIAMOND = 8019;
  
  public static final int ENCHANT_DRAGONSTONE = 8020;
  
  public static final int ENCHANT_ONYX = 8021;
  
  public static final int TELEKINETIC_GRAB = 8022;
  
  public static final int BOXING_RING = 8023;
  
  public static final int FENCING_RING = 8024;
  
  public static final int COMBAT_RING = 8025;
  
  public static final int RANGING_PEDESTALS = 8026;
  
  public static final int BALANCE_BEAM = 8027;
  
  public static final int GLOVE_RACK = 8028;
  
  public static final int WEAPONS_RACK = 8029;
  
  public static final int EXTRA_WEAPONS_RACK = 8030;
  
  public static final int WOODEN_BED = 8031;
  
  public static final int OAK_BED = 8032;
  
  public static final int LARGE_OAK_BED = 8033;
  
  public static final int TEAK_BED = 8034;
  
  public static final int LARGE_TEAK_BED = 8035;
  
  public static final int _4POSTER = 8036;
  
  public static final int GILDED_4POSTER = 8037;
  
  public static final int SHOE_BOX = 8038;
  
  public static final int OAK_DRAWERS = 8039;
  
  public static final int OAK_WARDROBE = 8040;
  
  public static final int TEAK_DRAWERS = 8041;
  
  public static final int TEAK_WARDROBE = 8042;
  
  public static final int MAHOGANY_WARDROBE = 8043;
  
  public static final int GILDED_WARDROBE = 8044;
  
  public static final int SHAVING_STAND = 8045;
  
  public static final int OAK_SHAVING_STAND = 8046;
  
  public static final int OAK_DRESSER = 8047;
  
  public static final int TEAK_DRESSER = 8048;
  
  public static final int FANCY_TEAK_DRESSER = 8049;
  
  public static final int MAHOGANY_DRESSER = 8050;
  
  public static final int GILDED_DRESSER = 8051;
  
  public static final int OAK_CLOCK = 8052;
  
  public static final int TEAK_CLOCK = 8053;
  
  public static final int GILDED_CLOCK = 8054;
  
  public static final int SARADOMIN_SYMBOL = 8055;
  
  public static final int ZAMORAK_SYMBOL = 8056;
  
  public static final int GUTHIX_SYMBOL = 8057;
  
  public static final int SARADOMIN_ICON = 8058;
  
  public static final int ZAMORAK_ICON = 8059;
  
  public static final int GUTHIX_ICON = 8060;
  
  public static final int BOB_ICON = 8061;
  
  public static final int OAK_ALTAR = 8062;
  
  public static final int TEAK_ALTAR = 8063;
  
  public static final int CLOTHCOVERED_ALTAR = 8064;
  
  public static final int MAHOGANY_ALTAR = 8065;
  
  public static final int LIMESTONE_ALTAR = 8066;
  
  public static final int MARBLE_ALTAR = 8067;
  
  public static final int GILDED_ALTAR = 8068;
  
  public static final int WOODEN_TORCHES = 8069;
  
  public static final int STEEL_TORCHES = 8070;
  
  public static final int STEEL_CANDLESTICKS = 8071;
  
  public static final int GOLD_CANDLESTICKS = 8072;
  
  public static final int INCENSE_BURNERS = 8073;
  
  public static final int MAHOGANY_BURNERS = 8074;
  
  public static final int MARBLE_BURNERS = 8075;
  
  public static final int SHUTTERED_WINDOW = 8076;
  
  public static final int DECORATIVE_WINDOW = 8077;
  
  public static final int STAINED_GLASS = 8078;
  
  public static final int WINDCHIMES = 8079;
  
  public static final int BELLS = 8080;
  
  public static final int ORGAN = 8081;
  
  public static final int SMALL_STATUES = 8082;
  
  public static final int MEDIUM_STATUES = 8083;
  
  public static final int LARGE_STATUES = 8084;
  
  public static final int SUIT_OF_ARMOUR = 8085;
  
  public static final int SMALL_PORTRAIT = 8086;
  
  public static final int TEAK_MOUNTED_HEAD_DISPLAY = 8087;
  
  public static final int MAHOGANY_MOUNTED_HEAD_DISPLAY = 8088;
  
  public static final int GILDED_MOUNTED_HEAD_DISPLAY = 8089;
  
  public static final int MOUNTED_SWORD = 8090;
  
  public static final int SMALL_LANDSCAPE = 8091;
  
  public static final int LARGE_PORTRAIT = 8093;
  
  public static final int LARGE_LANDSCAPE = 8094;
  
  public static final int RUNE_DISPLAY_CASE = 8095;
  
  public static final int LOWLEVEL_PLANTS = 8096;
  
  public static final int MIDLEVEL_PLANTS = 8097;
  
  public static final int HIGHLEVEL_PLANTS = 8098;
  
  public static final int ROPE_BELLPULL = 8099;
  
  public static final int BELLPULL = 8100;
  
  public static final int POSH_BELLPULL = 8101;
  
  public static final int OAK_DECORATION = 8102;
  
  public static final int TEAK_DECORATION = 8103;
  
  public static final int GILDED_DECORATION = 8104;
  
  public static final int ROUND_SHIELD = 8105;
  
  public static final int SQUARE_SHIELD = 8106;
  
  public static final int KITE_SHIELD = 8107;
  
  public static final int WOODEN_BENCH = 8108;
  
  public static final int OAK_BENCH = 8109;
  
  public static final int CARVED_OAK_BENCH = 8110;
  
  public static final int TEAK_DINING_BENCH = 8111;
  
  public static final int CARVED_TEAK_BENCH = 8112;
  
  public static final int MAHOGANY_BENCH = 8113;
  
  public static final int GILDED_BENCH = 8114;
  
  public static final int WOOD_DINING_TABLE = 8115;
  
  public static final int OAK_DINING_TABLE = 8116;
  
  public static final int CARVED_OAK_TABLE = 8117;
  
  public static final int TEAK_TABLE = 8118;
  
  public static final int CARVED_TEAK_TABLE = 8119;
  
  public static final int MAHOGANY_TABLE = 8120;
  
  public static final int OPULENT_TABLE = 8121;
  
  public static final int OAK_DOOR = 8122;
  
  public static final int STEELPLATED_DOOR = 8123;
  
  public static final int MARBLE_DOOR = 8124;
  
  public static final int DECORATIVE_BLOOD = 8125;
  
  public static final int DECORATIVE_PIPE = 8126;
  
  public static final int HANGING_SKELETON = 8127;
  
  public static final int CANDLES = 8128;
  
  public static final int TORCHES = 8129;
  
  public static final int SKULL_TORCHES = 8130;
  
  public static final int SKELETON_GUARD = 8131;
  
  public static final int GUARD_DOG = 8132;
  
  public static final int HOBGOBLIN_GUARD = 8133;
  
  public static final int BABY_RED_DRAGON = 8134;
  
  public static final int HUGE_SPIDER = 8135;
  
  public static final int TROLL_GUARD = 8136;
  
  public static final int HELLHOUND = 8137;
  
  public static final int DEMON = 8138;
  
  public static final int KALPHITE_SOLDIER = 8139;
  
  public static final int TOKXIL = 8140;
  
  public static final int DAGANNOTH = 8141;
  
  public static final int STEEL_DRAGON = 8142;
  
  public static final int SPIKE_TRAP = 8143;
  
  public static final int MAN_TRAP = 8144;
  
  public static final int TANGLE_VINE = 8145;
  
  public static final int MARBLE_TRAP = 8146;
  
  public static final int TELEPORT_TRAP = 8147;
  
  public static final int WOODEN_CRATE = 8148;
  
  public static final int OAK_CHEST = 8149;
  
  public static final int TEAK_CHEST = 8150;
  
  public static final int MAHOGANY_CHEST = 8151;
  
  public static final int MAGIC_CHEST = 8152;
  
  public static final int CLAY_ATTACK_STONE = 8153;
  
  public static final int ATTACK_STONE = 8154;
  
  public static final int MARBLE_ATT_STONE = 8155;
  
  public static final int MAGICAL_BALANCE_1 = 8156;
  
  public static final int MAGICAL_BALANCE_2 = 8157;
  
  public static final int MAGICAL_BALANCE_3 = 8158;
  
  public static final int JESTER = 8159;
  
  public static final int TREASURE_HUNT = 8160;
  
  public static final int HANGMAN_GAME = 8161;
  
  public static final int HOOP_AND_STICK = 8162;
  
  public static final int DARTBOARD = 8163;
  
  public static final int ARCHERY_TARGET = 8164;
  
  public static final int OAK_PRIZE_CHEST = 8165;
  
  public static final int TEAK_PRIZE_CHEST = 8166;
  
  public static final int MAHOGANY_CHEST_8167 = 8167;
  
  public static final int EXIT_PORTAL = 8168;
  
  public static final int DECORATIVE_ROCK = 8169;
  
  public static final int POND = 8170;
  
  public static final int IMP_STATUE = 8171;
  
  public static final int DUNGEON_ENTRANCE = 8172;
  
  public static final int TREE = 8173;
  
  public static final int NICE_TREE = 8174;
  
  public static final int OAK_TREE = 8175;
  
  public static final int WILLOW_TREE = 8176;
  
  public static final int MAPLE_TREE = 8177;
  
  public static final int YEW_TREE = 8178;
  
  public static final int MAGIC_TREE = 8179;
  
  public static final int PLANT = 8180;
  
  public static final int SMALL_FERN = 8181;
  
  public static final int FERN = 8182;
  
  public static final int DOCK_LEAF = 8183;
  
  public static final int THISTLE = 8184;
  
  public static final int REEDS = 8185;
  
  public static final int FERN_8186 = 8186;
  
  public static final int BUSH = 8187;
  
  public static final int TALL_PLANT = 8188;
  
  public static final int SHORT_PLANT = 8189;
  
  public static final int LARGELEAF_PLANT = 8190;
  
  public static final int HUGE_PLANT = 8191;
  
  public static final int GAZEBO = 8192;
  
  public static final int SMALL_FOUNTAIN = 8193;
  
  public static final int LARGE_FOUNTAIN = 8194;
  
  public static final int POSH_FOUNTAIN = 8195;
  
  public static final int BOUNDARY_STONES = 8196;
  
  public static final int WOODEN_FENCE = 8197;
  
  public static final int STONE_WALL = 8198;
  
  public static final int IRON_RAILINGS = 8199;
  
  public static final int PICKET_FENCE = 8200;
  
  public static final int GARDEN_FENCE = 8201;
  
  public static final int MARBLE_WALL = 8202;
  
  public static final int THORNY_HEDGE = 8203;
  
  public static final int NICE_HEDGE = 8204;
  
  public static final int SMALL_BOX_HEDGE = 8205;
  
  public static final int TOPIARY_HEDGE = 8206;
  
  public static final int FANCY_HEDGE = 8207;
  
  public static final int TALL_FANCY_HEDGE = 8208;
  
  public static final int TALL_BOX_HEDGE = 8209;
  
  public static final int ROSEMARY_8210 = 8210;
  
  public static final int DAFFODILS = 8211;
  
  public static final int BLUEBELLS = 8212;
  
  public static final int SUNFLOWER = 8213;
  
  public static final int MARIGOLDS_8214 = 8214;
  
  public static final int ROSES = 8215;
  
  public static final int FIREPIT = 8216;
  
  public static final int FIREPIT_WITH_HOOK = 8217;
  
  public static final int FIREPIT_WITH_POT = 8218;
  
  public static final int SMALL_OVEN = 8219;
  
  public static final int LARGE_OVEN = 8220;
  
  public static final int STEEL_RANGE = 8221;
  
  public static final int FANCY_RANGE = 8222;
  
  public static final int WOODEN_SHELVES_1 = 8223;
  
  public static final int WOODEN_SHELVES_2 = 8224;
  
  public static final int WOODEN_SHELVES_3 = 8225;
  
  public static final int OAK_SHELVES_1 = 8226;
  
  public static final int OAK_SHELVES_2 = 8227;
  
  public static final int TEAK_SHELVES_1 = 8228;
  
  public static final int TEAK_SHELVES_2 = 8229;
  
  public static final int PUMP_AND_DRAIN = 8230;
  
  public static final int PUMP_AND_TUB = 8231;
  
  public static final int SINK = 8232;
  
  public static final int WOODEN_LARDER = 8233;
  
  public static final int OAK_LARDER = 8234;
  
  public static final int TEAK_LARDER = 8235;
  
  public static final int CAT_BLANKET = 8236;
  
  public static final int CAT_BASKET = 8237;
  
  public static final int CUSHIONED_BASKET = 8238;
  
  public static final int BEER_BARREL = 8239;
  
  public static final int CIDER_BARREL = 8240;
  
  public static final int ASGARNIAN_ALE_8241 = 8241;
  
  public static final int GREENMANS_ALE_8242 = 8242;
  
  public static final int DRAGON_BITTER_8243 = 8243;
  
  public static final int CHEFS_DELIGHT_8244 = 8244;
  
  public static final int WOOD_KITCHEN_TABLE = 8246;
  
  public static final int OAK_KITCHEN_TABLE = 8247;
  
  public static final int TEAK_KITCHEN_TABLE = 8248;
  
  public static final int OAK_STAIRCASE = 8249;
  
  public static final int OAK_STAIRCASE_8250 = 8250;
  
  public static final int OAK_STAIRCASE_8251 = 8251;
  
  public static final int TEAK_STAIRCASE = 8252;
  
  public static final int TEAK_STAIRCASE_8253 = 8253;
  
  public static final int TEAK_STAIRCASE_8254 = 8254;
  
  public static final int MARBLE_STAIRCASE = 8255;
  
  public static final int MARBLE_STAIRCASE_8256 = 8256;
  
  public static final int MARBLE_STAIRCASE_8257 = 8257;
  
  public static final int SPIRAL_STAIRCASE = 8258;
  
  public static final int MARBLE_SPIRAL = 8259;
  
  public static final int CRAWLING_HAND_8260 = 8260;
  
  public static final int COCKATRICE_HEAD_8261 = 8261;
  
  public static final int BASILISK_HEAD_8262 = 8262;
  
  public static final int KURASK_HEAD_8263 = 8263;
  
  public static final int ABYSSAL_HEAD_8264 = 8264;
  
  public static final int KBD_HEADS_8265 = 8265;
  
  public static final int KQ_HEAD_8266 = 8266;
  
  public static final int MOUNTED_BASS = 8267;
  
  public static final int MOUNTED_SWORDFISH = 8268;
  
  public static final int MOUNTED_SHARK = 8269;
  
  public static final int MITHRIL_ARMOUR = 8270;
  
  public static final int ADAMANTITE_ARMOUR = 8271;
  
  public static final int RUNITE_ARMOUR = 8272;
  
  public static final int CW_ARMOUR_1 = 8273;
  
  public static final int CW_ARMOUR_2 = 8274;
  
  public static final int CW_ARMOUR_3 = 8275;
  
  public static final int RUNE_CASE_1 = 8276;
  
  public static final int RUNE_CASE_2 = 8277;
  
  public static final int RUNE_CASE_3 = 8278;
  
  public static final int SILVERLIGHT_8279 = 8279;
  
  public static final int EXCALIBUR_8280 = 8280;
  
  public static final int DARKLIGHT_8281 = 8281;
  
  public static final int ANTIDRAGON_SHIELD_8282 = 8282;
  
  public static final int AMULET_OF_GLORY_8283 = 8283;
  
  public static final int CAPE_OF_LEGENDS_8284 = 8284;
  
  public static final int KING_ARTHUR = 8285;
  
  public static final int ELENA = 8286;
  
  public static final int GIANT_DWARF = 8287;
  
  public static final int MISCELLANIANS = 8288;
  
  public static final int LUMBRIDGE = 8289;
  
  public static final int THE_DESERT = 8290;
  
  public static final int MORYTANIA = 8291;
  
  public static final int KARAMJA = 8292;
  
  public static final int ISAFDAR = 8293;
  
  public static final int SMALL_MAP_8294 = 8294;
  
  public static final int MEDIUM_MAP_8295 = 8295;
  
  public static final int LARGE_MAP_8296 = 8296;
  
  public static final int OAK_CAGE = 8297;
  
  public static final int OAK_AND_STEEL_CAGE = 8298;
  
  public static final int STEEL_CAGE = 8299;
  
  public static final int SPIKED_CAGE = 8300;
  
  public static final int BONE_CAGE = 8301;
  
  public static final int SPIKES = 8302;
  
  public static final int TENTACLE_POOL = 8303;
  
  public static final int FLAME_PIT = 8304;
  
  public static final int ROCNAR = 8305;
  
  public static final int OAK_LADDER = 8306;
  
  public static final int TEAK_LADDER = 8307;
  
  public static final int MAHOGANY_LADDER = 8308;
  
  public static final int CRUDE_WOODEN_CHAIR = 8309;
  
  public static final int WOODEN_CHAIR = 8310;
  
  public static final int ROCKING_CHAIR = 8311;
  
  public static final int OAK_CHAIR = 8312;
  
  public static final int OAK_ARMCHAIR = 8313;
  
  public static final int TEAK_ARMCHAIR = 8314;
  
  public static final int MAHOGANY_ARMCHAIR = 8315;
  
  public static final int BROWN_RUG = 8316;
  
  public static final int RUG = 8317;
  
  public static final int OPULENT_RUG = 8318;
  
  public static final int WOODEN_BOOKCASE = 8319;
  
  public static final int OAK_BOOKCASE = 8320;
  
  public static final int MAHOGANY_BOOKCASE = 8321;
  
  public static final int TORN_CURTAINS = 8322;
  
  public static final int CURTAINS = 8323;
  
  public static final int OPULENT_CURTAINS = 8324;
  
  public static final int CLAY_FIREPLACE = 8325;
  
  public static final int STONE_FIREPLACE = 8326;
  
  public static final int MARBLE_FIREPLACE = 8327;
  
  public static final int TEAK_PORTAL = 8328;
  
  public static final int MAHOGANY_PORTAL = 8329;
  
  public static final int MARBLE_PORTAL = 8330;
  
  public static final int TELEPORT_FOCUS = 8331;
  
  public static final int GREATER_FOCUS = 8332;
  
  public static final int SCRYING_POOL = 8333;
  
  public static final int OAK_LECTERN = 8334;
  
  public static final int EAGLE_LECTERN = 8335;
  
  public static final int DEMON_LECTERN = 8336;
  
  public static final int TEAK_EAGLE_LECTERN = 8337;
  
  public static final int TEAK_DEMON_LECTERN = 8338;
  
  public static final int MAHOGANY_EAGLE = 8339;
  
  public static final int MAHOGANY_DEMON = 8340;
  
  public static final int GLOBE = 8341;
  
  public static final int ORNAMENTAL_GLOBE = 8342;
  
  public static final int LUNAR_GLOBE = 8343;
  
  public static final int CELESTIAL_GLOBE = 8344;
  
  public static final int ARMILLARY_SPHERE = 8345;
  
  public static final int SMALL_ORRERY = 8346;
  
  public static final int LARGE_ORRERY = 8347;
  
  public static final int OAK_TELESCOPE = 8348;
  
  public static final int TEAK_TELESCOPE = 8349;
  
  public static final int MAHOGANY_TELESCOPE = 8350;
  
  public static final int CRYSTAL_BALL = 8351;
  
  public static final int ELEMENTAL_SPHERE = 8352;
  
  public static final int CRYSTAL_OF_POWER = 8353;
  
  public static final int ALCHEMICAL_CHART = 8354;
  
  public static final int ASTRONOMICAL_CHART = 8355;
  
  public static final int INFERNAL_CHART = 8356;
  
  public static final int OAK_THRONE = 8357;
  
  public static final int TEAK_THRONE = 8358;
  
  public static final int MAHOGANY_THRONE = 8359;
  
  public static final int GILDED_THRONE = 8360;
  
  public static final int SKELETON_THRONE = 8361;
  
  public static final int CRYSTAL_THRONE = 8362;
  
  public static final int DEMONIC_THRONE = 8363;
  
  public static final int OAK_LEVER = 8364;
  
  public static final int TEAK_LEVER = 8365;
  
  public static final int MAHOGANY_LEVER = 8366;
  
  public static final int TRAPDOOR = 8367;
  
  public static final int TRAPDOOR_8368 = 8368;
  
  public static final int TRAPDOOR_8369 = 8369;
  
  public static final int FLOOR_DECORATION = 8370;
  
  public static final int STEEL_CAGE_8371 = 8371;
  
  public static final int TRAPDOOR_8372 = 8372;
  
  public static final int LESSER_MAGIC_CAGE = 8373;
  
  public static final int GREATER_MAGIC_CAGE = 8374;
  
  public static final int WOODEN_WORKBENCH = 8375;
  
  public static final int OAK_WORKBENCH = 8376;
  
  public static final int STEEL_FRAMED_BENCH = 8377;
  
  public static final int BENCH_WITH_VICE = 8378;
  
  public static final int BENCH_WITH_LATHE = 8379;
  
  public static final int CRAFTING_TABLE_1 = 8380;
  
  public static final int CRAFTING_TABLE_2 = 8381;
  
  public static final int CRAFTING_TABLE_3 = 8382;
  
  public static final int CRAFTING_TABLE_4 = 8383;
  
  public static final int TOOL_STORE_1 = 8384;
  
  public static final int TOOL_STORE_2 = 8385;
  
  public static final int TOOL_STORE_3 = 8386;
  
  public static final int TOOL_STORE_4 = 8387;
  
  public static final int TOOL_STORE_5 = 8388;
  
  public static final int REPAIR_BENCH = 8389;
  
  public static final int WHETSTONE = 8390;
  
  public static final int ARMOUR_STAND = 8391;
  
  public static final int PLUMING_STAND = 8392;
  
  public static final int SHIELD_EASEL = 8393;
  
  public static final int BANNER_EASEL = 8394;
  
  public static final int PARLOUR = 8395;
  
  public static final int KITCHEN = 8396;
  
  public static final int DINING_ROOM = 8397;
  
  public static final int BEDROOM = 8398;
  
  public static final int GAMES_ROOM = 8399;
  
  public static final int COMBAT_ROOM = 8400;
  
  public static final int HALL = 8401;
  
  public static final int HALL_8402 = 8402;
  
  public static final int HALL_8403 = 8403;
  
  public static final int HALL_8404 = 8404;
  
  public static final int CHAPEL = 8405;
  
  public static final int WORKSHOP = 8406;
  
  public static final int STUDY = 8407;
  
  public static final int PORTAL_CHAMBER = 8408;
  
  public static final int THRONE_ROOM = 8409;
  
  public static final int OUBLIETTE = 8410;
  
  public static final int DUNGEON_CORRIDOR = 8411;
  
  public static final int DUNGEON_CROSS = 8412;
  
  public static final int DUNGEON_STAIRS = 8413;
  
  public static final int TREASURE_ROOM = 8414;
  
  public static final int GARDEN = 8415;
  
  public static final int FORMAL_GARDEN = 8416;
  
  public static final int BAGGED_DEAD_TREE = 8417;
  
  public static final int BAGGED_NICE_TREE = 8419;
  
  public static final int BAGGED_OAK_TREE = 8421;
  
  public static final int BAGGED_WILLOW_TREE = 8423;
  
  public static final int BAGGED_MAPLE_TREE = 8425;
  
  public static final int BAGGED_YEW_TREE = 8427;
  
  public static final int BAGGED_MAGIC_TREE = 8429;
  
  public static final int BAGGED_PLANT_1 = 8431;
  
  public static final int BAGGED_PLANT_2 = 8433;
  
  public static final int BAGGED_PLANT_3 = 8435;
  
  public static final int THORNY_HEDGE_8437 = 8437;
  
  public static final int NICE_HEDGE_8439 = 8439;
  
  public static final int SMALL_BOX_HEDGE_8441 = 8441;
  
  public static final int TOPIARY_HEDGE_8443 = 8443;
  
  public static final int FANCY_HEDGE_8445 = 8445;
  
  public static final int TALL_FANCY_HEDGE_8447 = 8447;
  
  public static final int TALL_BOX_HEDGE_8449 = 8449;
  
  public static final int BAGGED_FLOWER = 8451;
  
  public static final int BAGGED_DAFFODILS = 8453;
  
  public static final int BAGGED_BLUEBELLS = 8455;
  
  public static final int BAGGED_SUNFLOWER = 8457;
  
  public static final int BAGGED_MARIGOLDS = 8459;
  
  public static final int BAGGED_ROSES = 8461;
  
  public static final int CONSTRUCTION_GUIDE = 8463;
  
  public static final int RUNE_HERALDIC_HELM = 8464;
  
  public static final int RUNE_HERALDIC_HELM_8466 = 8466;
  
  public static final int RUNE_HERALDIC_HELM_8468 = 8468;
  
  public static final int RUNE_HERALDIC_HELM_8470 = 8470;
  
  public static final int RUNE_HERALDIC_HELM_8472 = 8472;
  
  public static final int RUNE_HERALDIC_HELM_8474 = 8474;
  
  public static final int RUNE_HERALDIC_HELM_8476 = 8476;
  
  public static final int RUNE_HERALDIC_HELM_8478 = 8478;
  
  public static final int RUNE_HERALDIC_HELM_8480 = 8480;
  
  public static final int RUNE_HERALDIC_HELM_8482 = 8482;
  
  public static final int RUNE_HERALDIC_HELM_8484 = 8484;
  
  public static final int RUNE_HERALDIC_HELM_8486 = 8486;
  
  public static final int RUNE_HERALDIC_HELM_8488 = 8488;
  
  public static final int RUNE_HERALDIC_HELM_8490 = 8490;
  
  public static final int RUNE_HERALDIC_HELM_8492 = 8492;
  
  public static final int RUNE_HERALDIC_HELM_8494 = 8494;
  
  public static final int CRUDE_CHAIR = 8496;
  
  public static final int WOODEN_CHAIR_8498 = 8498;
  
  public static final int ROCKING_CHAIR_8500 = 8500;
  
  public static final int OAK_CHAIR_8502 = 8502;
  
  public static final int OAK_ARMCHAIR_8504 = 8504;
  
  public static final int TEAK_ARMCHAIR_8506 = 8506;
  
  public static final int MAHOGANY_ARMCHAIR_8508 = 8508;
  
  public static final int BOOKCASE = 8510;
  
  public static final int OAK_BOOKCASE_8512 = 8512;
  
  public static final int MAHOGANY_BOOKCASE_8514 = 8514;
  
  public static final int BEER_BARREL_8516 = 8516;
  
  public static final int CIDER_BARREL_8518 = 8518;
  
  public static final int ASGARNIAN_ALE_8520 = 8520;
  
  public static final int GREENMANS_ALE_8522 = 8522;
  
  public static final int DRAGON_BITTER_8524 = 8524;
  
  public static final int CHEFS_DELIGHT_8526 = 8526;
  
  public static final int KITCHEN_TABLE = 8528;
  
  public static final int OAK_KITCHEN_TABLE_8530 = 8530;
  
  public static final int TEAK_KITCHEN_TABLE_8532 = 8532;
  
  public static final int OAK_LECTERN_8534 = 8534;
  
  public static final int EAGLE_LECTERN_8536 = 8536;
  
  public static final int DEMON_LECTERN_8538 = 8538;
  
  public static final int TEAK_EAGLE_LECTERN_8540 = 8540;
  
  public static final int TEAK_DEMON_LECTERN_8542 = 8542;
  
  public static final int MAHOGANY_EAGLE_8544 = 8544;
  
  public static final int MAHOGANY_DEMON_8546 = 8546;
  
  public static final int WOOD_DINING_TABLE_8548 = 8548;
  
  public static final int OAK_DINING_TABLE_8550 = 8550;
  
  public static final int CARVED_OAK_TABLE_8552 = 8552;
  
  public static final int TEAK_TABLE_8554 = 8554;
  
  public static final int CARVED_TEAK_TABLE_8556 = 8556;
  
  public static final int MAHOGANY_TABLE_8558 = 8558;
  
  public static final int OPULENT_TABLE_8560 = 8560;
  
  public static final int WOODEN_BENCH_8562 = 8562;
  
  public static final int OAK_BENCH_8564 = 8564;
  
  public static final int CARVED_OAK_BENCH_8566 = 8566;
  
  public static final int TEAK_DINING_BENCH_8568 = 8568;
  
  public static final int CARVED_TEAK_BENCH_8570 = 8570;
  
  public static final int MAHOGANY_BENCH_8572 = 8572;
  
  public static final int GILDED_BENCH_8574 = 8574;
  
  public static final int WOODEN_BED_8576 = 8576;
  
  public static final int OAK_BED_8578 = 8578;
  
  public static final int LARGE_OAK_BED_8580 = 8580;
  
  public static final int TEAK_BED_8582 = 8582;
  
  public static final int LARGE_TEAK_BED_8584 = 8584;
  
  public static final int FOURPOSTER_BED = 8586;
  
  public static final int GILDED_FOURPOSTER = 8588;
  
  public static final int OAK_CLOCK_8590 = 8590;
  
  public static final int TEAK_CLOCK_8592 = 8592;
  
  public static final int GILDED_CLOCK_8594 = 8594;
  
  public static final int SHAVING_STAND_8596 = 8596;
  
  public static final int OAK_SHAVING_STAND_8598 = 8598;
  
  public static final int OAK_DRESSER_8600 = 8600;
  
  public static final int TEAK_DRESSER_8602 = 8602;
  
  public static final int FANCY_TEAK_DRESSER_8604 = 8604;
  
  public static final int MAHOGANY_DRESSER_8606 = 8606;
  
  public static final int GILDED_DRESSER_8608 = 8608;
  
  public static final int SHOE_BOX_8610 = 8610;
  
  public static final int OAK_DRAWERS_8612 = 8612;
  
  public static final int OAK_WARDROBE_8614 = 8614;
  
  public static final int TEAK_DRAWERS_8616 = 8616;
  
  public static final int TEAK_WARDROBE_8618 = 8618;
  
  public static final int MAHOGANY_WARDROBE_8620 = 8620;
  
  public static final int GILDED_WARDROBE_8622 = 8622;
  
  public static final int CRYSTAL_BALL_8624 = 8624;
  
  public static final int ELEMENTAL_SPHERE_8626 = 8626;
  
  public static final int CRYSTAL_OF_POWER_8628 = 8628;
  
  public static final int GLOBE_8630 = 8630;
  
  public static final int ORNAMENTAL_GLOBE_8632 = 8632;
  
  public static final int LUNAR_GLOBE_8634 = 8634;
  
  public static final int CELESTIAL_GLOBE_8636 = 8636;
  
  public static final int ARMILLARY_SPHERE_8638 = 8638;
  
  public static final int SMALL_ORRERY_8640 = 8640;
  
  public static final int LARGE_ORRERY_8642 = 8642;
  
  public static final int OAK_TELESCOPE_8644 = 8644;
  
  public static final int TEAK_TELESCOPE_8646 = 8646;
  
  public static final int MAHOGANY_TELESCOPE_8648 = 8648;
  
  public static final int BANNER = 8650;
  
  public static final int BANNER_8652 = 8652;
  
  public static final int BANNER_8654 = 8654;
  
  public static final int BANNER_8656 = 8656;
  
  public static final int BANNER_8658 = 8658;
  
  public static final int BANNER_8660 = 8660;
  
  public static final int BANNER_8662 = 8662;
  
  public static final int BANNER_8664 = 8664;
  
  public static final int BANNER_8666 = 8666;
  
  public static final int BANNER_8668 = 8668;
  
  public static final int BANNER_8670 = 8670;
  
  public static final int BANNER_8672 = 8672;
  
  public static final int BANNER_8674 = 8674;
  
  public static final int BANNER_8676 = 8676;
  
  public static final int BANNER_8678 = 8678;
  
  public static final int BANNER_8680 = 8680;
  
  public static final int STEEL_HERALDIC_HELM = 8682;
  
  public static final int STEEL_HERALDIC_HELM_8684 = 8684;
  
  public static final int STEEL_HERALDIC_HELM_8686 = 8686;
  
  public static final int STEEL_HERALDIC_HELM_8688 = 8688;
  
  public static final int STEEL_HERALDIC_HELM_8690 = 8690;
  
  public static final int STEEL_HERALDIC_HELM_8692 = 8692;
  
  public static final int STEEL_HERALDIC_HELM_8694 = 8694;
  
  public static final int STEEL_HERALDIC_HELM_8696 = 8696;
  
  public static final int STEEL_HERALDIC_HELM_8698 = 8698;
  
  public static final int STEEL_HERALDIC_HELM_8700 = 8700;
  
  public static final int STEEL_HERALDIC_HELM_8702 = 8702;
  
  public static final int STEEL_HERALDIC_HELM_8704 = 8704;
  
  public static final int STEEL_HERALDIC_HELM_8706 = 8706;
  
  public static final int STEEL_HERALDIC_HELM_8708 = 8708;
  
  public static final int STEEL_HERALDIC_HELM_8710 = 8710;
  
  public static final int STEEL_HERALDIC_HELM_8712 = 8712;
  
  public static final int RUNE_KITESHIELD_8714 = 8714;
  
  public static final int RUNE_KITESHIELD_8716 = 8716;
  
  public static final int RUNE_KITESHIELD_8718 = 8718;
  
  public static final int RUNE_KITESHIELD_8720 = 8720;
  
  public static final int RUNE_KITESHIELD_8722 = 8722;
  
  public static final int RUNE_KITESHIELD_8724 = 8724;
  
  public static final int RUNE_KITESHIELD_8726 = 8726;
  
  public static final int RUNE_KITESHIELD_8728 = 8728;
  
  public static final int RUNE_KITESHIELD_8730 = 8730;
  
  public static final int RUNE_KITESHIELD_8732 = 8732;
  
  public static final int RUNE_KITESHIELD_8734 = 8734;
  
  public static final int RUNE_KITESHIELD_8736 = 8736;
  
  public static final int RUNE_KITESHIELD_8738 = 8738;
  
  public static final int RUNE_KITESHIELD_8740 = 8740;
  
  public static final int RUNE_KITESHIELD_8742 = 8742;
  
  public static final int RUNE_KITESHIELD_8744 = 8744;
  
  public static final int STEEL_KITESHIELD_8746 = 8746;
  
  public static final int STEEL_KITESHIELD_8748 = 8748;
  
  public static final int STEEL_KITESHIELD_8750 = 8750;
  
  public static final int STEEL_KITESHIELD_8752 = 8752;
  
  public static final int STEEL_KITESHIELD_8754 = 8754;
  
  public static final int STEEL_KITESHIELD_8756 = 8756;
  
  public static final int STEEL_KITESHIELD_8758 = 8758;
  
  public static final int STEEL_KITESHIELD_8760 = 8760;
  
  public static final int STEEL_KITESHIELD_8762 = 8762;
  
  public static final int STEEL_KITESHIELD_8764 = 8764;
  
  public static final int STEEL_KITESHIELD_8766 = 8766;
  
  public static final int STEEL_KITESHIELD_8768 = 8768;
  
  public static final int STEEL_KITESHIELD_8770 = 8770;
  
  public static final int STEEL_KITESHIELD_8772 = 8772;
  
  public static final int STEEL_KITESHIELD_8774 = 8774;
  
  public static final int STEEL_KITESHIELD_8776 = 8776;
  
  public static final int OAK_PLANK = 8778;
  
  public static final int TEAK_PLANK = 8780;
  
  public static final int MAHOGANY_PLANK = 8782;
  
  public static final int GOLD_LEAF_8784 = 8784;
  
  public static final int MARBLE_BLOCK = 8786;
  
  public static final int MAGIC_STONE_8788 = 8788;
  
  public static final int BOLT_OF_CLOTH = 8790;
  
  public static final int CLOCKWORK = 8792;
  
  public static final int SAW = 8794;
  
  public static final int TIMBER_BEAM = 8837;
  
  public static final int VOID_KNIGHT_TOP = 8839;
  
  public static final int VOID_KNIGHT_ROBE = 8840;
  
  public static final int VOID_KNIGHT_MACE = 8841;
  
  public static final int VOID_KNIGHT_GLOVES = 8842;
  
  public static final int BRONZE_DEFENDER = 8844;
  
  public static final int IRON_DEFENDER = 8845;
  
  public static final int STEEL_DEFENDER = 8846;
  
  public static final int BLACK_DEFENDER = 8847;
  
  public static final int MITHRIL_DEFENDER = 8848;
  
  public static final int ADAMANT_DEFENDER = 8849;
  
  public static final int RUNE_DEFENDER = 8850;
  
  public static final int WARRIOR_GUILD_TOKEN = 8851;
  
  public static final int DEFENSIVE_SHIELD = 8856;
  
  public static final int SHOT = 8857;
  
  public static final int _18LB_SHOT = 8858;
  
  public static final int _22LB_SHOT = 8859;
  
  public static final int ONE_BARREL = 8860;
  
  public static final int TWO_BARRELS = 8861;
  
  public static final int THREE_BARRELS = 8862;
  
  public static final int FOUR_BARRELS = 8863;
  
  public static final int FIVE_BARRELS = 8864;
  
  public static final int GROUND_ASHES = 8865;
  
  public static final int STEEL_KEY = 8866;
  
  public static final int BRONZE_KEY_8867 = 8867;
  
  public static final int SILVER_KEY = 8868;
  
  public static final int IRON_KEY_8869 = 8869;
  
  public static final int ZANIK = 8870;
  
  public static final int CRATE_WITH_ZANIK = 8871;
  
  public static final int BONE_DAGGER = 8872;
  
  public static final int BONE_DAGGER_P = 8874;
  
  public static final int BONE_DAGGER_P_8876 = 8876;
  
  public static final int BONE_DAGGER_P_8878 = 8878;
  
  public static final int DORGESHUUN_CROSSBOW = 8880;
  
  public static final int BONE_BOLTS = 8882;
  
  public static final int ZANIK_8887 = 8887;
  
  public static final int ZANIK_HAM = 8888;
  
  public static final int ZANIK_SHOWDOWN = 8889;
  
  public static final int COINS_8890 = 8890;
  
  public static final int CAVE_HORROR = 8900;
  
  public static final int BLACK_MASK_10 = 8901;
  
  public static final int BLACK_MASK_9 = 8903;
  
  public static final int BLACK_MASK_8 = 8905;
  
  public static final int BLACK_MASK_7 = 8907;
  
  public static final int BLACK_MASK_6 = 8909;
  
  public static final int BLACK_MASK_5 = 8911;
  
  public static final int BLACK_MASK_4 = 8913;
  
  public static final int BLACK_MASK_3 = 8915;
  
  public static final int BLACK_MASK_2 = 8917;
  
  public static final int BLACK_MASK_1 = 8919;
  
  public static final int BLACK_MASK = 8921;
  
  public static final int WITCHWOOD_ICON = 8923;
  
  public static final int BANDANA_EYEPATCH = 8924;
  
  public static final int BANDANA_EYEPATCH_8925 = 8925;
  
  public static final int BANDANA_EYEPATCH_8926 = 8926;
  
  public static final int BANDANA_EYEPATCH_8927 = 8927;
  
  public static final int HAT_EYEPATCH = 8928;
  
  public static final int CRABCLAW_HOOK = 8929;
  
  public static final int PIPE_SECTION = 8930;
  
  public static final int LUMBER_PATCH = 8932;
  
  public static final int SCRAPEY_TREE_LOGS = 8934;
  
  public static final int BLUE_FLOWERS_8936 = 8936;
  
  public static final int RED_FLOWERS_8938 = 8938;
  
  public static final int RUM = 8940;
  
  public static final int RUM_8941 = 8941;
  
  public static final int MONKEY_8942 = 8942;
  
  public static final int BLUE_MONKEY = 8943;
  
  public static final int BLUE_MONKEY_8944 = 8944;
  
  public static final int BLUE_MONKEY_8945 = 8945;
  
  public static final int RED_MONKEY = 8946;
  
  public static final int RED_MONKEY_8947 = 8947;
  
  public static final int RED_MONKEY_8948 = 8948;
  
  public static final int PIRATE_BANDANA_8949 = 8949;
  
  public static final int PIRATE_HAT = 8950;
  
  public static final int PIECES_OF_EIGHT = 8951;
  
  public static final int BLUE_NAVAL_SHIRT = 8952;
  
  public static final int GREEN_NAVAL_SHIRT = 8953;
  
  public static final int RED_NAVAL_SHIRT = 8954;
  
  public static final int BROWN_NAVAL_SHIRT = 8955;
  
  public static final int BLACK_NAVAL_SHIRT = 8956;
  
  public static final int PURPLE_NAVAL_SHIRT = 8957;
  
  public static final int GREY_NAVAL_SHIRT = 8958;
  
  public static final int BLUE_TRICORN_HAT = 8959;
  
  public static final int GREEN_TRICORN_HAT = 8960;
  
  public static final int RED_TRICORN_HAT = 8961;
  
  public static final int BROWN_TRICORN_HAT = 8962;
  
  public static final int BLACK_TRICORN_HAT = 8963;
  
  public static final int PURPLE_TRICORN_HAT = 8964;
  
  public static final int GREY_TRICORN_HAT = 8965;
  
  public static final int CUTTHROAT_FLAG = 8966;
  
  public static final int GILDED_SMILE_FLAG = 8967;
  
  public static final int BRONZE_FIST_FLAG = 8968;
  
  public static final int LUCKY_SHOT_FLAG = 8969;
  
  public static final int TREASURE_FLAG = 8970;
  
  public static final int PHASMATYS_FLAG = 8971;
  
  public static final int BOWL_OF_RED_WATER = 8972;
  
  public static final int BOWL_OF_BLUE_WATER = 8974;
  
  public static final int BITTERNUT = 8976;
  
  public static final int SCRAPEY_BARK = 8977;
  
  public static final int BRIDGE_SECTION = 8979;
  
  public static final int SWEETGRUBS = 8981;
  
  public static final int BUCKET_8986 = 8986;
  
  public static final int TORCH_8987 = 8987;
  
  public static final int THE_STUFF = 8988;
  
  public static final int BREWIN_GUIDE = 8989;
  
  public static final int BREWIN_GUIDE_8990 = 8990;
  
  public static final int BLUE_NAVY_SLACKS = 8991;
  
  public static final int GREEN_NAVY_SLACKS = 8992;
  
  public static final int RED_NAVY_SLACKS = 8993;
  
  public static final int BROWN_NAVY_SLACKS = 8994;
  
  public static final int BLACK_NAVY_SLACKS = 8995;
  
  public static final int PURPLE_NAVY_SLACKS = 8996;
  
  public static final int GREY_NAVY_SLACKS = 8997;
  
  public static final int SECURITY_BOOK = 9003;
  
  public static final int STRONGHOLD_NOTES = 9004;
  
  public static final int FANCY_BOOTS = 9005;
  
  public static final int FIGHTING_BOOTS = 9006;
  
  public static final int RIGHT_SKULL_HALF = 9007;
  
  public static final int LEFT_SKULL_HALF = 9008;
  
  public static final int STRANGE_SKULL = 9009;
  
  public static final int TOP_OF_SCEPTRE = 9010;
  
  public static final int BOTTOM_OF_SCEPTRE = 9011;
  
  public static final int RUNED_SCEPTRE = 9012;
  
  public static final int SKULL_SCEPTRE = 9013;
  
  public static final int GORAK_CLAWS = 9016;
  
  public static final int STAR_FLOWER = 9017;
  
  public static final int GORAK_CLAW_POWDER = 9018;
  
  public static final int MAGIC_ESSENCE_UNF = 9019;
  
  public static final int QUEENS_SECATEURS_9020 = 9020;
  
  public static final int MAGIC_ESSENCE4 = 9021;
  
  public static final int MAGIC_ESSENCE3 = 9022;
  
  public static final int MAGIC_ESSENCE2 = 9023;
  
  public static final int MAGIC_ESSENCE1 = 9024;
  
  public static final int NUFFS_CERTIFICATE = 9025;
  
  public static final int IVORY_COMB = 9026;
  
  public static final int GOLDEN_SCARAB = 9028;
  
  public static final int STONE_SCARAB = 9030;
  
  public static final int POTTERY_SCARAB = 9032;
  
  public static final int GOLDEN_STATUETTE = 9034;
  
  public static final int POTTERY_STATUETTE = 9036;
  
  public static final int STONE_STATUETTE = 9038;
  
  public static final int GOLD_SEAL = 9040;
  
  public static final int STONE_SEAL = 9042;
  
  public static final int PHARAOHS_SCEPTRE = 9044;
  
  public static final int PHARAOHS_SCEPTRE_9045 = 9045;
  
  public static final int PHARAOHS_SCEPTRE_9046 = 9046;
  
  public static final int PHARAOHS_SCEPTRE_9047 = 9047;
  
  public static final int PHARAOHS_SCEPTRE_9048 = 9048;
  
  public static final int PHARAOHS_SCEPTRE_9049 = 9049;
  
  public static final int PHARAOHS_SCEPTRE_9050 = 9050;
  
  public static final int PHARAOHS_SCEPTRE_9051 = 9051;
  
  public static final int LOCUST_MEAT = 9052;
  
  public static final int RED_GOBLIN_MAIL = 9054;
  
  public static final int BLACK_GOBLIN_MAIL = 9055;
  
  public static final int YELLOW_GOBLIN_MAIL = 9056;
  
  public static final int GREEN_GOBLIN_MAIL = 9057;
  
  public static final int PURPLE_GOBLIN_MAIL = 9058;
  
  public static final int PINK_GOBLIN_MAIL = 9059;
  
  public static final int EMERALD_LANTERN = 9064;
  
  public static final int EMERALD_LANTERN_9065 = 9065;
  
  public static final int EMERALD_LENS = 9066;
  
  public static final int DREAM_LOG = 9067;
  
  public static final int MOONCLAN_HELM = 9068;
  
  public static final int MOONCLAN_HAT = 9069;
  
  public static final int MOONCLAN_ARMOUR = 9070;
  
  public static final int MOONCLAN_SKIRT = 9071;
  
  public static final int MOONCLAN_GLOVES = 9072;
  
  public static final int MOONCLAN_BOOTS = 9073;
  
  public static final int MOONCLAN_CAPE = 9074;
  
  public static final int ASTRAL_RUNE = 9075;
  
  public static final int LUNAR_ORE = 9076;
  
  public static final int LUNAR_BAR = 9077;
  
  public static final int MOONCLAN_MANUAL = 9078;
  
  public static final int SUQAH_TOOTH = 9079;
  
  public static final int SUQAH_HIDE = 9080;
  
  public static final int SUQAH_LEATHER = 9081;
  
  public static final int GROUND_TOOTH = 9082;
  
  public static final int SEAL_OF_PASSAGE = 9083;
  
  public static final int LUNAR_STAFF = 9084;
  
  public static final int EMPTY_VIAL = 9085;
  
  public static final int VIAL_OF_WATER_9086 = 9086;
  
  public static final int WAKING_SLEEP_VIAL = 9087;
  
  public static final int GUAM_VIAL = 9088;
  
  public static final int MARR_VIAL = 9089;
  
  public static final int GUAMMARR_VIAL = 9090;
  
  public static final int LUNAR_STAFF__PT1 = 9091;
  
  public static final int LUNAR_STAFF__PT2 = 9092;
  
  public static final int LUNAR_STAFF__PT3 = 9093;
  
  public static final int KINDLING = 9094;
  
  public static final int SOAKED_KINDLING = 9095;
  
  public static final int LUNAR_HELM = 9096;
  
  public static final int LUNAR_TORSO = 9097;
  
  public static final int LUNAR_LEGS = 9098;
  
  public static final int LUNAR_GLOVES = 9099;
  
  public static final int LUNAR_BOOTS = 9100;
  
  public static final int LUNAR_CAPE = 9101;
  
  public static final int LUNAR_AMULET = 9102;
  
  public static final int A_SPECIAL_TIARA = 9103;
  
  public static final int LUNAR_RING = 9104;
  
  public static final int SUQAH_MONSTER = 9105;
  
  public static final int ASTRAL_TIARA = 9106;
  
  public static final int BLURITE_BOLTS = 9139;
  
  public static final int IRON_BOLTS = 9140;
  
  public static final int STEEL_BOLTS = 9141;
  
  public static final int MITHRIL_BOLTS = 9142;
  
  public static final int ADAMANT_BOLTS = 9143;
  
  public static final int RUNITE_BOLTS = 9144;
  
  public static final int SILVER_BOLTS = 9145;
  
  public static final int BRONZE_CROSSBOW = 9174;
  
  public static final int BLURITE_CROSSBOW = 9176;
  
  public static final int IRON_CROSSBOW = 9177;
  
  public static final int STEEL_CROSSBOW = 9179;
  
  public static final int MITHRIL_CROSSBOW = 9181;
  
  public static final int ADAMANT_CROSSBOW = 9183;
  
  public static final int RUNE_CROSSBOW = 9185;
  
  public static final int JADE_BOLT_TIPS = 9187;
  
  public static final int TOPAZ_BOLT_TIPS = 9188;
  
  public static final int SAPPHIRE_BOLT_TIPS = 9189;
  
  public static final int EMERALD_BOLT_TIPS = 9190;
  
  public static final int RUBY_BOLT_TIPS = 9191;
  
  public static final int DIAMOND_BOLT_TIPS = 9192;
  
  public static final int DRAGONSTONE_BOLT_TIPS = 9193;
  
  public static final int ONYX_BOLT_TIPS = 9194;
  
  public static final int OPAL_BOLTS_E = 9236;
  
  public static final int JADE_BOLTS_E = 9237;
  
  public static final int PEARL_BOLTS_E = 9238;
  
  public static final int TOPAZ_BOLTS_E = 9239;
  
  public static final int SAPPHIRE_BOLTS_E = 9240;
  
  public static final int EMERALD_BOLTS_E = 9241;
  
  public static final int RUBY_BOLTS_E = 9242;
  
  public static final int DIAMOND_BOLTS_E = 9243;
  
  public static final int DRAGONSTONE_BOLTS_E = 9244;
  
  public static final int ONYX_BOLTS_E = 9245;
  
  public static final int BLURITE_BOLTS_P = 9286;
  
  public static final int IRON_BOLTS_P = 9287;
  
  public static final int STEEL_BOLTS_P = 9288;
  
  public static final int MITHRIL_BOLTS_P = 9289;
  
  public static final int ADAMANT_BOLTS_P = 9290;
  
  public static final int RUNITE_BOLTS_P = 9291;
  
  public static final int SILVER_BOLTS_P = 9292;
  
  public static final int BLURITE_BOLTS_P_9293 = 9293;
  
  public static final int IRON_BOLTS_P_9294 = 9294;
  
  public static final int STEEL_BOLTS_P_9295 = 9295;
  
  public static final int MITHRIL_BOLTS_P_9296 = 9296;
  
  public static final int ADAMANT_BOLTS_P_9297 = 9297;
  
  public static final int RUNITE_BOLTS_P_9298 = 9298;
  
  public static final int SILVER_BOLTS_P_9299 = 9299;
  
  public static final int BLURITE_BOLTS_P_9300 = 9300;
  
  public static final int IRON_BOLTS_P_9301 = 9301;
  
  public static final int STEEL_BOLTS_P_9302 = 9302;
  
  public static final int MITHRIL_BOLTS_P_9303 = 9303;
  
  public static final int ADAMANT_BOLTS_P_9304 = 9304;
  
  public static final int RUNITE_BOLTS_P_9305 = 9305;
  
  public static final int SILVER_BOLTS_P_9306 = 9306;
  
  public static final int JADE_BOLTS = 9335;
  
  public static final int TOPAZ_BOLTS = 9336;
  
  public static final int SAPPHIRE_BOLTS = 9337;
  
  public static final int EMERALD_BOLTS = 9338;
  
  public static final int RUBY_BOLTS = 9339;
  
  public static final int DIAMOND_BOLTS = 9340;
  
  public static final int DRAGONSTONE_BOLTS = 9341;
  
  public static final int ONYX_BOLTS = 9342;
  
  public static final int BRONZE_BOLTS_UNF = 9375;
  
  public static final int BLURITE_BOLTS_UNF = 9376;
  
  public static final int IRON_BOLTS_UNF = 9377;
  
  public static final int STEEL_BOLTS_UNF = 9378;
  
  public static final int MITHRIL_BOLTS_UNF = 9379;
  
  public static final int ADAMANT_BOLTSUNF = 9380;
  
  public static final int RUNITE_BOLTS_UNF = 9381;
  
  public static final int SILVER_BOLTS_UNF = 9382;
  
  public static final int GRAPPLE = 9415;
  
  public static final int MITH_GRAPPLE_TIP = 9416;
  
  public static final int MITH_GRAPPLE = 9418;
  
  public static final int MITH_GRAPPLE_9419 = 9419;
  
  public static final int BRONZE_LIMBS = 9420;
  
  public static final int BLURITE_LIMBS = 9422;
  
  public static final int IRON_LIMBS = 9423;
  
  public static final int STEEL_LIMBS = 9425;
  
  public static final int MITHRIL_LIMBS = 9427;
  
  public static final int ADAMANTITE_LIMBS = 9429;
  
  public static final int RUNITE_LIMBS = 9431;
  
  public static final int BOLT_POUCH = 9433;
  
  public static final int BOLT_MOULD = 9434;
  
  public static final int SINEW = 9436;
  
  public static final int CROSSBOW_STRING = 9438;
  
  public static final int WOODEN_STOCK = 9440;
  
  public static final int OAK_STOCK = 9442;
  
  public static final int WILLOW_STOCK = 9444;
  
  public static final int TEAK_STOCK = 9446;
  
  public static final int MAPLE_STOCK = 9448;
  
  public static final int MAHOGANY_STOCK = 9450;
  
  public static final int YEW_STOCK = 9452;
  
  public static final int BRONZE_CROSSBOW_U = 9454;
  
  public static final int BLURITE_CROSSBOW_U = 9456;
  
  public static final int IRON_CROSSBOW_U = 9457;
  
  public static final int STEEL_CROSSBOW_U = 9459;
  
  public static final int MITHRIL_CROSSBOW_U = 9461;
  
  public static final int ADAMANT_CROSSBOW_U = 9463;
  
  public static final int RUNITE_CROSSBOW_U = 9465;
  
  public static final int BLURITE_BAR = 9467;
  
  public static final int SAWDUST = 9468;
  
  public static final int GRAND_SEED_POD = 9469;
  
  public static final int GNOME_SCARF = 9470;
  
  public static final int GNOME_GOGGLES = 9472;
  
  public static final int REWARD_TOKEN_9474 = 9474;
  
  public static final int MINT_CAKE = 9475;
  
  public static final int ALUFT_ALOFT_BOX = 9477;
  
  public static final int HALF_MADE_BATTA = 9478;
  
  public static final int UNFINISHED_BATTA_9479 = 9479;
  
  public static final int HALF_MADE_BATTA_9480 = 9480;
  
  public static final int UNFINISHED_BATTA_9481 = 9481;
  
  public static final int HALF_MADE_BATTA_9482 = 9482;
  
  public static final int HALF_MADE_BATTA_9483 = 9483;
  
  public static final int UNFINISHED_BATTA_9484 = 9484;
  
  public static final int HALF_MADE_BATTA_9485 = 9485;
  
  public static final int UNFINISHED_BATTA_9486 = 9486;
  
  public static final int WIZARD_BLIZZARD_9487 = 9487;
  
  public static final int WIZARD_BLIZZARD_9489 = 9489;
  
  public static final int WIZARD_BLIZZARD_9508 = 9508;
  
  public static final int SHORT_GREEN_GUY_9510 = 9510;
  
  public static final int PINEAPPLE_PUNCH_9512 = 9512;
  
  public static final int FRUIT_BLAST_9514 = 9514;
  
  public static final int DRUNK_DRAGON_9516 = 9516;
  
  public static final int CHOC_SATURDAY_9518 = 9518;
  
  public static final int BLURBERRY_SPECIAL_9520 = 9520;
  
  public static final int BATTA_TIN_9522 = 9522;
  
  public static final int BATTA_TIN_9524 = 9524;
  
  public static final int FRUIT_BATTA_9527 = 9527;
  
  public static final int TOAD_BATTA_9529 = 9529;
  
  public static final int WORM_BATTA_9531 = 9531;
  
  public static final int VEGETABLE_BATTA_9533 = 9533;
  
  public static final int CHEESETOM_BATTA_9535 = 9535;
  
  public static final int TOAD_CRUNCHIES_9538 = 9538;
  
  public static final int SPICY_CRUNCHIES_9540 = 9540;
  
  public static final int WORM_CRUNCHIES_9542 = 9542;
  
  public static final int CHOCCHIP_CRUNCHIES_9544 = 9544;
  
  public static final int WORM_HOLE_9547 = 9547;
  
  public static final int VEG_BALL_9549 = 9549;
  
  public static final int TANGLED_TOADS_LEGS_9551 = 9551;
  
  public static final int CHOCOLATE_BOMB_9553 = 9553;
  
  public static final int HALF_MADE_BOWL = 9558;
  
  public static final int HALF_MADE_BOWL_9559 = 9559;
  
  public static final int UNFINISHED_BOWL_9560 = 9560;
  
  public static final int HALF_MADE_BOWL_9561 = 9561;
  
  public static final int UNFINISHED_BOWL_9562 = 9562;
  
  public static final int HALF_MADE_BOWL_9563 = 9563;
  
  public static final int UNFINISHED_BOWL_9564 = 9564;
  
  public static final int MIXED_BLIZZARD = 9566;
  
  public static final int MIXED_SGG = 9567;
  
  public static final int MIXED_BLAST = 9568;
  
  public static final int MIXED_PUNCH = 9569;
  
  public static final int MIXED_SPECIAL = 9570;
  
  public static final int MIXED_SATURDAY = 9571;
  
  public static final int MIXED_SATURDAY_9572 = 9572;
  
  public static final int MIXED_SATURDAY_9573 = 9573;
  
  public static final int MIXED_DRAGON = 9574;
  
  public static final int MIXED_DRAGON_9575 = 9575;
  
  public static final int MIXED_DRAGON_9576 = 9576;
  
  public static final int HALF_MADE_CRUNCHY = 9577;
  
  public static final int UNFINISHED_CRUNCHY_9578 = 9578;
  
  public static final int HALF_MADE_CRUNCHY_9579 = 9579;
  
  public static final int UNFINISHED_CRUNCHY_9580 = 9580;
  
  public static final int HALF_MADE_CRUNCHY_9581 = 9581;
  
  public static final int UNFINISHED_CRUNCHY_9582 = 9582;
  
  public static final int HALF_MADE_CRUNCHY_9583 = 9583;
  
  public static final int UNFINISHED_CRUNCHY_9584 = 9584;
  
  public static final int DOSSIER = 9589;
  
  public static final int DOSSIER_9590 = 9590;
  
  public static final int BROKEN_CAULDRON = 9591;
  
  public static final int MAGIC_GLUE = 9592;
  
  public static final int WEIRD_GLOOP = 9593;
  
  public static final int GROUND_MUD_RUNES = 9594;
  
  public static final int HAZELMERES_BOOK = 9595;
  
  public static final int RED_CIRCLE = 9597;
  
  public static final int RED_TRIANGLE = 9598;
  
  public static final int RED_SQUARE = 9599;
  
  public static final int RED_PENTAGON = 9600;
  
  public static final int ORANGE_CIRCLE = 9601;
  
  public static final int ORANGE_TRIANGLE = 9602;
  
  public static final int ORANGE_SQUARE = 9603;
  
  public static final int ORANGE_PENTAGON = 9604;
  
  public static final int YELLOW_CIRCLE = 9605;
  
  public static final int YELLOW_TRIANGLE = 9606;
  
  public static final int YELLOW_SQUARE = 9607;
  
  public static final int YELLOW_PENTAGON = 9608;
  
  public static final int GREEN_CIRCLE = 9609;
  
  public static final int GREEN_TRIANGLE = 9610;
  
  public static final int GREEN_SQUARE = 9611;
  
  public static final int GREEN_PENTAGON = 9612;
  
  public static final int BLUE_CIRCLE = 9613;
  
  public static final int BLUE_TRIANGLE = 9614;
  
  public static final int BLUE_SQUARE = 9615;
  
  public static final int BLUE_PENTAGON = 9616;
  
  public static final int INDIGO_CIRCLE = 9617;
  
  public static final int INDIGO_TRIANGLE = 9618;
  
  public static final int INDIGO_SQUARE = 9619;
  
  public static final int INDIGO_PENTAGON = 9620;
  
  public static final int VIOLET_CIRCLE = 9621;
  
  public static final int VIOLET_TRIANGLE = 9622;
  
  public static final int VIOLET_SQUARE = 9623;
  
  public static final int VIOLET_PENTAGON = 9624;
  
  public static final int CRYSTAL_SAW = 9625;
  
  public static final int CRYSTAL_SAW_SEED = 9626;
  
  public static final int A_HANDWRITTEN_BOOK = 9627;
  
  public static final int TYRAS_HELM = 9629;
  
  public static final int DAEYALT_ORE = 9632;
  
  public static final int MESSAGE_9633 = 9633;
  
  public static final int VYREWATCH_TOP = 9634;
  
  public static final int VYREWATCH_LEGS = 9636;
  
  public static final int VYREWATCH_SHOES = 9638;
  
  public static final int CITIZEN_TOP = 9640;
  
  public static final int CITIZEN_TROUSERS = 9642;
  
  public static final int CITIZEN_SHOES = 9644;
  
  public static final int CASTLE_SKETCH_1 = 9646;
  
  public static final int CASTLE_SKETCH_2 = 9647;
  
  public static final int CASTLE_SKETCH_3 = 9648;
  
  public static final int MESSAGE_9649 = 9649;
  
  public static final int BLOOD_TITHE_POUCH = 9650;
  
  public static final int LARGE_ORNATE_KEY = 9651;
  
  public static final int HAEMALCHEMY_VOLUME_1 = 9652;
  
  public static final int SEALED_MESSAGE = 9653;
  
  public static final int DOOR_KEY_9654 = 9654;
  
  public static final int LADDER_TOP = 9655;
  
  public static final int TOME_OF_EXPERIENCE_3 = 9656;
  
  public static final int TOME_OF_EXPERIENCE_2 = 9657;
  
  public static final int TOME_OF_EXPERIENCE_1 = 9658;
  
  public static final int BUCKET_OF_WATER_9659 = 9659;
  
  public static final int BUCKET_9660 = 9660;
  
  public static final int USELESS_KEY = 9662;
  
  public static final int TORCH_9665 = 9665;
  
  public static final int PROSELYTE_HARNESS_M = 9666;
  
  public static final int INITIATE_HARNESS_M = 9668;
  
  public static final int PROSELYTE_HARNESS_F = 9670;
  
  public static final int PROSELYTE_SALLET = 9672;
  
  public static final int PROSELYTE_HAUBERK = 9674;
  
  public static final int PROSELYTE_CUISSE = 9676;
  
  public static final int PROSELYTE_TASSET = 9678;
  
  public static final int SEA_SLUG_GLUE = 9680;
  
  public static final int COMMORB_V2 = 9681;
  
  public static final int DOOR_TRANSCRIPTION = 9682;
  
  public static final int DEAD_SEA_SLUG = 9683;
  
  public static final int PAGE_1 = 9684;
  
  public static final int PAGE_2 = 9685;
  
  public static final int PAGE_3 = 9686;
  
  public static final int FRAGMENT_1 = 9687;
  
  public static final int FRAGMENT_2 = 9688;
  
  public static final int FRAGMENT_3 = 9689;
  
  public static final int BLANK_WATER_RUNE = 9690;
  
  public static final int WATER_RUNE_9691 = 9691;
  
  public static final int BLANK_AIR_RUNE = 9692;
  
  public static final int AIR_RUNE_9693 = 9693;
  
  public static final int BLANK_EARTH_RUNE = 9694;
  
  public static final int EARTH_RUNE_9695 = 9695;
  
  public static final int BLANK_MIND_RUNE = 9696;
  
  public static final int MIND_RUNE_9697 = 9697;
  
  public static final int BLANK_FIRE_RUNE = 9698;
  
  public static final int FIRE_RUNE_9699 = 9699;
  
  public static final int STICK_9702 = 9702;
  
  public static final int TRAINING_SWORD = 9703;
  
  public static final int TRAINING_SHIELD = 9704;
  
  public static final int TRAINING_BOW = 9705;
  
  public static final int TRAINING_ARROWS = 9706;
  
  public static final int SLASHED_BOOK = 9715;
  
  public static final int ROCK_9716 = 9716;
  
  public static final int BEATEN_BOOK = 9717;
  
  public static final int CRANE_SCHEMATIC = 9718;
  
  public static final int LEVER_SCHEMATIC = 9719;
  
  public static final int CRANE_CLAW = 9720;
  
  public static final int SCROLL_9721 = 9721;
  
  public static final int KEY_9722 = 9722;
  
  public static final int PIPE = 9723;
  
  public static final int LARGE_COG = 9724;
  
  public static final int MEDIUM_COG = 9725;
  
  public static final int SMALL_COG = 9726;
  
  public static final int PRIMED_BAR = 9727;
  
  public static final int PRIMED_MIND_BAR = 9728;
  
  public static final int ELEMENTAL_HELMET = 9729;
  
  public static final int MIND_SHIELD = 9731;
  
  public static final int MIND_HELMET = 9733;
  
  public static final int DESERT_GOAT_HORN = 9735;
  
  public static final int GOAT_HORN_DUST = 9736;
  
  public static final int COMBAT_POTION4 = 9739;
  
  public static final int COMBAT_POTION3 = 9741;
  
  public static final int COMBAT_POTION2 = 9743;
  
  public static final int COMBAT_POTION1 = 9745;
  
  public static final int ATTACK_CAPE = 9747;
  
  public static final int ATTACK_CAPET = 9748;
  
  public static final int ATTACK_HOOD = 9749;
  
  public static final int STRENGTH_CAPE = 9750;
  
  public static final int STRENGTH_CAPET = 9751;
  
  public static final int STRENGTH_HOOD = 9752;
  
  public static final int DEFENCE_CAPE = 9753;
  
  public static final int DEFENCE_CAPET = 9754;
  
  public static final int DEFENCE_HOOD = 9755;
  
  public static final int RANGING_CAPE = 9756;
  
  public static final int RANGING_CAPET = 9757;
  
  public static final int RANGING_HOOD = 9758;
  
  public static final int PRAYER_CAPE = 9759;
  
  public static final int PRAYER_CAPET = 9760;
  
  public static final int PRAYER_HOOD = 9761;
  
  public static final int MAGIC_CAPE = 9762;
  
  public static final int MAGIC_CAPET = 9763;
  
  public static final int MAGIC_HOOD = 9764;
  
  public static final int RUNECRAFT_CAPE = 9765;
  
  public static final int RUNECRAFT_CAPET = 9766;
  
  public static final int RUNECRAFT_HOOD = 9767;
  
  public static final int HITPOINTS_CAPE = 9768;
  
  public static final int HITPOINTS_CAPET = 9769;
  
  public static final int HITPOINTS_HOOD = 9770;
  
  public static final int AGILITY_CAPE = 9771;
  
  public static final int AGILITY_CAPET = 9772;
  
  public static final int AGILITY_HOOD = 9773;
  
  public static final int HERBLORE_CAPE = 9774;
  
  public static final int HERBLORE_CAPET = 9775;
  
  public static final int HERBLORE_HOOD = 9776;
  
  public static final int THIEVING_CAPE = 9777;
  
  public static final int THIEVING_CAPET = 9778;
  
  public static final int THIEVING_HOOD = 9779;
  
  public static final int CRAFTING_CAPE = 9780;
  
  public static final int CRAFTING_CAPET = 9781;
  
  public static final int CRAFTING_HOOD = 9782;
  
  public static final int FLETCHING_CAPE = 9783;
  
  public static final int FLETCHING_CAPET = 9784;
  
  public static final int FLETCHING_HOOD = 9785;
  
  public static final int SLAYER_CAPE = 9786;
  
  public static final int SLAYER_CAPET = 9787;
  
  public static final int SLAYER_HOOD = 9788;
  
  public static final int CONSTRUCT_CAPE = 9789;
  
  public static final int CONSTRUCT_CAPET = 9790;
  
  public static final int CONSTRUCT_HOOD = 9791;
  
  public static final int MINING_CAPE = 9792;
  
  public static final int MINING_CAPET = 9793;
  
  public static final int MINING_HOOD = 9794;
  
  public static final int SMITHING_CAPE = 9795;
  
  public static final int SMITHING_CAPET = 9796;
  
  public static final int SMITHING_HOOD = 9797;
  
  public static final int FISHING_CAPE = 9798;
  
  public static final int FISHING_CAPET = 9799;
  
  public static final int FISHING_HOOD = 9800;
  
  public static final int COOKING_CAPE = 9801;
  
  public static final int COOKING_CAPET = 9802;
  
  public static final int COOKING_HOOD = 9803;
  
  public static final int FIREMAKING_CAPE = 9804;
  
  public static final int FIREMAKING_CAPET = 9805;
  
  public static final int FIREMAKING_HOOD = 9806;
  
  public static final int WOODCUTTING_CAPE = 9807;
  
  public static final int WOODCUT_CAPET = 9808;
  
  public static final int WOODCUTTING_HOOD = 9809;
  
  public static final int FARMING_CAPE = 9810;
  
  public static final int FARMING_CAPET = 9811;
  
  public static final int FARMING_HOOD = 9812;
  
  public static final int QUEST_POINT_CAPE = 9813;
  
  public static final int QUEST_POINT_HOOD = 9814;
  
  public static final int OAK_CAPE_RACK = 9817;
  
  public static final int TEAK_CAPE_RACK = 9818;
  
  public static final int MAHOGANY_CAPE_RACK = 9819;
  
  public static final int GILDED_CAPE_RACK = 9820;
  
  public static final int MARBLE_CAPE_RACK = 9821;
  
  public static final int MAGICAL_CAPE_RACK = 9822;
  
  public static final int OAK_COSTUME_BOX = 9823;
  
  public static final int TEAK_COSTUME_BOX = 9824;
  
  public static final int MAHOGANY_COSTUME_BOX = 9825;
  
  public static final int OAK_ARMOUR_CASE = 9826;
  
  public static final int TEAK_ARMOUR_CASE = 9827;
  
  public static final int MAHOGANY_ARMOUR_CASE = 9828;
  
  public static final int OAK_WARDROBE_9829 = 9829;
  
  public static final int CARVED_OAK_WARDROBE = 9830;
  
  public static final int TEAK_WARDROBE_9831 = 9831;
  
  public static final int CARVED_TEAK_WARDROBE = 9832;
  
  public static final int MAHOGANY_WARDROBE_9833 = 9833;
  
  public static final int GILDED_WARDROBE_9834 = 9834;
  
  public static final int MARBLE_WARDROBE = 9835;
  
  public static final int OAK_TOY_BOX = 9836;
  
  public static final int TEAK_TOY_BOX = 9837;
  
  public static final int MAHOGANY_TOY_BOX = 9838;
  
  public static final int OAK_TREASURE_CHEST = 9839;
  
  public static final int TEAK_TREASURE_CHEST = 9840;
  
  public static final int MAHOGANY_TREASURE_CHEST = 9841;
  
  public static final int COSTUME_ROOM = 9842;
  
  public static final int OAK_CAPE_RACK_9843 = 9843;
  
  public static final int TEAK_CAPE_RACK_9844 = 9844;
  
  public static final int MAHOGANY_CAPE_RACK_9845 = 9845;
  
  public static final int GILDED_CAPE_RACK_9846 = 9846;
  
  public static final int MARBLE_CAPE_RACK_9847 = 9847;
  
  public static final int MAGIC_CAPE_RACK = 9848;
  
  public static final int OAK_TOY_BOX_9849 = 9849;
  
  public static final int TEAK_TOY_BOX_9850 = 9850;
  
  public static final int MAHOGANY_TOY_BOX_9851 = 9851;
  
  public static final int OAK_MAGIC_WARDROBE = 9852;
  
  public static final int CARVED_OAK_MAGIC_WARDROBE = 9853;
  
  public static final int TEAK_MAGIC_WARDROBE = 9854;
  
  public static final int CARVED_TEAK_MAGIC_WARDROBE = 9855;
  
  public static final int MAHOGANY_MAGIC_WARDROBE = 9856;
  
  public static final int GILDED_MAGIC_WARDROBE = 9857;
  
  public static final int MARBLE_MAGIC_WARDROBE = 9858;
  
  public static final int OAK_ARMOUR_CASE_9859 = 9859;
  
  public static final int TEAK_ARMOUR_CASE_9860 = 9860;
  
  public static final int MAHOGANY_ARMOUR_CASE_9861 = 9861;
  
  public static final int OAK_TREASURE_CHEST_9862 = 9862;
  
  public static final int TEAK_TREASURE_CHEST_9863 = 9863;
  
  public static final int M_TREASURE_CHEST = 9864;
  
  public static final int OAK_FANCY_DRESS_BOX = 9865;
  
  public static final int TEAK_FANCY_DRESS_BOX = 9866;
  
  public static final int MAHOGANY_FANCY_DRESS_BOX = 9867;
  
  public static final int GOUTWEEDY_LUMP = 9901;
  
  public static final int HARDY_GOUT_TUBERS = 9902;
  
  public static final int FARMING_MANUAL = 9903;
  
  public static final int SAILING_BOOK = 9904;
  
  public static final int GHOST_BUSTER_500 = 9906;
  
  public static final int GHOST_BUSTER_500_9907 = 9907;
  
  public static final int GHOST_BUSTER_500_9908 = 9908;
  
  public static final int GHOST_BUSTER_500_9909 = 9909;
  
  public static final int GHOST_BUSTER_500_9910 = 9910;
  
  public static final int GHOST_BUSTER_500_9911 = 9911;
  
  public static final int GHOST_BUSTER_500_9912 = 9912;
  
  public static final int WHITE_DESTABILISER = 9913;
  
  public static final int RED_DESTABILISER = 9914;
  
  public static final int BLUE_DESTABILISER = 9915;
  
  public static final int GREEN_DESTABILISER = 9916;
  
  public static final int YELLOW_DESTABILISER = 9917;
  
  public static final int BLACK_DESTABILISER = 9918;
  
  public static final int EVIL_ROOT = 9919;
  
  public static final int JACK_LANTERN_MASK = 9920;
  
  public static final int SKELETON_BOOTS = 9921;
  
  public static final int SKELETON_GLOVES = 9922;
  
  public static final int SKELETON_LEGGINGS = 9923;
  
  public static final int SKELETON_SHIRT = 9924;
  
  public static final int SKELETON_MASK = 9925;
  
  public static final int AUGUSTES_SAPLING = 9932;
  
  public static final int BALLOON_STRUCTURE = 9933;
  
  public static final int ORIGAMI_BALLOON = 9934;
  
  public static final int YELLOW_BALLOON = 9935;
  
  public static final int BLUE_BALLOON = 9936;
  
  public static final int RED_BALLOON = 9937;
  
  public static final int ORANGE_BALLOON = 9938;
  
  public static final int GREEN_BALLOON = 9939;
  
  public static final int PURPLE_BALLOON = 9940;
  
  public static final int PINK_BALLOON = 9941;
  
  public static final int BLACK_BALLOON = 9942;
  
  public static final int SANDBAG = 9943;
  
  public static final int BOMBER_JACKET = 9944;
  
  public static final int BOMBER_CAP = 9945;
  
  public static final int CAP_AND_GOGGLES = 9946;
  
  public static final int OLD_RED_DISK = 9947;
  
  public static final int HUNTER_CAPE = 9948;
  
  public static final int HUNTER_CAPET = 9949;
  
  public static final int HUNTER_HOOD = 9950;
  
  public static final int FOOTPRINT = 9951;
  
  public static final int IMP = 9952;
  
  public static final int KEBBIT = 9953;
  
  public static final int KEBBIT_9954 = 9954;
  
  public static final int KEBBIT_9955 = 9955;
  
  public static final int KEBBIT_9956 = 9956;
  
  public static final int KEBBIT_9957 = 9957;
  
  public static final int KEBBIT_9958 = 9958;
  
  public static final int KEBBIT_9959 = 9959;
  
  public static final int KEBBIT_9960 = 9960;
  
  public static final int KEBBIT_9961 = 9961;
  
  public static final int KEBBIT_9962 = 9962;
  
  public static final int KEBBIT_9963 = 9963;
  
  public static final int KEBBIT_9964 = 9964;
  
  public static final int CRIMSON_SWIFT = 9965;
  
  public static final int COPPER_LONGTAIL = 9966;
  
  public static final int CERULEAN_TWITCH = 9967;
  
  public static final int GOLDEN_WARBLER = 9968;
  
  public static final int TROPICAL_WAGTAIL = 9969;
  
  public static final int BUTTERFLY = 9970;
  
  public static final int BUTTERFLY_9971 = 9971;
  
  public static final int BUTTERFLY_9972 = 9972;
  
  public static final int BUTTERFLY_9973 = 9973;
  
  public static final int GIANT_EAGLE = 9974;
  
  public static final int RABBIT = 9975;
  
  public static final int CHINCHOMPA = 9976;
  
  public static final int RED_CHINCHOMPA = 9977;
  
  public static final int RAW_BIRD_MEAT = 9978;
  
  public static final int ROAST_BIRD_MEAT = 9980;
  
  public static final int BURNT_BIRD_MEAT = 9982;
  
  public static final int SKEWERED_BIRD_MEAT = 9984;
  
  public static final int RAW_BEAST_MEAT = 9986;
  
  public static final int ROAST_BEAST_MEAT = 9988;
  
  public static final int BURNT_BEAST_MEAT = 9990;
  
  public static final int SKEWERED_BEAST = 9992;
  
  public static final int SPICY_TOMATO = 9994;
  
  public static final int SPICY_MINCED_MEAT = 9996;
  
  public static final int HUNTER_POTION4 = 9998;
  
  public static final int HUNTER_POTION3 = 10000;
  
  public static final int HUNTER_POTION2 = 10002;
  
  public static final int HUNTER_POTION1 = 10004;
  
  public static final int BIRD_SNARE = 10006;
  
  public static final int BOX_TRAP = 10008;
  
  public static final int BUTTERFLY_NET = 10010;
  
  public static final int BUTTERFLY_JAR = 10012;
  
  public static final int BLACK_WARLOCK = 10014;
  
  public static final int SNOWY_KNIGHT = 10016;
  
  public static final int SAPPHIRE_GLACIALIS = 10018;
  
  public static final int RUBY_HARVEST = 10020;
  
  public static final int FALCONERS_GLOVE = 10023;
  
  public static final int FALCONERS_GLOVE_10024 = 10024;
  
  public static final int MAGIC_BOX = 10025;
  
  public static final int IMPINABOX2 = 10027;
  
  public static final int IMPINABOX1 = 10028;
  
  public static final int TEASING_STICK = 10029;
  
  public static final int RABBIT_SNARE = 10031;
  
  public static final int CHINCHOMPA_10033 = 10033;
  
  public static final int RED_CHINCHOMPA_10034 = 10034;
  
  public static final int KYATT_LEGS = 10035;
  
  public static final int KYATT_TOP = 10037;
  
  public static final int KYATT_HAT = 10039;
  
  public static final int LARUPIA_LEGS = 10041;
  
  public static final int LARUPIA_TOP = 10043;
  
  public static final int LARUPIA_HAT = 10045;
  
  public static final int GRAAHK_LEGS = 10047;
  
  public static final int GRAAHK_TOP = 10049;
  
  public static final int GRAAHK_HEADDRESS = 10051;
  
  public static final int WOOD_CAMO_TOP = 10053;
  
  public static final int WOOD_CAMO_LEGS = 10055;
  
  public static final int JUNGLE_CAMO_TOP = 10057;
  
  public static final int JUNGLE_CAMO_LEGS = 10059;
  
  public static final int DESERT_CAMO_TOP = 10061;
  
  public static final int DESERT_CAMO_LEGS = 10063;
  
  public static final int POLAR_CAMO_TOP = 10065;
  
  public static final int POLAR_CAMO_LEGS = 10067;
  
  public static final int SPOTTED_CAPE = 10069;
  
  public static final int SPOTTIER_CAPE = 10071;
  
  public static final int SPOTTED_CAPE_10073 = 10073;
  
  public static final int SPOTTIER_CAPE_10074 = 10074;
  
  public static final int GLOVES_OF_SILENCE = 10075;
  
  public static final int SPIKY_VAMBRACES = 10077;
  
  public static final int GREEN_SPIKY_VAMBRACES = 10079;
  
  public static final int BLUE_SPIKY_VAMBRACES = 10081;
  
  public static final int RED_SPIKY_VAMBRACES = 10083;
  
  public static final int BLACK_SPIKY_VAMBRACES = 10085;
  
  public static final int STRIPY_FEATHER = 10087;
  
  public static final int RED_FEATHER = 10088;
  
  public static final int BLUE_FEATHER = 10089;
  
  public static final int YELLOW_FEATHER = 10090;
  
  public static final int ORANGE_FEATHER = 10091;
  
  public static final int FERRET = 10092;
  
  public static final int TATTY_LARUPIA_FUR = 10093;
  
  public static final int LARUPIA_FUR = 10095;
  
  public static final int TATTY_GRAAHK_FUR = 10097;
  
  public static final int GRAAHK_FUR = 10099;
  
  public static final int TATTY_KYATT_FUR = 10101;
  
  public static final int KYATT_FUR = 10103;
  
  public static final int KEBBIT_SPIKE = 10105;
  
  public static final int LONG_KEBBIT_SPIKE = 10107;
  
  public static final int KEBBIT_TEETH = 10109;
  
  public static final int KEBBIT_TEETH_DUST = 10111;
  
  public static final int KEBBIT_CLAWS = 10113;
  
  public static final int DARK_KEBBIT_FUR = 10115;
  
  public static final int POLAR_KEBBIT_FUR = 10117;
  
  public static final int FELDIP_WEASEL_FUR = 10119;
  
  public static final int COMMON_KEBBIT_FUR = 10121;
  
  public static final int DESERT_DEVIL_FUR = 10123;
  
  public static final int SPOTTED_KEBBIT_FUR = 10125;
  
  public static final int DASHING_KEBBIT_FUR = 10127;
  
  public static final int BARBTAIL_HARPOON = 10129;
  
  public static final int STRUNG_RABBIT_FOOT = 10132;
  
  public static final int RABBIT_FOOT = 10134;
  
  public static final int RAINBOW_FISH = 10136;
  
  public static final int RAW_RAINBOW_FISH = 10138;
  
  public static final int BURNT_RAINBOW_FISH = 10140;
  
  public static final int GUAM_TAR = 10142;
  
  public static final int MARRENTILL_TAR = 10143;
  
  public static final int TARROMIN_TAR = 10144;
  
  public static final int HARRALANDER_TAR = 10145;
  
  public static final int ORANGE_SALAMANDER = 10146;
  
  public static final int RED_SALAMANDER = 10147;
  
  public static final int BLACK_SALAMANDER = 10148;
  
  public static final int SWAMP_LIZARD = 10149;
  
  public static final int NOOSE_WAND = 10150;
  
  public static final int HUNTERS_CROSSBOW = 10156;
  
  public static final int KEBBIT_BOLTS = 10158;
  
  public static final int LONG_KEBBIT_BOLTS = 10159;
  
  public static final int EAGLE_FEATHER = 10167;
  
  public static final int EAGLE_CAPE = 10171;
  
  public static final int FAKE_BEAK = 10172;
  
  public static final int BIRD_BOOK = 10173;
  
  public static final int METAL_FEATHER = 10174;
  
  public static final int GOLDEN_FEATHER_10175 = 10175;
  
  public static final int SILVER_FEATHER = 10176;
  
  public static final int BRONZE_FEATHER = 10177;
  
  public static final int ODD_BIRD_SEED = 10178;
  
  public static final int FEATHERED_JOURNAL = 10179;
  
  public static final int CLUE_SCROLL_EASY_10180 = 10180;
  
  public static final int CASKET_EASY_10181 = 10181;
  
  public static final int CLUE_SCROLL_EASY_10182 = 10182;
  
  public static final int CASKET_EASY_10183 = 10183;
  
  public static final int CLUE_SCROLL_EASY_10184 = 10184;
  
  public static final int CASKET_EASY_10185 = 10185;
  
  public static final int CLUE_SCROLL_EASY_10186 = 10186;
  
  public static final int CASKET_EASY_10187 = 10187;
  
  public static final int CLUE_SCROLL_EASY_10188 = 10188;
  
  public static final int CASKET_EASY_10189 = 10189;
  
  public static final int CLUE_SCROLL_EASY_10190 = 10190;
  
  public static final int CASKET_EASY_10191 = 10191;
  
  public static final int CLUE_SCROLL_EASY_10192 = 10192;
  
  public static final int CASKET_EASY_10193 = 10193;
  
  public static final int CLUE_SCROLL_EASY_10194 = 10194;
  
  public static final int CASKET_EASY_10195 = 10195;
  
  public static final int CLUE_SCROLL_EASY_10196 = 10196;
  
  public static final int CASKET_EASY_10197 = 10197;
  
  public static final int CLUE_SCROLL_EASY_10198 = 10198;
  
  public static final int CASKET_EASY_10199 = 10199;
  
  public static final int CLUE_SCROLL_EASY_10200 = 10200;
  
  public static final int CASKET_EASY_10201 = 10201;
  
  public static final int CLUE_SCROLL_EASY_10202 = 10202;
  
  public static final int CASKET_EASY_10203 = 10203;
  
  public static final int CLUE_SCROLL_EASY_10204 = 10204;
  
  public static final int CASKET_EASY_10205 = 10205;
  
  public static final int CLUE_SCROLL_EASY_10206 = 10206;
  
  public static final int CASKET_EASY_10207 = 10207;
  
  public static final int CLUE_SCROLL_EASY_10208 = 10208;
  
  public static final int CASKET_EASY_10209 = 10209;
  
  public static final int CLUE_SCROLL_EASY_10210 = 10210;
  
  public static final int CASKET_EASY_10211 = 10211;
  
  public static final int CLUE_SCROLL_EASY_10212 = 10212;
  
  public static final int CASKET_EASY_10213 = 10213;
  
  public static final int CLUE_SCROLL_EASY_10214 = 10214;
  
  public static final int CASKET_EASY_10215 = 10215;
  
  public static final int CLUE_SCROLL_EASY_10216 = 10216;
  
  public static final int CASKET_EASY_10217 = 10217;
  
  public static final int CLUE_SCROLL_EASY_10218 = 10218;
  
  public static final int CASKET_EASY_10219 = 10219;
  
  public static final int CLUE_SCROLL_EASY_10220 = 10220;
  
  public static final int CASKET_EASY_10221 = 10221;
  
  public static final int CLUE_SCROLL_EASY_10222 = 10222;
  
  public static final int CASKET_EASY_10223 = 10223;
  
  public static final int CLUE_SCROLL_EASY_10224 = 10224;
  
  public static final int CASKET_EASY_10225 = 10225;
  
  public static final int CLUE_SCROLL_EASY_10226 = 10226;
  
  public static final int CASKET_EASY_10227 = 10227;
  
  public static final int CLUE_SCROLL_EASY_10228 = 10228;
  
  public static final int CASKET_EASY_10229 = 10229;
  
  public static final int CLUE_SCROLL_EASY_10230 = 10230;
  
  public static final int CASKET_EASY_10231 = 10231;
  
  public static final int CLUE_SCROLL_EASY_10232 = 10232;
  
  public static final int CASKET_EASY_10233 = 10233;
  
  public static final int CLUE_SCROLL_HARD_10234 = 10234;
  
  public static final int CASKET_HARD_10235 = 10235;
  
  public static final int CLUE_SCROLL_HARD_10236 = 10236;
  
  public static final int CASKET_HARD_10237 = 10237;
  
  public static final int CLUE_SCROLL_HARD_10238 = 10238;
  
  public static final int CASKET_HARD_10239 = 10239;
  
  public static final int CLUE_SCROLL_HARD_10240 = 10240;
  
  public static final int CASKET_HARD_10241 = 10241;
  
  public static final int CLUE_SCROLL_HARD_10242 = 10242;
  
  public static final int CASKET_HARD_10243 = 10243;
  
  public static final int CLUE_SCROLL_HARD_10244 = 10244;
  
  public static final int CASKET_HARD_10245 = 10245;
  
  public static final int CLUE_SCROLL_HARD_10246 = 10246;
  
  public static final int CASKET_HARD_10247 = 10247;
  
  public static final int CLUE_SCROLL_HARD_10248 = 10248;
  
  public static final int CASKET_HARD_10249 = 10249;
  
  public static final int CLUE_SCROLL_HARD_10250 = 10250;
  
  public static final int CASKET_HARD_10251 = 10251;
  
  public static final int CLUE_SCROLL_HARD_10252 = 10252;
  
  public static final int CASKET_HARD_10253 = 10253;
  
  public static final int CLUE_SCROLL_MEDIUM_10254 = 10254;
  
  public static final int CASKET_MEDIUM_10255 = 10255;
  
  public static final int CLUE_SCROLL_MEDIUM_10256 = 10256;
  
  public static final int CASKET_MEDIUM_10257 = 10257;
  
  public static final int CLUE_SCROLL_MEDIUM_10258 = 10258;
  
  public static final int CASKET_MEDIUM_10259 = 10259;
  
  public static final int CLUE_SCROLL_MEDIUM_10260 = 10260;
  
  public static final int CASKET_MEDIUM_10261 = 10261;
  
  public static final int CLUE_SCROLL_MEDIUM_10262 = 10262;
  
  public static final int CASKET_MEDIUM_10263 = 10263;
  
  public static final int CLUE_SCROLL_MEDIUM_10264 = 10264;
  
  public static final int CASKET_MEDIUM_10265 = 10265;
  
  public static final int CLUE_SCROLL_MEDIUM_10266 = 10266;
  
  public static final int CASKET_MEDIUM_10267 = 10267;
  
  public static final int CLUE_SCROLL_MEDIUM_10268 = 10268;
  
  public static final int CASKET_MEDIUM_10269 = 10269;
  
  public static final int CLUE_SCROLL_MEDIUM_10270 = 10270;
  
  public static final int CASKET_MEDIUM_10271 = 10271;
  
  public static final int CLUE_SCROLL_MEDIUM_10272 = 10272;
  
  public static final int CASKET_MEDIUM_10273 = 10273;
  
  public static final int CLUE_SCROLL_MEDIUM_10274 = 10274;
  
  public static final int CASKET_MEDIUM_10275 = 10275;
  
  public static final int CLUE_SCROLL_MEDIUM_10276 = 10276;
  
  public static final int CASKET_MEDIUM_10277 = 10277;
  
  public static final int CLUE_SCROLL_MEDIUM_10278 = 10278;
  
  public static final int CASKET_MEDIUM_10279 = 10279;
  
  public static final int WILLOW_COMP_BOW = 10280;
  
  public static final int YEW_COMP_BOW = 10282;
  
  public static final int MAGIC_COMP_BOW = 10284;
  
  public static final int RUNE_HELM_H1 = 10286;
  
  public static final int RUNE_HELM_H2 = 10288;
  
  public static final int RUNE_HELM_H3 = 10290;
  
  public static final int RUNE_HELM_H4 = 10292;
  
  public static final int RUNE_HELM_H5 = 10294;
  
  public static final int ADAMANT_HELM_H1 = 10296;
  
  public static final int ADAMANT_HELM_H2 = 10298;
  
  public static final int ADAMANT_HELM_H3 = 10300;
  
  public static final int ADAMANT_HELM_H4 = 10302;
  
  public static final int ADAMANT_HELM_H5 = 10304;
  
  public static final int BLACK_HELM_H1 = 10306;
  
  public static final int BLACK_HELM_H2 = 10308;
  
  public static final int BLACK_HELM_H3 = 10310;
  
  public static final int BLACK_HELM_H4 = 10312;
  
  public static final int BLACK_HELM_H5 = 10314;
  
  public static final int BOBS_RED_SHIRT = 10316;
  
  public static final int BOBS_BLUE_SHIRT = 10318;
  
  public static final int BOBS_GREEN_SHIRT = 10320;
  
  public static final int BOBS_BLACK_SHIRT = 10322;
  
  public static final int BOBS_PURPLE_SHIRT = 10324;
  
  public static final int PURPLE_FIRELIGHTER = 10326;
  
  public static final int WHITE_FIRELIGHTER = 10327;
  
  public static final int WHITE_LOGS = 10328;
  
  public static final int PURPLE_LOGS = 10329;
  
  public static final int _3RD_AGE_RANGE_TOP = 10330;
  
  public static final int _3RD_AGE_RANGE_LEGS = 10332;
  
  public static final int _3RD_AGE_RANGE_COIF = 10334;
  
  public static final int _3RD_AGE_VAMBRACES = 10336;
  
  public static final int _3RD_AGE_ROBE_TOP = 10338;
  
  public static final int _3RD_AGE_ROBE = 10340;
  
  public static final int _3RD_AGE_MAGE_HAT = 10342;
  
  public static final int _3RD_AGE_AMULET = 10344;
  
  public static final int _3RD_AGE_PLATELEGS = 10346;
  
  public static final int _3RD_AGE_PLATEBODY = 10348;
  
  public static final int _3RD_AGE_FULL_HELMET = 10350;
  
  public static final int _3RD_AGE_KITESHIELD = 10352;
  
  public static final int AMULET_OF_GLORY_T4 = 10354;
  
  public static final int AMULET_OF_GLORY_T3 = 10356;
  
  public static final int AMULET_OF_GLORY_T2 = 10358;
  
  public static final int AMULET_OF_GLORY_T1 = 10360;
  
  public static final int AMULET_OF_GLORY_T = 10362;
  
  public static final int STRENGTH_AMULET_T = 10364;
  
  public static final int AMULET_OF_MAGIC_T = 10366;
  
  public static final int ZAMORAK_BRACERS = 10368;
  
  public static final int ZAMORAK_DHIDE_BODY = 10370;
  
  public static final int ZAMORAK_CHAPS = 10372;
  
  public static final int ZAMORAK_COIF = 10374;
  
  public static final int GUTHIX_BRACERS = 10376;
  
  public static final int GUTHIX_DHIDE_BODY = 10378;
  
  public static final int GUTHIX_CHAPS = 10380;
  
  public static final int GUTHIX_COIF = 10382;
  
  public static final int SARADOMIN_BRACERS = 10384;
  
  public static final int SARADOMIN_DHIDE_BODY = 10386;
  
  public static final int SARADOMIN_CHAPS = 10388;
  
  public static final int SARADOMIN_COIF = 10390;
  
  public static final int A_POWDERED_WIG = 10392;
  
  public static final int FLARED_TROUSERS = 10394;
  
  public static final int PANTALOONS = 10396;
  
  public static final int SLEEPING_CAP = 10398;
  
  public static final int BLACK_ELEGANT_SHIRT = 10400;
  
  public static final int BLACK_ELEGANT_LEGS = 10402;
  
  public static final int RED_ELEGANT_SHIRT = 10404;
  
  public static final int RED_ELEGANT_LEGS = 10406;
  
  public static final int BLUE_ELEGANT_SHIRT = 10408;
  
  public static final int BLUE_ELEGANT_LEGS = 10410;
  
  public static final int GREEN_ELEGANT_SHIRT = 10412;
  
  public static final int GREEN_ELEGANT_LEGS = 10414;
  
  public static final int PURPLE_ELEGANT_SHIRT = 10416;
  
  public static final int PURPLE_ELEGANT_LEGS = 10418;
  
  public static final int WHITE_ELEGANT_BLOUSE = 10420;
  
  public static final int WHITE_ELEGANT_SKIRT = 10422;
  
  public static final int RED_ELEGANT_BLOUSE = 10424;
  
  public static final int RED_ELEGANT_SKIRT = 10426;
  
  public static final int BLUE_ELEGANT_BLOUSE = 10428;
  
  public static final int BLUE_ELEGANT_SKIRT = 10430;
  
  public static final int GREEN_ELEGANT_BLOUSE = 10432;
  
  public static final int GREEN_ELEGANT_SKIRT = 10434;
  
  public static final int PURPLE_ELEGANT_BLOUSE = 10436;
  
  public static final int PURPLE_ELEGANT_SKIRT = 10438;
  
  public static final int SARADOMIN_CROZIER = 10440;
  
  public static final int GUTHIX_CROZIER = 10442;
  
  public static final int ZAMORAK_CROZIER = 10444;
  
  public static final int SARADOMIN_CLOAK = 10446;
  
  public static final int GUTHIX_CLOAK = 10448;
  
  public static final int ZAMORAK_CLOAK = 10450;
  
  public static final int SARADOMIN_MITRE = 10452;
  
  public static final int GUTHIX_MITRE = 10454;
  
  public static final int ZAMORAK_MITRE = 10456;
  
  public static final int SARADOMIN_ROBE_TOP = 10458;
  
  public static final int ZAMORAK_ROBE_TOP = 10460;
  
  public static final int GUTHIX_ROBE_TOP = 10462;
  
  public static final int SARADOMIN_ROBE_LEGS = 10464;
  
  public static final int GUTHIX_ROBE_LEGS = 10466;
  
  public static final int ZAMORAK_ROBE_LEGS = 10468;
  
  public static final int SARADOMIN_STOLE = 10470;
  
  public static final int GUTHIX_STOLE = 10472;
  
  public static final int ZAMORAK_STOLE = 10474;
  
  public static final int PURPLE_SWEETS_10476 = 10476;
  
  public static final int SCROLL_10485 = 10485;
  
  public static final int EMPTY_SACK_10486 = 10486;
  
  public static final int UNDEAD_CHICKEN = 10487;
  
  public static final int SELECTED_IRON = 10488;
  
  public static final int BAR_MAGNET = 10489;
  
  public static final int UNDEAD_TWIGS = 10490;
  
  public static final int BLESSED_AXE = 10491;
  
  public static final int RESEARCH_NOTES_10492 = 10492;
  
  public static final int TRANSLATED_NOTES = 10493;
  
  public static final int A_PATTERN = 10494;
  
  public static final int A_CONTAINER = 10495;
  
  public static final int POLISHED_BUTTONS = 10496;
  
  public static final int AVAS_ATTRACTOR = 10498;
  
  public static final int AVAS_ACCUMULATOR = 10499;
  
  public static final int CRONEMADE_AMULET = 10500;
  
  public static final int SNOWBALL = 10501;
  
  public static final int GUBLINCH_SHARDS = 10506;
  
  public static final int REINDEER_HAT = 10507;
  
  public static final int WINTUMBER_TREE = 10508;
  
  public static final int FREMENNIK_SEA_BOOTS = 10510;
  
  public static final int SCROLL_10512 = 10512;
  
  public static final int CRACKERS = 10513;
  
  public static final int TOFU = 10514;
  
  public static final int WORMS = 10515;
  
  public static final int ATTACKER_HORN = 10516;
  
  public static final int ATTACKER_HORN_10517 = 10517;
  
  public static final int ATTACKER_HORN_10518 = 10518;
  
  public static final int ATTACKER_HORN_10519 = 10519;
  
  public static final int ATTACKER_HORN_10520 = 10520;
  
  public static final int COLLECTION_BAG = 10521;
  
  public static final int COLLECTION_BAG_10522 = 10522;
  
  public static final int COLLECTION_BAG_10523 = 10523;
  
  public static final int COLLECTION_BAG_10524 = 10524;
  
  public static final int COLLECTION_BAG_10525 = 10525;
  
  public static final int HEALER_HORN = 10526;
  
  public static final int HEALER_HORN_10527 = 10527;
  
  public static final int HEALER_HORN_10528 = 10528;
  
  public static final int HEALER_HORN_10529 = 10529;
  
  public static final int HEALER_HORN_10530 = 10530;
  
  public static final int GREEN_EGG = 10531;
  
  public static final int RED_EGG = 10532;
  
  public static final int BLUE_EGG = 10533;
  
  public static final int YELLOW_EGG = 10534;
  
  public static final int POISONED_EGG = 10535;
  
  public static final int SPIKEDPOIS_EGG = 10536;
  
  public static final int OMEGA_EGG = 10537;
  
  public static final int DEFENDER_HORN = 10538;
  
  public static final int POISONED_TOFU = 10539;
  
  public static final int POISONED_WORMS = 10540;
  
  public static final int POISONED_MEAT = 10541;
  
  public static final int HEALING_VIAL4 = 10542;
  
  public static final int HEALING_VIAL3 = 10543;
  
  public static final int HEALING_VIAL2 = 10544;
  
  public static final int HEALING_VIAL1 = 10545;
  
  public static final int HEALING_VIAL = 10546;
  
  public static final int HEALER_HAT = 10547;
  
  public static final int FIGHTER_HAT = 10548;
  
  public static final int RUNNER_HAT = 10549;
  
  public static final int RANGER_HAT = 10550;
  
  public static final int FIGHTER_TORSO = 10551;
  
  public static final int RUNNER_BOOTS = 10552;
  
  public static final int PENANCE_GLOVES = 10553;
  
  public static final int PENANCE_GLOVES_10554 = 10554;
  
  public static final int PENANCE_SKIRT = 10555;
  
  public static final int ATTACKER_ICON = 10556;
  
  public static final int COLLECTOR_ICON = 10557;
  
  public static final int DEFENDER_ICON = 10558;
  
  public static final int HEALER_ICON = 10559;
  
  public static final int COLLECTOR_HORN = 10560;
  
  public static final int SPIKES_10561 = 10561;
  
  public static final int QUEEN_HELP_BOOK = 10562;
  
  public static final int NO_EGGS = 10563;
  
  public static final int GRANITE_BODY = 10564;
  
  public static final int FIRE_CAPE_10566 = 10566;
  
  public static final int HEALER_ICON_10567 = 10567;
  
  public static final int KERIS = 10581;
  
  public static final int KERISP = 10582;
  
  public static final int KERISP_10583 = 10583;
  
  public static final int KERISP_10584 = 10584;
  
  public static final int PARCHMENT = 10585;
  
  public static final int COMBAT_LAMP = 10586;
  
  public static final int TARNS_DIARY = 10587;
  
  public static final int SALVE_AMULET_E = 10588;
  
  public static final int GRANITE_HELM = 10589;
  
  public static final int TERROR_DOG = 10591;
  
  public static final int PENGUIN_BONGOS = 10592;
  
  public static final int COWBELLS = 10593;
  
  public static final int CLOCKWORK_BOOK = 10594;
  
  public static final int CLOCKWORK_SUIT = 10595;
  
  public static final int CLOCKWORK_SUIT_10596 = 10596;
  
  public static final int MISSION_REPORT = 10597;
  
  public static final int MISSION_REPORT_10598 = 10598;
  
  public static final int MISSION_REPORT_10599 = 10599;
  
  public static final int KGP_ID_CARD = 10600;
  
  public static final int ARCTIC_PYRE_LOGS = 10808;
  
  public static final int ARCTIC_PINE_LOGS = 10810;
  
  public static final int SPLIT_LOG = 10812;
  
  public static final int HAIR = 10814;
  
  public static final int RAW_YAK_MEAT = 10816;
  
  public static final int YAKHIDE = 10818;
  
  public static final int CURED_YAKHIDE = 10820;
  
  public static final int YAKHIDE_ARMOUR = 10822;
  
  public static final int YAKHIDE_ARMOUR_10824 = 10824;
  
  public static final int NEITIZNOT_SHIELD = 10826;
  
  public static final int HELM_OF_NEITIZNOT = 10828;
  
  public static final int DOCUMENTS = 10829;
  
  public static final int ROYAL_DECREE = 10830;
  
  public static final int EMPTY_TAX_BAG = 10831;
  
  public static final int LIGHT_TAX_BAG = 10832;
  
  public static final int NORMAL_TAX_BAG = 10833;
  
  public static final int HEFTY_TAX_BAG = 10834;
  
  public static final int BULGING_TAXBAG = 10835;
  
  public static final int SILLY_JESTER_HAT = 10836;
  
  public static final int SILLY_JESTER_TOP = 10837;
  
  public static final int SILLY_JESTER_TIGHTS = 10838;
  
  public static final int SILLY_JESTER_BOOTS = 10839;
  
  public static final int A_JESTER_STICK = 10840;
  
  public static final int APRICOT_CREAM_PIE = 10841;
  
  public static final int DECAPITATED_HEAD_10842 = 10842;
  
  public static final int SPRING_SQIRK = 10844;
  
  public static final int SUMMER_SQIRK = 10845;
  
  public static final int AUTUMN_SQIRK = 10846;
  
  public static final int WINTER_SQIRK = 10847;
  
  public static final int SPRING_SQIRKJUICE = 10848;
  
  public static final int SUMMER_SQIRKJUICE = 10849;
  
  public static final int AUTUMN_SQIRKJUICE = 10850;
  
  public static final int WINTER_SQIRKJUICE = 10851;
  
  public static final int SUMMER_GARDEN = 10852;
  
  public static final int SPRING_GARDEN = 10853;
  
  public static final int AUTUMN_GARDEN = 10854;
  
  public static final int WINTER_GARDEN = 10855;
  
  public static final int SIN_SEERS_NOTE = 10856;
  
  public static final int SEVERED_LEG = 10857;
  
  public static final int SHADOW_SWORD = 10858;
  
  public static final int TEA_FLASK = 10859;
  
  public static final int HARD_HAT = 10862;
  
  public static final int BUILDERS_SHIRT = 10863;
  
  public static final int BUILDERS_TROUSERS = 10864;
  
  public static final int BUILDERS_BOOTS = 10865;
  
  public static final int RIVETS = 10866;
  
  public static final int BINDING_FLUID = 10870;
  
  public static final int PIPE_10871 = 10871;
  
  public static final int PIPE_RING = 10872;
  
  public static final int METAL_SHEET = 10873;
  
  public static final int COLOURED_BALL = 10874;
  
  public static final int VALVE_WHEEL = 10875;
  
  public static final int METAL_BAR = 10876;
  
  public static final int PLAIN_SATCHEL = 10877;
  
  public static final int GREEN_SATCHEL = 10878;
  
  public static final int RED_SATCHEL = 10879;
  
  public static final int BLACK_SATCHEL = 10880;
  
  public static final int GOLD_SATCHEL = 10881;
  
  public static final int RUNE_SATCHEL = 10882;
  
  public static final int FUSE_10884 = 10884;
  
  public static final int KEG = 10885;
  
  public static final int PRAYER_BOOK = 10886;
  
  public static final int BARRELCHEST_ANCHOR = 10887;
  
  public static final int BARRELCHEST_ANCHOR_10888 = 10888;
  
  public static final int BLESSED_LAMP = 10889;
  
  public static final int PRAYER_BOOK_10890 = 10890;
  
  public static final int WOODEN_CAT = 10891;
  
  public static final int CRANIAL_CLAMP = 10893;
  
  public static final int BRAIN_TONGS = 10894;
  
  public static final int BELL_JAR = 10895;
  
  public static final int WOLF_WHISTLE = 10896;
  
  public static final int SHIPPING_ORDER = 10897;
  
  public static final int KEG_10898 = 10898;
  
  public static final int CRATE_PART = 10899;
  
  public static final int SKULL_STAPLE = 10904;
  
  public static final int MIXTURE__STEP_14 = 10909;
  
  public static final int MIXTURE__STEP_13 = 10911;
  
  public static final int MIXTURE__STEP_12 = 10913;
  
  public static final int MIXTURE__STEP_11 = 10915;
  
  public static final int MIXTURE__STEP_24 = 10917;
  
  public static final int MIXTURE__STEP_23 = 10919;
  
  public static final int MIXTURE__STEP_22 = 10921;
  
  public static final int MIXTURE__STEP_21 = 10923;
  
  public static final int SANFEW_SERUM4 = 10925;
  
  public static final int SANFEW_SERUM3 = 10927;
  
  public static final int SANFEW_SERUM2 = 10929;
  
  public static final int SANFEW_SERUM1 = 10931;
  
  public static final int LUMBERJACK_BOOTS = 10933;
  
  public static final int REWARD_TOKEN_10934 = 10934;
  
  public static final int REWARD_TOKEN_10935 = 10935;
  
  public static final int REWARD_TOKEN_10936 = 10936;
  
  public static final int NAIL_BEAST_NAILS = 10937;
  
  public static final int LUMBERJACK_TOP = 10939;
  
  public static final int LUMBERJACK_LEGS = 10940;
  
  public static final int LUMBERJACK_HAT = 10941;
  
  public static final int REWARD_TOKEN_10942 = 10942;
  
  public static final int REWARD_TOKEN_10943 = 10943;
  
  public static final int REWARD_TOKEN_10944 = 10944;
  
  public static final int PUSHUP = 10946;
  
  public static final int RUN = 10947;
  
  public static final int SITUP = 10948;
  
  public static final int STARJUMP = 10949;
  
  public static final int SKULL_STAPLES = 10950;
  
  public static final int SKULL_STAPLES_10951 = 10951;
  
  public static final int SLAYER_BELL = 10952;
  
  public static final int FROGLEATHER_BODY = 10954;
  
  public static final int FROGLEATHER_CHAPS = 10956;
  
  public static final int FROGLEATHER_BOOTS = 10958;
  
  public static final int GREEN_GLOOP_SOUP = 10960;
  
  public static final int FROGSPAWN_GUMBO = 10961;
  
  public static final int FROGBURGER = 10962;
  
  public static final int COATED_FROGS_LEGS = 10963;
  
  public static final int BAT_SHISH = 10964;
  
  public static final int FINGERS = 10965;
  
  public static final int GRUBS__LA_MODE = 10966;
  
  public static final int ROAST_FROG = 10967;
  
  public static final int MUSHROOMS = 10968;
  
  public static final int FILLETS = 10969;
  
  public static final int LOACH = 10970;
  
  public static final int EEL_SUSHI = 10971;
  
  public static final int DORGESHKAAN_SPHERE = 10972;
  
  public static final int LIGHT_ORB = 10973;
  
  public static final int SPANNER = 10975;
  
  public static final int LONG_BONE = 10976;
  
  public static final int CURVED_BONE = 10977;
  
  public static final int SWAMP_WEED = 10978;
  
  public static final int EMPTY_LIGHT_ORB = 10980;
  
  public static final int CAVE_GOBLIN_WIRE = 10981;
  
  public static final int COG = 10983;
  
  public static final int COG_10984 = 10984;
  
  public static final int FUSE_10985 = 10985;
  
  public static final int FUSE_10986 = 10986;
  
  public static final int METER = 10987;
  
  public static final int METER_10988 = 10988;
  
  public static final int CAPACITOR = 10989;
  
  public static final int CAPACITOR_10990 = 10990;
  
  public static final int LEVER_10991 = 10991;
  
  public static final int LEVER_10992 = 10992;
  
  public static final int POWERBOX = 10993;
  
  public static final int POWERBOX_10994 = 10994;
  
  public static final int PERFECT_SHELL = 10995;
  
  public static final int PERFECT_SNAIL_SHELL = 10996;
  
  public static final int MOLANISK = 10997;
  
  public static final int CAVE_GOBLIN = 10998;
  
  public static final int GOBLIN_BOOK = 10999;
  
  public static final int DAGONHAI_HISTORY = 11001;
  
  public static final int SINKETHS_DIARY = 11002;
  
  public static final int AN_EMPTY_FOLDER = 11003;
  
  public static final int USED_FOLDER = 11006;
  
  public static final int FULL_FOLDER = 11007;
  
  public static final int RATS_PAPER = 11008;
  
  public static final int LETTER_TO_SUROK = 11009;
  
  public static final int SUROKS_LETTER = 11010;
  
  public static final int ZAFFS_INSTRUCTIONS = 11011;
  
  public static final int WAND = 11012;
  
  public static final int INFUSED_WAND = 11013;
  
  public static final int BEACON_RING = 11014;
  
  public static final int CHICKEN_FEET = 11019;
  
  public static final int CHICKEN_WINGS = 11020;
  
  public static final int CHICKEN_HEAD = 11021;
  
  public static final int CHICKEN_LEGS = 11022;
  
  public static final int MAGIC_EGG = 11023;
  
  public static final int RABBIT_MOULD = 11024;
  
  public static final int CHOCOLATE_CHUNKS = 11025;
  
  public static final int CHOCOLATE_KEBBIT = 11026;
  
  public static final int EASTER_EGG_11027 = 11027;
  
  public static final int EASTER_EGG_11028 = 11028;
  
  public static final int EASTER_EGG_11029 = 11029;
  
  public static final int EASTER_EGG_11030 = 11030;
  
  public static final int DAMP_PLANKS = 11031;
  
  public static final int CRUDE_CARVING = 11032;
  
  public static final int CRUDER_CARVING = 11033;
  
  public static final int SVENS_LAST_MAP = 11034;
  
  public static final int WINDSWEPT_LOGS = 11035;
  
  public static final int PARCHMENT_11036 = 11036;
  
  public static final int BRINE_SABRE = 11037;
  
  public static final int KEY_11039 = 11039;
  
  public static final int KEY_11040 = 11040;
  
  public static final int KEY_11041 = 11041;
  
  public static final int KEY_11042 = 11042;
  
  public static final int KEY_11043 = 11043;
  
  public static final int ROTTEN_BARREL = 11044;
  
  public static final int ROTTEN_BARREL_11045 = 11045;
  
  public static final int ROPE_11046 = 11046;
  
  public static final int BRINE_RAT = 11047;
  
  public static final int ARMOUR_SHARD = 11048;
  
  public static final int ARTEFACT = 11049;
  
  public static final int AXE_HEAD = 11050;
  
  public static final int ARTEFACT_11051 = 11051;
  
  public static final int HELMET_FRAGMENT = 11052;
  
  public static final int ARTEFACT_11053 = 11053;
  
  public static final int SHIELD_FRAGMENT = 11054;
  
  public static final int ARTEFACT_11055 = 11055;
  
  public static final int SWORD_FRAGMENT = 11056;
  
  public static final int ARTEFACT_11057 = 11057;
  
  public static final int MACE = 11058;
  
  public static final int ARTEFACT_11059 = 11059;
  
  public static final int GOBLIN_VILLAGE_SPHERE = 11060;
  
  public static final int ANCIENT_MACE = 11061;
  
  public static final int ZANIK_SLICE = 11062;
  
  public static final int BRACELET_MOULD = 11065;
  
  public static final int GOLD_BRACELET = 11068;
  
  public static final int GOLD_BRACELET_11069 = 11069;
  
  public static final int SAPPHIRE_BRACELET = 11071;
  
  public static final int SAPPHIRE_BRACELET_11072 = 11072;
  
  public static final int BRACELET_OF_CLAY = 11074;
  
  public static final int EMERALD_BRACELET = 11076;
  
  public static final int EMERALD_BRACELET_11078 = 11078;
  
  public static final int CASTLE_WARS_BRACELET3 = 11079;
  
  public static final int CASTLE_WARS_BRACELET2 = 11081;
  
  public static final int CASTLE_WARS_BRACELET1 = 11083;
  
  public static final int RUBY_BRACELET = 11085;
  
  public static final int RUBY_BRACELET_11087 = 11087;
  
  public static final int INOCULATION_BRACELET = 11088;
  
  public static final int PHOENIX_NECKLACE = 11090;
  
  public static final int DIAMOND_BRACELET = 11092;
  
  public static final int DIAMOND_BRACELET_11094 = 11094;
  
  public static final int ABYSSAL_BRACELET5 = 11095;
  
  public static final int ABYSSAL_BRACELET4 = 11097;
  
  public static final int ABYSSAL_BRACELET3 = 11099;
  
  public static final int ABYSSAL_BRACELET2 = 11101;
  
  public static final int ABYSSAL_BRACELET1 = 11103;
  
  public static final int SKILLS_NECKLACE4 = 11105;
  
  public static final int SKILLS_NECKLACE3 = 11107;
  
  public static final int SKILLS_NECKLACE2 = 11109;
  
  public static final int SKILLS_NECKLACE1 = 11111;
  
  public static final int SKILLS_NECKLACE = 11113;
  
  public static final int DRAGONSTONE_BRACELET = 11115;
  
  public static final int DRAGON_BRACELET = 11117;
  
  public static final int COMBAT_BRACELET4 = 11118;
  
  public static final int COMBAT_BRACELET3 = 11120;
  
  public static final int COMBAT_BRACELET2 = 11122;
  
  public static final int COMBAT_BRACELET1 = 11124;
  
  public static final int COMBAT_BRACELET = 11126;
  
  public static final int BERSERKER_NECKLACE = 11128;
  
  public static final int ONYX_BRACELET = 11130;
  
  public static final int ONYX_BRACELET_11132 = 11132;
  
  public static final int REGEN_BRACELET = 11133;
  
  public static final int KARAMJA_GLOVES_1 = 11136;
  
  public static final int ANTIQUE_LAMP_11137 = 11137;
  
  public static final int KARAMJA_GLOVES_2 = 11138;
  
  public static final int ANTIQUE_LAMP_11139 = 11139;
  
  public static final int KARAMJA_GLOVES_3 = 11140;
  
  public static final int ANTIQUE_LAMP_11141 = 11141;
  
  public static final int DREAM_VIAL_EMPTY = 11151;
  
  public static final int DREAM_VIAL_WATER = 11152;
  
  public static final int DREAM_VIAL_HERB = 11153;
  
  public static final int DREAM_POTION = 11154;
  
  public static final int GROUND_ASTRAL_RUNE = 11155;
  
  public static final int ASTRAL_RUNE_SHARDS = 11156;
  
  public static final int DREAMY_LAMP = 11157;
  
  public static final int CYRISUSS_CHEST = 11158;
  
  public static final int HUNTER_KIT = 11159;
  
  public static final int PHOENIX_CROSSBOW_11165 = 11165;
  
  public static final int PHOENIX_CROSSBOW_11167 = 11167;
  
  public static final int NEWSPAPER = 11169;
  
  public static final int NEWSPAPER_11171 = 11171;
  
  public static final int HALF_CERTIFICATE = 11173;
  
  public static final int HALF_CERTIFICATE_11174 = 11174;
  
  public static final int UNCLEANED_FIND = 11175;
  
  public static final int ARROWHEADS = 11176;
  
  public static final int JEWELLERY = 11177;
  
  public static final int POTTERY = 11178;
  
  public static final int OLD_COIN = 11179;
  
  public static final int ANCIENT_COIN = 11180;
  
  public static final int ANCIENT_SYMBOL = 11181;
  
  public static final int OLD_SYMBOL = 11182;
  
  public static final int OLD_CHIPPED_VASE = 11183;
  
  public static final int MUSEUM_MAP = 11184;
  
  public static final int ANTIQUE_LAMP_11185 = 11185;
  
  public static final int ANTIQUE_LAMP_11186 = 11186;
  
  public static final int ANTIQUE_LAMP_11187 = 11187;
  
  public static final int ANTIQUE_LAMP_11188 = 11188;
  
  public static final int ANTIQUE_LAMP_11189 = 11189;
  
  public static final int DIGSITE_PENDANT_1 = 11190;
  
  public static final int DIGSITE_PENDANT_2 = 11191;
  
  public static final int DIGSITE_PENDANT_3 = 11192;
  
  public static final int DIGSITE_PENDANT_4 = 11193;
  
  public static final int DIGSITE_PENDANT_5 = 11194;
  
  public static final int CLEAN_NECKLACE = 11195;
  
  public static final int GRIFFIN_FEATHER = 11196;
  
  public static final int MIAZRQAS_PENDANT = 11197;
  
  public static final int MUSIC_SHEET = 11198;
  
  public static final int RUPERTS_HELMET = 11199;
  
  public static final int DWARVEN_HELMET = 11200;
  
  public static final int SHRINKING_RECIPE = 11202;
  
  public static final int TODO_LIST = 11203;
  
  public static final int SHRINKMEQUICK = 11204;
  
  public static final int SHRUNK_OGLEROOT = 11205;
  
  public static final int GOLDEN_GOBLIN = 11210;
  
  public static final int MAGIC_BEANS = 11211;
  
  public static final int DRAGON_ARROW = 11212;
  
  public static final int DRAGON_FIRE_ARROW = 11217;
  
  public static final int DRAGON_FIRE_ARROW_LIT = 11222;
  
  public static final int DRAGON_ARROWP = 11227;
  
  public static final int DRAGON_ARROWP_11228 = 11228;
  
  public static final int DRAGON_ARROWP_11229 = 11229;
  
  public static final int DRAGON_DART = 11230;
  
  public static final int DRAGON_DARTP = 11231;
  
  public static final int DRAGON_DART_TIP = 11232;
  
  public static final int DRAGON_DARTP_11233 = 11233;
  
  public static final int DRAGON_DARTP_11234 = 11234;
  
  public static final int DARK_BOW = 11235;
  
  public static final int DRAGON_ARROWTIPS = 11237;
  
  public static final int BABY_IMPLING_JAR = 11238;
  
  public static final int YOUNG_IMPLING_JAR = 11240;
  
  public static final int GOURMET_IMPLING_JAR = 11242;
  
  public static final int EARTH_IMPLING_JAR = 11244;
  
  public static final int ESSENCE_IMPLING_JAR = 11246;
  
  public static final int ECLECTIC_IMPLING_JAR = 11248;
  
  public static final int NATURE_IMPLING_JAR = 11250;
  
  public static final int MAGPIE_IMPLING_JAR = 11252;
  
  public static final int NINJA_IMPLING_JAR = 11254;
  
  public static final int DRAGON_IMPLING_JAR = 11256;
  
  public static final int JAR_GENERATOR = 11258;
  
  public static final int MAGIC_BUTTERFLY_NET = 11259;
  
  public static final int IMPLING_JAR = 11260;
  
  public static final int IMP_REPELLENT = 11262;
  
  public static final int ANCHOVY_OIL = 11264;
  
  public static final int ANCHOVY_PASTE = 11266;
  
  public static final int DUMMY_11267 = 11267;
  
  public static final int DUMMY_11268 = 11268;
  
  public static final int DUMMY_11269 = 11269;
  
  public static final int DUMMY_11271 = 11271;
  
  public static final int IMPLING_SCROLL = 11273;
  
  public static final int ELVARGS_HEAD = 11279;
  
  public static final int CAVALIER_MASK = 11280;
  
  public static final int BERET_MASK = 11282;
  
  public static final int DRAGONFIRE_SHIELD = 11283;
  
  public static final int DRAGONFIRE_SHIELD_11284 = 11284;
  
  public static final int DRACONIC_VISAGE = 11286;
  
  public static final int BARBARIAN_ROD = 11323;
  
  public static final int ROE = 11324;
  
  public static final int CAVIAR = 11326;
  
  public static final int LEAPING_TROUT = 11328;
  
  public static final int LEAPING_SALMON = 11330;
  
  public static final int LEAPING_STURGEON = 11332;
  
  public static final int FISH_OFFCUTS = 11334;
  
  public static final int DRAGON_FULL_HELM = 11335;
  
  public static final int MANGLED_BONES = 11337;
  
  public static final int CHEWED_BONES = 11338;
  
  public static final int MY_NOTES = 11339;
  
  public static final int BARBARIAN_SKILLS = 11340;
  
  public static final int ANCIENT_PAGE = 11341;
  
  public static final int ANCIENT_PAGE_11342 = 11342;
  
  public static final int ANCIENT_PAGE_11343 = 11343;
  
  public static final int ANCIENT_PAGE_11344 = 11344;
  
  public static final int ANCIENT_PAGE_11345 = 11345;
  
  public static final int ANCIENT_PAGE_11346 = 11346;
  
  public static final int ANCIENT_PAGE_11347 = 11347;
  
  public static final int ANCIENT_PAGE_11348 = 11348;
  
  public static final int ANCIENT_PAGE_11349 = 11349;
  
  public static final int ANCIENT_PAGE_11350 = 11350;
  
  public static final int ANCIENT_PAGE_11351 = 11351;
  
  public static final int ANCIENT_PAGE_11352 = 11352;
  
  public static final int ANCIENT_PAGE_11353 = 11353;
  
  public static final int ANCIENT_PAGE_11354 = 11354;
  
  public static final int ANCIENT_PAGE_11355 = 11355;
  
  public static final int ANCIENT_PAGE_11356 = 11356;
  
  public static final int ANCIENT_PAGE_11357 = 11357;
  
  public static final int ANCIENT_PAGE_11358 = 11358;
  
  public static final int ANCIENT_PAGE_11359 = 11359;
  
  public static final int ANCIENT_PAGE_11360 = 11360;
  
  public static final int ANCIENT_PAGE_11361 = 11361;
  
  public static final int ANCIENT_PAGE_11362 = 11362;
  
  public static final int ANCIENT_PAGE_11363 = 11363;
  
  public static final int ANCIENT_PAGE_11364 = 11364;
  
  public static final int ANCIENT_PAGE_11365 = 11365;
  
  public static final int ANCIENT_PAGE_11366 = 11366;
  
  public static final int BRONZE_HASTA = 11367;
  
  public static final int IRON_HASTA = 11369;
  
  public static final int STEEL_HASTA = 11371;
  
  public static final int MITHRIL_HASTA = 11373;
  
  public static final int ADAMANT_HASTA = 11375;
  
  public static final int RUNE_HASTA = 11377;
  
  public static final int BRONZE_HASTAP = 11379;
  
  public static final int BRONZE_HASTAKP = 11381;
  
  public static final int BRONZE_HASTAP_11382 = 11382;
  
  public static final int BRONZE_HASTAP_11384 = 11384;
  
  public static final int IRON_HASTAP = 11386;
  
  public static final int IRON_HASTAKP = 11388;
  
  public static final int IRON_HASTAP_11389 = 11389;
  
  public static final int IRON_HASTAP_11391 = 11391;
  
  public static final int STEEL_HASTAP = 11393;
  
  public static final int STEEL_HASTAKP = 11395;
  
  public static final int STEEL_HASTAP_11396 = 11396;
  
  public static final int STEEL_HASTAP_11398 = 11398;
  
  public static final int MITHRIL_HASTAP = 11400;
  
  public static final int MITHRIL_HASTAKP = 11402;
  
  public static final int MITHRIL_HASTAP_11403 = 11403;
  
  public static final int MITHRIL_HASTAP_11405 = 11405;
  
  public static final int ADAMANT_HASTAP = 11407;
  
  public static final int ADAMANT_HASTAKP = 11409;
  
  public static final int ADAMANT_HASTAP_11410 = 11410;
  
  public static final int ADAMANT_HASTAP_11412 = 11412;
  
  public static final int RUNE_HASTAP = 11414;
  
  public static final int RUNE_HASTAKP = 11416;
  
  public static final int RUNE_HASTAP_11417 = 11417;
  
  public static final int RUNE_HASTAP_11419 = 11419;
  
  public static final int FISH_VIAL = 11427;
  
  public static final int FISH_VIAL_11428 = 11428;
  
  public static final int ATTACK_MIX2 = 11429;
  
  public static final int ATTACK_MIX1 = 11431;
  
  public static final int ANTIPOISON_MIX2 = 11433;
  
  public static final int ANTIPOISON_MIX1 = 11435;
  
  public static final int RELICYMS_MIX2 = 11437;
  
  public static final int RELICYMS_MIX1 = 11439;
  
  public static final int STRENGTH_MIX1 = 11441;
  
  public static final int STRENGTH_MIX2 = 11443;
  
  public static final int COMBAT_MIX2 = 11445;
  
  public static final int COMBAT_MIX1 = 11447;
  
  public static final int RESTORE_MIX2 = 11449;
  
  public static final int RESTORE_MIX1 = 11451;
  
  public static final int ENERGY_MIX2 = 11453;
  
  public static final int ENERGY_MIX1 = 11455;
  
  public static final int DEFENCE_MIX2 = 11457;
  
  public static final int DEFENCE_MIX1 = 11459;
  
  public static final int AGILITY_MIX2 = 11461;
  
  public static final int AGILITY_MIX1 = 11463;
  
  public static final int PRAYER_MIX2 = 11465;
  
  public static final int PRAYER_MIX1 = 11467;
  
  public static final int SUPERATTACK_MIX2 = 11469;
  
  public static final int SUPERATTACK_MIX1 = 11471;
  
  public static final int ANTIPOISON_SUPERMIX2 = 11473;
  
  public static final int ANTIPOISON_SUPERMIX1 = 11475;
  
  public static final int FISHING_MIX2 = 11477;
  
  public static final int FISHING_MIX1 = 11479;
  
  public static final int SUPER_ENERGY_MIX2 = 11481;
  
  public static final int SUPER_ENERGY_MIX1 = 11483;
  
  public static final int SUPER_STR_MIX2 = 11485;
  
  public static final int SUPER_STR_MIX1 = 11487;
  
  public static final int MAGIC_ESSENCE_MIX2 = 11489;
  
  public static final int MAGIC_ESSENCE_MIX1 = 11491;
  
  public static final int SUPER_RESTORE_MIX2 = 11493;
  
  public static final int SUPER_RESTORE_MIX1 = 11495;
  
  public static final int SUPER_DEF_MIX2 = 11497;
  
  public static final int SUPER_DEF_MIX1 = 11499;
  
  public static final int ANTIDOTE_MIX2 = 11501;
  
  public static final int ANTIDOTE_MIX1 = 11503;
  
  public static final int ANTIFIRE_MIX2 = 11505;
  
  public static final int ANTIFIRE_MIX1 = 11507;
  
  public static final int RANGING_MIX2 = 11509;
  
  public static final int RANGING_MIX1 = 11511;
  
  public static final int MAGIC_MIX2 = 11513;
  
  public static final int MAGIC_MIX1 = 11515;
  
  public static final int HUNTING_MIX2 = 11517;
  
  public static final int HUNTING_MIX1 = 11519;
  
  public static final int ZAMORAK_MIX2 = 11521;
  
  public static final int ZAMORAK_MIX1 = 11523;
  
  public static final int FEATHER_11525 = 11525;
  
  public static final int MOUNTED_HARPOONFISH = 11578;
  
  public static final int OAK_MOUNTED_FISH_DISPLAY = 11599;
  
  public static final int MAHOGANY_MOUNTED_FISH_DISPLAY = 11601;
  
  public static final int TEAK_MOUNTED_FISH_DISPLAY = 11603;
  
  public static final int AVAS_DEVICE = 11628;
  
  public static final int BOOK_OF_KNOWLEDGE = 11640;
  
  public static final int GLASSBLOWING_BOOK = 11656;
  
  public static final int VOID_MAGE_HELM = 11663;
  
  public static final int VOID_RANGER_HELM = 11664;
  
  public static final int VOID_MELEE_HELM = 11665;
  
  public static final int VOID_SEAL8 = 11666;
  
  public static final int VOID_SEAL7 = 11667;
  
  public static final int VOID_SEAL6 = 11668;
  
  public static final int VOID_SEAL5 = 11669;
  
  public static final int VOID_SEAL4 = 11670;
  
  public static final int VOID_SEAL3 = 11671;
  
  public static final int VOID_SEAL2 = 11672;
  
  public static final int VOID_SEAL1 = 11673;
  
  public static final int EXPLORERS_NOTES = 11677;
  
  public static final int BLACK_KNIGHT_HELM = 11678;
  
  public static final int ANTIQUE_LAMP_11679 = 11679;
  
  public static final int ADDRESS_FORM = 11680;
  
  public static final int SCRAP_PAPER = 11681;
  
  public static final int HAIR_CLIP = 11682;
  
  public static final int FIRE_RUNE_11686 = 11686;
  
  public static final int WATER_RUNE_11687 = 11687;
  
  public static final int AIR_RUNE_11688 = 11688;
  
  public static final int EARTH_RUNE_11689 = 11689;
  
  public static final int MIND_RUNE_11690 = 11690;
  
  public static final int BODY_RUNE_11691 = 11691;
  
  public static final int DEATH_RUNE_11692 = 11692;
  
  public static final int NATURE_RUNE_11693 = 11693;
  
  public static final int CHAOS_RUNE_11694 = 11694;
  
  public static final int LAW_RUNE_11695 = 11695;
  
  public static final int COSMIC_RUNE_11696 = 11696;
  
  public static final int BLOOD_RUNE_11697 = 11697;
  
  public static final int SOUL_RUNE_11698 = 11698;
  
  public static final int ASTRAL_RUNE_11699 = 11699;
  
  public static final int BRONZE_ARROW_11700 = 11700;
  
  public static final int IRON_ARROW_11701 = 11701;
  
  public static final int STEEL_ARROW_11702 = 11702;
  
  public static final int MITHRIL_ARROW_11703 = 11703;
  
  public static final int RAW_PHEASANT_11704 = 11704;
  
  public static final int BEACH_BOXING_GLOVES = 11705;
  
  public static final int BEACH_BOXING_GLOVES_11706 = 11706;
  
  public static final int CURSED_GOBLIN_HAMMER = 11707;
  
  public static final int CURSED_GOBLIN_BOW = 11708;
  
  public static final int CURSED_GOBLIN_STAFF = 11709;
  
  public static final int ANTIDRAGON_SHIELD_NZ = 11710;
  
  public static final int MAGIC_SECATEURS_NZ = 11711;
  
  public static final int CHAOS_RUNE_NZ = 11712;
  
  public static final int DEATH_RUNE_NZ = 11713;
  
  public static final int BLOOD_RUNE_NZ = 11714;
  
  public static final int AIR_RUNE_NZ = 11715;
  
  public static final int WATER_RUNE_NZ = 11716;
  
  public static final int EARTH_RUNE_NZ = 11717;
  
  public static final int FIRE_RUNE_NZ = 11718;
  
  public static final int RUNE_PICKAXE_NZ = 11719;
  
  public static final int MITHRIL_PICKAXE_NZ = 11720;
  
  public static final int IRON_PICKAXE_NZ = 11721;
  
  public static final int SUPER_RANGING_4 = 11722;
  
  public static final int SUPER_RANGING_3 = 11723;
  
  public static final int SUPER_RANGING_2 = 11724;
  
  public static final int SUPER_RANGING_1 = 11725;
  
  public static final int SUPER_MAGIC_POTION_4 = 11726;
  
  public static final int SUPER_MAGIC_POTION_3 = 11727;
  
  public static final int SUPER_MAGIC_POTION_2 = 11728;
  
  public static final int SUPER_MAGIC_POTION_1 = 11729;
  
  public static final int OVERLOAD_4 = 11730;
  
  public static final int OVERLOAD_3 = 11731;
  
  public static final int OVERLOAD_2 = 11732;
  
  public static final int OVERLOAD_1 = 11733;
  
  public static final int ABSORPTION_4 = 11734;
  
  public static final int ABSORPTION_3 = 11735;
  
  public static final int ABSORPTION_2 = 11736;
  
  public static final int ABSORPTION_1 = 11737;
  
  public static final int HERB_BOX = 11738;
  
  public static final int OPEN_HERB_BOX = 11739;
  
  public static final int SCROLL_OF_REDIRECTION = 11740;
  
  public static final int RIMMINGTON_TELEPORT = 11741;
  
  public static final int TAVERLEY_TELEPORT = 11742;
  
  public static final int POLLNIVNEACH_TELEPORT = 11743;
  
  public static final int RELLEKKA_TELEPORT = 11744;
  
  public static final int BRIMHAVEN_TELEPORT = 11745;
  
  public static final int YANILLE_TELEPORT = 11746;
  
  public static final int TROLLHEIM_TELEPORT = 11747;
  
  public static final int NEW_CRYSTAL_BOW_I = 11748;
  
  public static final int CRYSTAL_BOW_FULL_I = 11749;
  
  public static final int CRYSTAL_BOW_910_I = 11750;
  
  public static final int CRYSTAL_BOW_810_I = 11751;
  
  public static final int CRYSTAL_BOW_710_I = 11752;
  
  public static final int CRYSTAL_BOW_610_I = 11753;
  
  public static final int CRYSTAL_BOW_510_I = 11754;
  
  public static final int CRYSTAL_BOW_410_I = 11755;
  
  public static final int CRYSTAL_BOW_310_I = 11756;
  
  public static final int CRYSTAL_BOW_210_I = 11757;
  
  public static final int CRYSTAL_BOW_110_I = 11758;
  
  public static final int NEW_CRYSTAL_SHIELD_I = 11759;
  
  public static final int CRYSTAL_SHIELD_FULL_I = 11760;
  
  public static final int CRYSTAL_SHIELD_910_I = 11761;
  
  public static final int CRYSTAL_SHIELD_810_I = 11762;
  
  public static final int CRYSTAL_SHIELD_710_I = 11763;
  
  public static final int CRYSTAL_SHIELD_610_I = 11764;
  
  public static final int CRYSTAL_SHIELD_510_I = 11765;
  
  public static final int CRYSTAL_SHIELD_410_I = 11766;
  
  public static final int CRYSTAL_SHIELD_310_I = 11767;
  
  public static final int CRYSTAL_SHIELD_210_I = 11768;
  
  public static final int CRYSTAL_SHIELD_110_I = 11769;
  
  public static final int SEERS_RING_I = 11770;
  
  public static final int ARCHERS_RING_I = 11771;
  
  public static final int WARRIOR_RING_I = 11772;
  
  public static final int BERSERKER_RING_I = 11773;
  
  public static final int BLACK_MASK_10_I = 11774;
  
  public static final int BLACK_MASK_9_I = 11775;
  
  public static final int BLACK_MASK_8_I = 11776;
  
  public static final int BLACK_MASK_7_I = 11777;
  
  public static final int BLACK_MASK_6_I = 11778;
  
  public static final int BLACK_MASK_5_I = 11779;
  
  public static final int BLACK_MASK_4_I = 11780;
  
  public static final int BLACK_MASK_3_I = 11781;
  
  public static final int BLACK_MASK_2_I = 11782;
  
  public static final int BLACK_MASK_1_I = 11783;
  
  public static final int BLACK_MASK_I = 11784;
  
  public static final int ARMADYL_CROSSBOW = 11785;
  
  public static final int STEAM_BATTLESTAFF = 11787;
  
  public static final int MYSTIC_STEAM_STAFF = 11789;
  
  public static final int STAFF_OF_THE_DEAD = 11791;
  
  public static final int AGILITY_JUMP_11793 = 11793;
  
  public static final int GODSWORD_SHARDS_1__2 = 11794;
  
  public static final int GODSWORD_SHARDS_1__3 = 11796;
  
  public static final int GODSWORD_BLADE = 11798;
  
  public static final int GODSWORD_SHARDS_2__3 = 11800;
  
  public static final int ARMADYL_GODSWORD = 11802;
  
  public static final int BANDOS_GODSWORD = 11804;
  
  public static final int SARADOMIN_GODSWORD = 11806;
  
  public static final int ZAMORAK_GODSWORD = 11808;
  
  public static final int ARMADYL_HILT = 11810;
  
  public static final int BANDOS_HILT = 11812;
  
  public static final int SARADOMIN_HILT = 11814;
  
  public static final int ZAMORAK_HILT = 11816;
  
  public static final int GODSWORD_SHARD_1 = 11818;
  
  public static final int GODSWORD_SHARD_2 = 11820;
  
  public static final int GODSWORD_SHARD_3 = 11822;
  
  public static final int ZAMORAKIAN_SPEAR = 11824;
  
  public static final int ARMADYL_HELMET = 11826;
  
  public static final int ARMADYL_CHESTPLATE = 11828;
  
  public static final int ARMADYL_CHAINSKIRT = 11830;
  
  public static final int BANDOS_CHESTPLATE = 11832;
  
  public static final int BANDOS_TASSETS = 11834;
  
  public static final int BANDOS_BOOTS = 11836;
  
  public static final int SARADOMIN_SWORD = 11838;
  
  public static final int DRAGON_BOOTS = 11840;
  
  public static final int KNIGHTS_NOTES = 11842;
  
  public static final int KNIGHTS_NOTES_11843 = 11843;
  
  public static final int BLACK_HWEEN_MASK = 11847;
  
  public static final int RANCID_TURKEY = 11848;
  
  public static final int MARK_OF_GRACE = 11849;
  
  public static final int GRACEFUL_HOOD = 11850;
  
  public static final int GRACEFUL_HOOD_11851 = 11851;
  
  public static final int GRACEFUL_CAPE = 11852;
  
  public static final int GRACEFUL_CAPE_11853 = 11853;
  
  public static final int GRACEFUL_TOP = 11854;
  
  public static final int GRACEFUL_TOP_11855 = 11855;
  
  public static final int GRACEFUL_LEGS = 11856;
  
  public static final int GRACEFUL_LEGS_11857 = 11857;
  
  public static final int GRACEFUL_GLOVES = 11858;
  
  public static final int GRACEFUL_GLOVES_11859 = 11859;
  
  public static final int GRACEFUL_BOOTS = 11860;
  
  public static final int GRACEFUL_BOOTS_11861 = 11861;
  
  public static final int BLACK_PARTYHAT = 11862;
  
  public static final int RAINBOW_PARTYHAT = 11863;
  
  public static final int SLAYER_HELMET = 11864;
  
  public static final int SLAYER_HELMET_I = 11865;
  
  public static final int SLAYER_RING_8 = 11866;
  
  public static final int SLAYER_RING_7 = 11867;
  
  public static final int SLAYER_RING_6 = 11868;
  
  public static final int SLAYER_RING_5 = 11869;
  
  public static final int SLAYER_RING_4 = 11870;
  
  public static final int SLAYER_RING_3 = 11871;
  
  public static final int SLAYER_RING_2 = 11872;
  
  public static final int SLAYER_RING_1 = 11873;
  
  public static final int BROAD_ARROWHEADS = 11874;
  
  public static final int BROAD_BOLTS = 11875;
  
  public static final int UNFINISHED_BROAD_BOLTS = 11876;
  
  public static final int EMPTY_VIAL_PACK = 11877;
  
  public static final int WATERFILLED_VIAL_PACK = 11879;
  
  public static final int FEATHER_PACK = 11881;
  
  public static final int BAIT_PACK = 11883;
  
  public static final int BROAD_ARROWHEAD_PACK = 11885;
  
  public static final int UNFINISHED_BROAD_BOLT_PACK = 11887;
  
  public static final int ZAMORAKIAN_HASTA = 11889;
  
  public static final int SARADOMIN_BANNER_11891 = 11891;
  
  public static final int ZAMORAK_BANNER_11892 = 11892;
  
  public static final int DECORATIVE_ARMOUR_11893 = 11893;
  
  public static final int DECORATIVE_ARMOUR_11894 = 11894;
  
  public static final int DECORATIVE_ARMOUR_11895 = 11895;
  
  public static final int DECORATIVE_ARMOUR_11896 = 11896;
  
  public static final int DECORATIVE_ARMOUR_11897 = 11897;
  
  public static final int DECORATIVE_ARMOUR_11898 = 11898;
  
  public static final int DECORATIVE_ARMOUR_11899 = 11899;
  
  public static final int DECORATIVE_ARMOUR_11900 = 11900;
  
  public static final int DECORATIVE_ARMOUR_11901 = 11901;
  
  public static final int LEAFBLADED_SWORD = 11902;
  
  public static final int ENTOMOLOGISTS_DIARY = 11904;
  
  public static final int TRIDENT_OF_THE_SEAS_FULL = 11905;
  
  public static final int TRIDENT_OF_THE_SEAS = 11907;
  
  public static final int UNCHARGED_TRIDENT = 11908;
  
  public static final int CHOCOLATE_STRAWBERRY = 11910;
  
  public static final int BOX_OF_CHOCOLATE_STRAWBERRIES = 11912;
  
  public static final int BOX_OF_CHOCOLATE_STRAWBERRIES_11914 = 11914;
  
  public static final int SLICE_OF_BIRTHDAY_CAKE = 11916;
  
  public static final int SLICE_OF_BIRTHDAY_CAKE_11917 = 11917;
  
  public static final int BIRTHDAY_PRESENT = 11918;
  
  public static final int COW_MASK = 11919;
  
  public static final int DRAGON_PICKAXE = 11920;
  
  public static final int LAVA_DRAGON_BONEMEAL = 11922;
  
  public static final int BROKEN_PICKAXE_11923 = 11923;
  
  public static final int MALEDICTION_WARD = 11924;
  
  public static final int ODIUM_WARD = 11926;
  
  public static final int ODIUM_SHARD_1 = 11928;
  
  public static final int ODIUM_SHARD_2 = 11929;
  
  public static final int ODIUM_SHARD_3 = 11930;
  
  public static final int MALEDICTION_SHARD_1 = 11931;
  
  public static final int MALEDICTION_SHARD_2 = 11932;
  
  public static final int MALEDICTION_SHARD_3 = 11933;
  
  public static final int RAW_DARK_CRAB = 11934;
  
  public static final int DARK_CRAB = 11936;
  
  public static final int BURNT_DARK_CRAB = 11938;
  
  public static final int DARK_FISHING_BAIT = 11940;
  
  public static final int LOOTING_BAG = 11941;
  
  public static final int ECUMENICAL_KEY = 11942;
  
  public static final int LAVA_DRAGON_BONES = 11943;
  
  public static final int EXTENDED_ANTIFIRE4 = 11951;
  
  public static final int EXTENDED_ANTIFIRE3 = 11953;
  
  public static final int EXTENDED_ANTIFIRE2 = 11955;
  
  public static final int EXTENDED_ANTIFIRE1 = 11957;
  
  public static final int BLACK_CHINCHOMPA = 11959;
  
  public static final int EXTENDED_ANTIFIRE_MIX2 = 11960;
  
  public static final int EXTENDED_ANTIFIRE_MIX1 = 11962;
  
  public static final int AMULET_OF_GLORY_T6 = 11964;
  
  public static final int AMULET_OF_GLORY_T5 = 11966;
  
  public static final int SKILLS_NECKLACE6 = 11968;
  
  public static final int SKILLS_NECKLACE5 = 11970;
  
  public static final int COMBAT_BRACELET6 = 11972;
  
  public static final int COMBAT_BRACELET5 = 11974;
  
  public static final int AMULET_OF_GLORY5 = 11976;
  
  public static final int AMULET_OF_GLORY6 = 11978;
  
  public static final int RING_OF_WEALTH_5 = 11980;
  
  public static final int RING_OF_WEALTH_4 = 11982;
  
  public static final int RING_OF_WEALTH_3 = 11984;
  
  public static final int RING_OF_WEALTH_2 = 11986;
  
  public static final int RING_OF_WEALTH_1 = 11988;
  
  public static final int FEDORA = 11990;
  
  public static final int LAVA_SCALE = 11992;
  
  public static final int LAVA_SCALE_SHARD = 11994;
  
  public static final int PET_CHAOS_ELEMENTAL = 11995;
  
  public static final int HOLIDAY_TOOL = 11996;
  
  public static final int EASTER = 11997;
  
  public static final int SMOKE_BATTLESTAFF = 11998;
  
  public static final int MYSTIC_SMOKE_STAFF = 12000;
  
  public static final int OCCULT_NECKLACE = 12002;
  
  public static final int KRAKEN_TENTACLE = 12004;
  
  public static final int ABYSSAL_TENTACLE = 12006;
  
  public static final int JAR_OF_DIRT = 12007;
  
  public static final int SOFT_CLAY_PACK = 12009;
  
  public static final int SOFT_CLAY_PACK_12010 = 12010;
  
  public static final int PAYDIRT = 12011;
  
  public static final int GOLDEN_NUGGET = 12012;
  
  public static final int PROSPECTOR_HELMET = 12013;
  
  public static final int PROSPECTOR_JACKET = 12014;
  
  public static final int PROSPECTOR_LEGS = 12015;
  
  public static final int PROSPECTOR_BOOTS = 12016;
  
  public static final int SALVE_AMULETI = 12017;
  
  public static final int SALVE_AMULETEI = 12018;
  
  public static final int COAL_BAG_12019 = 12019;
  
  public static final int GEM_BAG_12020 = 12020;
  
  public static final int CLUE_SCROLL_MEDIUM_12021 = 12021;
  
  public static final int CASKET_MEDIUM_12022 = 12022;
  
  public static final int CLUE_SCROLL_MEDIUM_12023 = 12023;
  
  public static final int CASKET_MEDIUM_12024 = 12024;
  
  public static final int CLUE_SCROLL_MEDIUM_12025 = 12025;
  
  public static final int CASKET_MEDIUM_12026 = 12026;
  
  public static final int CLUE_SCROLL_MEDIUM_12027 = 12027;
  
  public static final int CASKET_MEDIUM_12028 = 12028;
  
  public static final int CLUE_SCROLL_MEDIUM_12029 = 12029;
  
  public static final int CASKET_MEDIUM_12030 = 12030;
  
  public static final int CLUE_SCROLL_MEDIUM_12031 = 12031;
  
  public static final int CASKET_MEDIUM_12032 = 12032;
  
  public static final int CLUE_SCROLL_MEDIUM_12033 = 12033;
  
  public static final int CASKET_MEDIUM_12034 = 12034;
  
  public static final int CLUE_SCROLL_MEDIUM_12035 = 12035;
  
  public static final int CASKET_MEDIUM_12036 = 12036;
  
  public static final int CLUE_SCROLL_MEDIUM_12037 = 12037;
  
  public static final int CASKET_MEDIUM_12038 = 12038;
  
  public static final int CLUE_SCROLL_MEDIUM_12039 = 12039;
  
  public static final int CASKET_MEDIUM_12040 = 12040;
  
  public static final int CLUE_SCROLL_MEDIUM_12041 = 12041;
  
  public static final int CASKET_MEDIUM_12042 = 12042;
  
  public static final int CLUE_SCROLL_MEDIUM_12043 = 12043;
  
  public static final int CASKET_MEDIUM_12044 = 12044;
  
  public static final int CLUE_SCROLL_MEDIUM_12045 = 12045;
  
  public static final int CASKET_MEDIUM_12046 = 12046;
  
  public static final int CLUE_SCROLL_MEDIUM_12047 = 12047;
  
  public static final int CASKET_MEDIUM_12048 = 12048;
  
  public static final int CLUE_SCROLL_MEDIUM_12049 = 12049;
  
  public static final int CASKET_MEDIUM_12050 = 12050;
  
  public static final int CLUE_SCROLL_MEDIUM_12051 = 12051;
  
  public static final int CASKET_MEDIUM_12052 = 12052;
  
  public static final int CLUE_SCROLL_MEDIUM_12053 = 12053;
  
  public static final int CASKET_MEDIUM_12054 = 12054;
  
  public static final int CLUE_SCROLL_MEDIUM_12055 = 12055;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12056 = 12056;
  
  public static final int CLUE_SCROLL_MEDIUM_12057 = 12057;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12058 = 12058;
  
  public static final int CLUE_SCROLL_MEDIUM_12059 = 12059;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12060 = 12060;
  
  public static final int CLUE_SCROLL_MEDIUM_12061 = 12061;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12062 = 12062;
  
  public static final int CLUE_SCROLL_MEDIUM_12063 = 12063;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12064 = 12064;
  
  public static final int CLUE_SCROLL_MEDIUM_12065 = 12065;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12066 = 12066;
  
  public static final int CLUE_SCROLL_MEDIUM_12067 = 12067;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12068 = 12068;
  
  public static final int CLUE_SCROLL_MEDIUM_12069 = 12069;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12070 = 12070;
  
  public static final int CLUE_SCROLL_MEDIUM_12071 = 12071;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_12072 = 12072;
  
  public static final int CLUE_SCROLL_ELITE = 12073;
  
  public static final int CLUE_SCROLL_ELITE_12074 = 12074;
  
  public static final int CLUE_SCROLL_ELITE_12075 = 12075;
  
  public static final int CLUE_SCROLL_ELITE_12076 = 12076;
  
  public static final int CLUE_SCROLL_ELITE_12077 = 12077;
  
  public static final int CLUE_SCROLL_ELITE_12078 = 12078;
  
  public static final int CLUE_SCROLL_ELITE_12079 = 12079;
  
  public static final int CLUE_SCROLL_ELITE_12080 = 12080;
  
  public static final int CLUE_SCROLL_ELITE_12081 = 12081;
  
  public static final int CLUE_SCROLL_ELITE_12082 = 12082;
  
  public static final int CLUE_SCROLL_ELITE_12083 = 12083;
  
  public static final int CASKET_ELITE = 12084;
  
  public static final int CLUE_SCROLL_ELITE_12085 = 12085;
  
  public static final int CLUE_SCROLL_ELITE_12086 = 12086;
  
  public static final int CLUE_SCROLL_ELITE_12087 = 12087;
  
  public static final int CLUE_SCROLL_ELITE_12088 = 12088;
  
  public static final int CLUE_SCROLL_ELITE_12089 = 12089;
  
  public static final int CLUE_SCROLL_ELITE_12090 = 12090;
  
  public static final int CLUE_SCROLL_ELITE_12091 = 12091;
  
  public static final int CLUE_SCROLL_ELITE_12092 = 12092;
  
  public static final int CLUE_SCROLL_ELITE_12093 = 12093;
  
  public static final int CLUE_SCROLL_ELITE_12094 = 12094;
  
  public static final int CLUE_SCROLL_ELITE_12095 = 12095;
  
  public static final int CLUE_SCROLL_ELITE_12096 = 12096;
  
  public static final int CLUE_SCROLL_ELITE_12097 = 12097;
  
  public static final int CLUE_SCROLL_ELITE_12098 = 12098;
  
  public static final int CLUE_SCROLL_ELITE_12099 = 12099;
  
  public static final int CLUE_SCROLL_ELITE_12100 = 12100;
  
  public static final int CLUE_SCROLL_ELITE_12101 = 12101;
  
  public static final int CLUE_SCROLL_ELITE_12102 = 12102;
  
  public static final int CLUE_SCROLL_ELITE_12103 = 12103;
  
  public static final int CLUE_SCROLL_ELITE_12104 = 12104;
  
  public static final int CLUE_SCROLL_ELITE_12105 = 12105;
  
  public static final int CLUE_SCROLL_ELITE_12106 = 12106;
  
  public static final int CLUE_SCROLL_ELITE_12107 = 12107;
  
  public static final int CLUE_SCROLL_ELITE_12108 = 12108;
  
  public static final int CLUE_SCROLL_ELITE_12109 = 12109;
  
  public static final int CLUE_SCROLL_ELITE_12110 = 12110;
  
  public static final int CLUE_SCROLL_ELITE_12111 = 12111;
  
  public static final int CASKET_ELITE_12112 = 12112;
  
  public static final int CLUE_SCROLL_ELITE_12113 = 12113;
  
  public static final int CLUE_SCROLL_ELITE_12114 = 12114;
  
  public static final int CLUE_SCROLL_ELITE_12115 = 12115;
  
  public static final int CLUE_SCROLL_ELITE_12116 = 12116;
  
  public static final int CLUE_SCROLL_ELITE_12117 = 12117;
  
  public static final int CLUE_SCROLL_ELITE_12118 = 12118;
  
  public static final int CLUE_SCROLL_ELITE_12119 = 12119;
  
  public static final int CLUE_SCROLL_ELITE_12120 = 12120;
  
  public static final int CLUE_SCROLL_ELITE_12121 = 12121;
  
  public static final int CLUE_SCROLL_ELITE_12122 = 12122;
  
  public static final int CLUE_SCROLL_ELITE_12123 = 12123;
  
  public static final int CLUE_SCROLL_ELITE_12124 = 12124;
  
  public static final int CLUE_SCROLL_ELITE_12125 = 12125;
  
  public static final int CLUE_SCROLL_ELITE_12126 = 12126;
  
  public static final int CLUE_SCROLL_ELITE_12127 = 12127;
  
  public static final int CHALLENGE_SCROLL_ELITE = 12128;
  
  public static final int CASKET_ELITE_12129 = 12129;
  
  public static final int CLUE_SCROLL_ELITE_12130 = 12130;
  
  public static final int CASKET_ELITE_12131 = 12131;
  
  public static final int CLUE_SCROLL_ELITE_12132 = 12132;
  
  public static final int CLUE_SCROLL_ELITE_12133 = 12133;
  
  public static final int CLUE_SCROLL_ELITE_12134 = 12134;
  
  public static final int CLUE_SCROLL_ELITE_12135 = 12135;
  
  public static final int CLUE_SCROLL_ELITE_12136 = 12136;
  
  public static final int CLUE_SCROLL_ELITE_12137 = 12137;
  
  public static final int CLUE_SCROLL_ELITE_12138 = 12138;
  
  public static final int CHALLENGE_SCROLL_ELITE_12139 = 12139;
  
  public static final int CLUE_SCROLL_ELITE_12140 = 12140;
  
  public static final int CLUE_SCROLL_ELITE_12141 = 12141;
  
  public static final int CLUE_SCROLL_ELITE_12142 = 12142;
  
  public static final int CLUE_SCROLL_ELITE_12143 = 12143;
  
  public static final int CLUE_SCROLL_ELITE_12144 = 12144;
  
  public static final int CLUE_SCROLL_ELITE_12145 = 12145;
  
  public static final int CLUE_SCROLL_ELITE_12146 = 12146;
  
  public static final int CLUE_SCROLL_ELITE_12147 = 12147;
  
  public static final int CLUE_SCROLL_ELITE_12148 = 12148;
  
  public static final int CLUE_SCROLL_ELITE_12149 = 12149;
  
  public static final int CLUE_SCROLL_ELITE_12150 = 12150;
  
  public static final int CLUE_SCROLL_ELITE_12151 = 12151;
  
  public static final int CLUE_SCROLL_ELITE_12152 = 12152;
  
  public static final int CLUE_SCROLL_ELITE_12153 = 12153;
  
  public static final int CLUE_SCROLL_ELITE_12154 = 12154;
  
  public static final int CLUE_SCROLL_ELITE_12155 = 12155;
  
  public static final int CLUE_SCROLL_ELITE_12156 = 12156;
  
  public static final int CLUE_SCROLL_ELITE_12157 = 12157;
  
  public static final int CLUE_SCROLL_ELITE_12158 = 12158;
  
  public static final int CLUE_SCROLL_ELITE_12159 = 12159;
  
  public static final int CASKET_ELITE_12160 = 12160;
  
  public static final int PUZZLE_BOX_ELITE = 12161;
  
  public static final int CLUE_SCROLL_EASY_12162 = 12162;
  
  public static final int CASKET_EASY_12163 = 12163;
  
  public static final int CLUE_SCROLL_EASY_12164 = 12164;
  
  public static final int CASKET_EASY_12165 = 12165;
  
  public static final int CLUE_SCROLL_EASY_12166 = 12166;
  
  public static final int CLUE_SCROLL_EASY_12167 = 12167;
  
  public static final int CLUE_SCROLL_EASY_12168 = 12168;
  
  public static final int CLUE_SCROLL_EASY_12169 = 12169;
  
  public static final int CLUE_SCROLL_EASY_12170 = 12170;
  
  public static final int CASKET_EASY_12171 = 12171;
  
  public static final int CLUE_SCROLL_EASY_12172 = 12172;
  
  public static final int CLUE_SCROLL_EASY_12173 = 12173;
  
  public static final int CLUE_SCROLL_EASY_12174 = 12174;
  
  public static final int CLUE_SCROLL_EASY_12175 = 12175;
  
  public static final int CLUE_SCROLL_EASY_12176 = 12176;
  
  public static final int CLUE_SCROLL_EASY_12177 = 12177;
  
  public static final int CLUE_SCROLL_EASY_12178 = 12178;
  
  public static final int CLUE_SCROLL_EASY_12179 = 12179;
  
  public static final int CASKET_EASY_12180 = 12180;
  
  public static final int CLUE_SCROLL_EASY_12181 = 12181;
  
  public static final int CLUE_SCROLL_EASY_12182 = 12182;
  
  public static final int CLUE_SCROLL_EASY_12183 = 12183;
  
  public static final int CLUE_SCROLL_EASY_12184 = 12184;
  
  public static final int CLUE_SCROLL_EASY_12185 = 12185;
  
  public static final int CLUE_SCROLL_EASY_12186 = 12186;
  
  public static final int CLUE_SCROLL_EASY_12187 = 12187;
  
  public static final int CLUE_SCROLL_EASY_12188 = 12188;
  
  public static final int CLUE_SCROLL_EASY_12189 = 12189;
  
  public static final int CLUE_SCROLL_EASY_12190 = 12190;
  
  public static final int CLUE_SCROLL_EASY_12191 = 12191;
  
  public static final int CLUE_SCROLL_EASY_12192 = 12192;
  
  public static final int ANCIENT_ROBE_TOP = 12193;
  
  public static final int ANCIENT_ROBE_LEGS = 12195;
  
  public static final int ANCIENT_CLOAK = 12197;
  
  public static final int ANCIENT_CROZIER = 12199;
  
  public static final int ANCIENT_STOLE = 12201;
  
  public static final int ANCIENT_MITRE = 12203;
  
  public static final int BRONZE_PLATEBODY_G = 12205;
  
  public static final int BRONZE_PLATELEGS_G = 12207;
  
  public static final int BRONZE_PLATESKIRT_G = 12209;
  
  public static final int BRONZE_FULL_HELM_G = 12211;
  
  public static final int BRONZE_KITESHIELD_G = 12213;
  
  public static final int BRONZE_PLATEBODY_T = 12215;
  
  public static final int BRONZE_PLATELEGS_T = 12217;
  
  public static final int BRONZE_PLATESKIRT_T = 12219;
  
  public static final int BRONZE_FULL_HELM_T = 12221;
  
  public static final int BRONZE_KITESHIELD_T = 12223;
  
  public static final int IRON_PLATEBODY_T = 12225;
  
  public static final int IRON_PLATELEGS_T = 12227;
  
  public static final int IRON_PLATESKIRT_T = 12229;
  
  public static final int IRON_FULL_HELM_T = 12231;
  
  public static final int IRON_KITESHIELD_T = 12233;
  
  public static final int IRON_PLATEBODY_G = 12235;
  
  public static final int IRON_PLATELEGS_G = 12237;
  
  public static final int IRON_PLATESKIRT_G = 12239;
  
  public static final int IRON_FULL_HELM_G = 12241;
  
  public static final int IRON_KITESHIELD_G = 12243;
  
  public static final int BEANIE = 12245;
  
  public static final int RED_BERET = 12247;
  
  public static final int IMP_MASK = 12249;
  
  public static final int GOBLIN_MASK = 12251;
  
  public static final int ARMADYL_ROBE_TOP = 12253;
  
  public static final int ARMADYL_ROBE_LEGS = 12255;
  
  public static final int ARMADYL_STOLE = 12257;
  
  public static final int ARMADYL_MITRE = 12259;
  
  public static final int ARMADYL_CLOAK = 12261;
  
  public static final int ARMADYL_CROZIER = 12263;
  
  public static final int BANDOS_ROBE_TOP = 12265;
  
  public static final int BANDOS_ROBE_LEGS = 12267;
  
  public static final int BANDOS_STOLE = 12269;
  
  public static final int BANDOS_MITRE = 12271;
  
  public static final int BANDOS_CLOAK = 12273;
  
  public static final int BANDOS_CROZIER = 12275;
  
  public static final int MITHRIL_PLATEBODY_G = 12277;
  
  public static final int MITHRIL_PLATELEGS_G = 12279;
  
  public static final int MITHRIL_KITESHIELD_G = 12281;
  
  public static final int MITHRIL_FULL_HELM_G = 12283;
  
  public static final int MITHRIL_PLATESKIRT_G = 12285;
  
  public static final int MITHRIL_PLATEBODY_T = 12287;
  
  public static final int MITHRIL_PLATELEGS_T = 12289;
  
  public static final int MITHRIL_KITESHIELD_T = 12291;
  
  public static final int MITHRIL_FULL_HELM_T = 12293;
  
  public static final int MITHRIL_PLATESKIRT_T = 12295;
  
  public static final int BLACK_PICKAXE = 12297;
  
  public static final int WHITE_HEADBAND = 12299;
  
  public static final int BLUE_HEADBAND = 12301;
  
  public static final int GOLD_HEADBAND = 12303;
  
  public static final int PINK_HEADBAND = 12305;
  
  public static final int GREEN_HEADBAND = 12307;
  
  public static final int PINK_BOATER = 12309;
  
  public static final int PURPLE_BOATER = 12311;
  
  public static final int WHITE_BOATER = 12313;
  
  public static final int PINK_ELEGANT_SHIRT = 12315;
  
  public static final int PINK_ELEGANT_LEGS = 12317;
  
  public static final int CRIER_HAT = 12319;
  
  public static final int WHITE_CAVALIER = 12321;
  
  public static final int RED_CAVALIER = 12323;
  
  public static final int NAVY_CAVALIER = 12325;
  
  public static final int RED_DHIDE_BODY_G = 12327;
  
  public static final int RED_DHIDE_CHAPS_G = 12329;
  
  public static final int RED_DHIDE_BODY_T = 12331;
  
  public static final int RED_DHIDE_CHAPS_T = 12333;
  
  public static final int BRIEFCASE = 12335;
  
  public static final int SAGACIOUS_SPECTACLES = 12337;
  
  public static final int PINK_ELEGANT_BLOUSE = 12339;
  
  public static final int PINK_ELEGANT_SKIRT = 12341;
  
  public static final int GOLD_ELEGANT_BLOUSE = 12343;
  
  public static final int GOLD_ELEGANT_SKIRT = 12345;
  
  public static final int GOLD_ELEGANT_SHIRT = 12347;
  
  public static final int GOLD_ELEGANT_LEGS = 12349;
  
  public static final int MUSKETEER_HAT = 12351;
  
  public static final int MONOCLE = 12353;
  
  public static final int BIG_PIRATE_HAT = 12355;
  
  public static final int KATANA = 12357;
  
  public static final int LEPRECHAUN_HAT = 12359;
  
  public static final int CAT_MASK = 12361;
  
  public static final int BRONZE_DRAGON_MASK = 12363;
  
  public static final int IRON_DRAGON_MASK = 12365;
  
  public static final int STEEL_DRAGON_MASK = 12367;
  
  public static final int MITHRIL_DRAGON_MASK = 12369;
  
  public static final int LAVA_DRAGON_MASK = 12371;
  
  public static final int DRAGON_CANE = 12373;
  
  public static final int BLACK_CANE = 12375;
  
  public static final int ADAMANT_CANE = 12377;
  
  public static final int RUNE_CANE = 12379;
  
  public static final int BLACK_DHIDE_BODY_G = 12381;
  
  public static final int BLACK_DHIDE_CHAPS_G = 12383;
  
  public static final int BLACK_DHIDE_BODY_T = 12385;
  
  public static final int BLACK_DHIDE_CHAPS_T = 12387;
  
  public static final int GILDED_SCIMITAR = 12389;
  
  public static final int GILDED_BOOTS = 12391;
  
  public static final int ROYAL_GOWN_TOP = 12393;
  
  public static final int ROYAL_GOWN_BOTTOM = 12395;
  
  public static final int ROYAL_CROWN = 12397;
  
  public static final int PARTYHAT__SPECS = 12399;
  
  public static final int NARDAH_TELEPORT = 12402;
  
  public static final int DIGSITE_TELEPORT = 12403;
  
  public static final int FELDIP_HILLS_TELEPORT = 12404;
  
  public static final int LUNAR_ISLE_TELEPORT = 12405;
  
  public static final int MORTTON_TELEPORT = 12406;
  
  public static final int PEST_CONTROL_TELEPORT = 12407;
  
  public static final int PISCATORIS_TELEPORT = 12408;
  
  public static final int TAI_BWO_WANNAI_TELEPORT = 12409;
  
  public static final int IORWERTH_CAMP_TELEPORT = 12410;
  
  public static final int MOS_LEHARMLESS_TELEPORT = 12411;
  
  public static final int PIRATE_HAT__PATCH = 12412;
  
  public static final int DRAGON_CHAINBODY_G = 12414;
  
  public static final int DRAGON_PLATELEGS_G = 12415;
  
  public static final int DRAGON_PLATESKIRT_G = 12416;
  
  public static final int DRAGON_FULL_HELM_G = 12417;
  
  public static final int DRAGON_SQ_SHIELD_G = 12418;
  
  public static final int LIGHT_INFINITY_HAT = 12419;
  
  public static final int LIGHT_INFINITY_TOP = 12420;
  
  public static final int LIGHT_INFINITY_BOTTOMS = 12421;
  
  public static final int _3RD_AGE_WAND = 12422;
  
  public static final int _3RD_AGE_BOW = 12424;
  
  public static final int _3RD_AGE_LONGSWORD = 12426;
  
  public static final int PENGUIN_MASK = 12428;
  
  public static final int AFRO = 12430;
  
  public static final int TOP_HAT = 12432;
  
  public static final int TOP_HAT__MONOCLE = 12434;
  
  public static final int AMULET_OF_FURY_OR = 12436;
  
  public static final int _3RD_AGE_CLOAK = 12437;
  
  public static final int ROYAL_SCEPTRE = 12439;
  
  public static final int MUSKETEER_TABARD = 12441;
  
  public static final int MUSKETEER_PANTS = 12443;
  
  public static final int BLACK_SKIRT_G = 12445;
  
  public static final int BLACK_SKIRT_T = 12447;
  
  public static final int BLACK_WIZARD_ROBE_G = 12449;
  
  public static final int BLACK_WIZARD_ROBE_T = 12451;
  
  public static final int BLACK_WIZARD_HAT_G = 12453;
  
  public static final int BLACK_WIZARD_HAT_T = 12455;
  
  public static final int DARK_INFINITY_HAT = 12457;
  
  public static final int DARK_INFINITY_TOP = 12458;
  
  public static final int DARK_INFINITY_BOTTOMS = 12459;
  
  public static final int ANCIENT_PLATEBODY = 12460;
  
  public static final int ANCIENT_PLATELEGS = 12462;
  
  public static final int ANCIENT_PLATESKIRT = 12464;
  
  public static final int ANCIENT_FULL_HELM = 12466;
  
  public static final int ANCIENT_KITESHIELD = 12468;
  
  public static final int ARMADYL_PLATEBODY = 12470;
  
  public static final int ARMADYL_PLATELEGS = 12472;
  
  public static final int ARMADYL_PLATESKIRT = 12474;
  
  public static final int ARMADYL_FULL_HELM = 12476;
  
  public static final int ARMADYL_KITESHIELD = 12478;
  
  public static final int BANDOS_PLATEBODY = 12480;
  
  public static final int BANDOS_PLATELEGS = 12482;
  
  public static final int BANDOS_PLATESKIRT = 12484;
  
  public static final int BANDOS_FULL_HELM = 12486;
  
  public static final int BANDOS_KITESHIELD = 12488;
  
  public static final int ANCIENT_BRACERS = 12490;
  
  public static final int ANCIENT_DHIDE_BODY = 12492;
  
  public static final int ANCIENT_CHAPS = 12494;
  
  public static final int ANCIENT_COIF = 12496;
  
  public static final int BANDOS_BRACERS = 12498;
  
  public static final int BANDOS_DHIDE_BODY = 12500;
  
  public static final int BANDOS_CHAPS = 12502;
  
  public static final int BANDOS_COIF = 12504;
  
  public static final int ARMADYL_BRACERS = 12506;
  
  public static final int ARMADYL_DHIDE_BODY = 12508;
  
  public static final int ARMADYL_CHAPS = 12510;
  
  public static final int ARMADYL_COIF = 12512;
  
  public static final int EXPLORER_BACKPACK = 12514;
  
  public static final int PITH_HELMET = 12516;
  
  public static final int GREEN_DRAGON_MASK = 12518;
  
  public static final int BLUE_DRAGON_MASK = 12520;
  
  public static final int RED_DRAGON_MASK = 12522;
  
  public static final int BLACK_DRAGON_MASK = 12524;
  
  public static final int FURY_ORNAMENT_KIT = 12526;
  
  public static final int DARK_INFINITY_COLOUR_KIT = 12528;
  
  public static final int LIGHT_INFINITY_COLOUR_KIT = 12530;
  
  public static final int DRAGON_SQ_SHIELD_ORNAMENT_KIT = 12532;
  
  public static final int DRAGON_CHAINBODY_ORNAMENT_KIT = 12534;
  
  public static final int DRAGON_LEGSSKIRT_ORNAMENT_KIT = 12536;
  
  public static final int DRAGON_FULL_HELM_ORNAMENT_KIT = 12538;
  
  public static final int DEERSTALKER = 12540;
  
  public static final int CLUE_SCROLL_HARD_12542 = 12542;
  
  public static final int CASKET_HARD_12543 = 12543;
  
  public static final int CLUE_SCROLL_HARD_12544 = 12544;
  
  public static final int CASKET_HARD_12545 = 12545;
  
  public static final int CLUE_SCROLL_HARD_12546 = 12546;
  
  public static final int CASKET_HARD_12547 = 12547;
  
  public static final int CLUE_SCROLL_HARD_12548 = 12548;
  
  public static final int CASKET_HARD_12549 = 12549;
  
  public static final int CLUE_SCROLL_HARD_12550 = 12550;
  
  public static final int CASKET_HARD_12551 = 12551;
  
  public static final int CLUE_SCROLL_HARD_12552 = 12552;
  
  public static final int CASKET_HARD_12553 = 12553;
  
  public static final int CLUE_SCROLL_HARD_12554 = 12554;
  
  public static final int CASKET_HARD_12555 = 12555;
  
  public static final int CLUE_SCROLL_HARD_12556 = 12556;
  
  public static final int CASKET_HARD_12557 = 12557;
  
  public static final int CLUE_SCROLL_HARD_12558 = 12558;
  
  public static final int CASKET_HARD_12559 = 12559;
  
  public static final int CLUE_SCROLL_HARD_12560 = 12560;
  
  public static final int CASKET_HARD_12561 = 12561;
  
  public static final int CLUE_SCROLL_HARD_12562 = 12562;
  
  public static final int CASKET_HARD_12563 = 12563;
  
  public static final int CLUE_SCROLL_HARD_12564 = 12564;
  
  public static final int CASKET_HARD_12565 = 12565;
  
  public static final int CLUE_SCROLL_HARD_12566 = 12566;
  
  public static final int CHALLENGE_SCROLL_HARD_12567 = 12567;
  
  public static final int CLUE_SCROLL_HARD_12568 = 12568;
  
  public static final int CHALLENGE_SCROLL_HARD_12569 = 12569;
  
  public static final int CLUE_SCROLL_HARD_12570 = 12570;
  
  public static final int CHALLENGE_SCROLL_HARD_12571 = 12571;
  
  public static final int CLUE_SCROLL_HARD_12572 = 12572;
  
  public static final int CHALLENGE_SCROLL_HARD_12573 = 12573;
  
  public static final int CLUE_SCROLL_HARD_12574 = 12574;
  
  public static final int CHALLENGE_SCROLL_HARD_12575 = 12575;
  
  public static final int CLUE_SCROLL_HARD_12576 = 12576;
  
  public static final int CHALLENGE_SCROLL_HARD_12577 = 12577;
  
  public static final int CLUE_SCROLL_HARD_12578 = 12578;
  
  public static final int PUZZLE_BOX_HARD_12579 = 12579;
  
  public static final int CASKET_HARD_12580 = 12580;
  
  public static final int CLUE_SCROLL_HARD_12581 = 12581;
  
  public static final int PUZZLE_BOX_HARD_12582 = 12582;
  
  public static final int CASKET_HARD_12583 = 12583;
  
  public static final int CLUE_SCROLL_HARD_12584 = 12584;
  
  public static final int PUZZLE_BOX_HARD_12585 = 12585;
  
  public static final int CASKET_HARD_12586 = 12586;
  
  public static final int CLUE_SCROLL_HARD_12587 = 12587;
  
  public static final int PUZZLE_BOX_HARD_12588 = 12588;
  
  public static final int CASKET_HARD_12589 = 12589;
  
  public static final int CLUE_SCROLL_HARD_12590 = 12590;
  
  public static final int CASKET_HARD_12591 = 12591;
  
  public static final int BLACK_PICK_HEAD = 12592;
  
  public static final int BROKEN_PICKAXE_12594 = 12594;
  
  public static final int RANGERS_TUNIC = 12596;
  
  public static final int HOLY_SANDALS = 12598;
  
  public static final int DRUIDIC_WREATH = 12600;
  
  public static final int RING_OF_THE_GODS = 12601;
  
  public static final int TYRANNICAL_RING = 12603;
  
  public static final int TREASONOUS_RING = 12605;
  
  public static final int DAMAGED_BOOK_12607 = 12607;
  
  public static final int BOOK_OF_WAR = 12608;
  
  public static final int DAMAGED_BOOK_12609 = 12609;
  
  public static final int BOOK_OF_LAW = 12610;
  
  public static final int DAMAGED_BOOK_12611 = 12611;
  
  public static final int BOOK_OF_DARKNESS = 12612;
  
  public static final int BANDOS_PAGE_1 = 12613;
  
  public static final int BANDOS_PAGE_2 = 12614;
  
  public static final int BANDOS_PAGE_3 = 12615;
  
  public static final int BANDOS_PAGE_4 = 12616;
  
  public static final int ARMADYL_PAGE_1 = 12617;
  
  public static final int ARMADYL_PAGE_2 = 12618;
  
  public static final int ARMADYL_PAGE_3 = 12619;
  
  public static final int ARMADYL_PAGE_4 = 12620;
  
  public static final int ANCIENT_PAGE_1 = 12621;
  
  public static final int ANCIENT_PAGE_2 = 12622;
  
  public static final int ANCIENT_PAGE_3 = 12623;
  
  public static final int ANCIENT_PAGE_4 = 12624;
  
  public static final int STAMINA_POTION4 = 12625;
  
  public static final int STAMINA_POTION3 = 12627;
  
  public static final int STAMINA_POTION2 = 12629;
  
  public static final int STAMINA_POTION1 = 12631;
  
  public static final int STAMINA_MIX2 = 12633;
  
  public static final int STAMINA_MIX1 = 12635;
  
  public static final int SARADOMIN_HALO = 12637;
  
  public static final int ZAMORAK_HALO = 12638;
  
  public static final int GUTHIX_HALO = 12639;
  
  public static final int AMYLASE_CRYSTAL = 12640;
  
  public static final int AMYLASE_PACK = 12641;
  
  public static final int LUMBERYARD_TELEPORT = 12642;
  
  public static final int PET_DAGANNOTH_SUPREME = 12643;
  
  public static final int PET_DAGANNOTH_PRIME = 12644;
  
  public static final int PET_DAGANNOTH_REX = 12645;
  
  public static final int BABY_MOLE = 12646;
  
  public static final int KALPHITE_PRINCESS = 12647;
  
  public static final int PET_SMOKE_DEVIL = 12648;
  
  public static final int PET_KREEARRA = 12649;
  
  public static final int PET_GENERAL_GRAARDOR = 12650;
  
  public static final int PET_ZILYANA = 12651;
  
  public static final int PET_KRIL_TSUTSAROTH = 12652;
  
  public static final int PRINCE_BLACK_DRAGON = 12653;
  
  public static final int KALPHITE_PRINCESS_12654 = 12654;
  
  public static final int PET_KRAKEN = 12655;
  
  public static final int JUNK = 12656;
  
  public static final int JUNK_12657 = 12657;
  
  public static final int IBANS_STAFF_U = 12658;
  
  public static final int CLAN_WARS_CAPE = 12659;
  
  public static final int CLAN_WARS_CAPE_12660 = 12660;
  
  public static final int CLAN_WARS_CAPE_12661 = 12661;
  
  public static final int CLAN_WARS_CAPE_12662 = 12662;
  
  public static final int CLAN_WARS_CAPE_12663 = 12663;
  
  public static final int CLAN_WARS_CAPE_12664 = 12664;
  
  public static final int CLAN_WARS_CAPE_12665 = 12665;
  
  public static final int CLAN_WARS_CAPE_12666 = 12666;
  
  public static final int CLAN_WARS_CAPE_12667 = 12667;
  
  public static final int CLAN_WARS_CAPE_12668 = 12668;
  
  public static final int CLAN_WARS_CAPE_12669 = 12669;
  
  public static final int CLAN_WARS_CAPE_12670 = 12670;
  
  public static final int CLAN_WARS_CAPE_12671 = 12671;
  
  public static final int CLAN_WARS_CAPE_12672 = 12672;
  
  public static final int CLAN_WARS_CAPE_12673 = 12673;
  
  public static final int CLAN_WARS_CAPE_12674 = 12674;
  
  public static final int CLAN_WARS_CAPE_12675 = 12675;
  
  public static final int CLAN_WARS_CAPE_12676 = 12676;
  
  public static final int CLAN_WARS_CAPE_12677 = 12677;
  
  public static final int CLAN_WARS_CAPE_12678 = 12678;
  
  public static final int CLAN_WARS_CAPE_12679 = 12679;
  
  public static final int CLAN_WARS_CAPE_12680 = 12680;
  
  public static final int CLAN_WARS_CAPE_12681 = 12681;
  
  public static final int CLAN_WARS_CAPE_12682 = 12682;
  
  public static final int CLAN_WARS_CAPE_12683 = 12683;
  
  public static final int CLAN_WARS_CAPE_12684 = 12684;
  
  public static final int CLAN_WARS_CAPE_12685 = 12685;
  
  public static final int CLAN_WARS_CAPE_12686 = 12686;
  
  public static final int CLAN_WARS_CAPE_12687 = 12687;
  
  public static final int CLAN_WARS_CAPE_12688 = 12688;
  
  public static final int CLAN_WARS_CAPE_12689 = 12689;
  
  public static final int CLAN_WARS_CAPE_12690 = 12690;
  
  public static final int TYRANNICAL_RING_I = 12691;
  
  public static final int TREASONOUS_RING_I = 12692;
  
  public static final int KREEARRA = 12693;
  
  public static final int CHAOS_ELEMENTAL = 12694;
  
  public static final int SUPER_COMBAT_POTION4 = 12695;
  
  public static final int SUPER_COMBAT_POTION3 = 12697;
  
  public static final int SUPER_COMBAT_POTION2 = 12699;
  
  public static final int SUPER_COMBAT_POTION1 = 12701;
  
  public static final int PET_PENANCE_QUEEN = 12703;
  
  public static final int OAK_HOUSE = 12704;
  
  public static final int TEAK_HOUSE = 12705;
  
  public static final int MAHOGANY_HOUSE = 12706;
  
  public static final int CONSECRATED_HOUSE = 12707;
  
  public static final int DESECRATED_HOUSE = 12708;
  
  public static final int NATURE_HOUSE = 12709;
  
  public static final int GRASSLAND_HABITAT = 12710;
  
  public static final int FOREST_HABITAT = 12711;
  
  public static final int DESERT_HABITAT = 12712;
  
  public static final int POLAR_HABITAT = 12713;
  
  public static final int VOLCANIC_HABITAT = 12714;
  
  public static final int OAK_SCRATCHING_POST = 12715;
  
  public static final int TEAK_SCRATCHING_POST = 12716;
  
  public static final int MAHOGANY_SCRATCHING_POST = 12717;
  
  public static final int SIMPLE_ARENA = 12718;
  
  public static final int ADVANCED_ARENA = 12719;
  
  public static final int GLORIOUS_ARENA = 12720;
  
  public static final int PET_LIST = 12721;
  
  public static final int OAK_FEEDER = 12722;
  
  public static final int TEAK_FEEDER = 12723;
  
  public static final int MAHOGANY_FEEDER = 12724;
  
  public static final int MENAGERIE = 12725;
  
  public static final int MENAGERIE_12726 = 12726;
  
  public static final int GOBLIN_PAINT_CANNON = 12727;
  
  public static final int AIR_RUNE_PACK = 12728;
  
  public static final int WATER_RUNE_PACK = 12730;
  
  public static final int EARTH_RUNE_PACK = 12732;
  
  public static final int FIRE_RUNE_PACK = 12734;
  
  public static final int MIND_RUNE_PACK = 12736;
  
  public static final int CHAOS_RUNE_PACK = 12738;
  
  public static final int BIRD_SNARE_PACK = 12740;
  
  public static final int BOX_TRAP_PACK = 12742;
  
  public static final int MAGIC_IMP_BOX_PACK = 12744;
  
  public static final int ARCHAIC_EMBLEM_TIER_1 = 12746;
  
  public static final int ARCHAIC_EMBLEM_TIER_1_12747 = 12747;
  
  public static final int ARCHAIC_EMBLEM_TIER_2 = 12748;
  
  public static final int ARCHAIC_EMBLEM_TIER_3 = 12749;
  
  public static final int ARCHAIC_EMBLEM_TIER_4 = 12750;
  
  public static final int ARCHAIC_EMBLEM_TIER_5 = 12751;
  
  public static final int ARCHAIC_EMBLEM_TIER_6 = 12752;
  
  public static final int ARCHAIC_EMBLEM_TIER_7 = 12753;
  
  public static final int ARCHAIC_EMBLEM_TIER_8 = 12754;
  
  public static final int ARCHAIC_EMBLEM_TIER_9 = 12755;
  
  public static final int ARCHAIC_EMBLEM_TIER_10 = 12756;
  
  public static final int BLUE_DARK_BOW_PAINT = 12757;
  
  public static final int GREEN_DARK_BOW_PAINT = 12759;
  
  public static final int YELLOW_DARK_BOW_PAINT = 12761;
  
  public static final int WHITE_DARK_BOW_PAINT = 12763;
  
  public static final int DARK_BOW_12765 = 12765;
  
  public static final int DARK_BOW_12766 = 12766;
  
  public static final int DARK_BOW_12767 = 12767;
  
  public static final int DARK_BOW_12768 = 12768;
  
  public static final int FROZEN_WHIP_MIX = 12769;
  
  public static final int VOLCANIC_WHIP_MIX = 12771;
  
  public static final int VOLCANIC_ABYSSAL_WHIP = 12773;
  
  public static final int FROZEN_ABYSSAL_WHIP = 12774;
  
  public static final int ANNAKARL_TELEPORT = 12775;
  
  public static final int CARRALLANGER_TELEPORT = 12776;
  
  public static final int DAREEYAK_TELEPORT = 12777;
  
  public static final int GHORROCK_TELEPORT = 12778;
  
  public static final int KHARYRLL_TELEPORT = 12779;
  
  public static final int LASSAR_TELEPORT = 12780;
  
  public static final int PADDEWWA_TELEPORT = 12781;
  
  public static final int SENNTISTEN_TELEPORT = 12782;
  
  public static final int RING_OF_WEALTH_SCROLL = 12783;
  
  public static final int RING_OF_WEALTH_I = 12785;
  
  public static final int MAGIC_SHORTBOW_SCROLL = 12786;
  
  public static final int MAGIC_SHORTBOW_I = 12788;
  
  public static final int CLUE_BOX = 12789;
  
  public static final int RUNE_POUCH = 12791;
  
  public static final int NEST_BOX_EMPTY = 12792;
  
  public static final int NEST_BOX_SEEDS = 12793;
  
  public static final int NEST_BOX_RING = 12794;
  
  public static final int STEAM_BATTLESTAFF_12795 = 12795;
  
  public static final int MYSTIC_STEAM_STAFF_12796 = 12796;
  
  public static final int DRAGON_PICKAXE_12797 = 12797;
  
  public static final int STEAM_STAFF_UPGRADE_KIT = 12798;
  
  public static final int DRAGON_PICKAXE_UPGRADE_KIT = 12800;
  
  public static final int WARD_UPGRADE_KIT = 12802;
  
  public static final int SARADOMINS_TEAR = 12804;
  
  public static final int MALEDICTION_WARD_12806 = 12806;
  
  public static final int ODIUM_WARD_12807 = 12807;
  
  public static final int SARAS_BLESSED_SWORD_FULL = 12808;
  
  public static final int SARADOMINS_BLESSED_SWORD = 12809;
  
  public static final int IRONMAN_HELM = 12810;
  
  public static final int IRONMAN_PLATEBODY = 12811;
  
  public static final int IRONMAN_PLATELEGS = 12812;
  
  public static final int ULTIMATE_IRONMAN_HELM = 12813;
  
  public static final int ULTIMATE_IRONMAN_PLATEBODY = 12814;
  
  public static final int ULTIMATE_IRONMAN_PLATELEGS = 12815;
  
  public static final int PET_DARK_CORE = 12816;
  
  public static final int ELYSIAN_SPIRIT_SHIELD = 12817;
  
  public static final int ELYSIAN_SIGIL = 12819;
  
  public static final int SPECTRAL_SPIRIT_SHIELD = 12821;
  
  public static final int SPECTRAL_SIGIL = 12823;
  
  public static final int ARCANE_SPIRIT_SHIELD = 12825;
  
  public static final int ARCANE_SIGIL = 12827;
  
  public static final int SPIRIT_SHIELD = 12829;
  
  public static final int BLESSED_SPIRIT_SHIELD = 12831;
  
  public static final int HOLY_ELIXIR = 12833;
  
  public static final int COMMUNITY_PUMPKIN = 12835;
  
  public static final int GRIM_REAPERS_DIARY = 12836;
  
  public static final int GRIM_ROBE = 12837;
  
  public static final int WILL_AND_TESTAMENT = 12838;
  
  public static final int HUMAN_BONES = 12839;
  
  public static final int SERVANTS_SKULL = 12840;
  
  public static final int HOURGLASS_12841 = 12841;
  
  public static final int SCYTHE_SHARPENER = 12842;
  
  public static final int HUMAN_EYE = 12843;
  
  public static final int VOICE_POTION = 12844;
  
  public static final int GRIM_REAPER_HOOD = 12845;
  
  public static final int TARGET_TELEPORT_SCROLL = 12846;
  
  public static final int GRANITE_MAUL_12848 = 12848;
  
  public static final int GRANITE_CLAMP = 12849;
  
  public static final int AMULET_OF_THE_DAMNED_FULL = 12851;
  
  public static final int AMULET_OF_THE_DAMNED = 12853;
  
  public static final int FLAMTAER_BAG = 12854;
  
  public static final int HUNTERS_HONOUR = 12855;
  
  public static final int ROGUES_REVENGE = 12856;
  
  public static final int OLIVE_OIL_PACK = 12857;
  
  public static final int EYE_OF_NEWT_PACK = 12859;
  
  public static final int THANKSGIVING_DINNER = 12861;
  
  public static final int THANKSGIVING_DINNER_12862 = 12862;
  
  public static final int DWARF_CANNON_SET = 12863;
  
  public static final int GREEN_DRAGONHIDE_SET = 12865;
  
  public static final int BLUE_DRAGONHIDE_SET = 12867;
  
  public static final int RED_DRAGONHIDE_SET = 12869;
  
  public static final int BLACK_DRAGONHIDE_SET = 12871;
  
  public static final int GUTHANS_ARMOUR_SET = 12873;
  
  public static final int VERACS_ARMOUR_SET = 12875;
  
  public static final int DHAROKS_ARMOUR_SET = 12877;
  
  public static final int TORAGS_ARMOUR_SET = 12879;
  
  public static final int AHRIMS_ARMOUR_SET = 12881;
  
  public static final int KARILS_ARMOUR_SET = 12883;
  
  public static final int JAR_OF_SAND = 12885;
  
  public static final int SANTA_MASK = 12887;
  
  public static final int SANTA_JACKET = 12888;
  
  public static final int SANTA_PANTALOONS = 12889;
  
  public static final int SANTA_GLOVES = 12890;
  
  public static final int SANTA_BOOTS = 12891;
  
  public static final int ANTISANTA_MASK = 12892;
  
  public static final int ANTISANTA_JACKET = 12893;
  
  public static final int ANTISANTA_PANTALOONS = 12894;
  
  public static final int ANTISANTA_GLOVES = 12895;
  
  public static final int ANTISANTA_BOOTS = 12896;
  
  public static final int ANTISANTAS_COAL_BOX = 12897;
  
  public static final int ANTISANTAS_COAL_BOX_FULL = 12898;
  
  public static final int TRIDENT_OF_THE_SWAMP = 12899;
  
  public static final int UNCHARGED_TOXIC_TRIDENT = 12900;
  
  public static final int TOXIC_STAFF_UNCHARGED = 12902;
  
  public static final int TOXIC_STAFF_OF_THE_DEAD = 12904;
  
  public static final int ANTIVENOM4 = 12905;
  
  public static final int ANTIVENOM3 = 12907;
  
  public static final int ANTIVENOM2 = 12909;
  
  public static final int ANTIVENOM1 = 12911;
  
  public static final int ANTIVENOM4_12913 = 12913;
  
  public static final int ANTIVENOM3_12915 = 12915;
  
  public static final int ANTIVENOM2_12917 = 12917;
  
  public static final int ANTIVENOM1_12919 = 12919;
  
  public static final int PET_SNAKELING = 12921;
  
  public static final int TANZANITE_FANG = 12922;
  
  public static final int TOXIC_BLOWPIPE_EMPTY = 12924;
  
  public static final int TOXIC_BLOWPIPE = 12926;
  
  public static final int SERPENTINE_VISAGE = 12927;
  
  public static final int SERPENTINE_HELM_UNCHARGED = 12929;
  
  public static final int SERPENTINE_HELM = 12931;
  
  public static final int MAGIC_FANG = 12932;
  
  public static final int ZULRAHS_SCALES = 12934;
  
  public static final int OHNS_DIARY = 12935;
  
  public static final int JAR_OF_SWAMP = 12936;
  
  public static final int ZULANDRA_TELEPORT = 12938;
  
  public static final int PET_SNAKELING_12939 = 12939;
  
  public static final int PET_SNAKELING_12940 = 12940;
  
  public static final int DRAGON_DEFENDER = 12954;
  
  public static final int FREE_TO_PLAY_STARTER_PACK = 12955;
  
  public static final int COW_TOP = 12956;
  
  public static final int COW_TROUSERS = 12957;
  
  public static final int COW_GLOVES = 12958;
  
  public static final int COW_SHOES = 12959;
  
  public static final int BRONZE_SET_LG = 12960;
  
  public static final int BRONZE_SET_SK = 12962;
  
  public static final int BRONZE_TRIMMED_SET_LG = 12964;
  
  public static final int BRONZE_TRIMMED_SET_SK = 12966;
  
  public static final int BRONZE_GOLDTRIMMED_SET_LG = 12968;
  
  public static final int BRONZE_GOLDTRIMMED_SET_SK = 12970;
  
  public static final int IRON_SET_LG = 12972;
  
  public static final int IRON_SET_SK = 12974;
  
  public static final int IRON_TRIMMED_SET_LG = 12976;
  
  public static final int IRON_TRIMMED_SET_SK = 12978;
  
  public static final int IRON_GOLDTRIMMED_SET_LG = 12980;
  
  public static final int IRON_GOLDTRIMMED_SET_SK = 12982;
  
  public static final int STEEL_SET_LG = 12984;
  
  public static final int STEEL_SET_SK = 12986;
  
  public static final int BLACK_SET_LG = 12988;
  
  public static final int BLACK_SET_SK = 12990;
  
  public static final int BLACK_TRIMMED_SET_LG = 12992;
  
  public static final int BLACK_TRIMMED_SET_SK = 12994;
  
  public static final int BLACK_GOLDTRIMMED_SET_LG = 12996;
  
  public static final int BLACK_GOLDTRIMMED_SET_SK = 12998;
  
  public static final int MITHRIL_SET_LG = 13000;
  
  public static final int MITHRIL_SET_SK = 13002;
  
  public static final int MITHRIL_TRIMMED_SET_LG = 13004;
  
  public static final int MITHRIL_TRIMMED_SET_SK = 13006;
  
  public static final int MITHRIL_GOLDTRIMMED_SET_LG = 13008;
  
  public static final int MITHRIL_GOLDTRIMMED_SET_SK = 13010;
  
  public static final int ADAMANT_SET_LG = 13012;
  
  public static final int ADAMANT_SET_SK = 13014;
  
  public static final int ADAMANT_TRIMMED_SET_LG = 13016;
  
  public static final int ADAMANT_TRIMMED_SET_SK = 13018;
  
  public static final int ADAMANT_GOLDTRIMMED_SET_LG = 13020;
  
  public static final int ADAMANT_GOLDTRIMMED_SET_SK = 13022;
  
  public static final int RUNE_ARMOUR_SET_LG = 13024;
  
  public static final int RUNE_ARMOUR_SET_SK = 13026;
  
  public static final int RUNE_TRIMMED_SET_LG = 13028;
  
  public static final int RUNE_TRIMMED_SET_SK = 13030;
  
  public static final int RUNE_GOLDTRIMMED_SET_LG = 13032;
  
  public static final int RUNE_GOLDTRIMMED_SET_SK = 13034;
  
  public static final int GILDED_ARMOUR_SET_LG = 13036;
  
  public static final int GILDED_ARMOUR_SET_SK = 13038;
  
  public static final int SARADOMIN_ARMOUR_SET_LG = 13040;
  
  public static final int SARADOMIN_ARMOUR_SET_SK = 13042;
  
  public static final int ZAMORAK_ARMOUR_SET_LG = 13044;
  
  public static final int ZAMORAK_ARMOUR_SET_SK = 13046;
  
  public static final int GUTHIX_ARMOUR_SET_LG = 13048;
  
  public static final int GUTHIX_ARMOUR_SET_SK = 13050;
  
  public static final int ARMADYL_RUNE_ARMOUR_SET_LG = 13052;
  
  public static final int ARMADYL_RUNE_ARMOUR_SET_SK = 13054;
  
  public static final int BANDOS_RUNE_ARMOUR_SET_LG = 13056;
  
  public static final int BANDOS_RUNE_ARMOUR_SET_SK = 13058;
  
  public static final int ANCIENT_RUNE_ARMOUR_SET_LG = 13060;
  
  public static final int ANCIENT_RUNE_ARMOUR_SET_SK = 13062;
  
  public static final int COMBAT_POTION_SET = 13064;
  
  public static final int SUPER_POTION_SET = 13066;
  
  public static final int QUEST_POINT_CAPE_T = 13068;
  
  public static final int ACHIEVEMENT_DIARY_CAPE_T = 13069;
  
  public static final int ACHIEVEMENT_DIARY_HOOD = 13070;
  
  public static final int CHOMPY_CHICK = 13071;
  
  public static final int ELITE_VOID_TOP = 13072;
  
  public static final int ELITE_VOID_ROBE = 13073;
  
  public static final int PHARAOHS_SCEPTRE_13074 = 13074;
  
  public static final int PHARAOHS_SCEPTRE_13075 = 13075;
  
  public static final int PHARAOHS_SCEPTRE_13076 = 13076;
  
  public static final int PHARAOHS_SCEPTRE_13077 = 13077;
  
  public static final int PHARAOHS_SCEPTRE_13078 = 13078;
  
  public static final int ENCHANTED_LYRE5 = 13079;
  
  public static final int NEW_CRYSTAL_HALBERD_FULL_I = 13080;
  
  public static final int CRYSTAL_HALBERD_FULL_I = 13081;
  
  public static final int CRYSTAL_HALBERD_910_I = 13082;
  
  public static final int CRYSTAL_HALBERD_810_I = 13083;
  
  public static final int CRYSTAL_HALBERD_710_I = 13084;
  
  public static final int CRYSTAL_HALBERD_610_I = 13085;
  
  public static final int CRYSTAL_HALBERD_510_I = 13086;
  
  public static final int CRYSTAL_HALBERD_410_I = 13087;
  
  public static final int CRYSTAL_HALBERD_310_I = 13088;
  
  public static final int CRYSTAL_HALBERD_210_I = 13089;
  
  public static final int CRYSTAL_HALBERD_110_I = 13090;
  
  public static final int NEW_CRYSTAL_HALBERD_FULL = 13091;
  
  public static final int CRYSTAL_HALBERD_FULL = 13092;
  
  public static final int CRYSTAL_HALBERD_910 = 13093;
  
  public static final int CRYSTAL_HALBERD_810 = 13094;
  
  public static final int CRYSTAL_HALBERD_710 = 13095;
  
  public static final int CRYSTAL_HALBERD_610 = 13096;
  
  public static final int CRYSTAL_HALBERD_510 = 13097;
  
  public static final int CRYSTAL_HALBERD_410 = 13098;
  
  public static final int CRYSTAL_HALBERD_310 = 13099;
  
  public static final int CRYSTAL_HALBERD_210 = 13100;
  
  public static final int CRYSTAL_HALBERD_110 = 13101;
  
  public static final int TELEPORT_CRYSTAL_5 = 13102;
  
  public static final int KARAMJA_GLOVES_4 = 13103;
  
  public static final int VARROCK_ARMOUR_1 = 13104;
  
  public static final int VARROCK_ARMOUR_2 = 13105;
  
  public static final int VARROCK_ARMOUR_3 = 13106;
  
  public static final int VARROCK_ARMOUR_4 = 13107;
  
  public static final int WILDERNESS_SWORD_1 = 13108;
  
  public static final int WILDERNESS_SWORD_2 = 13109;
  
  public static final int WILDERNESS_SWORD_3 = 13110;
  
  public static final int WILDERNESS_SWORD_4 = 13111;
  
  public static final int MORYTANIA_LEGS_1 = 13112;
  
  public static final int MORYTANIA_LEGS_2 = 13113;
  
  public static final int MORYTANIA_LEGS_3 = 13114;
  
  public static final int MORYTANIA_LEGS_4 = 13115;
  
  public static final int BONECRUSHER = 13116;
  
  public static final int FALADOR_SHIELD_1 = 13117;
  
  public static final int FALADOR_SHIELD_2 = 13118;
  
  public static final int FALADOR_SHIELD_3 = 13119;
  
  public static final int FALADOR_SHIELD_4 = 13120;
  
  public static final int ARDOUGNE_CLOAK_1 = 13121;
  
  public static final int ARDOUGNE_CLOAK_2 = 13122;
  
  public static final int ARDOUGNE_CLOAK_3 = 13123;
  
  public static final int ARDOUGNE_CLOAK_4 = 13124;
  
  public static final int EXPLORERS_RING_1 = 13125;
  
  public static final int EXPLORERS_RING_2 = 13126;
  
  public static final int EXPLORERS_RING_3 = 13127;
  
  public static final int EXPLORERS_RING_4 = 13128;
  
  public static final int FREMENNIK_SEA_BOOTS_1 = 13129;
  
  public static final int FREMENNIK_SEA_BOOTS_2 = 13130;
  
  public static final int FREMENNIK_SEA_BOOTS_3 = 13131;
  
  public static final int FREMENNIK_SEA_BOOTS_4 = 13132;
  
  public static final int DESERT_AMULET_1 = 13133;
  
  public static final int DESERT_AMULET_2 = 13134;
  
  public static final int DESERT_AMULET_3 = 13135;
  
  public static final int DESERT_AMULET_4 = 13136;
  
  public static final int KANDARIN_HEADGEAR_1 = 13137;
  
  public static final int KANDARIN_HEADGEAR_2 = 13138;
  
  public static final int KANDARIN_HEADGEAR_3 = 13139;
  
  public static final int KANDARIN_HEADGEAR_4 = 13140;
  
  public static final int WESTERN_BANNER_1 = 13141;
  
  public static final int WESTERN_BANNER_2 = 13142;
  
  public static final int WESTERN_BANNER_3 = 13143;
  
  public static final int WESTERN_BANNER_4 = 13144;
  
  public static final int ANTIQUE_LAMP_13145 = 13145;
  
  public static final int ANTIQUE_LAMP_13146 = 13146;
  
  public static final int ANTIQUE_LAMP_13147 = 13147;
  
  public static final int ANTIQUE_LAMP_13148 = 13148;
  
  public static final int HOLY_BOOK_PAGE_SET = 13149;
  
  public static final int UNHOLY_BOOK_PAGE_SET = 13151;
  
  public static final int BOOK_OF_BALANCE_PAGE_SET = 13153;
  
  public static final int BOOK_OF_WAR_PAGE_SET = 13155;
  
  public static final int BOOK_OF_LAW_PAGE_SET = 13157;
  
  public static final int BOOK_OF_DARKNESS_PAGE_SET = 13159;
  
  public static final int ZAMORAK_DRAGONHIDE_SET = 13161;
  
  public static final int SARADOMIN_DRAGONHIDE_SET = 13163;
  
  public static final int GUTHIX_DRAGONHIDE_SET = 13165;
  
  public static final int BANDOS_DRAGONHIDE_SET = 13167;
  
  public static final int ARMADYL_DRAGONHIDE_SET = 13169;
  
  public static final int ANCIENT_DRAGONHIDE_SET = 13171;
  
  public static final int PARTYHAT_SET = 13173;
  
  public static final int HALLOWEEN_MASK_SET = 13175;
  
  public static final int VENENATIS_SPIDERLING = 13177;
  
  public static final int CALLISTO_CUB = 13178;
  
  public static final int VETION_JR = 13179;
  
  public static final int VETION_JR_13180 = 13180;
  
  public static final int SCORPIAS_OFFSPRING = 13181;
  
  public static final int BUNNY_FEET = 13182;
  
  public static final int EMPTY_BLASTER = 13183;
  
  public static final int INCOMPLETE_BLASTER = 13184;
  
  public static final int EASTER_BLASTER = 13185;
  
  public static final int VOLATILE_MINERAL = 13186;
  
  public static final int PACKAGE = 13187;
  
  public static final int DIANGOS_CLAWS = 13188;
  
  public static final int OLD_SCHOOL_BOND = 13190;
  
  public static final int OLD_SCHOOL_BOND_UNTRADEABLE = 13192;
  
  public static final int BONE_BOLT_PACK = 13193;
  
  public static final int ODDSKULL = 13195;
  
  public static final int TANZANITE_HELM_UNCHARGED = 13196;
  
  public static final int TANZANITE_HELM = 13197;
  
  public static final int MAGMA_HELM_UNCHARGED = 13198;
  
  public static final int MAGMA_HELM = 13199;
  
  public static final int TANZANITE_MUTAGEN = 13200;
  
  public static final int MAGMA_MUTAGEN = 13201;
  
  public static final int RING_OF_THE_GODS_I = 13202;
  
  public static final int MASK_OF_BALANCE = 13203;
  
  public static final int PLATINUM_TOKEN = 13204;
  
  public static final int ROTTEN_EGG = 13205;
  
  public static final int TIGER_TOY = 13215;
  
  public static final int LION_TOY = 13216;
  
  public static final int SNOW_LEOPARD_TOY = 13217;
  
  public static final int AMUR_LEOPARD_TOY = 13218;
  
  public static final int MUSIC_CAPE = 13221;
  
  public static final int MUSIC_CAPET = 13222;
  
  public static final int MUSIC_HOOD = 13223;
  
  public static final int TZREKJAD = 13225;
  
  public static final int HERB_SACK = 13226;
  
  public static final int ETERNAL_CRYSTAL = 13227;
  
  public static final int PEGASIAN_CRYSTAL = 13229;
  
  public static final int PRIMORDIAL_CRYSTAL = 13231;
  
  public static final int SMOULDERING_STONE = 13233;
  
  public static final int ETERNAL_BOOTS = 13235;
  
  public static final int PEGASIAN_BOOTS = 13237;
  
  public static final int PRIMORDIAL_BOOTS = 13239;
  
  public static final int INFERNAL_AXE = 13241;
  
  public static final int INFERNAL_AXE_UNCHARGED = 13242;
  
  public static final int INFERNAL_PICKAXE = 13243;
  
  public static final int INFERNAL_PICKAXE_UNCHARGED = 13244;
  
  public static final int JAR_OF_SOULS = 13245;
  
  public static final int HELLPUPPY = 13247;
  
  public static final int KEY_MASTERS_KEY = 13248;
  
  public static final int KEY_MASTER_TELEPORT = 13249;
  
  public static final int PLANT_POT_PACK = 13250;
  
  public static final int SACK_PACK = 13252;
  
  public static final int BASKET_PACK = 13254;
  
  public static final int SARADOMINS_LIGHT = 13256;
  
  public static final int ANGLER_HAT = 13258;
  
  public static final int ANGLER_TOP = 13259;
  
  public static final int ANGLER_WADERS = 13260;
  
  public static final int ANGLER_BOOTS = 13261;
  
  public static final int ABYSSAL_ORPHAN = 13262;
  
  public static final int ABYSSAL_BLUDGEON = 13263;
  
  public static final int ABYSSAL_DAGGER = 13265;
  
  public static final int ABYSSAL_DAGGER_P = 13267;
  
  public static final int ABYSSAL_DAGGER_P_13269 = 13269;
  
  public static final int ABYSSAL_DAGGER_P_13271 = 13271;
  
  public static final int UNSIRED = 13273;
  
  public static final int BLUDGEON_SPINE = 13274;
  
  public static final int BLUDGEON_CLAW = 13275;
  
  public static final int BLUDGEON_AXON = 13276;
  
  public static final int JAR_OF_MIASMA = 13277;
  
  public static final int OVERSEERS_BOOK = 13279;
  
  public static final int MAX_CAPE = 13280;
  
  public static final int MAX_HOOD = 13281;
  
  public static final int GRAVEDIGGER_MASK = 13283;
  
  public static final int GRAVEDIGGER_TOP = 13284;
  
  public static final int GRAVEDIGGER_LEGGINGS = 13285;
  
  public static final int GRAVEDIGGER_BOOTS = 13286;
  
  public static final int GRAVEDIGGER_GLOVES = 13287;
  
  public static final int ANTIPANTIES = 13288;
  
  public static final int BANK_KEY = 13302;
  
  public static final int BANK_KEY_13303 = 13303;
  
  public static final int BANK_KEY_13304 = 13304;
  
  public static final int BANK_KEY_13305 = 13305;
  
  public static final int BANK_KEY_13306 = 13306;
  
  public static final int BLOOD_MONEY = 13307;
  
  public static final int DEADMANS_CHEST = 13317;
  
  public static final int DEADMANS_LEGS = 13318;
  
  public static final int DEADMANS_CAPE = 13319;
  
  public static final int HERON = 13320;
  
  public static final int ROCK_GOLEM = 13321;
  
  public static final int BEAVER = 13322;
  
  public static final int BABY_CHINCHOMPA = 13323;
  
  public static final int BABY_CHINCHOMPA_13324 = 13324;
  
  public static final int BABY_CHINCHOMPA_13325 = 13325;
  
  public static final int BABY_CHINCHOMPA_13326 = 13326;
  
  public static final int ROTTEN_ONION = 13327;
  
  public static final int GREEN_BANNER = 13328;
  
  public static final int FIRE_MAX_CAPE = 13329;
  
  public static final int FIRE_MAX_HOOD = 13330;
  
  public static final int SARADOMIN_MAX_CAPE = 13331;
  
  public static final int SARADOMIN_MAX_HOOD = 13332;
  
  public static final int ZAMORAK_MAX_CAPE = 13333;
  
  public static final int ZAMORAK_MAX_HOOD = 13334;
  
  public static final int GUTHIX_MAX_CAPE = 13335;
  
  public static final int GUTHIX_MAX_HOOD = 13336;
  
  public static final int ACCUMULATOR_MAX_CAPE = 13337;
  
  public static final int ACCUMULATOR_MAX_HOOD = 13338;
  
  public static final int SACRED_EEL = 13339;
  
  public static final int AGILITY_CAPE_13340 = 13340;
  
  public static final int AGILITY_CAPET_13341 = 13341;
  
  public static final int MAX_CAPE_13342 = 13342;
  
  public static final int BLACK_SANTA_HAT = 13343;
  
  public static final int INVERTED_SANTA_HAT = 13344;
  
  public static final int ANTIPRESENT = 13345;
  
  public static final int PRESENT_13346 = 13346;
  
  public static final int VIAL_OF_TEARS_EMPTY = 13347;
  
  public static final int VIAL_OF_TEARS_1 = 13348;
  
  public static final int VIAL_OF_TEARS_2 = 13349;
  
  public static final int VIAL_OF_TEARS_3 = 13350;
  
  public static final int VIAL_OF_TEARS_FULL = 13351;
  
  public static final int VIAL_OF_SORROW = 13352;
  
  public static final int GRICOLLERS_CAN = 13353;
  
  public static final int LOVAKITE_BAR = 13354;
  
  public static final int JUNIPER_LOGS = 13355;
  
  public static final int LOVAKITE_ORE = 13356;
  
  public static final int SHAYZIEN_GLOVES_1 = 13357;
  
  public static final int SHAYZIEN_BOOTS_1 = 13358;
  
  public static final int SHAYZIEN_HELM_1 = 13359;
  
  public static final int SHAYZIEN_GREAVES_1 = 13360;
  
  public static final int SHAYZIEN_PLATEBODY_1 = 13361;
  
  public static final int SHAYZIEN_GLOVES_2 = 13362;
  
  public static final int SHAYZIEN_BOOTS_2 = 13363;
  
  public static final int SHAYZIEN_HELM_2 = 13364;
  
  public static final int SHAYZIEN_GREAVES_2 = 13365;
  
  public static final int SHAYZIEN_PLATEBODY_2 = 13366;
  
  public static final int SHAYZIEN_GLOVES_3 = 13367;
  
  public static final int SHAYZIEN_BOOTS_3 = 13368;
  
  public static final int SHAYZIEN_HELM_3 = 13369;
  
  public static final int SHAYZIEN_GREAVES_3 = 13370;
  
  public static final int SHAYZIEN_PLATEBODY_3 = 13371;
  
  public static final int SHAYZIEN_GLOVES_4 = 13372;
  
  public static final int SHAYZIEN_BOOTS_4 = 13373;
  
  public static final int SHAYZIEN_HELM_4 = 13374;
  
  public static final int SHAYZIEN_GREAVES_4 = 13375;
  
  public static final int SHAYZIEN_PLATEBODY_4 = 13376;
  
  public static final int SHAYZIEN_GLOVES_5 = 13377;
  
  public static final int SHAYZIEN_BOOTS_5 = 13378;
  
  public static final int SHAYZIEN_HELM_5 = 13379;
  
  public static final int SHAYZIEN_GREAVES_5 = 13380;
  
  public static final int SHAYZIEN_BODY_5 = 13381;
  
  public static final int SHAYZIEN_MEDPACK = 13382;
  
  public static final int XERICIAN_FABRIC = 13383;
  
  public static final int XERICIAN_HAT = 13385;
  
  public static final int XERICIAN_TOP = 13387;
  
  public static final int XERICIAN_ROBE = 13389;
  
  public static final int LIZARDMAN_FANG = 13391;
  
  public static final int XERICS_TALISMAN_INERT = 13392;
  
  public static final int XERICS_TALISMAN = 13393;
  
  public static final int GANG_MEETING_INFO = 13394;
  
  public static final int INTELLIGENCE = 13395;
  
  public static final int TRAINING_MANUAL = 13396;
  
  public static final int SERVERY_FLOUR = 13397;
  
  public static final int SERVERY_PASTRY_DOUGH = 13398;
  
  public static final int SERVERY_RAW_MEAT = 13399;
  
  public static final int SERVERY_DISH = 13400;
  
  public static final int SERVERY_PIE_SHELL = 13401;
  
  public static final int SERVERY_UNCOOKED_PIE = 13402;
  
  public static final int SERVERY_MEAT_PIE = 13403;
  
  public static final int SERVERY_PIZZA_BASE = 13404;
  
  public static final int SERVERY_TOMATO = 13405;
  
  public static final int SERVERY_INCOMPLETE_PIZZA = 13406;
  
  public static final int SERVERY_CHEESE = 13407;
  
  public static final int SERVERY_UNCOOKED_PIZZA = 13408;
  
  public static final int SERVERY_PLAIN_PIZZA = 13409;
  
  public static final int SERVERY_PINEAPPLE = 13410;
  
  public static final int SERVERY_PINEAPPLE_CHUNKS = 13411;
  
  public static final int SERVERY_PINEAPPLE_PIZZA = 13412;
  
  public static final int SERVERY_COOKED_MEAT = 13413;
  
  public static final int SERVERY_POTATO = 13414;
  
  public static final int SERVERY_INCOMPLETE_STEW = 13415;
  
  public static final int SERVERY_INCOMPLETE_STEW_13416 = 13416;
  
  public static final int SERVERY_UNCOOKED_STEW = 13417;
  
  public static final int SERVERY_STEW = 13418;
  
  public static final int SULPHUROUS_FERTILISER = 13419;
  
  public static final int GRICOLLERS_FERTILISER = 13420;
  
  public static final int SALTPETRE = 13421;
  
  public static final int GOLOVANOVA_SEED = 13423;
  
  public static final int BOLOGANO_SEED = 13424;
  
  public static final int LOGAVANO_SEED = 13425;
  
  public static final int GOLOVANOVA_FRUIT = 13426;
  
  public static final int BOLOGANO_FRUIT = 13427;
  
  public static final int LOGAVANO_FRUIT = 13428;
  
  public static final int FRESH_FISH = 13429;
  
  public static final int BUCKET_OF_SANDWORMS = 13430;
  
  public static final int SANDWORMS = 13431;
  
  public static final int SANDWORMS_PACK = 13432;
  
  public static final int STOLEN_PENDANT = 13434;
  
  public static final int STOLEN_GARNET_RING = 13435;
  
  public static final int STOLEN_CIRCLET = 13436;
  
  public static final int STOLEN_FAMILY_HEIRLOOM = 13437;
  
  public static final int STOLEN_JEWELRY_BOX = 13438;
  
  public static final int RAW_ANGLERFISH = 13439;
  
  public static final int ANGLERFISH = 13441;
  
  public static final int BURNT_ANGLERFISH = 13443;
  
  public static final int DENSE_ESSENCE_BLOCK = 13445;
  
  public static final int DARK_ESSENCE_BLOCK = 13446;
  
  public static final int ENSOULED_GOBLIN_HEAD = 13447;
  
  public static final int ENSOULED_GOBLIN_HEAD_13448 = 13448;
  
  public static final int ENSOULED_MONKEY_HEAD = 13450;
  
  public static final int ENSOULED_MONKEY_HEAD_13451 = 13451;
  
  public static final int ENSOULED_IMP_HEAD = 13453;
  
  public static final int ENSOULED_IMP_HEAD_13454 = 13454;
  
  public static final int ENSOULED_MINOTAUR_HEAD = 13456;
  
  public static final int ENSOULED_MINOTAUR_HEAD_13457 = 13457;
  
  public static final int ENSOULED_SCORPION_HEAD = 13459;
  
  public static final int ENSOULED_SCORPION_HEAD_13460 = 13460;
  
  public static final int ENSOULED_BEAR_HEAD = 13462;
  
  public static final int ENSOULED_BEAR_HEAD_13463 = 13463;
  
  public static final int ENSOULED_UNICORN_HEAD = 13465;
  
  public static final int ENSOULED_UNICORN_HEAD_13466 = 13466;
  
  public static final int ENSOULED_DOG_HEAD = 13468;
  
  public static final int ENSOULED_DOG_HEAD_13469 = 13469;
  
  public static final int ENSOULED_CHAOS_DRUID_HEAD = 13471;
  
  public static final int ENSOULED_CHAOS_DRUID_HEAD_13472 = 13472;
  
  public static final int ENSOULED_GIANT_HEAD = 13474;
  
  public static final int ENSOULED_GIANT_HEAD_13475 = 13475;
  
  public static final int ENSOULED_OGRE_HEAD = 13477;
  
  public static final int ENSOULED_OGRE_HEAD_13478 = 13478;
  
  public static final int ENSOULED_ELF_HEAD = 13480;
  
  public static final int ENSOULED_ELF_HEAD_13481 = 13481;
  
  public static final int ENSOULED_TROLL_HEAD = 13483;
  
  public static final int ENSOULED_TROLL_HEAD_13484 = 13484;
  
  public static final int ENSOULED_HORROR_HEAD = 13486;
  
  public static final int ENSOULED_HORROR_HEAD_13487 = 13487;
  
  public static final int ENSOULED_KALPHITE_HEAD = 13489;
  
  public static final int ENSOULED_KALPHITE_HEAD_13490 = 13490;
  
  public static final int ENSOULED_DAGANNOTH_HEAD = 13492;
  
  public static final int ENSOULED_DAGANNOTH_HEAD_13493 = 13493;
  
  public static final int ENSOULED_BLOODVELD_HEAD = 13495;
  
  public static final int ENSOULED_BLOODVELD_HEAD_13496 = 13496;
  
  public static final int ENSOULED_TZHAAR_HEAD = 13498;
  
  public static final int ENSOULED_TZHAAR_HEAD_13499 = 13499;
  
  public static final int ENSOULED_DEMON_HEAD = 13501;
  
  public static final int ENSOULED_DEMON_HEAD_13502 = 13502;
  
  public static final int ENSOULED_AVIANSIE_HEAD = 13504;
  
  public static final int ENSOULED_AVIANSIE_HEAD_13505 = 13505;
  
  public static final int ENSOULED_ABYSSAL_HEAD = 13507;
  
  public static final int ENSOULED_ABYSSAL_HEAD_13508 = 13508;
  
  public static final int ENSOULED_DRAGON_HEAD = 13510;
  
  public static final int ENSOULED_DRAGON_HEAD_13511 = 13511;
  
  public static final int BOOK_OF_ARCANE_KNOWLEDGE = 13513;
  
  public static final int DARK_MANUSCRIPT = 13514;
  
  public static final int DARK_MANUSCRIPT_13515 = 13515;
  
  public static final int DARK_MANUSCRIPT_13516 = 13516;
  
  public static final int DARK_MANUSCRIPT_13517 = 13517;
  
  public static final int DARK_MANUSCRIPT_13518 = 13518;
  
  public static final int DARK_MANUSCRIPT_13519 = 13519;
  
  public static final int DARK_MANUSCRIPT_13520 = 13520;
  
  public static final int DARK_MANUSCRIPT_13521 = 13521;
  
  public static final int DARK_MANUSCRIPT_13522 = 13522;
  
  public static final int DARK_MANUSCRIPT_13523 = 13523;
  
  public static final int RADAS_CENSUS = 13524;
  
  public static final int RICKTORS_DIARY_7 = 13525;
  
  public static final int EATHRAM__RADA_EXTRACT = 13526;
  
  public static final int KILLING_OF_A_KING = 13527;
  
  public static final int HOSIDIUS_LETTER = 13528;
  
  public static final int WINTERTODT_PARABLE = 13529;
  
  public static final int TWILL_ACCORD = 13530;
  
  public static final int BYRNES_CORONATION_SPEECH = 13531;
  
  public static final int IDEOLOGY_OF_DARKNESS = 13532;
  
  public static final int RADAS_JOURNEY = 13533;
  
  public static final int TRANSVERGENCE_THEORY = 13534;
  
  public static final int TRISTESSAS_TRAGEDY = 13535;
  
  public static final int TREACHERY_OF_ROYALTY = 13536;
  
  public static final int TRANSPORTATION_INCANTATIONS = 13537;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_1 = 13538;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_1 = 13539;
  
  public static final int SHAYZIEN_SUPPLY_HELM_1 = 13540;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_1 = 13541;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_1 = 13542;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_2 = 13543;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_2 = 13544;
  
  public static final int SHAYZIEN_SUPPLY_HELM_2 = 13545;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_2 = 13546;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_2 = 13547;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_3 = 13548;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_3 = 13549;
  
  public static final int SHAYZIEN_SUPPLY_HELM_3 = 13550;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_3 = 13551;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_3 = 13552;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_4 = 13553;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_4 = 13554;
  
  public static final int SHAYZIEN_SUPPLY_HELM_4 = 13555;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_4 = 13556;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_4 = 13557;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_5 = 13558;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_5 = 13559;
  
  public static final int SHAYZIEN_SUPPLY_HELM_5 = 13560;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_5 = 13561;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_5 = 13562;
  
  public static final int SHAYZIEN_SUPPLY_CRATE = 13563;
  
  public static final int SHAYZIEN_SUPPLY_CRATE_13564 = 13564;
  
  public static final int SHAYZIEN_SUPPLY_SET_1 = 13565;
  
  public static final int SHAYZIEN_SUPPLY_SET_2 = 13566;
  
  public static final int SHAYZIEN_SUPPLY_SET_3 = 13567;
  
  public static final int SHAYZIEN_SUPPLY_SET_4 = 13568;
  
  public static final int SHAYZIEN_SUPPLY_SET_5 = 13569;
  
  public static final int JUNIPER_CHARCOAL = 13570;
  
  public static final int VOLCANIC_SULPHUR = 13571;
  
  public static final int DYNAMITE_POT = 13572;
  
  public static final int DYNAMITE = 13573;
  
  public static final int BLASTED_ORE = 13575;
  
  public static final int DRAGON_WARHAMMER = 13576;
  
  public static final int GRACEFUL_HOOD_13579 = 13579;
  
  public static final int GRACEFUL_HOOD_13580 = 13580;
  
  public static final int GRACEFUL_CAPE_13581 = 13581;
  
  public static final int GRACEFUL_CAPE_13582 = 13582;
  
  public static final int GRACEFUL_TOP_13583 = 13583;
  
  public static final int GRACEFUL_TOP_13584 = 13584;
  
  public static final int GRACEFUL_LEGS_13585 = 13585;
  
  public static final int GRACEFUL_LEGS_13586 = 13586;
  
  public static final int GRACEFUL_GLOVES_13587 = 13587;
  
  public static final int GRACEFUL_GLOVES_13588 = 13588;
  
  public static final int GRACEFUL_BOOTS_13589 = 13589;
  
  public static final int GRACEFUL_BOOTS_13590 = 13590;
  
  public static final int GRACEFUL_HOOD_13591 = 13591;
  
  public static final int GRACEFUL_HOOD_13592 = 13592;
  
  public static final int GRACEFUL_CAPE_13593 = 13593;
  
  public static final int GRACEFUL_CAPE_13594 = 13594;
  
  public static final int GRACEFUL_TOP_13595 = 13595;
  
  public static final int GRACEFUL_TOP_13596 = 13596;
  
  public static final int GRACEFUL_LEGS_13597 = 13597;
  
  public static final int GRACEFUL_LEGS_13598 = 13598;
  
  public static final int GRACEFUL_GLOVES_13599 = 13599;
  
  public static final int GRACEFUL_GLOVES_13600 = 13600;
  
  public static final int GRACEFUL_BOOTS_13601 = 13601;
  
  public static final int GRACEFUL_BOOTS_13602 = 13602;
  
  public static final int GRACEFUL_HOOD_13603 = 13603;
  
  public static final int GRACEFUL_HOOD_13604 = 13604;
  
  public static final int GRACEFUL_CAPE_13605 = 13605;
  
  public static final int GRACEFUL_CAPE_13606 = 13606;
  
  public static final int GRACEFUL_TOP_13607 = 13607;
  
  public static final int GRACEFUL_TOP_13608 = 13608;
  
  public static final int GRACEFUL_LEGS_13609 = 13609;
  
  public static final int GRACEFUL_LEGS_13610 = 13610;
  
  public static final int GRACEFUL_GLOVES_13611 = 13611;
  
  public static final int GRACEFUL_GLOVES_13612 = 13612;
  
  public static final int GRACEFUL_BOOTS_13613 = 13613;
  
  public static final int GRACEFUL_BOOTS_13614 = 13614;
  
  public static final int GRACEFUL_HOOD_13615 = 13615;
  
  public static final int GRACEFUL_HOOD_13616 = 13616;
  
  public static final int GRACEFUL_CAPE_13617 = 13617;
  
  public static final int GRACEFUL_CAPE_13618 = 13618;
  
  public static final int GRACEFUL_TOP_13619 = 13619;
  
  public static final int GRACEFUL_TOP_13620 = 13620;
  
  public static final int GRACEFUL_LEGS_13621 = 13621;
  
  public static final int GRACEFUL_LEGS_13622 = 13622;
  
  public static final int GRACEFUL_GLOVES_13623 = 13623;
  
  public static final int GRACEFUL_GLOVES_13624 = 13624;
  
  public static final int GRACEFUL_BOOTS_13625 = 13625;
  
  public static final int GRACEFUL_BOOTS_13626 = 13626;
  
  public static final int GRACEFUL_HOOD_13627 = 13627;
  
  public static final int GRACEFUL_HOOD_13628 = 13628;
  
  public static final int GRACEFUL_CAPE_13629 = 13629;
  
  public static final int GRACEFUL_CAPE_13630 = 13630;
  
  public static final int GRACEFUL_TOP_13631 = 13631;
  
  public static final int GRACEFUL_TOP_13632 = 13632;
  
  public static final int GRACEFUL_LEGS_13633 = 13633;
  
  public static final int GRACEFUL_LEGS_13634 = 13634;
  
  public static final int GRACEFUL_GLOVES_13635 = 13635;
  
  public static final int GRACEFUL_GLOVES_13636 = 13636;
  
  public static final int GRACEFUL_BOOTS_13637 = 13637;
  
  public static final int GRACEFUL_BOOTS_13638 = 13638;
  
  public static final int SEED_BOX = 13639;
  
  public static final int FARMERS_BORO_TROUSERS = 13640;
  
  public static final int FARMERS_BORO_TROUSERS_13641 = 13641;
  
  public static final int FARMERS_JACKET = 13642;
  
  public static final int FARMERS_SHIRT = 13643;
  
  public static final int FARMERS_BOOTS = 13644;
  
  public static final int FARMERS_BOOTS_13645 = 13645;
  
  public static final int FARMERS_STRAWHAT = 13646;
  
  public static final int FARMERS_STRAWHAT_13647 = 13647;
  
  public static final int CLUE_BOTTLE_EASY = 13648;
  
  public static final int CLUE_BOTTLE_MEDIUM = 13649;
  
  public static final int CLUE_BOTTLE_HARD = 13650;
  
  public static final int CLUE_BOTTLE_ELITE = 13651;
  
  public static final int DRAGON_CLAWS = 13652;
  
  public static final int BIRD_NEST_13653 = 13653;
  
  public static final int NEST_BOX_SEEDS_13654 = 13654;
  
  public static final int GNOME_CHILD_HAT = 13655;
  
  public static final int PRESENT_13656 = 13656;
  
  public static final int GRAPE_SEED = 13657;
  
  public static final int TELEPORT_CARD = 13658;
  
  public static final int CHRONICLE = 13660;
  
  public static final int BUNNY_TOP = 13663;
  
  public static final int BUNNY_LEGS = 13664;
  
  public static final int BUNNY_PAWS = 13665;
  
  public static final int DEADMAN_TELEPORT_TABLET = 13666;
  
  public static final int GRACEFUL_HOOD_13667 = 13667;
  
  public static final int GRACEFUL_HOOD_13668 = 13668;
  
  public static final int GRACEFUL_CAPE_13669 = 13669;
  
  public static final int GRACEFUL_CAPE_13670 = 13670;
  
  public static final int GRACEFUL_TOP_13671 = 13671;
  
  public static final int GRACEFUL_TOP_13672 = 13672;
  
  public static final int GRACEFUL_LEGS_13673 = 13673;
  
  public static final int GRACEFUL_LEGS_13674 = 13674;
  
  public static final int GRACEFUL_GLOVES_13675 = 13675;
  
  public static final int GRACEFUL_GLOVES_13676 = 13676;
  
  public static final int GRACEFUL_BOOTS_13677 = 13677;
  
  public static final int GRACEFUL_BOOTS_13678 = 13678;
  
  public static final int CABBAGE_CAPE = 13679;
  
  public static final int CABBAGE_RUNE = 13680;
  
  public static final int CRUCIFEROUS_CODEX = 13681;
  
  public static final int PHARAOHS_SCEPTRE_16176 = 16176;
  
  public static final int USELESS_KEY_16684 = 16684;
  
  public static final int NEW_CRYSTAL_BOW_16888 = 16888;
  
  public static final int NEW_CRYSTAL_BOW_I_16889 = 16889;
  
  public static final int NEW_CRYSTAL_SHIELD_16890 = 16890;
  
  public static final int NEW_CRYSTAL_SHIELD_I_16891 = 16891;
  
  public static final int NEW_CRYSTAL_HALBERD_FULL_I_16892 = 16892;
  
  public static final int NEW_CRYSTAL_HALBERD_FULL_16893 = 16893;
  
  public static final int DEAD_ORB_17152 = 17152;
  
  public static final int SHAYZIEN_MEDPACK_18459 = 18459;
  
  public static final int SULPHUROUS_FERTILISER_18467 = 18467;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_1_18555 = 18555;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_1_18556 = 18556;
  
  public static final int SHAYZIEN_SUPPLY_HELM_1_18557 = 18557;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_1_18558 = 18558;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_1_18559 = 18559;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_2_18560 = 18560;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_2_18561 = 18561;
  
  public static final int SHAYZIEN_SUPPLY_HELM_2_18562 = 18562;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_2_18563 = 18563;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_2_18564 = 18564;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_3_18565 = 18565;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_3_18566 = 18566;
  
  public static final int SHAYZIEN_SUPPLY_HELM_3_18567 = 18567;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_3_18568 = 18568;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_3_18569 = 18569;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_4_18570 = 18570;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_4_18571 = 18571;
  
  public static final int SHAYZIEN_SUPPLY_HELM_4_18572 = 18572;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_4_18573 = 18573;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_4_18574 = 18574;
  
  public static final int SHAYZIEN_SUPPLY_GLOVES_5_18575 = 18575;
  
  public static final int SHAYZIEN_SUPPLY_BOOTS_5_18576 = 18576;
  
  public static final int SHAYZIEN_SUPPLY_HELM_5_18577 = 18577;
  
  public static final int SHAYZIEN_SUPPLY_GREAVES_5_18578 = 18578;
  
  public static final int SHAYZIEN_SUPPLY_PLATEBODY_5_18579 = 18579;
  
  public static final int SHAYZIEN_SUPPLY_CRATE_18580 = 18580;
  
  public static final int SHAYZIEN_SUPPLY_SET_1_18581 = 18581;
  
  public static final int SHAYZIEN_SUPPLY_SET_2_18582 = 18582;
  
  public static final int SHAYZIEN_SUPPLY_SET_3_18583 = 18583;
  
  public static final int SHAYZIEN_SUPPLY_SET_4_18584 = 18584;
  
  public static final int SHAYZIEN_SUPPLY_SET_5_18585 = 18585;
  
  public static final int BAG_FULL_OF_GEMS = 19473;
  
  public static final int ACHIEVEMENT_DIARY_CAPE = 19476;
  
  public static final int LIGHT_BALLISTA = 19478;
  
  public static final int HEAVY_BALLISTA = 19481;
  
  public static final int DRAGON_JAVELIN = 19484;
  
  public static final int DRAGON_JAVELINP = 19486;
  
  public static final int DRAGON_JAVELINP_19488 = 19488;
  
  public static final int DRAGON_JAVELINP_19490 = 19490;
  
  public static final int ZENYTE_BRACELET = 19492;
  
  public static final int ZENYTE = 19493;
  
  public static final int UNCUT_ZENYTE = 19496;
  
  public static final int ZENYTE_AMULET_U = 19501;
  
  public static final int MYSTERIOUS_NOTE = 19505;
  
  public static final int MYSTERIOUS_NOTE_19507 = 19507;
  
  public static final int MYSTERIOUS_NOTE_19509 = 19509;
  
  public static final int SCRAWLED_NOTE_19511 = 19511;
  
  public static final int TRANSLATED_NOTE = 19513;
  
  public static final int BOOK_OF_SPYOLOGY = 19515;
  
  public static final int BRUSH = 19517;
  
  public static final int JUICECOATED_BRUSH = 19519;
  
  public static final int HANDKERCHIEF = 19521;
  
  public static final int KRUKS_PAW = 19523;
  
  public static final int KRUK_MONKEY_GREEGREE = 19525;
  
  public static final int SATCHEL = 19527;
  
  public static final int SATCHEL_19528 = 19528;
  
  public static final int ZENYTE_SHARD = 19529;
  
  public static final int ZENYTE_BRACELET_19532 = 19532;
  
  public static final int ZENYTE_NECKLACE = 19535;
  
  public static final int ZENYTE_RING = 19538;
  
  public static final int ZENYTE_AMULET = 19541;
  
  public static final int TORMENTED_BRACELET = 19544;
  
  public static final int NECKLACE_OF_ANGUISH = 19547;
  
  public static final int RING_OF_SUFFERING = 19550;
  
  public static final int AMULET_OF_TORTURE = 19553;
  
  public static final int MONKEY_19556 = 19556;
  
  public static final int NIEVE = 19558;
  
  public static final int ELYSIAN_SPIRIT_SHIELD_19559 = 19559;
  
  public static final int CHARGED_ONYX = 19560;
  
  public static final int DECONSTRUCTED_ONYX = 19562;
  
  public static final int ROYAL_SEED_POD = 19564;
  
  public static final int BRONZE_KEY_19566 = 19566;
  
  public static final int COMBAT_SCARRED_KEY = 19567;
  
  public static final int COMBAT_SCRATCHED_KEY = 19568;
  
  public static final int COMBAT_DAMAGED_KEY = 19569;
  
  public static final int BRONZE_JAVELIN_HEADS = 19570;
  
  public static final int IRON_JAVELIN_HEADS = 19572;
  
  public static final int STEEL_JAVELIN_HEADS = 19574;
  
  public static final int MITHRIL_JAVELIN_HEADS = 19576;
  
  public static final int ADAMANT_JAVELIN_HEADS = 19578;
  
  public static final int RUNE_JAVELIN_HEADS = 19580;
  
  public static final int DRAGON_JAVELIN_HEADS = 19582;
  
  public static final int JAVELIN_SHAFT = 19584;
  
  public static final int LIGHT_FRAME = 19586;
  
  public static final int HEAVY_FRAME = 19589;
  
  public static final int BALLISTA_LIMBS = 19592;
  
  public static final int INCOMPLETE_LIGHT_BALLISTA = 19595;
  
  public static final int INCOMPLETE_HEAVY_BALLISTA = 19598;
  
  public static final int BALLISTA_SPRING = 19601;
  
  public static final int UNSTRUNG_LIGHT_BALLISTA = 19604;
  
  public static final int UNSTRUNG_HEAVY_BALLISTA = 19607;
  
  public static final int MONKEY_TAIL = 19610;
  
  public static final int ARCEUUS_LIBRARY_TELEPORT = 19613;
  
  public static final int DRAYNOR_MANOR_TELEPORT = 19615;
  
  public static final int MIND_ALTAR_TELEPORT = 19617;
  
  public static final int SALVE_GRAVEYARD_TELEPORT = 19619;
  
  public static final int FENKENSTRAINS_CASTLE_TELEPORT = 19621;
  
  public static final int WEST_ARDOUGNE_TELEPORT = 19623;
  
  public static final int HARMONY_ISLAND_TELEPORT = 19625;
  
  public static final int CEMETERY_TELEPORT = 19627;
  
  public static final int BARROWS_TELEPORT = 19629;
  
  public static final int APE_ATOLL_TELEPORT = 19631;
  
  public static final int SOUL_BEARER = 19634;
  
  public static final int DAMAGED_SOUL_BEARER = 19636;
  
  public static final int SOUL_JOURNEY = 19637;
  
  public static final int BLACK_SLAYER_HELMET = 19639;
  
  public static final int BLACK_SLAYER_HELMET_I = 19641;
  
  public static final int GREEN_SLAYER_HELMET = 19643;
  
  public static final int GREEN_SLAYER_HELMET_I = 19645;
  
  public static final int RED_SLAYER_HELMET = 19647;
  
  public static final int RED_SLAYER_HELMET_I = 19649;
  
  public static final int HOSIDIUS_TELEPORT = 19651;
  
  public static final int GOLOVANOVA_FRUIT_TOP = 19653;
  
  public static final int UNCOOKED_BOTANICAL_PIE = 19656;
  
  public static final int HALF_A_BOTANICAL_PIE = 19659;
  
  public static final int BOTANICAL_PIE = 19662;
  
  public static final int DAMAGED_MONKEY_TAIL = 19665;
  
  public static final int MINECART_CONTROL_SCROLL = 19668;
  
  public static final int REDWOOD_LOGS = 19669;
  
  public static final int REDWOOD_PYRE_LOGS = 19672;
  
  public static final int ARCLIGHT = 19675;
  
  public static final int ANCIENT_SHARD = 19677;
  
  public static final int DARK_TOTEM_BASE = 19679;
  
  public static final int DARK_TOTEM_MIDDLE = 19681;
  
  public static final int DARK_TOTEM_TOP = 19683;
  
  public static final int DARK_TOTEM = 19685;
  
  public static final int HELM_OF_RAEDWALD = 19687;
  
  public static final int CLUE_HUNTER_GARB = 19689;
  
  public static final int CLUE_HUNTER_GLOVES = 19691;
  
  public static final int CLUE_HUNTER_TROUSERS = 19693;
  
  public static final int CLUE_HUNTER_BOOTS = 19695;
  
  public static final int CLUE_HUNTER_CLOAK = 19697;
  
  public static final int HORNWOOD_HELM = 19699;
  
  public static final int JAR_OF_DARKNESS = 19701;
  
  public static final int COMPOST_PACK = 19704;
  
  public static final int AMULET_OF_ETERNAL_GLORY = 19707;
  
  public static final int RING_OF_SUFFERING_I = 19710;
  
  public static final int CLUE_NEST_EASY = 19712;
  
  public static final int CLUE_NEST_MEDIUM = 19714;
  
  public static final int CLUE_NEST_HARD = 19716;
  
  public static final int CLUE_NEST_ELITE = 19718;
  
  public static final int OCCULT_NECKLACE_OR = 19720;
  
  public static final int DRAGON_DEFENDER_T = 19722;
  
  public static final int LEFT_EYE_PATCH = 19724;
  
  public static final int DOUBLE_EYE_PATCH = 19727;
  
  public static final int BLOODHOUND = 19730;
  
  public static final int LUCKY_IMPLING_JAR = 19732;
  
  public static final int CLUE_SCROLL_MEDIUM_19734 = 19734;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19735 = 19735;
  
  public static final int CLUE_SCROLL_MEDIUM_19736 = 19736;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19737 = 19737;
  
  public static final int CLUE_SCROLL_MEDIUM_19738 = 19738;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19739 = 19739;
  
  public static final int CLUE_SCROLL_MEDIUM_19740 = 19740;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19741 = 19741;
  
  public static final int CLUE_SCROLL_MEDIUM_19742 = 19742;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19743 = 19743;
  
  public static final int CLUE_SCROLL_MEDIUM_19744 = 19744;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19745 = 19745;
  
  public static final int CLUE_SCROLL_MEDIUM_19746 = 19746;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19747 = 19747;
  
  public static final int CLUE_SCROLL_MEDIUM_19748 = 19748;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19749 = 19749;
  
  public static final int CLUE_SCROLL_MEDIUM_19750 = 19750;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19751 = 19751;
  
  public static final int CLUE_SCROLL_MEDIUM_19752 = 19752;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19753 = 19753;
  
  public static final int CLUE_SCROLL_MEDIUM_19754 = 19754;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19755 = 19755;
  
  public static final int CLUE_SCROLL_MEDIUM_19756 = 19756;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19757 = 19757;
  
  public static final int CLUE_SCROLL_MEDIUM_19758 = 19758;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19759 = 19759;
  
  public static final int CLUE_SCROLL_MEDIUM_19760 = 19760;
  
  public static final int KEY_MEDIUM_19761 = 19761;
  
  public static final int CLUE_SCROLL_MEDIUM_19762 = 19762;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19763 = 19763;
  
  public static final int CLUE_SCROLL_MEDIUM_19764 = 19764;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19765 = 19765;
  
  public static final int CLUE_SCROLL_MEDIUM_19766 = 19766;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19767 = 19767;
  
  public static final int CLUE_SCROLL_MEDIUM_19768 = 19768;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19769 = 19769;
  
  public static final int CLUE_SCROLL_MEDIUM_19770 = 19770;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19771 = 19771;
  
  public static final int CLUE_SCROLL_MEDIUM_19772 = 19772;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_19773 = 19773;
  
  public static final int CLUE_SCROLL_MEDIUM_19774 = 19774;
  
  public static final int CASKET_MEDIUM_19775 = 19775;
  
  public static final int CLUE_SCROLL_MEDIUM_19776 = 19776;
  
  public static final int CASKET_MEDIUM_19777 = 19777;
  
  public static final int CLUE_SCROLL_MEDIUM_19778 = 19778;
  
  public static final int CASKET_MEDIUM_19779 = 19779;
  
  public static final int CLUE_SCROLL_MEDIUM_19780 = 19780;
  
  public static final int CASKET_MEDIUM_19781 = 19781;
  
  public static final int CLUE_SCROLL_ELITE_19782 = 19782;
  
  public static final int CLUE_SCROLL_ELITE_19783 = 19783;
  
  public static final int CLUE_SCROLL_ELITE_19784 = 19784;
  
  public static final int CLUE_SCROLL_ELITE_19785 = 19785;
  
  public static final int CLUE_SCROLL_ELITE_19786 = 19786;
  
  public static final int CLUE_SCROLL_ELITE_19787 = 19787;
  
  public static final int CLUE_SCROLL_ELITE_19788 = 19788;
  
  public static final int CLUE_SCROLL_ELITE_19789 = 19789;
  
  public static final int CLUE_SCROLL_ELITE_19790 = 19790;
  
  public static final int CLUE_SCROLL_ELITE_19791 = 19791;
  
  public static final int CLUE_SCROLL_ELITE_19792 = 19792;
  
  public static final int CLUE_SCROLL_ELITE_19793 = 19793;
  
  public static final int CLUE_SCROLL_ELITE_19794 = 19794;
  
  public static final int CLUE_SCROLL_ELITE_19795 = 19795;
  
  public static final int CLUE_SCROLL_ELITE_19796 = 19796;
  
  public static final int CLUE_SCROLL_ELITE_19797 = 19797;
  
  public static final int CLUE_SCROLL_ELITE_19798 = 19798;
  
  public static final int CLUE_SCROLL_ELITE_19799 = 19799;
  
  public static final int CLUE_SCROLL_ELITE_19800 = 19800;
  
  public static final int CLUE_SCROLL_ELITE_19801 = 19801;
  
  public static final int CLUE_SCROLL_ELITE_19802 = 19802;
  
  public static final int CLUE_SCROLL_ELITE_19803 = 19803;
  
  public static final int CLUE_SCROLL_ELITE_19804 = 19804;
  
  public static final int CLUE_SCROLL_ELITE_19805 = 19805;
  
  public static final int CLUE_SCROLL_ELITE_19806 = 19806;
  
  public static final int CLUE_SCROLL_ELITE_19807 = 19807;
  
  public static final int CLUE_SCROLL_ELITE_19808 = 19808;
  
  public static final int CLUE_SCROLL_ELITE_19809 = 19809;
  
  public static final int CLUE_SCROLL_ELITE_19810 = 19810;
  
  public static final int CLUE_SCROLL_ELITE_19811 = 19811;
  
  public static final int KEY_ELITE = 19812;
  
  public static final int CLUE_SCROLL_ELITE_19813 = 19813;
  
  public static final int CLUE_SCROLL_EASY_19814 = 19814;
  
  public static final int CASKET_EASY_19815 = 19815;
  
  public static final int CLUE_SCROLL_EASY_19816 = 19816;
  
  public static final int CLUE_SCROLL_EASY_19817 = 19817;
  
  public static final int CLUE_SCROLL_EASY_19818 = 19818;
  
  public static final int CLUE_SCROLL_EASY_19819 = 19819;
  
  public static final int CLUE_SCROLL_EASY_19820 = 19820;
  
  public static final int CLUE_SCROLL_EASY_19821 = 19821;
  
  public static final int CLUE_SCROLL_EASY_19822 = 19822;
  
  public static final int CLUE_SCROLL_EASY_19823 = 19823;
  
  public static final int CLUE_SCROLL_EASY_19824 = 19824;
  
  public static final int CLUE_SCROLL_EASY_19825 = 19825;
  
  public static final int CLUE_SCROLL_EASY_19826 = 19826;
  
  public static final int CASKET_EASY_19827 = 19827;
  
  public static final int CLUE_SCROLL_EASY_19828 = 19828;
  
  public static final int CLUE_SCROLL_EASY_19829 = 19829;
  
  public static final int CLUE_SCROLL_EASY_19830 = 19830;
  
  public static final int CLUE_SCROLL_EASY_19831 = 19831;
  
  public static final int CASKET_EASY_19832 = 19832;
  
  public static final int CLUE_SCROLL_EASY_19833 = 19833;
  
  public static final int CASKET_EASY_19834 = 19834;
  
  public static final int CLUE_SCROLL_MASTER = 19835;
  
  public static final int REWARD_CASKET_MASTER = 19836;
  
  public static final int TORN_CLUE_SCROLL_PART_1 = 19837;
  
  public static final int TORN_CLUE_SCROLL_PART_2 = 19838;
  
  public static final int TORN_CLUE_SCROLL_PART_3 = 19839;
  
  public static final int CLUE_SCROLL_HARD_19840 = 19840;
  
  public static final int CASKET_HARD_19841 = 19841;
  
  public static final int CLUE_SCROLL_HARD_19842 = 19842;
  
  public static final int CASKET_HARD_19843 = 19843;
  
  public static final int CLUE_SCROLL_HARD_19844 = 19844;
  
  public static final int CASKET_HARD_19845 = 19845;
  
  public static final int CLUE_SCROLL_HARD_19846 = 19846;
  
  public static final int CHALLENGE_SCROLL_HARD_19847 = 19847;
  
  public static final int CLUE_SCROLL_HARD_19848 = 19848;
  
  public static final int CASKET_HARD_19849 = 19849;
  
  public static final int CLUE_SCROLL_HARD_19850 = 19850;
  
  public static final int CASKET_HARD_19851 = 19851;
  
  public static final int CLUE_SCROLL_HARD_19852 = 19852;
  
  public static final int CLUE_SCROLL_HARD_19853 = 19853;
  
  public static final int CLUE_SCROLL_HARD_19854 = 19854;
  
  public static final int CHALLENGE_SCROLL_HARD_19855 = 19855;
  
  public static final int CLUE_SCROLL_HARD_19856 = 19856;
  
  public static final int CLUE_SCROLL_HARD_19857 = 19857;
  
  public static final int CLUE_SCROLL_HARD_19858 = 19858;
  
  public static final int CHALLENGE_SCROLL_HARD_19859 = 19859;
  
  public static final int CLUE_SCROLL_HARD_19860 = 19860;
  
  public static final int CASKET_HARD_19861 = 19861;
  
  public static final int CLUE_SCROLL_HARD_19862 = 19862;
  
  public static final int CASKET_HARD_19863 = 19863;
  
  public static final int CLUE_SCROLL_HARD_19864 = 19864;
  
  public static final int CASKET_HARD_19865 = 19865;
  
  public static final int CLUE_SCROLL_HARD_19866 = 19866;
  
  public static final int CASKET_HARD_19867 = 19867;
  
  public static final int CLUE_SCROLL_HARD_19868 = 19868;
  
  public static final int CASKET_HARD_19869 = 19869;
  
  public static final int CLUE_SCROLL_HARD_19870 = 19870;
  
  public static final int CASKET_HARD_19871 = 19871;
  
  public static final int CLUE_SCROLL_HARD_19872 = 19872;
  
  public static final int CASKET_HARD_19873 = 19873;
  
  public static final int CLUE_SCROLL_HARD_19874 = 19874;
  
  public static final int CASKET_HARD_19875 = 19875;
  
  public static final int CLUE_SCROLL_HARD_19876 = 19876;
  
  public static final int CASKET_HARD_19877 = 19877;
  
  public static final int CLUE_SCROLL_HARD_19878 = 19878;
  
  public static final int CASKET_HARD_19879 = 19879;
  
  public static final int CLUE_SCROLL_HARD_19880 = 19880;
  
  public static final int CASKET_HARD_19881 = 19881;
  
  public static final int CLUE_SCROLL_HARD_19882 = 19882;
  
  public static final int CHALLENGE_SCROLL_HARD_19883 = 19883;
  
  public static final int CLUE_SCROLL_HARD_19884 = 19884;
  
  public static final int CHALLENGE_SCROLL_HARD_19885 = 19885;
  
  public static final int CLUE_SCROLL_HARD_19886 = 19886;
  
  public static final int PUZZLE_BOX_HARD_19887 = 19887;
  
  public static final int CLUE_SCROLL_HARD_19888 = 19888;
  
  public static final int CHALLENGE_SCROLL_HARD_19889 = 19889;
  
  public static final int CLUE_SCROLL_HARD_19890 = 19890;
  
  public static final int PUZZLE_BOX_HARD_19891 = 19891;
  
  public static final int CLUE_SCROLL_HARD_19892 = 19892;
  
  public static final int CHALLENGE_SCROLL_HARD_19893 = 19893;
  
  public static final int CLUE_SCROLL_HARD_19894 = 19894;
  
  public static final int PUZZLE_BOX_HARD_19895 = 19895;
  
  public static final int CLUE_SCROLL_HARD_19896 = 19896;
  
  public static final int PUZZLE_BOX_HARD_19897 = 19897;
  
  public static final int CLUE_SCROLL_HARD_19898 = 19898;
  
  public static final int CHALLENGE_SCROLL_HARD_19899 = 19899;
  
  public static final int CLUE_SCROLL_HARD_19900 = 19900;
  
  public static final int CHALLENGE_SCROLL_HARD_19901 = 19901;
  
  public static final int CLUE_SCROLL_HARD_19902 = 19902;
  
  public static final int PUZZLE_BOX_HARD_19903 = 19903;
  
  public static final int CLUE_SCROLL_HARD_19904 = 19904;
  
  public static final int CHALLENGE_SCROLL_HARD_19905 = 19905;
  
  public static final int CLUE_SCROLL_HARD_19906 = 19906;
  
  public static final int CHALLENGE_SCROLL_HARD_19907 = 19907;
  
  public static final int CLUE_SCROLL_HARD_19908 = 19908;
  
  public static final int CHALLENGE_SCROLL_HARD_19909 = 19909;
  
  public static final int CLUE_SCROLL_HARD_19910 = 19910;
  
  public static final int PUZZLE_BOX_HARD_19911 = 19911;
  
  public static final int ZOMBIE_HEAD_19912 = 19912;
  
  public static final int CYCLOPS_HEAD = 19915;
  
  public static final int NUNCHAKU = 19918;
  
  public static final int ANCIENT_DHIDE_BOOTS = 19921;
  
  public static final int BANDOS_DHIDE_BOOTS = 19924;
  
  public static final int GUTHIX_DHIDE_BOOTS = 19927;
  
  public static final int ARMADYL_DHIDE_BOOTS = 19930;
  
  public static final int SARADOMIN_DHIDE_BOOTS = 19933;
  
  public static final int ZAMORAK_DHIDE_BOOTS = 19936;
  
  public static final int STRANGE_DEVICE = 19939;
  
  public static final int HEAVY_CASKET = 19941;
  
  public static final int ARCEUUS_SCARF = 19943;
  
  public static final int HOSIDIUS_SCARF = 19946;
  
  public static final int LOVAKENGJ_SCARF = 19949;
  
  public static final int PISCARILIUS_SCARF = 19952;
  
  public static final int SHAYZIEN_SCARF = 19955;
  
  public static final int DARK_TUXEDO_JACKET = 19958;
  
  public static final int DARK_TUXEDO_CUFFS = 19961;
  
  public static final int DARK_TROUSERS = 19964;
  
  public static final int DARK_TUXEDO_SHOES = 19967;
  
  public static final int DARK_BOW_TIE = 19970;
  
  public static final int LIGHT_TUXEDO_JACKET = 19973;
  
  public static final int LIGHT_TUXEDO_CUFFS = 19976;
  
  public static final int LIGHT_TROUSERS = 19979;
  
  public static final int LIGHT_TUXEDO_SHOES = 19982;
  
  public static final int LIGHT_BOW_TIE = 19985;
  
  public static final int BLACKSMITHS_HELM = 19988;
  
  public static final int BUCKET_HELM = 19991;
  
  public static final int RANGER_GLOVES = 19994;
  
  public static final int HOLY_WRAPS = 19997;
  
  public static final int DRAGON_SCIMITAR_OR = 20000;
  
  public static final int DRAGON_SCIMITAR_ORNAMENT_KIT = 20002;
  
  public static final int RING_OF_NATURE = 20005;
  
  public static final int FANCY_TIARA = 20008;
  
  public static final int _3RD_AGE_AXE = 20011;
  
  public static final int _3RD_AGE_PICKAXE = 20014;
  
  public static final int RING_OF_COINS = 20017;
  
  public static final int LESSER_DEMON_MASK = 20020;
  
  public static final int GREATER_DEMON_MASK = 20023;
  
  public static final int BLACK_DEMON_MASK = 20026;
  
  public static final int OLD_DEMON_MASK = 20029;
  
  public static final int JUNGLE_DEMON_MASK = 20032;
  
  public static final int SAMURAI_KASA = 20035;
  
  public static final int SAMURAI_SHIRT = 20038;
  
  public static final int SAMURAI_GLOVES = 20041;
  
  public static final int SAMURAI_GREAVES = 20044;
  
  public static final int SAMURAI_BOOTS = 20047;
  
  public static final int OBSIDIAN_CAPE_R = 20050;
  
  public static final int HALF_MOON_SPECTACLES = 20053;
  
  public static final int ALE_OF_THE_GODS = 20056;
  
  public static final int BUCKET_HELM_G = 20059;
  
  public static final int TORTURE_ORNAMENT_KIT = 20062;
  
  public static final int OCCULT_ORNAMENT_KIT = 20065;
  
  public static final int ARMADYL_GODSWORD_ORNAMENT_KIT = 20068;
  
  public static final int BANDOS_GODSWORD_ORNAMENT_KIT = 20071;
  
  public static final int SARADOMIN_GODSWORD_ORNAMENT_KIT = 20074;
  
  public static final int ZAMORAK_GODSWORD_ORNAMENT_KIT = 20077;
  
  public static final int MUMMYS_HEAD = 20080;
  
  public static final int MUMMYS_BODY = 20083;
  
  public static final int MUMMYS_HANDS = 20086;
  
  public static final int MUMMYS_LEGS = 20089;
  
  public static final int MUMMYS_FEET = 20092;
  
  public static final int ANKOU_MASK = 20095;
  
  public static final int ANKOU_TOP = 20098;
  
  public static final int ANKOU_GLOVES = 20101;
  
  public static final int ANKOUS_LEGGINGS = 20104;
  
  public static final int ANKOU_SOCKS = 20107;
  
  public static final int BOWL_WIG = 20110;
  
  public static final int ARCEUUS_HOOD = 20113;
  
  public static final int HOSIDIUS_HOOD = 20116;
  
  public static final int LOVAKENGJ_HOOD = 20119;
  
  public static final int PISCARILIUS_HOOD = 20122;
  
  public static final int SHAYZIEN_HOOD = 20125;
  
  public static final int HOOD_OF_DARKNESS = 20128;
  
  public static final int ROBE_TOP_OF_DARKNESS = 20131;
  
  public static final int GLOVES_OF_DARKNESS = 20134;
  
  public static final int ROBE_BOTTOM_OF_DARKNESS = 20137;
  
  public static final int BOOTS_OF_DARKNESS = 20140;
  
  public static final int DRAGON_DEFENDER_ORNAMENT_KIT = 20143;
  
  public static final int GILDED_MED_HELM = 20146;
  
  public static final int GILDED_CHAINBODY = 20149;
  
  public static final int GILDED_SQ_SHIELD = 20152;
  
  public static final int GILDED_2H_SWORD = 20155;
  
  public static final int GILDED_SPEAR = 20158;
  
  public static final int GILDED_HASTA = 20161;
  
  public static final int LARGE_SPADE = 20164;
  
  public static final int WOODEN_SHIELD_G = 20166;
  
  public static final int STEEL_PLATEBODY_G = 20169;
  
  public static final int STEEL_PLATELEGS_G = 20172;
  
  public static final int STEEL_PLATESKIRT_G = 20175;
  
  public static final int STEEL_FULL_HELM_G = 20178;
  
  public static final int STEEL_KITESHIELD_G = 20181;
  
  public static final int STEEL_PLATEBODY_T = 20184;
  
  public static final int STEEL_PLATELEGS_T = 20187;
  
  public static final int STEEL_PLATESKIRT_T = 20190;
  
  public static final int STEEL_FULL_HELM_T = 20193;
  
  public static final int STEEL_KITESHIELD_T = 20196;
  
  public static final int MONKS_ROBE_TOP_G = 20199;
  
  public static final int MONKS_ROBE_G = 20202;
  
  public static final int GOLDEN_CHEFS_HAT = 20205;
  
  public static final int GOLDEN_APRON = 20208;
  
  public static final int TEAM_CAPE_ZERO = 20211;
  
  public static final int TEAM_CAPE_X = 20214;
  
  public static final int TEAM_CAPE_I = 20217;
  
  public static final int HOLY_BLESSING = 20220;
  
  public static final int UNHOLY_BLESSING = 20223;
  
  public static final int PEACEFUL_BLESSING = 20226;
  
  public static final int HONOURABLE_BLESSING = 20229;
  
  public static final int WAR_BLESSING = 20232;
  
  public static final int ANCIENT_BLESSING = 20235;
  
  public static final int CHARGE_DRAGONSTONE_JEWELLERY_SCROLL = 20238;
  
  public static final int CRIER_COAT = 20240;
  
  public static final int CRIER_BELL = 20243;
  
  public static final int BLACK_LEPRECHAUN_HAT = 20246;
  
  public static final int CLUELESS_SCROLL = 20249;
  
  public static final int ARCEUUS_BANNER = 20251;
  
  public static final int HOSIDIUS_BANNER = 20254;
  
  public static final int LOVAKENGJ_BANNER = 20257;
  
  public static final int PISCARILIUS_BANNER = 20260;
  
  public static final int SHAYZIEN_BANNER = 20263;
  
  public static final int BLACK_UNICORN_MASK = 20266;
  
  public static final int WHITE_UNICORN_MASK = 20269;
  
  public static final int CABBAGE_ROUND_SHIELD = 20272;
  
  public static final int GNOMISH_FIRELIGHTER = 20275;
  
  public static final int GNOMISH_FIRELIGHTER_20278 = 20278;
  
  public static final int PUZZLE_BOX_MASTER = 20280;
  
  public static final int PUZZLE_BOX_MASTER_20281 = 20281;
  
  public static final int PUZZLE_BOX_MASTER_20282 = 20282;
  
  public static final int LIGHT_BOX = 20355;
  
  public static final int CLUE_GEODE_EASY = 20358;
  
  public static final int CLUE_GEODE_MEDIUM = 20360;
  
  public static final int CLUE_GEODE_HARD = 20362;
  
  public static final int CLUE_GEODE_ELITE = 20364;
  
  public static final int AMULET_OF_TORTURE_OR = 20366;
  
  public static final int ARMADYL_GODSWORD_OR = 20368;
  
  public static final int BANDOS_GODSWORD_OR = 20370;
  
  public static final int SARADOMIN_GODSWORD_OR = 20372;
  
  public static final int ZAMORAK_GODSWORD_OR = 20374;
  
  public static final int STEEL_TRIMMED_SET_LG = 20376;
  
  public static final int STEEL_TRIMMED_SET_SK = 20379;
  
  public static final int STEEL_GOLDTRIMMED_SET_LG = 20382;
  
  public static final int STEEL_GOLDTRIMMED_SET_SK = 20385;
  
  public static final int ADAMANT_ARROW_20388 = 20388;
  
  public static final int DRAGON_ARROW_20389 = 20389;
  
  public static final int SHARK_20390 = 20390;
  
  public static final int PRAYER_POTION4_20393 = 20393;
  
  public static final int PRAYER_POTION3_20394 = 20394;
  
  public static final int PRAYER_POTION2_20395 = 20395;
  
  public static final int PRAYER_POTION1_20396 = 20396;
  
  public static final int SPEAR = 20397;
  
  public static final int YEW_SHORTBOW_20401 = 20401;
  
  public static final int RUNE_SCIMITAR_20402 = 20402;
  
  public static final int MAPLE_SHORTBOW_20403 = 20403;
  
  public static final int ABYSSAL_WHIP_20405 = 20405;
  
  public static final int DRAGON_SCIMITAR_20406 = 20406;
  
  public static final int DRAGON_DAGGER_20407 = 20407;
  
  public static final int DARK_BOW_20408 = 20408;
  
  public static final int ADAMANT_PLATEBODY_20415 = 20415;
  
  public static final int ADAMANT_PLATELEGS_20416 = 20416;
  
  public static final int BLUE_DHIDE_BODY_20417 = 20417;
  
  public static final int BLUE_DHIDE_CHAPS_20418 = 20418;
  
  public static final int RUNE_PLATEBODY_20421 = 20421;
  
  public static final int RUNE_PLATELEGS_20422 = 20422;
  
  public static final int BLACK_DHIDE_BODY_20423 = 20423;
  
  public static final int BLACK_DHIDE_CHAPS_20424 = 20424;
  
  public static final int MYSTIC_ROBE_TOP_20425 = 20425;
  
  public static final int MYSTIC_ROBE_BOTTOM_20426 = 20426;
  
  public static final int DRAGON_CHAINBODY_20428 = 20428;
  
  public static final int DRAGON_PLATELEGS_20429 = 20429;
  
  public static final int ANCIENT_MAGICKS_TABLET = 20430;
  
  public static final int ANCIENT_STAFF_20431 = 20431;
  
  public static final int EVIL_CHICKEN_FEET = 20433;
  
  public static final int EVIL_CHICKEN_WINGS = 20436;
  
  public static final int EVIL_CHICKEN_HEAD = 20439;
  
  public static final int EVIL_CHICKEN_LEGS = 20442;
  
  public static final int FIRE_CAPE_BROKEN = 20445;
  
  public static final int FIRE_MAX_CAPE_BROKEN = 20447;
  
  public static final int BRONZE_DEFENDER_BROKEN = 20449;
  
  public static final int IRON_DEFENDER_BROKEN = 20451;
  
  public static final int STEEL_DEFENDER_BROKEN = 20453;
  
  public static final int BLACK_DEFENDER_BROKEN = 20455;
  
  public static final int MITHRIL_DEFENDER_BROKEN = 20457;
  
  public static final int ADAMANT_DEFENDER_BROKEN = 20459;
  
  public static final int RUNE_DEFENDER_BROKEN = 20461;
  
  public static final int DRAGON_DEFENDER_BROKEN = 20463;
  
  public static final int VOID_KNIGHT_TOP_BROKEN = 20465;
  
  public static final int ELITE_VOID_TOP_BROKEN = 20467;
  
  public static final int VOID_KNIGHT_ROBE_BROKEN = 20469;
  
  public static final int ELITE_VOID_ROBE_BROKEN = 20471;
  
  public static final int VOID_KNIGHT_MACE_BROKEN = 20473;
  
  public static final int VOID_KNIGHT_GLOVES_BROKEN = 20475;
  
  public static final int VOID_MAGE_HELM_BROKEN = 20477;
  
  public static final int VOID_RANGER_HELM_BROKEN = 20479;
  
  public static final int VOID_MELEE_HELM_BROKEN = 20481;
  
  public static final int DECORATIVE_SWORD_BROKEN = 20483;
  
  public static final int DECORATIVE_ARMOUR_BROKEN = 20485;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20487 = 20487;
  
  public static final int DECORATIVE_HELM_BROKEN = 20489;
  
  public static final int DECORATIVE_SHIELD_BROKEN = 20491;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20493 = 20493;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20495 = 20495;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20497 = 20497;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20499 = 20499;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20501 = 20501;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20503 = 20503;
  
  public static final int DECORATIVE_ARMOUR_BROKEN_20505 = 20505;
  
  public static final int FIGHTER_HAT_BROKEN = 20507;
  
  public static final int RANGER_HAT_BROKEN = 20509;
  
  public static final int HEALER_HAT_BROKEN = 20511;
  
  public static final int FIGHTER_TORSO_BROKEN = 20513;
  
  public static final int PENANCE_SKIRT_BROKEN = 20515;
  
  public static final int ELDER_CHAOS_TOP = 20517;
  
  public static final int ELDER_CHAOS_ROBE = 20520;
  
  public static final int CATALYTIC_RUNE_PACK = 20523;
  
  public static final int ELEMENTAL_RUNE_PACK = 20524;
  
  public static final int ADAMANT_ARROW_PACK = 20525;
  
  public static final int BLOODY_KEY = 20526;
  
  public static final int SURVIVAL_TOKEN = 20527;
  
  public static final int STASH_UNITS_EASY = 20532;
  
  public static final int STASH_UNITS_MEDIUM = 20533;
  
  public static final int STASH_UNITS_HARD = 20534;
  
  public static final int STASH_UNITS_ELITE = 20535;
  
  public static final int STASH_UNITS_MASTER = 20536;
  
  public static final int SARADOMIN_HALO_BROKEN = 20537;
  
  public static final int ZAMORAK_HALO_BROKEN = 20539;
  
  public static final int GUTHIX_HALO_BROKEN = 20541;
  
  public static final int REWARD_CASKET_ELITE = 20543;
  
  public static final int REWARD_CASKET_HARD = 20544;
  
  public static final int REWARD_CASKET_MEDIUM = 20545;
  
  public static final int REWARD_CASKET_EASY = 20546;
  
  public static final int MONKFISH_20547 = 20547;
  
  public static final int SUPER_ENERGY4_20548 = 20548;
  
  public static final int SUPER_ENERGY3_20549 = 20549;
  
  public static final int SUPER_ENERGY2_20550 = 20550;
  
  public static final int SUPER_ENERGY1_20551 = 20551;
  
  public static final int RUNE_BATTLEAXE_20552 = 20552;
  
  public static final int BEGINNER_WAND_20553 = 20553;
  
  public static final int TOKTZXILAK_20554 = 20554;
  
  public static final int RUNE_2H_SWORD_20555 = 20555;
  
  public static final int APPRENTICE_WAND_20556 = 20556;
  
  public static final int GRANITE_MAUL_20557 = 20557;
  
  public static final int MAGIC_SHORTBOW_20558 = 20558;
  
  public static final int DRAGON_2H_SWORD_20559 = 20559;
  
  public static final int MASTER_WAND_20560 = 20560;
  
  public static final int ADAMANT_FULL_HELM_20561 = 20561;
  
  public static final int MYSTIC_HAT_20562 = 20562;
  
  public static final int PROSELYTE_SALLET_20563 = 20563;
  
  public static final int PROSELYTE_HAUBERK_20564 = 20564;
  
  public static final int PROSELYTE_CUISSE_20565 = 20565;
  
  public static final int RED_DHIDE_BODY_20566 = 20566;
  
  public static final int RED_DHIDE_CHAPS_20567 = 20567;
  
  public static final int SPLITBARK_HELM_20568 = 20568;
  
  public static final int WARRIOR_HELM_20571 = 20571;
  
  public static final int ARCHER_HELM_20572 = 20572;
  
  public static final int FARSEER_HELM_20573 = 20573;
  
  public static final int INFINITY_TOP_20574 = 20574;
  
  public static final int INFINITY_BOTTOMS_20575 = 20575;
  
  public static final int _3RD_AGE_ROBE_TOP_20576 = 20576;
  
  public static final int _3RD_AGE_ROBE_20577 = 20577;
  
  public static final int CLIMBING_BOOTS_20578 = 20578;
  
  public static final int MYSTIC_BOOTS_20579 = 20579;
  
  public static final int SNAKESKIN_BOOTS_20580 = 20580;
  
  public static final int MITHRIL_GLOVES_20581 = 20581;
  
  public static final int ADAMANT_GLOVES_20582 = 20582;
  
  public static final int RUNE_GLOVES_20583 = 20583;
  
  public static final int AMULET_OF_ACCURACY_20584 = 20584;
  
  public static final int AMULET_OF_POWER_20585 = 20585;
  
  public static final int AMULET_OF_GLORY_20586 = 20586;
  
  public static final int ROPE_20587 = 20587;
  
  public static final int STALE_BAGUETTE = 20590;
  
  public static final int ARMADYL_GODSWORD_20593 = 20593;
  
  public static final int BANK_FILLER = 20594;
  
  public static final int ELDER_CHAOS_HOOD = 20595;
  
  public static final int AHRIMS_ROBETOP_20598 = 20598;
  
  public static final int AHRIMS_ROBESKIRT_20599 = 20599;
  
  public static final int RUNE_ARROW_20600 = 20600;
  
  public static final int WOODEN_TABLE = 20601;
  
  public static final int WAXWOOD_BED = 20602;
  
  public static final int CARPET = 20603;
  
  public static final int WOODEN_STOOL = 20604;
  
  public static final int WOODEN_CHAIR_20605 = 20605;
  
  public static final int RUNE_ARROW_PACK = 20607;
  
  public static final int BLOODIER_KEY = 20608;
  
  public static final int FAIRY_ENCHANTMENT = 20609;
  
  public static final int ANCIENT_SIGNET = 20611;
  
  public static final int LUNAR_SIGNET = 20613;
  
  public static final int ARCEUUS_SIGNET = 20615;
  
  public static final int ANCIENT_ALTAR = 20617;
  
  public static final int LUNAR_ALTAR = 20618;
  
  public static final int DARK_ALTAR = 20619;
  
  public static final int OCCULT_ALTAR = 20620;
  
  public static final int OCCULT_ALTAR_20621 = 20621;
  
  public static final int OCCULT_ALTAR_20622 = 20622;
  
  public static final int MAHOGANY_ADVENTURE_LOG = 20623;
  
  public static final int GILDED_ADVENTURE_LOG = 20624;
  
  public static final int MARBLE_ADVENTURE_LOG = 20625;
  
  public static final int BASIC_JEWELLERY_BOX = 20626;
  
  public static final int FANCY_JEWELLERY_BOX = 20627;
  
  public static final int ORNATE_JEWELLERY_BOX = 20628;
  
  public static final int BOSS_LAIR_DISPLAY = 20629;
  
  public static final int MOUNTED_EMBLEM = 20630;
  
  public static final int MOUNTED_COINS = 20631;
  
  public static final int CAPE_HANGER = 20632;
  
  public static final int QUEST_LIST = 20633;
  
  public static final int TIP_JAR = 20634;
  
  public static final int SPIRIT_TREE_20635 = 20635;
  
  public static final int FAIRY_RING = 20636;
  
  public static final int SPIRIT_TREE__FAIRY_RING = 20637;
  
  public static final int TOPIARY_BUSH = 20638;
  
  public static final int RESTORATION_POOL = 20639;
  
  public static final int REVITALISATION_POOL = 20640;
  
  public static final int REJUVENATION_POOL = 20641;
  
  public static final int FANCY_REJUVENATION_POOL = 20642;
  
  public static final int ORNATE_REJUVENATION_POOL = 20643;
  
  public static final int ZEN_THEME = 20644;
  
  public static final int OTHERWORLDLY_THEME = 20645;
  
  public static final int VOLCANIC_THEME = 20646;
  
  public static final int REDWOOD_FENCE = 20647;
  
  public static final int OBSIDIAN_FENCE = 20648;
  
  public static final int TEAK_GARDEN_BENCH = 20649;
  
  public static final int GNOME_BENCH = 20650;
  
  public static final int MARBLE_DECORATIVE_BENCH = 20651;
  
  public static final int OBSIDIAN_DECORATIVE_BENCH = 20652;
  
  public static final int SUPERIOR_GARDEN = 20653;
  
  public static final int ACHIEVEMENT_GALLERY = 20654;
  
  public static final int RING_OF_SUFFERING_R = 20655;
  
  public static final int RING_OF_SUFFERING_RI = 20657;
  
  public static final int GIANT_SQUIRREL = 20659;
  
  public static final int TANGLEROOT = 20661;
  
  public static final int ROCKY = 20663;
  
  public static final int RIFT_GUARDIAN = 20665;
  
  public static final int RIFT_GUARDIAN_20667 = 20667;
  
  public static final int RIFT_GUARDIAN_20669 = 20669;
  
  public static final int RIFT_GUARDIAN_20671 = 20671;
  
  public static final int RIFT_GUARDIAN_20673 = 20673;
  
  public static final int RIFT_GUARDIAN_20675 = 20675;
  
  public static final int RIFT_GUARDIAN_20677 = 20677;
  
  public static final int RIFT_GUARDIAN_20679 = 20679;
  
  public static final int RIFT_GUARDIAN_20681 = 20681;
  
  public static final int RIFT_GUARDIAN_20683 = 20683;
  
  public static final int RIFT_GUARDIAN_20685 = 20685;
  
  public static final int RIFT_GUARDIAN_20687 = 20687;
  
  public static final int RIFT_GUARDIAN_20689 = 20689;
  
  public static final int RIFT_GUARDIAN_20691 = 20691;
  
  public static final int PHOENIX = 20693;
  
  public static final int BRUMA_ROOT = 20695;
  
  public static final int BRUMA_KINDLING = 20696;
  
  public static final int REJUVENATION_POTION_UNF = 20697;
  
  public static final int BRUMA_HERB = 20698;
  
  public static final int REJUVENATION_POTION_4 = 20699;
  
  public static final int REJUVENATION_POTION_3 = 20700;
  
  public static final int REJUVENATION_POTION_2 = 20701;
  
  public static final int REJUVENATION_POTION_1 = 20702;
  
  public static final int SUPPLY_CRATE = 20703;
  
  public static final int PYROMANCER_GARB = 20704;
  
  public static final int PYROMANCER_ROBE = 20706;
  
  public static final int PYROMANCER_HOOD = 20708;
  
  public static final int PYROMANCER_BOOTS = 20710;
  
  public static final int WARM_GLOVES = 20712;
  
  public static final int TOME_OF_FIRE = 20714;
  
  public static final int TOME_OF_FIRE_EMPTY = 20716;
  
  public static final int BURNT_PAGE = 20718;
  
  public static final int BRUMA_TORCH = 20720;
  
  public static final int EMERALD_LANTERN_20722 = 20722;
  
  public static final int IMBUED_HEART = 20724;
  
  public static final int LEAFBLADED_BATTLEAXE = 20727;
  
  public static final int MIST_BATTLESTAFF = 20730;
  
  public static final int MYSTIC_MIST_STAFF = 20733;
  
  public static final int DUST_BATTLESTAFF = 20736;
  
  public static final int MYSTIC_DUST_STAFF = 20739;
  
  public static final int EMPTY_JUG_PACK = 20742;
  
  public static final int COMBAT_DUMMY = 20745;
  
  public static final int UNDEAD_COMBAT_DUMMY = 20746;
  
  public static final int BOLOGAS_BLESSING = 20747;
  
  public static final int ZAMORAKS_GRAPES = 20749;
  
  public static final int ZAMORAKS_UNFERMENTED_WINE = 20752;
  
  public static final int GIANT_KEY = 20754;
  
  public static final int HILL_GIANT_CLUB = 20756;
  
  public static final int ARDOUGNE_MAX_CAPE = 20760;
  
  public static final int ARDOUGNE_MAX_HOOD = 20764;
  
  public static final int MANOR_KEY = 20766;
  
  public static final int RUBY_KEY = 20767;
  
  public static final int EMERALD_KEY = 20768;
  
  public static final int SAPPHIRE_KEY = 20769;
  
  public static final int NOTES = 20770;
  
  public static final int NOTES_20771 = 20771;
  
  public static final int NOTES_20772 = 20772;
  
  public static final int BANSHEE_MASK = 20773;
  
  public static final int BANSHEE_TOP = 20775;
  
  public static final int BANSHEE_ROBE = 20777;
  
  public static final int HUNTING_KNIFE = 20779;
  
  public static final int KILLERS_KNIFE = 20781;
  
  public static final int BANDOS_GODSWORD_20782 = 20782;
  
  public static final int DRAGON_CLAWS_20784 = 20784;
  
  public static final int DRAGON_WARHAMMER_20785 = 20785;
  
  public static final int RING_OF_WEALTH_I5 = 20786;
  
  public static final int RING_OF_WEALTH_I4 = 20787;
  
  public static final int RING_OF_WEALTH_I3 = 20788;
  
  public static final int RING_OF_WEALTH_I2 = 20789;
  
  public static final int RING_OF_WEALTH_I1 = 20790;
  
  public static final int EXTRA_SUPPLY_CRATE = 20791;
  
  public static final int HARDCORE_IRONMAN_HELM = 20792;
  
  public static final int HARDCORE_IRONMAN_PLATEBODY = 20794;
  
  public static final int HARDCORE_IRONMAN_PLATELEGS = 20796;
  
  public static final int SMELLY_JOURNAL = 20798;
  
  public static final int KINDLING_20799 = 20799;
  
  public static final int EMPTY_GOURD_VIAL = 20800;
  
  public static final int WATERFILLED_GOURD_VIAL = 20801;
  
  public static final int HEALER_ICON_20802 = 20802;
  
  public static final int SNOW_GLOBE = 20832;
  
  public static final int SACK_OF_PRESENTS = 20834;
  
  public static final int GIANT_PRESENT = 20836;
  
  public static final int CORRUPTED_HELM = 20838;
  
  public static final int CORRUPTED_PLATEBODY = 20840;
  
  public static final int CORRUPTED_PLATELEGS = 20842;
  
  public static final int CORRUPTED_PLATESKIRT = 20844;
  
  public static final int CORRUPTED_KITESHIELD = 20846;
  
  public static final int DRAGON_THROWNAXE = 20849;
  
  public static final int OLMLET = 20851;
  
  public static final int CAVE_WORMS = 20853;
  
  public static final int BURNT_FISH_20854 = 20854;
  
  public static final int RAW_PYSK_FISH_0 = 20855;
  
  public static final int PYSK_FISH_0 = 20856;
  
  public static final int RAW_SUPHI_FISH_1 = 20857;
  
  public static final int SUPHI_FISH_1 = 20858;
  
  public static final int RAW_LECKISH_FISH_2 = 20859;
  
  public static final int LECKISH_FISH_2 = 20860;
  
  public static final int RAW_BRAWK_FISH_3 = 20861;
  
  public static final int BRAWK_FISH_3 = 20862;
  
  public static final int RAW_MYCIL_FISH_4 = 20863;
  
  public static final int MYCIL_FISH_4 = 20864;
  
  public static final int RAW_ROQED_FISH_5 = 20865;
  
  public static final int ROQED_FISH_5 = 20866;
  
  public static final int RAW_KYREN_FISH_6 = 20867;
  
  public static final int KYREN_FISH_6 = 20868;
  
  public static final int BURNT_BAT = 20869;
  
  public static final int RAW_GUANIC_BAT_0 = 20870;
  
  public static final int GUANIC_BAT_0 = 20871;
  
  public static final int RAW_PRAEL_BAT_1 = 20872;
  
  public static final int PRAEL_BAT_1 = 20873;
  
  public static final int RAW_GIRAL_BAT_2 = 20874;
  
  public static final int GIRAL_BAT_2 = 20875;
  
  public static final int RAW_PHLUXIA_BAT_3 = 20876;
  
  public static final int PHLUXIA_BAT_3 = 20877;
  
  public static final int RAW_KRYKET_BAT_4 = 20878;
  
  public static final int KRYKET_BAT_4 = 20879;
  
  public static final int RAW_MURNG_BAT_5 = 20880;
  
  public static final int MURNG_BAT_5 = 20881;
  
  public static final int RAW_PSYKK_BAT_6 = 20882;
  
  public static final int PSYKK_BAT_6 = 20883;
  
  public static final int KEYSTONE_CRYSTAL = 20884;
  
  public static final int CAVERN_GRUBS = 20885;
  
  public static final int CREATURE_KEEPERS_JOURNAL = 20886;
  
  public static final int NISTIRIOS_MANIFESTO = 20888;
  
  public static final int TEKTONS_JOURNAL = 20890;
  
  public static final int MEDIVAEMIA_BLOSSOM = 20892;
  
  public static final int TRANSDIMENSIONAL_NOTES = 20893;
  
  public static final int VANGUARD_JUDGEMENT = 20895;
  
  public static final int HOUNDMASTERS_DIARY = 20897;
  
  public static final int DARK_JOURNAL = 20899;
  
  public static final int GRIMY_NOXIFER = 20901;
  
  public static final int NOXIFER = 20902;
  
  public static final int NOXIFER_SEED = 20903;
  
  public static final int GRIMY_GOLPAR = 20904;
  
  public static final int GOLPAR = 20905;
  
  public static final int GOLPAR_SEED = 20906;
  
  public static final int GRIMY_BUCHU_LEAF = 20907;
  
  public static final int BUCHU_LEAF = 20908;
  
  public static final int BUCHU_SEED = 20909;
  
  public static final int STINKHORN_MUSHROOM = 20910;
  
  public static final int ENDARKENED_JUICE = 20911;
  
  public static final int CICELY = 20912;
  
  public static final int ELDER_1 = 20913;
  
  public static final int ELDER_2 = 20914;
  
  public static final int ELDER_3 = 20915;
  
  public static final int ELDER_4 = 20916;
  
  public static final int ELDER_POTION_1 = 20917;
  
  public static final int ELDER_POTION_2 = 20918;
  
  public static final int ELDER_POTION_3 = 20919;
  
  public static final int ELDER_POTION_4 = 20920;
  
  public static final int ELDER_1_20921 = 20921;
  
  public static final int ELDER_2_20922 = 20922;
  
  public static final int ELDER_3_20923 = 20923;
  
  public static final int ELDER_4_20924 = 20924;
  
  public static final int TWISTED_1 = 20925;
  
  public static final int TWISTED_2 = 20926;
  
  public static final int TWISTED_3 = 20927;
  
  public static final int TWISTED_4 = 20928;
  
  public static final int TWISTED_POTION_1 = 20929;
  
  public static final int TWISTED_POTION_2 = 20930;
  
  public static final int TWISTED_POTION_3 = 20931;
  
  public static final int TWISTED_POTION_4 = 20932;
  
  public static final int TWISTED_1_20933 = 20933;
  
  public static final int TWISTED_2_20934 = 20934;
  
  public static final int TWISTED_3_20935 = 20935;
  
  public static final int TWISTED_4_20936 = 20936;
  
  public static final int KODAI_1 = 20937;
  
  public static final int KODAI_2 = 20938;
  
  public static final int KODAI_3 = 20939;
  
  public static final int KODAI_4 = 20940;
  
  public static final int KODAI_POTION_1 = 20941;
  
  public static final int KODAI_POTION_2 = 20942;
  
  public static final int KODAI_POTION_3 = 20943;
  
  public static final int KODAI_POTION_4 = 20944;
  
  public static final int KODAI_1_20945 = 20945;
  
  public static final int KODAI_2_20946 = 20946;
  
  public static final int KODAI_3_20947 = 20947;
  
  public static final int KODAI_4_20948 = 20948;
  
  public static final int REVITALISATION_1 = 20949;
  
  public static final int REVITALISATION_2 = 20950;
  
  public static final int REVITALISATION_3 = 20951;
  
  public static final int REVITALISATION_4 = 20952;
  
  public static final int REVITALISATION_POTION_1 = 20953;
  
  public static final int REVITALISATION_POTION_2 = 20954;
  
  public static final int REVITALISATION_POTION_3 = 20955;
  
  public static final int REVITALISATION_POTION_4 = 20956;
  
  public static final int REVITALISATION_1_20957 = 20957;
  
  public static final int REVITALISATION_2_20958 = 20958;
  
  public static final int REVITALISATION_3_20959 = 20959;
  
  public static final int REVITALISATION_4_20960 = 20960;
  
  public static final int PRAYER_ENHANCE_1 = 20961;
  
  public static final int PRAYER_ENHANCE_2 = 20962;
  
  public static final int PRAYER_ENHANCE_3 = 20963;
  
  public static final int PRAYER_ENHANCE_4 = 20964;
  
  public static final int PRAYER_ENHANCE_1_20965 = 20965;
  
  public static final int PRAYER_ENHANCE_2_20966 = 20966;
  
  public static final int PRAYER_ENHANCE_3_20967 = 20967;
  
  public static final int PRAYER_ENHANCE_4_20968 = 20968;
  
  public static final int PRAYER_ENHANCE_1_20969 = 20969;
  
  public static final int PRAYER_ENHANCE_2_20970 = 20970;
  
  public static final int PRAYER_ENHANCE_3_20971 = 20971;
  
  public static final int PRAYER_ENHANCE_4_20972 = 20972;
  
  public static final int XERICS_AID_1 = 20973;
  
  public static final int XERICS_AID_2 = 20974;
  
  public static final int XERICS_AID_3 = 20975;
  
  public static final int XERICS_AID_4 = 20976;
  
  public static final int XERICS_AID_1_20977 = 20977;
  
  public static final int XERICS_AID_2_20978 = 20978;
  
  public static final int XERICS_AID_3_20979 = 20979;
  
  public static final int XERICS_AID_4_20980 = 20980;
  
  public static final int XERICS_AID_1_20981 = 20981;
  
  public static final int XERICS_AID_2_20982 = 20982;
  
  public static final int XERICS_AID_3_20983 = 20983;
  
  public static final int XERICS_AID_4_20984 = 20984;
  
  public static final int OVERLOAD_1_20985 = 20985;
  
  public static final int OVERLOAD_2_20986 = 20986;
  
  public static final int OVERLOAD_3_20987 = 20987;
  
  public static final int OVERLOAD_4_20988 = 20988;
  
  public static final int OVERLOAD_1_20989 = 20989;
  
  public static final int OVERLOAD_2_20990 = 20990;
  
  public static final int OVERLOAD_3_20991 = 20991;
  
  public static final int OVERLOAD_4_20992 = 20992;
  
  public static final int OVERLOAD_1_20993 = 20993;
  
  public static final int OVERLOAD_2_20994 = 20994;
  
  public static final int OVERLOAD_3_20995 = 20995;
  
  public static final int OVERLOAD_4_20996 = 20996;
  
  public static final int TWISTED_BOW = 20997;
  
  public static final int TWISTED_BUCKLER = 21000;
  
  public static final int ELDER_MAUL = 21003;
  
  public static final int KODAI_WAND = 21006;
  
  public static final int DRAGON_SWORD = 21009;
  
  public static final int DRAGON_HUNTER_CROSSBOW = 21012;
  
  public static final int DINHS_BULWARK = 21015;
  
  public static final int ANCESTRAL_HAT = 21018;
  
  public static final int ANCESTRAL_ROBE_TOP = 21021;
  
  public static final int ANCESTRAL_ROBE_BOTTOM = 21024;
  
  public static final int DARK_RELIC = 21027;
  
  public static final int DRAGON_HARPOON = 21028;
  
  public static final int INFERNAL_HARPOON = 21031;
  
  public static final int INFERNAL_HARPOON_UNCHARGED = 21033;
  
  public static final int DEXTEROUS_PRAYER_SCROLL = 21034;
  
  public static final int MALLIGNUM_ROOT_PLANK = 21036;
  
  public static final int SMALL_STORAGE_UNIT = 21037;
  
  public static final int MEDIUM_STORAGE_UNIT = 21038;
  
  public static final int LARGE_STORAGE_UNIT = 21039;
  
  public static final int MEDIUM_STORAGE_UNIT_21040 = 21040;
  
  public static final int LARGE_STORAGE_UNIT_21041 = 21041;
  
  public static final int LARGE_STORAGE_UNIT_21042 = 21042;
  
  public static final int KODAI_INSIGNIA = 21043;
  
  public static final int ANCIENT_TABLET = 21046;
  
  public static final int TORN_PRAYER_SCROLL = 21047;
  
  public static final int ANCESTRAL_ROBES_SET = 21049;
  
  public static final int MANOR_KEY_21052 = 21052;
  
  public static final int RUBY_KEY_21053 = 21053;
  
  public static final int EMERALD_KEY_21054 = 21054;
  
  public static final int SAPPHIRE_KEY_21055 = 21055;
  
  public static final int NOTES_21056 = 21056;
  
  public static final int NOTES_21057 = 21057;
  
  public static final int NOTES_21058 = 21058;
  
  public static final int KILLERS_KNIFE_21059 = 21059;
  
  public static final int BANDOS_GODSWORD_21060 = 21060;
  
  public static final int GRACEFUL_HOOD_21061 = 21061;
  
  public static final int GRACEFUL_HOOD_21063 = 21063;
  
  public static final int GRACEFUL_CAPE_21064 = 21064;
  
  public static final int GRACEFUL_CAPE_21066 = 21066;
  
  public static final int GRACEFUL_TOP_21067 = 21067;
  
  public static final int GRACEFUL_TOP_21069 = 21069;
  
  public static final int GRACEFUL_LEGS_21070 = 21070;
  
  public static final int GRACEFUL_LEGS_21072 = 21072;
  
  public static final int GRACEFUL_GLOVES_21073 = 21073;
  
  public static final int GRACEFUL_GLOVES_21075 = 21075;
  
  public static final int GRACEFUL_BOOTS_21076 = 21076;
  
  public static final int GRACEFUL_BOOTS_21078 = 21078;
  
  public static final int ARCANE_PRAYER_SCROLL = 21079;
  
  public static final int OPAL_RING = 21081;
  
  public static final int JADE_RING = 21084;
  
  public static final int TOPAZ_RING = 21087;
  
  public static final int OPAL_NECKLACE = 21090;
  
  public static final int JADE_NECKLACE = 21093;
  
  public static final int TOPAZ_NECKLACE = 21096;
  
  public static final int OPAL_AMULET_U = 21099;
  
  public static final int JADE_AMULET_U = 21102;
  
  public static final int TOPAZ_AMULET_U = 21105;
  
  public static final int OPAL_AMULET = 21108;
  
  public static final int JADE_AMULET = 21111;
  
  public static final int TOPAZ_AMULET = 21114;
  
  public static final int OPAL_BRACELET = 21117;
  
  public static final int JADE_BRACELET = 21120;
  
  public static final int TOPAZ_BRACELET = 21123;
  
  public static final int RING_OF_PURSUIT = 21126;
  
  public static final int RING_OF_RETURNING5 = 21129;
  
  public static final int RING_OF_RETURNING4 = 21132;
  
  public static final int RING_OF_RETURNING3 = 21134;
  
  public static final int RING_OF_RETURNING2 = 21136;
  
  public static final int RING_OF_RETURNING1 = 21138;
  
  public static final int EFARITAYS_AID = 21140;
  
  public static final int DODGY_NECKLACE = 21143;
  
  public static final int NECKLACE_OF_PASSAGE5 = 21146;
  
  public static final int NECKLACE_OF_PASSAGE4 = 21149;
  
  public static final int NECKLACE_OF_PASSAGE3 = 21151;
  
  public static final int NECKLACE_OF_PASSAGE2 = 21153;
  
  public static final int NECKLACE_OF_PASSAGE1 = 21155;
  
  public static final int NECKLACE_OF_FAITH = 21157;
  
  public static final int AMULET_OF_BOUNTY = 21160;
  
  public static final int AMULET_OF_CHEMISTRY = 21163;
  
  public static final int BURNING_AMULET5 = 21166;
  
  public static final int BURNING_AMULET4 = 21169;
  
  public static final int BURNING_AMULET3 = 21171;
  
  public static final int BURNING_AMULET2 = 21173;
  
  public static final int BURNING_AMULET1 = 21175;
  
  public static final int EXPEDITIOUS_BRACELET = 21177;
  
  public static final int FLAMTAER_BRACELET = 21180;
  
  public static final int BRACELET_OF_SLAUGHTER = 21183;
  
  public static final int FIRE_MAX_CAPE_21186 = 21186;
  
  public static final int ROCK_GOLEM_21187 = 21187;
  
  public static final int ROCK_GOLEM_21188 = 21188;
  
  public static final int ROCK_GOLEM_21189 = 21189;
  
  public static final int ROCK_GOLEM_21190 = 21190;
  
  public static final int ROCK_GOLEM_21191 = 21191;
  
  public static final int ROCK_GOLEM_21192 = 21192;
  
  public static final int ROCK_GOLEM_21193 = 21193;
  
  public static final int ROCK_GOLEM_21194 = 21194;
  
  public static final int ROCK_GOLEM_21195 = 21195;
  
  public static final int ROCK_GOLEM_21196 = 21196;
  
  public static final int ROCK_GOLEM_21197 = 21197;
  
  public static final int LAVA_BATTLESTAFF_21198 = 21198;
  
  public static final int MYSTIC_LAVA_STAFF_21200 = 21200;
  
  public static final int LAVA_STAFF_UPGRADE_KIT = 21202;
  
  public static final int ELDER_MAUL_21205 = 21205;
  
  public static final int DRAGON_SWORD_21206 = 21206;
  
  public static final int DRAGON_THROWNAXE_21207 = 21207;
  
  public static final int INVITATION_LIST = 21208;
  
  public static final int BIRTHDAY_BALLOONS = 21209;
  
  public static final int _4TH_BIRTHDAY_HAT = 21211;
  
  public static final int SERVANTS_MONEY_BAG = 21213;
  
  public static final int EASTER_EGG_HELM = 21214;
  
  public static final int FRUITY_EASTER_EGG = 21216;
  
  public static final int FRESH_EASTER_EGG = 21217;
  
  public static final int BITTER_EASTER_EGG = 21218;
  
  public static final int EARTHY_EASTER_EGG = 21219;
  
  public static final int SPICY_EASTER_EGG = 21220;
  
  public static final int MEATY_EASTER_EGG = 21221;
  
  public static final int SALTED_EASTER_EGG = 21222;
  
  public static final int RICH_EASTER_EGG = 21223;
  
  public static final int FLUFFY_EASTER_EGG = 21224;
  
  public static final int SMOKED_EASTER_EGG = 21225;
  
  public static final int FISHY_EASTER_EGG = 21226;
  
  public static final int CRUNCHY_EASTER_EGG = 21227;
  
  public static final int FRUITY_CHOCOLATE_MIX = 21228;
  
  public static final int FRESH_CHOCOLATE_MIX = 21229;
  
  public static final int BITTER_CHOCOLATE_MIX = 21230;
  
  public static final int EARTHY_CHOCOLATE_MIX = 21231;
  
  public static final int SPICY_CHOCOLATE_MIX = 21232;
  
  public static final int MEATY_CHOCOLATE_MIX = 21233;
  
  public static final int SALTED_CHOCOLATE_MIX = 21234;
  
  public static final int RICH_CHOCOLATE_MIX = 21235;
  
  public static final int FLUFFY_CHOCOLATE_MIX = 21236;
  
  public static final int SMOKED_CHOCOLATE_MIX = 21237;
  
  public static final int FISHY_CHOCOLATE_MIX = 21238;
  
  public static final int CRUNCHY_CHOCOLATE_MIX = 21239;
  
  public static final int WESTER_BANANA = 21240;
  
  public static final int WESTER_PAPAYA = 21241;
  
  public static final int WESTER_LEMON = 21242;
  
  public static final int BUCKET_OF_WESTER_SAND = 21243;
  
  public static final int WESTER_SPICES = 21244;
  
  public static final int BEEF_FILLET = 21245;
  
  public static final int SEA_SALT = 21246;
  
  public static final int GOLD_FRAGMENT = 21247;
  
  public static final int FLUFFY_FEATHERS = 21248;
  
  public static final int WESTER_FISH = 21249;
  
  public static final int ROCK_21250 = 21250;
  
  public static final int WESTER_CHOCOLATE = 21251;
  
  public static final int EGG_MOULD = 21252;
  
  public static final int FARMERS_STRAWHAT_21253 = 21253;
  
  public static final int FARMERS_STRAWHAT_21254 = 21254;
  
  public static final int SLAYERS_STAFF_E = 21255;
  
  public static final int SLAYERS_ENCHANTMENT = 21257;
  
  public static final int ENCHANTED_SCROLL = 21259;
  
  public static final int ENCHANTED_QUILL = 21260;
  
  public static final int MYSTERIOUS_ORB = 21261;
  
  public static final int ANTIQUE_LAMP_21262 = 21262;
  
  public static final int COPPERS_CRIMSON_COLLAR = 21263;
  
  public static final int PURPLE_SLAYER_HELMET = 21264;
  
  public static final int PURPLE_SLAYER_HELMET_I = 21266;
  
  public static final int SLAYER_RING_ETERNAL = 21268;
  
  public static final int ETERNAL_GEM = 21270;
  
  public static final int SKOTOS = 21273;
  
  public static final int DARK_CLAW = 21275;
  
  public static final int SKULL_SCEPTRE_I = 21276;
  
  public static final int TZHAARHUR = 21278;
  
  public static final int OBSIDIAN_ARMOUR_SET = 21279;
  
  public static final int INFERNAL_MAX_HOOD = 21282;
  
  public static final int INFERNAL_MAX_CAPE = 21284;
  
  public static final int INFERNAL_MAX_CAPE_21285 = 21285;
  
  public static final int INFERNAL_CAPE_BROKEN = 21287;
  
  public static final int INFERNAL_MAX_CAPE_BROKEN = 21289;
  
  public static final int JALNIBREK = 21291;
  
  public static final int INFERNAL_EEL = 21293;
  
  public static final int INFERNAL_CAPE = 21295;
  
  public static final int INFERNAL_CAPE_21297 = 21297;
  
  public static final int OBSIDIAN_HELMET = 21298;
  
  public static final int OBSIDIAN_PLATEBODY = 21301;
  
  public static final int OBSIDIAN_PLATELEGS = 21304;
  
  public static final int ROGUES_EQUIPMENT_CRATE = 21307;
  
  public static final int RED_RAINBOW_STRAND = 21308;
  
  public static final int ORANGE_RAINBOW_STRAND = 21309;
  
  public static final int YELLOW_RAINBOW_STRAND = 21310;
  
  public static final int GREEN_RAINBOW_STRAND = 21311;
  
  public static final int BLUE_RAINBOW_STRAND = 21312;
  
  public static final int PURPLE_RAINBOW_STRAND = 21313;
  
  public static final int RAINBOW_SCARF = 21314;
  
  public static final int AMETHYST_BROAD_BOLTS = 21316;
  
  public static final int AMETHYST_JAVELIN = 21318;
  
  public static final int AMETHYST_JAVELINP = 21320;
  
  public static final int AMETHYST_JAVELINP_21322 = 21322;
  
  public static final int AMETHYST_JAVELINP_21324 = 21324;
  
  public static final int AMETHYST_ARROW = 21326;
  
  public static final int AMETHYST_FIRE_ARROW = 21328;
  
  public static final int AMETHYST_FIRE_ARROW_LIT = 21330;
  
  public static final int AMETHYST_ARROWP = 21332;
  
  public static final int AMETHYST_ARROWP_21334 = 21334;
  
  public static final int AMETHYST_ARROWP_21336 = 21336;
  
  public static final int AMETHYST_BOLT_TIPS = 21338;
  
  public static final int ROCK_GOLEM_21340 = 21340;
  
  public static final int UNIDENTIFIED_MINERALS = 21341;
  
  public static final int MINING_GLOVES = 21343;
  
  public static final int SUPERIOR_MINING_GLOVES = 21345;
  
  public static final int AMETHYST = 21347;
  
  public static final int AMETHYST_ARROWTIPS = 21350;
  
  public static final int AMETHYST_JAVELIN_HEADS = 21352;
  
  public static final int HAND_FAN = 21354;
  
  public static final int MINNOW = 21356;
  
  public static final int ROCK_GOLEM_21358 = 21358;
  
  public static final int ROCK_GOLEM_21359 = 21359;
  
  public static final int ROCK_GOLEM_21360 = 21360;
  
  public static final int MASTER_SCROLL_BOOK_EMPTY = 21387;
  
  public static final int MASTER_SCROLL_BOOK = 21389;
  
  public static final int BRUTAL_BLACK_DRAGON = 21391;
  
  public static final int EXPERT_MINING_GLOVES = 21392;
  
  public static final int KARAMBWANJI = 21394;
  
  public static final int CLAN_WARS_CAPE_21396 = 21396;
  
  public static final int CLAN_WARS_CAPE_21397 = 21397;
  
  public static final int CLAN_WARS_CAPE_21398 = 21398;
  
  public static final int CLAN_WARS_CAPE_21399 = 21399;
  
  public static final int CLAN_WARS_CAPE_21400 = 21400;
  
  public static final int CLAN_WARS_CAPE_21401 = 21401;
  
  public static final int CLAN_WARS_CAPE_21402 = 21402;
  
  public static final int CLAN_WARS_CAPE_21403 = 21403;
  
  public static final int CLAN_WARS_CAPE_21404 = 21404;
  
  public static final int CLAN_WARS_CAPE_21405 = 21405;
  
  public static final int CLAN_WARS_CAPE_21406 = 21406;
  
  public static final int CLAN_WARS_CAPE_21407 = 21407;
  
  public static final int CLAN_WARS_CAPE_21408 = 21408;
  
  public static final int CLAN_WARS_CAPE_21409 = 21409;
  
  public static final int CLAN_WARS_CAPE_21410 = 21410;
  
  public static final int CLAN_WARS_CAPE_21411 = 21411;
  
  public static final int CLAN_WARS_CAPE_21412 = 21412;
  
  public static final int CLAN_WARS_CAPE_21413 = 21413;
  
  public static final int CLAN_WARS_CAPE_21414 = 21414;
  
  public static final int CLAN_WARS_CAPE_21415 = 21415;
  
  public static final int CLAN_WARS_CAPE_21416 = 21416;
  
  public static final int CLAN_WARS_CAPE_21417 = 21417;
  
  public static final int CLAN_WARS_CAPE_21418 = 21418;
  
  public static final int CLAN_WARS_CAPE_21419 = 21419;
  
  public static final int CLAN_WARS_CAPE_21420 = 21420;
  
  public static final int CLAN_WARS_CAPE_21421 = 21421;
  
  public static final int CLAN_WARS_CAPE_21422 = 21422;
  
  public static final int CLAN_WARS_CAPE_21423 = 21423;
  
  public static final int CLAN_WARS_CAPE_21424 = 21424;
  
  public static final int CLAN_WARS_CAPE_21425 = 21425;
  
  public static final int CLAN_WARS_CAPE_21426 = 21426;
  
  public static final int CLAN_WARS_CAPE_21427 = 21427;
  
  public static final int WILDERNESS_CAPE = 21428;
  
  public static final int WILDERNESS_CAPE_21429 = 21429;
  
  public static final int WILDERNESS_CAPE_21430 = 21430;
  
  public static final int WILDERNESS_CAPE_21431 = 21431;
  
  public static final int WILDERNESS_CAPE_21432 = 21432;
  
  public static final int WILDERNESS_CHAMPION_AMULET = 21433;
  
  public static final int WILDERNESS_CAPE_21434 = 21434;
  
  public static final int WILDERNESS_CAPE_21435 = 21435;
  
  public static final int WILDERNESS_CAPE_21436 = 21436;
  
  public static final int WILDERNESS_CAPE_21437 = 21437;
  
  public static final int WILDERNESS_CAPE_21438 = 21438;
  
  public static final int CHAMPIONS_CAPE = 21439;
  
  public static final int PHARAOHS_SCEPTRE_21445 = 21445;
  
  public static final int PHARAOHS_SCEPTRE_21446 = 21446;
  
  public static final int TEAK_SEEDLING = 21469;
  
  public static final int MAHOGANY_SEEDLING = 21471;
  
  public static final int TEAK_SEEDLING_W = 21473;
  
  public static final int MAHOGANY_SEEDLING_W = 21475;
  
  public static final int TEAK_SAPLING = 21477;
  
  public static final int MAHOGANY_SAPLING = 21480;
  
  public static final int ULTRACOMPOST = 21483;
  
  public static final int TEAK_SEED = 21486;
  
  public static final int MAHOGANY_SEED = 21488;
  
  public static final int SEAWEED_SPORE = 21490;
  
  public static final int GIANT_SEAWEED = 21504;
  
  public static final int FOSSIL_ISLAND_WYVERN = 21507;
  
  public static final int FOSSIL_ISLAND_WYVERN_21508 = 21508;
  
  public static final int HERBI = 21509;
  
  public static final int HERBIBOAR = 21511;
  
  public static final int BIRD_HOUSE = 21512;
  
  public static final int OAK_BIRD_HOUSE = 21515;
  
  public static final int WILLOW_BIRD_HOUSE = 21518;
  
  public static final int TEAK_BIRD_HOUSE = 21521;
  
  public static final int CLUE_SCROLL_ELITE_21524 = 21524;
  
  public static final int CLUE_SCROLL_ELITE_21525 = 21525;
  
  public static final int CLUE_SCROLL_HARD_21526 = 21526;
  
  public static final int CLUE_SCROLL_HARD_21527 = 21527;
  
  public static final int SAWMILL_PROPOSAL = 21528;
  
  public static final int SAWMILL_AGREEMENT = 21529;
  
  public static final int BONE_CHARM = 21530;
  
  public static final int POTION_OF_SEALEGS = 21531;
  
  public static final int IRON_ORE_FRAGMENT = 21532;
  
  public static final int SILVER_ORE_FRAGMENT = 21533;
  
  public static final int COAL_FRAGMENT = 21534;
  
  public static final int GOLD_ORE_FRAGMENT = 21535;
  
  public static final int MITHRIL_ORE_FRAGMENT = 21536;
  
  public static final int ADAMANTITE_ORE_FRAGMENT = 21537;
  
  public static final int RUNITE_ORE_FRAGMENT = 21538;
  
  public static final int HEATPROOF_VESSEL = 21539;
  
  public static final int LARGE_ROCK = 21540;
  
  public static final int VOLCANIC_MINE_TELEPORT = 21541;
  
  public static final int CALCITE = 21543;
  
  public static final int PYROPHOSPHITE = 21545;
  
  public static final int SMALL_ENRICHED_BONE = 21547;
  
  public static final int MEDIUM_ENRICHED_BONE = 21549;
  
  public static final int LARGE_ENRICHED_BONE = 21551;
  
  public static final int RARE_ENRICHED_BONE = 21553;
  
  public static final int NUMULITE = 21555;
  
  public static final int UNIDENTIFIED_SMALL_FOSSIL = 21562;
  
  public static final int UNIDENTIFIED_MEDIUM_FOSSIL = 21564;
  
  public static final int UNIDENTIFIED_LARGE_FOSSIL = 21566;
  
  public static final int UNIDENTIFIED_RARE_FOSSIL = 21568;
  
  public static final int SMALL_FOSSILISED_LIMBS = 21570;
  
  public static final int SMALL_FOSSILISED_SPINE = 21572;
  
  public static final int SMALL_FOSSILISED_RIBS = 21574;
  
  public static final int SMALL_FOSSILISED_PELVIS = 21576;
  
  public static final int SMALL_FOSSILISED_SKULL = 21578;
  
  public static final int MEDIUM_FOSSILISED_LIMBS = 21580;
  
  public static final int MEDIUM_FOSSILISED_SPINE = 21582;
  
  public static final int MEDIUM_FOSSILISED_RIBS = 21584;
  
  public static final int MEDIUM_FOSSILISED_PELVIS = 21586;
  
  public static final int MEDIUM_FOSSILISED_SKULL = 21588;
  
  public static final int FOSSILISED_ROOTS = 21590;
  
  public static final int FOSSILISED_STUMP = 21592;
  
  public static final int FOSSILISED_BRANCH = 21594;
  
  public static final int FOSSILISED_LEAF = 21596;
  
  public static final int FOSSILISED_MUSHROOM = 21598;
  
  public static final int LARGE_FOSSILISED_LIMBS = 21600;
  
  public static final int LARGE_FOSSILISED_SPINE = 21602;
  
  public static final int LARGE_FOSSILISED_RIBS = 21604;
  
  public static final int LARGE_FOSSILISED_PELVIS = 21606;
  
  public static final int LARGE_FOSSILISED_SKULL = 21608;
  
  public static final int RARE_FOSSILISED_LIMBS = 21610;
  
  public static final int RARE_FOSSILISED_SPINE = 21612;
  
  public static final int RARE_FOSSILISED_RIBS = 21614;
  
  public static final int RARE_FOSSILISED_PELVIS = 21616;
  
  public static final int RARE_FOSSILISED_SKULL = 21618;
  
  public static final int RARE_FOSSILISED_TUSK = 21620;
  
  public static final int VOLCANIC_ASH = 21622;
  
  public static final int HOOP_SNAKE = 21624;
  
  public static final int SULLIUSCEP_CAP = 21626;
  
  public static final int ARCHAEOLOGISTS_DIARY = 21629;
  
  public static final int ANCIENT_DIARY = 21631;
  
  public static final int ANCIENT_WYVERN_SHIELD = 21633;
  
  public static final int ANCIENT_WYVERN_SHIELD_21634 = 21634;
  
  public static final int WYVERN_VISAGE = 21637;
  
  public static final int ANTIQUE_LAMP_21640 = 21640;
  
  public static final int ANTIQUE_LAMP_21641 = 21641;
  
  public static final int ANTIQUE_LAMP_21642 = 21642;
  
  public static final int GRANITE_BOOTS = 21643;
  
  public static final int GRANITE_LONGSWORD = 21646;
  
  public static final int MERFOLK_TRIDENT = 21649;
  
  public static final int DRIFT_NET = 21652;
  
  public static final int PUFFERFISH = 21655;
  
  public static final int MERMAIDS_TEAR = 21656;
  
  public static final int FOSSIL_ISLAND_NOTE_BOOK = 21662;
  
  public static final int SCRIBBLED_NOTE = 21664;
  
  public static final int PARTIAL_NOTE = 21666;
  
  public static final int ANCIENT_NOTE = 21668;
  
  public static final int ANCIENT_WRITINGS = 21670;
  
  public static final int EXPERIMENTAL_NOTE = 21672;
  
  public static final int PARAGRAPH_OF_TEXT = 21674;
  
  public static final int MUSTY_SMELLING_NOTE = 21676;
  
  public static final int HASTILY_SCRAWLED_NOTE = 21678;
  
  public static final int OLD_WRITING = 21680;
  
  public static final int SHORT_NOTE = 21682;
  
  public static final int UNCOOKED_MUSHROOM_PIE = 21684;
  
  public static final int HALF_A_MUSHROOM_PIE = 21687;
  
  public static final int MUSHROOM_PIE = 21690;
  
  public static final int BOWL_OF_FISH = 21693;
  
  public static final int RUNEFEST_SHIELD = 21695;
  
  public static final int ASH_COVERED_TOME = 21697;
  
  public static final int TZHAAR_AIR_RUNE_PACK = 21698;
  
  public static final int TZHAAR_WATER_RUNE_PACK = 21701;
  
  public static final int TZHAAR_EARTH_RUNE_PACK = 21704;
  
  public static final int TZHAAR_FIRE_RUNE_PACK = 21707;
  
  public static final int DEATH_NOTE = 21710;
  
  public static final int MURKY_POTION = 21711;
  
  public static final int SPECTRAL_POTION = 21712;
  
  public static final int TOMBERRIES = 21713;
  
  public static final int TATTERED_BOOK = 21714;
  
  public static final int NOTE_21715 = 21715;
  
  public static final int CARVED_GEM = 21716;
  
  public static final int TIME_BUBBLE = 21717;
  
  public static final int TRAIBORN_NOTE = 21718;
  
  public static final int JONAS_MASK = 21719;
  
  public static final int JONAS_MASK_21720 = 21720;
  
  public static final int DIVING_HELMET = 21722;
  
  public static final int DIVING_APPARATUS_21723 = 21723;
  
  public static final int BRITTLE_KEY = 21724;
  
  public static final int GRANITE_DUST = 21726;
  
  public static final int GRANITE_CANNONBALL = 21728;
  
  public static final int BLACK_TOURMALINE_CORE = 21730;
  
  public static final int GUARDIAN_BOOTS = 21733;
  
  public static final int GRANITE_GLOVES = 21736;
  
  public static final int GRANITE_RING = 21739;
  
  public static final int GRANITE_HAMMER = 21742;
  
  public static final int JAR_OF_STONE = 21745;
  
  public static final int NOON = 21748;
  
  public static final int MIDNIGHT = 21750;
  
  public static final int GRANITE_RING_I = 21752;
  
  public static final int ROCK_THROWNHAMMER = 21754;
  
  public static final int VARLAMORE_ENVOY = 21756;
  
  public static final int ROYAL_ACCORD_OF_TWILL = 21758;
  
  public static final int CERTIFICATE_21759 = 21759;
  
  public static final int KHAREDSTS_MEMOIRS = 21760;
  
  public static final int LUNCH_BY_THE_LANCALLIUMS = 21762;
  
  public static final int THE_FISHERS_FLUTE = 21764;
  
  public static final int HISTORY_AND_HEARSAY = 21766;
  
  public static final int JEWELLERY_OF_JUBILATION = 21768;
  
  public static final int A_DARK_DISPOSITION = 21770;
  
  public static final int SECRET_PAGE = 21772;
  
  public static final int LETTER_21774 = 21774;
  
  public static final int CERTIFICATE_21775 = 21775;
  
  public static final int IMBUED_SARADOMIN_MAX_CAPE = 21776;
  
  public static final int IMBUED_SARADOMIN_MAX_HOOD = 21778;
  
  public static final int IMBUED_ZAMORAK_MAX_CAPE = 21780;
  
  public static final int IMBUED_ZAMORAK_MAX_HOOD = 21782;
  
  public static final int IMBUED_GUTHIX_MAX_CAPE = 21784;
  
  public static final int IMBUED_GUTHIX_MAX_HOOD = 21786;
  
  public static final int OBELISK = 21788;
  
  public static final int IMBUED_SARADOMIN_CAPE = 21791;
  
  public static final int IMBUED_GUTHIX_CAPE = 21793;
  
  public static final int IMBUED_ZAMORAK_CAPE = 21795;
  
  public static final int JUSTICIARS_HAND = 21797;
  
  public static final int ENTS_ROOTS = 21798;
  
  public static final int DEMONS_HEART = 21799;
  
  public static final int ENCHANTED_SYMBOL = 21800;
  
  public static final int REVENANT_CAVE_TELEPORT = 21802;
  
  public static final int ANCIENT_CRYSTAL = 21804;
  
  public static final int ANCIENT_EMBLEM = 21807;
  
  public static final int ANCIENT_TOTEM = 21810;
  
  public static final int ANCIENT_STATUETTE = 21813;
  
  public static final int BRACELET_OF_ETHEREUM = 21816;
  
  public static final int BRACELET_OF_ETHEREUM_UNCHARGED = 21817;
  
  public static final int REVENANT_ETHER = 21820;
  
  public static final int OGRE_ARTEFACT_21837 = 21837;
  
  public static final int SHAMAN_MASK = 21838;
  
  public static final int SNOW_IMP_COSTUME_HEAD = 21841;
  
  public static final int SNOW_IMP_COSTUME_BODY = 21842;
  
  public static final int SNOW_IMP_COSTUME_LEGS = 21843;
  
  public static final int SNOW_IMP_COSTUME_TAIL = 21844;
  
  public static final int SNOW_IMP_COSTUME_GLOVES = 21845;
  
  public static final int SNOW_IMP_COSTUME_FEET = 21846;
  
  public static final int SNOW_IMP_COSTUME_HEAD_21847 = 21847;
  
  public static final int SNOW_IMP_COSTUME_BODY_21849 = 21849;
  
  public static final int SNOW_IMP_COSTUME_LEGS_21851 = 21851;
  
  public static final int SNOW_IMP_COSTUME_TAIL_21853 = 21853;
  
  public static final int SNOW_IMP_COSTUME_GLOVES_21855 = 21855;
  
  public static final int SNOW_IMP_COSTUME_FEET_21857 = 21857;
  
  public static final int WISE_OLD_MANS_SANTA_HAT = 21859;
  
  public static final int ENCHANTED_CURTAINS = 21861;
  
  public static final int ENCHANTED_SNOWY_CURTAINS = 21862;
  
  public static final int WISE_OLD_MANS_TELEPORT_TABLET = 21863;
  
  public static final int SNOW_SPRITE = 21864;
  
  public static final int FINE_MESH_NET = 21865;
  
  public static final int SANTA_SUIT = 21866;
  
  public static final int SANTA_SUIT_WET = 21867;
  
  public static final int SANTA_SUIT_DRY = 21868;
  
  public static final int LOGS_AND_KINDLING = 21869;
  
  public static final int PROMISSORY_NOTE_21870 = 21870;
  
  public static final int SANTAS_SEAL = 21871;
  
  public static final int VAULT_KEY = 21872;
  
  public static final int EMPTY_SACK_21873 = 21873;
  
  public static final int BULGING_SACK = 21874;
  
  public static final int KRISTMAS_KEBAB = 21875;
  
  public static final int WRATH_RUNE = 21880;
  
  public static final int DRAGON_ARMOUR_SET_LG = 21882;
  
  public static final int DRAGON_ARMOUR_SET_SK = 21885;
  
  public static final int TURQUOISE_SLAYER_HELMET = 21888;
  
  public static final int TURQUOISE_SLAYER_HELMET_I = 21890;
  
  public static final int DRAGON_PLATEBODY = 21892;
  
  public static final int DRAGON_KITESHIELD = 21895;
  
  public static final int ASSEMBLER_MAX_CAPE = 21898;
  
  public static final int ASSEMBLER_MAX_HOOD = 21900;
  
  public static final int DRAGON_CROSSBOW = 21902;
  
  public static final int DRAGON_BOLTS = 21905;
  
  public static final int VORKATHS_HEAD_21907 = 21907;
  
  public static final int VORKATHS_STUFFED_HEAD = 21909;
  
  public static final int RUNE_DRAGON = 21911;
  
  public static final int VORKATHS_HEAD_21912 = 21912;
  
  public static final int MYTHICAL_CAPE = 21913;
  
  public static final int AVAS_ASSEMBLER_BROKEN = 21914;
  
  public static final int ASSEMBLER_MAX_CAPE_BROKEN = 21916;
  
  public static final int DRAGON_LIMBS = 21918;
  
  public static final int DRAGON_CROSSBOW_U = 21921;
  
  public static final int DRAGON_BOLTS_P = 21924;
  
  public static final int DRAGON_BOLTS_P_21926 = 21926;
  
  public static final int DRAGON_BOLTS_P_21928 = 21928;
  
  public static final int DRAGON_BOLTS_UNF = 21930;
  
  public static final int OPAL_DRAGON_BOLTS_E = 21932;
  
  public static final int JADE_DRAGON_BOLTS_E = 21934;
  
  public static final int PEARL_DRAGON_BOLTS_E = 21936;
  
  public static final int TOPAZ_DRAGON_BOLTS_E = 21938;
  
  public static final int SAPPHIRE_DRAGON_BOLTS_E = 21940;
  
  public static final int EMERALD_DRAGON_BOLTS_E = 21942;
  
  public static final int RUBY_DRAGON_BOLTS_E = 21944;
  
  public static final int DIAMOND_DRAGON_BOLTS_E = 21946;
  
  public static final int DRAGONSTONE_DRAGON_BOLTS_E = 21948;
  
  public static final int ONYX_DRAGON_BOLTS_E = 21950;
  
  public static final int MAGIC_STOCK = 21952;
  
  public static final int OPAL_DRAGON_BOLTS = 21955;
  
  public static final int JADE_DRAGON_BOLTS = 21957;
  
  public static final int PEARL_DRAGON_BOLTS = 21959;
  
  public static final int TOPAZ_DRAGON_BOLTS = 21961;
  
  public static final int SAPPHIRE_DRAGON_BOLTS = 21963;
  
  public static final int EMERALD_DRAGON_BOLTS = 21965;
  
  public static final int RUBY_DRAGON_BOLTS = 21967;
  
  public static final int DIAMOND_DRAGON_BOLTS = 21969;
  
  public static final int DRAGONSTONE_DRAGON_BOLTS = 21971;
  
  public static final int ONYX_DRAGON_BOLTS = 21973;
  
  public static final int CRUSHED_SUPERIOR_DRAGON_BONES = 21975;
  
  public static final int SUPER_ANTIFIRE_POTION4 = 21978;
  
  public static final int SUPER_ANTIFIRE_POTION3 = 21981;
  
  public static final int SUPER_ANTIFIRE_POTION2 = 21984;
  
  public static final int SUPER_ANTIFIRE_POTION1 = 21987;
  
  public static final int RIFT_GUARDIAN_21990 = 21990;
  
  public static final int VORKI = 21992;
  
  public static final int SUPER_ANTIFIRE_MIX2 = 21994;
  
  public static final int SUPER_ANTIFIRE_MIX1 = 21997;
  
  public static final int CLUE_SCROLL_ELITE_22000 = 22000;
  
  public static final int CLUE_SCROLL_EASY_22001 = 22001;
  
  public static final int DRAGONFIRE_WARD = 22002;
  
  public static final int DRAGONFIRE_WARD_22003 = 22003;
  
  public static final int SKELETAL_VISAGE = 22006;
  
  public static final int MAP_PIECE = 22009;
  
  public static final int MAP_PIECE_22010 = 22010;
  
  public static final int MAP_PIECE_22011 = 22011;
  
  public static final int MAP_PIECE_22012 = 22012;
  
  public static final int MAP_PIECE_22013 = 22013;
  
  public static final int MAP_PIECE_22014 = 22014;
  
  public static final int MAP_PIECE_22015 = 22015;
  
  public static final int MAP_PIECE_22016 = 22016;
  
  public static final int MAP_PIECE_22017 = 22017;
  
  public static final int MAP_PIECE_22018 = 22018;
  
  public static final int MAP_PIECE_22019 = 22019;
  
  public static final int MAP_PIECE_22020 = 22020;
  
  public static final int MAP_PIECE_22021 = 22021;
  
  public static final int MAP_PIECE_22022 = 22022;
  
  public static final int MAP_PIECE_22023 = 22023;
  
  public static final int MAP_PIECE_22024 = 22024;
  
  public static final int MAP_PIECE_22025 = 22025;
  
  public static final int MAP_PIECE_22026 = 22026;
  
  public static final int MAP_PIECE_22027 = 22027;
  
  public static final int MAP_PIECE_22028 = 22028;
  
  public static final int MAP_PIECE_22029 = 22029;
  
  public static final int MAP_PIECE_22030 = 22030;
  
  public static final int MAP_PIECE_22031 = 22031;
  
  public static final int MAP_PIECE_22032 = 22032;
  
  public static final int AIVAS_DIARY = 22033;
  
  public static final int VARROCK_CENSUS_RECORDS = 22035;
  
  public static final int MALUMACS_JOURNAL = 22037;
  
  public static final int ABLENKIANS_ESCAPE = 22039;
  
  public static final int IMCANDORIAS_FALL = 22041;
  
  public static final int IMAFORES_BETRAYAL = 22043;
  
  public static final int LUTWIDGE_AND_THE_MOONFLY = 22045;
  
  public static final int SERAFINA = 22047;
  
  public static final int THE_WEEPING = 22049;
  
  public static final int OLD_NOTES = 22051;
  
  public static final int OLD_NOTES_22053 = 22053;
  
  public static final int OLD_NOTES_22055 = 22055;
  
  public static final int OLD_NOTES_22057 = 22057;
  
  public static final int OLD_NOTES_22059 = 22059;
  
  public static final int OLD_NOTES_22061 = 22061;
  
  public static final int OLD_NOTES_22063 = 22063;
  
  public static final int OLD_NOTES_22065 = 22065;
  
  public static final int OLD_NOTES_22067 = 22067;
  
  public static final int OLD_NOTES_22069 = 22069;
  
  public static final int OLD_NOTES_22071 = 22071;
  
  public static final int OLD_NOTES_22073 = 22073;
  
  public static final int OLD_NOTES_22075 = 22075;
  
  public static final int OLD_NOTES_22077 = 22077;
  
  public static final int INERT_LOCATOR_ORB = 22079;
  
  public static final int LOCATOR_ORB = 22081;
  
  public static final int ROBERT_BUST = 22083;
  
  public static final int CAMORRA_BUST = 22084;
  
  public static final int TRISTAN_BUST = 22085;
  
  public static final int AIVAS_BUST = 22086;
  
  public static final int DRAGON_KEY = 22087;
  
  public static final int DRAGON_KEY_PIECE = 22088;
  
  public static final int DRAGON_KEY_PIECE_22089 = 22089;
  
  public static final int DRAGON_KEY_PIECE_22090 = 22090;
  
  public static final int DRAGON_KEY_PIECE_22091 = 22091;
  
  public static final int DRAGON_KEY_22092 = 22092;
  
  public static final int ANCIENT_KEY = 22093;
  
  public static final int WATER_CONTAINER = 22094;
  
  public static final int SWAMP_PASTE_22095 = 22095;
  
  public static final int REVITALISATION_POTION = 22096;
  
  public static final int DRAGON_METAL_SHARD = 22097;
  
  public static final int DRAGON_METAL_SLICE = 22100;
  
  public static final int DRAGON_METAL_LUMP = 22103;
  
  public static final int JAR_OF_DECAY = 22106;
  
  public static final int AVAS_ASSEMBLER = 22109;
  
  public static final int DRAGONBONE_NECKLACE = 22111;
  
  public static final int MYTHICAL_CAPE_22114 = 22114;
  
  public static final int SUPERIOR_DRAGON_BONEMEAL = 22116;
  
  public static final int WRATH_TALISMAN = 22118;
  
  public static final int WRATH_TIARA = 22121;
  
  public static final int SUPERIOR_DRAGON_BONES = 22124;
  
  public static final int ADAMANT_KITESHIELD_22127 = 22127;
  
  public static final int ADAMANT_KITESHIELD_22129 = 22129;
  
  public static final int ADAMANT_KITESHIELD_22131 = 22131;
  
  public static final int ADAMANT_KITESHIELD_22133 = 22133;
  
  public static final int ADAMANT_KITESHIELD_22135 = 22135;
  
  public static final int ADAMANT_KITESHIELD_22137 = 22137;
  
  public static final int ADAMANT_KITESHIELD_22139 = 22139;
  
  public static final int ADAMANT_KITESHIELD_22141 = 22141;
  
  public static final int ADAMANT_KITESHIELD_22143 = 22143;
  
  public static final int ADAMANT_KITESHIELD_22145 = 22145;
  
  public static final int ADAMANT_KITESHIELD_22147 = 22147;
  
  public static final int ADAMANT_KITESHIELD_22149 = 22149;
  
  public static final int ADAMANT_KITESHIELD_22151 = 22151;
  
  public static final int ADAMANT_KITESHIELD_22153 = 22153;
  
  public static final int ADAMANT_KITESHIELD_22155 = 22155;
  
  public static final int ADAMANT_KITESHIELD_22157 = 22157;
  
  public static final int ADAMANT_HERALDIC_HELM = 22159;
  
  public static final int ADAMANT_HERALDIC_HELM_22161 = 22161;
  
  public static final int ADAMANT_HERALDIC_HELM_22163 = 22163;
  
  public static final int ADAMANT_HERALDIC_HELM_22165 = 22165;
  
  public static final int ADAMANT_HERALDIC_HELM_22167 = 22167;
  
  public static final int ADAMANT_HERALDIC_HELM_22169 = 22169;
  
  public static final int ADAMANT_HERALDIC_HELM_22171 = 22171;
  
  public static final int ADAMANT_HERALDIC_HELM_22173 = 22173;
  
  public static final int ADAMANT_HERALDIC_HELM_22175 = 22175;
  
  public static final int ADAMANT_HERALDIC_HELM_22177 = 22177;
  
  public static final int ADAMANT_HERALDIC_HELM_22179 = 22179;
  
  public static final int ADAMANT_HERALDIC_HELM_22181 = 22181;
  
  public static final int ADAMANT_HERALDIC_HELM_22183 = 22183;
  
  public static final int ADAMANT_HERALDIC_HELM_22185 = 22185;
  
  public static final int ADAMANT_HERALDIC_HELM_22187 = 22187;
  
  public static final int ADAMANT_HERALDIC_HELM_22189 = 22189;
  
  public static final int USEFUL_ROCK = 22191;
  
  public static final int MAPLE_BIRD_HOUSE = 22192;
  
  public static final int MAHOGANY_BIRD_HOUSE = 22195;
  
  public static final int YEW_BIRD_HOUSE = 22198;
  
  public static final int MAGIC_BIRD_HOUSE = 22201;
  
  public static final int REDWOOD_BIRD_HOUSE = 22204;
  
  public static final int GLISTENING_TEAR = 22207;
  
  public static final int WRATH_RUNE_22208 = 22208;
  
  public static final int EXTENDED_SUPER_ANTIFIRE4 = 22209;
  
  public static final int EXTENDED_SUPER_ANTIFIRE3 = 22212;
  
  public static final int EXTENDED_SUPER_ANTIFIRE2 = 22215;
  
  public static final int EXTENDED_SUPER_ANTIFIRE1 = 22218;
  
  public static final int EXTENDED_SUPER_ANTIFIRE_MIX2 = 22221;
  
  public static final int EXTENDED_SUPER_ANTIFIRE_MIX1 = 22224;
  
  public static final int BULLET_ARROW = 22227;
  
  public static final int FIELD_ARROW = 22228;
  
  public static final int BLUNT_ARROW = 22229;
  
  public static final int BARBED_ARROW = 22230;
  
  public static final int DRAGON_BOOTS_ORNAMENT_KIT = 22231;
  
  public static final int DRAGON_BOOTS_G = 22234;
  
  public static final int DRAGON_PLATEBODY_ORNAMENT_KIT = 22236;
  
  public static final int DRAGON_KITESHIELD_ORNAMENT_KIT = 22239;
  
  public static final int DRAGON_PLATEBODY_G = 22242;
  
  public static final int DRAGON_KITESHIELD_G = 22244;
  
  public static final int ANGUISH_ORNAMENT_KIT = 22246;
  
  public static final int NECKLACE_OF_ANGUISH_OR = 22249;
  
  public static final int OAK_SHIELD = 22251;
  
  public static final int WILLOW_SHIELD = 22254;
  
  public static final int MAPLE_SHIELD = 22257;
  
  public static final int YEW_SHIELD = 22260;
  
  public static final int MAGIC_SHIELD = 22263;
  
  public static final int REDWOOD_SHIELD = 22266;
  
  public static final int HARD_LEATHER_SHIELD = 22269;
  
  public static final int SNAKESKIN_SHIELD = 22272;
  
  public static final int GREEN_DHIDE_SHIELD = 22275;
  
  public static final int BLUE_DHIDE_SHIELD = 22278;
  
  public static final int RED_DHIDE_SHIELD = 22281;
  
  public static final int BLACK_DHIDE_SHIELD = 22284;
  
  public static final int LEATHER_SHIELDS_FLYER = 22287;
  
  public static final int TRIDENT_OF_THE_SEAS_E = 22288;
  
  public static final int UNCHARGED_TRIDENT_E = 22290;
  
  public static final int TRIDENT_OF_THE_SWAMP_E = 22292;
  
  public static final int UNCHARGED_TOXIC_TRIDENT_E = 22294;
  
  public static final int STAFF_OF_LIGHT = 22296;
  
  public static final int ANCIENT_MEDALLION = 22299;
  
  public static final int ANCIENT_EFFIGY = 22302;
  
  public static final int ANCIENT_RELIC = 22305;
  
  public static final int HEALER_ICON_22308 = 22308;
  
  public static final int HEALER_ICON_22309 = 22309;
  
  public static final int HEALER_ICON_22310 = 22310;
  
  public static final int HEALER_ICON_22311 = 22311;
  
  public static final int COLLECTOR_ICON_22312 = 22312;
  
  public static final int COLLECTOR_ICON_22313 = 22313;
  
  public static final int COLLECTOR_ICON_22314 = 22314;
  
  public static final int COLLECTOR_ICON_22315 = 22315;
  
  public static final int PROP_SWORD = 22316;
  
  public static final int PET_CORPOREAL_CRITTER = 22318;
  
  public static final int TZREKZUK = 22319;
  
  public static final int CHAMPIONS_LAMP = 22320;
  
  public static final int ROTTEN_CABBAGE = 22321;
  
  public static final int AVERNIC_DEFENDER = 22322;
  
  public static final int SANGUINESTI_STAFF = 22323;
  
  public static final int GHRAZI_RAPIER = 22324;
  
  public static final int SCYTHE_OF_VITUR = 22325;
  
  public static final int JUSTICIAR_FACEGUARD = 22326;
  
  public static final int JUSTICIAR_CHESTGUARD = 22327;
  
  public static final int JUSTICIAR_LEGGUARDS = 22328;
  
  public static final int DEADMAN_STARTER_PACK = 22330;
  
  public static final int STARTER_SWORD = 22331;
  
  public static final int STARTER_BOW = 22333;
  
  public static final int STARTER_STAFF = 22335;
  
  public static final int COLLECTOR_ICON_22337 = 22337;
  
  public static final int COLLECTOR_ICON_22338 = 22338;
  
  public static final int COLLECTOR_ICON_22339 = 22339;
  
  public static final int DEFENDER_ICON_22340 = 22340;
  
  public static final int DEFENDER_ICON_22341 = 22341;
  
  public static final int DEFENDER_ICON_22342 = 22342;
  
  public static final int DEFENDER_ICON_22343 = 22343;
  
  public static final int DEFENDER_ICON_22344 = 22344;
  
  public static final int DEFENDER_ICON_22345 = 22345;
  
  public static final int ATTACKER_ICON_22346 = 22346;
  
  public static final int ATTACKER_ICON_22347 = 22347;
  
  public static final int ATTACKER_ICON_22348 = 22348;
  
  public static final int ATTACKER_ICON_22349 = 22349;
  
  public static final int EGGSHELL_PLATEBODY = 22351;
  
  public static final int EGGSHELL_PLATELEGS = 22353;
  
  public static final int HOLY_HANDEGG = 22355;
  
  public static final int PEACEFUL_HANDEGG = 22358;
  
  public static final int CHAOTIC_HANDEGG = 22361;
  
  public static final int OCULUS_ORB = 22364;
  
  public static final int CERTIFICATE_22365 = 22365;
  
  public static final int CERTIFICATE_22367 = 22367;
  
  public static final int BRYOPHYTAS_STAFF_UNCHARGED = 22368;
  
  public static final int BRYOPHYTAS_STAFF = 22370;
  
  public static final int BRYOPHYTAS_ESSENCE = 22372;
  
  public static final int MOSSY_KEY = 22374;
  
  public static final int PUPPADILE = 22376;
  
  public static final int TEKTINY = 22378;
  
  public static final int VANGUARD = 22380;
  
  public static final int VASA_MINIRIO = 22382;
  
  public static final int VESPINA = 22384;
  
  public static final int METAMORPHIC_DUST = 22386;
  
  public static final int XERICS_GUARD = 22388;
  
  public static final int XERICS_WARRIOR = 22390;
  
  public static final int XERICS_SENTINEL = 22392;
  
  public static final int XERICS_GENERAL = 22394;
  
  public static final int XERICS_CHAMPION = 22396;
  
  public static final int IVANDIS_FLAIL = 22398;
  
  public static final int DRAKANS_MEDALLION = 22400;
  
  public static final int MYSTERIOUS_HERB = 22402;
  
  public static final int MYSTERIOUS_MEAT = 22403;
  
  public static final int MYSTERIOUS_CRUSHED_MEAT = 22404;
  
  public static final int VIAL_OF_BLOOD = 22405;
  
  public static final int UNFINISHED_BLOOD_POTION = 22406;
  
  public static final int BLOOD_POTION = 22407;
  
  public static final int UNFINISHED_POTION_22408 = 22408;
  
  public static final int POTION_22409 = 22409;
  
  public static final int OLD_NOTES_22410 = 22410;
  
  public static final int OLD_DIARY = 22411;
  
  public static final int FLAYGIANS_NOTES = 22413;
  
  public static final int CHAIN = 22414;
  
  public static final int TOME_OF_EXPERIENCE = 22415;
  
  public static final int THE_TURNCLOAK = 22416;
  
  public static final int EXPLOSIVE_DISCOVERY = 22418;
  
  public static final int BLOODY_GRIMOIRE = 22420;
  
  public static final int ELIXIR_OF_EVERLASTING = 22422;
  
  public static final int BURIED_ALIVE = 22424;
  
  public static final int DEED = 22426;
  
  public static final int OLD_KEY = 22428;
  
  public static final int BLOODY_BRACER = 22430;
  
  public static final int EMERALD_SICKLE_B = 22433;
  
  public static final int ENCHANTED_EMERALD_SICKLE_B = 22435;
  
  public static final int ROTTEN_CARROT = 22437;
  
  public static final int JUSTICIAR_ARMOUR_SET = 22438;
  
  public static final int AVERNIC_DEFENDER_BROKEN = 22441;
  
  public static final int CADANTINE_BLOOD_POTION_UNF = 22443;
  
  public static final int VIAL_OF_BLOOD_22446 = 22446;
  
  public static final int BATTLEMAGE_POTION4 = 22449;
  
  public static final int BATTLEMAGE_POTION3 = 22452;
  
  public static final int BATTLEMAGE_POTION2 = 22455;
  
  public static final int BATTLEMAGE_POTION1 = 22458;
  
  public static final int BASTION_POTION4 = 22461;
  
  public static final int BASTION_POTION3 = 22464;
  
  public static final int BASTION_POTION2 = 22467;
  
  public static final int BASTION_POTION1 = 22470;
  
  public static final int LIL_ZIK = 22473;
  
  public static final int MESSAGE_22475 = 22475;
  
  public static final int AVERNIC_DEFENDER_HILT = 22477;
  
  public static final int SANGUINESTI_STAFF_UNCHARGED = 22481;
  
  public static final int SCYTHE_OF_VITUR_UNCHARGED = 22486;
  
  public static final int SINHAZA_SHROUD_TIER_1 = 22494;
  
  public static final int SINHAZA_SHROUD_TIER_2 = 22496;
  
  public static final int SINHAZA_SHROUD_TIER_3 = 22498;
  
  public static final int SINHAZA_SHROUD_TIER_4 = 22500;
  
  public static final int SINHAZA_SHROUD_TIER_5 = 22502;
  
  public static final int SERAFINAS_DIARY = 22504;
  
  public static final int THE_BUTCHER = 22506;
  
  public static final int ARACHNIDS_OF_VAMPYRIUM = 22508;
  
  public static final int THE_SHADOW_REALM = 22510;
  
  public static final int THE_WILD_HUNT = 22512;
  
  public static final int VERZIK_VITUR__PATIENT_RECORD = 22514;
  
  public static final int DAWNBRINGER = 22516;
  
  public static final int ESCAPE_CRYSTAL = 22517;
  
  public static final int CABBAGE_22519 = 22519;
  
  public static final int CABBAGE_22520 = 22520;
  
  public static final int COIN_POUCH = 22521;
  
  public static final int COIN_POUCH_22522 = 22522;
  
  public static final int COIN_POUCH_22523 = 22523;
  
  public static final int COIN_POUCH_22524 = 22524;
  
  public static final int COIN_POUCH_22525 = 22525;
  
  public static final int COIN_POUCH_22526 = 22526;
  
  public static final int COIN_POUCH_22527 = 22527;
  
  public static final int COIN_POUCH_22528 = 22528;
  
  public static final int COIN_POUCH_22529 = 22529;
  
  public static final int COIN_POUCH_22530 = 22530;
  
  public static final int COIN_POUCH_22531 = 22531;
  
  public static final int COIN_POUCH_22532 = 22532;
  
  public static final int COIN_POUCH_22533 = 22533;
  
  public static final int COIN_POUCH_22534 = 22534;
  
  public static final int COIN_POUCH_22535 = 22535;
  
  public static final int COIN_POUCH_22536 = 22536;
  
  public static final int COIN_POUCH_22537 = 22537;
  
  public static final int COIN_POUCH_22538 = 22538;
  
  public static final int ROTTEN_STRAWBERRY = 22541;
  
  public static final int VIGGORAS_CHAINMACE_U = 22542;
  
  public static final int VIGGORAS_CHAINMACE = 22545;
  
  public static final int CRAWS_BOW_U = 22547;
  
  public static final int CRAWS_BOW = 22550;
  
  public static final int THAMMARONS_SCEPTRE_U = 22552;
  
  public static final int THAMMARONS_SCEPTRE = 22555;
  
  public static final int AMULET_OF_AVARICE = 22557;
  
  public static final int LOOTING_BAG_22586 = 22586;
  
  public static final int OLD_MANS_COFFIN = 22588;
  
  public static final int REDUCED_CADAVA_POTION = 22589;
  
  public static final int GOAT_DUNG = 22590;
  
  public static final int WEISS_FIRE_NOTES = 22591;
  
  public static final int TE_SALT = 22593;
  
  public static final int EFH_SALT = 22595;
  
  public static final int URT_SALT = 22597;
  
  public static final int ICY_BASALT = 22599;
  
  public static final int STONY_BASALT = 22601;
  
  public static final int BASALT = 22603;
  
  public static final int FIRE_OF_ETERNAL_LIGHT = 22606;
  
  public static final int FIRE_OF_DEHUMIDIFICATION = 22607;
  
  public static final int FIRE_OF_NOURISHMENT = 22608;
  
  public static final int FIRE_OF_UNSEASONAL_WARMTH = 22609;
  
  public static final int VESTAS_SPEAR = 22610;
  
  public static final int VESTAS_LONGSWORD = 22613;
  
  public static final int VESTAS_CHAINBODY = 22616;
  
  public static final int VESTAS_PLATESKIRT = 22619;
  
  public static final int STATIUSS_WARHAMMER = 22622;
  
  public static final int STATIUSS_FULL_HELM = 22625;
  
  public static final int STATIUSS_PLATEBODY = 22628;
  
  public static final int STATIUSS_PLATELEGS = 22631;
  
  public static final int MORRIGANS_THROWING_AXE = 22634;
  
  public static final int MORRIGANS_JAVELIN = 22636;
  
  public static final int MORRIGANS_COIF = 22638;
  
  public static final int MORRIGANS_LEATHER_BODY = 22641;
  
  public static final int MORRIGANS_LEATHER_CHAPS = 22644;
  
  public static final int ZURIELS_STAFF = 22647;
  
  public static final int ZURIELS_HOOD = 22650;
  
  public static final int ZURIELS_ROBE_TOP = 22653;
  
  public static final int ZURIELS_ROBE_BOTTOM = 22656;
  
  public static final int EMPTY_BUCKET_PACK = 22660;
  
  public static final int PET_SMOKE_DEVIL_22663 = 22663;
  
  public static final int SCYTHE_OF_VITUR_22664 = 22664;
  
  public static final int ARMADYL_GODSWORD_22665 = 22665;
  
  public static final int RUBBER_CHICKEN_22666 = 22666;
  
  public static final int KQ_HEAD_TATTERED = 22671;
  
  public static final int STUFFED_KQ_HEAD_TATTERED = 22673;
  
  public static final int SCROLL_SACK = 22675;
  
  public static final int EEK = 22684;
  
  public static final int CLOWN_MASK = 22689;
  
  public static final int CLOWN_BOW_TIE = 22692;
  
  public static final int CLOWN_GOWN = 22695;
  
  public static final int CLOWN_TROUSERS = 22698;
  
  public static final int CLOWN_SHOES = 22701;
  
  public static final int PORTAL_NEXUS = 22704;
  
  public static final int MARBLE_PORTAL_NEXUS = 22705;
  
  public static final int GILDED_PORTAL_NEXUS = 22706;
  
  public static final int CRYSTALLINE_PORTAL_NEXUS = 22707;
  
  public static final int MOUNTED_XERICS_TALISMAN = 22708;
  
  public static final int MOUNTED_DIGSITE_PENDANT = 22709;
  
  public static final int CURATORS_MEDALLION = 22710;
  
  public static final int COLLECTION_LOG = 22711;
  
  public static final int STARFACE = 22713;
  
  public static final int TREE_TOP = 22715;
  
  public static final int TREE_SKIRT = 22717;
  
  public static final int CANDY_CANE = 22719;
  
  public static final int ATTACKER_ICON_22721 = 22721;
  
  public static final int ATTACKER_ICON_22722 = 22722;
  
  public static final int ATTACKER_ICON_22723 = 22723;
  
  public static final int COLLECTOR_ICON_22724 = 22724;
  
  public static final int DEFENDER_ICON_22725 = 22725;
  
  public static final int DEFENDER_ICON_22726 = 22726;
  
  public static final int DEFENDER_ICON_22727 = 22727;
  
  public static final int DEFENDER_ICON_22728 = 22728;
  
  public static final int ATTACKER_ICON_22729 = 22729;
  
  public static final int ATTACKER_ICON_22730 = 22730;
  
  public static final int DRAGON_HASTA = 22731;
  
  public static final int DRAGON_HASTAP = 22734;
  
  public static final int DRAGON_HASTAP_22737 = 22737;
  
  public static final int DRAGON_HASTAP_22740 = 22740;
  
  public static final int DRAGON_HASTAKP = 22743;
  
  public static final int FAKE_DRAGON_HASTAKP = 22744;
  
  public static final int IKKLE_HYDRA = 22746;
  
  public static final int IKKLE_HYDRA_22748 = 22748;
  
  public static final int IKKLE_HYDRA_22750 = 22750;
  
  public static final int IKKLE_HYDRA_22752 = 22752;
  
  public static final int WYRM_BONEMEAL = 22754;
  
  public static final int DRAKE_BONEMEAL = 22756;
  
  public static final int HYDRA_BONEMEAL = 22758;
  
  public static final int CERTIFICATE_22760 = 22760;
  
  public static final int DINHS_HAMMER = 22761;
  
  public static final int GENERATOR_CRANK = 22762;
  
  public static final int _8GALLON_JUG = 22763;
  
  public static final int _5GALLON_JUG = 22764;
  
  public static final int ENERGY_DISK_LEVEL_4 = 22765;
  
  public static final int ENERGY_DISK_LEVEL_3 = 22766;
  
  public static final int ENERGY_DISK_LEVEL_2 = 22767;
  
  public static final int ENERGY_DISK_LEVEL_1 = 22768;
  
  public static final int UNKNOWN_FLUID_1 = 22769;
  
  public static final int UNKNOWN_FLUID_2 = 22770;
  
  public static final int UNKNOWN_FLUID_3 = 22771;
  
  public static final int UNKNOWN_FLUID_4 = 22772;
  
  public static final int UNKNOWN_FLUID_5 = 22773;
  
  public static final int OLD_NOTES_22774 = 22774;
  
  public static final int ANCIENT_LETTER = 22775;
  
  public static final int CERTIFICATE_22777 = 22777;
  
  public static final int WYRM_BONES = 22780;
  
  public static final int DRAKE_BONES = 22783;
  
  public static final int HYDRA_BONES = 22786;
  
  public static final int UNCOOKED_DRAGONFRUIT_PIE = 22789;
  
  public static final int HALF_A_DRAGONFRUIT_PIE = 22792;
  
  public static final int DRAGONFRUIT_PIE = 22795;
  
  public static final int BIRD_NEST_22798 = 22798;
  
  public static final int BIRD_NEST_22800 = 22800;
  
  public static final int RADAS_BLESSING = 22803;
  
  public static final int DRAGON_KNIFE = 22804;
  
  public static final int DRAGON_KNIFEP = 22806;
  
  public static final int DRAGON_KNIFEP_22808 = 22808;
  
  public static final int DRAGON_KNIFEP_22810 = 22810;
  
  public static final int DRAGON_KNIFE_22812 = 22812;
  
  public static final int DRAGON_KNIFE_22814 = 22814;
  
  public static final int CORMORANTS_GLOVE = 22816;
  
  public static final int CORMORANTS_GLOVE_22817 = 22817;
  
  public static final int FISH_CHUNKS = 22818;
  
  public static final int MOLCH_PEARL = 22820;
  
  public static final int BLUEGILL = 22826;
  
  public static final int COMMON_TENCH = 22829;
  
  public static final int MOTTLED_EEL = 22832;
  
  public static final int GREATER_SIREN = 22835;
  
  public static final int FISH_SACK = 22838;
  
  public static final int GOLDEN_TENCH = 22840;
  
  public static final int PEARL_BARBARIAN_ROD = 22842;
  
  public static final int PEARL_FLY_FISHING_ROD = 22844;
  
  public static final int PEARL_FISHING_ROD = 22846;
  
  public static final int CELASTRUS_SEEDLING = 22848;
  
  public static final int REDWOOD_SEEDLING = 22850;
  
  public static final int CELASTRUS_SEEDLING_W = 22852;
  
  public static final int REDWOOD_SEEDLING_W = 22854;
  
  public static final int CELASTRUS_SAPLING = 22856;
  
  public static final int REDWOOD_SAPLING = 22859;
  
  public static final int DRAGONFRUIT_SEEDLING = 22862;
  
  public static final int DRAGONFRUIT_SEEDLING_W = 22864;
  
  public static final int DRAGONFRUIT_SAPLING = 22866;
  
  public static final int CELASTRUS_SEED = 22869;
  
  public static final int REDWOOD_TREE_SEED = 22871;
  
  public static final int POTATO_CACTUS_SEED = 22873;
  
  public static final int HESPORI_SEED = 22875;
  
  public static final int DRAGONFRUIT_TREE_SEED = 22877;
  
  public static final int SNAPE_GRASS_SEED = 22879;
  
  public static final int ATTAS_SEED = 22881;
  
  public static final int IASOR_SEED = 22883;
  
  public static final int KRONOS_SEED = 22885;
  
  public static final int WHITE_LILY_SEED = 22887;
  
  public static final int DRAGONFRUIT = 22929;
  
  public static final int WHITE_LILY = 22932;
  
  public static final int CELASTRUS_BARK = 22935;
  
  public static final int RADAS_BLESSING_1 = 22941;
  
  public static final int RADAS_BLESSING_2 = 22943;
  
  public static final int RADAS_BLESSING_3 = 22945;
  
  public static final int RADAS_BLESSING_4 = 22947;
  
  public static final int BATTLEFRONT_TELEPORT = 22949;
  
  public static final int BOOTS_OF_BRIMSTONE = 22951;
  
  public static final int DEVOUT_BOOTS = 22954;
  
  public static final int DRAKES_CLAW = 22957;
  
  public static final int DRAKES_TOOTH = 22960;
  
  public static final int BROKEN_DRAGON_HASTA = 22963;
  
  public static final int HYDRAS_CLAW = 22966;
  
  public static final int HYDRAS_HEART = 22969;
  
  public static final int HYDRAS_FANG = 22971;
  
  public static final int HYDRAS_EYE = 22973;
  
  public static final int BRIMSTONE_RING = 22975;
  
  public static final int DRAGON_HUNTER_LANCE = 22978;
  
  public static final int FEROCIOUS_GLOVES = 22981;
  
  public static final int HYDRA_LEATHER = 22983;
  
  public static final int BONECRUSHER_NECKLACE = 22986;
  
  public static final int HYDRA_TAIL = 22988;
  
  public static final int STONE_TABLET_22991 = 22991;
  
  public static final int SEED_PACK = 22993;
  
  public static final int BOTTOMLESS_COMPOST_BUCKET = 22994;
  
  public static final int BOTTOMLESS_COMPOST_BUCKET_22997 = 22997;
  
  public static final int BOTTLED_DRAGONBREATH_UNPOWERED = 22999;
  
  public static final int BOTTLED_DRAGONBREATH = 23002;
  
  public static final int TATTY_NOTE = 23007;
  
  public static final int GIELINORS_FLORA__FLOWERS = 23009;
  
  public static final int GIELINORS_FLORA__BUSHES = 23011;
  
  public static final int GIELINORS_FLORA__HOPS = 23013;
  
  public static final int GIELINORS_FLORA__ALLOTMENTS = 23015;
  
  public static final int GIELINORS_FLORA__HERBS = 23017;
  
  public static final int GIELINORS_FLORA__TREES = 23019;
  
  public static final int GIELINORS_FLORA__FRUIT = 23021;
  
  public static final int OLD_NOTES_23023 = 23023;
  
  public static final int OLD_NOTES_23025 = 23025;
  
  public static final int OLD_NOTES_23027 = 23027;
  
  public static final int OLD_NOTES_23029 = 23029;
  
  public static final int OLD_NOTES_23031 = 23031;
  
  public static final int OLD_NOTES_23033 = 23033;
  
  public static final int OLD_NOTES_23035 = 23035;
  
  public static final int BOOTS_OF_STONE = 23037;
  
  public static final int WYRM = 23040;
  
  public static final int DRAKE = 23041;
  
  public static final int HYDRA = 23042;
  
  public static final int SULPHUR_LIZARD = 23043;
  
  public static final int CLUE_SCROLL_HARD_23045 = 23045;
  
  public static final int CLUE_SCROLL_MEDIUM_23046 = 23046;
  
  public static final int MYSTIC_HAT_DUSK = 23047;
  
  public static final int MYSTIC_ROBE_TOP_DUSK = 23050;
  
  public static final int MYSTIC_ROBE_BOTTOM_DUSK = 23053;
  
  public static final int MYSTIC_GLOVES_DUSK = 23056;
  
  public static final int MYSTIC_BOOTS_DUSK = 23059;
  
  public static final int NEST_BOX_SEEDS_23062 = 23062;
  
  public static final int JAR_OF_CHEMICALS = 23064;
  
  public static final int TREASURE_SCROLL = 23067;
  
  public static final int TREASURE_SCROLL_23068 = 23068;
  
  public static final int MYSTERIOUS_ORB_23069 = 23069;
  
  public static final int TREASURE_SCROLL_23070 = 23070;
  
  public static final int ANCIENT_CASKET = 23071;
  
  public static final int ANTIQUE_LAMP_23072 = 23072;
  
  public static final int HYDRA_SLAYER_HELMET = 23073;
  
  public static final int HYDRA_SLAYER_HELMET_I = 23075;
  
  public static final int ALCHEMICAL_HYDRA_HEADS = 23077;
  
  public static final int STUFFED_HYDRA_HEADS = 23079;
  
  public static final int ALCHEMICAL_HYDRA_HEAD = 23081;
  
  public static final int ANTIQUE_LAMP_23082 = 23082;
  
  public static final int BRIMSTONE_KEY = 23083;
  
  public static final int ORNATE_GLOVES = 23091;
  
  public static final int ORNATE_BOOTS = 23093;
  
  public static final int ORNATE_LEGS = 23095;
  
  public static final int ORNATE_TOP = 23097;
  
  public static final int ORNATE_CAPE = 23099;
  
  public static final int ORNATE_HELM = 23101;
  
  public static final int BIRTHDAY_CAKE = 23108;
  
  public static final int MYSTIC_SET_LIGHT = 23110;
  
  public static final int MYSTIC_SET_BLUE = 23113;
  
  public static final int MYSTIC_SET_DARK = 23116;
  
  public static final int MYSTIC_SET_DUSK = 23119;
  
  public static final int OILY_PEARL_FISHING_ROD = 23122;
  
  public static final int GILDED_DRAGONHIDE_SET = 23124;
  
  public static final int CLUE_NEST_BEGINNER = 23127;
  
  public static final int CLUE_BOTTLE_BEGINNER = 23129;
  
  public static final int CLUE_SCROLL_MEDIUM_23131 = 23131;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_23132 = 23132;
  
  public static final int CLUE_SCROLL_MEDIUM_23133 = 23133;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_23134 = 23134;
  
  public static final int CLUE_SCROLL_MEDIUM_23135 = 23135;
  
  public static final int CLUE_SCROLL_MEDIUM_23136 = 23136;
  
  public static final int CLUE_SCROLL_MEDIUM_23137 = 23137;
  
  public static final int CLUE_SCROLL_MEDIUM_23138 = 23138;
  
  public static final int CLUE_SCROLL_MEDIUM_23139 = 23139;
  
  public static final int CLUE_SCROLL_MEDIUM_23140 = 23140;
  
  public static final int CLUE_SCROLL_MEDIUM_23141 = 23141;
  
  public static final int CLUE_SCROLL_MEDIUM_23142 = 23142;
  
  public static final int CLUE_SCROLL_MEDIUM_23143 = 23143;
  
  public static final int CLUE_SCROLL_ELITE_23144 = 23144;
  
  public static final int CLUE_SCROLL_ELITE_23145 = 23145;
  
  public static final int CLUE_SCROLL_ELITE_23146 = 23146;
  
  public static final int CLUE_SCROLL_ELITE_23147 = 23147;
  
  public static final int CLUE_SCROLL_ELITE_23148 = 23148;
  
  public static final int CLUE_SCROLL_EASY_23149 = 23149;
  
  public static final int CLUE_SCROLL_EASY_23150 = 23150;
  
  public static final int CLUE_SCROLL_EASY_23151 = 23151;
  
  public static final int CLUE_SCROLL_EASY_23152 = 23152;
  
  public static final int CLUE_SCROLL_EASY_23153 = 23153;
  
  public static final int CLUE_SCROLL_EASY_23154 = 23154;
  
  public static final int CLUE_SCROLL_EASY_23155 = 23155;
  
  public static final int CLUE_SCROLL_EASY_23156 = 23156;
  
  public static final int CLUE_SCROLL_EASY_23157 = 23157;
  
  public static final int CLUE_SCROLL_EASY_23158 = 23158;
  
  public static final int CLUE_SCROLL_EASY_23159 = 23159;
  
  public static final int CLUE_SCROLL_EASY_23160 = 23160;
  
  public static final int CLUE_SCROLL_EASY_23161 = 23161;
  
  public static final int CLUE_SCROLL_EASY_23162 = 23162;
  
  public static final int CLUE_SCROLL_EASY_23163 = 23163;
  
  public static final int CLUE_SCROLL_EASY_23164 = 23164;
  
  public static final int CLUE_SCROLL_EASY_23165 = 23165;
  
  public static final int CLUE_SCROLL_EASY_23166 = 23166;
  
  public static final int CLUE_SCROLL_HARD_23167 = 23167;
  
  public static final int CLUE_SCROLL_HARD_23168 = 23168;
  
  public static final int CLUE_SCROLL_HARD_23169 = 23169;
  
  public static final int CLUE_SCROLL_HARD_23170 = 23170;
  
  public static final int PUZZLE_BOX_HARD_23171 = 23171;
  
  public static final int CLUE_SCROLL_HARD_23172 = 23172;
  
  public static final int PUZZLE_BOX_HARD_23173 = 23173;
  
  public static final int CLUE_SCROLL_HARD_23174 = 23174;
  
  public static final int CLUE_SCROLL_HARD_23175 = 23175;
  
  public static final int CLUE_SCROLL_HARD_23176 = 23176;
  
  public static final int CLUE_SCROLL_HARD_23177 = 23177;
  
  public static final int CLUE_SCROLL_HARD_23178 = 23178;
  
  public static final int CLUE_SCROLL_HARD_23179 = 23179;
  
  public static final int CLUE_SCROLL_HARD_23180 = 23180;
  
  public static final int CLUE_SCROLL_HARD_23181 = 23181;
  
  public static final int CLUE_SCROLL_BEGINNER = 23182;
  
  public static final int STRANGE_DEVICE_23183 = 23183;
  
  public static final int MIMIC = 23184;
  
  public static final int RING_OF_3RD_AGE = 23185;
  
  public static final int GUTHIX_DHIDE_SHIELD = 23188;
  
  public static final int SARADOMIN_DHIDE_SHIELD = 23191;
  
  public static final int ZAMORAK_DHIDE_SHIELD = 23194;
  
  public static final int ANCIENT_DHIDE_SHIELD = 23197;
  
  public static final int ARMADYL_DHIDE_SHIELD = 23200;
  
  public static final int BANDOS_DHIDE_SHIELD = 23203;
  
  public static final int DUAL_SAI = 23206;
  
  public static final int RUNE_PLATEBODY_H1 = 23209;
  
  public static final int RUNE_PLATEBODY_H2 = 23212;
  
  public static final int RUNE_PLATEBODY_H3 = 23215;
  
  public static final int RUNE_PLATEBODY_H4 = 23218;
  
  public static final int RUNE_PLATEBODY_H5 = 23221;
  
  public static final int THIEVING_BAG = 23224;
  
  public static final int RUNE_DEFENDER_ORNAMENT_KIT = 23227;
  
  public static final int RUNE_DEFENDER_T = 23230;
  
  public static final int TZHAARKETOM_ORNAMENT_KIT = 23232;
  
  public static final int TZHAARKETOM_T = 23235;
  
  public static final int BERSERKER_NECKLACE_ORNAMENT_KIT = 23237;
  
  public static final int BERSERKER_NECKLACE_OR = 23240;
  
  public static final int _3RD_AGE_PLATESKIRT = 23242;
  
  public static final int REWARD_CASKET_BEGINNER = 23245;
  
  public static final int FREMENNIK_KILT = 23246;
  
  public static final int RANGERS_TIGHTS = 23249;
  
  public static final int GIANT_BOOT = 23252;
  
  public static final int URIS_HAT = 23255;
  
  public static final int GILDED_COIF = 23258;
  
  public static final int GILDED_DHIDE_VAMBRACES = 23261;
  
  public static final int GILDED_DHIDE_BODY = 23264;
  
  public static final int GILDED_DHIDE_CHAPS = 23267;
  
  public static final int ADAMANT_DRAGON_MASK = 23270;
  
  public static final int RUNE_DRAGON_MASK = 23273;
  
  public static final int GILDED_PICKAXE = 23276;
  
  public static final int GILDED_AXE = 23279;
  
  public static final int GILDED_SPADE = 23282;
  
  public static final int MOLE_SLIPPERS = 23285;
  
  public static final int FROG_SLIPPERS = 23288;
  
  public static final int BEAR_FEET = 23291;
  
  public static final int DEMON_FEET = 23294;
  
  public static final int JESTER_CAPE = 23297;
  
  public static final int SHOULDER_PARROT = 23300;
  
  public static final int MONKS_ROBE_TOP_T = 23303;
  
  public static final int MONKS_ROBE_T = 23306;
  
  public static final int AMULET_OF_DEFENCE_T = 23309;
  
  public static final int SANDWICH_LADY_HAT = 23312;
  
  public static final int SANDWICH_LADY_TOP = 23315;
  
  public static final int SANDWICH_LADY_BOTTOM = 23318;
  
  public static final int RUNE_SCIMITAR_ORNAMENT_KIT_GUTHIX = 23321;
  
  public static final int RUNE_SCIMITAR_ORNAMENT_KIT_SARADOMIN = 23324;
  
  public static final int RUNE_SCIMITAR_ORNAMENT_KIT_ZAMORAK = 23327;
  
  public static final int RUNE_SCIMITAR_23330 = 23330;
  
  public static final int RUNE_SCIMITAR_23332 = 23332;
  
  public static final int RUNE_SCIMITAR_23334 = 23334;
  
  public static final int _3RD_AGE_DRUIDIC_ROBE_TOP = 23336;
  
  public static final int _3RD_AGE_DRUIDIC_ROBE_BOTTOMS = 23339;
  
  public static final int _3RD_AGE_DRUIDIC_STAFF = 23342;
  
  public static final int _3RD_AGE_DRUIDIC_CLOAK = 23345;
  
  public static final int TORMENTED_ORNAMENT_KIT = 23348;
  
  public static final int CAPE_OF_SKULLS = 23351;
  
  public static final int AMULET_OF_POWER_T = 23354;
  
  public static final int RAIN_BOW = 23357;
  
  public static final int HAM_JOINT = 23360;
  
  public static final int STAFF_OF_BOB_THE_CAT = 23363;
  
  public static final int BLACK_PLATEBODY_H1 = 23366;
  
  public static final int BLACK_PLATEBODY_H2 = 23369;
  
  public static final int BLACK_PLATEBODY_H3 = 23372;
  
  public static final int BLACK_PLATEBODY_H4 = 23375;
  
  public static final int BLACK_PLATEBODY_H5 = 23378;
  
  public static final int LEATHER_BODY_G = 23381;
  
  public static final int LEATHER_CHAPS_G = 23384;
  
  public static final int WATSON_TELEPORT = 23387;
  
  public static final int SPIKED_MANACLES = 23389;
  
  public static final int ADAMANT_PLATEBODY_H1 = 23392;
  
  public static final int ADAMANT_PLATEBODY_H2 = 23395;
  
  public static final int ADAMANT_PLATEBODY_H3 = 23398;
  
  public static final int ADAMANT_PLATEBODY_H4 = 23401;
  
  public static final int ADAMANT_PLATEBODY_H5 = 23404;
  
  public static final int WOLF_MASK = 23407;
  
  public static final int WOLF_CLOAK = 23410;
  
  public static final int CLIMBING_BOOTS_G = 23413;
  
  public static final int STASH_UNITS_BEGINNER = 23416;
  
  public static final int PUZZLE_BOX_MASTER_23417 = 23417;
  
  public static final int CLUE_GEODE_BEGINNER = 23442;
  
  public static final int TORMENTED_BRACELET_OR = 23444;
  
  public static final int GIANT_EASTER_EGG = 23446;
  
  public static final int BUNNYMAN_MASK = 23448;
  
  public static final int ENCHANTED_LYREI = 23458;
  
  public static final int ATTACKER_ICON_23460 = 23460;
  
  public static final int ATTACKER_ICON_23461 = 23461;
  
  public static final int ATTACKER_ICON_23462 = 23462;
  
  public static final int ATTACKER_ICON_23463 = 23463;
  
  public static final int ATTACKER_ICON_23464 = 23464;
  
  public static final int ATTACKER_ICON_23465 = 23465;
  
  public static final int DEFENDER_ICON_23466 = 23466;
  
  public static final int DEFENDER_ICON_23467 = 23467;
  
  public static final int DEFENDER_ICON_23468 = 23468;
  
  public static final int DEFENDER_ICON_23469 = 23469;
  
  public static final int DEFENDER_ICON_23470 = 23470;
  
  public static final int COLLECTOR_ICON_23471 = 23471;
  
  public static final int COLLECTOR_ICON_23472 = 23472;
  
  public static final int COLLECTOR_ICON_23473 = 23473;
  
  public static final int COLLECTOR_ICON_23474 = 23474;
  
  public static final int COLLECTOR_ICON_23475 = 23475;
  
  public static final int COLLECTOR_ICON_23476 = 23476;
  
  public static final int COLLECTOR_ICON_23477 = 23477;
  
  public static final int HEALER_ICON_23478 = 23478;
  
  public static final int HEALER_ICON_23479 = 23479;
  
  public static final int HEALER_ICON_23480 = 23480;
  
  public static final int HEALER_ICON_23481 = 23481;
  
  public static final int HEALER_ICON_23482 = 23482;
  
  public static final int HEALER_ICON_23483 = 23483;
  
  public static final int HEALER_ICON_23484 = 23484;
  
  public static final int HEALER_ICON_23485 = 23485;
  
  public static final int HEALER_ICON_23486 = 23486;
  
  public static final int ARCHAIC_EMBLEM_TIER_10_23487 = 23487;
  
  public static final int WINE_OF_ZAMORAK_23489 = 23489;
  
  public static final int LARRANS_KEY = 23490;
  
  public static final int SRARACHA = 23495;
  
  public static final int TEMPLE_COIN = 23497;
  
  public static final int GRUBBY_KEY = 23499;
  
  public static final int TEMPLE_KEY = 23502;
  
  public static final int TOME_OF_THE_MOON = 23504;
  
  public static final int TOME_OF_THE_SUN = 23506;
  
  public static final int TOME_OF_THE_TEMPLE = 23508;
  
  public static final int TATTERED_MOON_PAGE = 23510;
  
  public static final int TATTERED_SUN_PAGE = 23512;
  
  public static final int TATTERED_TEMPLE_PAGE = 23514;
  
  public static final int LAMP_OF_KNOWLEDGE = 23516;
  
  public static final int GIANT_EGG_SACFULL = 23517;
  
  public static final int GIANT_EGG_SAC = 23520;
  
  public static final int MASK_OF_RANUL = 23522;
  
  public static final int JAR_OF_EYES = 23525;
  
  public static final int SARACHNIS_CUDGEL = 23528;
  
  public static final int COOKED_KARAMBWAN_23533 = 23533;
  
  public static final int SUPER_COMBAT_POTION4_23543 = 23543;
  
  public static final int SUPER_COMBAT_POTION3_23545 = 23545;
  
  public static final int SUPER_COMBAT_POTION2_23547 = 23547;
  
  public static final int SUPER_COMBAT_POTION1_23549 = 23549;
  
  public static final int RANGING_POTION4_23551 = 23551;
  
  public static final int RANGING_POTION3_23553 = 23553;
  
  public static final int RANGING_POTION2_23555 = 23555;
  
  public static final int RANGING_POTION1_23557 = 23557;
  
  public static final int SANFEW_SERUM4_23559 = 23559;
  
  public static final int SANFEW_SERUM3_23561 = 23561;
  
  public static final int SANFEW_SERUM2_23563 = 23563;
  
  public static final int SANFEW_SERUM1_23565 = 23565;
  
  public static final int SUPER_RESTORE4_23567 = 23567;
  
  public static final int SUPER_RESTORE3_23569 = 23569;
  
  public static final int SUPER_RESTORE2_23571 = 23571;
  
  public static final int SUPER_RESTORE1_23573 = 23573;
  
  public static final int SARADOMIN_BREW4_23575 = 23575;
  
  public static final int SARADOMIN_BREW3_23577 = 23577;
  
  public static final int SARADOMIN_BREW2_23579 = 23579;
  
  public static final int SARADOMIN_BREW1_23581 = 23581;
  
  public static final int STAMINA_POTION4_23583 = 23583;
  
  public static final int STAMINA_POTION3_23585 = 23585;
  
  public static final int STAMINA_POTION2_23587 = 23587;
  
  public static final int STAMINA_POTION1_23589 = 23589;
  
  public static final int HELM_OF_NEITIZNOT_23591 = 23591;
  
  public static final int BARROWS_GLOVES_23593 = 23593;
  
  public static final int BERSERKER_RING_23595 = 23595;
  
  public static final int DRAGON_DEFENDER_23597 = 23597;
  
  public static final int SPIRIT_SHIELD_23599 = 23599;
  
  public static final int RUNE_CROSSBOW_23601 = 23601;
  
  public static final int IMBUED_GUTHIX_CAPE_23603 = 23603;
  
  public static final int IMBUED_ZAMORAK_CAPE_23605 = 23605;
  
  public static final int IMBUED_SARADOMIN_CAPE_23607 = 23607;
  
  public static final int AVAS_ACCUMULATOR_23609 = 23609;
  
  public static final int ARMADYL_CROSSBOW_23611 = 23611;
  
  public static final int STAFF_OF_THE_DEAD_23613 = 23613;
  
  public static final int VESTAS_LONGSWORD_23615 = 23615;
  
  public static final int ZURIELS_STAFF_23617 = 23617;
  
  public static final int MORRIGANS_JAVELIN_23619 = 23619;
  
  public static final int STATIUSS_WARHAMMER_23620 = 23620;
  
  public static final int INFERNAL_CAPE_23622 = 23622;
  
  public static final int SEERS_RING_I_23624 = 23624;
  
  public static final int KODAI_WAND_23626 = 23626;
  
  public static final int GHRAZI_RAPIER_23628 = 23628;
  
  public static final int HEAVY_BALLISTA_23630 = 23630;
  
  public static final int KARILS_LEATHERTOP_23632 = 23632;
  
  public static final int DHAROKS_PLATELEGS_23633 = 23633;
  
  public static final int TORAGS_PLATELEGS_23634 = 23634;
  
  public static final int VERACS_PLATESKIRT_23635 = 23635;
  
  public static final int VERACS_HELM_23636 = 23636;
  
  public static final int TORAGS_HELM_23637 = 23637;
  
  public static final int GUTHANS_HELM_23638 = 23638;
  
  public static final int DHAROKS_HELM_23639 = 23639;
  
  public static final int AMULET_OF_FURY_23640 = 23640;
  
  public static final int BLESSED_SPIRIT_SHIELD_23642 = 23642;
  
  public static final int ETERNAL_BOOTS_23644 = 23644;
  
  public static final int BANDOS_TASSETS_23646 = 23646;
  
  public static final int DRAGON_JAVELIN_23648 = 23648;
  
  public static final int DIAMOND_BOLTS_E_23649 = 23649;
  
  public static final int RUNE_POUCH_23650 = 23650;
  
  public static final int MAGES_BOOK_23652 = 23652;
  
  public static final int AHRIMS_STAFF_23653 = 23653;
  
  public static final int OCCULT_NECKLACE_23654 = 23654;
  
  public static final int CRYSTAL_SEEDLING = 23655;
  
  public static final int CRYSTAL_SEEDLING_W = 23657;
  
  public static final int CRYSTAL_SAPLING = 23659;
  
  public static final int CRYSTAL_ACORN = 23661;
  
  public static final int DRAGONSTONE_ARMOUR_SET = 23667;
  
  public static final int FLYER_23670 = 23670;
  
  public static final int CRYSTAL_AXE = 23673;
  
  public static final int CRYSTAL_AXE_INACTIVE = 23675;
  
  public static final int DRAGON_PICKAXE_OR = 23677;
  
  public static final int CRYSTAL_PICKAXE = 23680;
  
  public static final int CRYSTAL_PICKAXE_INACTIVE = 23682;
  
  public static final int DIVINE_SUPER_COMBAT_POTION4 = 23685;
  
  public static final int DIVINE_SUPER_COMBAT_POTION3 = 23688;
  
  public static final int DIVINE_SUPER_COMBAT_POTION2 = 23691;
  
  public static final int DIVINE_SUPER_COMBAT_POTION1 = 23694;
  
  public static final int DIVINE_SUPER_ATTACK_POTION4 = 23697;
  
  public static final int DIVINE_SUPER_ATTACK_POTION3 = 23700;
  
  public static final int DIVINE_SUPER_ATTACK_POTION2 = 23703;
  
  public static final int DIVINE_SUPER_ATTACK_POTION1 = 23706;
  
  public static final int DIVINE_SUPER_STRENGTH_POTION4 = 23709;
  
  public static final int DIVINE_SUPER_STRENGTH_POTION3 = 23712;
  
  public static final int DIVINE_SUPER_STRENGTH_POTION2 = 23715;
  
  public static final int DIVINE_SUPER_STRENGTH_POTION1 = 23718;
  
  public static final int DIVINE_SUPER_DEFENCE_POTION4 = 23721;
  
  public static final int DIVINE_SUPER_DEFENCE_POTION3 = 23724;
  
  public static final int DIVINE_SUPER_DEFENCE_POTION2 = 23727;
  
  public static final int DIVINE_SUPER_DEFENCE_POTION1 = 23730;
  
  public static final int DIVINE_RANGING_POTION4 = 23733;
  
  public static final int DIVINE_RANGING_POTION3 = 23736;
  
  public static final int DIVINE_RANGING_POTION2 = 23739;
  
  public static final int DIVINE_RANGING_POTION1 = 23742;
  
  public static final int DIVINE_MAGIC_POTION4 = 23745;
  
  public static final int DIVINE_MAGIC_POTION3 = 23748;
  
  public static final int DIVINE_MAGIC_POTION2 = 23751;
  
  public static final int DIVINE_MAGIC_POTION1 = 23754;
  
  public static final int YOUNGLLEF = 23757;
  
  public static final int CORRUPTED_YOUNGLLEF = 23759;
  
  public static final int SMOLCANO = 23760;
  
  public static final int CRYSTAL_HARPOON = 23762;
  
  public static final int CRYSTAL_HARPOON_INACTIVE = 23764;
  
  public static final int CRYSTAL_IMPLING_JAR = 23768;
  
  public static final int CLUE_SCROLL_ELITE_23770 = 23770;
  
  public static final int PRIFDDINAS_TELEPORT = 23771;
  
  public static final int SCRAWLED_NOTES = 23773;
  
  public static final int HAND_MIRROR_23775 = 23775;
  
  public static final int RED_CRYSTAL_23776 = 23776;
  
  public static final int YELLOW_CRYSTAL_23777 = 23777;
  
  public static final int GREEN_CRYSTAL_23778 = 23778;
  
  public static final int CYAN_CRYSTAL_23779 = 23779;
  
  public static final int BLUE_CRYSTAL_23780 = 23780;
  
  public static final int MAGENTA_CRYSTAL_23781 = 23781;
  
  public static final int BLACK_CRYSTAL = 23782;
  
  public static final int GREEN_CRYSTAL_23783 = 23783;
  
  public static final int FRACTURED_CRYSTAL_23784 = 23784;
  
  public static final int ARDOUGNE_KNIGHT_HELM = 23785;
  
  public static final int ARDOUGNE_KNIGHT_PLATEBODY = 23787;
  
  public static final int ARDOUGNE_KNIGHT_PLATELEGS = 23789;
  
  public static final int ARDOUGNE_KNIGHT_TABARD = 23791;
  
  public static final int BLUE_LIQUID = 23792;
  
  public static final int GREEN_POWDER = 23793;
  
  public static final int CLEAR_LIQUID = 23794;
  
  public static final int RED_POWDER = 23795;
  
  public static final int ODE_TO_ETERNITY = 23796;
  
  public static final int ELDER_CADANTINE = 23798;
  
  public static final int ELDER_CADANTINE_POTION_UNF = 23800;
  
  public static final int CRYSTAL_23802 = 23802;
  
  public static final int CRYSTAL_DUST = 23804;
  
  public static final int INVERSION_POTION = 23806;
  
  public static final int CRYSTAL_SEED = 23808;
  
  public static final int CRYSTAL_SEED_23810 = 23810;
  
  public static final int ORB_OF_LIGHT_23812 = 23812;
  
  public static final int CLUE_SCROLL_23814 = 23814;
  
  public static final int CLUE_SCROLL_23815 = 23815;
  
  public static final int CLUE_SCROLL_23816 = 23816;
  
  public static final int CLUE_SCROLL_23817 = 23817;
  
  public static final int EXPLOSIVE_POTION_23818 = 23818;
  
  public static final int CORRUPTED_SCEPTRE = 23820;
  
  public static final int CORRUPTED_AXE = 23821;
  
  public static final int CORRUPTED_PICKAXE = 23822;
  
  public static final int CORRUPTED_HARPOON = 23823;
  
  public static final int CORRUPTED_SHARDS = 23824;
  
  public static final int CORRUPTED_DUST = 23830;
  
  public static final int CORRUPTED_SPIKE = 23831;
  
  public static final int CORRUPTED_BOWSTRING = 23832;
  
  public static final int CORRUPTED_ORB = 23833;
  
  public static final int WEAPON_FRAME = 23834;
  
  public static final int GRYM_LEAF = 23835;
  
  public static final int LINUM_TIRINUM = 23836;
  
  public static final int CORRUPTED_ORE = 23837;
  
  public static final int PHREN_BARK = 23838;
  
  public static final int VIAL_23839 = 23839;
  
  public static final int CORRUPTED_HELM_BASIC = 23840;
  
  public static final int CORRUPTED_HELM_ATTUNED = 23841;
  
  public static final int CORRUPTED_HELM_PERFECTED = 23842;
  
  public static final int CORRUPTED_BODY_BASIC = 23843;
  
  public static final int CORRUPTED_BODY_ATTUNED = 23844;
  
  public static final int CORRUPTED_BODY_PERFECTED = 23845;
  
  public static final int CORRUPTED_LEGS_BASIC = 23846;
  
  public static final int CORRUPTED_LEGS_ATTUNED = 23847;
  
  public static final int CORRUPTED_LEGS_PERFECTED = 23848;
  
  public static final int CORRUPTED_HALBERD_BASIC = 23849;
  
  public static final int CORRUPTED_HALBERD_ATTUNED = 23850;
  
  public static final int CORRUPTED_HALBERD_PERFECTED = 23851;
  
  public static final int CORRUPTED_STAFF_BASIC = 23852;
  
  public static final int CORRUPTED_STAFF_ATTUNED = 23853;
  
  public static final int CORRUPTED_STAFF_PERFECTED = 23854;
  
  public static final int CORRUPTED_BOW_BASIC = 23855;
  
  public static final int CORRUPTED_BOW_ATTUNED = 23856;
  
  public static final int CORRUPTED_BOW_PERFECTED = 23857;
  
  public static final int CORRUPTED_TELEPORT_CRYSTAL = 23858;
  
  public static final int GAUNTLET_CAPE = 23859;
  
  public static final int CRYSTAL_SCEPTRE = 23861;
  
  public static final int CRYSTAL_AXE_23862 = 23862;
  
  public static final int CRYSTAL_PICKAXE_23863 = 23863;
  
  public static final int CRYSTAL_HARPOON_23864 = 23864;
  
  public static final int PESTLE_AND_MORTAR_23865 = 23865;
  
  public static final int CRYSTAL_SHARDS = 23866;
  
  public static final int CRYSTAL_DUST_23867 = 23867;
  
  public static final int CRYSTAL_SPIKE = 23868;
  
  public static final int CRYSTALLINE_BOWSTRING = 23869;
  
  public static final int CRYSTAL_ORB = 23870;
  
  public static final int WEAPON_FRAME_23871 = 23871;
  
  public static final int RAW_PADDLEFISH = 23872;
  
  public static final int BURNT_FISH_23873 = 23873;
  
  public static final int PADDLEFISH = 23874;
  
  public static final int GRYM_LEAF_23875 = 23875;
  
  public static final int LINUM_TIRINUM_23876 = 23876;
  
  public static final int CRYSTAL_ORE = 23877;
  
  public static final int PHREN_BARK_23878 = 23878;
  
  public static final int VIAL_23879 = 23879;
  
  public static final int WATERFILLED_VIAL = 23880;
  
  public static final int GRYM_POTION_UNF = 23881;
  
  public static final int EGNIOL_POTION_1 = 23882;
  
  public static final int EGNIOL_POTION_2 = 23883;
  
  public static final int EGNIOL_POTION_3 = 23884;
  
  public static final int EGNIOL_POTION_4 = 23885;
  
  public static final int CRYSTAL_HELM_BASIC = 23886;
  
  public static final int CRYSTAL_HELM_ATTUNED = 23887;
  
  public static final int CRYSTAL_HELM_PERFECTED = 23888;
  
  public static final int CRYSTAL_BODY_BASIC = 23889;
  
  public static final int CRYSTAL_BODY_ATTUNED = 23890;
  
  public static final int CRYSTAL_BODY_PERFECTED = 23891;
  
  public static final int CRYSTAL_LEGS_BASIC = 23892;
  
  public static final int CRYSTAL_LEGS_ATTUNED = 23893;
  
  public static final int CRYSTAL_LEGS_PERFECTED = 23894;
  
  public static final int CRYSTAL_HALBERD_BASIC = 23895;
  
  public static final int CRYSTAL_HALBERD_ATTUNED = 23896;
  
  public static final int CRYSTAL_HALBERD_PERFECTED = 23897;
  
  public static final int CRYSTAL_STAFF_BASIC = 23898;
  
  public static final int CRYSTAL_STAFF_ATTUNED = 23899;
  
  public static final int CRYSTAL_STAFF_PERFECTED = 23900;
  
  public static final int CRYSTAL_BOW_BASIC = 23901;
  
  public static final int CRYSTAL_BOW_ATTUNED = 23902;
  
  public static final int CRYSTAL_BOW_PERFECTED = 23903;
  
  public static final int TELEPORT_CRYSTAL = 23904;
  
  public static final int TEPHRA = 23905;
  
  public static final int REFINED_TEPHRA = 23906;
  
  public static final int IMBUED_TEPHRA = 23907;
  
  public static final int ZALCANO_SHARD = 23908;
  
  public static final int CRYSTAL_CROWN = 23911;
  
  public static final int CRYSTAL_CROWN_23913 = 23913;
  
  public static final int CRYSTAL_CROWN_23915 = 23915;
  
  public static final int CRYSTAL_CROWN_23917 = 23917;
  
  public static final int CRYSTAL_CROWN_23919 = 23919;
  
  public static final int CRYSTAL_CROWN_23921 = 23921;
  
  public static final int CRYSTAL_CROWN_23923 = 23923;
  
  public static final int CRYSTAL_CROWN_23925 = 23925;
  
  public static final int CRYSTAL_OF_ITHELL = 23927;
  
  public static final int CRYSTAL_OF_IORWERTH = 23929;
  
  public static final int CRYSTAL_OF_TRAHAEARN = 23931;
  
  public static final int CRYSTAL_OF_CADARN = 23933;
  
  public static final int CRYSTAL_OF_CRWYS = 23935;
  
  public static final int CRYSTAL_OF_MEILYR = 23937;
  
  public static final int CRYSTAL_OF_HEFIN = 23939;
  
  public static final int CRYSTAL_OF_AMLODD = 23941;
  
  public static final int ELVEN_SIGNET = 23943;
  
  public static final int ETERNAL_TELEPORT_CRYSTAL = 23946;
  
  public static final int ELVEN_DAWN = 23948;
  
  public static final int ENHANCED_CRYSTAL_KEY = 23951;
  
  public static final int CRYSTAL_TOOL_SEED = 23953;
  
  public static final int CRYSTAL_ARMOUR_SEED = 23956;
  
  public static final int ENHANCED_CRYSTAL_TELEPORT_SEED = 23959;
  
  public static final int CRYSTAL_SHARD = 23962;
  
  public static final int CRYSTAL_DUST_23964 = 23964;
  
  public static final int CRYSTAL_HELM = 23971;
  
  public static final int CRYSTAL_HELM_INACTIVE = 23973;
  
  public static final int CRYSTAL_BODY = 23975;
  
  public static final int CRYSTAL_BODY_INACTIVE = 23977;
  
  public static final int CRYSTAL_LEGS = 23979;
  
  public static final int CRYSTAL_LEGS_INACTIVE = 23981;
  
  public static final int CRYSTAL_BOW = 23983;
  
  public static final int CRYSTAL_BOW_INACTIVE = 23985;
  
  public static final int CRYSTAL_HALBERD = 23987;
  
  public static final int CRYSTAL_HALBERD_INACTIVE = 23989;
  
  public static final int CRYSTAL_SHIELD = 23991;
  
  public static final int CRYSTAL_SHIELD_INACTIVE = 23993;
  
  public static final int BLADE_OF_SAELDOR = 23995;
  
  public static final int BLADE_OF_SAELDOR_INACTIVE = 23997;
  
  public static final int CRYSTAL_GRAIL = 24000;
  
  public static final int ELVEN_BOOTS = 24003;
  
  public static final int ELVEN_GLOVES = 24006;
  
  public static final int ELVEN_TOP = 24009;
  
  public static final int ELVEN_SKIRT = 24012;
  
  public static final int ELVEN_TOP_24015 = 24015;
  
  public static final int ELVEN_SKIRT_24018 = 24018;
  
  public static final int ELVEN_TOP_24021 = 24021;
  
  public static final int ELVEN_LEGWEAR = 24024;
  
  public static final int ELVEN_TOP_24027 = 24027;
  
  public static final int MEMORIAM_CRYSTAL_1 = 24030;
  
  public static final int MEMORIAM_CRYSTAL_2 = 24031;
  
  public static final int MEMORIAM_CRYSTAL_3 = 24032;
  
  public static final int MEMORIAM_CRYSTAL_4 = 24033;
  
  public static final int DRAGONSTONE_FULL_HELM = 24034;
  
  public static final int DRAGONSTONE_PLATEBODY = 24037;
  
  public static final int DRAGONSTONE_PLATELEGS = 24040;
  
  public static final int DRAGONSTONE_BOOTS = 24043;
  
  public static final int DRAGONSTONE_GAUNTLETS = 24046;
  
  public static final int CRAZED_SCRIBBLES = 24049;
  
  public static final int A_DEAR_FRIEND = 24051;
  
  public static final int ON_LEPRECHAUNS = 24053;
  
  public static final int BLOODY_DIARY = 24055;
  
  public static final int THE_EIGHT_CLANS = 24057;
  
  public static final int GOLLWYNS_FINAL_STATEMENT = 24059;
  
  public static final int NIFF__HARRY = 24061;
  
  public static final int SOGGY_JOURNAL = 24063;
  
  public static final int EBRILLS_JOURNAL = 24065;
  
  public static final int STAINED_JOURNAL = 24067;
  
  public static final int THE_TRUTH_BEHIND_THE_MYTH_EXCERPT = 24069;
  
  public static final int THE_LIVING_STATUES = 24071;
  
  public static final int THE_SPURNED_DEMON = 24073;
  
  public static final int LEGENDS_OF_THE_MOUNTAIN = 24075;
  
  public static final int CRYSTAL_BOW_24123 = 24123;
  
  public static final int CRYSTAL_HALBERD_24125 = 24125;
  
  public static final int CRYSTAL_SHIELD_24127 = 24127;
  
  public static final int COMBAT_PATH_STARTER_KIT = 24130;
  
  public static final int COMBAT_PATH_VOUCHER = 24131;
  
  public static final int MARBLE_LECTERN = 24132;
  
  public static final int INFERNAL_MAX_CAPE_L = 24133;
  
  public static final int FIRE_MAX_CAPE_L = 24134;
  
  public static final int ASSEMBLER_MAX_CAPE_L = 24135;
  
  public static final int BRONZE_DEFENDER_L = 24136;
  
  public static final int IRON_DEFENDER_L = 24137;
  
  public static final int STEEL_DEFENDER_L = 24138;
  
  public static final int BLACK_DEFENDER_L = 24139;
  
  public static final int MITHRIL_DEFENDER_L = 24140;
  
  public static final int ADAMANT_DEFENDER_L = 24141;
  
  public static final int RUNE_DEFENDER_L = 24142;
  
  public static final int DRAGON_DEFENDER_L = 24143;
  
  public static final int STAFF_OF_BALANCE = 24144;
  
  public static final int ARMADYL_HALO_BROKEN = 24147;
  
  public static final int BANDOS_HALO_BROKEN = 24149;
  
  public static final int SEREN_HALO_BROKEN = 24151;
  
  public static final int ANCIENT_HALO_BROKEN = 24153;
  
  public static final int BRASSICA_HALO_BROKEN = 24155;
  
  public static final int DECORATIVE_SWORD_L = 24157;
  
  public static final int DECORATIVE_ARMOUR_L = 24158;
  
  public static final int DECORATIVE_ARMOUR_L_24159 = 24159;
  
  public static final int DECORATIVE_HELM_L = 24160;
  
  public static final int DECORATIVE_SHIELD_L = 24161;
  
  public static final int DECORATIVE_ARMOUR_L_24162 = 24162;
  
  public static final int DECORATIVE_ARMOUR_L_24163 = 24163;
  
  public static final int DECORATIVE_ARMOUR_L_24164 = 24164;
  
  public static final int DECORATIVE_ARMOUR_L_24165 = 24165;
  
  public static final int DECORATIVE_ARMOUR_L_24166 = 24166;
  
  public static final int DECORATIVE_ARMOUR_L_24167 = 24167;
  
  public static final int DECORATIVE_ARMOUR_L_24168 = 24168;
  
  public static final int SARADOMIN_HALO_L = 24169;
  
  public static final int ZAMORAK_HALO_L = 24170;
  
  public static final int GUTHIX_HALO_L = 24171;
  
  public static final int HEALER_HAT_L = 24172;
  
  public static final int FIGHTER_HAT_L = 24173;
  
  public static final int RANGER_HAT_L = 24174;
  
  public static final int FIGHTER_TORSO_L = 24175;
  
  public static final int PENANCE_SKIRT_L = 24176;
  
  public static final int VOID_KNIGHT_TOP_L = 24177;
  
  public static final int ELITE_VOID_TOP_L = 24178;
  
  public static final int VOID_KNIGHT_ROBE_L = 24179;
  
  public static final int ELITE_VOID_ROBE_L = 24180;
  
  public static final int VOID_KNIGHT_MACE_L = 24181;
  
  public static final int VOID_KNIGHT_GLOVES_L = 24182;
  
  public static final int VOID_MAGE_HELM_L = 24183;
  
  public static final int VOID_RANGER_HELM_L = 24184;
  
  public static final int VOID_MELEE_HELM_L = 24185;
  
  public static final int AVERNIC_DEFENDER_L = 24186;
  
  public static final int TROUVER_PARCHMENT = 24187;
  
  public static final int DEADMANS_CHEST_24189 = 24189;
  
  public static final int DEADMANS_LEGS_24190 = 24190;
  
  public static final int DEADMANS_CAPE_24191 = 24191;
  
  public static final int ARMADYL_HALO = 24192;
  
  public static final int ARMADYL_HALO_L = 24194;
  
  public static final int BANDOS_HALO = 24195;
  
  public static final int BANDOS_HALO_L = 24197;
  
  public static final int SEREN_HALO = 24198;
  
  public static final int SEREN_HALO_L = 24200;
  
  public static final int ANCIENT_HALO = 24201;
  
  public static final int ANCIENT_HALO_L = 24203;
  
  public static final int BRASSICA_HALO = 24204;
  
  public static final int BRASSICA_HALO_L = 24206;
  
  public static final int VICTORS_CAPE_1 = 24207;
  
  public static final int VICTORS_CAPE_10 = 24209;
  
  public static final int VICTORS_CAPE_50 = 24211;
  
  public static final int VICTORS_CAPE_100 = 24213;
  
  public static final int VICTORS_CAPE_500 = 24215;
  
  public static final int GUTHIXIAN_ICON = 24217;
  
  public static final int SWIFT_BLADE = 24219;
  
  public static final int AVAS_ASSEMBLER_L = 24222;
  
  public static final int FIRE_CAPE_L = 24223;
  
  public static final int INFERNAL_CAPE_L = 24224;
  
  public static final int GRANITE_MAUL_24225 = 24225;
  
  public static final int GRANITE_MAUL_24227 = 24227;
  
  public static final int ORNATE_MAUL_HANDLE = 24229;
  
  public static final int IMBUED_SARADOMIN_MAX_CAPE_L = 24232;
  
  public static final int IMBUED_ZAMORAK_MAX_CAPE_L = 24233;
  
  public static final int IMBUED_GUTHIX_MAX_CAPE_L = 24234;
  
  public static final int HOUSE_ADVERTISEMENT = 24235;
  
  public static final int IMBUED_SARADOMIN_CAPE_BROKEN = 24236;
  
  public static final int IMBUED_SARADOMIN_MAX_CAPE_BROKEN = 24238;
  
  public static final int IMBUED_GUTHIX_CAPE_BROKEN = 24240;
  
  public static final int IMBUED_GUTHIX_MAX_CAPE_BROKEN = 24242;
  
  public static final int IMBUED_ZAMORAK_CAPE_BROKEN = 24244;
  
  public static final int IMBUED_ZAMORAK_MAX_CAPE_BROKEN = 24246;
  
  public static final int IMBUED_SARADOMIN_CAPE_L = 24248;
  
  public static final int IMBUED_GUTHIX_CAPE_L = 24249;
  
  public static final int IMBUED_ZAMORAK_CAPE_L = 24250;
  
  public static final int WILDERNESS_CRABS_TELEPORT = 24251;
  
  public static final int CLUE_SCROLL_ELITE_24253 = 24253;
  
  public static final int FANG = 24254;
  
  public static final int VENOM_GLAND = 24255;
  
  public static final int UNSEALED_LETTER = 24256;
  
  public static final int UNSEALED_LETTER_24257 = 24257;
  
  public static final int V_SIGIL = 24258;
  
  public static final int V_SIGIL_E = 24259;
  
  public static final int MOLTEN_GLASS_I = 24260;
  
  public static final int LUNAR_GLASS = 24261;
  
  public static final int POLISHING_ROCK = 24262;
  
  public static final int BALLAD_OF_THE_BASILISK = 24263;
  
  public static final int VS_SHIELD = 24265;
  
  public static final int VS_SHIELD_24266 = 24266;
  
  public static final int BASILISK_JAW = 24268;
  
  public static final int NEITIZNOT_FACEGUARD = 24271;
  
  public static final int BASILISK_KNIGHT = 24276;
  
  public static final int MYSTERIOUS_EMBLEM_TIER_1 = 24277;
  
  public static final int MYSTERIOUS_EMBLEM_TIER_2 = 24279;
  
  public static final int MYSTERIOUS_EMBLEM_TIER_3 = 24281;
  
  public static final int MYSTERIOUS_EMBLEM_TIER_4 = 24283;
  
  public static final int MYSTERIOUS_EMBLEM_TIER_5 = 24285;
  
  public static final int DECORATIVE_EMBLEM = 24287;
  
  public static final int DAGONHAI_HAT = 24288;
  
  public static final int DAGONHAI_ROBE_TOP = 24291;
  
  public static final int DAGONHAI_ROBE_BOTTOM = 24294;
  
  public static final int WHITE_BED_SHEETS = 24297;
  
  public static final int SMOKE_POWDER = 24298;
  
  public static final int SHINY_GLASS = 24299;
  
  public static final int SPOOKY_HOOD = 24300;
  
  public static final int SPOOKY_ROBE = 24301;
  
  public static final int SPOOKY_SKIRT = 24302;
  
  public static final int SPOOKY_GLOVES = 24303;
  
  public static final int SPOOKY_BOOTS = 24304;
  
  public static final int SPOOKY_HOOD_24305 = 24305;
  
  public static final int SPOOKY_ROBE_24307 = 24307;
  
  public static final int SPOOKY_SKIRT_24309 = 24309;
  
  public static final int SPOOKY_GLOVES_24311 = 24311;
  
  public static final int SPOOKY_BOOTS_24313 = 24313;
  
  public static final int SPOOKIER_HOOD = 24315;
  
  public static final int SPOOKIER_ROBE = 24317;
  
  public static final int SPOOKIER_SKIRT = 24319;
  
  public static final int SPOOKIER_GLOVES = 24321;
  
  public static final int SPOOKIER_BOOTS = 24323;
  
  public static final int PUMPKIN_LANTERN = 24325;
  
  public static final int SKELETON_LANTERN = 24327;
  
  public static final int BOUNTY_CRATE = 24329;
  
  public static final int BIRTHDAY_CAKE_24331 = 24331;
  
  public static final int BIRTHDAY_CAKE_24332 = 24332;
  
  public static final int DAGONHAI_ROBES_SET = 24333;
  
  public static final int TARGET_TELEPORT = 24336;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_1 = 24338;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_2 = 24340;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_3 = 24342;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_4 = 24344;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_5 = 24346;
  
  public static final int BOUNTY_HUNTER_HAT_TIER_6 = 24348;
  
  public static final int SCROLL_BOX_BEGINNER = 24361;
  
  public static final int SCROLL_BOX_EASY = 24362;
  
  public static final int SCROLL_BOX_MEDIUM = 24363;
  
  public static final int SCROLL_BOX_HARD = 24364;
  
  public static final int SCROLL_BOX_ELITE = 24365;
  
  public static final int SCROLL_BOX_MASTER = 24366;
  
  public static final int CABBAGE_24367 = 24367;
  
  public static final int TWISTED_SLAYER_HELMET = 24370;
  
  public static final int TWISTED_DRAGON_TROPHY = 24372;
  
  public static final int TWISTED_RUNE_TROPHY = 24374;
  
  public static final int TWISTED_ADAMANT_TROPHY = 24376;
  
  public static final int TWISTED_MITHRIL_TROPHY = 24378;
  
  public static final int TWISTED_STEEL_TROPHY = 24380;
  
  public static final int TWISTED_IRON_TROPHY = 24382;
  
  public static final int TWISTED_BRONZE_TROPHY = 24384;
  
  public static final int TWISTED_HAT_T3 = 24387;
  
  public static final int TWISTED_COAT_T3 = 24389;
  
  public static final int TWISTED_TROUSERS_T3 = 24391;
  
  public static final int TWISTED_BOOTS_T3 = 24393;
  
  public static final int TWISTED_CANE = 24395;
  
  public static final int TWISTED_HAT_T2 = 24397;
  
  public static final int TWISTED_COAT_T2 = 24399;
  
  public static final int TWISTED_TROUSERS_T2 = 24401;
  
  public static final int TWISTED_BOOTS_T2 = 24403;
  
  public static final int TWISTED_HAT_T1 = 24405;
  
  public static final int TWISTED_COAT_T1 = 24407;
  
  public static final int TWISTED_TROUSERS_T1 = 24409;
  
  public static final int TWISTED_BOOTS_T1 = 24411;
  
  public static final int TWISTED_BANNER = 24413;
  
  public static final int RUNE_POUCH_L = 24416;
  
  public static final int INQUISITORS_MACE = 24417;
  
  public static final int GRAVESTONE = 24418;
  
  public static final int INQUISITORS_GREAT_HELM = 24419;
  
  public static final int INQUISITORS_HAUBERK = 24420;
  
  public static final int INQUISITORS_PLATESKIRT = 24421;
  
  public static final int NIGHTMARE_STAFF = 24422;
  
  public static final int HARMONISED_NIGHTMARE_STAFF = 24423;
  
  public static final int VOLATILE_NIGHTMARE_STAFF = 24424;
  
  public static final int ELDRITCH_NIGHTMARE_STAFF = 24425;
  
  public static final int CABBAGE_24426 = 24426;
  
  public static final int GREEN_GINGERBREAD_SHIELD = 24428;
  
  public static final int RED_GINGERBREAD_SHIELD = 24430;
  
  public static final int BLUE_GINGERBREAD_SHIELD = 24431;
  
  public static final int FESTIVE_CINNAMON_STICK = 24432;
  
  public static final int FESTIVE_GINGER_POWDER = 24433;
  
  public static final int FESTIVE_EGG = 24434;
  
  public static final int FESTIVE_POT = 24435;
  
  public static final int FESTIVE_FLOUR = 24436;
  
  public static final int GINGERBREAD_SHIELD = 24437;
  
  public static final int ICED_GINGERBREAD_SHIELD = 24438;
  
  public static final int ICED_GINGERBREAD_SHIELD_24439 = 24439;
  
  public static final int ICED_GINGERBREAD_SHIELD_24440 = 24440;
  
  public static final int SCAPERUNE_TELEPORT = 24441;
  
  public static final int BAKERY_STORAGE_KEY = 24442;
  
  public static final int GINGERBREAD_GNOME = 24443;
  
  public static final int TWISTED_SLAYER_HELMET_I = 24444;
  
  public static final int TWISTED_TELEPORT_SCROLL = 24460;
  
  public static final int TWISTED_BLUEPRINTS = 24463;
  
  public static final int TWISTED_HORNS = 24466;
  
  public static final int TWISTED_RELIC_HUNTER_T1_ARMOUR_SET = 24469;
  
  public static final int TWISTED_RELIC_HUNTER_T2_ARMOUR_SET = 24472;
  
  public static final int TWISTED_RELIC_HUNTER_T3_ARMOUR_SET = 24475;
  
  public static final int OPEN_HERB_SACK = 24478;
  
  public static final int SPICE_RACK = 24479;
  
  public static final int OPEN_COAL_BAG = 24480;
  
  public static final int OPEN_GEM_BAG = 24481;
  
  public static final int OPEN_SEED_BOX = 24482;
  
  public static final int PHOENIX_24483 = 24483;
  
  public static final int PHOENIX_24484 = 24484;
  
  public static final int PHOENIX_24485 = 24485;
  
  public static final int PHOENIX_24486 = 24486;
  
  public static final int INQUISITORS_ARMOUR_SET = 24488;
  
  public static final int LITTLE_NIGHTMARE = 24491;
  
  public static final int CLUE_SCROLL_HARD_24493 = 24493;
  
  public static final int PUZZLE_BOX_HARD_24494 = 24494;
  
  public static final int JAR_OF_DREAMS = 24495;
  
  public static final int HARMONISED_ORB = 24511;
  
  public static final int VOLATILE_ORB = 24514;
  
  public static final int ELDRITCH_ORB = 24517;
  
  public static final int VICTORS_CAPE_1000 = 24520;
  
  public static final int DEATHS_COFFER = 24523;
  
  public static final int GRAVESTONE_24524 = 24524;
  
  public static final int CAT_EARS = 24525;
  
  public static final int HELL_CAT_EARS = 24527;
  
  public static final int LAMP_OF_THE_GATHERER = 24528;
  
  public static final int HARMONY = 24529;
  
  public static final int RUNNER_HAT_BROKEN = 24531;
  
  public static final int RUNNER_HAT_L = 24533;
  
  public static final int MITHRIL_SEEDS_24534 = 24534;
  
  public static final int MAGIC_EGG_BALL = 24535;
  
  public static final int CARROT_SWORD = 24537;
  
  public static final int _24CARAT_SWORD = 24539;
  
  public static final int PAINTED_FAKE_MAGIC_EGG = 24541;
  
  public static final int UNPAINTED_FAKE_MAGIC_EGG = 24542;
  
  public static final int CONCH_SHELL = 24543;
  
  public static final int BROKEN_EGG = 24544;
  
  public static final int DUMMY_PORTAL = 24545;
  
  public static final int CARROT = 24546;
  
  public static final int BROKEN_GOAT_HORN = 24547;
  
  public static final int CAKE_24549 = 24549;
  
  public static final int BLADE_OF_SAELDOR_C = 24551;
  
  public static final int BLADE_OF_SAELDOR_C_24553 = 24553;
  
  public static final int PYROMANCER_SET = 24554;
  
  public static final int TANGLEROOT_24555 = 24555;
  
  public static final int TANGLEROOT_24557 = 24557;
  
  public static final int TANGLEROOT_24559 = 24559;
  
  public static final int TANGLEROOT_24561 = 24561;
  
  public static final int TANGLEROOT_24563 = 24563;
  
  public static final int ANTIQUE_EMBLEM_TIER_1 = 24565;
  
  public static final int ANTIQUE_EMBLEM_TIER_2 = 24567;
  
  public static final int ANTIQUE_EMBLEM_TIER_3 = 24569;
  
  public static final int ANTIQUE_EMBLEM_TIER_4 = 24571;
  
  public static final int ANTIQUE_EMBLEM_TIER_5 = 24573;
  
  public static final int ANTIQUE_EMBLEM_TIER_6 = 24575;
  
  public static final int ANTIQUE_EMBLEM_TIER_7 = 24577;
  
  public static final int ANTIQUE_EMBLEM_TIER_8 = 24579;
  
  public static final int ANTIQUE_EMBLEM_TIER_9 = 24581;
  
  public static final int ANTIQUE_EMBLEM_TIER_10 = 24583;
  
  public static final int LOOTING_BAG_NOTE = 24585;
  
  public static final int RUNE_POUCH_NOTE = 24587;
  
  public static final int BLIGHTED_MANTA_RAY = 24589;
  
  public static final int BLIGHTED_ANGLERFISH = 24592;
  
  public static final int BLIGHTED_KARAMBWAN = 24595;
  
  public static final int BLIGHTED_SUPER_RESTORE4 = 24598;
  
  public static final int BLIGHTED_SUPER_RESTORE3 = 24601;
  
  public static final int BLIGHTED_SUPER_RESTORE2 = 24603;
  
  public static final int BLIGHTED_SUPER_RESTORE1 = 24605;
  
  public static final int BLIGHTED_ANCIENT_ICE_SACK = 24607;
  
  public static final int BLIGHTED_ENTANGLE_SACK = 24613;
  
  public static final int BLIGHTED_TELEPORT_SPELL_SACK = 24615;
  
  public static final int VESTAS_BLIGHTED_LONGSWORD = 24617;
  
  public static final int VESTAS_LONGSWORD_INACTIVE = 24619;
  
  public static final int BLIGHTED_VENGEANCE_SACK = 24621;
  
  public static final int DIVINE_BATTLEMAGE_POTION4 = 24623;
  
  public static final int DIVINE_BATTLEMAGE_POTION3 = 24626;
  
  public static final int DIVINE_BATTLEMAGE_POTION2 = 24629;
  
  public static final int DIVINE_BATTLEMAGE_POTION1 = 24632;
  
  public static final int DIVINE_BASTION_POTION4 = 24635;
  
  public static final int DIVINE_BASTION_POTION3 = 24638;
  
  public static final int DIVINE_BASTION_POTION2 = 24641;
  
  public static final int DIVINE_BASTION_POTION1 = 24644;
  
  public static final int LOGS_24650 = 24650;
  
  public static final int RAW_SHRIMPS_24652 = 24652;
  
  public static final int BONES_24655 = 24655;
  
  public static final int ENRAGED_TEKTINY = 24656;
  
  public static final int FLYING_VESPINA = 24658;
  
  public static final int MASSIVE_STORAGE_UNIT = 24660;
  
  public static final int MASSIVE_STORAGE_UNIT_24661 = 24661;
  
  public static final int MASSIVE_STORAGE_UNIT_24662 = 24662;
  
  public static final int MASSIVE_STORAGE_UNIT_24663 = 24663;
  
  public static final int TWISTED_ANCESTRAL_HAT = 24664;
  
  public static final int TWISTED_ANCESTRAL_ROBE_TOP = 24666;
  
  public static final int TWISTED_ANCESTRAL_ROBE_BOTTOM = 24668;
  
  public static final int TWISTED_ANCESTRAL_COLOUR_KIT = 24670;
  
  public static final int HAEMALCHEMY_VOLUME_2 = 24672;
  
  public static final int VYRE_NOBLE_TOP_UNSCENTED = 24673;
  
  public static final int VYRE_NOBLE_LEGS_UNSCENTED = 24674;
  
  public static final int VYRE_NOBLE_SHOES_UNSCENTED = 24675;
  
  public static final int VYRE_NOBLE_TOP = 24676;
  
  public static final int VYRE_NOBLE_LEGS = 24678;
  
  public static final int VYRE_NOBLE_SHOES = 24680;
  
  public static final int OLD_NOTE = 24682;
  
  public static final int TATTY_NOTE_24684 = 24684;
  
  public static final int JOURNAL_PAGE = 24686;
  
  public static final int ANCIENT_ARMOUR = 24688;
  
  public static final int TOME_OF_EXPERIENCE_24690 = 24690;
  
  public static final int BLISTERWOOD_LOGS = 24691;
  
  public static final int RUBY_SICKLE_B = 24693;
  
  public static final int ENCHANTED_RUBY_SICKLE_B = 24695;
  
  public static final int BLISTERWOOD_SICKLE = 24697;
  
  public static final int BLISTERWOOD_FLAIL = 24699;
  
  public static final int DARK_SQUIRREL = 24701;
  
  public static final int VYRE = 24702;
  
  public static final int COIN_POUCH_24703 = 24703;
  
  public static final int DAEYALT_ESSENCE = 24704;
  
  public static final int DAEYALT_SHARD = 24706;
  
  public static final int VAMPYRE = 24708;
  
  public static final int HALLOWED_CRYSTAL_SHARD = 24709;
  
  public static final int HALLOWED_MARK = 24711;
  
  public static final int HALLOWED_TOKEN = 24719;
  
  public static final int HALLOWED_GRAPPLE = 24721;
  
  public static final int HALLOWED_FOCUS = 24723;
  
  public static final int HALLOWED_SYMBOL = 24725;
  
  public static final int HALLOWED_HAMMER = 24727;
  
  public static final int DARK_DYE = 24729;
  
  public static final int HALLOWED_RING = 24731;
  
  public static final int DARK_ACORN = 24733;
  
  public static final int RING_OF_ENDURANCE_UNCHARGED = 24735;
  
  public static final int RING_OF_ENDURANCE = 24736;
  
  public static final int STRANGE_OLD_LOCKPICK = 24738;
  
  public static final int STRANGE_OLD_LOCKPICK_FULL = 24740;
  
  public static final int GRACEFUL_HOOD_24743 = 24743;
  
  public static final int GRACEFUL_HOOD_24745 = 24745;
  
  public static final int GRACEFUL_CAPE_24746 = 24746;
  
  public static final int GRACEFUL_CAPE_24748 = 24748;
  
  public static final int GRACEFUL_TOP_24749 = 24749;
  
  public static final int GRACEFUL_TOP_24751 = 24751;
  
  public static final int GRACEFUL_LEGS_24752 = 24752;
  
  public static final int GRACEFUL_LEGS_24754 = 24754;
  
  public static final int GRACEFUL_GLOVES_24755 = 24755;
  
  public static final int GRACEFUL_GLOVES_24757 = 24757;
  
  public static final int GRACEFUL_BOOTS_24758 = 24758;
  
  public static final int GRACEFUL_BOOTS_24760 = 24760;
  
  public static final int STRANGE_HALLOWED_TOME = 24761;
  
  public static final int MYSTERIOUS_PAGE = 24763;
  
  public static final int MYSTERIOUS_PAGE_24765 = 24765;
  
  public static final int MYSTERIOUS_PAGE_24767 = 24767;
  
  public static final int MYSTERIOUS_PAGE_24769 = 24769;
  
  public static final int MYSTERIOUS_PAGE_24771 = 24771;
  
  public static final int CLUE_SCROLL_ELITE_24773 = 24773;
  
  public static final int BLOOD_PINT = 24774;
  
  public static final int BLOOD_SHARD = 24777;
  
  public static final int AMULET_OF_BLOOD_FURY = 24780;
  
  public static final int RAW_MYSTERY_MEAT = 24782;
  
  public static final int COOKED_MYSTERY_MEAT = 24785;
  
  public static final int PAT_OF_NOT_GARLIC_BUTTER = 24788;
  
  public static final int LONG_ROPE = 24790;
  
  public static final int SEVERED_LEG_24792 = 24792;
  
  public static final int VYRE_NOBLE_BLAZER = 24794;
  
  public static final int VYRE_NOBLE_COAT_TAILS = 24796;
  
  public static final int VYRE_NOBLE_VEST = 24798;
  
  public static final int VYRE_NOBLE_PANTS = 24800;
  
  public static final int VYRE_NOBLE_CORSET = 24802;
  
  public static final int VYRE_NOBLE_SKIRT = 24804;
  
  public static final int VYRE_NOBLE_DRESS_TOP = 24806;
  
  public static final int VYRE_NOBLE_DRESS_BOTTOM = 24808;
  
  public static final int VYRE_NOBLE_BLAZER_24810 = 24810;
  
  public static final int VYRE_NOBLE_COAT_TAILS_24812 = 24812;
  
  public static final int VYRE_NOBLE_VEST_24814 = 24814;
  
  public static final int VYRE_NOBLE_PANTS_24816 = 24816;
  
  public static final int VYRE_NOBLE_CORSET_24818 = 24818;
  
  public static final int VYRE_NOBLE_SKIRT_24820 = 24820;
  
  public static final int VYRE_NOBLE_DRESS_TOP_24822 = 24822;
  
  public static final int VYRE_NOBLE_DRESS_BOTTOM_24824 = 24824;
  
  public static final int VYRE_NOBLE_BLAZER_24826 = 24826;
  
  public static final int VYRE_NOBLE_COAT_TAILS_24828 = 24828;
  
  public static final int VYRE_NOBLE_VEST_24830 = 24830;
  
  public static final int VYRE_NOBLE_PANTS_24832 = 24832;
  
  public static final int VYRE_NOBLE_CORSET_24834 = 24834;
  
  public static final int VYRE_NOBLE_SKIRT_24836 = 24836;
  
  public static final int VYRE_NOBLE_DRESS_TOP_24838 = 24838;
  
  public static final int VYRE_NOBLE_DRESS_BOTTOM_24840 = 24840;
  
  public static final int A_TASTE_OF_HOPE = 24842;
  
  public static final int RING_OF_ENDURANCE_UNCHARGED_24844 = 24844;
  
  public static final int RED = 24847;
  
  public static final int ZIGGY = 24849;
  
  public static final int SOFT_CLAY_PACK_24851 = 24851;
  
  public static final int BAG_FULL_OF_GEMS_24853 = 24853;
  
  public static final int MYTHICAL_MAX_CAPE = 24855;
  
  public static final int MYTHICAL_MAX_HOOD = 24857;
  
  public static final int WARRIOR_PATH_STARTER_KIT = 24859;
  
  public static final int WIZARD_PATH_STARTER_KIT = 24860;
  
  public static final int RANGER_PATH_STARTER_KIT = 24861;
  
  public static final int KARAMJAN_MONKEY = 24862;
  
  public static final int ZOMBIE_MONKEY = 24863;
  
  public static final int MANIACAL_MONKEY = 24864;
  
  public static final int SKELETON_MONKEY = 24865;
  
  public static final int KRUK_JR = 24866;
  
  public static final int PRINCELY_MONKEY = 24867;
  
  public static final int GOLDEN_ARMADYL_SPECIAL_ATTACK = 24868;
  
  public static final int GOLDEN_BANDOS_SPECIAL_ATTACK = 24869;
  
  public static final int GOLDEN_SARADOMIN_SPECIAL_ATTACK = 24870;
  
  public static final int GOLDEN_ZAMORAK_SPECIAL_ATTACK = 24871;
  
  public static final int CARPENTERS_HELMET = 24872;
  
  public static final int CARPENTERS_SHIRT = 24874;
  
  public static final int CARPENTERS_TROUSERS = 24876;
  
  public static final int CARPENTERS_BOOTS = 24878;
  
  public static final int AMYS_SAW = 24880;
  
  public static final int PLANK_SACK = 24882;
  
  public static final int SUPPLY_CRATE_24884 = 24884;
  
  public static final int HOSIDIUS_BLUEPRINTS = 24885;
  
  public static final int WOODEN_TABLE_24886 = 24886;
  
  public static final int OAK_TABLE = 24887;
  
  public static final int TEAK_TABLE_24888 = 24888;
  
  public static final int MAHOGANY_TABLE_24889 = 24889;
  
  public static final int WOODEN_TABLE_24890 = 24890;
  
  public static final int OAK_TABLE_24891 = 24891;
  
  public static final int TEAK_TABLE_24892 = 24892;
  
  public static final int MAHOGANY_TABLE_24893 = 24893;
  
  public static final int WOODEN_TABLE_24894 = 24894;
  
  public static final int OAK_TABLE_24895 = 24895;
  
  public static final int TEAK_TABLE_24896 = 24896;
  
  public static final int MAHOGANY_TABLE_24897 = 24897;
  
  public static final int WOODEN_CABINET = 24898;
  
  public static final int OAK_CABINET = 24899;
  
  public static final int TEAK_CABINET = 24900;
  
  public static final int MAHOGANY_CABINET = 24901;
  
  public static final int WOODEN_BOOKCASE_24902 = 24902;
  
  public static final int OAK_BOOKCASE_24903 = 24903;
  
  public static final int TEAK_BOOKCASE = 24904;
  
  public static final int MAHOGANY_BOOKCASE_24905 = 24905;
  
  public static final int WOODEN_WARDROBE = 24906;
  
  public static final int OAK_WARDROBE_24907 = 24907;
  
  public static final int TEAK_WARDROBE_24908 = 24908;
  
  public static final int MAHOGANY_WARDROBE_24909 = 24909;
  
  public static final int WOODEN_DRESSER = 24910;
  
  public static final int OAK_DRESSER_24911 = 24911;
  
  public static final int TEAK_DRESSER_24912 = 24912;
  
  public static final int MAHOGANY_DRESSER_24913 = 24913;
  
  public static final int WOODEN_SHELVES = 24914;
  
  public static final int OAK_SHELVES = 24915;
  
  public static final int TEAK_SHELVES = 24916;
  
  public static final int MAHOGANY_SHELVES = 24917;
  
  public static final int WOODEN_BED_24918 = 24918;
  
  public static final int OAK_BED_24919 = 24919;
  
  public static final int TEAK_BED_24920 = 24920;
  
  public static final int MAHOGANY_BED = 24921;
  
  public static final int WOODEN_BED_24922 = 24922;
  
  public static final int OAK_BED_24923 = 24923;
  
  public static final int TEAK_BED_24924 = 24924;
  
  public static final int MAHOGANY_BED_24925 = 24925;
  
  public static final int WOODEN_DRAWER = 24926;
  
  public static final int OAK_DRAWER = 24927;
  
  public static final int TEAK_DRAWER = 24928;
  
  public static final int MAHOGANY_DRAWER = 24929;
  
  public static final int WOODEN_CHAIR_24930 = 24930;
  
  public static final int OAK_CHAIR_24931 = 24931;
  
  public static final int TEAK_CHAIR = 24932;
  
  public static final int MAHOGANY_CHAIR = 24933;
  
  public static final int WOODEN_CUPBOARD = 24934;
  
  public static final int OAK_CUPBOARD = 24935;
  
  public static final int TEAK_CUPBOARD = 24936;
  
  public static final int MAHOGANY_CUPBOARD = 24937;
  
  public static final int WAXWOOD_LOG = 24938;
  
  public static final int WAXWOOD_PLANK = 24939;
  
  public static final int MARLOS_CRATE = 24940;
  
  public static final int BP_OBJ = 24941;
  
  public static final int REINFORCED_GOGGLES = 24942;
  
  public static final int SOURHOG_FOOT = 24944;
  
  public static final int HALLOWED_SACK = 24946;
  
  public static final int MOONCLAN_TELEPORT = 24949;
  
  public static final int OURANIA_TELEPORT = 24951;
  
  public static final int WATERBIRTH_TELEPORT = 24953;
  
  public static final int BARBARIAN_TELEPORT = 24955;
  
  public static final int KHAZARD_TELEPORT = 24957;
  
  public static final int FISHING_GUILD_TELEPORT = 24959;
  
  public static final int CATHERBY_TELEPORT = 24961;
  
  public static final int ICE_PLATEAU_TELEPORT = 24963;
  
  public static final int CABBAGE_24971 = 24971;
  
  public static final int CABBAGE_24973 = 24973;
  
  public static final int HEADLESS_HEAD = 24975;
  
  public static final int MAGICAL_PUMPKIN = 24977;
  
  public static final int PUMPKIN_24979 = 24979;
  
  public static final int BROWN_CANDY = 24980;
  
  public static final int BLUE_CANDY = 24981;
  
  public static final int WHITE_CANDY = 24982;
  
  public static final int PURPLE_CANDY = 24983;
  
  public static final int RED_CANDY = 24984;
  
  public static final int GREEN_CANDY = 24985;
  
  public static final int BLACK_CANDY = 24986;
  
  public static final int ORANGE_CANDY = 24987;
  
  public static final int PINK_CANDY = 24988;
  
  public static final int RICKS_BOX = 24989;
  
  public static final int RICKS_HEAD = 24990;
  
  public static final int WITCHS_BREW = 24991;
  
  public static final int SPIDER_SNACK = 24992;
  
  public static final int INCANTATION = 24993;
  
  public static final int CABBAGE_24994 = 24994;
  
  public static final int CABBAGE_24996 = 24996;
  
  public static final int TRAILBLAZER_HOOD_T3 = 25001;
  
  public static final int TRAILBLAZER_TOP_T3 = 25004;
  
  public static final int TRAILBLAZER_TROUSERS_T3 = 25007;
  
  public static final int TRAILBLAZER_BOOTS_T3 = 25010;
  
  public static final int TRAILBLAZER_CANE = 25013;
  
  public static final int TRAILBLAZER_HOOD_T2 = 25016;
  
  public static final int TRAILBLAZER_TOP_T2 = 25019;
  
  public static final int TRAILBLAZER_TROUSERS_T2 = 25022;
  
  public static final int TRAILBLAZER_BOOTS_T2 = 25025;
  
  public static final int TRAILBLAZER_HOOD_T1 = 25028;
  
  public static final int TRAILBLAZER_TOP_T1 = 25031;
  
  public static final int TRAILBLAZER_TROUSERS_T1 = 25034;
  
  public static final int TRAILBLAZER_BOOTS_T1 = 25037;
  
  public static final int TRAILBLAZER_DRAGON_TROPHY = 25042;
  
  public static final int TRAILBLAZER_RUNE_TROPHY = 25044;
  
  public static final int TRAILBLAZER_ADAMANT_TROPHY = 25046;
  
  public static final int TRAILBLAZER_MITHRIL_TROPHY = 25048;
  
  public static final int TRAILBLAZER_STEEL_TROPHY = 25050;
  
  public static final int TRAILBLAZER_IRON_TROPHY = 25052;
  
  public static final int TRAILBLAZER_BRONZE_TROPHY = 25054;
  
  public static final int TRAILBLAZER_BANNER = 25056;
  
  public static final int INFERNAL_HARPOON_OR = 25059;
  
  public static final int INFERNAL_PICKAXE_OR = 25063;
  
  public static final int INFERNAL_AXE_OR = 25066;
  
  public static final int GRACEFUL_HOOD_25069 = 25069;
  
  public static final int GRACEFUL_HOOD_25071 = 25071;
  
  public static final int GRACEFUL_CAPE_25072 = 25072;
  
  public static final int GRACEFUL_CAPE_25074 = 25074;
  
  public static final int GRACEFUL_TOP_25075 = 25075;
  
  public static final int GRACEFUL_TOP_25077 = 25077;
  
  public static final int GRACEFUL_LEGS_25078 = 25078;
  
  public static final int GRACEFUL_LEGS_25080 = 25080;
  
  public static final int GRACEFUL_GLOVES_25081 = 25081;
  
  public static final int GRACEFUL_GLOVES_25083 = 25083;
  
  public static final int GRACEFUL_BOOTS_25084 = 25084;
  
  public static final int GRACEFUL_BOOTS_25086 = 25086;
  
  public static final int TRAILBLAZER_TELEPORT_SCROLL = 25087;
  
  public static final int TRAILBLAZER_TOOL_ORNAMENT_KIT = 25090;
  
  public static final int TRAILBLAZER_GLOBE = 25093;
  
  public static final int TRAILBLAZER_RUG = 25096;
  
  public static final int TRAILBLAZER_GRACEFUL_ORNAMENT_KIT = 25099;
  
  public static final int FAIRY_MUSHROOM = 25102;
  
  public static final int CRYSTAL_OF_ECHOES = 25104;
  
  public static final int EXTRADIMENSIONAL_BAG = 25106;
  
  public static final int EXTRADIMENSIONAL_BAG_25108 = 25108;
  
  public static final int ECHO_AXE = 25110;
  
  public static final int ECHO_PICKAXE = 25112;
  
  public static final int ECHO_HARPOON = 25114;
  
  public static final int LEAGUE_TOMATO = 25117;
  
  public static final int BEEKEEPERS_HAT = 25129;
  
  public static final int BEEKEEPERS_TOP = 25131;
  
  public static final int BEEKEEPERS_LEGS = 25133;
  
  public static final int BEEKEEPERS_GLOVES = 25135;
  
  public static final int BEEKEEPERS_BOOTS = 25137;
  
  public static final int BONE_FRAGMENTS = 25139;
  
  public static final int CLAY_HEAD = 25145;
  
  public static final int FUR_HEAD = 25146;
  
  public static final int BLOODY_HEAD = 25147;
  
  public static final int NEILANS_JOURNAL = 25152;
  
  public static final int ORNATE_UNDEAD_COMBAT_DUMMY = 25154;
  
  public static final int DECORATIVE_BOOTS_BROKEN = 25155;
  
  public static final int DECORATIVE_FULL_HELM_BROKEN = 25157;
  
  public static final int CASTLEWARS_BREW4 = 25159;
  
  public static final int CASTLEWARS_BREW3 = 25160;
  
  public static final int CASTLEWARS_BREW2 = 25161;
  
  public static final int CASTLEWARS_BREW1 = 25162;
  
  public static final int DECORATIVE_BOOTS = 25163;
  
  public static final int DECORATIVE_FULL_HELM = 25165;
  
  public static final int DECORATIVE_BOOTS_25167 = 25167;
  
  public static final int DECORATIVE_FULL_HELM_25169 = 25169;
  
  public static final int DECORATIVE_BOOTS_25171 = 25171;
  
  public static final int DECORATIVE_BOOTS_L = 25173;
  
  public static final int DECORATIVE_FULL_HELM_25174 = 25174;
  
  public static final int DECORATIVE_FULL_HELM_L = 25176;
  
  public static final int SLAYER_HELMET_I_25177 = 25177;
  
  public static final int BLACK_SLAYER_HELMET_I_25179 = 25179;
  
  public static final int GREEN_SLAYER_HELMET_I_25181 = 25181;
  
  public static final int RED_SLAYER_HELMET_I_25183 = 25183;
  
  public static final int PURPLE_SLAYER_HELMET_I_25185 = 25185;
  
  public static final int TURQUOISE_SLAYER_HELMET_I_25187 = 25187;
  
  public static final int HYDRA_SLAYER_HELMET_I_25189 = 25189;
  
  public static final int TWISTED_SLAYER_HELMET_I_25191 = 25191;
  
  public static final int GRANITE_RING_I_25193 = 25193;
  
  public static final int BLUE_CAPE_25195 = 25195;
  
  public static final int SOUL_FRAGMENT = 25196;
  
  public static final int SOUL_WARS_GUIDE = 25197;
  
  public static final int BONES_25199 = 25199;
  
  public static final int SOUL_FRAGMENT_25201 = 25201;
  
  public static final int BANDAGES_25202 = 25202;
  
  public static final int POTION_OF_POWER4 = 25203;
  
  public static final int POTION_OF_POWER3 = 25204;
  
  public static final int POTION_OF_POWER2 = 25205;
  
  public static final int POTION_OF_POWER1 = 25206;
  
  public static final int RED_CAPE_25207 = 25207;
  
  public static final int BLUE_CAPE_25208 = 25208;
  
  public static final int BARRICADE_25209 = 25209;
  
  public static final int BARRICADE_25210 = 25210;
  
  public static final int EXPLOSIVE_POTION_25211 = 25211;
  
  public static final int BLUE_ICON = 25212;
  
  public static final int BLUE_ICON_25213 = 25213;
  
  public static final int BLUE_ICON_25214 = 25214;
  
  public static final int BLUE_ICON_25215 = 25215;
  
  public static final int BLUE_ICON_25216 = 25216;
  
  public static final int BLUE_ICON_25217 = 25217;
  
  public static final int BLUE_ICON_25218 = 25218;
  
  public static final int BLUE_ICON_25219 = 25219;
  
  public static final int BLUE_ICON_25220 = 25220;
  
  public static final int BLUE_ICON_25221 = 25221;
  
  public static final int BLUE_ICON_25222 = 25222;
  
  public static final int BLUE_ICON_25223 = 25223;
  
  public static final int BLUE_ICON_25224 = 25224;
  
  public static final int BLUE_ICON_25225 = 25225;
  
  public static final int BLUE_ICON_25226 = 25226;
  
  public static final int BLUE_ICON_25227 = 25227;
  
  public static final int RED_ICON = 25228;
  
  public static final int RED_ICON_25229 = 25229;
  
  public static final int RED_ICON_25230 = 25230;
  
  public static final int RED_ICON_25231 = 25231;
  
  public static final int RED_ICON_25232 = 25232;
  
  public static final int RED_ICON_25233 = 25233;
  
  public static final int RED_ICON_25234 = 25234;
  
  public static final int RED_ICON_25235 = 25235;
  
  public static final int RED_ICON_25236 = 25236;
  
  public static final int RED_ICON_25237 = 25237;
  
  public static final int RED_ICON_25238 = 25238;
  
  public static final int RED_ICON_25239 = 25239;
  
  public static final int RED_ICON_25240 = 25240;
  
  public static final int RED_ICON_25241 = 25241;
  
  public static final int RED_ICON_25242 = 25242;
  
  public static final int RED_ICON_25243 = 25243;
  
  public static final int DARK_KEY = 25244;
  
  public static final int RING_OF_SUFFERING_I_25246 = 25246;
  
  public static final int RING_OF_SUFFERING_RI_25248 = 25248;
  
  public static final int SALVE_AMULETI_25250 = 25250;
  
  public static final int RING_OF_THE_GODS_I_25252 = 25252;
  
  public static final int TYRANNICAL_RING_I_25254 = 25254;
  
  public static final int TREASONOUS_RING_I_25256 = 25256;
  
  public static final int SEERS_RING_I_25258 = 25258;
  
  public static final int ARCHERS_RING_I_25260 = 25260;
  
  public static final int WARRIOR_RING_I_25262 = 25262;
  
  public static final int BERSERKER_RING_I_25264 = 25264;
  
  public static final int BLACK_MASK_10_I_25266 = 25266;
  
  public static final int BLACK_MASK_9_I_25267 = 25267;
  
  public static final int BLACK_MASK_8_I_25268 = 25268;
  
  public static final int BLACK_MASK_7_I_25269 = 25269;
  
  public static final int BLACK_MASK_6_I_25270 = 25270;
  
  public static final int BLACK_MASK_5_I_25271 = 25271;
  
  public static final int BLACK_MASK_4_I_25272 = 25272;
  
  public static final int BLACK_MASK_3_I_25273 = 25273;
  
  public static final int BLACK_MASK_2_I_25274 = 25274;
  
  public static final int BLACK_MASK_1_I_25275 = 25275;
  
  public static final int BLACK_MASK_I_25276 = 25276;
  
  public static final int SALVE_AMULETEI_25278 = 25278;
  
  public static final int ESSENCE_PACK = 25280;
  
  public static final int SLED_25282 = 25282;
  
  public static final int RED_FIREFLIES = 25283;
  
  public static final int GREEN_FIREFLIES = 25284;
  
  public static final int STICK_25285 = 25285;
  
  public static final int MOULDY_SAWDUST = 25286;
  
  public static final int ROTTEN_MEAT = 25287;
  
  public static final int STALE_BREAD = 25288;
  
  public static final int GOBLIN_STEW = 25289;
  
  public static final int GOBLIN_GIFTS = 25290;
  
  public static final int GIANT_BOULDER = 25314;
  
  public static final int GOBLIN_DECORATIONS = 25316;
  
  public static final int GNOME_CHILD_ICON = 25319;
  
  public static final int _20TH_ANNIVERSARY_HAT = 25322;
  
  public static final int _20TH_ANNIVERSARY_TOP = 25324;
  
  public static final int _20TH_ANNIVERSARY_BOTTOM = 25326;
  
  public static final int _20TH_ANNIVERSARY_BOOTS = 25328;
  
  public static final int _20TH_ANNIVERSARY_GLOVES = 25330;
  
  public static final int _20TH_ANNIVERSARY_NECKLACE = 25332;
  
  public static final int _20TH_ANNIVERSARY_CAPE = 25334;
  
  public static final int GNOME_CHILD_MASK = 25336;
  
  public static final int GNOME_CHILD_ICON_25338 = 25338;
  
  public static final int ECTOPLASMATOR = 25340;
  
  public static final int SPOILS_OF_WAR = 25342;
  
  public static final int SOUL_CAPE = 25344;
  
  public static final int SOUL_CAPE_25346 = 25346;
  
  public static final int LIL_CREATOR = 25348;
  
  public static final int LIL_DESTRUCTOR = 25350;
  
  public static final int TROPHY_PEDESTAL = 25351;
  
  public static final int ORNATE_TROPHY_PEDESTAL = 25352;
  
  public static final int OAK_TROPHY_CASE = 25353;
  
  public static final int MAHOGANY_TROPHY_CASE = 25354;
  
  public static final int BANNER_STAND = 25355;
  
  public static final int ORNATE_BANNER_STAND = 25356;
  
  public static final int OAK_OUTFIT_STAND = 25357;
  
  public static final int MAHOGANY_OUTFIT_STAND = 25358;
  
  public static final int LEAGUE_STATUE = 25359;
  
  public static final int ORNATE_LEAGUE_STATUE = 25360;
  
  public static final int TRAILBLAZER_GLOBE_25361 = 25361;
  
  public static final int RUG_25362 = 25362;
  
  public static final int OPULENT_RUG_25363 = 25363;
  
  public static final int TRAILBLAZER_RUG_25364 = 25364;
  
  public static final int LEAGUE_ACCOMPLISHMENTS_SCROLL = 25365;
  
  public static final int LEAGUE_HALL = 25366;
  
  public static final int INFERNAL_HARPOON_UNCHARGED_25367 = 25367;
  
  public static final int INFERNAL_PICKAXE_UNCHARGED_25369 = 25369;
  
  public static final int INFERNAL_AXE_UNCHARGED_25371 = 25371;
  
  public static final int DRAGON_HARPOON_OR = 25373;
  
  public static final int DRAGON_PICKAXE_OR_25376 = 25376;
  
  public static final int DRAGON_AXE_OR = 25378;
  
  public static final int TRAILBLAZER_RELIC_HUNTER_T1_ARMOUR_SET = 25380;
  
  public static final int TRAILBLAZER_RELIC_HUNTER_T2_ARMOUR_SET = 25383;
  
  public static final int TRAILBLAZER_RELIC_HUNTER_T3_ARMOUR_SET = 25386;
  
  public static final int SWAMPBARK_BODY = 25389;
  
  public static final int SWAMPBARK_GAUNTLETS = 25392;
  
  public static final int SWAMPBARK_BOOTS = 25395;
  
  public static final int SWAMPBARK_HELM = 25398;
  
  public static final int SWAMPBARK_LEGS = 25401;
  
  public static final int BLOODBARK_BODY = 25404;
  
  public static final int BLOODBARK_GAUNTLETS = 25407;
  
  public static final int BLOODBARK_BOOTS = 25410;
  
  public static final int BLOODBARK_HELM = 25413;
  
  public static final int BLOODBARK_LEGS = 25416;
  
  public static final int URIUM_REMAINS = 25419;
  
  public static final int BLEACHED_BONES = 25422;
  
  public static final int GOLD_KEY_RED = 25424;
  
  public static final int GOLD_KEY_BROWN = 25426;
  
  public static final int GOLD_KEY_CRIMSON = 25428;
  
  public static final int GOLD_KEY_BLACK = 25430;
  
  public static final int GOLD_KEY_PURPLE = 25432;
  
  public static final int ZEALOTS_ROBE_TOP = 25434;
  
  public static final int ZEALOTS_ROBE_BOTTOM = 25436;
  
  public static final int ZEALOTS_HELM = 25438;
  
  public static final int ZEALOTS_BOOTS = 25440;
  
  public static final int BRONZE_LOCKS = 25442;
  
  public static final int STEEL_LOCKS = 25445;
  
  public static final int BLACK_LOCKS = 25448;
  
  public static final int SILVER_LOCKS = 25451;
  
  public static final int GOLD_LOCKS = 25454;
  
  public static final int BROKEN_COFFIN = 25457;
  
  public static final int BRONZE_COFFIN = 25459;
  
  public static final int STEEL_COFFIN = 25461;
  
  public static final int BLACK_COFFIN = 25463;
  
  public static final int SILVER_COFFIN = 25465;
  
  public static final int GOLD_COFFIN = 25467;
  
  public static final int OPEN_BRONZE_COFFIN = 25469;
  
  public static final int OPEN_STEEL_COFFIN = 25470;
  
  public static final int OPEN_BLACK_COFFIN = 25471;
  
  public static final int OPEN_SILVER_COFFIN = 25472;
  
  public static final int OPEN_GOLD_COFFIN = 25473;
  
  public static final int TREE_WIZARDS_JOURNAL = 25474;
  
  public static final int BLOODY_NOTES = 25476;
  
  public static final int RUNESCROLL_OF_SWAMPBARK = 25478;
  
  public static final int RUNESCROLL_OF_BLOODBARK = 25481;
  
  public static final int SOULREAPER_AXE = 25484;
  
  public static final int ULTOR_RING = 25485;
  
  public static final int MAGUS_RING = 25486;
  
  public static final int VENATOR_RING = 25487;
  
  public static final int BELLATOR_RING = 25488;
  
  public static final int BLOOD_ANCIENT_SCEPTRE = 25489;
  
  public static final int ICE_ANCIENT_SCEPTRE = 25490;
  
  public static final int SMOKE_ANCIENT_SCEPTRE = 25491;
  
  public static final int SHADOW_ANCIENT_SCEPTRE = 25492;
  
  public static final int BLACK_DHIDE_CHAPS_BETA = 25493;
  
  public static final int BLACK_DHIDE_VAMBRACES_BETA = 25494;
  
  public static final int CRYSTAL_HELM_BETA = 25495;
  
  public static final int CRYSTAL_BODY_BETA = 25496;
  
  public static final int CRYSTAL_LEGS_BETA = 25497;
  
  public static final int CLUE_SCROLL_ELITE_25498 = 25498;
  
  public static final int CLUE_SCROLL_ELITE_25499 = 25499;
  
  public static final int CURSED_BANANA = 25500;
  
  public static final int BANANA_CAPE = 25502;
  
  public static final int DHAROKS_PLATEBODY_25515 = 25515;
  
  public static final int DHAROKS_GREATAXE_25516 = 25516;
  
  public static final int VOLATILE_NIGHTMARE_STAFF_25517 = 25517;
  
  public static final int ANCESTRAL_HAT_25518 = 25518;
  
  public static final int JALREKJAD = 25519;
  
  public static final int JAR_OF_SPIRITS = 25521;
  
  public static final int JAR_OF_SMOKE = 25524;
  
  public static final int STARDUST = 25527;
  
  public static final int SOFT_CLAY_PACK_25533 = 25533;
  
  public static final int ESSENCE_PACK_25535 = 25535;
  
  public static final int BAG_FULL_OF_GEMS_25537 = 25537;
  
  public static final int CELESTIAL_RING_UNCHARGED = 25539;
  
  public static final int CELESTIAL_RING = 25541;
  
  public static final int CELESTIAL_SIGNET_UNCHARGED = 25543;
  
  public static final int CELESTIAL_SIGNET = 25545;
  
  public static final int STAR_FRAGMENT = 25547;
  
  public static final int GOLDEN_PROSPECTOR_HELMET = 25549;
  
  public static final int GOLDEN_PROSPECTOR_JACKET = 25551;
  
  public static final int GOLDEN_PROSPECTOR_LEGS = 25553;
  
  public static final int GOLDEN_PROSPECTOR_BOOTS = 25555;
  
  public static final int DARK_FLIPPERS = 25557;
  
  public static final int BIG_HARPOONFISH = 25559;
  
  public static final int STUFFED_BIG_HARPOONFISH = 25561;
  
  public static final int MOUNTED_HARPOONFISH_25563 = 25563;
  
  public static final int RAW_HARPOONFISH = 25564;
  
  public static final int HARPOONFISH = 25565;
  
  public static final int CRYSTALLISED_HARPOONFISH = 25566;
  
  public static final int THE_DESERT_TROUT__SHIPS_LOG = 25567;
  
  public static final int SPIRIT_ANGLERS_RESEARCH_NOTES = 25569;
  
  public static final int DAMP_EGG = 25571;
  
  public static final int TOME_OF_WATER = 25574;
  
  public static final int TOME_OF_WATER_EMPTY = 25576;
  
  public static final int SOAKED_PAGE = 25578;
  
  public static final int TACKLE_BOX = 25580;
  
  public static final int FISH_BARREL = 25582;
  
  public static final int OPEN_FISH_BARREL = 25584;
  
  public static final int FISH_SACK_BARREL = 25585;
  
  public static final int OPEN_FISH_SACK_BARREL = 25587;
  
  public static final int SPIRIT_FLAKES = 25588;
  
  public static final int CASKET_25590 = 25590;
  
  public static final int SPIRIT_ANGLER_HEADBAND = 25592;
  
  public static final int SPIRIT_ANGLER_TOP = 25594;
  
  public static final int SPIRIT_ANGLER_WADERS = 25596;
  
  public static final int SPIRIT_ANGLER_BOOTS = 25598;
  
  public static final int GREAT_BLUE_HERON = 25600;
  
  public static final int TINY_TEMPOR = 25602;
  
  public static final int GREGGS_EASTDOOR = 25604;
  
  public static final int PROPELLER_HAT = 25606;
  
  public static final int GREGGS_IOU = 25608;
  
  public static final int PASTEL_FLOWERS = 25609;
  
  public static final int THICK_DYE = 25610;
  
  public static final int STASH_CHART = 25611;
  
  public static final int STASH_BLUEPRINT = 25612;
  
  public static final int BABY_MOLERAT = 25613;
  
  public static final int LARGE_WATER_CONTAINER = 25615;
  
  public static final int TEA_FLASK_25617 = 25617;
  
  public static final int PLAIN_SATCHEL_25618 = 25618;
  
  public static final int GREEN_SATCHEL_25619 = 25619;
  
  public static final int RED_SATCHEL_25620 = 25620;
  
  public static final int BLACK_SATCHEL_25621 = 25621;
  
  public static final int GOLD_SATCHEL_25622 = 25622;
  
  public static final int RUNE_SATCHEL_25623 = 25623;
  
  public static final int UNSIRED_25624 = 25624;
  
  public static final int BARRONITE_MACE_BROKEN = 25625;
  
  public static final int COAL_BAG_25627 = 25627;
  
  public static final int GEM_BAG_25628 = 25628;
  
  public static final int PLANK_SACK_25629 = 25629;
  
  public static final int FLAMTAER_BAG_25630 = 25630;
  
  public static final int STEAK_SANDWICH = 25631;
  
  public static final int IMCANDO_HAMMER_BROKEN = 25633;
  
  public static final int BARRONITE_HEAD = 25635;
  
  public static final int BARRONITE_HANDLE = 25637;
  
  public static final int BARRONITE_GUARD = 25639;
  
  public static final int BARRONITE_MACE = 25641;
  
  public static final int BARRONITE_MACE_L = 25643;
  
  public static final int IMCANDO_HAMMER = 25644;
  
  public static final int SIMPLE_LOCKBOX = 25646;
  
  public static final int SIMPLE_LOCKBOX_25647 = 25647;
  
  public static final int ELABORATE_LOCKBOX = 25648;
  
  public static final int ELABORATE_LOCKBOX_25649 = 25649;
  
  public static final int ORNATE_LOCKBOX = 25650;
  
  public static final int ORNATE_LOCKBOX_25651 = 25651;
  
  public static final int RAW_GUPPY = 25652;
  
  public static final int GUPPY = 25654;
  
  public static final int RUINED_GUPPY = 25656;
  
  public static final int RAW_CAVEFISH = 25658;
  
  public static final int CAVEFISH = 25660;
  
  public static final int RUINED_CAVEFISH = 25662;
  
  public static final int RAW_TETRA = 25664;
  
  public static final int TETRA = 25666;
  
  public static final int RUINED_TETRA = 25668;
  
  public static final int RAW_CATFISH = 25670;
  
  public static final int CATFISH = 25672;
  
  public static final int RUINED_CATFISH = 25674;
  
  public static final int BARRONITE_SHARDS = 25676;
  
  public static final int BARRONITE_DEPOSIT = 25684;
  
  public static final int ANCIENT_GLOBE = 25686;
  
  public static final int ANCIENT_LEDGER = 25688;
  
  public static final int ANCIENT_ASTROSCOPE = 25690;
  
  public static final int ANCIENT_TREATISE = 25692;
  
  public static final int ANCIENT_CARCANET = 25694;
  
  public static final int MIND_CORE = 25696;
  
  public static final int BODY_CORE = 25698;
  
  public static final int CHAOS_CORE = 25700;
  
  public static final int UNGAEL_LAB_NOTES = 25702;
  
  public static final int LITHKREN_VAULT_NOTES = 25704;
  
  public static final int DUSTY_NOTE = 25706;
  
  public static final int BOARD_GAME_PIECE_25708 = 25708;
  
  public static final int STOOL_25710 = 25710;
  
  public static final int STOOL_25711 = 25711;
  
  public static final int CLAN_CLOAK = 25712;
  
  public static final int CLAN_CLOAK_25714 = 25714;
  
  public static final int CLAN_CLOAK_25715 = 25715;
  
  public static final int CLAN_CLOAK_25716 = 25716;
  
  public static final int CLAN_CLOAK_25717 = 25717;
  
  public static final int CLAN_CLOAK_25718 = 25718;
  
  public static final int CLAN_CLOAK_25719 = 25719;
  
  public static final int CLAN_CLOAK_25720 = 25720;
  
  public static final int CLAN_VEXILLUM = 25721;
  
  public static final int CLAN_VEXILLUM_25723 = 25723;
  
  public static final int CLAN_VEXILLUM_25724 = 25724;
  
  public static final int CLAN_VEXILLUM_25725 = 25725;
  
  public static final int CLAN_VEXILLUM_25726 = 25726;
  
  public static final int CLAN_VEXILLUM_25727 = 25727;
  
  public static final int CLAN_VEXILLUM_25728 = 25728;
  
  public static final int CLAN_VEXILLUM_25729 = 25729;
  
  public static final int BANDAGES_25730 = 25730;
  
  public static final int HOLY_SANGUINESTI_STAFF = 25731;
  
  public static final int HOLY_SANGUINESTI_STAFF_UNCHARGED = 25733;
  
  public static final int HOLY_GHRAZI_RAPIER = 25734;
  
  public static final int HOLY_SCYTHE_OF_VITUR = 25736;
  
  public static final int HOLY_SCYTHE_OF_VITUR_UNCHARGED = 25738;
  
  public static final int SANGUINE_SCYTHE_OF_VITUR = 25739;
  
  public static final int SANGUINE_SCYTHE_OF_VITUR_UNCHARGED = 25741;
  
  public static final int HOLY_ORNAMENT_KIT = 25742;
  
  public static final int SANGUINE_ORNAMENT_KIT = 25744;
  
  public static final int SANGUINE_DUST = 25746;
  
  public static final int LIL_MAIDEN = 25748;
  
  public static final int LIL_BLOAT = 25749;
  
  public static final int LIL_NYLO = 25750;
  
  public static final int LIL_SOT = 25751;
  
  public static final int LIL_XARP = 25752;
  
  public static final int ANTIQUE_LAMP_25753 = 25753;
  
  public static final int ANTIPOISON_1 = 25754;
  
  public static final int ANTIPOISON_2 = 25755;
  
  public static final int ANTIPOISON_3 = 25756;
  
  public static final int ANTIPOISON_4 = 25757;
  
  public static final int ANTIPOISON_POTION_1 = 25758;
  
  public static final int ANTIPOISON_POTION_2 = 25759;
  
  public static final int ANTIPOISON_POTION_3 = 25760;
  
  public static final int ANTIPOISON_POTION_4 = 25761;
  
  public static final int ANTIPOISON_1_25762 = 25762;
  
  public static final int ANTIPOISON_2_25763 = 25763;
  
  public static final int ANTIPOISON_3_25764 = 25764;
  
  public static final int ANTIPOISON_4_25765 = 25765;
  
  public static final int FIENDISH_ASHES = 25766;
  
  public static final int VILE_ASHES = 25769;
  
  public static final int MALICIOUS_ASHES = 25772;
  
  public static final int ABYSSAL_ASHES = 25775;
  
  public static final int INFERNAL_ASHES = 25778;
  
  public static final int ASH_SANCTIFIER = 25781;
  
  public static final int CLUE_SCROLL_MEDIUM_25783 = 25783;
  
  public static final int CLUE_SCROLL_MEDIUM_25784 = 25784;
  
  public static final int CHALLENGE_SCROLL_MEDIUM_25785 = 25785;
  
  public static final int CLUE_SCROLL_ELITE_25786 = 25786;
  
  public static final int CLUE_SCROLL_ELITE_25787 = 25787;
  
  public static final int CLUE_SCROLL_EASY_25788 = 25788;
  
  public static final int CLUE_SCROLL_EASY_25789 = 25789;
  
  public static final int CLUE_SCROLL_HARD_25790 = 25790;
  
  public static final int CLUE_SCROLL_HARD_25791 = 25791;
  
  public static final int CLUE_SCROLL_HARD_25792 = 25792;
  
  public static final int RECEIPT_25793 = 25793;
  
  public static final int BONE = 25794;
  
  public static final int ROSE = 25795;
  
  public static final int DELIVERY_CONFIRMATION = 25796;
  
  public static final int ORDER_FORM = 25797;
  
  public static final int DEMONIC_INCANTATIONS = 25798;
  
  public static final int BLOODY_KNIFE = 25799;
  
  public static final int CULTIST_ROBE = 25800;
  
  public static final int KOUREND_MAP = 25801;
  
  public static final int ROSES_DIARY = 25802;
  
  public static final int BLUISH_KEY = 25803;
  
  public static final int COLD_KEY = 25804;
  
  public static final int ROSES_NOTE = 25805;
  
  public static final int ROSES_NOTE_25806 = 25806;
  
  public static final int ROSES_NOTE_25807 = 25807;
  
  public static final int ROSES_NOTE_25808 = 25808;
  
  public static final int LIZARDMAN_EGG = 25809;
  
  public static final int DAMP_KEY = 25810;
  
  public static final int BROKEN_REDIRECTOR = 25811;
  
  public static final int SULPHUR_POTION = 25812;
  
  public static final int SHIELDING_POTION = 25813;
  
  public static final int DECLARATION = 25814;
  
  public static final int DARK_NULLIFIER = 25815;
  
  public static final int SHAYZIEN_JOURNAL = 25816;
  
  public static final int ROYAL_ACCORD_OF_TWILL_25817 = 25817;
  
  public static final int BOOK_OF_THE_DEAD = 25818;
  
  public static final int ANTIQUE_LAMP_25820 = 25820;
  
  public static final int PROTEST_BANNER = 25822;
  
  public static final int RESEARCH_NOTES_25824 = 25824;
  
  public static final int LIZARDKICKER = 25826;
  
  public static final int OLD_NOTE_25829 = 25829;
  
  public static final int SHAYZIA_MILITARY_ORDERS = 25831;
  
  public static final int RAW_BOAR_MEAT = 25833;
  
  public static final int LITTLE_PARASITE = 25836;
  
  public static final int SLEPEY_TABLET = 25837;
  
  public static final int PARASITIC_EGG = 25838;
  
  public static final int BANANA_HAT = 25840;
  
  public static final int SRARACHA_25842 = 25842;
  
  public static final int SRARACHA_25843 = 25843;
  
  public static final int ORANGE_EGG_SAC = 25844;
  
  public static final int BLUE_EGG_SAC = 25846;
  
  public static final int AMETHYST_DART = 25849;
  
  public static final int AMETHYST_DARTP = 25851;
  
  public static final int AMETHYST_DART_TIP = 25853;
  
  public static final int AMETHYST_DARTP_25855 = 25855;
  
  public static final int AMETHYST_DARTP_25857 = 25857;
  
  public static final int ENHANCED_CRYSTAL_WEAPON_SEED = 25859;
  
  public static final int BOW_OF_FAERDHINEN_INACTIVE = 25862;
  
  public static final int BOW_OF_FAERDHINEN = 25865;
  
  public static final int BOW_OF_FAERDHINEN_C = 25867;
  
  public static final int BOW_OF_FAERDHINEN_C_25869 = 25869;
  
  public static final int BLADE_OF_SAELDOR_C_25870 = 25870;
  
  public static final int BLADE_OF_SAELDOR_C_25872 = 25872;
  
  public static final int BLADE_OF_SAELDOR_C_25874 = 25874;
  
  public static final int BLADE_OF_SAELDOR_C_25876 = 25876;
  
  public static final int BLADE_OF_SAELDOR_C_25878 = 25878;
  
  public static final int BLADE_OF_SAELDOR_C_25880 = 25880;
  
  public static final int BLADE_OF_SAELDOR_C_25882 = 25882;
  
  public static final int BOW_OF_FAERDHINEN_C_25884 = 25884;
  
  public static final int BOW_OF_FAERDHINEN_C_25886 = 25886;
  
  public static final int BOW_OF_FAERDHINEN_C_25888 = 25888;
  
  public static final int BOW_OF_FAERDHINEN_C_25890 = 25890;
  
  public static final int BOW_OF_FAERDHINEN_C_25892 = 25892;
  
  public static final int BOW_OF_FAERDHINEN_C_25894 = 25894;
  
  public static final int BOW_OF_FAERDHINEN_C_25896 = 25896;
  
  public static final int TZTOK_SLAYER_HELMET = 25898;
  
  public static final int TZTOK_SLAYER_HELMET_I = 25900;
  
  public static final int TZTOK_SLAYER_HELMET_I_25902 = 25902;
  
  public static final int VAMPYRIC_SLAYER_HELMET = 25904;
  
  public static final int VAMPYRIC_SLAYER_HELMET_I = 25906;
  
  public static final int VAMPYRIC_SLAYER_HELMET_I_25908 = 25908;
  
  public static final int TZKAL_SLAYER_HELMET = 25910;
  
  public static final int TZKAL_SLAYER_HELMET_I = 25912;
  
  public static final int TZKAL_SLAYER_HELMET_I_25914 = 25914;
  
  public static final int DRAGON_HUNTER_CROSSBOW_T = 25916;
  
  public static final int DRAGON_HUNTER_CROSSBOW_B = 25918;
  
  public static final int ANTIQUE_LAMP_25920 = 25920;
  
  public static final int ANTIQUE_LAMP_25921 = 25921;
  
  public static final int ANTIQUE_LAMP_25922 = 25922;
  
  public static final int ANTIQUE_LAMP_25923 = 25923;
  
  public static final int ANTIQUE_LAMP_25924 = 25924;
  
  public static final int ANTIQUE_LAMP_25925 = 25925;
  
  public static final int GHOMMALS_HILT_1 = 25926;
  
  public static final int GHOMMALS_HILT_2 = 25928;
  
  public static final int GHOMMALS_HILT_3 = 25930;
  
  public static final int GHOMMALS_HILT_4 = 25932;
  
  public static final int GHOMMALS_HILT_5 = 25934;
  
  public static final int GHOMMALS_HILT_6 = 25936;
  
  public static final int ANIM_OFFHAND = 25938;
  
  public static final int ANIM_OFFHAND_25941 = 25941;
  
  public static final int ANIM_OFFHAND_25944 = 25944;
  
  public static final int ANIM_OFFHAND_25947 = 25947;
  
  public static final int ANIM_OFFHAND_25950 = 25950;
  
  public static final int ANIM_OFFHAND_25953 = 25953;
  
  public static final int COMBAT_ACHIEVEMENTS = 25956;
  
  public static final int CORRUPTED_PADDLEFISH = 25958;
  
  public static final int CORRUPTED_ESCAPE_CRYSTAL = 25959;
  
  public static final int CRYSTAL_PADDLEFISH = 25960;
  
  public static final int ESCAPE_CRYSTAL_25961 = 25961;
  
  public static final int CRYPT_KEY = 25963;
  
  public static final int RANIS_HEAD = 25964;
  
  public static final int STRANGE_SPIDER_EGGS = 25965;
  
  public static final int SULPHURIC_ACID = 25966;
  
  public static final int STICKY_NOTE = 25967;
  
  public static final int HESPORI_BARK = 25968;
  
  public static final int LIGHTBEARER = 25975;
  
  public static final int KERIS_PARTISAN = 25979;
  
  public static final int KERIS_PARTISAN_OF_BREACHING = 25981;
  
  public static final int ELIDINIS_WARD = 25985;
  
  public static final int SIGIL_OF_RESILIENCE = 25990;
  
  public static final int SIGIL_OF_RESILIENCE_25991 = 25991;
  
  public static final int SIGIL_OF_CONSISTENCY = 25993;
  
  public static final int SIGIL_OF_CONSISTENCY_25994 = 25994;
  
  public static final int SIGIL_OF_THE_FORMIDABLE_FIGHTER = 25996;
  
  public static final int SIGIL_OF_THE_FORMIDABLE_FIGHTER_25997 = 25997;
  
  public static final int SIGIL_OF_THE_RIGOROUS_RANGER = 25999;
  
  public static final int SIGIL_OF_THE_RIGOROUS_RANGER_26000 = 26000;
  
  public static final int SIGIL_OF_THE_METICULOUS_MAGE = 26002;
  
  public static final int SIGIL_OF_THE_METICULOUS_MAGE_26003 = 26003;
  
  public static final int SIGIL_OF_FORTIFICATION = 26005;
  
  public static final int SIGIL_OF_FORTIFICATION_26006 = 26006;
  
  public static final int SIGIL_OF_BARROWS = 26008;
  
  public static final int SIGIL_OF_BARROWS_26009 = 26009;
  
  public static final int SIGIL_OF_DEFT_STRIKES = 26011;
  
  public static final int SIGIL_OF_DEFT_STRIKES_26012 = 26012;
  
  public static final int SIGIL_OF_FREEDOM = 26014;
  
  public static final int SIGIL_OF_FREEDOM_26015 = 26015;
  
  public static final int SIGIL_OF_ENHANCED_HARVEST = 26017;
  
  public static final int SIGIL_OF_ENHANCED_HARVEST_26018 = 26018;
  
  public static final int SIGIL_OF_STORAGE = 26020;
  
  public static final int SIGIL_OF_STORAGE_26021 = 26021;
  
  public static final int SIGIL_OF_THE_SMITH = 26023;
  
  public static final int SIGIL_OF_THE_SMITH_26024 = 26024;
  
  public static final int SIGIL_OF_THE_ALCHEMIST = 26026;
  
  public static final int SIGIL_OF_THE_ALCHEMIST_26027 = 26027;
  
  public static final int SIGIL_OF_THE_FLETCHER = 26029;
  
  public static final int SIGIL_OF_THE_FLETCHER_26030 = 26030;
  
  public static final int SIGIL_OF_THE_CHEF = 26032;
  
  public static final int SIGIL_OF_THE_CHEF_26033 = 26033;
  
  public static final int SIGIL_OF_THE_CRAFTSMAN = 26035;
  
  public static final int SIGIL_OF_THE_CRAFTSMAN_26036 = 26036;
  
  public static final int SIGIL_OF_THE_ABYSS = 26038;
  
  public static final int SIGIL_OF_THE_ABYSS_26039 = 26039;
  
  public static final int SIGIL_OF_STAMINA = 26041;
  
  public static final int SIGIL_OF_STAMINA_26042 = 26042;
  
  public static final int SIGIL_OF_THE_POTION_MASTER = 26044;
  
  public static final int SIGIL_OF_THE_POTION_MASTER_26045 = 26045;
  
  public static final int SIGIL_OF_THE_ETERNAL_JEWELLER = 26047;
  
  public static final int SIGIL_OF_THE_ETERNAL_JEWELLER_26048 = 26048;
  
  public static final int SIGIL_OF_THE_TREASURE_HUNTER = 26050;
  
  public static final int SIGIL_OF_THE_TREASURE_HUNTER_26051 = 26051;
  
  public static final int SIGIL_OF_MOBILITY = 26053;
  
  public static final int SIGIL_OF_MOBILITY_26054 = 26054;
  
  public static final int SIGIL_OF_EXAGGERATION = 26056;
  
  public static final int SIGIL_OF_EXAGGERATION_26057 = 26057;
  
  public static final int SIGIL_OF_SPECIALISED_STRIKES = 26059;
  
  public static final int SIGIL_OF_SPECIALISED_STRIKES_26060 = 26060;
  
  public static final int SIGIL_OF_THE_PORCUPINE = 26062;
  
  public static final int SIGIL_OF_THE_PORCUPINE_26063 = 26063;
  
  public static final int SIGIL_OF_BINDING = 26065;
  
  public static final int SIGIL_OF_BINDING_26066 = 26066;
  
  public static final int SIGIL_OF_ESCAPING = 26068;
  
  public static final int SIGIL_OF_ESCAPING_26069 = 26069;
  
  public static final int SIGIL_OF_THE_RUTHLESS_RANGER = 26071;
  
  public static final int SIGIL_OF_THE_RUTHLESS_RANGER_26072 = 26072;
  
  public static final int SIGIL_OF_THE_FERAL_FIGHTER = 26074;
  
  public static final int SIGIL_OF_THE_FERAL_FIGHTER_26075 = 26075;
  
  public static final int SIGIL_OF_THE_MENACING_MAGE = 26077;
  
  public static final int SIGIL_OF_THE_MENACING_MAGE_26078 = 26078;
  
  public static final int SIGIL_OF_PROSPERITY = 26080;
  
  public static final int SIGIL_OF_PROSPERITY_26081 = 26081;
  
  public static final int SIGIL_OF_THE_DWARVES = 26083;
  
  public static final int SIGIL_OF_THE_DWARVES_26084 = 26084;
  
  public static final int SIGIL_OF_THE_ELVES = 26086;
  
  public static final int SIGIL_OF_THE_ELVES_26087 = 26087;
  
  public static final int SIGIL_OF_THE_BARBARIANS = 26089;
  
  public static final int SIGIL_OF_THE_BARBARIANS_26090 = 26090;
  
  public static final int SIGIL_OF_THE_GNOMES = 26092;
  
  public static final int SIGIL_OF_THE_GNOMES_26093 = 26093;
  
  public static final int SIGIL_OF_NATURE = 26095;
  
  public static final int SIGIL_OF_NATURE_26096 = 26096;
  
  public static final int SIGIL_OF_DEVOTION = 26098;
  
  public static final int SIGIL_OF_DEVOTION_26099 = 26099;
  
  public static final int SIGIL_OF_THE_FORAGER = 26101;
  
  public static final int SIGIL_OF_THE_FORAGER_26102 = 26102;
  
  public static final int SIGIL_OF_GARMENTS = 26104;
  
  public static final int SIGIL_OF_GARMENTS_26105 = 26105;
  
  public static final int SIGIL_OF_SLAUGHTER = 26107;
  
  public static final int SIGIL_OF_SLAUGHTER_26108 = 26108;
  
  public static final int SIGIL_OF_THE_FORTUNE_FARMER = 26110;
  
  public static final int SIGIL_OF_THE_FORTUNE_FARMER_26111 = 26111;
  
  public static final int SIGIL_OF_VERSATILITY = 26113;
  
  public static final int SIGIL_OF_VERSATILITY_26114 = 26114;
  
  public static final int SIGIL_OF_THE_SERPENT = 26116;
  
  public static final int SIGIL_OF_THE_SERPENT_26117 = 26117;
  
  public static final int SIGIL_OF_SUPREME_STAMINA = 26119;
  
  public static final int SIGIL_OF_SUPREME_STAMINA_26120 = 26120;
  
  public static final int SIGIL_OF_PRESERVATION = 26122;
  
  public static final int SIGIL_OF_PRESERVATION_26123 = 26123;
  
  public static final int SIGIL_OF_FINALITY = 26125;
  
  public static final int SIGIL_OF_FINALITY_26126 = 26126;
  
  public static final int SIGIL_OF_PIOUS_PROTECTION = 26128;
  
  public static final int SIGIL_OF_PIOUS_PROTECTION_26129 = 26129;
  
  public static final int SIGIL_OF_AGGRESSION = 26131;
  
  public static final int SIGIL_OF_AGGRESSION_26132 = 26132;
  
  public static final int SIGIL_OF_RAMPAGE = 26134;
  
  public static final int SIGIL_OF_RAMPAGE_26135 = 26135;
  
  public static final int SIGIL_OF_THE_SKILLER = 26137;
  
  public static final int SIGIL_OF_THE_SKILLER_26138 = 26138;
  
  public static final int SIGIL_OF_REMOTE_STORAGE = 26140;
  
  public static final int SIGIL_OF_REMOTE_STORAGE_26141 = 26141;
  
  public static final int SIGIL_OF_LAST_RECALL = 26143;
  
  public static final int SIGIL_OF_LAST_RECALL_26144 = 26144;
  
  public static final int SIGIL_OF_THE_GUARDIAN_ANGEL = 26146;
  
  public static final int SIGIL_OF_THE_GUARDIAN_ANGEL_26147 = 26147;
  
  public static final int TUNA_26149 = 26149;
  
  public static final int COMBAT_POTION4_26150 = 26150;
  
  public static final int COMBAT_POTION3_26151 = 26151;
  
  public static final int COMBAT_POTION2_26152 = 26152;
  
  public static final int COMBAT_POTION1_26153 = 26153;
  
  public static final int MOUNT_KARUULM_DIARY = 26154;
  
  public static final int GROUP_IRONMAN_HELM = 26156;
  
  public static final int GROUP_IRONMAN_PLATEBODY = 26158;
  
  public static final int GROUP_IRONMAN_PLATEBODY_26160 = 26160;
  
  public static final int GROUP_IRONMAN_PLATEBODY_26162 = 26162;
  
  public static final int GROUP_IRONMAN_PLATEBODY_26164 = 26164;
  
  public static final int GROUP_IRONMAN_PLATELEGS = 26166;
  
  public static final int GROUP_IRONMAN_BRACERS = 26168;
  
  public static final int HARDCORE_GROUP_IRONMAN_HELM = 26170;
  
  public static final int HARDCORE_GROUP_IRONMAN_PLATEBODY = 26172;
  
  public static final int HARDCORE_GROUP_IRONMAN_PLATEBODY_26174 = 26174;
  
  public static final int HARDCORE_GROUP_IRONMAN_PLATEBODY_26176 = 26176;
  
  public static final int HARDCORE_GROUP_IRONMAN_PLATEBODY_26178 = 26178;
  
  public static final int HARDCORE_GROUP_IRONMAN_PLATELEGS = 26180;
  
  public static final int HARDCORE_GROUP_IRONMAN_BRACERS = 26182;
  
  public static final int BLUE_ICON_26184 = 26184;
  
  public static final int BLUE_ICON_26185 = 26185;
  
  public static final int BLUE_ICON_26186 = 26186;
  
  public static final int BLUE_ICON_26187 = 26187;
  
  public static final int BLUE_ICON_26188 = 26188;
  
  public static final int BLUE_ICON_26189 = 26189;
  
  public static final int BLUE_ICON_26190 = 26190;
  
  public static final int BLUE_ICON_26191 = 26191;
  
  public static final int BLUE_ICON_26192 = 26192;
  
  public static final int BLUE_ICON_26193 = 26193;
  
  public static final int BLUE_ICON_26194 = 26194;
  
  public static final int BLUE_ICON_26195 = 26195;
  
  public static final int BLUE_ICON_26196 = 26196;
  
  public static final int BLUE_ICON_26197 = 26197;
  
  public static final int BLUE_ICON_26198 = 26198;
  
  public static final int BLUE_ICON_26199 = 26199;
  
  public static final int RED_ICON_26200 = 26200;
  
  public static final int RED_ICON_26201 = 26201;
  
  public static final int RED_ICON_26202 = 26202;
  
  public static final int RED_ICON_26203 = 26203;
  
  public static final int RED_ICON_26204 = 26204;
  
  public static final int RED_ICON_26205 = 26205;
  
  public static final int RED_ICON_26206 = 26206;
  
  public static final int RED_ICON_26207 = 26207;
  
  public static final int RED_ICON_26208 = 26208;
  
  public static final int RED_ICON_26209 = 26209;
  
  public static final int RED_ICON_26210 = 26210;
  
  public static final int RED_ICON_26211 = 26211;
  
  public static final int RED_ICON_26212 = 26212;
  
  public static final int RED_ICON_26213 = 26213;
  
  public static final int RED_ICON_26214 = 26214;
  
  public static final int RED_ICON_26215 = 26215;
  
  public static final int OSMUMTENS_FANG = 26219;
  
  public static final int ANCIENT_CEREMONIAL_TOP = 26221;
  
  public static final int ANCIENT_CEREMONIAL_LEGS = 26223;
  
  public static final int ANCIENT_CEREMONIAL_MASK = 26225;
  
  public static final int ANCIENT_CEREMONIAL_GLOVES = 26227;
  
  public static final int ANCIENT_CEREMONIAL_BOOTS = 26229;
  
  public static final int NIHIL_SHARD = 26231;
  
  public static final int ANCIENT_GODSWORD = 26233;
  
  public static final int ZARYTE_VAMBRACES = 26235;
  
  public static final int ZARYTE_BOW = 26237;
  
  public static final int ZARYTE_BOW_26239 = 26239;
  
  public static final int VIRTUS_MASK = 26241;
  
  public static final int VIRTUS_ROBE_TOP = 26243;
  
  public static final int VIRTUS_ROBE_BOTTOM = 26245;
  
  public static final int PUMPKIN_PIE = 26247;
  
  public static final int JEREDS_EMPTY_WINE_BOTTLE = 26250;
  
  public static final int AD_COUPON = 26252;
  
  public static final int SAUCEPAN = 26254;
  
  public static final int UGLY_HALLOWEEN_JUMPER_ORANGE = 26256;
  
  public static final int UGLY_HALLOWEEN_JUMPER_BLACK = 26258;
  
  public static final int HAUNTED_WINE_BOTTLE = 26260;
  
  public static final int RUNE_SCIMITAR_26262 = 26262;
  
  public static final int STUDDED_BODY_26264 = 26264;
  
  public static final int CONDENSED_GOLD = 26266;
  
  public static final int GOLD_SINK = 26269;
  
  public static final int FESTIVE_CINNAMON = 26270;
  
  public static final int FESTIVE_HOLLY = 26272;
  
  public static final int FESTIVE_WHITE_WINE = 26274;
  
  public static final int NOTES_26276 = 26276;
  
  public static final int MAGICAL_CLEANING_POTION = 26278;
  
  public static final int PINK_STAINED_PLATEBODY = 26280;
  
  public static final int PINK_STAINED_PLATELEGS = 26282;
  
  public static final int PINK_STAINED_FULL_HELM = 26284;
  
  public static final int CLEAN_PLATEBODY = 26286;
  
  public static final int CLEAN_PLATELEGS = 26288;
  
  public static final int CLEAN_FULL_HELM = 26290;
  
  public static final int FESTIVE_GINGERBREAD_GNOMES = 26292;
  
  public static final int FESTIVE_MULLED_WINE = 26294;
  
  public static final int SNOW = 26296;
  
  public static final int SECRET_SANTA_PRESENT = 26298;
  
  public static final int SECRET_SANTA_PRESENT_26300 = 26300;
  
  public static final int SECRET_SANTA_PRESENT_26302 = 26302;
  
  public static final int CHOCOLATE_CHIPS = 26304;
  
  public static final int CHOCOLATE_CHIPS_26306 = 26306;
  
  public static final int A_BIG_PRESENT = 26308;
  
  public static final int FESTIVE_ELF_SLIPPERS = 26310;
  
  public static final int FESTIVE_ELF_HAT = 26312;
  
  public static final int SNOWMAN_RING = 26314;
  
  public static final int SECRET_SANTA_PRESENT_RED = 26316;
  
  public static final int SECRET_SANTA_PRESENT_BLUE = 26318;
  
  public static final int SECRET_SANTA_PRESENT_GREEN = 26320;
  
  public static final int SECRET_SANTA_PRESENT_BLACK = 26322;
  
  public static final int SECRET_SANTA_PRESENT_GOLD = 26324;
  
  public static final int LITTLE_SNOWBALL = 26326;
  
  public static final int SMALL_SNOWBALL = 26328;
  
  public static final int NORMAL_SNOWBALL = 26330;
  
  public static final int BIG_SNOWBALL = 26332;
  
  public static final int LARGE_SNOWBALL = 26334;
  
  public static final int HUGE_SNOWBALL = 26336;
  
  public static final int HUMONGOUS_SNOWBALL = 26338;
  
  public static final int ANCIENT_BREW4 = 26340;
  
  public static final int ANCIENT_BREW3 = 26342;
  
  public static final int ANCIENT_BREW2 = 26344;
  
  public static final int ANCIENT_BREW1 = 26346;
  
  public static final int NEXLING = 26348;
  
  public static final int ANCIENT_MIX2 = 26350;
  
  public static final int ANCIENT_MIX1 = 26353;
  
  public static final int FROZEN_KEY_26356 = 26356;
  
  public static final int FROZEN_KEY_PIECE_ARMADYL = 26358;
  
  public static final int FROZEN_KEY_PIECE_BANDOS = 26360;
  
  public static final int FROZEN_KEY_PIECE_ZAMORAK = 26362;
  
  public static final int FROZEN_KEY_PIECE_SARADOMIN = 26364;
  
  public static final int IMPORTANT_LETTER = 26366;
  
  public static final int NIHIL_DUST = 26368;
  
  public static final int ANCIENT_HILT = 26370;
  
  public static final int NIHIL_HORN = 26372;
  
  public static final int ZARYTE_CROSSBOW = 26374;
  
  public static final int TORVA_FULL_HELM_DAMAGED = 26376;
  
  public static final int TORVA_PLATEBODY_DAMAGED = 26378;
  
  public static final int TORVA_PLATELEGS_DAMAGED = 26380;
  
  public static final int TORVA_FULL_HELM = 26382;
  
  public static final int TORVA_PLATEBODY = 26384;
  
  public static final int TORVA_PLATELEGS = 26386;
  
  public static final int ECUMENICAL_KEY_SHARD = 26388;
  
  public static final int BLOOD_ESSENCE = 26390;
  
  public static final int BLOOD_ESSENCE_ACTIVE = 26392;
  
  public static final int BANDOSIAN_COMPONENTS = 26394;
  
  public static final int CABBAGE_26417 = 26417;
  
  public static final int CABBAGE_26419 = 26419;
  
  public static final int SHATTERED_RELICS_VARIETY_ORNAMENT_KIT = 26421;
  
  public static final int SHATTERED_BANNER = 26424;
  
  public static final int SHATTERED_HOOD_T1 = 26427;
  
  public static final int SHATTERED_TOP_T1 = 26430;
  
  public static final int SHATTERED_TROUSERS_T1 = 26433;
  
  public static final int SHATTERED_BOOTS_T1 = 26436;
  
  public static final int SHATTERED_HOOD_T2 = 26439;
  
  public static final int SHATTERED_TOP_T2 = 26442;
  
  public static final int SHATTERED_TROUSERS_T2 = 26445;
  
  public static final int SHATTERED_BOOTS_T2 = 26448;
  
  public static final int SHATTERED_HOOD_T3 = 26451;
  
  public static final int SHATTERED_TOP_T3 = 26454;
  
  public static final int SHATTERED_TROUSERS_T3 = 26457;
  
  public static final int SHATTERED_BOOTS_T3 = 26460;
  
  public static final int VOID_KNIGHT_TOP_OR = 26463;
  
  public static final int VOID_KNIGHT_ROBE_OR = 26465;
  
  public static final int VOID_KNIGHT_GLOVES_OR = 26467;
  
  public static final int ELITE_VOID_TOP_OR = 26469;
  
  public static final int ELITE_VOID_ROBE_OR = 26471;
  
  public static final int VOID_MAGE_HELM_OR = 26473;
  
  public static final int VOID_RANGER_HELM_OR = 26475;
  
  public static final int VOID_MELEE_HELM_OR = 26477;
  
  public static final int SHATTERED_RELICS_VOID_ORNAMENT_KIT = 26479;
  
  public static final int ABYSSAL_WHIP_OR = 26482;
  
  public static final int ABYSSAL_TENTACLE_OR = 26484;
  
  public static final int RUNE_CROSSBOW_OR = 26486;
  
  public static final int BOOK_OF_BALANCE_OR = 26488;
  
  public static final int BOOK_OF_DARKNESS_OR = 26490;
  
  public static final int BOOK_OF_LAW_OR = 26492;
  
  public static final int BOOK_OF_WAR_OR = 26494;
  
  public static final int HOLY_BOOK_OR = 26496;
  
  public static final int UNHOLY_BOOK_OR = 26498;
  
  public static final int SHATTERED_TELEPORT_SCROLL = 26500;
  
  public static final int SHATTERED_RELICS_BRONZE_TROPHY = 26503;
  
  public static final int SHATTERED_RELICS_IRON_TROPHY = 26505;
  
  public static final int SHATTERED_RELICS_STEEL_TROPHY = 26507;
  
  public static final int SHATTERED_RELICS_MITHRIL_TROPHY = 26509;
  
  public static final int SHATTERED_RELICS_ADAMANT_TROPHY = 26511;
  
  public static final int SHATTERED_RELICS_RUNE_TROPHY = 26513;
  
  public static final int SHATTERED_RELICS_DRAGON_TROPHY = 26515;
  
  public static final int SHATTERED_CANE = 26517;
  
  public static final int CANNON_BASE_OR = 26520;
  
  public static final int CANNON_STAND_OR = 26522;
  
  public static final int CANNON_BARRELS_OR = 26524;
  
  public static final int CANNON_FURNACE_OR = 26526;
  
  public static final int SHATTERED_CANNON_ORNAMENT_KIT = 26528;
  
  public static final int MYSTIC_HAT_OR = 26531;
  
  public static final int MYSTIC_ROBE_TOP_OR = 26533;
  
  public static final int MYSTIC_ROBE_BOTTOM_OR = 26535;
  
  public static final int MYSTIC_GLOVES_OR = 26537;
  
  public static final int MYSTIC_BOOTS_OR = 26539;
  
  public static final int SHATTERED_RELICS_MYSTIC_ORNAMENT_KIT = 26541;
  
  public static final int UNIDENTIFIED_FRAGMENT_HARVESTING = 26544;
  
  public static final int UNIDENTIFIED_FRAGMENT_PRODUCTION = 26545;
  
  public static final int UNIDENTIFIED_FRAGMENT_SKILLING = 26546;
  
  public static final int UNIDENTIFIED_FRAGMENT_COMBAT = 26547;
  
  public static final int UNIDENTIFIED_FRAGMENT_MISC = 26548;
  
  public static final int PORTABLE_WAYSTONE = 26549;
  
  public static final int ARCANE_GRIMOIRE = 26551;
  
  public static final int SHATTERED_RELIC_HUNTER_T1_ARMOUR_SET = 26554;
  
  public static final int SHATTERED_RELIC_HUNTER_T2_ARMOUR_SET = 26557;
  
  public static final int SHATTERED_RELIC_HUNTER_T3_ARMOUR_SET = 26560;
  
  public static final int CLUE_SCROLL_HARD_26566 = 26566;
  
  public static final int WHITE_GOBLIN_MAIL = 26567;
  
  public static final int PHARMAKOS_BERRIES = 26569;
  
  public static final int EKELESHUUN_KEY = 26571;
  
  public static final int NAROGOSHUUN_KEY = 26572;
  
  public static final int HUZAMOGAARB_KEY = 26573;
  
  public static final int SARAGORGAK_KEY = 26574;
  
  public static final int HOROGOTHGAR_KEY = 26575;
  
  public static final int YURKOLGOKH_KEY = 26576;
  
  public static final int PLAIN_OF_MUD_SPHERE = 26577;
  
  public static final int WHITEFISH = 26579;
  
  public static final int GOBLIN_POTION4 = 26581;
  
  public static final int GOBLIN_POTION3 = 26583;
  
  public static final int GOBLIN_POTION2 = 26585;
  
  public static final int GOBLIN_POTION1 = 26587;
  
  public static final int SNOTHEADS_BONE = 26589;
  
  public static final int SNAILFEETS_BONE = 26590;
  
  public static final int MOSSCHINS_BONE = 26591;
  
  public static final int REDEYES_BONE = 26592;
  
  public static final int STRONGBONES_BONE = 26593;
  
  public static final int GRUBFOOT = 26594;
  
  public static final int ZANIK_26595 = 26595;
  
  public static final int NOTES_26596 = 26596;
  
  public static final int DESERT_BAIT = 26598;
  
  public static final int TINY_FISH = 26600;
  
  public static final int OSMANS_REPORT = 26602;
  
  public static final int TREASURE_CLUE_ONE = 26605;
  
  public static final int TREASURE_CLUE_TWO = 26607;
  
  public static final int TREASURE_CLUE_THREE = 26609;
  
  public static final int ZEKES_CHALLENGE_SCROLL = 26611;
  
  public static final int CAPT_ARNAVS_CHEST = 26613;
  
  public static final int BUCKET_COOKOUT = 26615;
  
  public static final int BUCKET_OF_WATER_COOKOUT = 26617;
  
  public static final int POT_COOKOUT = 26619;
  
  public static final int POT_OF_FLOUR_COOKOUT = 26621;
  
  public static final int TOMATO_COOKOUT = 26623;
  
  public static final int CHEESE_COOKOUT = 26625;
  
  public static final int BANANA_COOKOUT = 26627;
  
  public static final int PIZZA_BASE_COOKOUT = 26629;
  
  public static final int INCOMPLETE_PIZZA_COOKOUT = 26631;
  
  public static final int UNCOOKED_PIZZA_COOKOUT = 26633;
  
  public static final int PLAIN_PIZZA_COOKOUT = 26635;
  
  public static final int BURNT_PIZZA_COOKOUT = 26637;
  
  public static final int BREAD_DOUGH_COOKOUT = 26639;
  
  public static final int BREAD_COOKOUT = 26641;
  
  public static final int BURNT_BREAD_COOKOUT = 26643;
  
  public static final int BANANA_PIZZA_COOKOUT = 26645;
  
  public static final int BURNT_BANANA_PIZZA_COOKOUT = 26647;
  
  public static final int SKIS = 26649;
  
  public static final int LOOT_KEY = 26651;
  
  public static final int LOOT_KEY_26652 = 26652;
  
  public static final int LOOT_KEY_26653 = 26653;
  
  public static final int LOOT_KEY_26654 = 26654;
  
  public static final int LOOT_KEY_26655 = 26655;
  
  public static final int SHOE_26656 = 26656;
  
  public static final int SHOE_26657 = 26657;
  
  public static final int SHOE_26658 = 26658;
  
  public static final int SHOE_26659 = 26659;
  
  public static final int SHOE_26660 = 26660;
  
  public static final int SHOE_26661 = 26661;
  
  public static final int SHOE_26662 = 26662;
  
  public static final int SHOE_26663 = 26663;
  
  public static final int SHOE_26664 = 26664;
  
  public static final int SHOE_26665 = 26665;
  
  public static final int SHOE_26666 = 26666;
  
  public static final int SHOE_26667 = 26667;
  
  public static final int SHOE_26668 = 26668;
  
  public static final int SHOE_26669 = 26669;
  
  public static final int SHOE_26670 = 26670;
  
  public static final int SHOE_26671 = 26671;
  
  public static final int SHOE_26672 = 26672;
  
  public static final int SHOE_26673 = 26673;
  
  public static final int SLAYER_HELMET_I_26674 = 26674;
  
  public static final int BLACK_SLAYER_HELMET_I_26675 = 26675;
  
  public static final int GREEN_SLAYER_HELMET_I_26676 = 26676;
  
  public static final int RED_SLAYER_HELMET_I_26677 = 26677;
  
  public static final int PURPLE_SLAYER_HELMET_I_26678 = 26678;
  
  public static final int TURQUOISE_SLAYER_HELMET_I_26679 = 26679;
  
  public static final int HYDRA_SLAYER_HELMET_I_26680 = 26680;
  
  public static final int TWISTED_SLAYER_HELMET_I_26681 = 26681;
  
  public static final int TZTOK_SLAYER_HELMET_I_26682 = 26682;
  
  public static final int VAMPYRIC_SLAYER_HELMET_I_26683 = 26683;
  
  public static final int TZKAL_SLAYER_HELMET_I_26684 = 26684;
  
  public static final int GRANITE_RING_I_26685 = 26685;
  
  public static final int MAOMAS_MED_HELM_BROKEN = 26686;
  
  public static final int MAOMAS_FULL_HELM_BROKEN = 26687;
  
  public static final int MAOMAS_GREAT_HELM_BROKEN = 26688;
  
  public static final int CALAMITY_CHEST_BROKEN = 26689;
  
  public static final int SUPERIOR_CALAMITY_CHEST_BROKEN = 26690;
  
  public static final int ELITE_CALAMITY_CHEST_BROKEN = 26691;
  
  public static final int CALAMITY_BREECHES_BROKEN = 26692;
  
  public static final int SUPERIOR_CALAMITY_BREECHES_BROKEN = 26693;
  
  public static final int ELITE_CALAMITY_BREECHES_BROKEN = 26694;
  
  public static final int CENTURION_CUIRASS_BROKEN = 26695;
  
  public static final int WRISTBANDS_OF_THE_ARENA_BROKEN = 26696;
  
  public static final int HARDENED_WRISTBANDS_OF_THE_ARENA_BROKEN = 26697;
  
  public static final int KORIFFS_HEADBAND_BROKEN = 26698;
  
  public static final int KORIFFS_COWL_BROKEN = 26699;
  
  public static final int KORIFFS_COIF_BROKEN = 26700;
  
  public static final int SAIKAS_HOOD_BROKEN = 26701;
  
  public static final int SAIKAS_VEIL_BROKEN = 26702;
  
  public static final int SAIKAS_SHROUD_BROKEN = 26703;
  
  public static final int BLIGHTED_SURGE_SACK = 26705;
  
  public static final int SCROLL_OF_IMBUING = 26706;
  
  public static final int DRAGON_CLAWS_ORNAMENT_KIT = 26707;
  
  public static final int DRAGON_CLAWS_OR = 26708;
  
  public static final int DRAGON_WARHAMMER_ORNAMENT_KIT = 26709;
  
  public static final int DRAGON_WARHAMMER_OR = 26710;
  
  public static final int HEAVY_BALLISTA_ORNAMENT_KIT = 26711;
  
  public static final int HEAVY_BALLISTA_OR = 26712;
  
  public static final int ARMADYL_ARMOUR_ORNAMENT_KIT = 26713;
  
  public static final int ARMADYL_HELMET_OR = 26714;
  
  public static final int ARMADYL_CHESTPLATE_OR = 26715;
  
  public static final int ARMADYL_CHAINSKIRT_OR = 26716;
  
  public static final int BANDOS_ARMOUR_ORNAMENT_KIT = 26717;
  
  public static final int BANDOS_CHESTPLATE_OR = 26718;
  
  public static final int BANDOS_TASSETS_OR = 26719;
  
  public static final int BANDOS_BOOTS_OR = 26720;
  
  public static final int CENTURION_CUIRASS = 26721;
  
  public static final int CENTURION_CUIRASS_L = 26722;
  
  public static final int WRISTBANDS_OF_THE_ARENA = 26723;
  
  public static final int WRISTBANDS_OF_THE_ARENA_L = 26724;
  
  public static final int WRISTBANDS_OF_THE_ARENA_C = 26725;
  
  public static final int WRISTBANDS_OF_THE_ARENA_CL = 26726;
  
  public static final int WRISTBANDS_OF_THE_ARENA_I = 26727;
  
  public static final int WRISTBANDS_OF_THE_ARENA_IL = 26728;
  
  public static final int WRISTBANDS_OF_THE_ARENA_IC = 26729;
  
  public static final int WRISTBANDS_OF_THE_ARENA_ILC = 26730;
  
  public static final int SAIKAS_HOOD = 26731;
  
  public static final int SAIKAS_HOOD_L = 26732;
  
  public static final int SAIKAS_VEIL = 26733;
  
  public static final int SAIKAS_VEIL_L = 26734;
  
  public static final int SAIKAS_SHROUD = 26735;
  
  public static final int SAIKAS_SHROUD_L = 26736;
  
  public static final int KORIFFS_HEADBAND = 26737;
  
  public static final int KORIFFS_HEADBAND_L = 26738;
  
  public static final int KORIFFS_COWL = 26739;
  
  public static final int KORIFFS_COWL_L = 26740;
  
  public static final int KORIFFS_COIF = 26741;
  
  public static final int KORIFFS_COIF_L = 26742;
  
  public static final int MAOMAS_MED_HELM = 26743;
  
  public static final int MAOMAS_MED_HELM_L = 26744;
  
  public static final int MAOMAS_FULL_HELM = 26745;
  
  public static final int MAOMAS_FULL_HELM_L = 26746;
  
  public static final int MAOMAS_GREAT_HELM = 26747;
  
  public static final int MAOMAS_GREAT_HELM_L = 26748;
  
  public static final int CALAMITY_CHEST = 26749;
  
  public static final int CALAMITY_CHEST_L = 26750;
  
  public static final int SUPERIOR_CALAMITY_CHEST = 26751;
  
  public static final int SUPERIOR_CALAMITY_CHEST_L = 26752;
  
  public static final int ELITE_CALAMITY_CHEST = 26753;
  
  public static final int ELITE_CALAMITY_CHEST_L = 26754;
  
  public static final int CALAMITY_BREECHES = 26755;
  
  public static final int CALAMITY_BREECHES_L = 26756;
  
  public static final int SUPERIOR_CALAMITY_BREECHES = 26757;
  
  public static final int SUPERIOR_CALAMITY_BREECHES_L = 26758;
  
  public static final int ELITE_CALAMITY_BREECHES = 26759;
  
  public static final int ELITE_CALAMITY_BREECHES_L = 26760;
  
  public static final int RING_OF_SUFFERING_I_26761 = 26761;
  
  public static final int RING_OF_SUFFERING_RI_26762 = 26762;
  
  public static final int SALVE_AMULETI_26763 = 26763;
  
  public static final int RING_OF_THE_GODS_I_26764 = 26764;
  
  public static final int TYRANNICAL_RING_I_26765 = 26765;
  
  public static final int TREASONOUS_RING_I_26766 = 26766;
  
  public static final int SEERS_RING_I_26767 = 26767;
  
  public static final int ARCHERS_RING_I_26768 = 26768;
  
  public static final int WARRIOR_RING_I_26769 = 26769;
  
  public static final int BERSERKER_RING_I_26770 = 26770;
  
  public static final int BLACK_MASK_10_I_26771 = 26771;
  
  public static final int BLACK_MASK_9_I_26772 = 26772;
  
  public static final int BLACK_MASK_8_I_26773 = 26773;
  
  public static final int BLACK_MASK_7_I_26774 = 26774;
  
  public static final int BLACK_MASK_6_I_26775 = 26775;
  
  public static final int BLACK_MASK_5_I_26776 = 26776;
  
  public static final int BLACK_MASK_4_I_26777 = 26777;
  
  public static final int BLACK_MASK_3_I_26778 = 26778;
  
  public static final int BLACK_MASK_2_I_26779 = 26779;
  
  public static final int BLACK_MASK_1_I_26780 = 26780;
  
  public static final int BLACK_MASK_I_26781 = 26781;
  
  public static final int SALVE_AMULETEI_26782 = 26782;
  
  public static final int COLOSSAL_POUCH = 26784;
  
  public static final int COLOSSAL_POUCH_26786 = 26786;
  
  public static final int GOLD_TIARA = 26788;
  
  public static final int ABYSSAL_PEARLS = 26792;
  
  public static final int CATALYTIC_TALISMAN = 26798;
  
  public static final int CATALYTIC_TIARA = 26801;
  
  public static final int ELEMENTAL_TIARA = 26804;
  
  public static final int ABYSSAL_GREEN_DYE = 26807;
  
  public static final int ABYSSAL_BLUE_DYE = 26809;
  
  public static final int ABYSSAL_RED_DYE = 26811;
  
  public static final int ABYSSAL_NEEDLE = 26813;
  
  public static final int RING_OF_THE_ELEMENTS = 26815;
  
  public static final int RING_OF_THE_ELEMENTS_26818 = 26818;
  
  public static final int GUARDIANS_EYE = 26820;
  
  public static final int ABYSSAL_LANTERN = 26822;
  
  public static final int ABYSSAL_LANTERN_NORMAL_LOGS = 26824;
  
  public static final int ABYSSAL_LANTERN_BLUE_LOGS = 26826;
  
  public static final int ABYSSAL_LANTERN_RED_LOGS = 26828;
  
  public static final int ABYSSAL_LANTERN_WHITE_LOGS = 26830;
  
  public static final int ABYSSAL_LANTERN_PURPLE_LOGS = 26832;
  
  public static final int ABYSSAL_LANTERN_GREEN_LOGS = 26834;
  
  public static final int ABYSSAL_LANTERN_OAK_LOGS = 26836;
  
  public static final int ABYSSAL_LANTERN_WILLOW_LOGS = 26838;
  
  public static final int ABYSSAL_LANTERN_MAPLE_LOGS = 26840;
  
  public static final int ABYSSAL_LANTERN_YEW_LOGS = 26842;
  
  public static final int ABYSSAL_LANTERN_BLISTERWOOD_LOGS = 26844;
  
  public static final int ABYSSAL_LANTERN_MAGIC_LOGS = 26846;
  
  public static final int ABYSSAL_LANTERN_REDWOOD_LOGS = 26848;
  
  public static final int HAT_OF_THE_EYE = 26850;
  
  public static final int ROBE_TOP_OF_THE_EYE = 26852;
  
  public static final int ROBE_BOTTOMS_OF_THE_EYE = 26854;
  
  public static final int BOOTS_OF_THE_EYE = 26856;
  
  public static final int HAT_OF_THE_EYE_RED = 26858;
  
  public static final int ROBE_TOP_OF_THE_EYE_RED = 26860;
  
  public static final int ROBE_BOTTOMS_OF_THE_EYE_RED = 26862;
  
  public static final int HAT_OF_THE_EYE_GREEN = 26864;
  
  public static final int ROBE_TOP_OF_THE_EYE_GREEN = 26866;
  
  public static final int ROBE_BOTTOMS_OF_THE_EYE_GREEN = 26868;
  
  public static final int HAT_OF_THE_EYE_BLUE = 26870;
  
  public static final int ROBE_TOP_OF_THE_EYE_BLUE = 26872;
  
  public static final int ROBE_BOTTOMS_OF_THE_EYE_BLUE = 26874;
  
  public static final int ATLAXS_DIARY = 26876;
  
  public static final int GUARDIAN_FRAGMENTS = 26878;
  
  public static final int GUARDIAN_ESSENCE = 26879;
  
  public static final int CATALYTIC_GUARDIAN_STONE = 26880;
  
  public static final int ELEMENTAL_GUARDIAN_STONE = 26881;
  
  public static final int UNCHARGED_CELL = 26882;
  
  public static final int WEAK_CELL = 26883;
  
  public static final int MEDIUM_CELL = 26884;
  
  public static final int STRONG_CELL = 26885;
  
  public static final int OVERCHARGED_CELL = 26886;
  
  public static final int PORTAL_TALISMAN_AIR = 26887;
  
  public static final int PORTAL_TALISMAN_WATER = 26888;
  
  public static final int PORTAL_TALISMAN_EARTH = 26889;
  
  public static final int PORTAL_TALISMAN_FIRE = 26890;
  
  public static final int PORTAL_TALISMAN_MIND = 26891;
  
  public static final int PORTAL_TALISMAN_CHAOS = 26892;
  
  public static final int PORTAL_TALISMAN_DEATH = 26893;
  
  public static final int PORTAL_TALISMAN_BLOOD = 26894;
  
  public static final int PORTAL_TALISMAN_BODY = 26895;
  
  public static final int PORTAL_TALISMAN_COSMIC = 26896;
  
  public static final int PORTAL_TALISMAN_NATURE = 26897;
  
  public static final int PORTAL_TALISMAN_LAW = 26898;
  
  public static final int GREATISH_GUARDIAN = 26899;
  
  public static final int ABYSSAL_PROTECTOR = 26901;
  
  public static final int EYE_AMULET = 26903;
  
  public static final int STRONG_CUP_OF_TEA = 26904;
  
  public static final int ABYSSAL_INCANTATION = 26905;
  
  public static final int COLOSSAL_POUCH_26906 = 26906;
  
  public static final int INTRICATE_POUCH = 26908;
  
  public static final int TARNISHED_LOCKET = 26910;
  
  public static final int LOST_BAG = 26912;
  
  public static final int AMULET_OF_THE_EYE = 26914;
  
  public static final int SPECIAL_HOT_SAUCE = 26916;
  
  public static final int SPECIAL_SUPER_HOT_KEBAB = 26917;
  
  public static final int SECRET_REPORT = 26918;
  
  public static final int BIG_BUCKET = 26919;
  
  public static final int BIG_BUCKET_OF_CAMEL_MILK = 26920;
  
  public static final int BIG_BUCKET_OF_FROZEN_CAMEL_MILK = 26921;
  
  public static final int MAGICAL_CLEANING_POTION_26924 = 26924;
  
  public static final int COOLER = 26925;
  
  public static final int EASTER_EGG_26926 = 26926;
  
  public static final int MELTED_EASTER_EGG = 26927;
  
  public static final int ICE_CREAM_EASTER_EGG = 26928;
  
  public static final int BLUNT_SCIMITARS = 26929;
  
  public static final int WASHING_LINE = 26930;
  
  public static final int TANNING_WHEEL = 26931;
  
  public static final int VAT_DIRTY = 26932;
  
  public static final int VAT_CLEANED = 26933;
  
  public static final int WOODEN_POLE = 26934;
  
  public static final int CHURNING_MACHINE = 26935;
  
  public static final int FROZEN_CHURNING_MACHINE = 26936;
  
  public static final int EASTER_HAT = 26937;
  
  public static final int CRATE_RING = 26939;
  
  public static final int POLYELEMENTAL_GUARDIAN_STONE = 26941;
  
  public static final int MESSAGE_26942 = 26942;
  
  public static final int CLUE_SCROLL_ELITE_26943 = 26943;
  
  public static final int CLUE_SCROLL_ELITE_26944 = 26944;
  
  public static final int PHARAOHS_SCEPTRE_UNCHARGED = 26945;
  
  public static final int PHARAOHS_SCEPTRE_26948 = 26948;
  
  public static final int PHARAOHS_SCEPTRE_26950 = 26950;
  
  public static final int SCARAB_MOULD = 26952;
  
  public static final int SCARAB_EMBLEM = 26953;
  
  public static final int STONE_TABLET_26954 = 26954;
  
  public static final int CHEST_26955 = 26955;
  
  public static final int SCARAB_EMBLEM_26956 = 26956;
  
  public static final int HUMAN_EMBLEM = 26957;
  
  public static final int BABOON_EMBLEM = 26958;
  
  public static final int CROCODILE_EMBLEM = 26959;
  
  public static final int RUSTY_KEY = 26960;
  
  public static final int LILY_OF_THE_ELID = 26961;
  
  public static final int CURE_CRATE = 26962;
  
  public static final int ODD_SPECTACLES = 26963;
  
  public static final int BOTTLE_OF_TONIC = 26965;
  
  public static final int CIRCLET_OF_WATER_UNCHARGED = 26967;
  
  public static final int CIRCLET_OF_WATER = 26969;
  
  public static final int CABBAGE_26971 = 26971;
  
  public static final int CABBAGE_26973 = 26973;
  
  public static final int CABBAGE_26975 = 26975;
  
  public static final int CABBAGE_26977 = 26977;
  
  public static final int CABBAGE_26979 = 26979;
  
  public static final int LOST_BAG_26984 = 26984;
  
  public static final int LOST_BAG_26986 = 26986;
  
  public static final int LOST_BAG_26988 = 26988;
  
  public static final int AMULET_OF_THE_EYE_26990 = 26990;
  
  public static final int AMULET_OF_THE_EYE_26992 = 26992;
  
  public static final int AMULET_OF_THE_EYE_26994 = 26994;
  
  public static final int ENSOULED_HELLHOUND_HEAD = 26996;
  
  public static final int ENSOULED_HELLHOUND_HEAD_26997 = 26997;
  
  public static final int VOID_KNIGHT_TOP_LOR = 27000;
  
  public static final int VOID_KNIGHT_ROBE_LOR = 27001;
  
  public static final int VOID_KNIGHT_GLOVES_LOR = 27002;
  
  public static final int ELITE_VOID_TOP_LOR = 27003;
  
  public static final int ELITE_VOID_ROBE_LOR = 27004;
  
  public static final int VOID_MAGE_HELM_LOR = 27005;
  
  public static final int VOID_RANGER_HELM_LOR = 27006;
  
  public static final int VOID_MELEE_HELM_LOR = 27007;
  
  public static final int DRAGON_DEFENDER_LT = 27008;
  
  public static final int RUNE_DEFENDER_LT = 27009;
  
  public static final int PREFORM = 27010;
  
  public static final int DOUBLE_AMMO_MOULD = 27012;
  
  public static final int KOVACS_GROG = 27014;
  
  public static final int SMITHING_CATALYST = 27017;
  
  public static final int ORE_PACK = 27019;
  
  public static final int COLOSSAL_BLADE = 27021;
  
  public static final int SMITHS_TUNIC = 27023;
  
  public static final int SMITHS_TROUSERS = 27025;
  
  public static final int SMITHS_BOOTS = 27027;
  
  public static final int SMITHS_GLOVES = 27029;
  
  public static final int SMITHS_GLOVES_I = 27031;
  
  public static final int FLOWER_CROWN = 27035;
  
  public static final int LEGENDARY_RED_ROSE_SEED = 27037;
  
  public static final int GORGEOUS_ORANGE_LILY_SEED = 27038;
  
  public static final int BEAUTIFUL_YELLOW_PANSY_SEED = 27039;
  
  public static final int TENACIOUS_INDIGO_IRIS_SEED = 27040;
  
  public static final int QUALITY_VIOLET_TULIP_SEED = 27041;
  
  public static final int GROUP_IRONMAN_HELM_UNRANKED = 27042;
  
  public static final int GROUP_IRONMAN_PLATELEGS_UNRANKED = 27044;
  
  public static final int GROUP_IRONMAN_BRACERS_UNRANKED = 27046;
  
  public static final int GROUP_IRONMAN_PLATEBODY_UNRANKED = 27048;
  
  public static final int GROUP_IRONMAN_PLATEBODY_UNRANKED_27050 = 27050;
  
  public static final int GROUP_IRONMAN_PLATEBODY_UNRANKED_27052 = 27052;
  
  public static final int GROUP_IRONMAN_PLATEBODY_UNRANKED_27054 = 27054;
  
  public static final int RUNE_POUCH_27086 = 27086;
  
  public static final int ELDER_MAUL_ORNAMENT_KIT = 27098;
  
  public static final int ELDER_MAUL_OR = 27100;
  
  public static final int MITHRIL_GLOVES_WRAPPED = 27110;
  
  public static final int RUNE_GLOVES_WRAPPED = 27111;
  
  public static final int BARROWS_GLOVES_WRAPPED = 27112;
  
  public static final int ELDER_CHAOS_ROBES_ORNAMENT_KIT = 27113;
  
  public static final int ELDER_CHAOS_TOP_OR = 27115;
  
  public static final int ELDER_CHAOS_ROBE_OR = 27117;
  
  public static final int ELDER_CHAOS_HOOD_OR = 27119;
  
  public static final int DAGONHAI_ROBES_ORNAMENT_KIT = 27121;
  
  public static final int DAGONHAI_HAT_OR = 27123;
  
  public static final int DAGONHAI_ROBE_TOP_OR = 27125;
  
  public static final int DAGONHAI_ROBE_BOTTOM_OR = 27127;
  
  public static final int FLOWER_CROWN_27141 = 27141;
  
  public static final int FLOWER_CROWN_27143 = 27143;
  
  public static final int FLOWER_CROWN_27145 = 27145;
  
  public static final int FLOWER_CROWN_27147 = 27147;
  
  public static final int FLOWER_CROWN_27149 = 27149;
  
  public static final int FLOWER_CROWN_27151 = 27151;
  
  public static final int FLOWER_CROWN_27153 = 27153;
  
  public static final int FLOWER_CROWN_27155 = 27155;
  
  public static final int DRAGON_KNIFE_27157 = 27157;
  
  public static final int MYSTIC_ROBE_TOP_DARK_27158 = 27158;
  
  public static final int MYSTIC_ROBE_BOTTOM_DARK_27159 = 27159;
  
  public static final int MYSTIC_ROBE_TOP_LIGHT_27160 = 27160;
  
  public static final int MYSTIC_ROBE_BOTTOM_LIGHT_27161 = 27161;
  
  public static final int WIZARD_BOOTS_27162 = 27162;
  
  public static final int GUTHIX_HALO_27163 = 27163;
  
  public static final int ZAMORAK_HALO_27164 = 27164;
  
  public static final int SARADOMIN_HALO_27165 = 27165;
  
  public static final int GHOSTLY_HOOD_27166 = 27166;
  
  public static final int GHOSTLY_ROBE_27167 = 27167;
  
  public static final int GHOSTLY_ROBE_27168 = 27168;
  
  public static final int BERSERKER_HELM_27169 = 27169;
  
  public static final int INFINITY_BOOTS_27170 = 27170;
  
  public static final int TORMENTED_BRACELET_27171 = 27171;
  
  public static final int NECKLACE_OF_ANGUISH_27172 = 27172;
  
  public static final int AMULET_OF_TORTURE_27173 = 27173;
  
  public static final int ELDER_CHAOS_TOP_27174 = 27174;
  
  public static final int ELDER_CHAOS_ROBE_27175 = 27175;
  
  public static final int ELDER_CHAOS_HOOD_27176 = 27176;
  
  public static final int FREMENNIK_KILT_27177 = 27177;
  
  public static final int SPIKED_MANACLES_27178 = 27178;
  
  public static final int RANGERS_TUNIC_27179 = 27179;
  
  public static final int GUTHIX_CHAPS_27180 = 27180;
  
  public static final int ZAMORAK_CHAPS_27181 = 27181;
  
  public static final int SARADOMIN_CHAPS_27182 = 27182;
  
  public static final int _3RD_AGE_MAGE_HAT_27183 = 27183;
  
  public static final int ANCIENT_GODSWORD_27184 = 27184;
  
  public static final int RUNE_DEFENDER_27185 = 27185;
  
  public static final int ZARYTE_CROSSBOW_27186 = 27186;
  
  public static final int BOW_OF_FAERDHINEN_27187 = 27187;
  
  public static final int LIGHT_BALLISTA_27188 = 27188;
  
  public static final int VERACS_FLAIL_27189 = 27189;
  
  public static final int VERACS_BRASSARD_27190 = 27190;
  
  public static final int UNHOLY_BOOK_27191 = 27191;
  
  public static final int OPAL_DRAGON_BOLTS_E_27192 = 27192;
  
  public static final int ANCESTRAL_ROBE_TOP_27193 = 27193;
  
  public static final int ANCESTRAL_ROBE_BOTTOM_27194 = 27194;
  
  public static final int INQUISITORS_GREAT_HELM_27195 = 27195;
  
  public static final int INQUISITORS_HAUBERK_27196 = 27196;
  
  public static final int INQUISITORS_PLATESKIRT_27197 = 27197;
  
  public static final int INQUISITORS_MACE_27198 = 27198;
  
  public static final int _3RD_AGE_RANGE_TOP_27199 = 27199;
  
  public static final int _3RD_AGE_RANGE_LEGS_27200 = 27200;
  
  public static final int _3RD_AGE_RANGE_COIF_27201 = 27201;
  
  public static final int MENAPHITE_REMEDY4 = 27202;
  
  public static final int MENAPHITE_REMEDY3 = 27205;
  
  public static final int MENAPHITE_REMEDY2 = 27208;
  
  public static final int MENAPHITE_REMEDY1 = 27211;
  
  public static final int SCARAB_DUNG = 27214;
  
  public static final int FOSSILISED_DUNG = 27216;
  
  public static final int FANG_27219 = 27219;
  
  public static final int BIG_BANANA = 27221;
  
  public static final int ELDRITCH_ASHES = 27223;
  
  public static final int GRAIN_27225 = 27225;
  
  public static final int MASORI_MASK = 27226;
  
  public static final int MASORI_BODY = 27229;
  
  public static final int MASORI_CHAPS = 27232;
  
  public static final int MASORI_MASK_F = 27235;
  
  public static final int MASORI_BODY_F = 27238;
  
  public static final int MASORI_CHAPS_F = 27241;
  
  public static final int OSMUMTENS_FANG_OR = 27246;
  
  public static final int CURSED_PHALANX = 27248;
  
  public static final int ELIDINIS_WARD_F = 27251;
  
  public static final int ELIDINIS_WARD_OR = 27253;
  
  public static final int MENAPHITE_ORNAMENT_KIT = 27255;
  
  public static final int ICTHLARINS_SHROUD_TIER_1 = 27257;
  
  public static final int ICTHLARINS_SHROUD_TIER_2 = 27259;
  
  public static final int ICTHLARINS_SHROUD_TIER_3 = 27261;
  
  public static final int ICTHLARINS_SHROUD_TIER_4 = 27263;
  
  public static final int ICTHLARINS_SHROUD_TIER_5 = 27265;
  
  public static final int ICTHLARINS_HOOD_TIER_5 = 27267;
  
  public static final int ARMADYLEAN_PLATE = 27269;
  
  public static final int LILY_OF_THE_SANDS = 27272;
  
  public static final int TUMEKENS_SHADOW = 27275;
  
  public static final int TUMEKENS_SHADOW_UNCHARGED = 27277;
  
  public static final int THREAD_OF_ELIDINIS = 27279;
  
  public static final int DIVINE_RUNE_POUCH = 27281;
  
  public static final int BREACH_OF_THE_SCARAB = 27283;
  
  public static final int EYE_OF_THE_CORRUPTOR = 27285;
  
  public static final int KERIS_PARTISAN_OF_CORRUPTION = 27287;
  
  public static final int JEWEL_OF_THE_SUN = 27289;
  
  public static final int KERIS_PARTISAN_OF_THE_SUN = 27291;
  
  public static final int CACHE_OF_RUNES = 27293;
  
  public static final int WATER_CONTAINER_27295 = 27295;
  
  public static final int MIRROR_27296 = 27296;
  
  public static final int NEUTRALISING_POTION = 27297;
  
  public static final int MAISAS_MESSAGE = 27298;
  
  public static final int ANTIQUE_LAMP_27299 = 27299;
  
  public static final int AKILAS_JOURNAL = 27300;
  
  public static final int HETS_CAPTURE = 27302;
  
  public static final int APMEKENS_CAPTURE = 27304;
  
  public static final int SCABARAS_CAPTURE = 27306;
  
  public static final int CRONDIS_CAPTURE = 27308;
  
  public static final int THE_WARDENS = 27310;
  
  public static final int THE_JACKALS_TORCH = 27312;
  
  public static final int SUPPLIES = 27314;
  
  public static final int NECTAR_4 = 27315;
  
  public static final int NECTAR_3 = 27317;
  
  public static final int NECTAR_2 = 27319;
  
  public static final int NECTAR_1 = 27321;
  
  public static final int SILK_DRESSING_2 = 27323;
  
  public static final int SILK_DRESSING_1 = 27325;
  
  public static final int TEARS_OF_ELIDINIS_4 = 27327;
  
  public static final int TEARS_OF_ELIDINIS_3 = 27329;
  
  public static final int TEARS_OF_ELIDINIS_2 = 27331;
  
  public static final int TEARS_OF_ELIDINIS_1 = 27333;
  
  public static final int BLESSED_CRYSTAL_SCARAB_2 = 27335;
  
  public static final int BLESSED_CRYSTAL_SCARAB_1 = 27337;
  
  public static final int LIQUID_ADRENALINE_2 = 27339;
  
  public static final int LIQUID_ADRENALINE_1 = 27341;
  
  public static final int SMELLING_SALTS_2 = 27343;
  
  public static final int SMELLING_SALTS_1 = 27345;
  
  public static final int AMBROSIA_2 = 27347;
  
  public static final int AMBROSIA_1 = 27349;
  
  public static final int HONEY_LOCUST = 27351;
  
  public static final int TUMEKENS_GUARDIAN = 27352;
  
  public static final int ELIDINIS_GUARDIAN = 27354;
  
  public static final int MASORI_ARMOUR_SET_F = 27355;
  
  public static final int TOME_OF_FIRE_27358 = 27358;
  
  public static final int MASORI_ASSEMBLER_BROKEN = 27359;
  
  public static final int MASORI_ASSEMBLER_MAX_CAPE_BROKEN = 27361;
  
  public static final int MASORI_ASSEMBLER_MAX_CAPE = 27363;
  
  public static final int MASORI_ASSEMBLER_MAX_CAPE_L = 27365;
  
  public static final int MASORI_ASSEMBLER_MAX_HOOD = 27366;
  
  public static final int DAWN_SCARAB_EGG = 27368;
  
  public static final int ANCIENT_KEY_27369 = 27369;
  
  public static final int MASK_OF_REBIRTH = 27370;
  
  public static final int MASORI_CRAFTING_KIT = 27372;
  
  public static final int MASORI_ASSEMBLER = 27374;
  
  public static final int MASORI_ASSEMBLER_L = 27376;
  
  public static final int REMNANT_OF_AKKHA = 27377;
  
  public static final int REMNANT_OF_BABA = 27378;
  
  public static final int REMNANT_OF_KEPHRI = 27379;
  
  public static final int REMNANT_OF_ZEBAK = 27380;
  
  public static final int ANCIENT_REMNANT = 27381;
  
  public static final int AKKHITO = 27382;
  
  public static final int BABI = 27383;
  
  public static final int KEPHRITI = 27384;
  
  public static final int ZEBO = 27385;
  
  public static final int TUMEKENS_DAMAGED_GUARDIAN = 27386;
  
  public static final int ELIDINIS_DAMAGED_GUARDIAN = 27387;
  
  public static final int ADVENTURERS_TOP_T1 = 27388;
  
  public static final int ADVENTURERS_TROUSERS_T1 = 27390;
  
  public static final int ADVENTURERS_HOOD_T1 = 27392;
  
  public static final int ADVENTURERS_BOOTS_T1 = 27394;
  
  public static final int ADVENTURERS_TOP_T2 = 27396;
  
  public static final int ADVENTURERS_TROUSERS_T2 = 27398;
  
  public static final int ADVENTURERS_HOOD_T2 = 27400;
  
  public static final int ADVENTURERS_BOOTS_T2 = 27402;
  
  public static final int ADVENTURERS_TOP_T3 = 27404;
  
  public static final int ADVENTURERS_TROUSERS_T3 = 27406;
  
  public static final int ADVENTURERS_HOOD_T3 = 27408;
  
  public static final int ADVENTURERS_BOOTS_T3 = 27410;
  
  public static final int ADVENTURERS_VAMBRACES = 27412;
  
  public static final int GIANT_STOPWATCH = 27414;
  
  public static final int SPEEDY_TELEPORT_SCROLL = 27416;
  
  public static final int BRONZE_SPEEDRUN_TROPHY = 27418;
  
  public static final int SILVER_SPEEDRUN_TROPHY = 27420;
  
  public static final int GOLD_SPEEDRUN_TROPHY = 27422;
  
  public static final int PLATINUM_SPEEDRUN_TROPHY = 27424;
  
  public static final int DYNAMITEP = 27426;
  
  public static final int CLUE_SCROLL_SPECIAL = 27427;
  
  public static final int HOOD_OF_RUIN = 27428;
  
  public static final int ROBE_TOP_OF_RUIN = 27430;
  
  public static final int ROBE_BOTTOM_OF_RUIN = 27432;
  
  public static final int GLOVES_OF_RUIN = 27434;
  
  public static final int SOCKS_OF_RUIN = 27436;
  
  public static final int CLOAK_OF_RUIN = 27438;
  
  public static final int INFINITE_MONEY_BAG = 27440;
  
  public static final int ADVENTURERS_CAPE = 27442;
  
  public static final int GRACEFUL_HOOD_27444 = 27444;
  
  public static final int GRACEFUL_HOOD_27446 = 27446;
  
  public static final int GRACEFUL_CAPE_27447 = 27447;
  
  public static final int GRACEFUL_CAPE_27449 = 27449;
  
  public static final int GRACEFUL_TOP_27450 = 27450;
  
  public static final int GRACEFUL_TOP_27452 = 27452;
  
  public static final int GRACEFUL_LEGS_27453 = 27453;
  
  public static final int GRACEFUL_LEGS_27455 = 27455;
  
  public static final int GRACEFUL_GLOVES_27456 = 27456;
  
  public static final int GRACEFUL_GLOVES_27458 = 27458;
  
  public static final int GRACEFUL_BOOTS_27459 = 27459;
  
  public static final int GRACEFUL_BOOTS_27461 = 27461;
  
  public static final int FRESH_START_HELPER = 27462;
  
  public static final int TREAT_CAULDRON = 27463;
  
  public static final int TREAT_CAULDRON_27465 = 27465;
  
  public static final int TREAT_CAULDRON_27467 = 27467;
  
  public static final int TREAT_CAULDRON_27469 = 27469;
  
  public static final int TREAT_CAULDRON_27471 = 27471;
  
  public static final int WITCH_HAT = 27473;
  
  public static final int WITCH_TOP = 27475;
  
  public static final int WITCH_ROBES = 27477;
  
  public static final int WITCH_BOOTS = 27479;
  
  public static final int WITCH_CAPE = 27481;
  
  public static final int TERRIFYING_CHARM = 27483;
  
  public static final int BRUISED_BANANA = 27485;
  
  public static final int SMELLY_SOCK = 27488;
  
  public static final int SPOOKY_EGG = 27491;
  
  public static final int OLD_WOOL = 27494;
  
  public static final int HALLOWEEN_WIG = 27497;
  
  public static final int HALLOWEEN_WIG_27499 = 27499;
  
  public static final int HALLOWEEN_WIG_27501 = 27501;
  
  public static final int HALLOWEEN_WIG_27503 = 27503;
  
  public static final int HALLOWEEN_WIG_27505 = 27505;
  
  public static final int HALLOWEEN_WIG_27507 = 27507;
  
  public static final int DIVINE_RUNE_POUCH_L = 27509;
  
  public static final int KASONDES_JOURNAL = 27511;
  
  public static final int WORD_TRANSLATIONS = 27513;
  
  public static final int DIRTY_NOTE = 27515;
  
  public static final int DIRTY_NOTE_27516 = 27516;
  
  public static final int DIRTY_NOTE_27517 = 27517;
  
  public static final int WARNING_NOTE = 27518;
  
  public static final int STONE_TABLET_27519 = 27519;
  
  public static final int STONE_TABLET_27520 = 27520;
  
  public static final int STONE_TABLET_27521 = 27521;
  
  public static final int STONE_TABLET_27522 = 27522;
  
  public static final int WOOD_CARVING = 27523;
  
  public static final int WOOD_CARVING_27524 = 27524;
  
  public static final int WOOD_CARVING_27525 = 27525;
  
  public static final int WOOD_CARVING_27526 = 27526;
  
  public static final int WOOD_CARVING_27527 = 27527;
  
  public static final int WOOD_CARVING_27528 = 27528;
  
  public static final int WOOD_CARVING_27529 = 27529;
  
  public static final int WOOD_CARVING_27530 = 27530;
  
  public static final int WOOD_CARVING_27531 = 27531;
  
  public static final int COMPASS = 27532;
  
  public static final int WOOD_CARVING_27533 = 27533;
  
  public static final int WOOD_CARVING_27534 = 27534;
  
  public static final int WOOD_CARVING_27535 = 27535;
  
  public static final int WOOD_CARVING_27536 = 27536;
  
  public static final int WOOD_CARVING_27537 = 27537;
  
  public static final int ANTIQUE_LAMP_27543 = 27543;
  
  public static final int GHOMMALS_LUCKY_PENNY = 27544;
  
  public static final int ANIM_OFFHAND_27546 = 27546;
  
  public static final int ANIM_OFFHAND_27548 = 27548;
  
  public static final int GHOMMALS_AVERNIC_DEFENDER_5 = 27550;
  
  public static final int GHOMMALS_AVERNIC_DEFENDER_5_L = 27551;
  
  public static final int GHOMMALS_AVERNIC_DEFENDER_6 = 27552;
  
  public static final int GHOMMALS_AVERNIC_DEFENDER_6_L = 27553;
  
  public static final int PERFECT_GINGERBREAD = 27554;
  
  public static final int BROKEN_GINGERBREAD = 27555;
  
  public static final int VERY_BROKEN_GINGERBREAD = 27556;
  
  public static final int SHATTERED_GINGERBREAD = 27557;
  
  public static final int SACK_OF_COAL = 27558;
  
  public static final int SNOWBALL_27559 = 27559;
  
  public static final int GOLDEN_SNOWBALL = 27560;
  
  public static final int LIGHT_BEER = 27561;
  
  public static final int MULLED_PINE = 27562;
  
  public static final int EGGNOG = 27563;
  
  public static final int SANTAS_LIST = 27564;
  
  public static final int CHRISTMAS_JUMPER = 27566;
  
  public static final int SNOW_GOGGLES__HAT = 27568;
  
  public static final int SACK_OF_COAL_27570 = 27570;
  
  public static final int FESTIVE_NUTCRACKER_TOP = 27572;
  
  public static final int FESTIVE_NUTCRACKER_TROUSERS = 27574;
  
  public static final int FESTIVE_NUTCRACKER_HAT = 27576;
  
  public static final int FESTIVE_NUTCRACKER_BOOTS = 27578;
  
  public static final int FESTIVE_NUTCRACKER_STAFF = 27580;
  
  public static final int SWEET_NUTCRACKER_TOP = 27582;
  
  public static final int SWEET_NUTCRACKER_TROUSERS = 27583;
  
  public static final int SWEET_NUTCRACKER_HAT = 27584;
  
  public static final int SWEET_NUTCRACKER_BOOTS = 27585;
  
  public static final int SWEET_NUTCRACKER_STAFF = 27586;
  
  public static final int FESTIVE_GAMES_CROWN = 27588;
  
  public static final int MUPHIN = 27590;
  
  public static final int MUPHIN_27592 = 27592;
  
  public static final int MUPHIN_27593 = 27593;
  
  public static final int DUSTY_SCROLL_27595 = 27595;
  
  public static final int TULLIAS_LETTER = 27596;
  
  public static final int ANCIENT_MAP = 27597;
  
  public static final int STRANGE_CIPHER = 27598;
  
  public static final int STRANGE_LIST = 27599;
  
  public static final int DUKE_NOTE = 27600;
  
  public static final int NUMBERS_NOTE = 27601;
  
  public static final int SETTLEMENTS_NOTE = 27602;
  
  public static final int LEVER_HANDLE = 27603;
  
  public static final int ICY_CHEST = 27604;
  
  public static final int JEWEL_SHARD = 27605;
  
  public static final int JEWEL_SHARD_27606 = 27606;
  
  public static final int ANCIENT_JEWEL = 27607;
  
  public static final int ICY_KEY = 27608;
  
  public static final int VENATOR_BOW = 27610;
  
  public static final int VENATOR_BOW_UNCHARGED = 27612;
  
  public static final int VENATOR_SHARD = 27614;
  
  public static final int ANCIENT_ESSENCE = 27616;
  
  public static final int FROZEN_CACHE = 27622;
  
  public static final int ANCIENT_SCEPTRE = 27624;
  
  public static final int ANCIENT_SCEPTRE_L = 27626;
  
  public static final int ANCIENT_ICON = 27627;
  
  public static final int FORGOTTEN_BREW4 = 27629;
  
  public static final int FORGOTTEN_BREW3 = 27632;
  
  public static final int FORGOTTEN_BREW2 = 27635;
  
  public static final int FORGOTTEN_BREW1 = 27638;
  
  public static final int SATURATED_HEART = 27641;
  
  public static final int CHARGED_ICE = 27643;
  
  public static final int MYSTIC_CARDS = 27645;
  
  public static final int VENENATIS_SPIDERLING_27648 = 27648;
  
  public static final int CALLISTO_CUB_27649 = 27649;
  
  public static final int VETION_JR_27650 = 27650;
  
  public static final int VETION_JR_27651 = 27651;
  
  public static final int WEBWEAVER_BOW_U = 27652;
  
  public static final int WEBWEAVER_BOW = 27655;
  
  public static final int URSINE_CHAINMACE_U = 27657;
  
  public static final int URSINE_CHAINMACE = 27660;
  
  public static final int ACCURSED_SCEPTRE_U = 27662;
  
  public static final int ACCURSED_SCEPTRE = 27665;
  
  public static final int CLAWS_OF_CALLISTO = 27667;
  
  public static final int FANGS_OF_VENENATIS = 27670;
  
  public static final int SKULL_OF_VETION = 27673;
  
  public static final int ACCURSED_SCEPTRE_AU = 27676;
  
  public static final int ACCURSED_SCEPTRE_A = 27679;
  
  public static final int VOIDWAKER_HILT = 27681;
  
  public static final int VOIDWAKER_BLADE = 27684;
  
  public static final int VOIDWAKER_GEM = 27687;
  
  public static final int VOIDWAKER = 27690;
  
  public static final int ORE_PACK_27693 = 27693;
  
  public static final int DRAGON_PICKAXE_BROKEN = 27695;
  
  public static final int CRYSTAL_BODY_27697 = 27697;
  
  public static final int CRYSTAL_BODY_INACTIVE_27699 = 27699;
  
  public static final int CRYSTAL_LEGS_27701 = 27701;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27703 = 27703;
  
  public static final int CRYSTAL_HELM_27705 = 27705;
  
  public static final int CRYSTAL_HELM_INACTIVE_27707 = 27707;
  
  public static final int CRYSTAL_BODY_27709 = 27709;
  
  public static final int CRYSTAL_BODY_INACTIVE_27711 = 27711;
  
  public static final int CRYSTAL_LEGS_27713 = 27713;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27715 = 27715;
  
  public static final int CRYSTAL_HELM_27717 = 27717;
  
  public static final int CRYSTAL_HELM_INACTIVE_27719 = 27719;
  
  public static final int CRYSTAL_BODY_27721 = 27721;
  
  public static final int CRYSTAL_BODY_INACTIVE_27723 = 27723;
  
  public static final int CRYSTAL_LEGS_27725 = 27725;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27727 = 27727;
  
  public static final int CRYSTAL_HELM_27729 = 27729;
  
  public static final int CRYSTAL_HELM_INACTIVE_27731 = 27731;
  
  public static final int CRYSTAL_BODY_27733 = 27733;
  
  public static final int CRYSTAL_BODY_INACTIVE_27735 = 27735;
  
  public static final int CRYSTAL_LEGS_27737 = 27737;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27739 = 27739;
  
  public static final int CRYSTAL_HELM_27741 = 27741;
  
  public static final int CRYSTAL_HELM_INACTIVE_27743 = 27743;
  
  public static final int CRYSTAL_BODY_27745 = 27745;
  
  public static final int CRYSTAL_BODY_INACTIVE_27747 = 27747;
  
  public static final int CRYSTAL_LEGS_27749 = 27749;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27751 = 27751;
  
  public static final int CRYSTAL_HELM_27753 = 27753;
  
  public static final int CRYSTAL_HELM_INACTIVE_27755 = 27755;
  
  public static final int CRYSTAL_BODY_27757 = 27757;
  
  public static final int CRYSTAL_BODY_INACTIVE_27759 = 27759;
  
  public static final int CRYSTAL_LEGS_27761 = 27761;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27763 = 27763;
  
  public static final int CRYSTAL_HELM_27765 = 27765;
  
  public static final int CRYSTAL_HELM_INACTIVE_27767 = 27767;
  
  public static final int CRYSTAL_BODY_27769 = 27769;
  
  public static final int CRYSTAL_BODY_INACTIVE_27771 = 27771;
  
  public static final int CRYSTAL_LEGS_27773 = 27773;
  
  public static final int CRYSTAL_LEGS_INACTIVE_27775 = 27775;
  
  public static final int CRYSTAL_HELM_27777 = 27777;
  
  public static final int CRYSTAL_HELM_INACTIVE_27779 = 27779;
  
  public static final int CABBAGE_27781 = 27781;
  
  public static final int DIAMOND_SPEEDRUN_TROPHY = 27783;
  
  public static final int THAMMARONS_SCEPTRE_AU = 27785;
  
  public static final int THAMMARONS_SCEPTRE_A = 27788;
  
  public static final int NIGHTSHADE = 27790;
  
  public static final int GNOME_CHILD_BACKPACK = 27802;
  
  public static final int CAKE_HAT = 27804;
  
  public static final int BOB_THE_CAT_SLIPPERS = 27806;
  
  public static final int JAD_SLIPPERS = 27808;
  
  public static final int DRAGON_CANDLE_DAGGER = 27810;
  
  public static final int _10TH_BIRTHDAY_CAPE = 27812;
  
  public static final int JAD_PLUSH = 27814;
  
  public static final int STRAY_DOG_PLUSH = 27816;
  
  public static final int GNOME_CHILD_PLUSH = 27818;
  
  public static final int _10TH_BIRTHDAY_BALLOONS = 27820;
  
  public static final int OLDSCHOOL_JUMPER = 27822;
  
  public static final int OLDSCHOOL_JUMPER_27823 = 27823;
  
  public static final int OLDSCHOOL_JUMPER_27824 = 27824;
  
  public static final int OLDSCHOOL_JUMPER_27825 = 27825;
  
  public static final int OLDSCHOOL_JUMPER_27826 = 27826;
  
  public static final int OLDSCHOOL_JUMPER_27827 = 27827;
  
  public static final int SILVER_PARTYHAT = 27828;
  
  public static final int VESTAS_CHAINBODY_BH = 27831;
  
  public static final int VESTAS_PLATESKIRT_BH = 27832;
  
  public static final int STATIUSS_FULL_HELM_BH = 27833;
  
  public static final int STATIUSS_PLATEBODY_BH = 27834;
  
  public static final int STATIUSS_PLATELEGS_BH = 27835;
  
  public static final int MORRIGANS_COIF_BH = 27836;
  
  public static final int MORRIGANS_LEATHER_BODY_BH = 27837;
  
  public static final int MORRIGANS_LEATHER_CHAPS_BH = 27838;
  
  public static final int ZURIELS_HOOD_BH = 27839;
  
  public static final int ZURIELS_ROBE_TOP_BH = 27840;
  
  public static final int ZURIELS_ROBE_BOTTOM_BH = 27841;
  
  public static final int CORRUPTED_VESTAS_CHAINBODY_BH = 27842;
  
  public static final int CORRUPTED_VESTAS_PLATESKIRT_BH = 27843;
  
  public static final int CORRUPTED_STATIUSS_FULL_HELM_BH = 27844;
  
  public static final int CORRUPTED_STATIUSS_PLATEBODY_BH = 27845;
  
  public static final int CORRUPTED_STATIUSS_PLATELEGS_BH = 27846;
  
  public static final int CORRUPTED_MORRIGANS_COIF_BH = 27847;
  
  public static final int CORRUPTED_MORRIGANS_LEATHER_BODY_BH = 27848;
  
  public static final int CORRUPTED_MORRIGANS_LEATHER_CHAPS_BH = 27849;
  
  public static final int CORRUPTED_ZURIELS_HOOD_BH = 27850;
  
  public static final int CORRUPTED_ZURIELS_ROBE_TOP_BH = 27851;
  
  public static final int CORRUPTED_ZURIELS_ROBE_BOTTOM_BH = 27852;
  
  public static final int DARK_BOW_BH = 27853;
  
  public static final int BARRELCHEST_ANCHOR_BH = 27855;
  
  public static final int DRAGON_MACE_BH = 27857;
  
  public static final int DRAGON_LONGSWORD_BH = 27859;
  
  public static final int ABYSSAL_DAGGER_BH = 27861;
  
  public static final int ABYSSAL_DAGGER_BHP = 27863;
  
  public static final int ABYSSAL_DAGGER_BHP_27865 = 27865;
  
  public static final int ABYSSAL_DAGGER_BHP_27867 = 27867;
  
  public static final int VOIDWAKER_27869 = 27869;
  
  public static final int LIGHTBEARER_27870 = 27870;
  
  public static final int GIANT_BRONZE_DAGGER = 27871;
  
  public static final int EASTFLOOR_SPADE = 27873;
  
  public static final int NEST_HAT = 27875;
  
  public static final int NEST_HAT_27877 = 27877;
  
  public static final int SCALY_BLUE_DRAGONHIDE = 27897;
  
  public static final int VESTAS_SPEAR_BH = 27900;
  
  public static final int VESTAS_SPEAR_BHINACTIVE = 27902;
  
  public static final int VESTAS_LONGSWORD_BH = 27904;
  
  public static final int VESTAS_LONGSWORD_BHINACTIVE = 27906;
  
  public static final int STATIUSS_WARHAMMER_BH = 27908;
  
  public static final int STATIUSS_WARHAMMER_BHINACTIVE = 27910;
  
  public static final int MORRIGANS_THROWING_AXE_BH = 27912;
  
  public static final int MORRIGANS_THROWING_AXE_BHINACTIVE = 27914;
  
  public static final int MORRIGANS_JAVELIN_BH = 27916;
  
  public static final int MORRIGANS_JAVELIN_BHINACTIVE = 27918;
  
  public static final int ZURIELS_STAFF_BH = 27920;
  
  public static final int ZURIELS_STAFF_BHINACTIVE = 27922;
  
  public static final int VESTAS_CHAINBODY_BHINACTIVE = 27925;
  
  public static final int VESTAS_PLATESKIRT_BHINACTIVE = 27928;
  
  public static final int STATIUSS_FULL_HELM_BHINACTIVE = 27931;
  
  public static final int STATIUSS_PLATEBODY_BHINACTIVE = 27934;
  
  public static final int STATIUSS_PLATELEGS_BHINACTIVE = 27937;
  
  public static final int MORRIGANS_COIF_BHINACTIVE = 27940;
  
  public static final int MORRIGANS_LEATHER_BODY_BHINACTIVE = 27943;
  
  public static final int MORRIGANS_LEATHER_CHAPS_BHINACTIVE = 27946;
  
  public static final int ZURIELS_HOOD_BHINACTIVE = 27949;
  
  public static final int ZURIELS_ROBE_TOP_BHINACTIVE = 27952;
  
  public static final int ZURIELS_ROBE_BOTTOM_BHINACTIVE = 27955;
  
  public static final int ATTACK_XP = 27957;
  
  public static final int STRENGTH_XP = 27958;
  
  public static final int DEFENCE_XP = 27959;
  
  public static final int HITPOINTS_XP = 27960;
  
  public static final int MAGIC_XP = 27961;
  
  public static final int RANGED_XP = 27962;
  
  public static final int PRAYER_XP = 27963;
  
  public static final int CORRUPTED_VESTAS_CHAINBODY_BHINACTIVE = 27965;
  
  public static final int CORRUPTED_VESTAS_PLATESKIRT_BHINACTIVE = 27968;
  
  public static final int CORRUPTED_STATIUSS_FULL_HELM_BHINACTIVE = 27971;
  
  public static final int CORRUPTED_STATIUSS_PLATEBODY_BHINACTIVE = 27974;
  
  public static final int CORRUPTED_STATIUSS_PLATELEGS_BHINACTIVE = 27977;
  
  public static final int CORRUPTED_MORRIGANS_COIF_BHINACTIVE = 27980;
  
  public static final int CORRUPTED_MORRIGANS_LEATHER_BODY_BHINACTIVE = 27983;
  
  public static final int CORRUPTED_MORRIGANS_LEATHER_CHAPS_BHINACTIVE = 27986;
  
  public static final int CORRUPTED_ZURIELS_HOOD_BHINACTIVE = 27989;
  
  public static final int CORRUPTED_ZURIELS_ROBE_TOP_BHINACTIVE = 27992;
  
  public static final int CORRUPTED_ZURIELS_ROBE_BOTTOM_BHINACTIVE = 27995;
  
  public static final int ESOTERIC_EMBLEM_TIER_1 = 27997;
  
  public static final int ESOTERIC_EMBLEM_TIER_2 = 27999;
  
  public static final int ESOTERIC_EMBLEM_TIER_3 = 28001;
  
  public static final int ESOTERIC_EMBLEM_TIER_4 = 28003;
  
  public static final int ESOTERIC_EMBLEM_TIER_5 = 28005;
  
  public static final int ESOTERIC_EMBLEM_TIER_6 = 28007;
  
  public static final int ESOTERIC_EMBLEM_TIER_7 = 28009;
  
  public static final int ESOTERIC_EMBLEM_TIER_8 = 28011;
  
  public static final int ESOTERIC_EMBLEM_TIER_9 = 28013;
  
  public static final int ESOTERIC_EMBLEM_TIER_10 = 28015;
  
  public static final int BOUNTY_HUNTER_ORNAMENT_KIT = 28017;
  
  public static final int DRAGON_DAGGER_CR = 28019;
  
  public static final int DRAGON_DAGGER_PCR = 28021;
  
  public static final int DRAGON_DAGGER_PCR_28023 = 28023;
  
  public static final int DRAGON_DAGGER_PCR_28025 = 28025;
  
  public static final int DRAGON_MACE_CR = 28027;
  
  public static final int DRAGON_SWORD_CR = 28029;
  
  public static final int DRAGON_SCIMITAR_CR = 28031;
  
  public static final int DRAGON_LONGSWORD_CR = 28033;
  
  public static final int DRAGON_WARHAMMER_CR = 28035;
  
  public static final int DRAGON_BATTLEAXE_CR = 28037;
  
  public static final int DRAGON_CLAWS_CR = 28039;
  
  public static final int DRAGON_SPEAR_CR = 28041;
  
  public static final int DRAGON_SPEAR_PCR = 28043;
  
  public static final int DRAGON_SPEAR_PCR_28045 = 28045;
  
  public static final int DRAGON_SPEAR_PCR_28047 = 28047;
  
  public static final int DRAGON_HALBERD_CR = 28049;
  
  public static final int DRAGON_2H_SWORD_CR = 28051;
  
  public static final int DRAGON_CROSSBOW_CR = 28053;
  
  public static final int DRAGON_BOOTS_CR = 28055;
  
  public static final int DRAGON_MED_HELM_CR = 28057;
  
  public static final int DRAGON_SQ_SHIELD_CR = 28059;
  
  public static final int DRAGON_PLATELEGS_CR = 28061;
  
  public static final int DRAGON_PLATESKIRT_CR = 28063;
  
  public static final int DRAGON_CHAINBODY_CR = 28065;
  
  public static final int FIGHTER_TORSO_OR = 28067;
  
  public static final int FIGHTER_TORSO_LOR = 28069;
  
  public static final int HELM_OF_NEITIZNOT_OR = 28070;
  
  public static final int DARK_BOW_IMBUE_SCROLL = 28072;
  
  public static final int BARRELCHEST_ANCHOR_IMBUE_SCROLL = 28074;
  
  public static final int DRAGON_MACE_IMBUE_SCROLL = 28076;
  
  public static final int DRAGON_LONGSWORD_IMBUE_SCROLL = 28078;
  
  public static final int ABYSSAL_DAGGER_IMBUE_SCROLL = 28080;
  
  public static final int BOUNTY_CRATE_TIER_1 = 28082;
  
  public static final int BOUNTY_CRATE_TIER_2 = 28084;
  
  public static final int BOUNTY_CRATE_TIER_3 = 28086;
  
  public static final int BOUNTY_CRATE_TIER_4 = 28088;
  
  public static final int BOUNTY_CRATE_TIER_5 = 28090;
  
  public static final int BOUNTY_CRATE_TIER_6 = 28092;
  
  public static final int BOUNTY_CRATE_TIER_7 = 28094;
  
  public static final int BOUNTY_CRATE_TIER_8 = 28096;
  
  public static final int BOUNTY_CRATE_TIER_9 = 28098;
  
  public static final int COLOURFUL_SCARF = 28108;
  
  public static final int COLOURFUL_SCARF_28109 = 28109;
  
  public static final int COLOURFUL_SCARF_28110 = 28110;
  
  public static final int COLOURFUL_SCARF_28111 = 28111;
  
  public static final int COLOURFUL_SCARF_28112 = 28112;
  
  public static final int COLOURFUL_SCARF_28113 = 28113;
  
  public static final int COLOURFUL_SCARF_28114 = 28114;
  
  public static final int COLOURFUL_SCARF_28115 = 28115;
  
  public static final int RAINBOW_JUMPER = 28116;
  
  public static final int COLOURFUL_JUMPER = 28118;
  
  public static final int COLOURFUL_JUMPER_28119 = 28119;
  
  public static final int COLOURFUL_JUMPER_28120 = 28120;
  
  public static final int COLOURFUL_JUMPER_28121 = 28121;
  
  public static final int COLOURFUL_JUMPER_28122 = 28122;
  
  public static final int COLOURFUL_JUMPER_28123 = 28123;
  
  public static final int COLOURFUL_JUMPER_28124 = 28124;
  
  public static final int COLOURFUL_JUMPER_28125 = 28125;
  
  public static final int POETS_JACKET = 28126;
  
  public static final int LOVE_CROSSBOW = 28128;
  
  public static final int STRANGE_ICON = 28130;
  
  public static final int DUSTY_LAMP = 28132;
  
  public static final int CRYPT_MAP = 28133;
  
  public static final int ANIMAINFUSED_BARK = 28134;
  
  public static final int FORESTRY_KIT = 28136;
  
  public static final int FUNKY_SHAPED_LOG = 28138;
  
  public static final int LOG_BASKET = 28140;
  
  public static final int OPEN_LOG_BASKET = 28142;
  
  public static final int FORESTRY_BASKET = 28143;
  
  public static final int OPEN_FORESTRY_BASKET = 28145;
  
  public static final int LOG_BRACE = 28146;
  
  public static final int STURDY_HARNESS = 28149;
  
  public static final int NATURE_OFFERINGS = 28152;
  
  public static final int RITUAL_MULCH = 28154;
  
  public static final int FORESTERS_RATION = 28157;
  
  public static final int SECATEURS_BLADE = 28159;
  
  public static final int SECATEURS_ATTACHMENT = 28161;
  
  public static final int CLOTHES_POUCH = 28163;
  
  public static final int CLOTHES_POUCH_BLUEPRINT = 28166;
  
  public static final int FORESTRY_TOP = 28169;
  
  public static final int FORESTRY_LEGS = 28171;
  
  public static final int FORESTRY_HAT = 28173;
  
  public static final int FORESTRY_BOOTS = 28175;
  
  public static final int FELLING_AXE_HANDLE = 28177;
  
  public static final int LEPRECHAUN_CHARM = 28179;
  
  public static final int CLOVER_INSIGNIA = 28181;
  
  public static final int MULCH = 28183;
  
  public static final int BEE_ON_A_STICK = 28184;
  
  public static final int POWDERED_POLLEN = 28190;
  
  public static final int STRANGE_POLLEN = 28192;
  
  public static final int UNFIRED_CUP = 28193;
  
  public static final int BRONZE_FELLING_AXE = 28196;
  
  public static final int IRON_FELLING_AXE = 28199;
  
  public static final int STEEL_FELLING_AXE = 28202;
  
  public static final int BLACK_FELLING_AXE = 28205;
  
  public static final int MITHRIL_FELLING_AXE = 28208;
  
  public static final int ADAMANT_FELLING_AXE = 28211;
  
  public static final int RUNE_FELLING_AXE = 28214;
  
  public static final int DRAGON_FELLING_AXE = 28217;
  
  public static final int CRYSTAL_FELLING_AXE = 28220;
  
  public static final int CRYSTAL_FELLING_AXE_INACTIVE = 28223;
  
  public static final int _3RD_AGE_FELLING_AXE = 28226;
  
  public static final int BEAVER_28229 = 28229;
  
  public static final int BEAVER_28230 = 28230;
  
  public static final int BEAVER_28231 = 28231;
  
  public static final int BEAVER_28232 = 28232;
  
  public static final int BEAVER_28233 = 28233;
  
  public static final int BEAVER_28234 = 28234;
  
  public static final int BEAVER_28235 = 28235;
  
  public static final int BEAVER_28236 = 28236;
  
  public static final int BEAVER_28237 = 28237;
  
  public static final int BLOOD_ANCIENT_SCEPTRE_BROKEN = 28238;
  
  public static final int SMOKE_ANCIENT_SCEPTRE_BROKEN = 28240;
  
  public static final int ICE_ANCIENT_SCEPTRE_BROKEN = 28242;
  
  public static final int SHADOW_ANCIENT_SCEPTRE_BROKEN = 28244;
  
  public static final int WISP = 28246;
  
  public static final int BUTCH = 28248;
  
  public static final int BARON = 28250;
  
  public static final int LILVIATHAN = 28252;
  
  public static final int SANGUINE_TORVA_FULL_HELM = 28254;
  
  public static final int SANGUINE_TORVA_PLATEBODY = 28256;
  
  public static final int SANGUINE_TORVA_PLATELEGS = 28258;
  
  public static final int BLOOD_ANCIENT_SCEPTRE_28260 = 28260;
  
  public static final int ICE_ANCIENT_SCEPTRE_28262 = 28262;
  
  public static final int SMOKE_ANCIENT_SCEPTRE_28264 = 28264;
  
  public static final int SHADOW_ANCIENT_SCEPTRE_28266 = 28266;
  
  public static final int BLOOD_QUARTZ = 28268;
  
  public static final int ICE_QUARTZ = 28270;
  
  public static final int SHADOW_QUARTZ = 28272;
  
  public static final int SMOKE_QUARTZ = 28274;
  
  public static final int CHROMIUM_INGOT = 28276;
  
  public static final int BELLATOR_VESTIGE = 28279;
  
  public static final int MAGUS_VESTIGE = 28281;
  
  public static final int VENATOR_VESTIGE = 28283;
  
  public static final int ULTOR_VESTIGE = 28285;
  
  public static final int ULTOR_ICON = 28287;
  
  public static final int VENATOR_ICON = 28289;
  
  public static final int MAGUS_ICON = 28291;
  
  public static final int BELLATOR_ICON = 28293;
  
  public static final int BERSERKER_ICON = 28295;
  
  public static final int ARCHER_ICON = 28298;
  
  public static final int WARRIOR_ICON = 28301;
  
  public static final int SEERS_ICON = 28304;
  
  public static final int ULTOR_RING_28307 = 28307;
  
  public static final int VENATOR_RING_28310 = 28310;
  
  public static final int MAGUS_RING_28313 = 28313;
  
  public static final int BELLATOR_RING_28316 = 28316;
  
  public static final int EXECUTIONERS_AXE_HEAD = 28319;
  
  public static final int EYE_OF_THE_DUKE = 28321;
  
  public static final int SIRENS_STAFF = 28323;
  
  public static final int LEVIATHANS_LURE = 28325;
  
  public static final int RING_OF_SHADOWS = 28327;
  
  public static final int RING_OF_SHADOWS_UNCHARGED = 28329;
  
  public static final int STRANGLED_TABLET = 28330;
  
  public static final int SIRENIC_TABLET = 28331;
  
  public static final int SCARRED_TABLET = 28332;
  
  public static final int FROZEN_TABLET = 28333;
  
  public static final int AWAKENERS_ORB = 28334;
  
  public static final int ANCIENT_BLOOD_ORNAMENT_KIT = 28336;
  
  public static final int SOULREAPER_AXE_28338 = 28338;
  
  public static final int MUSCA_MUSHROOM = 28341;
  
  public static final int MUSCA_POWDER = 28342;
  
  public static final int HOLOS_MUSHROOM = 28343;
  
  public static final int HOLOS_POWDER = 28344;
  
  public static final int ARDER_MUSHROOM = 28345;
  
  public static final int ARDER_POWDER = 28346;
  
  public static final int RESPER_MUSHROOM = 28347;
  
  public static final int RESPER_POWDER = 28348;
  
  public static final int SALAX_SALT = 28349;
  
  public static final int MUSCAHOLOS_POISON = 28350;
  
  public static final int ARDERMUSCA_POISON = 28351;
  
  public static final int MUSCARESPER_POISON = 28352;
  
  public static final int HOLOSARDER_POISON = 28353;
  
  public static final int RESPERHOLOS_POISON = 28354;
  
  public static final int ARDERRESPER_POISON = 28355;
  
  public static final int BLACKSTONE_FRAGMENT = 28356;
  
  public static final int BLACKSTONE_FRAGMENT_28357 = 28357;
  
  public static final int STRANGE_ICON_28360 = 28360;
  
  public static final int ICON_SEGMENT = 28361;
  
  public static final int ICON_SEGMENT_28362 = 28362;
  
  public static final int VERY_LONG_ROPE = 28363;
  
  public static final int BASIC_SHADOW_TORCH = 28364;
  
  public static final int SUPERIOR_SHADOW_TORCH = 28365;
  
  public static final int PERFECTED_SHADOW_TORCH = 28366;
  
  public static final int SHADOW_BLOCKER = 28367;
  
  public static final int REVITALISING_IDOL = 28368;
  
  public static final int ANIMA_PORTAL = 28369;
  
  public static final int SHADOW_KEY = 28370;
  
  public static final int SHADOW_KEY_28371 = 28371;
  
  public static final int SHADOW_KEY_28372 = 28372;
  
  public static final int SHADOW_KEY_28373 = 28373;
  
  public static final int SHADOW_KEY_28374 = 28374;
  
  public static final int ANIMA_PORTAL_SCHEMATIC = 28375;
  
  public static final int REVITALISING_IDOL_SCHEMATIC = 28376;
  
  public static final int SHADOW_BLOCKER_SCHEMATIC = 28377;
  
  public static final int BASIC_SHADOW_TORCH_SCHEMATIC = 28378;
  
  public static final int SUPERIOR_SHADOW_TORCH_SCHEMATIC = 28379;
  
  public static final int PERFECTED_SHADOW_TORCH_SCHEMATIC = 28380;
  
  public static final int PERFECTED_SHADOW_TORCH_SCHEMATIC_28381 = 28381;
  
  public static final int POTION_NOTE = 28382;
  
  public static final int STRANGE_POTION_28383 = 28383;
  
  public static final int KORBAL_HERB = 28384;
  
  public static final int ARGIAN_BERRIES = 28385;
  
  public static final int UNFINISHED_SERUM = 28386;
  
  public static final int UNFINISHED_SERUM_28387 = 28387;
  
  public static final int STRANGLER_SERUM = 28388;
  
  public static final int TEMPLE_KEY_28389 = 28389;
  
  public static final int BARRICADE_28390 = 28390;
  
  public static final int SATCHEL_28392 = 28392;
  
  public static final int DETONATOR = 28393;
  
  public static final int TATTY_PAGE = 28394;
  
  public static final int TATTY_PAGE_28395 = 28395;
  
  public static final int TATTY_PAGE_28396 = 28396;
  
  public static final int TATTY_PAGE_28397 = 28397;
  
  public static final int TATTY_PAGE_28398 = 28398;
  
  public static final int TATTY_PAGE_28399 = 28399;
  
  public static final int TATTY_PAGE_28400 = 28400;
  
  public static final int MUCKY_NOTE = 28401;
  
  public static final int UNCHARGED_CELL_28402 = 28402;
  
  public static final int CHARGED_CELL = 28403;
  
  public static final int VARDORVIS_MEDALLION = 28404;
  
  public static final int PERSERIYAS_MEDALLION = 28405;
  
  public static final int SUCELLUS_MEDALLION = 28406;
  
  public static final int WHISPERERS_MEDALLION = 28407;
  
  public static final int HAIR_CLIP_28408 = 28408;
  
  public static final int ANCIENT_LAMP = 28409;
  
  public static final int DR_BANIKAN = 28410;
  
  public static final int PRISONERS_LETTER = 28412;
  
  public static final int KNIFE_28413 = 28413;
  
  public static final int CHISEL_28414 = 28414;
  
  public static final int LOCKPICK_28415 = 28415;
  
  public static final int SAPPHIRE_KEY_28416 = 28416;
  
  public static final int EMERALD_KEY_28417 = 28417;
  
  public static final int RUBY_KEY_28418 = 28418;
  
  public static final int DIAMOND_KEY = 28419;
  
  public static final int DRAGONSTONE_KEY = 28420;
  
  public static final int ONYX_KEY = 28421;
  
  public static final int RATIONS = 28422;
  
  public static final int REQUISITION_NOTE = 28423;
  
  public static final int GRID_NOTE = 28424;
  
  public static final int CODE_CONVERTER = 28425;
  
  public static final int MAGIC_LANTERN = 28426;
  
  public static final int STRANGE_SLIDER = 28427;
  
  public static final int LIBRARY_NOTE = 28428;
  
  public static final int WARNING_LETTER = 28429;
  
  public static final int ODD_KEY = 28430;
  
  public static final int ORDERS_NOTE = 28431;
  
  public static final int REFUGEES_NOTE = 28432;
  
  public static final int REQUEST_NOTE = 28433;
  
  public static final int PRAYER_NOTE = 28434;
  
  public static final int THANK_YOU_NOTE = 28435;
  
  public static final int PROTEST_NOTE = 28436;
  
  public static final int EVACUATION_NOTE = 28437;
  
  public static final int OLD_TABLET = 28438;
  
  public static final int DAMP_TABLET = 28439;
  
  public static final int DAMP_TABLET_28440 = 28440;
  
  public static final int SLIMY_KEY = 28441;
  
  public static final int GUNPOWDER_28442 = 28442;
  
  public static final int SCARRED_SCRAPS = 28443;
  
  public static final int WITHERED_NOTE = 28444;
  
  public static final int EARTH_NERVE = 28445;
  
  public static final int WATER_NERVE = 28446;
  
  public static final int FIRE_NERVE = 28447;
  
  public static final int AIR_NERVE = 28448;
  
  public static final int MIND_NERVE = 28449;
  
  public static final int SOUL_NERVE = 28450;
  
  public static final int NATURE_NERVE = 28451;
  
  public static final int SMOKE_NERVE = 28452;
  
  public static final int BLOOD_NERVE = 28453;
  
  public static final int LAW_NERVE = 28454;
  
  public static final int COSMIC_NERVE = 28455;
  
  public static final int ASTRAL_NERVE = 28456;
  
  public static final int WRATH_NERVE = 28457;
  
  public static final int DUST_NERVE = 28458;
  
  public static final int STEAM_NERVE = 28459;
  
  public static final int LAVA_NERVE = 28460;
  
  public static final int ABYSSAL_OBSERVATIONS = 28461;
  
  public static final int CRIMSON_FIBRE = 28462;
  
  public static final int RADIANT_FIBRE = 28463;
  
  public static final int ILLUMINATING_LURE = 28464;
  
  public static final int SLIMY_TABLET = 28465;
  
  public static final int SLIMY_TABLET_28466 = 28466;
  
  public static final int SLIMY_TABLET_28467 = 28467;
  
  public static final int GOOEY_NOTE = 28468;
  
  public static final int GOOEY_NOTE_28469 = 28469;
  
  public static final int GOOEY_NOTE_28470 = 28470;
  
  public static final int STINK_BOMB = 28471;
  
  public static final int BLOOD_ANCIENT_SCEPTRE_L = 28473;
  
  public static final int ICE_ANCIENT_SCEPTRE_L = 28474;
  
  public static final int SMOKE_ANCIENT_SCEPTRE_L = 28475;
  
  public static final int SHADOW_ANCIENT_SCEPTRE_L = 28476;
  
  public static final int SIGIL_OF_SUSTENANCE = 28477;
  
  public static final int SIGIL_OF_SUSTENANCE_28478 = 28478;
  
  public static final int SIGIL_OF_HOARDING = 28480;
  
  public static final int SIGIL_OF_HOARDING_28481 = 28481;
  
  public static final int SIGIL_OF_THE_ALCHEMANIAC = 28483;
  
  public static final int SIGIL_OF_THE_ALCHEMANIAC_28484 = 28484;
  
  public static final int SIGIL_OF_THE_HUNTER = 28486;
  
  public static final int SIGIL_OF_THE_HUNTER_28487 = 28487;
  
  public static final int SIGIL_OF_RESISTANCE = 28489;
  
  public static final int SIGIL_OF_RESISTANCE_28490 = 28490;
  
  public static final int SIGIL_OF_AGILE_FORTUNE = 28492;
  
  public static final int SIGIL_OF_AGILE_FORTUNE_28493 = 28493;
  
  public static final int SIGIL_OF_THE_FOOD_MASTER = 28495;
  
  public static final int SIGIL_OF_THE_FOOD_MASTER_28496 = 28496;
  
  public static final int SIGIL_OF_THE_WELLFED = 28498;
  
  public static final int SIGIL_OF_THE_WELLFED_28499 = 28499;
  
  public static final int SIGIL_OF_THE_INFERNAL_CHEF = 28501;
  
  public static final int SIGIL_OF_THE_INFERNAL_CHEF_28502 = 28502;
  
  public static final int SIGIL_OF_THE_INFERNAL_SMITH = 28504;
  
  public static final int SIGIL_OF_THE_INFERNAL_SMITH_28505 = 28505;
  
  public static final int SIGIL_OF_THE_LIGHTBEARER = 28507;
  
  public static final int SIGIL_OF_THE_LIGHTBEARER_28508 = 28508;
  
  public static final int SIGIL_OF_THE_BLOODHOUND = 28510;
  
  public static final int SIGIL_OF_THE_BLOODHOUND_28511 = 28511;
  
  public static final int SIGIL_OF_PRECISION = 28513;
  
  public static final int SIGIL_OF_PRECISION_28514 = 28514;
  
  public static final int SIGIL_OF_THE_AUGMENTED_THRALL = 28516;
  
  public static final int SIGIL_OF_THE_AUGMENTED_THRALL_28517 = 28517;
  
  public static final int SIGIL_OF_FAITH = 28519;
  
  public static final int SIGIL_OF_FAITH_28520 = 28520;
  
  public static final int SIGIL_OF_TITANIUM = 28522;
  
  public static final int SIGIL_OF_TITANIUM_28523 = 28523;
  
  public static final int SIGIL_OF_THE_NINJA = 28525;
  
  public static final int SIGIL_OF_THE_NINJA_28526 = 28526;
  
  public static final int SIGIL_OF_WOODCRAFT = 28528;
  
  public static final int SIGIL_OF_WOODCRAFT_28529 = 28529;
  
  public static final int CORRUPTED_VOIDWAKER = 28531;
  
  public static final int CORRUPTED_DRAGON_CLAWS = 28534;
  
  public static final int CORRUPTED_ARMADYL_GODSWORD = 28537;
  
  public static final int CORRUPTED_TWISTED_BOW = 28540;
  
  public static final int CORRUPTED_SCYTHE_OF_VITUR = 28543;
  
  public static final int CORRUPTED_SCYTHE_OF_VITUR_UNCHARGED = 28545;
  
  public static final int CORRUPTED_TUMEKENS_SHADOW = 28547;
  
  public static final int CORRUPTED_TUMEKENS_SHADOW_UNCHARGED = 28549;
  
  public static final int QUEST_LAMP = 28551;
  
  public static final int QUEST_LAMP_28552 = 28552;
  
  public static final int QUEST_LAMP_28553 = 28553;
  
  public static final int QUEST_LAMP_28554 = 28554;
  
  public static final int STARTER_BOW_28555 = 28555;
  
  public static final int STARTER_STAFF_28557 = 28557;
  
  public static final int STARTER_SWORD_28559 = 28559;
  
  public static final int TRINKET_OF_VENGEANCE = 28561;
  
  public static final int TRINKET_OF_FAIRIES = 28564;
  
  public static final int TRINKET_OF_ADVANCED_WEAPONRY = 28567;
  
  public static final int TRINKET_OF_UNDEAD = 28570;
  
  public static final int CHEST_KEY_28573 = 28573;
  
  public static final int STRONGROOM_KEY = 28574;
  
  public static final int CRYSTAL_CHIME_SEED = 28575;
  
  public static final int CRYSTAL_CHIME = 28577;
  
  public static final int YEWNOCKS_NOTES = 28579;
  
  public static final int WARPED_SCEPTRE_UNCHARGED = 28583;
  
  public static final int WARPED_SCEPTRE = 28585;
  
  public static final int MAGIC_LAMP_STRENGTH = 28587;
  
  public static final int MAGIC_LAMP_SLAYER = 28588;
  
  public static final int MAGIC_LAMP_THIEVING = 28589;
  
  public static final int MAGIC_LAMP_MAGIC = 28590;
  
  public static final int TAINTED_ESSENCE_CHUNK = 28591;
  
  public static final int WARPED_EXTRACT = 28593;
  
  public static final int TWISTED_EXTRACT = 28595;
  
  public static final int MANGLED_EXTRACT = 28597;
  
  public static final int SCARRED_EXTRACT = 28599;
  
  public static final int COBWEB_CAPE = 28601;
  
  public static final int SPIDER_HAT = 28603;
  
  public static final int SPIDER_HAT_28605 = 28605;
  
  public static final int SPIDER_HAT_28607 = 28607;
  
  public static final int SPIDER_HAT_28609 = 28609;
  
  public static final int SPIDER_HAT_28611 = 28611;
  
  public static final int CAPE_POUCH = 28613;
  
  public static final int PHEASANT_CAPE = 28616;
  
  public static final int PHEASANT_BOOTS = 28618;
  
  public static final int PHEASANT_HAT = 28620;
  
  public static final int PHEASANT_LEGS = 28622;
  
  public static final int PHEASANT_TAIL_FEATHERS = 28624;
  
  public static final int FOX_WHISTLE = 28626;
  
  public static final int SAWMILL_VOUCHER = 28628;
  
  public static final int TWITCHERS_GLOVES = 28630;
  
  public static final int SMOKER_FUEL = 28644;
  
  public static final int SMOKER_CANISTER = 28646;
  
  public static final int MULCH_28648 = 28648;
  
  public static final int MULCH_28649 = 28649;
  
  public static final int PACKED_MULCH = 28650;
  
  public static final int CRYSTAL_CHARM = 28651;
  
  public static final int PETAL_CIRCLET = 28653;
  
  public static final int PETAL_GARLAND = 28655;
  
  public static final int PADDED_SPOON = 28657;
  
  public static final int EGG_CUSHION = 28659;
  
  public static final int PHEASANT_EGG = 28661;
  
  public static final int GOLDEN_PHEASANT_EGG = 28663;
  
  public static final int TRAP_DISARMER = 28665;
  
  public static final int TRAP_DISARMER_BLUEPRINT = 28667;
  
  public static final int PHEASANT = 28669;
  
  public static final int FOX_28670 = 28670;
  
  public static final int WEB_CLOAK = 28671;
  
  public static final int FANCIER_BOOTS = 28672;
  
  public static final int STURDY_BEEHIVE_PARTS = 28674;
  
  public static final int BEEHIVE_STYLE_1 = 28676;
  
  public static final int BEEHIVE_STYLE_2 = 28677;
  
  public static final int CABBAGE_28678 = 28678;
  
  public static final int CABBAGE_28680 = 28680;
  
  public static final int DINHS_BLAZING_BULWARK = 28682;
  
  public static final int TRAILBLAZER_RELOADED_BULWARK_ORNAMENT_KIT = 28684;
  
  public static final int BLAZING_BLOWPIPE_EMPTY = 28687;
  
  public static final int BLAZING_BLOWPIPE = 28688;
  
  public static final int TRAILBLAZER_RELOADED_BLOWPIPE_ORNAMENT_KIT = 28690;
  
  public static final int TRAILBLAZER_RELOADED_ALCHEMY_SCROLL = 28693;
  
  public static final int TRAILBLAZER_RELOADED_VENGEANCE_SCROLL = 28696;
  
  public static final int TRAILBLAZER_RELOADED_DEATH_SCROLL = 28699;
  
  public static final int TRAILBLAZER_RELOADED_BANNER = 28702;
  
  public static final int TRAILBLAZER_RELOADED_HOME_TELEPORT_SCROLL = 28705;
  
  public static final int TRAILBLAZER_RELOADED_REJUVENATION_POOL_SCROLL = 28708;
  
  public static final int TRAILBLAZER_RELOADED_REJUVENATION_POOL = 28711;
  
  public static final int TRAILBLAZER_RELOADED_HEADBAND_T1 = 28712;
  
  public static final int TRAILBLAZER_RELOADED_TOP_T1 = 28715;
  
  public static final int TRAILBLAZER_RELOADED_TROUSERS_T1 = 28718;
  
  public static final int TRAILBLAZER_RELOADED_BOOTS_T1 = 28721;
  
  public static final int TRAILBLAZER_RELOADED_HEADBAND_T2 = 28724;
  
  public static final int TRAILBLAZER_RELOADED_TOP_T2 = 28727;
  
  public static final int TRAILBLAZER_RELOADED_TROUSERS_T2 = 28730;
  
  public static final int TRAILBLAZER_RELOADED_BOOTS_T2 = 28733;
  
  public static final int TRAILBLAZER_RELOADED_HEADBAND_T3 = 28736;
  
  public static final int TRAILBLAZER_RELOADED_TOP_T3 = 28739;
  
  public static final int TRAILBLAZER_RELOADED_TROUSERS_T3 = 28742;
  
  public static final int TRAILBLAZER_RELOADED_BOOTS_T3 = 28745;
  
  public static final int TRAILBLAZER_RELOADED_TORCH = 28748;
  
  public static final int TRAILBLAZER_RELOADED_DRAGON_TROPHY = 28751;
  
  public static final int TRAILBLAZER_RELOADED_RUNE_TROPHY = 28753;
  
  public static final int TRAILBLAZER_RELOADED_ADAMANT_TROPHY = 28755;
  
  public static final int TRAILBLAZER_RELOADED_MITHRIL_TROPHY = 28757;
  
  public static final int TRAILBLAZER_RELOADED_STEEL_TROPHY = 28759;
  
  public static final int TRAILBLAZER_RELOADED_IRON_TROPHY = 28761;
  
  public static final int TRAILBLAZER_RELOADED_BRONZE_TROPHY = 28763;
  
  public static final int GLOBETROTTER_PENDANT = 28765;
  
  public static final int BANKERS_NOTE = 28767;
  
  public static final int GUARDIAN_HORN = 28769;
  
  public static final int SAGES_GREAVES = 28771;
  
  public static final int SAGES_AXE = 28773;
  
  public static final int RUINOUS_POWERS = 28775;
  
  public static final int TRAILBLAZER_RELOADED_RELIC_HUNTER_T1_ARMOUR_SET = 28777;
  
  public static final int TRAILBLAZER_RELOADED_RELIC_HUNTER_T2_ARMOUR_SET = 28780;
  
  public static final int TRAILBLAZER_RELOADED_RELIC_HUNTER_T3_ARMOUR_SET = 28783;
  
  public static final int ICY_JUMPER = 28786;
  
  public static final int SNOWGLOBE_HELMET = 28788;
  
  public static final int KOUREND_CASTLE_TELEPORT = 28790;
  
  public static final int BONE_MACE = 28792;
  
  public static final int BONE_SHORTBOW = 28794;
  
  public static final int BONE_STAFF = 28796;
  
  public static final int SCURRIUS_SPINE = 28798;
  
  public static final int ANTIQUE_LAMP_28800 = 28800;
  
  public static final int SCURRY = 28801;
  
  public static final int GRUBBY_KEY_28803 = 28803;
  
  public static final int BOTTLE = 28804;
  
  public static final int BOTTLE_OF_MIST = 28805;
  
  public static final int IMBUED_BARRONITE = 28806;
  
  public static final int SHIELD_OF_ARRAV = 28807;
  
  public static final int LIST_OF_ELDERS = 28808;
  
  public static final int ELIAS_WHITE = 28809;
  
  public static final int ZOMBIE_AXE = 28810;
  
  public static final int BROKEN_ZOMBIE_AXE = 28813;
  
  public static final int STONE_TABLET_28816 = 28816;
  
  public static final int GRANITE_TABLET = 28817;
  
  public static final int SLATE_TABLET = 28818;
  
  public static final int SHALE_TABLET = 28819;
  
  public static final int ANTIQUE_LAMP_28820 = 28820;
  
  public static final int WEALTHY_CITIZEN = 28821;
  
  public static final int COIN_POUCH_28822 = 28822;
  
  public static final int LESSER_NAGUA = 28823;
  
  public static final int CIVITAS_ILLA_FORTIS_TELEPORT = 28824;
  
  public static final int DIZANAS_QUIVER_BROKEN = 28826;
  
  public static final int BLESSED_DIZANAS_QUIVER_BROKEN = 28828;
  
  public static final int DIZANAS_MAX_CAPE_BROKEN = 28830;
  
  public static final int IMMATURE_TECU_SALAMANDER = 28831;
  
  public static final int TECU_SALAMANDER = 28834;
  
  public static final int IRIT_TAR = 28837;
  
  public static final int WOOD_CAMO_TOP_28839 = 28839;
  
  public static final int WOOD_CAMO_LEGS_28842 = 28842;
  
  public static final int JUNGLE_CAMO_TOP_28845 = 28845;
  
  public static final int JUNGLE_CAMO_LEGS_28848 = 28848;
  
  public static final int DESERT_CAMO_TOP_28851 = 28851;
  
  public static final int DESERT_CAMO_LEGS_28854 = 28854;
  
  public static final int POLAR_CAMO_TOP_28857 = 28857;
  
  public static final int POLAR_CAMO_LEGS_28860 = 28860;
  
  public static final int SUNLIGHT_MOTH = 28863;
  
  public static final int MOONLIGHT_MOTH = 28864;
  
  public static final int PYRE_FOX = 28865;
  
  public static final int EMBERTAILED_JERBOA = 28866;
  
  public static final int SUNLIGHT_ANTELOPE = 28867;
  
  public static final int MOONLIGHT_ANTELOPE = 28868;
  
  public static final int HUNTERS_SUNLIGHT_CROSSBOW = 28869;
  
  public static final int SUNLIGHT_ANTLER_BOLTS = 28872;
  
  public static final int MOONLIGHT_ANTLER_BOLTS = 28878;
  
  public static final int SUNLIGHT_ANTLER = 28884;
  
  public static final int MOONLIGHT_ANTLER = 28887;
  
  public static final int SUNLIGHT_MOTH_28890 = 28890;
  
  public static final int MOONLIGHT_MOTH_28893 = 28893;
  
  public static final int RUM_28896 = 28896;
  
  public static final int WYRMLING_BONES = 28899;
  
  public static final int DIZANAS_MAX_CAPE = 28902;
  
  public static final int DIZANAS_MAX_HOOD = 28904;
  
  public static final int DIZANAS_MAX_CAPE_L = 28906;
  
  public static final int CLUE_SCROLL_MEDIUM_28907 = 28907;
  
  public static final int CLUE_SCROLL_MEDIUM_28908 = 28908;
  
  public static final int CLUE_SCROLL_MEDIUM_28909 = 28909;
  
  public static final int CLUE_SCROLL_ELITE_28910 = 28910;
  
  public static final int CLUE_SCROLL_ELITE_28911 = 28911;
  
  public static final int CLUE_SCROLL_ELITE_28912 = 28912;
  
  public static final int CLUE_SCROLL_EASY_28913 = 28913;
  
  public static final int CLUE_SCROLL_EASY_28914 = 28914;
  
  public static final int CLUE_SCROLL_HARD_28915 = 28915;
  
  public static final int CLUE_SCROLL_HARD_28916 = 28916;
  
  public static final int PUZZLE_BOX_HARD_28917 = 28917;
  
  public static final int CLUE_SCROLL_HARD_28918 = 28918;
  
  public static final int TONALZTICS_OF_RALOS_UNCHARGED = 28919;
  
  public static final int TONALZTICS_OF_RALOS = 28922;
  
  public static final int SUNFIRE_SPLINTERS = 28924;
  
  public static final int SUNFIRE_RUNE = 28929;
  
  public static final int SEARING_PAGE = 28931;
  
  public static final int SUNFIRE_FANATIC_HELM = 28933;
  
  public static final int SUNFIRE_FANATIC_CUIRASS = 28936;
  
  public static final int SUNFIRE_FANATIC_CHAUSSES = 28939;
  
  public static final int ECHO_CRYSTAL = 28942;
  
  public static final int ECHO_BOOTS = 28945;
  
  public static final int DIZANAS_QUIVER_UNCHARGED = 28947;
  
  public static final int DIZANAS_QUIVER_UNCHARGED_L = 28949;
  
  public static final int DIZANAS_QUIVER = 28951;
  
  public static final int DIZANAS_QUIVER_L = 28953;
  
  public static final int BLESSED_DIZANAS_QUIVER = 28955;
  
  public static final int BLESSED_DIZANAS_QUIVER_L = 28957;
  
  public static final int SCRAWLED_POEM = 28958;
  
  public static final int SMOL_HEREDIT = 28960;
  
  public static final int QUETZIN = 28962;
  
  public static final int ENCHANTED_WATER_TALISMAN = 28964;
  
  public static final int ENCHANTED_EARTH_TALISMAN = 28965;
  
  public static final int INFUSED_WATER_TALISMAN = 28966;
  
  public static final int INFUSED_EARTH_TALISMAN = 28967;
  
  public static final int BUILDING_SUPPLIES = 28968;
  
  public static final int MOSS_LIZARD_TAIL = 28969;
  
  public static final int BREAM_SCALES = 28970;
  
  public static final int VARLAMORE_INVITATION = 28972;
  
  public static final int VARLAMORE_CREST = 28973;
  
  public static final int INCRIMINATING_LETTER = 28974;
  
  public static final int QUETZAL_FEED = 28975;
  
  public static final int STOLEN_AMULET = 28976;
  
  public static final int KNIGHT_OF_VARLAMORE = 28977;
  
  public static final int SMOOTH_LEAF = 28978;
  
  public static final int STICKY_LEAF = 28979;
  
  public static final int MAKESHIFT_POULTICE = 28980;
  
  public static final int FUR_SAMPLE = 28981;
  
  public static final int TRIMMED_FUR = 28982;
  
  public static final int FOXS_REPORT = 28983;
  
  public static final int BABY_DRAGON_BONEMEAL_28984 = 28984;
  
  public static final int LOVE_LETTER = 28986;
  
  public static final int PLUSHY = 28987;
  
  public static final int BLUE_MOON_SPEAR = 28988;
  
  public static final int ATLATL_DART = 28991;
  
  public static final int DUAL_MACUAHUITL = 28997;
  
  public static final int ECLIPSE_ATLATL = 29000;
  
  public static final int ECLIPSE_MOON_CHESTPLATE = 29004;
  
  public static final int ECLIPSE_MOON_TASSETS = 29007;
  
  public static final int ECLIPSE_MOON_HELM = 29010;
  
  public static final int BLUE_MOON_CHESTPLATE = 29013;
  
  public static final int BLUE_MOON_TASSETS = 29016;
  
  public static final int BLUE_MOON_HELM = 29019;
  
  public static final int BLOOD_MOON_CHESTPLATE = 29022;
  
  public static final int BLOOD_MOON_TASSETS = 29025;
  
  public static final int BLOOD_MOON_HELM = 29028;
  
  public static final int ECLIPSE_MOON_CHESTPLATE_29031 = 29031;
  
  public static final int ECLIPSE_MOON_TASSETS_29033 = 29033;
  
  public static final int ECLIPSE_MOON_HELM_29035 = 29035;
  
  public static final int BLUE_MOON_CHESTPLATE_29037 = 29037;
  
  public static final int BLUE_MOON_TASSETS_29039 = 29039;
  
  public static final int BLUE_MOON_HELM_29041 = 29041;
  
  public static final int BLOOD_MOON_CHESTPLATE_29043 = 29043;
  
  public static final int BLOOD_MOON_TASSETS_29045 = 29045;
  
  public static final int BLOOD_MOON_HELM_29047 = 29047;
  
  public static final int ECLIPSE_MOON_CHESTPLATE_BROKEN = 29049;
  
  public static final int ECLIPSE_MOON_TASSETS_BROKEN = 29052;
  
  public static final int ECLIPSE_MOON_HELM_BROKEN = 29055;
  
  public static final int BLUE_MOON_CHESTPLATE_BROKEN = 29058;
  
  public static final int BLUE_MOON_TASSETS_BROKEN = 29061;
  
  public static final int BLUE_MOON_HELM_BROKEN = 29064;
  
  public static final int BLOOD_MOON_CHESTPLATE_BROKEN = 29067;
  
  public static final int BLOOD_MOON_TASSETS_BROKEN = 29070;
  
  public static final int BLOOD_MOON_HELM_BROKEN = 29073;
  
  public static final int RAW_MOSS_LIZARD = 29076;
  
  public static final int COOKED_MOSS_LIZARD = 29077;
  
  public static final int MOONLIGHT_GRUB = 29078;
  
  public static final int MOONLIGHT_GRUB_PASTE = 29079;
  
  public static final int MOONLIGHT_POTION4 = 29080;
  
  public static final int MOONLIGHT_POTION3 = 29081;
  
  public static final int MOONLIGHT_POTION2 = 29082;
  
  public static final int MOONLIGHT_POTION1 = 29083;
  
  public static final int SULPHUR_BLADES = 29084;
  
  public static final int SULPHUROUS_ESSENCE = 29087;
  
  public static final int CALCIFIED_DEPOSIT = 29088;
  
  public static final int CALCIFIED_MOTH = 29090;
  
  public static final int NOT_MEAT = 29098;
  
  public static final int RAW_BARBTAILED_KEBBIT = 29101;
  
  public static final int RAW_WILD_KEBBIT = 29104;
  
  public static final int RAW_DASHING_KEBBIT = 29107;
  
  public static final int RAW_PYRE_FOX = 29110;
  
  public static final int RAW_MOONLIGHT_ANTELOPE = 29113;
  
  public static final int RAW_SUNLIGHT_ANTELOPE = 29116;
  
  public static final int RAW_GRAAHK = 29119;
  
  public static final int RAW_LARUPIA = 29122;
  
  public static final int RAW_KYATT = 29125;
  
  public static final int COOKED_WILD_KEBBIT = 29128;
  
  public static final int COOKED_BARBTAILED_KEBBIT = 29131;
  
  public static final int COOKED_DASHING_KEBBIT = 29134;
  
  public static final int COOKED_PYRE_FOX = 29137;
  
  public static final int COOKED_SUNLIGHT_ANTELOPE = 29140;
  
  public static final int COOKED_MOONLIGHT_ANTELOPE = 29143;
  
  public static final int COOKED_LARUPIA = 29146;
  
  public static final int COOKED_GRAAHK = 29149;
  
  public static final int COOKED_KYATT = 29152;
  
  public static final int BURNT_KEBBIT = 29155;
  
  public static final int BURNT_LARGE_BEAST = 29157;
  
  public static final int BURNT_ANTELOPE = 29159;
  
  public static final int BURNT_FOX_MEAT = 29161;
  
  public static final int FOX_FUR = 29163;
  
  public static final int JERBOA_TAIL = 29166;
  
  public static final int SUNLIGHT_ANTELOPE_ANTLER = 29168;
  
  public static final int MOONLIGHT_ANTELOPE_ANTLER = 29171;
  
  public static final int MOONLIGHT_ANTELOPE_FUR = 29174;
  
  public static final int SUNLIGHT_ANTELOPE_FUR = 29177;
  
  public static final int SAPPHIRE_GLACIALIS_MIX_2 = 29180;
  
  public static final int SNOWY_KNIGHT_MIX_2 = 29183;
  
  public static final int RUBY_HARVEST_MIX_2 = 29186;
  
  public static final int BLACK_WARLOCK_MIX_2 = 29189;
  
  public static final int SUNLIGHT_MOTH_MIX_2 = 29192;
  
  public static final int MOONLIGHT_MOTH_MIX_2 = 29195;
  
  public static final int SAPPHIRE_GLACIALIS_MIX_1 = 29198;
  
  public static final int SNOWY_KNIGHT_MIX_1 = 29201;
  
  public static final int RUBY_HARVEST_MIX_1 = 29204;
  
  public static final int BLACK_WARLOCK_MIX_1 = 29207;
  
  public static final int SUNLIGHT_MOTH_MIX_1 = 29210;
  
  public static final int MOONLIGHT_MOTH_MIX_1 = 29213;
  
  public static final int RAW_BREAM = 29216;
  
  public static final int COOKED_BREAM = 29217;
  
  public static final int JAGUAR_FUR = 29218;
  
  public static final int CHINCHOMPA_TUFT = 29221;
  
  public static final int TAILFEATHERS = 29222;
  
  public static final int KEBBITY_TUFT = 29223;
  
  public static final int BLUE_BUTTERFLY_WING = 29224;
  
  public static final int SWAMP_LIZARD_CLAW = 29225;
  
  public static final int LARUPIA_EAR = 29226;
  
  public static final int WHITE_BUTTERFLY_WING = 29227;
  
  public static final int LARGE_JERBOA_TAIL = 29228;
  
  public static final int GRAAHK_HORN_SPUR = 29229;
  
  public static final int BLACK_BUTTERFLY_WING = 29230;
  
  public static final int ORANGE_SALAMANDER_CLAW = 29231;
  
  public static final int KYATT_TOOTH_CHIP = 29232;
  
  public static final int FOX_FLUFF = 29233;
  
  public static final int RED_SALAMANDER_CLAW = 29234;
  
  public static final int RED_CHINCHOMPA_TUFT = 29235;
  
  public static final int ANTELOPE_HOOF_SHARD = 29236;
  
  public static final int SUNLIGHT_MOTH_WING = 29237;
  
  public static final int SALAMANDER_CLAW = 29238;
  
  public static final int HERBY_TUFT = 29239;
  
  public static final int MOONLIGHT_MOTH_WING = 29240;
  
  public static final int ANTELOPE_HOOF_SHARD_29241 = 29241;
  
  public static final int HUNTERS_LOOT_SACK_BASIC = 29242;
  
  public static final int HUNTERS_LOOT_SACK_ADEPT = 29244;
  
  public static final int HUNTERS_LOOT_SACK_EXPERT = 29246;
  
  public static final int HUNTERS_LOOT_SACK_MASTER = 29248;
  
  public static final int HUNTERS_LOOT_SACK = 29250;
  
  public static final int BASIC_QUETZAL_WHISTLE_BLUEPRINT = 29251;
  
  public static final int ENHANCED_QUETZAL_WHISTLE_BLUEPRINT = 29253;
  
  public static final int PERFECTED_QUETZAL_WHISTLE_BLUEPRINT = 29256;
  
  public static final int TORN_ENHANCED_QUETZAL_WHISTLE_BLUEPRINT = 29259;
  
  public static final int TORN_PERFECTED_QUETZAL_WHISTLE_BLUEPRINT = 29261;
  
  public static final int GUILD_HUNTER_HEADWEAR = 29263;
  
  public static final int GUILD_HUNTER_TOP = 29265;
  
  public static final int GUILD_HUNTER_LEGS = 29267;
  
  public static final int GUILD_HUNTER_BOOTS = 29269;
  
  public static final int BASIC_QUETZAL_WHISTLE = 29271;
  
  public static final int ENHANCED_QUETZAL_WHISTLE = 29273;
  
  public static final int PERFECTED_QUETZAL_WHISTLE = 29275;
  
  public static final int TRAPPERS_TIPPLE = 29277;
  
  public static final int MIXED_HIDE_TOP = 29280;
  
  public static final int MIXED_HIDE_LEGS = 29283;
  
  public static final int MIXED_HIDE_BOOTS = 29286;
  
  public static final int MIXED_HIDE_CAPE = 29289;
  
  public static final int MIXED_HIDE_BASE = 29292;
  
  public static final int SMALL_MEAT_POUCH = 29295;
  
  public static final int LARGE_MEAT_POUCH = 29297;
  
  public static final int SMALL_FUR_POUCH = 29299;
  
  public static final int MEDIUM_FUR_POUCH = 29301;
  
  public static final int LARGE_FUR_POUCH = 29303;
  
  public static final int HUNTERS_SPEAR = 29305;
  
  public static final int QUETZAL_FEED_29307 = 29307;
  
  public static final int HUNTSMANS_KIT = 29309;
  
  public static final int HUNTER_SPEAR_TIPS = 29311;
  
  public static final int TATTERED_REQUEST_NOTE = 29317;
  
  public static final int GUILD_HISTORY_EXCERPT = 29319;
  
  public static final int APATURAS_NOTE = 29321;
  
  public static final int APATURAS_KEY = 29323;
  
  public static final int HOUSE_KEYS = 29325;
  
  public static final int VALUABLES = 29332;
  
  public static final int BLESSED_BONE_STATUETTE = 29338;
  
  public static final int BLESSED_BONE_STATUETTE_29340 = 29340;
  
  public static final int BLESSED_BONE_STATUETTE_29342 = 29342;
  
  public static final int BLESSED_BONES = 29344;
  
  public static final int BLESSED_BAT_BONES = 29346;
  
  public static final int BLESSED_BIG_BONES = 29348;
  
  public static final int BLESSED_ZOGRE_BONES = 29350;
  
  public static final int BLESSED_BABYDRAGON_BONES = 29352;
  
  public static final int BLESSED_BABYWYRM_BONES = 29354;
  
  public static final int BLESSED_DRAGON_BONES = 29356;
  
  public static final int BLESSED_LAVA_DRAGON_BONES = 29358;
  
  public static final int BLESSED_WYVERN_BONES = 29360;
  
  public static final int BLESSED_SUPERIOR_DRAGON_BONES = 29362;
  
  public static final int BLESSED_WYRM_BONES = 29364;
  
  public static final int BLESSED_DRAKE_BONES = 29366;
  
  public static final int BLESSED_HYDRA_BONES = 29368;
  
  public static final int BLESSED_FAYRG_BONES = 29370;
  
  public static final int BLESSED_RAURG_BONES = 29372;
  
  public static final int BLESSED_OURG_BONES = 29374;
  
  public static final int DAGANNOTH_BONES_29376 = 29376;
  
  public static final int SUNKISSED_BONES = 29378;
  
  public static final int BLESSED_BONE_SHARDS = 29381;
  
  public static final int JUG_OF_SUNFIRE_WINE = 29382;
  
  public static final int JUG_OF_BLESSED_SUNFIRE_WINE = 29384;
  
  public static final int JUG_OF_BLESSED_WINE = 29386;
  
  public static final int TOKEN = 29388;
  
  public static final int TOKEN_29389 = 29389;
  
  public static final int TOKEN_29390 = 29390;
  
  public static final int TOKEN_29391 = 29391;
  
  public static final int TOKEN_29392 = 29392;
  
  public static final int TOKEN_29393 = 29393;
  
  public static final int TOKEN_29394 = 29394;
  
  public static final int TOKEN_29395 = 29395;
  
  public static final int TOKEN_29396 = 29396;
  
  public static final int TOKEN_29397 = 29397;
  
  public static final int TOKEN_29398 = 29398;
  
  public static final int TOKEN_29399 = 29399;
  
  public static final int TOKEN_29400 = 29400;
  
  public static final int TOKEN_29401 = 29401;
  
  public static final int TOKEN_29402 = 29402;
  
  public static final int TOKEN_29403 = 29403;
  
  public static final int TOKEN_29404 = 29404;
  
  public static final int TOKEN_29405 = 29405;
  
  public static final int TOKEN_29406 = 29406;
  
  public static final int TOKEN_29407 = 29407;
  
  public static final int A_NICE_KEY = 29408;
  
  public static final int SUNBEAM_ALE = 29409;
  
  public static final int STEAMFORGE_BREW = 29412;
  
  public static final int ECLIPSE_RED = 29415;
  
  public static final int MOONLITE = 29418;
  
  public static final int SUNSHINE = 29421;
  
  public static final int SUNFIRE_FANATIC_ARMOUR_SET = 29424;
  
  public static final int HERBALISTS_NOTES = 29427;
  
  public static final int CHEFS_NOTES = 29428;
  
  public static final int BOOK_OF_EGG = 29433;
  
  public static final int BOOK_OF_EGG_29435 = 29435;
  
  public static final int EGG_PRIEST_ROBE = 29437;
  
  public static final int EGG_PRIEST_ROBE_TOP = 29439;
  
  public static final int EGG_PRIEST_NECKLACE = 29441;
  
  public static final int EGG_PRIEST_MITRE = 29443;
  
  public static final int IMBUED_MAGE_ARENA_CAPE = 29448;
  
  public static final int ZOMBIE_PIRATE_KEY = 29449;
  
  public static final int TELEPORT_ANCHORING_SCROLL = 29455;
  
  public static final int ADAMANT_SEEDS = 29458;
  
  public static final int WILDERNESS_AGILITY_TICKET = 29460;
  
  public static final int SMALL_MEAT_POUCH_OPEN = 29462;
  
  public static final int LARGE_MEAT_POUCH_OPEN = 29464;
  
  public static final int SMALL_FUR_POUCH_OPEN = 29466;
  
  public static final int MEDIUM_FUR_POUCH_OPEN = 29468;
  
  public static final int LARGE_FUR_POUCH_OPEN = 29470;
  
  public static final int PROSPECTOR_HELMET_29472 = 29472;
  
  public static final int PROSPECTOR_JACKET_29474 = 29474;
  
  public static final int PROSPECTOR_LEGS_29476 = 29476;
  
  public static final int PROSPECTOR_BOOTS_29478 = 29478;
  
  public static final int AGILITY_ARENA_TICKET_29480 = 29480;
  
  public static final int BRIMHAVEN_VOUCHER = 29482;
  
  public static final int AGILITY_XP = 29484;
  
  public static final int GRACEFUL_RECOLOUR = 29485;
  
  public static final int CURSED_AMULET_OF_MAGIC = 29486;
  
  public static final int RAINBOW_CAPE = 29489;
  
  public static final int COLOURFUL_CAPE = 29491;
  
  public static final int COLOURFUL_CAPE_29493 = 29493;
  
  public static final int COLOURFUL_CAPE_29495 = 29495;
  
  public static final int COLOURFUL_CAPE_29497 = 29497;
  
  public static final int COLOURFUL_CAPE_29499 = 29499;
  
  public static final int COLOURFUL_CAPE_29501 = 29501;
  
  public static final int COLOURFUL_CAPE_29503 = 29503;
  
  public static final int COLOURFUL_CAPE_29505 = 29505;
  
  public static final int RAINBOW_CROWN_SHIRT = 29507;
  
  public static final int COLOURFUL_CROWN_SHIRT = 29509;
  
  public static final int COLOURFUL_CROWN_SHIRT_29510 = 29510;
  
  public static final int COLOURFUL_CROWN_SHIRT_29511 = 29511;
  
  public static final int COLOURFUL_CROWN_SHIRT_29512 = 29512;
  
  public static final int COLOURFUL_CROWN_SHIRT_29513 = 29513;
  
  public static final int COLOURFUL_CROWN_SHIRT_29514 = 29514;
  
  public static final int COLOURFUL_CROWN_SHIRT_29515 = 29515;
  
  public static final int COLOURFUL_CROWN_SHIRT_29516 = 29516;
  
  public static final int ARMADYL_COMMUNIQU = 29517;
  
  public static final int UNCONSCIOUS_BROAV = 29518;
  
  public static final int BROAV = 29519;
  
  public static final int DIRTY_SHIRT = 29521;
  
  public static final int WASTEPAPER_BASKET = 29522;
  
  public static final int RUBY_KEY_29523 = 29523;
  
  public static final int NOTES_ON_PRESSURE = 29524;
  
  public static final int MOVARIOS_NOTES_VOLUME_1 = 29525;
  
  public static final int MOVARIOS_NOTES_VOLUME_2 = 29526;
  
  public static final int WEIGHT_1KG = 29527;
  
  public static final int WEIGHT_2KG = 29528;
  
  public static final int WEIGHT_5KG = 29529;
  
  public static final int ENRICHED_SNAPDRAGON = 29530;
  
  public static final int SUPER_TRUTH_SERUM = 29531;
  
  public static final int TRUTH_SERUM_29532 = 29532;
  
  public static final int SUSPECT_SKETCH = 29533;
  
  public static final int CELL_KEY = 29534;
  
  public static final int STRANGE_TELEORB = 29535;
  
  public static final int TELEORB = 29536;
  
  public static final int TELEORB_29537 = 29537;
  
  public static final int ENRICHED_SNAPDRAGON_SEED = 29538;
  
  public static final int AGILITY_DOLMEN = 29539;
  
  public static final int ENERGY_DOLMEN = 29540;
  
  public static final int RESTORATION_DOLMEN = 29541;
  
  public static final int ATTACK_DOLMEN = 29542;
  
  public static final int STRENGTH_DOLMEN = 29543;
  
  public static final int DEFENCE_DOLMEN = 29544;
  
  public static final int COMBAT_DOLMEN = 29545;
  
  public static final int RANGED_DOLMEN = 29546;
  
  public static final int PRAYER_DOLMEN = 29547;
  
  public static final int HUNTER_DOLMEN = 29548;
  
  public static final int FISHING_DOLMEN = 29549;
  
  public static final int MAGIC_DOLMEN = 29550;
  
  public static final int BALANCE_DOLMEN = 29551;
  
  public static final int AIR_BLOCK = 29552;
  
  public static final int EARTH_BLOCK = 29553;
  
  public static final int FIRE_BLOCK = 29554;
  
  public static final int WATER_BLOCK = 29555;
  
  public static final int VINE_FLOWER = 29556;
  
  public static final int GRIMY_NOTE = 29558;
  
  public static final int ELITE_BLACK_FULL_HELM = 29560;
  
  public static final int ELITE_BLACK_PLATEBODY = 29562;
  
  public static final int ELITE_BLACK_PLATELEGS = 29564;
  
  public static final int DARK_SQUALL_HOOD = 29566;
  
  public static final int DARK_SQUALL_ROBE_TOP = 29568;
  
  public static final int DARK_SQUALL_ROBE_BOTTOM = 29570;
  
  public static final int SILIF = 29572;
  
  public static final int LIT_EXPLOSIVE = 29573;
  
  public static final int BURNING_CLAW = 29574;
  
  public static final int BURNING_CLAWS = 29577;
  
  public static final int TORMENTED_SYNAPSE = 29580;
  
  public static final int SMOULDERING_HEART = 29583;
  
  public static final int SMOULDERING_PILE_OF_FLESH = 29585;
  
  public static final int SMOULDERING_GLAND = 29587;
  
  public static final int EMBERLIGHT = 29589;
  
  public static final int SCORCHING_BOW = 29591;
  
  public static final int PURGING_STAFF = 29594;
  
  public static final int DURADELS_NOTES = 29596;
  
  public static final int DEADMAN_RUG = 29598;
  
  public static final int CORRUPTED_DARK_BOW = 29599;
  
  public static final int CORRUPTED_VOLATILE_NIGHTMARE_STAFF = 29602;
  
  public static final int ARMADYL_GODSWORD_DEADMAN = 29605;
  
  public static final int VOIDWAKER_DEADMAN = 29607;
  
  public static final int VOLATILE_NIGHTMARE_STAFF_DEADMAN = 29609;
  
  public static final int DARK_BOW_DEADMAN = 29611;
  
  public static final int IMBUED_ZAMORAK_CAPE_DEADMAN = 29613;
  
  public static final int IMBUED_GUTHIX_CAPE_DEADMAN = 29615;
  
  public static final int IMBUED_SARADOMIN_CAPE_DEADMAN = 29617;
  
  public static final int ARMAGEDDON_RUG = 29619;
  
  public static final int ARMAGEDDON_TELEPORT_SCROLL = 29622;
  
  public static final int ARMAGEDDON_WEAPON_SCROLL = 29625;
  
  public static final int ARMAGEDDON_CAPE_FABRIC = 29628;
  
  public static final int BLIGHTED_OVERLOAD_4 = 29631;
  
  public static final int BLIGHTED_OVERLOAD_3 = 29634;
  
  public static final int BLIGHTED_OVERLOAD_2 = 29637;
  
  public static final int BLIGHTED_OVERLOAD_1 = 29640;
  
  public static final int CHITIN = 29643;
  
  public static final int CABBAGE_29646 = 29646;
  
  public static final int SIGIL_OF_METICULOUSNESS = 29648;
  
  public static final int SIGIL_OF_METICULOUSNESS_29649 = 29649;
  
  public static final int SIGIL_OF_REVOKED_LIMITATION = 29651;
  
  public static final int SIGIL_OF_REVOKED_LIMITATION_29652 = 29652;
  
  public static final int SIGIL_OF_RAMPART = 29654;
  
  public static final int SIGIL_OF_RAMPART_29655 = 29655;
  
  public static final int SIGIL_OF_DECEPTION = 29657;
  
  public static final int SIGIL_OF_DECEPTION_29658 = 29658;
  
  public static final int SIGIL_OF_LITHE = 29660;
  
  public static final int SIGIL_OF_LITHE_29661 = 29661;
  
  public static final int SIGIL_OF_ADROIT = 29663;
  
  public static final int SIGIL_OF_ADROIT_29664 = 29664;
  
  public static final int SIGIL_OF_ONSLAUGHT = 29666;
  
  public static final int SIGIL_OF_ONSLAUGHT_29667 = 29667;
  
  public static final int SIGIL_OF_RESTORATION = 29669;
  
  public static final int SIGIL_OF_RESTORATION_29670 = 29670;
  
  public static final int SIGIL_OF_SWASHBUCKLER = 29672;
  
  public static final int SIGIL_OF_SWASHBUCKLER_29673 = 29673;
  
  public static final int SIGIL_OF_GUNSLINGER = 29675;
  
  public static final int SIGIL_OF_GUNSLINGER_29676 = 29676;
  
  public static final int SIGIL_OF_ARCANE_SWIFTNESS = 29678;
  
  public static final int SIGIL_OF_ARCANE_SWIFTNESS_29679 = 29679;
  
  public static final int GUTHIXIAN_TEMPLE_TELEPORT = 29684;
  
  public static final int DNI23_TORSO_LIGHTBUTTONS = 29686;
  
  public static final int DNI23_TORSO_DARKBUTTONS = 29688;
  
  public static final int DNI23_TORSO_DARKBUTTONS_29690 = 29690;
  
  public static final int DNI23_TORSO_SHIRT = 29692;
  
  public static final int DNI23_TORSO_STITCHING = 29694;
  
  public static final int DNI23_TORSO_TWOTONED = 29696;
  
  public static final int DNI23_TORSO_PRINCELY = 29698;
  
  public static final int DNI23_TORSO_RIPPEDWESKIT = 29700;
  
  public static final int DNI23_TORSO_RIPPEDWESKIT_29702 = 29702;
  
  public static final int DNI23_TORSO_CROPTOPS = 29704;
  
  public static final int DNI23_TORSO_POLONECK = 29706;
  
  public static final int DNI23_TORSO_SIMPLE = 29708;
  
  public static final int DNI23_TORSO_FRILLY = 29710;
  
  public static final int DNI23_TORSO_CORSETRY = 29712;
  
  public static final int DNI23_TORSO_BODICE = 29714;
  
  public static final int DNI23_ARMS_THIN = 29716;
  
  public static final int DNI23_ARMS_SHOULDERPADS = 29718;
  
  public static final int DNI23_ARMS_THICKSTRIPE = 29720;
  
  public static final int DNI23_ARMS_LOOSESLEEVES = 29722;
  
  public static final int DNI23_ARMS_PRINCELY = 29724;
  
  public static final int DNI23_ARMS_TATTYLONG = 29726;
  
  public static final int DNI23_ARMS_RIPPED = 29728;
  
  public static final int DNI23_ARMS_BARE = 29730;
  
  public static final int DNI23_ARMS_FRILLY = 29732;
  
  public static final int DNI23_ARMS_TATTYSHORT = 29734;
  
  public static final int DNI23_ARMS_BARESHOULDERS = 29736;
  
  public static final int DNI23_LEGS_SHORTS = 29738;
  
  public static final int DNI23_LEGS_BEACH = 29740;
  
  public static final int DNI23_LEGS_PRINCELY = 29742;
  
  public static final int DNI23_LEGS_LEGGINGS = 29744;
  
  public static final int DNI23_LEGS_SIDESTRIPES = 29746;
  
  public static final int DNI23_LEGS_RIPPED = 29748;
  
  public static final int DNI23_LEGS_PATCHED = 29750;
  
  public static final int DNI23_LEGS_SKIRT = 29752;
  
  public static final int DNI23_LEGS_LONGSKIRT = 29754;
  
  public static final int DNI23_LEGS_LONGNARROWSKIRT = 29756;
  
  public static final int DNI23_LEGS_SHORTSKIRT = 29758;
  
  public static final int DNI23_LEGS_LAYERED = 29760;
  
  public static final int DNI23_LEGS_SASHDOTS = 29762;
  
  public static final int DNI23_LEGS_BIGHEM = 29764;
  
  public static final int DNI23_LEGS_SASHTROUSERS = 29766;
  
  public static final int DNI23_LEGS_PATTERNED = 29768;
  
  public static final int DNI23_LEGS_TORNSKIRT = 29770;
  
  public static final int DNI23_LEGS_PATCHEDSKIRT = 29772;
  
  public static final int AMYS_SAW_OFFHAND = 29774;
  
  public static final int IMCANDO_HAMMER_OFFHAND = 29775;
  
  public static final int BRUMA_TORCH_OFFHAND = 29777;
  
  public static final int COAGULATED_VENOM = 29781;
  
  public static final int SPIDER_CAVE_TELEPORT = 29782;
  
  public static final int ARAXYTE_VENOM_SACK = 29784;
  
  public static final int JAR_OF_VENOM = 29786;
  
  public static final int ARAXYTE_HEAD = 29788;
  
  public static final int NOXIOUS_POINT = 29790;
  
  public static final int NOXIOUS_BLADE = 29792;
  
  public static final int NOXIOUS_POMMEL = 29794;
  
  public static final int NOXIOUS_HALBERD = 29796;
  
  public static final int ARAXYTE_FANG = 29799;
  
  public static final int AMULET_OF_RANCOUR = 29801;
  
  public static final int AMULET_OF_RANCOUR_S = 29804;
  
  public static final int ARANEA_BOOTS = 29806;
  
  public static final int VENOMRIDDLED_NOTE = 29809;
  
  public static final int ARAXYTE_SLAYER_HELMET = 29816;
  
  public static final int ARAXYTE_SLAYER_HELMET_I = 29818;
  
  public static final int ARAXYTE_SLAYER_HELMET_I_29820 = 29820;
  
  public static final int ARAXYTE_SLAYER_HELMET_I_29822 = 29822;
  
  public static final int EXTENDED_ANTIVENOM4 = 29824;
  
  public static final int EXTENDED_ANTIVENOM3 = 29827;
  
  public static final int EXTENDED_ANTIVENOM2 = 29830;
  
  public static final int EXTENDED_ANTIVENOM1 = 29833;
  
  public static final int NID = 29836;
  
  public static final int RAX = 29838;
  
  public static final int ECLIPSE_MOON_CHESTPLATE_29840 = 29840;
  
  public static final int ECLIPSE_MOON_TASSETS_29841 = 29841;
  
  public static final int ECLIPSE_MOON_HELM_29842 = 29842;
  
  public static final int BLUE_MOON_CHESTPLATE_29843 = 29843;
  
  public static final int BLUE_MOON_TASSETS_29844 = 29844;
  
  public static final int BLUE_MOON_HELM_29845 = 29845;
  
  public static final int BLOOD_MOON_CHESTPLATE_29846 = 29846;
  
  public static final int BLOOD_MOON_TASSETS_29847 = 29847;
  
  public static final int BLOOD_MOON_HELM_29848 = 29848;
  
  public static final int BLUE_MOON_SPEAR_29849 = 29849;
  
  public static final int DUAL_MACUAHUITL_29850 = 29850;
  
  public static final int ECLIPSE_ATLATL_29851 = 29851;
  
  public static final int ATLATL_DART_29852 = 29852;
  
  public static final int CLUE_SCROLL_EASY_29853 = 29853;
  
  public static final int CLUE_SCROLL_EASY_29854 = 29854;
  
  public static final int CLUE_SCROLL_ELITE_29855 = 29855;
  
  public static final int CLUE_SCROLL_ELITE_29856 = 29856;
  
  public static final int CLUE_SCROLL_MEDIUM_29857 = 29857;
  
  public static final int CLUE_SCROLL_MEDIUM_29858 = 29858;
  
  public static final int CLUE_SCROLL_HARD_29859 = 29859;
  
  public static final int CASKET_EASY_29860 = 29860;
  
  public static final int CASKET_MEDIUM_29861 = 29861;
  
  public static final int CASKET_MEDIUM_29862 = 29862;
  
  public static final int CASKET_MEDIUM_29863 = 29863;
  
  public static final int CASKET_HARD_29864 = 29864;
  
  public static final int PRINCE_ITZLA_ARKAN = 29867;
  
  public static final int EMISSARY_HOOD = 29868;
  
  public static final int EMISSARY_ROBE_TOP = 29870;
  
  public static final int EMISSARY_ROBE_BOTTOM = 29872;
  
  public static final int EMISSARY_SANDALS = 29874;
  
  public static final int STONE_TABLET_29876 = 29876;
  
  public static final int TOWER_KEY_29877 = 29877;
  
  public static final int BOOK_29878 = 29878;
  
  public static final int POEM = 29879;
  
  public static final int SCRAP_OF_PAPER = 29880;
  
  public static final int SCRAP_OF_PAPER_29881 = 29881;
  
  public static final int SCRAP_OF_PAPER_29882 = 29882;
  
  public static final int COMPLETED_NOTE = 29883;
  
  public static final int BANDAGES_29884 = 29884;
  
  public static final int ICON = 29885;
  
  public static final int ICON_29886 = 29886;
  
  public static final int ICON_29887 = 29887;
  
  public static final int ICON_29888 = 29888;
  
  public static final int GLACIAL_TEMOTLI = 29889;
  
  public static final int PENDANT_OF_ATES_INERT = 29892;
  
  public static final int PENDANT_OF_ATES = 29893;
  
  public static final int FROZEN_TEAR = 29895;
  
  public static final int ICON_29897 = 29897;
  
  public static final int TEST_KEBAB = 29898;
  
  public static final int TEST_KEBAB_29899 = 29899;
  
  public static final int VARLAMORIAN_KEBAB = 29900;
  
  public static final int TATTERED_SAILS = 29903;
  
  public static final int SAILS = 29904;
  
  public static final int BETTYS_NOTES = 29905;
  
  public static final int STOREROOM_KEY_29906 = 29906;
  
  public static final int PROP_SWORD_29911 = 29911;
  
  public static final int BUTLERS_TRAY = 29912;
  
  public static final int BUTLERS_TRAY_29913 = 29913;
  
  public static final int BUTLERS_UNIFORM = 29914;
  
  public static final int BUTLERS_UNIFORM_29915 = 29915;
  
  public static final int BUTLERS_UNIFORM_29916 = 29916;
  
  public static final int BUTLERS_UNIFORM_29918 = 29918;
  
  public static final int COSTUME_NEEDLE = 29920;
  
  public static final int CASE_FILE = 29922;
  
  public static final int CHEST_KEY_29923 = 29923;
  
  public static final int DRINKING_FLASK = 29925;
  
  public static final int THREATENING_NOTE = 29926;
  
  public static final int SHIPPING_CONTRACT = 29927;
  
  public static final int WINE_LABELS = 29928;
  
  public static final int RAM_MASK = 29929;
  
  public static final int WOLF_MASK_29930 = 29930;
  
  public static final int BIRD_MASK = 29931;
  
  public static final int JAGUAR_MASK = 29932;
  
  public static final int SNAKE_MASK = 29933;
  
  public static final int RAM_MASK_29934 = 29934;
  
  public static final int WOLF_MASK_29936 = 29936;
  
  public static final int BIRD_MASK_29938 = 29938;
  
  public static final int JAGUAR_MASK_29940 = 29940;
  
  public static final int SNAKE_MASK_29942 = 29942;
  
  public static final int BLACKBIRD_RED = 29944;
  
  public static final int CHILHUAC_RED = 29947;
  
  public static final int PRINCIPUM_RED = 29950;
  
  public static final int IXCOZTIC_WHITE = 29952;
  
  public static final int METZTONALLI_WHITE = 29955;
  
  public static final int TONAMEYO_WHITE = 29958;
  
  public static final int FORTIS_ASH_WHITE = 29961;
  
  public static final int CHICHILIHUI_ROS = 29963;
  
  public static final int IMPERIAL_ROS = 29966;
  
  public static final int XOCHIPALTIC_ROS = 29969;
  
  public static final int APPRENTICE_POTION_PACK = 29971;
  
  public static final int ADEPT_POTION_PACK = 29972;
  
  public static final int EXPERT_POTION_PACK = 29973;
  
  public static final int PRESCRIPTION_GOGGLES = 29974;
  
  public static final int PRESCRIPTION_GOGGLES_29976 = 29976;
  
  public static final int ALCHEMIST_LABCOAT = 29978;
  
  public static final int ALCHEMIST_LABCOAT_29980 = 29980;
  
  public static final int ALCHEMIST_PANTS = 29982;
  
  public static final int ALCHEMIST_PANTS_29984 = 29984;
  
  public static final int ALCHEMIST_GLOVES = 29986;
  
  public static final int ALCHEMISTS_AMULET = 29988;
  
  public static final int ALCHEMISTS_AMULET_29990 = 29990;
  
  public static final int ALCHEMISTS_AMULET_29992 = 29992;
  
  public static final int ALDARIUM = 29993;
  
  public static final int REAGENT_POUCH = 29996;
  
  public static final int OPEN_REAGENT_POUCH = 29998;
  
  public static final int POTION_STORAGE = 29999;
  
  public static final int CHUGGING_BARREL = 30000;
  
  public static final int CHUGGING_BARREL_DISASSEMBLED = 30002;
  
  public static final int MOX_PASTE = 30005;
  
  public static final int AGA_PASTE = 30007;
  
  public static final int LYE_PASTE = 30009;
  
  public static final int MAMMOTHMIGHT_MIX = 30011;
  
  public static final int MYSTIC_MANA_AMALGAM = 30012;
  
  public static final int MARLEYS_MOONLIGHT = 30013;
  
  public static final int ALCOAUGMENTATOR = 30014;
  
  public static final int AQUALUX_AMALGAM = 30015;
  
  public static final int AZURE_AURA_MIX = 30016;
  
  public static final int LIPLACK_LIQUOR = 30017;
  
  public static final int ANTILEECH_LOTION = 30018;
  
  public static final int MEGALITE_LIQUID = 30019;
  
  public static final int MIXALOT = 30020;
  
  public static final int MAMMOTHMIGHT_MIX_30021 = 30021;
  
  public static final int MYSTIC_MANA_AMALGAM_30022 = 30022;
  
  public static final int MARLEYS_MOONLIGHT_30023 = 30023;
  
  public static final int ALCOAUGMENTATOR_30024 = 30024;
  
  public static final int AQUALUX_AMALGAM_30025 = 30025;
  
  public static final int AZURE_AURA_MIX_30026 = 30026;
  
  public static final int LIPLACK_LIQUOR_30027 = 30027;
  
  public static final int ANTILEECH_LOTION_30028 = 30028;
  
  public static final int MEGALITE_LIQUID_30029 = 30029;
  
  public static final int MIXALOT_30030 = 30030;
  
  public static final int DIGWEED = 30031;
  
  public static final int MIXOLOGY_LAB_NOTES = 30032;
  
  public static final int MOONRISE_WINES = 30035;
  
  public static final int GRAPE_BARREL = 30037;
  
  public static final int TERMITES = 30038;
  
  public static final int COLOSSAL_WYRM_TELEPORT_SCROLL = 30040;
  
  public static final int CALCIFIED_ACORN = 30042;
  
  public static final int GRACEFUL_CRAFTING_KIT = 30044;
  
  public static final int GRACEFUL_HOOD_30045 = 30045;
  
  public static final int GRACEFUL_HOOD_30047 = 30047;
  
  public static final int GRACEFUL_CAPE_30048 = 30048;
  
  public static final int GRACEFUL_CAPE_30050 = 30050;
  
  public static final int GRACEFUL_TOP_30051 = 30051;
  
  public static final int GRACEFUL_TOP_30053 = 30053;
  
  public static final int GRACEFUL_LEGS_30054 = 30054;
  
  public static final int GRACEFUL_LEGS_30056 = 30056;
  
  public static final int GRACEFUL_GLOVES_30057 = 30057;
  
  public static final int GRACEFUL_GLOVES_30059 = 30059;
  
  public static final int GRACEFUL_BOOTS_30060 = 30060;
  
  public static final int GRACEFUL_BOOTS_30062 = 30062;
  
  public static final int TOME_OF_EARTH = 30064;
  
  public static final int TOME_OF_EARTH_EMPTY = 30066;
  
  public static final int SOILED_PAGE = 30068;
  
  public static final int DRAGON_HUNTER_WAND = 30070;
  
  public static final int HUEYCOATL_HIDE_COIF = 30073;
  
  public static final int HUEYCOATL_HIDE_BODY = 30076;
  
  public static final int HUEYCOATL_HIDE_CHAPS = 30079;
  
  public static final int HUEYCOATL_HIDE_VAMBRACES = 30082;
  
  public static final int HUEYCOATL_HIDE = 30085;
  
  public static final int HUASCA_SEED = 30088;
  
  public static final int GRIMY_HUASCA = 30094;
  
  public static final int HUASCA = 30097;
  
  public static final int HUASCA_POTION_UNF = 30100;
  
  public static final int REDBERRY_ANTELOPE = 30103;
  
  public static final int TOOTH_HALF_OF_KEY_30105 = 30105;
  
  public static final int LOOP_HALF_OF_KEY_30107 = 30107;
  
  public static final int MOON_KEY = 30109;
  
  public static final int HELMET_OF_THE_MOON = 30111;
  
  public static final int NASTY_TOKEN = 30113;
  
  public static final int NASTY_TOKEN_30114 = 30114;
  
  public static final int NASTY_TOKEN_30115 = 30115;
  
  public static final int NASTY_TOKEN_30116 = 30116;
  
  public static final int NASTY_TOKEN_30117 = 30117;
  
  public static final int NASTY_TOKEN_30118 = 30118;
  
  public static final int NASTY_TOKEN_30119 = 30119;
  
  public static final int NASTY_TOKEN_30120 = 30120;
  
  public static final int NASTY_TOKEN_30121 = 30121;
  
  public static final int NASTY_SURPRISE = 30122;
  
  public static final int THE_HUEYCOATL = 30123;
  
  public static final int PRAYER_REGENERATION_POTION4 = 30125;
  
  public static final int PRAYER_REGENERATION_POTION3 = 30128;
  
  public static final int PRAYER_REGENERATION_POTION2 = 30131;
  
  public static final int PRAYER_REGENERATION_POTION1 = 30134;
  
  public static final int GOADING_POTION4 = 30137;
  
  public static final int GOADING_POTION3 = 30140;
  
  public static final int GOADING_POTION2 = 30143;
  
  public static final int GOADING_POTION1 = 30146;
  
  public static final int ALDARIN_TELEPORT = 30149;
  
  public static final int BONE_SQUIRREL = 30151;
  
  public static final int HUBERTE = 30152;
  
  public static final int MOXI = 30154;
  
  public static final int BUTLERS_TRAY_30156 = 30156;
  
  public static final int BUTLERS_TRAY_30157 = 30157;
  
  public static final int SCARECROW_SHIRT = 30232;
  
  public static final int HALLOWEEN_SCARECROW = 30234;
  
  public static final int SCARECROW_30236 = 30236;
  
  public static final int BEIGE_PUMPKIN_DISGUSTED = 30237;
  
  public static final int BEIGE_PUMPKIN_SILLY = 30239;
  
  public static final int BEIGE_PUMPKIN_EVIL = 30241;
  
  public static final int BEIGE_PUMPKIN_ANGRY = 30242;
  
  public static final int BEIGE_PUMPKIN_DEPRESSED = 30243;
  
  public static final int BEIGE_PUMPKIN_SHOCKED = 30244;
  
  public static final int BEIGE_PUMPKIN_SAD = 30245;
  
  public static final int BEIGE_PUMPKIN_HAPPY = 30246;
  
  public static final int BEIGE_PUMPKIN_LAUGHING = 30247;
  
  public static final int WHITE_PUMPKIN_DISGUSTED = 30248;
  
  public static final int WHITE_PUMPKIN_SILLY = 30249;
  
  public static final int WHITE_PUMPKIN_EVIL = 30250;
  
  public static final int WHITE_PUMPKIN_ANGRY = 30251;
  
  public static final int WHITE_PUMPKIN_DEPRESSED = 30252;
  
  public static final int WHITE_PUMPKIN_SHOCKED = 30253;
  
  public static final int WHITE_PUMPKIN_SAD = 30254;
  
  public static final int WHITE_PUMPKIN_HAPPY = 30255;
  
  public static final int WHITE_PUMPKIN_LAUGHING = 30256;
  
  public static final int YELLOW_PUMPKIN_DISGUSTED = 30257;
  
  public static final int YELLOW_PUMPKIN_SILLY = 30258;
  
  public static final int YELLOW_PUMPKIN_EVIL = 30259;
  
  public static final int YELLOW_PUMPKIN_ANGRY = 30260;
  
  public static final int YELLOW_PUMPKIN_DEPRESSED = 30261;
  
  public static final int YELLOW_PUMPKIN_SHOCKED = 30262;
  
  public static final int YELLOW_PUMPKIN_SAD = 30263;
  
  public static final int YELLOW_PUMPKIN_HAPPY = 30264;
  
  public static final int YELLOW_PUMPKIN_LAUGHING = 30265;
  
  public static final int ORANGE_PUMPKIN_DISGUSTED = 30266;
  
  public static final int ORANGE_PUMPKIN_SILLY = 30267;
  
  public static final int ORANGE_PUMPKIN_EVIL = 30268;
  
  public static final int ORANGE_PUMPKIN_ANGRY = 30269;
  
  public static final int ORANGE_PUMPKIN_DEPRESSED = 30270;
  
  public static final int ORANGE_PUMPKIN_SHOCKED = 30271;
  
  public static final int ORANGE_PUMPKIN_SAD = 30272;
  
  public static final int ORANGE_PUMPKIN_HAPPY = 30273;
  
  public static final int ORANGE_PUMPKIN_LAUGHING = 30274;
  
  public static final int RED_PUMPKIN_DISGUSTED = 30275;
  
  public static final int RED_PUMPKIN_SILLY = 30276;
  
  public static final int RED_PUMPKIN_EVIL = 30277;
  
  public static final int RED_PUMPKIN_ANGRY = 30278;
  
  public static final int RED_PUMPKIN_DEPRESSED = 30279;
  
  public static final int RED_PUMPKIN_SHOCKED = 30280;
  
  public static final int RED_PUMPKIN_SAD = 30281;
  
  public static final int RED_PUMPKIN_HAPPY = 30282;
  
  public static final int RED_PUMPKIN_LAUGHING = 30283;
  
  public static final int DARK_GREEN_PUMPKIN_DISGUSTED = 30284;
  
  public static final int DARK_GREEN_PUMPKIN_SILLY = 30285;
  
  public static final int DARK_GREEN_PUMPKIN_EVIL = 30286;
  
  public static final int DARK_GREEN_PUMPKIN_ANGRY = 30287;
  
  public static final int DARK_GREEN_PUMPKIN_DEPRESSED = 30288;
  
  public static final int DARK_GREEN_PUMPKIN_SHOCKED = 30289;
  
  public static final int DARK_GREEN_PUMPKIN_SAD = 30290;
  
  public static final int DARK_GREEN_PUMPKIN_HAPPY = 30291;
  
  public static final int DARK_GREEN_PUMPKIN_LAUGHING = 30292;
  
  public static final int POWDER_GREY_PUMPKIN_DISGUSTED = 30293;
  
  public static final int POWDER_GREY_PUMPKIN_SILLY = 30294;
  
  public static final int POWDER_GREY_PUMPKIN_EVIL = 30295;
  
  public static final int POWDER_GREY_PUMPKIN_ANGRY = 30296;
  
  public static final int POWDER_GREY_PUMPKIN_DEPRESSED = 30297;
  
  public static final int POWDER_GREY_PUMPKIN_SHOCKED = 30298;
  
  public static final int POWDER_GREY_PUMPKIN_SAD = 30299;
  
  public static final int POWDER_GREY_PUMPKIN_HAPPY = 30300;
  
  public static final int POWDER_GREY_PUMPKIN_LAUGHING = 30301;
  
  public static final int TORVA_FULL_HELM_30302 = 30302;
  
  public static final int TORVA_PLATEBODY_30303 = 30303;
  
  public static final int TORVA_PLATELEGS_30304 = 30304;
  
  public static final int ARCLIGHT_INACTIVE = 30305;
  
  public static final int ELIAS_MESSAGE = 30307;
  
  public static final int MASTABA_KEY = 30308;
  
  public static final int MASTABA_KEY_30309 = 30309;
  
  public static final int BASE_PLANS = 30310;
  
  public static final int BASE_KEY = 30311;
  
  public static final int CANOPIC_JAR_OIL = 30312;
  
  public static final int CANOPIC_JAR_OIL_AND_BERRIES = 30313;
  
  public static final int CANOPIC_JAR_FULL = 30314;
  
  public static final int CODE_KEY = 30316;
  
  public static final int DECODER_STRIPS = 30317;
  
  public static final int MAHJARRAT_NOTES_AJ = 30318;
  
  public static final int MAHJARRAT_NOTES_KZ = 30319;
  
  public static final int ARRAVS_AXE = 30320;
  
  public static final int ZOMBIE_HELMET = 30321;
  
  public static final int BROKEN_ZOMBIE_HELMET = 30324;
  
  public static final int DUST = 30328;
  
  public static final int RAGING_ECHOES_RELIC_HUNTER_T1_ARMOUR_SET = 30331;
  
  public static final int RAGING_ECHOES_RELIC_HUNTER_T2_ARMOUR_SET = 30334;
  
  public static final int RAGING_ECHOES_RELIC_HUNTER_T3_ARMOUR_SET = 30337;
  
  public static final int CRYSTAL_DAGGER_PERFECTED = 30340;
  
  public static final int INFERNAL_HARPOON_OR_30342 = 30342;
  
  public static final int INFERNAL_HARPOON_UNCHARGED_30343 = 30343;
  
  public static final int INFERNAL_PICKAXE_OR_30345 = 30345;
  
  public static final int INFERNAL_PICKAXE_UNCHARGED_30346 = 30346;
  
  public static final int INFERNAL_AXE_OR_30347 = 30347;
  
  public static final int INFERNAL_AXE_UNCHARGED_30348 = 30348;
  
  public static final int DRAGON_HARPOON_OR_30349 = 30349;
  
  public static final int DRAGON_PICKAXE_OR_30351 = 30351;
  
  public static final int DRAGON_AXE_OR_30352 = 30352;
  
  public static final int CABBAGE_30353 = 30353;
  
  public static final int CABBAGE_30355 = 30355;
  
  public static final int FORAGERS_POUCH = 30357;
  
  public static final int LEPRECHAUNS_VAULT = 30359;
  
  public static final int BANKERS_BRIEFCASE = 30361;
  
  public static final int CLUE_COMPASS = 30363;
  
  public static final int POCKET_KINGDOM = 30365;
  
  public static final int THE_DOGSWORD = 30367;
  
  public static final int SUNLIGHT_SPEAR = 30369;
  
  public static final int DEVILS_ELEMENT = 30371;
  
  public static final int DRYGORE_BLOWPIPE_EMPTY = 30373;
  
  public static final int DRYGORE_BLOWPIPE = 30374;
  
  public static final int AMULET_OF_THE_MONARCHS = 30376;
  
  public static final int EMPEROR_RING = 30378;
  
  public static final int GLOVES_OF_THE_DAMNED = 30380;
  
  public static final int THOUSANDDRAGON_WARD = 30382;
  
  public static final int CRYSTAL_BLESSING = 30384;
  
  public static final int SUNLIT_BRACERS = 30386;
  
  public static final int THUNDER_KHOPESH = 30388;
  
  public static final int NATURES_REPRISAL = 30390;
  
  public static final int NATURES_REPRISAL_UNCHARGED = 30392;
  
  public static final int ASGARNIA_ECHO_ORB = 30393;
  
  public static final int DESERT_ECHO_ORB = 30394;
  
  public static final int FREMENNIK_ECHO_ORB = 30395;
  
  public static final int KANDARIN_ECHO_ORB = 30396;
  
  public static final int MORYTANIA_ECHO_ORB = 30397;
  
  public static final int TIRANNWN_ECHO_ORB = 30398;
  
  public static final int WILDERNESS_ECHO_ORB = 30399;
  
  public static final int KOUREND_ECHO_ORB = 30400;
  
  public static final int VARLAMORE_ECHO_ORB = 30401;
  
  public static final int RAIDS_MEGARARE_VOUCHER = 30402;
  
  public static final int RAGING_ECHOES_HAT_T1 = 30404;
  
  public static final int RAGING_ECHOES_TOP_T1 = 30406;
  
  public static final int RAGING_ECHOES_ROBESKIRT_T1 = 30408;
  
  public static final int RAGING_ECHOES_BOOTS_T1 = 30410;
  
  public static final int RAGING_ECHOES_HAT_T2 = 30412;
  
  public static final int RAGING_ECHOES_TOP_T2 = 30414;
  
  public static final int RAGING_ECHOES_ROBESKIRT_T2 = 30416;
  
  public static final int RAGING_ECHOES_BOOTS_T2 = 30418;
  
  public static final int RAGING_ECHOES_HAT_T3 = 30420;
  
  public static final int RAGING_ECHOES_TOP_T3 = 30422;
  
  public static final int RAGING_ECHOES_ROBESKIRT_T3 = 30424;
  
  public static final int RAGING_ECHOES_BOOTS_T3 = 30426;
  
  public static final int RAGING_ECHOES_CANE = 30428;
  
  public static final int RAGING_ECHOES_BANNER = 30430;
  
  public static final int ECHO_VENATOR_BOW_ORNAMENT_KIT = 30432;
  
  public static final int ECHO_VENATOR_BOW = 30434;
  
  public static final int ECHO_VENATOR_BOW_UNCHARGED = 30436;
  
  public static final int ECHO_VIRTUS_MASK = 30437;
  
  public static final int ECHO_VIRTUS_ROBE_TOP = 30439;
  
  public static final int ECHO_VIRTUS_ROBE_BOTTOM = 30441;
  
  public static final int ECHO_VIRTUS_ORNAMENT_KIT = 30443;
  
  public static final int ECHO_AHRIMS_HOOD = 30445;
  
  public static final int ECHO_AHRIMS_ROBETOP = 30447;
  
  public static final int ECHO_AHRIMS_ROBESKIRT = 30449;
  
  public static final int ECHO_AHRIMS_ORNAMENT_KIT = 30451;
  
  public static final int ECHO_HOME_TELEPORT_SCROLL = 30453;
  
  public static final int RAGING_ECHOES_DEATH_SCROLL = 30455;
  
  public static final int RAGING_ECHOES_NPC_CONTACT_SCROLL = 30457;
  
  public static final int RAGING_ECHOES_NEXUS_SCROLL = 30459;
  
  public static final int RAGING_ECHOES_PORTAL_SCROLL = 30461;
  
  public static final int RAGING_ECHOES_DRAGON_TROPHY = 30465;
  
  public static final int RAGING_ECHOES_RUNE_TROPHY = 30467;
  
  public static final int RAGING_ECHOES_ADAMANT_TROPHY = 30469;
  
  public static final int RAGING_ECHOES_MITHRIL_TROPHY = 30471;
  
  public static final int RAGING_ECHOES_STEEL_TROPHY = 30473;
  
  public static final int RAGING_ECHOES_IRON_TROPHY = 30475;
  
  public static final int RAGING_ECHOES_BRONZE_TROPHY = 30477;
  
  public static final int PRESENT_BOX_HAT = 30479;
  
  public static final int PRESENT_BOX_HAT_30481 = 30481;
  
  public static final int PRESENT_BOX_HAT_30483 = 30483;
  
  public static final int PRESENT_BOX_HAT_30485 = 30485;
  
  public static final int DOG_DISGUISE = 30487;
  
  public static final int FESTIVE_SCARF = 30489;
  
  public static final int DOG_BOOTS = 30491;
  
  public static final int SPIRIT_TREE_30495 = 30495;
  
  public static final int SPIRIT_TREE_30496 = 30496;
  
  public static final int RAGING_ECHOES_PORTAL_NEXUS = 30497;
  
  public static final int RAGING_ECHOES_PORTAL = 30498;
  
  public static final int SCRYING_POOL_30499 = 30499;
  
  public static final int RAGING_ECHOES_SPIRIT_TREE__FAIRY_RING = 30500;
  
  public static final int RAGING_ECHOES_RUG = 30501;
  
  public static final int RAGING_ECHOES_CURTAINS = 30502;
  
  public static final int ECHO_AHRIMS_HOOD_100 = 30519;
  
  public static final int ECHO_AHRIMS_ROBETOP_100 = 30521;
  
  public static final int ECHO_AHRIMS_ROBESKIRT_100 = 30523;
  
  public static final int ECHO_AHRIMS_HOOD_75 = 30525;
  
  public static final int ECHO_AHRIMS_ROBETOP_75 = 30527;
  
  public static final int ECHO_AHRIMS_ROBESKIRT_75 = 30529;
  
  public static final int ECHO_AHRIMS_HOOD_50 = 30531;
  
  public static final int ECHO_AHRIMS_ROBETOP_50 = 30533;
  
  public static final int ECHO_AHRIMS_ROBESKIRT_50 = 30535;
  
  public static final int ECHO_AHRIMS_HOOD_25 = 30537;
  
  public static final int ECHO_AHRIMS_ROBETOP_25 = 30539;
  
  public static final int ECHO_AHRIMS_ROBESKIRT_25 = 30541;
  
  public static final int ECHO_AHRIMS_HOOD_0 = 30543;
  
  public static final int ECHO_AHRIMS_ROBETOP_0 = 30545;
  
  public static final int ECHO_AHRIMS_ROBESKIRT_0 = 30547;
  
  public static final int RAGING_ECHOES_RUG_30554 = 30554;
  
  public static final int RAGING_ECHOES_CURTAINS_30557 = 30557;
  
  public static final int RAGING_ECHOES_SCRYING_POOL_SCROLL = 30560;
  
  public static final int RAGING_ECHOES_SPIRIT_TREE_SCROLL = 30563;
  
  public static final int RAGING_ECHOES_SPIRIT_TREE = 30567;
  
  public static final int ECHO_AHRIMS_STAFF = 30568;
  
  public static final int ECHO_AHRIMS_STAFF_100 = 30570;
  
  public static final int ECHO_AHRIMS_STAFF_75 = 30571;
  
  public static final int ECHO_AHRIMS_STAFF_50 = 30572;
  
  public static final int ECHO_AHRIMS_STAFF_25 = 30573;
  
  public static final int ECHO_AHRIMS_STAFF_0 = 30574;
  
  public static final int BOUNTY_SUPPLY_CRATE = 30576;
  
  public static final int COLLECTION_LOG_30579 = 30579;
  
  public static final int COLLECTION_LOG_30581 = 30581;
  
  public static final int COLLECTION_LOG_30583 = 30583;
  
  public static final int COLLECTION_LOG_30585 = 30585;
  
  public static final int COLLECTION_LOG_30587 = 30587;
  
  public static final int COLLECTION_LOG_30589 = 30589;
  
  public static final int COLLECTION_LOG_30591 = 30591;
  
  public static final int COLLECTION_LOG_30593 = 30593;
  
  public static final int COLLECTION_LOG_30595 = 30595;
  
  public static final int BRONZE_STAFF_OF_COLLECTION = 30597;
  
  public static final int IRON_STAFF_OF_COLLECTION = 30599;
  
  public static final int STEEL_STAFF_OF_COLLECTION = 30601;
  
  public static final int BLACK_STAFF_OF_COLLECTION = 30603;
  
  public static final int MITHRIL_STAFF_OF_COLLECTION = 30605;
  
  public static final int ADAMANT_STAFF_OF_COLLECTION = 30607;
  
  public static final int RUNE_STAFF_OF_COLLECTION = 30609;
  
  public static final int DRAGON_STAFF_OF_COLLECTION = 30611;
  
  public static final int GILDED_STAFF_OF_COLLECTION = 30613;
  
  public static final int BOUNTY_SUPPLY_CRATE_MANTA_RAY = 30616;
  
  public static final int BOUNTY_SUPPLY_CRATE_ANGLERFISH = 30619;
  
  public static final int BRAN = 30622;
  
  public static final int RIC = 30624;
  
  public static final int DEADEYE_PRAYER_SCROLL = 30626;
  
  public static final int MYSTIC_VIGOUR_PRAYER_SCROLL = 30627;
  
  public static final int ICE_ELEMENT_STAFF_CROWN = 30628;
  
  public static final int FIRE_ELEMENT_STAFF_CROWN = 30631;
  
  public static final int TWINFLAME_STAFF = 30634;
  
  public static final int GIANTSOUL_AMULET_UNCHARGED = 30637;
  
  public static final int GIANTSOUL_AMULET = 30638;
  
  public static final int DESICCATED_PAGE = 30640;
  
  public static final int HUNTERS_LOOT_SACK_SUPPLIES = 30644;
  
  public static final int CLASSIC_IMP_TAIL = 30646;
  
  public static final int CLASSIC_IMP_HOOD = 30648;
  
  public static final int TEAK_DISPLAY = 30650;
  
  public static final int MAHOGANY_DISPLAY = 30651;
  
  public static final int MAHOGANY_DISPLAY_30652 = 30652;
  
  public static final int GILDED_DISPLAY = 30653;
  
  public static final int GILDED_DISPLAY_30654 = 30654;
  
  public static final int CRAWLING_HAND_30655 = 30655;
  
  public static final int CRAWLING_HAND_30656 = 30656;
  
  public static final int COCKATRICE_HEAD_30657 = 30657;
  
  public static final int COCKATRICE_HEAD_30658 = 30658;
  
  public static final int BASILISK_HEAD_30659 = 30659;
  
  public static final int BASILISK_HEAD_30660 = 30660;
  
  public static final int KURASK_HEAD_30661 = 30661;
  
  public static final int ABYSSAL_HEAD_30662 = 30662;
  
  public static final int OAK_DISPLAY = 30663;
  
  public static final int TEAK_DISPLAY_30664 = 30664;
  
  public static final int TEAK_DISPLAY_30665 = 30665;
  
  public static final int MAHOGANY_DISPLAY_30666 = 30666;
  
  public static final int MAHOGANY_DISPLAY_30667 = 30667;
  
  public static final int MOUNTED_BASS_30668 = 30668;
  
  public static final int MOUNTED_BASS_30669 = 30669;
  
  public static final int MOUNTED_SWORDFISH_30670 = 30670;
  
  public static final int MOUNTED_HARPOONFISH_30671 = 30671;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\item\ItemID.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */