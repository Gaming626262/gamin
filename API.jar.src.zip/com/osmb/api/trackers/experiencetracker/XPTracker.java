/*     */ package com.osmb.api.trackers.experiencetracker;
/*     */ 
/*     */ import com.osmb.api.ScriptCore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ public class XPTracker
/*     */ {
/*     */   private double xp;
/*     */   private final int startXp;
/*     */   
/*     */   public XPTracker(ScriptCore scriptCoreService, int currentXp) {
/*  13 */     this.xp = currentXp;
/*  14 */     this.startXp = currentXp;
/*     */   }
/*     */   
/*     */   public double getXp() {
/*  18 */     return this.xp;
/*     */   }
/*     */   
/*     */   public void setXp(int xp) {
/*  22 */     this.xp = xp;
/*     */   }
/*     */   
/*     */   public void incrementXp(double exp) {
/*  26 */     this.xp += exp;
/*     */   }
/*     */   
/*     */   public double getXpGained() {
/*  30 */     return this.xp - this.startXp;
/*     */   }
/*     */   
/*     */   public int getXpPerHour(long startTime) {
/*  34 */     return (int)(getXpGained() * 3600000.0D / (System.currentTimeMillis() - startTime));
/*     */   }
/*     */   
/*     */   public double getXpForNextLevel() {
/*  38 */     int currentLevel = getLevelForXp(this.xp);
/*  39 */     int xpForNextLevel = getExperienceForLevel(currentLevel + 1);
/*  40 */     return xpForNextLevel - this.xp;
/*     */   }
/*     */   
/*     */   public int getLevelProgressPercentage() {
/*  44 */     int currentLevel = getLevelForXp(this.xp);
/*  45 */     float startXpForCurrentLevel = getExperienceForLevel(currentLevel);
/*  46 */     float startXpForNextLevel = getExperienceForLevel(currentLevel + 1);
/*  47 */     return (int)((this.xp - startXpForCurrentLevel) / (startXpForNextLevel - startXpForCurrentLevel) * 100.0D);
/*     */   }
/*     */   
/*     */   public int getLevel() {
/*  51 */     return getLevelForXp(this.xp);
/*     */   }
/*     */   
/*     */   public int getLevelForXp(double exp) {
/*  55 */     double points = 0.0D;
/*  56 */     double output = 0.0D;
/*  57 */     for (int lvl = 1; lvl <= 150; lvl++) {
/*  58 */       points += Math.floor(lvl + 300.0D * Math.pow(2.0D, lvl / 7.0D));
/*  59 */       if (lvl >= 1) {
/*  60 */         if (output > exp) {
/*  61 */           lvl--;
/*  62 */           if (lvl == 0)
/*  63 */             return 1; 
/*  64 */           if (lvl > 99) {
/*  65 */             return 99;
/*     */           }
/*  67 */           return lvl;
/*     */         } 
/*     */         
/*  70 */         output = Math.floor(points / 4.0D);
/*     */       } 
/*     */     } 
/*     */     
/*  74 */     return 0;
/*     */   }
/*     */   
/*     */   public long timeToNextLevelMillis(double xpPH) {
/*  78 */     if (xpPH > 0.0D) {
/*  79 */       long timeTNL = (long)(getXpForNextLevel() / xpPH * 3600000.0D);
/*  80 */       return timeTNL;
/*     */     } 
/*  82 */     return 0L;
/*     */   }
/*     */   
/*     */   public String timeToNextLevelString(double xpPH) {
/*  86 */     if (xpPH > 0.0D) {
/*  87 */       long timeTNL = (long)(getXpForNextLevel() / xpPH * 3600000.0D);
/*  88 */       return String.format("%02d:%02d:%02d", new Object[] { Long.valueOf(TimeUnit.MILLISECONDS.toHours(timeTNL)), 
/*  89 */             Long.valueOf(TimeUnit.MILLISECONDS.toMinutes(timeTNL) - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(timeTNL))), 
/*  90 */             Long.valueOf(TimeUnit.MILLISECONDS.toSeconds(timeTNL) - TimeUnit.MINUTES
/*  91 */               .toSeconds(TimeUnit.MILLISECONDS.toMinutes(timeTNL))) });
/*     */     } 
/*  93 */     return "--:--:--";
/*     */   }
/*     */   
/*     */   public int getExperienceForLevel(int level) {
/*  97 */     int total = 0;
/*  98 */     for (int i = 1; i < level; i++) {
/*  99 */       total = (int)(total + i + 300.0D * Math.pow(2.0D, i / 7.0D));
/*     */     }
/* 101 */     return (int)(total * 2.5D) / 10;
/*     */   }
/*     */   
/*     */   public int getStartXp() {
/* 105 */     return this.startXp;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\trackers\experiencetracker\XPTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */