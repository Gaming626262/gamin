/*    */ package com.osmb.api.trackers.experiencetracker;
/*    */ 
/*    */ public enum Skill
/*    */ {
/*  5 */   ATTACK("attack"),
/*  6 */   STRENGTH("strength"),
/*  7 */   DEFENCE("defence"),
/*  8 */   RANGE("range"),
/*  9 */   PRAYER("prayer"),
/* 10 */   MAGIC("magic"),
/* 11 */   RUNECRAFTING("runecrafting"),
/* 12 */   CONSTRUCTION("construction"),
/*    */   
/* 14 */   HITPOINTS("hitpoints"),
/* 15 */   AGILITY("agility"),
/* 16 */   HERBLORE("herblore"),
/* 17 */   THIEVING("thieving"),
/* 18 */   CRAFTING("crafting"),
/* 19 */   FLETCHING("fletching"),
/* 20 */   SLAYER("slayer"),
/* 21 */   HUNTER("hunter"),
/*    */   
/* 23 */   MINING("mining"),
/* 24 */   SMITHING("smithing"),
/* 25 */   FISHING("fishing"),
/* 26 */   COOKING("cooking"),
/* 27 */   FIREMAKING("firemaking"),
/* 28 */   WOODCUTTING("woodcutting"),
/* 29 */   FARMING("farming");
/*    */   
/*    */   private final String imageName;
/*    */   
/*    */   Skill(String imageName) {
/* 34 */     this.imageName = imageName;
/*    */   }
/*    */   
/*    */   public String getImageName() {
/* 38 */     return this.imageName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\trackers\experiencetracker\Skill.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */