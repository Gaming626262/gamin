/*    */ package com.osmb.api.trackers.itemlistener;
/*    */ 
/*    */ import com.osmb.api.item.ItemGroup;
/*    */ 
/*    */ public class TrackedItem {
/*    */   private final int itemId;
/*    */   private int previousAmount;
/*    */   private int amount;
/*    */   private final ItemGroup widget;
/*    */   
/*    */   public TrackedItem(int itemId, ItemGroup widget) {
/* 12 */     this.itemId = itemId;
/* 13 */     this.amount = 0;
/* 14 */     this.previousAmount = -1;
/* 15 */     this.widget = widget;
/*    */   }
/*    */   
/*    */   public int getItemId() {
/* 19 */     return this.itemId;
/*    */   }
/*    */   
/*    */   public int getPreviousAmount() {
/* 23 */     return this.previousAmount;
/*    */   }
/*    */   
/*    */   public void setPreviousAmount(int previousAmount) {
/* 27 */     this.previousAmount = previousAmount;
/*    */   }
/*    */   
/*    */   public int getAmount() {
/* 31 */     return this.amount;
/*    */   }
/*    */   
/*    */   public void setAmount(int amount) {
/* 35 */     this.amount = amount;
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemGroup getWidget() {
/* 40 */     return this.widget;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\trackers\itemlistener\TrackedItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */