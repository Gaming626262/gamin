/*    */ package com.osmb.api.trackers.itemlistener;
/*    */ 
/*    */ import com.osmb.api.ScriptCore;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ItemTracker
/*    */ {
/*  9 */   private final List<TrackedItem> trackedItems = new ArrayList<>();
/*    */   private final ScriptCore scriptCoreService;
/*    */   
/*    */   public ItemTracker(ScriptCore scriptCoreService) {
/* 13 */     this.scriptCoreService = scriptCoreService;
/*    */   }
/*    */   
/*    */   public void add(TrackedItem trackedItem) {
/* 17 */     this.trackedItems.add(trackedItem);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void listenForTrackedItems() {}
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\trackers\itemlistener\ItemTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */