package com.osmb.api.trackers.itemlistener;

import com.osmb.api.item.ItemGroup;
import java.util.Map;

public interface ItemListener {
  @Deprecated
  void ItemIncremented(Map<Integer, Integer> paramMap);
  
  @Deprecated
  void ItemDecremented(Map<Integer, Integer> paramMap);
  
  @Deprecated
  void ItemsToListen(Map<Integer, ItemGroup> paramMap);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\trackers\itemlistener\ItemListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */