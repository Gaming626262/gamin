package com.osmb.api;

import com.osmb.api.input.Finger;
import com.osmb.api.input.Keyboard;
import com.osmb.api.item.ItemManager;
import com.osmb.api.location.position.types.LocalPosition;
import com.osmb.api.location.position.types.WorldPosition;
import com.osmb.api.scene.ObjectManager;
import com.osmb.api.scene.SceneManager;
import com.osmb.api.screen.Screen;
import com.osmb.api.ui.GameState;
import com.osmb.api.ui.SpriteManager;
import com.osmb.api.ui.WidgetManager;
import com.osmb.api.utils.AppManager;
import com.osmb.api.utils.StageController;
import com.osmb.api.utils.Utils;
import com.osmb.api.visual.ImageAnalyzer;
import com.osmb.api.visual.PixelAnalyzer;
import com.osmb.api.visual.drawing.Canvas;
import com.osmb.api.visual.drawing.SceneProjector;
import com.osmb.api.visual.ocr.OCR;
import com.osmb.api.walker.Walker;
import java.util.function.BooleanSupplier;

public interface ScriptCore {
  AppManager getAppManager();
  
  WidgetManager getWidgetManager();
  
  Finger getFinger();
  
  Keyboard getKeyboard();
  
  Screen getScreen();
  
  WorldPosition getWorldPosition();
  
  LocalPosition getLocalPosition();
  
  SceneManager getSceneManager();
  
  ImageAnalyzer getImageAnalyzer();
  
  PixelAnalyzer getPixelAnalyzer();
  
  SceneProjector getSceneProjector();
  
  SpriteManager getSpriteManager();
  
  void log(Class paramClass, String paramString);
  
  ObjectManager getObjectManager();
  
  ItemManager getItemManager();
  
  Walker getWalker();
  
  Utils getUtils();
  
  int random(long paramLong1, long paramLong2);
  
  OCR getOCR();
  
  StageController getStageController();
  
  void log(String paramString);
  
  void log(String paramString1, String paramString2);
  
  boolean submitTask(BooleanSupplier paramBooleanSupplier, int paramInt);
  
  boolean submitTask(BooleanSupplier paramBooleanSupplier, int paramInt, boolean paramBoolean);
  
  boolean submitHumanTask(BooleanSupplier paramBooleanSupplier, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  boolean submitHumanTask(BooleanSupplier paramBooleanSupplier, int paramInt);
  
  boolean submitTask(BooleanSupplier paramBooleanSupplier, int paramInt, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean isDueToBreak();
  
  boolean isDueToHop();
  
  boolean isDueToAFK();
  
  void sleep(long paramLong);
  
  int random(int paramInt);
  
  int random(int paramInt1, int paramInt2);
  
  boolean submitTask(BooleanSupplier paramBooleanSupplier, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  void sleep(int paramInt);
  
  void stop();
  
  boolean stopped();
  
  void setPause(boolean paramBoolean);
  
  boolean paused();
  
  default void onGameStateChanged(GameState newGameState) {}
  
  default void onPaint(Canvas c) {}
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\osmb\api\ScriptCore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */