/*    */ package com.sun.javafx.beans.event;
/*    */ 
/*    */ import javafx.beans.InvalidationListener;
/*    */ import javafx.beans.WeakInvalidationListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractNotifyListener
/*    */   implements InvalidationListener
/*    */ {
/* 61 */   private final WeakInvalidationListener weakListener = new WeakInvalidationListener(this);
/*    */   
/*    */   public InvalidationListener getWeakListener() {
/* 64 */     return (InvalidationListener)this.weakListener;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\beans\event\AbstractNotifyListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */