/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DFontDecoder
/*     */   extends FontFileWriter
/*     */ {
/*     */   static {
/*  37 */     Void void_ = AccessController.<Void>doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_font");
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decode(String paramString) throws IOException {
/*  53 */     if (paramString == null) {
/*  54 */       throw new IOException("Invalid font name");
/*     */     }
/*  56 */     long l = 0L;
/*     */     try {
/*  58 */       l = createCTFont(paramString);
/*  59 */       if (l == 0L) {
/*  60 */         throw new IOException("Failure creating CTFont");
/*     */       }
/*  62 */       int i = getCTFontFormat(l);
/*  63 */       if (i != 1953658213 && i != 65536 && i != 1330926671) {
/*  64 */         throw new IOException("Unsupported Dfont");
/*     */       }
/*  66 */       int[] arrayOfInt = getCTFontTags(l);
/*  67 */       short s = (short)arrayOfInt.length;
/*  68 */       int j = 12 + 16 * s;
/*  69 */       byte[][] arrayOfByte = new byte[s][]; int k;
/*  70 */       for (k = 0; k < arrayOfInt.length; k++) {
/*  71 */         int m = arrayOfInt[k];
/*  72 */         arrayOfByte[k] = getCTFontTable(l, m);
/*  73 */         int n = (arrayOfByte[k]).length;
/*  74 */         j += n + 3 & 0xFFFFFFFC;
/*     */       } 
/*  76 */       releaseCTFont(l);
/*  77 */       l = 0L;
/*     */ 
/*     */       
/*  80 */       setLength(j);
/*  81 */       writeHeader(i, s);
/*     */       
/*  83 */       k = 12 + 16 * s;
/*  84 */       for (byte b = 0; b < s; b++) {
/*  85 */         int m = arrayOfInt[b];
/*  86 */         byte[] arrayOfByte1 = arrayOfByte[b];
/*     */ 
/*     */         
/*  89 */         writeDirectoryEntry(b, m, 0, k, arrayOfByte1.length);
/*     */ 
/*     */         
/*  92 */         seek(k);
/*  93 */         writeBytes(arrayOfByte1);
/*     */         
/*  95 */         k += arrayOfByte1.length + 3 & 0xFFFFFFFC;
/*     */       } 
/*     */     } finally {
/*     */       
/*  99 */       if (l != 0L)
/* 100 */         releaseCTFont(l); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native byte[] getCTFontTable(long paramLong, int paramInt);
/*     */   
/*     */   private static native int[] getCTFontTags(long paramLong);
/*     */   
/*     */   private static native int getCTFontFormat(long paramLong);
/*     */   
/*     */   private static native void releaseCTFont(long paramLong);
/*     */   
/*     */   private static native long createCTFont(String paramString);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\DFontDecoder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */