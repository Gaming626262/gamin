package com.sun.javafx.font;

import java.io.InputStream;

public interface FontFactory {
  public static final String DEFAULT_FULLNAME = "System Regular";
  
  PGFont createFont(String paramString, float paramFloat);
  
  PGFont createFont(String paramString, boolean paramBoolean1, boolean paramBoolean2, float paramFloat);
  
  PGFont deriveFont(PGFont paramPGFont, boolean paramBoolean1, boolean paramBoolean2, float paramFloat);
  
  String[] getFontFamilyNames();
  
  String[] getFontFullNames();
  
  String[] getFontFullNames(String paramString);
  
  boolean hasPermission();
  
  PGFont[] loadEmbeddedFont(String paramString, InputStream paramInputStream, float paramFloat, boolean paramBoolean1, boolean paramBoolean2);
  
  PGFont[] loadEmbeddedFont(String paramString1, String paramString2, float paramFloat, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean isPlatformFont(String paramString);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\FontFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */