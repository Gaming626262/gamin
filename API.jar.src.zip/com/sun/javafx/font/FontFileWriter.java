/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontFileWriter
/*     */   implements FontConstants
/*     */ {
/*     */   byte[] header;
/*     */   int pos;
/*     */   int headerPos;
/*     */   int writtenBytes;
/*     */   FontTracker tracker;
/*     */   File file;
/*     */   RandomAccessFile raFile;
/*     */   
/*     */   public FontFileWriter() {
/*  56 */     if (!hasTempPermission()) {
/*  57 */       this.tracker = FontTracker.getTracker();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void setLength(int paramInt) throws IOException {
/*  62 */     if (this.raFile == null) {
/*  63 */       throw new IOException("File not open");
/*     */     }
/*  65 */     checkTracker(paramInt);
/*  66 */     this.raFile.setLength(paramInt);
/*     */   }
/*     */   
/*     */   public void seek(int paramInt) throws IOException {
/*  70 */     if (this.raFile == null) {
/*  71 */       throw new IOException("File not open");
/*     */     }
/*  73 */     if (paramInt != this.pos) {
/*  74 */       this.raFile.seek(paramInt);
/*  75 */       this.pos = paramInt;
/*     */     } 
/*     */   }
/*     */   
/*     */   public File getFile() {
/*  80 */     return this.file;
/*     */   }
/*     */ 
/*     */   
/*     */   public File openFile() throws PrivilegedActionException {
/*  85 */     this.pos = 0;
/*  86 */     this.writtenBytes = 0;
/*  87 */     this.file = AccessController.<File>doPrivileged(() -> {
/*     */           
/*     */           try {
/*     */             return Files.createTempFile("+JXF", ".tmp", (FileAttribute<?>[])new FileAttribute[0]).toFile();
/*  91 */           } catch (IOException iOException) {
/*     */             throw new IOException("Unable to create temporary file");
/*     */           } 
/*     */         });
/*     */ 
/*     */     
/*  97 */     if (this.tracker != null) {
/*  98 */       this.tracker.add(this.file);
/*     */     }
/* 100 */     this.raFile = AccessController.<RandomAccessFile>doPrivileged(() -> new RandomAccessFile(this.file, "rw"));
/*     */ 
/*     */     
/* 103 */     if (this.tracker != null) {
/* 104 */       this.tracker.set(this.file, this.raFile);
/*     */     }
/* 106 */     if (PrismFontFactory.debugFonts) {
/* 107 */       System.err.println("Temp file created: " + this.file.getPath());
/*     */     }
/* 109 */     return this.file;
/*     */   }
/*     */   
/*     */   public void closeFile() throws IOException {
/* 113 */     if (this.header != null) {
/* 114 */       this.raFile.seek(0L);
/* 115 */       this.raFile.write(this.header);
/* 116 */       this.header = null;
/*     */     } 
/* 118 */     if (this.raFile != null) {
/* 119 */       this.raFile.close();
/* 120 */       this.raFile = null;
/*     */     } 
/* 122 */     if (this.tracker != null) {
/* 123 */       this.tracker.remove(this.file);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteFile() {
/* 129 */     if (this.file != null) {
/* 130 */       if (this.tracker != null) {
/* 131 */         this.tracker.subBytes(this.writtenBytes);
/*     */       }
/*     */       try {
/* 134 */         closeFile();
/* 135 */       } catch (Exception exception) {}
/*     */       
/*     */       try {
/* 138 */         AccessController.doPrivileged(() -> {
/*     */               this.file.delete();
/*     */               
/*     */               return null;
/*     */             });
/*     */         
/* 144 */         if (PrismFontFactory.debugFonts) {
/* 145 */           System.err.println("Temp file delete: " + this.file.getPath());
/*     */         }
/* 147 */       } catch (Exception exception) {}
/*     */       
/* 149 */       this.file = null;
/* 150 */       this.raFile = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isTracking() {
/* 155 */     return (this.tracker != null);
/*     */   }
/*     */   
/*     */   private void checkTracker(int paramInt) throws IOException {
/* 159 */     if (this.tracker != null) {
/* 160 */       if (paramInt < 0 || this.pos > 33554432 - paramInt) {
/* 161 */         throw new IOException("File too big.");
/*     */       }
/* 163 */       if (this.tracker.getNumBytes() > 335544320 - paramInt) {
/* 164 */         throw new IOException("Total files too big.");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkSize(int paramInt) throws IOException {
/* 170 */     if (this.tracker != null) {
/* 171 */       checkTracker(paramInt);
/* 172 */       this.tracker.addBytes(paramInt);
/* 173 */       this.writtenBytes += paramInt;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setHeaderPos(int paramInt) {
/* 178 */     this.headerPos = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeader(int paramInt, short paramShort) throws IOException {
/* 185 */     int i = 12 + 16 * paramShort;
/* 186 */     checkSize(i);
/* 187 */     this.header = new byte[i];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     short s1 = paramShort;
/* 195 */     s1 = (short)(s1 | s1 >> 1);
/* 196 */     s1 = (short)(s1 | s1 >> 2);
/* 197 */     s1 = (short)(s1 | s1 >> 4);
/* 198 */     s1 = (short)(s1 | s1 >> 8);
/*     */ 
/*     */     
/* 201 */     s1 = (short)(s1 & (s1 >> 1 ^ 0xFFFFFFFF));
/* 202 */     short s2 = (short)(s1 * 16);
/* 203 */     short s3 = 0;
/* 204 */     while (s1 > 1) {
/* 205 */       s3 = (short)(s3 + 1);
/* 206 */       s1 = (short)(s1 >> 1);
/*     */     } 
/* 208 */     short s4 = (short)(paramShort * 16 - s2);
/*     */     
/* 210 */     setHeaderPos(0);
/* 211 */     writeInt(paramInt);
/* 212 */     writeShort(paramShort);
/* 213 */     writeShort(s2);
/* 214 */     writeShort(s3);
/* 215 */     writeShort(s4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDirectoryEntry(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws IOException {
/* 221 */     setHeaderPos(12 + 16 * paramInt1);
/* 222 */     writeInt(paramInt2);
/* 223 */     writeInt(paramInt3);
/* 224 */     writeInt(paramInt4);
/* 225 */     writeInt(paramInt5);
/*     */   }
/*     */   
/*     */   private void writeInt(int paramInt) throws IOException {
/* 229 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF000000) >> 24);
/* 230 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF0000) >> 16);
/* 231 */     this.header[this.headerPos++] = (byte)((paramInt & 0xFF00) >> 8);
/* 232 */     this.header[this.headerPos++] = (byte)(paramInt & 0xFF);
/*     */   }
/*     */   
/*     */   private void writeShort(short paramShort) throws IOException {
/* 236 */     this.header[this.headerPos++] = (byte)((paramShort & 0xFF00) >> 8);
/* 237 */     this.header[this.headerPos++] = (byte)(paramShort & 0xFF);
/*     */   }
/*     */   
/*     */   public void writeBytes(byte[] paramArrayOfbyte) throws IOException {
/* 241 */     writeBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 247 */     checkSize(paramInt2);
/* 248 */     this.raFile.write(paramArrayOfbyte, paramInt1, paramInt2);
/* 249 */     this.pos += paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasTempPermission() {
/* 259 */     if (System.getSecurityManager() == null) {
/* 260 */       return true;
/*     */     }
/* 262 */     File file = null;
/* 263 */     boolean bool = false;
/*     */     try {
/* 265 */       file = Files.createTempFile("+JXF", ".tmp", (FileAttribute<?>[])new FileAttribute[0]).toFile();
/* 266 */       file.delete();
/* 267 */       file = null;
/* 268 */       bool = true;
/* 269 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/* 272 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   static class FontTracker
/*     */   {
/*     */     public static final int MAX_FILE_SIZE = 33554432;
/*     */     
/*     */     public static final int MAX_TOTAL_BYTES = 335544320;
/*     */     
/*     */     static int numBytes;
/*     */     
/*     */     static FontTracker tracker;
/*     */     
/*     */     public static synchronized FontTracker getTracker() {
/* 287 */       if (tracker == null) {
/* 288 */         tracker = new FontTracker();
/*     */       }
/* 290 */       return tracker;
/*     */     }
/*     */     
/*     */     public synchronized int getNumBytes() {
/* 294 */       return numBytes;
/*     */     }
/*     */     
/*     */     public synchronized void addBytes(int param1Int) {
/* 298 */       numBytes += param1Int;
/*     */     }
/*     */     
/*     */     public synchronized void subBytes(int param1Int) {
/* 302 */       numBytes -= param1Int;
/*     */     }
/*     */     
/* 305 */     private static Semaphore cs = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static synchronized Semaphore getCS() {
/* 311 */       if (cs == null)
/*     */       {
/*     */         
/* 314 */         cs = new Semaphore(5, true);
/*     */       }
/* 316 */       return cs;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean acquirePermit() throws InterruptedException {
/* 321 */       return getCS().tryAcquire(120L, TimeUnit.SECONDS);
/*     */     }
/*     */     
/*     */     public void releasePermit() {
/* 325 */       getCS().release();
/*     */     }
/*     */     
/*     */     public void add(File param1File) {
/* 329 */       TempFileDeletionHook.add(param1File);
/*     */     }
/*     */     
/*     */     public void set(File param1File, RandomAccessFile param1RandomAccessFile) {
/* 333 */       TempFileDeletionHook.set(param1File, param1RandomAccessFile);
/*     */     }
/*     */     
/*     */     public void remove(File param1File) {
/* 337 */       TempFileDeletionHook.remove(param1File);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static class TempFileDeletionHook
/*     */     {
/* 344 */       private static HashMap<File, RandomAccessFile> files = new HashMap<>();
/*     */ 
/*     */       
/* 347 */       private static Thread t = null;
/*     */       
/*     */       static void init() {
/* 350 */         if (t == null)
/*     */         {
/* 352 */           AccessController.doPrivileged(() -> {
/*     */                 t = new Thread(());
/*     */                 Runtime.getRuntime().addShutdownHook(t);
/*     */                 return null;
/*     */               });
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       static synchronized void add(File param2File) {
/* 367 */         init();
/* 368 */         files.put(param2File, null);
/*     */       }
/*     */       
/*     */       static synchronized void set(File param2File, RandomAccessFile param2RandomAccessFile) {
/* 372 */         files.put(param2File, param2RandomAccessFile);
/*     */       }
/*     */       
/*     */       static synchronized void remove(File param2File) {
/* 376 */         files.remove(param2File);
/*     */       }
/*     */       
/*     */       static synchronized void runHooks() {
/* 380 */         if (files.isEmpty()) {
/*     */           return;
/*     */         }
/*     */         
/* 384 */         for (Map.Entry<File, RandomAccessFile> entry : files.entrySet())
/*     */         
/*     */         { 
/*     */           try {
/* 388 */             if (entry.getValue() != null) {
/* 389 */               ((RandomAccessFile)entry.getValue()).close();
/*     */             }
/* 391 */           } catch (Exception exception) {}
/* 392 */           ((File)entry.getKey()).delete(); }  } } } private static class TempFileDeletionHook { static synchronized void runHooks() { if (files.isEmpty()) return;  for (Map.Entry<File, RandomAccessFile> entry : files.entrySet()) { try { if (entry.getValue() != null) ((RandomAccessFile)entry.getValue()).close();  } catch (Exception exception) {} ((File)entry.getKey()).delete(); }
/*     */        }
/*     */ 
/*     */     
/*     */     private static HashMap<File, RandomAccessFile> files = new HashMap<>();
/*     */     private static Thread t = null;
/*     */     
/*     */     static void init() {
/*     */       if (t == null)
/*     */         AccessController.doPrivileged(() -> {
/*     */               t = new Thread(());
/*     */               Runtime.getRuntime().addShutdownHook(t);
/*     */               return null;
/*     */             }); 
/*     */     }
/*     */     
/*     */     static synchronized void add(File param1File) {
/*     */       init();
/*     */       files.put(param1File, null);
/*     */     }
/*     */     
/*     */     static synchronized void set(File param1File, RandomAccessFile param1RandomAccessFile) {
/*     */       files.put(param1File, param1RandomAccessFile);
/*     */     }
/*     */     
/*     */     static synchronized void remove(File param1File) {
/*     */       files.remove(param1File);
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\FontFileWriter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */