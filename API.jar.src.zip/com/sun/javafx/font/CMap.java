/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CMap
/*     */ {
/*     */   static final char noSuchChar = '�';
/*     */   static final int SHORTMASK = 65535;
/*     */   static final int INTMASK = -1;
/*     */   private static final int MAX_CODE_POINTS = 1114111;
/*     */   
/*     */   static CMap initialize(PrismFontFile paramPrismFontFile) {
/*  52 */     CMap cMap = null;
/*     */     
/*  54 */     short s = -1;
/*     */     
/*  56 */     int i = 0, j = 0, k = 0, m = 0;
/*  57 */     boolean bool1 = false, bool2 = false;
/*     */     
/*  59 */     FontFileReader.Buffer buffer = paramPrismFontFile.readTable(1668112752);
/*  60 */     short s1 = buffer.getShort(2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     for (byte b = 0; b < s1; b++) {
/*  72 */       buffer.position(b * 8 + 4);
/*  73 */       short s2 = buffer.getShort();
/*     */       
/*  75 */       if (s2 == 0) {
/*  76 */         bool1 = true;
/*  77 */         s = buffer.getShort();
/*  78 */         m = buffer.getInt();
/*     */       }
/*  80 */       else if (s2 == 3) {
/*  81 */         bool2 = true;
/*  82 */         s = buffer.getShort();
/*  83 */         int n = buffer.getInt();
/*  84 */         switch (s) { case 0:
/*  85 */             i = n; break;
/*  86 */           case 1: j = n; break;
/*  87 */           case 10: k = n;
/*     */             break; }
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/*  93 */     if (bool2) {
/*  94 */       if (k != 0) {
/*  95 */         cMap = createCMap(buffer, k);
/*     */       }
/*  97 */       else if (i != 0) {
/*  98 */         cMap = createCMap(buffer, i);
/*     */       }
/* 100 */       else if (j != 0) {
/* 101 */         cMap = createCMap(buffer, j);
/*     */       } 
/* 103 */     } else if (bool1 && m != 0) {
/* 104 */       cMap = createCMap(buffer, m);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       cMap = createCMap(buffer, buffer.getInt(8));
/*     */     } 
/* 119 */     return cMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static CMap createCMap(FontFileReader.Buffer paramBuffer, int paramInt) {
/* 126 */     char c = paramBuffer.getChar(paramInt);
/*     */     
/* 128 */     switch (c) { case '\000':
/* 129 */         return new CMapFormat0(paramBuffer, paramInt);
/* 130 */       case '\002': return new CMapFormat2(paramBuffer, paramInt);
/* 131 */       case '\004': return new CMapFormat4(paramBuffer, paramInt);
/* 132 */       case '\006': return new CMapFormat6(paramBuffer, paramInt);
/* 133 */       case '\b': return new CMapFormat8(paramBuffer, paramInt);
/* 134 */       case '\n': return new CMapFormat10(paramBuffer, paramInt);
/* 135 */       case '\f': return new CMapFormat12(paramBuffer, paramInt); }
/* 136 */      throw new RuntimeException("Cmap format unimplemented: " + paramBuffer
/* 137 */         .getChar(paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CMapFormat4
/*     */     extends CMap
/*     */   {
/*     */     int segCount;
/*     */ 
/*     */     
/*     */     int entrySelector;
/*     */ 
/*     */     
/*     */     int rangeShift;
/*     */ 
/*     */     
/*     */     char[] endCount;
/*     */ 
/*     */     
/*     */     char[] startCount;
/*     */ 
/*     */     
/*     */     short[] idDelta;
/*     */ 
/*     */     
/*     */     char[] idRangeOffset;
/*     */ 
/*     */     
/*     */     char[] glyphIds;
/*     */ 
/*     */     
/*     */     CMapFormat4(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 170 */       param1Buffer.position(param1Int);
/* 171 */       param1Buffer.getChar();
/* 172 */       int i = param1Buffer.getChar();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 181 */       if (param1Int + i > param1Buffer.capacity()) {
/* 182 */         i = param1Buffer.capacity() - param1Int;
/*     */       }
/* 184 */       param1Buffer.getChar();
/* 185 */       this.segCount = param1Buffer.getChar() / 2;
/* 186 */       param1Buffer.getChar();
/* 187 */       this.entrySelector = param1Buffer.getChar();
/* 188 */       this.rangeShift = param1Buffer.getChar() / 2;
/* 189 */       this.startCount = new char[this.segCount];
/* 190 */       this.endCount = new char[this.segCount];
/* 191 */       this.idDelta = new short[this.segCount];
/* 192 */       this.idRangeOffset = new char[this.segCount];
/*     */       int j;
/* 194 */       for (j = 0; j < this.segCount; j++) {
/* 195 */         this.endCount[j] = param1Buffer.getChar();
/*     */       }
/* 197 */       param1Buffer.getChar();
/* 198 */       for (j = 0; j < this.segCount; j++) {
/* 199 */         this.startCount[j] = param1Buffer.getChar();
/*     */       }
/*     */       
/* 202 */       for (j = 0; j < this.segCount; j++) {
/* 203 */         this.idDelta[j] = (short)param1Buffer.getChar();
/*     */       }
/*     */       
/* 206 */       for (j = 0; j < this.segCount; j++) {
/* 207 */         char c = param1Buffer.getChar();
/* 208 */         this.idRangeOffset[j] = (char)(c >> 1 & 0xFFFF);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 213 */       j = (this.segCount * 8 + 16) / 2;
/* 214 */       param1Buffer.position(j * 2 + param1Int);
/* 215 */       int k = i / 2 - j;
/* 216 */       this.glyphIds = new char[k];
/* 217 */       for (byte b = 0; b < k; b++) {
/* 218 */         this.glyphIds[b] = param1Buffer.getChar();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 224 */       int i = 0;
/* 225 */       char c = Character.MIN_VALUE;
/*     */       
/* 227 */       int j = getControlCodeGlyph(param1Int, true);
/* 228 */       if (j >= 0) {
/* 229 */         return (char)j;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       int k = 0, m = this.startCount.length;
/* 251 */       i = this.startCount.length >> 1;
/* 252 */       while (k < m) {
/* 253 */         if (this.endCount[i] < param1Int) {
/* 254 */           k = i + 1;
/*     */         } else {
/* 256 */           m = i;
/*     */         } 
/* 258 */         i = k + m >> 1;
/*     */       } 
/*     */       
/* 261 */       if (param1Int >= this.startCount[i] && param1Int <= this.endCount[i]) {
/* 262 */         char c1 = this.idRangeOffset[i];
/*     */         
/* 264 */         if (c1 == '\000') {
/* 265 */           c = (char)(param1Int + this.idDelta[i]);
/*     */         } else {
/*     */           
/* 268 */           int n = c1 - this.segCount + i + param1Int - this.startCount[i];
/*     */           
/* 270 */           c = this.glyphIds[n];
/* 271 */           if (c != '\000') {
/* 272 */             c = (char)(c + this.idDelta[i]);
/*     */           }
/*     */         } 
/*     */       } 
/* 276 */       return c;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CMapFormat0
/*     */     extends CMap
/*     */   {
/*     */     byte[] cmap;
/*     */     
/*     */     CMapFormat0(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 287 */       char c = param1Buffer.getChar(param1Int + 2);
/* 288 */       this.cmap = new byte[c - 6];
/* 289 */       param1Buffer.get(param1Int + 6, this.cmap, 0, c - 6);
/*     */     }
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 293 */       if (param1Int < 256) {
/* 294 */         if (param1Int < 16) {
/* 295 */           switch (param1Int) { case 9:
/*     */             case 10:
/*     */             case 13:
/* 298 */               return Character.MAX_VALUE; }
/*     */         
/*     */         }
/* 301 */         return (char)(0xFF & this.cmap[param1Int]);
/*     */       } 
/* 303 */       return Character.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CMapFormat2
/*     */     extends CMap
/*     */   {
/* 311 */     char[] subHeaderKey = new char[256];
/*     */ 
/*     */     
/*     */     char[] firstCodeArray;
/*     */ 
/*     */     
/*     */     char[] entryCountArray;
/*     */ 
/*     */     
/*     */     short[] idDeltaArray;
/*     */ 
/*     */     
/*     */     char[] idRangeOffSetArray;
/*     */     
/*     */     char[] glyphIndexArray;
/*     */ 
/*     */     
/*     */     CMapFormat2(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 329 */       char c = param1Buffer.getChar(param1Int + 2);
/* 330 */       param1Buffer.position(param1Int + 6);
/* 331 */       char c1 = Character.MIN_VALUE; int i;
/* 332 */       for (i = 0; i < 256; i++) {
/* 333 */         this.subHeaderKey[i] = param1Buffer.getChar();
/* 334 */         if (this.subHeaderKey[i] > c1) {
/* 335 */           c1 = this.subHeaderKey[i];
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 342 */       i = (c1 >> 3) + 1;
/* 343 */       this.firstCodeArray = new char[i];
/* 344 */       this.entryCountArray = new char[i];
/* 345 */       this.idDeltaArray = new short[i];
/* 346 */       this.idRangeOffSetArray = new char[i]; int j;
/* 347 */       for (j = 0; j < i; j++) {
/* 348 */         this.firstCodeArray[j] = param1Buffer.getChar();
/* 349 */         this.entryCountArray[j] = param1Buffer.getChar();
/* 350 */         this.idDeltaArray[j] = (short)param1Buffer.getChar();
/* 351 */         this.idRangeOffSetArray[j] = param1Buffer.getChar();
/*     */       } 
/*     */       
/* 354 */       j = (c - 518 - i * 8) / 2;
/* 355 */       this.glyphIndexArray = new char[j];
/* 356 */       for (byte b = 0; b < j; b++) {
/* 357 */         this.glyphIndexArray[b] = param1Buffer.getChar();
/*     */       }
/*     */     }
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 362 */       int i = getControlCodeGlyph(param1Int, true);
/* 363 */       if (i >= 0) {
/* 364 */         return (char)i;
/*     */       }
/*     */       
/* 367 */       char c1 = (char)(param1Int >> 8);
/* 368 */       char c2 = (char)(param1Int & 0xFF);
/* 369 */       int j = this.subHeaderKey[c1] >> 3;
/*     */ 
/*     */       
/* 372 */       if (j != 0) {
/* 373 */         c = c2;
/*     */       } else {
/* 375 */         c = c1;
/* 376 */         if (c == '\000') {
/* 377 */           c = c2;
/*     */         }
/*     */       } 
/* 380 */       char c3 = this.firstCodeArray[j];
/* 381 */       if (c < c3) {
/* 382 */         return Character.MIN_VALUE;
/*     */       }
/* 384 */       char c = (char)(c - c3);
/*     */ 
/*     */       
/* 387 */       if (c < this.entryCountArray[j]) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 401 */         int k = (this.idRangeOffSetArray.length - j) * 8 - 6;
/* 402 */         int m = (this.idRangeOffSetArray[j] - k) / 2;
/*     */         
/* 404 */         char c4 = this.glyphIndexArray[m + c];
/* 405 */         if (c4 != '\000') {
/* 406 */           c4 = (char)(c4 + this.idDeltaArray[j]);
/* 407 */           return c4;
/*     */         } 
/*     */       } 
/* 410 */       return Character.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CMapFormat6
/*     */     extends CMap
/*     */   {
/*     */     char firstCode;
/*     */     char entryCount;
/*     */     char[] glyphIdArray;
/*     */     
/*     */     CMapFormat6(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 423 */       param1Buffer.position(param1Int + 6);
/* 424 */       this.firstCode = param1Buffer.getChar();
/* 425 */       this.entryCount = param1Buffer.getChar();
/* 426 */       this.glyphIdArray = new char[this.entryCount];
/* 427 */       for (byte b = 0; b < this.entryCount; b++) {
/* 428 */         this.glyphIdArray[b] = param1Buffer.getChar();
/*     */       }
/*     */     }
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 433 */       int i = getControlCodeGlyph(param1Int, true);
/* 434 */       if (i >= 0) {
/* 435 */         return (char)i;
/*     */       }
/*     */       
/* 438 */       param1Int -= this.firstCode;
/* 439 */       if (param1Int < 0 || param1Int >= this.entryCount) {
/* 440 */         return Character.MIN_VALUE;
/*     */       }
/* 442 */       return this.glyphIdArray[param1Int];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CMapFormat8
/*     */     extends CMap
/*     */   {
/*     */     CMapFormat8(FontFileReader.Buffer param1Buffer, int param1Int) {}
/*     */ 
/*     */ 
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 457 */       return Character.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class CMapFormat10
/*     */     extends CMap
/*     */   {
/*     */     long startCharCode;
/*     */     
/*     */     int numChars;
/*     */     
/*     */     char[] glyphIdArray;
/*     */ 
/*     */     
/*     */     CMapFormat10(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 474 */       param1Buffer.position(param1Int + 12);
/* 475 */       this.startCharCode = (param1Buffer.getInt() & 0xFFFFFFFF);
/* 476 */       this.numChars = param1Buffer.getInt() & 0xFFFFFFFF;
/* 477 */       if (this.numChars <= 0 || this.numChars > 1114111 || param1Int > param1Buffer
/* 478 */         .capacity() - this.numChars * 2 - 12 - 8)
/*     */       {
/* 480 */         throw new RuntimeException("Invalid cmap subtable");
/*     */       }
/* 482 */       this.glyphIdArray = new char[this.numChars];
/* 483 */       for (byte b = 0; b < this.numChars; b++) {
/* 484 */         this.glyphIdArray[b] = param1Buffer.getChar();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 490 */       int i = (int)(param1Int - this.startCharCode);
/* 491 */       if (i < 0 || i >= this.numChars) {
/* 492 */         return Character.MIN_VALUE;
/*     */       }
/* 494 */       return this.glyphIdArray[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class CMapFormat12
/*     */     extends CMap
/*     */   {
/*     */     int numGroups;
/*     */     
/* 504 */     int highBit = 0;
/*     */     
/*     */     int power;
/*     */     int extra;
/*     */     long[] startCharCode;
/*     */     long[] endCharCode;
/*     */     int[] startGlyphID;
/*     */     
/*     */     CMapFormat12(FontFileReader.Buffer param1Buffer, int param1Int) {
/* 513 */       this.numGroups = param1Buffer.getInt(param1Int + 12);
/* 514 */       if (this.numGroups <= 0 || this.numGroups > 1114111 || param1Int > param1Buffer
/* 515 */         .capacity() - this.numGroups * 12 - 12 - 4)
/*     */       {
/* 517 */         throw new RuntimeException("Invalid cmap subtable");
/*     */       }
/* 519 */       this.startCharCode = new long[this.numGroups];
/* 520 */       this.endCharCode = new long[this.numGroups];
/* 521 */       this.startGlyphID = new int[this.numGroups];
/* 522 */       param1Buffer.position(param1Int + 16);
/*     */       
/*     */       int i;
/* 525 */       for (i = 0; i < this.numGroups; i++) {
/* 526 */         this.startCharCode[i] = (param1Buffer.getInt() & 0xFFFFFFFF);
/* 527 */         this.endCharCode[i] = (param1Buffer.getInt() & 0xFFFFFFFF);
/* 528 */         this.startGlyphID[i] = param1Buffer.getInt() & 0xFFFFFFFF;
/*     */       } 
/*     */ 
/*     */       
/* 532 */       i = this.numGroups;
/*     */       
/* 534 */       if (i >= 65536) {
/* 535 */         i >>= 16;
/* 536 */         this.highBit += 16;
/*     */       } 
/*     */       
/* 539 */       if (i >= 256) {
/* 540 */         i >>= 8;
/* 541 */         this.highBit += 8;
/*     */       } 
/*     */       
/* 544 */       if (i >= 16) {
/* 545 */         i >>= 4;
/* 546 */         this.highBit += 4;
/*     */       } 
/*     */       
/* 549 */       if (i >= 4) {
/* 550 */         i >>= 2;
/* 551 */         this.highBit += 2;
/*     */       } 
/*     */       
/* 554 */       if (i >= 2) {
/* 555 */         i >>= 1;
/* 556 */         this.highBit++;
/*     */       } 
/*     */       
/* 559 */       this.power = 1 << this.highBit;
/* 560 */       this.extra = this.numGroups - this.power;
/*     */     }
/*     */     
/*     */     char getGlyph(int param1Int) {
/* 564 */       int i = getControlCodeGlyph(param1Int, false);
/* 565 */       if (i >= 0) {
/* 566 */         return (char)i;
/*     */       }
/* 568 */       int j = this.power;
/* 569 */       int k = 0;
/*     */       
/* 571 */       if (this.startCharCode[this.extra] <= param1Int) {
/* 572 */         k = this.extra;
/*     */       }
/*     */       
/* 575 */       while (j > 1) {
/* 576 */         j >>= 1;
/*     */         
/* 578 */         if (this.startCharCode[k + j] <= param1Int) {
/* 579 */           k += j;
/*     */         }
/*     */       } 
/*     */       
/* 583 */       if (this.startCharCode[k] <= param1Int && this.endCharCode[k] >= param1Int)
/*     */       {
/* 585 */         return (char)(int)(this.startGlyphID[k] + param1Int - this.startCharCode[k]);
/*     */       }
/*     */ 
/*     */       
/* 589 */       return Character.MIN_VALUE;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class NullCMapClass
/*     */     extends CMap
/*     */   {
/*     */     char getGlyph(int param1Int) {
/* 598 */       return Character.MIN_VALUE;
/*     */     }
/*     */   }
/*     */   
/* 602 */   public static final NullCMapClass theNullCmap = new NullCMapClass();
/*     */   abstract char getGlyph(int paramInt);
/*     */   final int getControlCodeGlyph(int paramInt, boolean paramBoolean) {
/* 605 */     if (paramInt < 16) {
/* 606 */       switch (paramInt) { case 9:
/*     */         case 10:
/*     */         case 13:
/* 609 */           return 65535; }
/*     */     
/* 611 */     } else if (paramInt >= 8204) {
/* 612 */       if (paramInt <= 8207 || (paramInt >= 8232 && paramInt <= 8238) || (paramInt >= 8298 && paramInt <= 8303))
/*     */       {
/*     */         
/* 615 */         return 65535; } 
/* 616 */       if (paramBoolean && paramInt >= 65535) {
/* 617 */         return 0;
/*     */       }
/*     */     } 
/* 620 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\CMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */