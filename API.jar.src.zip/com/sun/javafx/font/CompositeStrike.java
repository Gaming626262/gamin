/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ import com.sun.javafx.geom.transform.Affine2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.text.GlyphList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeStrike
/*     */   implements FontStrike
/*     */ {
/*     */   private CompositeFontResource fontResource;
/*     */   private float size;
/*     */   private int aaMode;
/*     */   BaseTransform transform;
/*     */   private FontStrike slot0Strike;
/*     */   private FontStrike[] strikeSlots;
/*     */   private FontStrikeDesc desc;
/*     */   DisposerRecord disposer;
/*     */   private PrismMetrics metrics;
/*     */   
/*     */   public void clearDesc() {
/*  48 */     this.fontResource.getStrikeMap().remove(this.desc);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     if (this.slot0Strike != null) {
/*  55 */       this.slot0Strike.clearDesc();
/*     */     }
/*  57 */     if (this.strikeSlots != null) {
/*  58 */       for (byte b = 1; b < this.strikeSlots.length; b++) {
/*  59 */         if (this.strikeSlots[b] != null) {
/*  60 */           this.strikeSlots[b].clearDesc();
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompositeStrike(CompositeFontResource paramCompositeFontResource, float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/*  70 */     this.fontResource = paramCompositeFontResource;
/*  71 */     this.size = paramFloat;
/*  72 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/*  73 */       this.transform = BaseTransform.IDENTITY_TRANSFORM;
/*     */     } else {
/*  75 */       this.transform = paramBaseTransform.copy();
/*     */     } 
/*  77 */     this.desc = paramFontStrikeDesc;
/*  78 */     this.aaMode = paramInt;
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.disposer = new CompositeStrikeDisposer(paramCompositeFontResource, paramFontStrikeDesc);
/*     */   }
/*     */   
/*     */   public int getAAMode() {
/*  86 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  87 */     if (prismFontFactory.isLCDTextSupported()) {
/*  88 */       return this.aaMode;
/*     */     }
/*  90 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseTransform getTransform() {
/*  99 */     return this.transform;
/*     */   }
/*     */   
/*     */   public FontStrike getStrikeSlot(int paramInt) {
/* 103 */     if (paramInt == 0) {
/* 104 */       if (this.slot0Strike == null) {
/* 105 */         FontResource fontResource = this.fontResource.getSlotResource(0);
/* 106 */         this.slot0Strike = fontResource.getStrike(this.size, this.transform, 
/* 107 */             getAAMode());
/*     */       } 
/* 109 */       return this.slot0Strike;
/*     */     } 
/* 111 */     if (this.strikeSlots == null) {
/* 112 */       this.strikeSlots = new FontStrike[this.fontResource.getNumSlots()];
/*     */     }
/*     */     
/* 115 */     if (paramInt >= this.strikeSlots.length) {
/* 116 */       FontStrike[] arrayOfFontStrike = new FontStrike[this.fontResource.getNumSlots()];
/* 117 */       System.arraycopy(this.strikeSlots, 0, arrayOfFontStrike, 0, this.strikeSlots.length);
/* 118 */       this.strikeSlots = arrayOfFontStrike;
/*     */     } 
/* 120 */     if (this.strikeSlots[paramInt] == null) {
/* 121 */       FontResource fontResource = this.fontResource.getSlotResource(paramInt);
/* 122 */       this.strikeSlots[paramInt] = fontResource.getStrike(this.size, this.transform, 
/* 123 */           getAAMode());
/*     */     } 
/* 125 */     return this.strikeSlots[paramInt];
/*     */   }
/*     */ 
/*     */   
/*     */   public FontResource getFontResource() {
/* 130 */     return this.fontResource;
/*     */   }
/*     */   
/*     */   public int getStrikeSlotForGlyph(int paramInt) {
/* 134 */     return paramInt >>> 24;
/*     */   }
/*     */   
/*     */   public float getSize() {
/* 138 */     return this.size;
/*     */   }
/*     */   
/*     */   public boolean drawAsShapes() {
/* 142 */     return getStrikeSlot(0).drawAsShapes();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Metrics getMetrics() {
/* 148 */     if (this.metrics == null) {
/* 149 */       PrismFontFile prismFontFile = (PrismFontFile)this.fontResource.getSlotResource(0);
/* 150 */       this.metrics = prismFontFile.getFontMetrics(this.size);
/*     */     } 
/* 152 */     return this.metrics;
/*     */   }
/*     */   
/*     */   public Glyph getGlyph(char paramChar) {
/* 156 */     int i = this.fontResource.getGlyphMapper().charToGlyph(paramChar);
/* 157 */     return getGlyph(i);
/*     */   }
/*     */   
/*     */   public Glyph getGlyph(int paramInt) {
/* 161 */     int i = paramInt >>> 24;
/* 162 */     int j = paramInt & 0xFFFFFF;
/* 163 */     return getStrikeSlot(i).getGlyph(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getCharAdvance(char paramChar) {
/* 174 */     int i = this.fontResource.getGlyphMapper().charToGlyph(paramChar);
/* 175 */     return this.fontResource.getAdvance(i, this.size);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getQuantizedPosition(Point2D paramPoint2D) {
/* 180 */     return getStrikeSlot(0).getQuantizedPosition(paramPoint2D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getOutline(GlyphList paramGlyphList, BaseTransform paramBaseTransform) {
/* 185 */     Path2D path2D = new Path2D();
/* 186 */     getOutline(paramGlyphList, paramBaseTransform, path2D);
/* 187 */     return (Shape)path2D;
/*     */   }
/*     */   
/*     */   void getOutline(GlyphList paramGlyphList, BaseTransform paramBaseTransform, Path2D paramPath2D) {
/* 191 */     paramPath2D.reset();
/* 192 */     if (paramGlyphList == null) {
/*     */       return;
/*     */     }
/* 195 */     if (paramBaseTransform == null) {
/* 196 */       paramBaseTransform = BaseTransform.IDENTITY_TRANSFORM;
/*     */     }
/* 198 */     Affine2D affine2D = new Affine2D();
/* 199 */     for (byte b = 0; b < paramGlyphList.getGlyphCount(); b++) {
/* 200 */       int i = paramGlyphList.getGlyphCode(b);
/* 201 */       if (i != 65535) {
/* 202 */         Glyph glyph = getGlyph(i);
/* 203 */         Shape shape = glyph.getShape();
/* 204 */         if (shape != null) {
/* 205 */           affine2D.setTransform(paramBaseTransform);
/* 206 */           affine2D.translate(paramGlyphList.getPosX(b), paramGlyphList.getPosY(b));
/* 207 */           paramPath2D.append(shape.getPathIterator((BaseTransform)affine2D), false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\CompositeStrike.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */