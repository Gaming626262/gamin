/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.prism.GraphicsPipeline;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DWFactory
/*     */   extends PrismFontFactory
/*     */ {
/*  36 */   private static IDWriteFactory DWRITE_FACTORY = null;
/*  37 */   private static IDWriteFontCollection FONT_COLLECTION = null;
/*  38 */   private static IWICImagingFactory WIC_FACTORY = null;
/*  39 */   private static ID2D1Factory D2D_FACTORY = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Thread d2dThread;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrismFontFactory getFactory() {
/*  50 */     if (getDWriteFactory() == null)
/*     */     {
/*     */       
/*  53 */       return null;
/*     */     }
/*  55 */     return new DWFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontFile createFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  66 */     return new DWFontFile(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */   }
/*     */ 
/*     */   
/*     */   public GlyphLayout createGlyphLayout() {
/*  71 */     return new DWGlyphLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean registerEmbeddedFont(String paramString) {
/*  76 */     IDWriteFactory iDWriteFactory = getDWriteFactory();
/*  77 */     IDWriteFontFile iDWriteFontFile = iDWriteFactory.CreateFontFileReference(paramString);
/*  78 */     if (iDWriteFontFile == null) return false; 
/*  79 */     boolean[] arrayOfBoolean = new boolean[1];
/*  80 */     int[] arrayOfInt1 = new int[1];
/*  81 */     int[] arrayOfInt2 = new int[1];
/*  82 */     int[] arrayOfInt3 = new int[1];
/*  83 */     int i = iDWriteFontFile.Analyze(arrayOfBoolean, arrayOfInt1, arrayOfInt2, arrayOfInt3);
/*  84 */     iDWriteFontFile.Release();
/*  85 */     if (i != 0) return false; 
/*  86 */     return arrayOfBoolean[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static IDWriteFactory getDWriteFactory() {
/*  92 */     if (DWRITE_FACTORY == null) {
/*  93 */       DWRITE_FACTORY = OS.DWriteCreateFactory(0);
/*     */     }
/*  95 */     return DWRITE_FACTORY;
/*     */   }
/*     */   
/*     */   static IDWriteFontCollection getFontCollection() {
/*  99 */     if (FONT_COLLECTION == null) {
/* 100 */       FONT_COLLECTION = getDWriteFactory().GetSystemFontCollection(false);
/*     */     }
/* 102 */     return FONT_COLLECTION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkThread() {
/* 109 */     Thread thread = Thread.currentThread();
/* 110 */     if (d2dThread == null) {
/* 111 */       d2dThread = thread;
/*     */     }
/* 113 */     if (d2dThread != thread) {
/* 114 */       throw new IllegalStateException("This operation is not permitted on the current thread [" + thread
/*     */           
/* 116 */           .getName() + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   static synchronized IWICImagingFactory getWICFactory() {
/* 121 */     checkThread();
/*     */     
/* 123 */     if (WIC_FACTORY == null) {
/*     */ 
/*     */ 
/*     */       
/* 127 */       if (!OS.CoInitializeEx(6)) {
/* 128 */         return null;
/*     */       }
/*     */       
/* 131 */       WIC_FACTORY = OS.WICCreateImagingFactory();
/* 132 */       if (WIC_FACTORY == null) {
/* 133 */         return null;
/*     */       }
/*     */       
/* 136 */       GraphicsPipeline.getPipeline().addDisposeHook(() -> {
/*     */             checkThread();
/*     */             WIC_FACTORY.Release();
/*     */             OS.CoUninitialize();
/*     */             WIC_FACTORY = null;
/*     */           });
/*     */     } 
/* 143 */     return WIC_FACTORY;
/*     */   }
/*     */   
/*     */   static synchronized ID2D1Factory getD2DFactory() {
/* 147 */     checkThread();
/*     */     
/* 149 */     if (D2D_FACTORY == null) {
/* 150 */       D2D_FACTORY = OS.D2D1CreateFactory(0);
/*     */     }
/* 152 */     return D2D_FACTORY;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\DWFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */