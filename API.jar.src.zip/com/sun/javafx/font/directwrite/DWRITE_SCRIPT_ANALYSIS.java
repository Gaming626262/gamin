package com.sun.javafx.font.directwrite;

class DWRITE_SCRIPT_ANALYSIS {
  short script;
  
  int shapes;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\DWRITE_SCRIPT_ANALYSIS.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */