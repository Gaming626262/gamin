package com.sun.javafx.font.directwrite;

class DWRITE_GLYPH_METRICS {
  int leftSideBearing;
  
  int advanceWidth;
  
  int rightSideBearing;
  
  int topSideBearing;
  
  int advanceHeight;
  
  int bottomSideBearing;
  
  int verticalOriginY;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\DWRITE_GLYPH_METRICS.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */