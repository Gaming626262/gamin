/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ID2D1Factory
/*    */   extends IUnknown
/*    */ {
/*    */   ID2D1Factory(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   ID2D1RenderTarget CreateWicBitmapRenderTarget(IWICBitmap paramIWICBitmap, D2D1_RENDER_TARGET_PROPERTIES paramD2D1_RENDER_TARGET_PROPERTIES) {
/* 34 */     long l = OS.CreateWicBitmapRenderTarget(this.ptr, paramIWICBitmap.ptr, paramD2D1_RENDER_TARGET_PROPERTIES);
/* 35 */     return (l != 0L) ? new ID2D1RenderTarget(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\ID2D1Factory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */