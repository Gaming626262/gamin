/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFont
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFont(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   IDWriteFontFace CreateFontFace() {
/* 34 */     long l = OS.CreateFontFace(this.ptr);
/* 35 */     return (l != 0L) ? new IDWriteFontFace(l) : null;
/*    */   }
/*    */   
/*    */   IDWriteLocalizedStrings GetFaceNames() {
/* 39 */     long l = OS.GetFaceNames(this.ptr);
/* 40 */     return (l != 0L) ? new IDWriteLocalizedStrings(l) : null;
/*    */   }
/*    */   
/*    */   IDWriteFontFamily GetFontFamily() {
/* 44 */     long l = OS.GetFontFamily(this.ptr);
/* 45 */     return (l != 0L) ? new IDWriteFontFamily(l) : null;
/*    */   }
/*    */   
/*    */   IDWriteLocalizedStrings GetInformationalStrings(int paramInt) {
/* 49 */     long l = OS.GetInformationalStrings(this.ptr, paramInt);
/* 50 */     return (l != 0L) ? new IDWriteLocalizedStrings(l) : null;
/*    */   }
/*    */   
/*    */   int GetSimulations() {
/* 54 */     return OS.GetSimulations(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStretch() {
/* 58 */     return OS.GetStretch(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStyle() {
/* 62 */     return OS.GetStyle(this.ptr);
/*    */   }
/*    */   
/*    */   int GetWeight() {
/* 66 */     return OS.GetWeight(this.ptr);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\IDWriteFont.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */