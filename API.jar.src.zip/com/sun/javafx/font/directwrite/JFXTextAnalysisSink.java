/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JFXTextAnalysisSink
/*    */   extends IUnknown
/*    */ {
/*    */   JFXTextAnalysisSink(long paramLong) {
/* 31 */     super(paramLong);
/*    */   }
/*    */   
/*    */   boolean Next() {
/* 35 */     return OS.Next(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStart() {
/* 39 */     return OS.GetStart(this.ptr);
/*    */   }
/*    */   
/*    */   int GetLength() {
/* 43 */     return OS.GetLength(this.ptr);
/*    */   }
/*    */   
/*    */   DWRITE_SCRIPT_ANALYSIS GetAnalysis() {
/* 47 */     return OS.GetAnalysis(this.ptr);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\JFXTextAnalysisSink.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */