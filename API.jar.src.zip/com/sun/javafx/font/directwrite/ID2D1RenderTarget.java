/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ID2D1RenderTarget
/*    */   extends IUnknown
/*    */ {
/*    */   ID2D1RenderTarget(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   void BeginDraw() {
/* 34 */     OS.BeginDraw(this.ptr);
/*    */   }
/*    */   
/*    */   int EndDraw() {
/* 38 */     return OS.EndDraw(this.ptr);
/*    */   }
/*    */   
/*    */   void Clear(D2D1_COLOR_F paramD2D1_COLOR_F) {
/* 42 */     OS.Clear(this.ptr, paramD2D1_COLOR_F);
/*    */   }
/*    */   
/*    */   void SetTransform(D2D1_MATRIX_3X2_F paramD2D1_MATRIX_3X2_F) {
/* 46 */     OS.SetTransform(this.ptr, paramD2D1_MATRIX_3X2_F);
/*    */   }
/*    */   
/*    */   void SetTextAntialiasMode(int paramInt) {
/* 50 */     OS.SetTextAntialiasMode(this.ptr, paramInt);
/*    */   }
/*    */   
/*    */   void DrawGlyphRun(D2D1_POINT_2F paramD2D1_POINT_2F, DWRITE_GLYPH_RUN paramDWRITE_GLYPH_RUN, ID2D1Brush paramID2D1Brush, int paramInt) {
/* 54 */     OS.DrawGlyphRun(this.ptr, paramD2D1_POINT_2F, paramDWRITE_GLYPH_RUN, paramID2D1Brush.ptr, paramInt);
/*    */   }
/*    */   
/*    */   ID2D1Brush CreateSolidColorBrush(D2D1_COLOR_F paramD2D1_COLOR_F) {
/* 58 */     long l = OS.CreateSolidColorBrush(this.ptr, paramD2D1_COLOR_F);
/* 59 */     return (l != 0L) ? new ID2D1Brush(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\ID2D1RenderTarget.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */