/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontFile
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFontFile(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int Analyze(boolean[] paramArrayOfboolean, int[] paramArrayOfint1, int[] paramArrayOfint2, int[] paramArrayOfint3) {
/* 34 */     return OS.Analyze(this.ptr, paramArrayOfboolean, paramArrayOfint1, paramArrayOfint2, paramArrayOfint3);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\IDWriteFontFile.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */