/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IWICBitmapLock
/*    */   extends IUnknown
/*    */ {
/*    */   IWICBitmapLock(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   byte[] GetDataPointer() {
/* 34 */     return OS.GetDataPointer(this.ptr);
/*    */   }
/*    */   
/*    */   int GetStride() {
/* 38 */     return OS.GetStride(this.ptr);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\IWICBitmapLock.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */