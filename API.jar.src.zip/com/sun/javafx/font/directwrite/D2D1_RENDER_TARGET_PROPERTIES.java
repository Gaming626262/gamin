/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class D2D1_RENDER_TARGET_PROPERTIES
/*    */ {
/*    */   int type;
/* 30 */   D2D1_PIXEL_FORMAT pixelFormat = new D2D1_PIXEL_FORMAT();
/*    */   float dpiX;
/*    */   float dpiY;
/*    */   int usage;
/*    */   int minLevel;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\D2D1_RENDER_TARGET_PROPERTIES.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */