package com.sun.javafx.font.directwrite;

class DWRITE_GLYPH_RUN {
  long fontFace;
  
  float fontEmSize;
  
  short glyphIndices;
  
  float glyphAdvances;
  
  float advanceOffset;
  
  float ascenderOffset;
  
  boolean isSideways;
  
  int bidiLevel;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\DWRITE_GLYPH_RUN.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */