/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteTextAnalyzer
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteTextAnalyzer(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int AnalyzeScript(JFXTextAnalysisSink paramJFXTextAnalysisSink1, int paramInt1, int paramInt2, JFXTextAnalysisSink paramJFXTextAnalysisSink2) {
/* 34 */     return OS.AnalyzeScript(this.ptr, paramJFXTextAnalysisSink1.ptr, paramInt1, paramInt2, paramJFXTextAnalysisSink2.ptr);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int GetGlyphs(char[] paramArrayOfchar, int paramInt1, int paramInt2, IDWriteFontFace paramIDWriteFontFace, boolean paramBoolean1, boolean paramBoolean2, DWRITE_SCRIPT_ANALYSIS paramDWRITE_SCRIPT_ANALYSIS, String paramString, long paramLong, long[] paramArrayOflong, int[] paramArrayOfint1, int paramInt3, int paramInt4, short[] paramArrayOfshort1, short[] paramArrayOfshort2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int[] paramArrayOfint2) {
/* 55 */     return OS.GetGlyphs(this.ptr, paramArrayOfchar, paramInt1, paramInt2, paramIDWriteFontFace.ptr, paramBoolean1, paramBoolean2, paramDWRITE_SCRIPT_ANALYSIS, 
/*    */ 
/*    */         
/* 58 */         (paramString != null) ? (paramString + "\000").toCharArray() : (char[])null, paramLong, paramArrayOflong, paramArrayOfint1, paramInt3, paramInt4, paramArrayOfshort1, paramArrayOfshort2, paramArrayOfshort3, paramArrayOfshort4, paramArrayOfint2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int GetGlyphPlacements(char[] paramArrayOfchar, short[] paramArrayOfshort1, short[] paramArrayOfshort2, int paramInt1, int paramInt2, short[] paramArrayOfshort3, short[] paramArrayOfshort4, int paramInt3, IDWriteFontFace paramIDWriteFontFace, float paramFloat, boolean paramBoolean1, boolean paramBoolean2, DWRITE_SCRIPT_ANALYSIS paramDWRITE_SCRIPT_ANALYSIS, String paramString, long[] paramArrayOflong, int[] paramArrayOfint, int paramInt4, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 84 */     return OS.GetGlyphPlacements(this.ptr, paramArrayOfchar, paramArrayOfshort1, paramArrayOfshort2, paramInt1, paramInt2, paramArrayOfshort3, paramArrayOfshort4, paramInt3, paramIDWriteFontFace.ptr, paramFloat, paramBoolean1, paramBoolean2, paramDWRITE_SCRIPT_ANALYSIS, 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 89 */         (paramString != null) ? (paramString + "\000").toCharArray() : (char[])null, paramArrayOflong, paramArrayOfint, paramInt4, paramArrayOffloat1, paramArrayOffloat2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\IDWriteTextAnalyzer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */