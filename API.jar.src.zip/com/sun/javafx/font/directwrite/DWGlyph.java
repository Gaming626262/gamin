/*     */ package com.sun.javafx.font.directwrite;
/*     */ 
/*     */ import com.sun.javafx.font.Glyph;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.geom.Point2D;
/*     */ import com.sun.javafx.geom.RectBounds;
/*     */ import com.sun.javafx.geom.Shape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DWGlyph
/*     */   implements Glyph
/*     */ {
/*     */   private DWFontStrike strike;
/*     */   private DWRITE_GLYPH_METRICS metrics;
/*     */   private DWRITE_GLYPH_RUN run;
/*     */   private float pixelXAdvance;
/*     */   private float pixelYAdvance;
/*     */   private RECT rect;
/*     */   private boolean drawShapes;
/*     */   private byte[][] pixelData;
/*     */   private RECT[] rects;
/*     */   private static final boolean CACHE_TARGET = true;
/*     */   private static IWICBitmap cachedBitmap;
/*     */   private static ID2D1RenderTarget cachedTarget;
/*     */   private static final int BITMAP_WIDTH = 256;
/*     */   private static final int BITMAP_HEIGHT = 256;
/*     */   private static final int BITMAP_PIXEL_FORMAT = 8;
/*  51 */   private static D2D1_COLOR_F BLACK = new D2D1_COLOR_F(0.0F, 0.0F, 0.0F, 1.0F);
/*  52 */   private static D2D1_COLOR_F WHITE = new D2D1_COLOR_F(1.0F, 1.0F, 1.0F, 1.0F);
/*  53 */   private static D2D1_MATRIX_3X2_F D2D2_MATRIX_IDENTITY = new D2D1_MATRIX_3X2_F(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
/*     */   
/*     */   public static final int SHORTMASK = 65535;
/*     */   
/*     */   DWGlyph(DWFontStrike paramDWFontStrike, int paramInt, boolean paramBoolean) {
/*  58 */     this.strike = paramDWFontStrike;
/*  59 */     this.drawShapes = paramBoolean;
/*  60 */     byte b = DWFontStrike.SUBPIXEL_Y ? 9 : 3;
/*  61 */     this.pixelData = new byte[b][];
/*  62 */     this.rects = new RECT[b];
/*     */     
/*  64 */     IDWriteFontFace iDWriteFontFace = paramDWFontStrike.getFontFace();
/*  65 */     this.run = new DWRITE_GLYPH_RUN();
/*  66 */     this.run.fontFace = (iDWriteFontFace != null) ? iDWriteFontFace.ptr : 0L;
/*  67 */     this.run.fontEmSize = paramDWFontStrike.getSize();
/*  68 */     this.run.glyphIndices = (short)paramInt;
/*  69 */     this.run.glyphAdvances = 0.0F;
/*  70 */     this.run.advanceOffset = 0.0F;
/*  71 */     this.run.ascenderOffset = 0.0F;
/*  72 */     this.run.bidiLevel = 0;
/*  73 */     this.run.isSideways = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkMetrics() {
/*  82 */     if (this.metrics != null)
/*     */       return; 
/*  84 */     IDWriteFontFace iDWriteFontFace = this.strike.getFontFace();
/*  85 */     if (iDWriteFontFace == null)
/*  86 */       return;  this.metrics = iDWriteFontFace.GetDesignGlyphMetrics(this.run.glyphIndices, false);
/*  87 */     if (this.metrics != null) {
/*  88 */       float f = this.strike.getUpem();
/*  89 */       this.pixelXAdvance = this.metrics.advanceWidth * this.strike.getSize() / f;
/*  90 */       this.pixelYAdvance = 0.0F;
/*  91 */       if (this.strike.matrix != null) {
/*  92 */         Point2D point2D = new Point2D(this.pixelXAdvance, this.pixelYAdvance);
/*  93 */         this.strike.getTransform().transform(point2D, point2D);
/*  94 */         this.pixelXAdvance = point2D.x;
/*  95 */         this.pixelYAdvance = point2D.y;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void checkBounds() {
/* 101 */     if (this.rect != null) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     boolean bool = true;
/* 106 */     IDWriteGlyphRunAnalysis iDWriteGlyphRunAnalysis = createAnalysis(0.0F, 0.0F);
/* 107 */     if (iDWriteGlyphRunAnalysis != null) {
/* 108 */       this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(bool);
/* 109 */       if (this.rect == null || this.rect.right - this.rect.left == 0 || this.rect.bottom - this.rect.top == 0)
/*     */       {
/*     */ 
/*     */         
/* 113 */         this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(0);
/*     */       }
/* 115 */       iDWriteGlyphRunAnalysis.Release();
/*     */     } 
/* 117 */     if (this.rect == null) {
/* 118 */       this.rect = new RECT();
/*     */     } else {
/*     */       
/* 121 */       this.rect.left--;
/* 122 */       this.rect.top--;
/* 123 */       this.rect.right++;
/* 124 */       this.rect.bottom++;
/*     */     } 
/*     */   }
/*     */   
/*     */   byte[] getLCDMask(float paramFloat1, float paramFloat2) {
/* 129 */     IDWriteGlyphRunAnalysis iDWriteGlyphRunAnalysis = createAnalysis(paramFloat1, paramFloat2);
/* 130 */     byte[] arrayOfByte = null;
/* 131 */     if (iDWriteGlyphRunAnalysis != null) {
/* 132 */       boolean bool = true;
/* 133 */       this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(bool);
/* 134 */       if (this.rect != null && this.rect.right - this.rect.left != 0 && this.rect.bottom - this.rect.top != 0) {
/* 135 */         arrayOfByte = iDWriteGlyphRunAnalysis.CreateAlphaTexture(bool, this.rect);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 140 */         this.rect = iDWriteGlyphRunAnalysis.GetAlphaTextureBounds(0);
/* 141 */         if (this.rect != null && this.rect.right - this.rect.left != 0 && this.rect.bottom - this.rect.top != 0) {
/* 142 */           arrayOfByte = getD2DMask(paramFloat1, paramFloat2, true);
/*     */         }
/*     */       } 
/* 145 */       iDWriteGlyphRunAnalysis.Release();
/*     */     } 
/* 147 */     if (arrayOfByte == null) {
/* 148 */       arrayOfByte = new byte[0];
/* 149 */       this.rect = new RECT();
/*     */     } 
/* 151 */     return arrayOfByte; } byte[] getD2DMask(float paramFloat1, float paramFloat2, boolean paramBoolean) {
/*     */     IWICBitmap iWICBitmap;
/*     */     ID2D1RenderTarget iD2D1RenderTarget;
/*     */     D2D1_MATRIX_3X2_F d2D1_MATRIX_3X2_F;
/* 155 */     checkBounds();
/* 156 */     if (getWidth() == 0 || getHeight() == 0 || this.run.fontFace == 0L) {
/* 157 */       return new byte[0];
/*     */     }
/*     */     
/* 160 */     float f1 = this.rect.left;
/* 161 */     float f2 = this.rect.top;
/* 162 */     int i = this.rect.right - this.rect.left;
/* 163 */     int j = this.rect.bottom - this.rect.top;
/* 164 */     boolean bool = (256 >= i && 256 >= j) ? true : false;
/*     */ 
/*     */     
/* 167 */     if (bool) {
/* 168 */       iWICBitmap = getCachedBitmap();
/* 169 */       iD2D1RenderTarget = getCachedRenderingTarget();
/*     */     } else {
/* 171 */       iWICBitmap = createBitmap(i, j);
/* 172 */       iD2D1RenderTarget = createRenderingTarget(iWICBitmap);
/*     */     } 
/* 174 */     if (iWICBitmap == null || iD2D1RenderTarget == null) {
/* 175 */       return new byte[0];
/*     */     }
/*     */     
/* 178 */     DWRITE_MATRIX dWRITE_MATRIX = this.strike.matrix;
/*     */     
/* 180 */     if (dWRITE_MATRIX != null) {
/* 181 */       d2D1_MATRIX_3X2_F = new D2D1_MATRIX_3X2_F(dWRITE_MATRIX.m11, dWRITE_MATRIX.m12, dWRITE_MATRIX.m21, dWRITE_MATRIX.m22, -f1 + paramFloat1, -f2 + paramFloat2);
/*     */ 
/*     */       
/* 184 */       f1 = f2 = 0.0F;
/*     */     } else {
/* 186 */       d2D1_MATRIX_3X2_F = D2D2_MATRIX_IDENTITY;
/* 187 */       f1 -= paramFloat1;
/* 188 */       f2 -= paramFloat2;
/*     */     } 
/*     */     
/* 191 */     iD2D1RenderTarget.BeginDraw();
/* 192 */     iD2D1RenderTarget.SetTransform(d2D1_MATRIX_3X2_F);
/* 193 */     iD2D1RenderTarget.Clear(WHITE);
/* 194 */     D2D1_POINT_2F d2D1_POINT_2F = new D2D1_POINT_2F(-f1, -f2);
/* 195 */     ID2D1Brush iD2D1Brush = iD2D1RenderTarget.CreateSolidColorBrush(BLACK);
/* 196 */     if (!paramBoolean) {
/* 197 */       iD2D1RenderTarget.SetTextAntialiasMode(2);
/*     */     }
/* 199 */     iD2D1RenderTarget.DrawGlyphRun(d2D1_POINT_2F, this.run, iD2D1Brush, 0);
/* 200 */     int k = iD2D1RenderTarget.EndDraw();
/* 201 */     iD2D1Brush.Release();
/*     */     
/* 203 */     if (k != 0) {
/*     */       
/* 205 */       iWICBitmap.Release();
/* 206 */       cachedBitmap = null;
/* 207 */       iD2D1RenderTarget.Release();
/* 208 */       cachedTarget = null;
/* 209 */       if (PrismFontFactory.debugFonts) {
/* 210 */         System.err.println("Rendering failed=" + k);
/*     */       }
/* 212 */       this.rect.left = this.rect.top = this.rect.right = this.rect.bottom = 0;
/* 213 */       return null;
/*     */     } 
/*     */     
/* 216 */     byte[] arrayOfByte = null;
/* 217 */     IWICBitmapLock iWICBitmapLock = iWICBitmap.Lock(0, 0, i, j, 1);
/* 218 */     if (iWICBitmapLock != null) {
/* 219 */       byte[] arrayOfByte1 = iWICBitmapLock.GetDataPointer();
/*     */ 
/*     */       
/* 222 */       if (arrayOfByte1 != null) {
/* 223 */         int m = iWICBitmapLock.GetStride();
/* 224 */         byte b = 0; int n = 0;
/* 225 */         byte b1 = -1;
/* 226 */         if (paramBoolean) {
/* 227 */           arrayOfByte = new byte[i * j * 3];
/* 228 */           for (byte b2 = 0; b2 < j; b2++) {
/* 229 */             int i1 = n;
/* 230 */             for (byte b3 = 0; b3 < i; b3++) {
/* 231 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 232 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 233 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1++]);
/* 234 */               i1++;
/*     */             } 
/* 236 */             n += m;
/*     */           } 
/*     */         } else {
/* 239 */           arrayOfByte = new byte[i * j];
/* 240 */           for (byte b2 = 0; b2 < j; b2++) {
/* 241 */             int i1 = n;
/* 242 */             for (byte b3 = 0; b3 < i; b3++) {
/* 243 */               arrayOfByte[b++] = (byte)(b1 - arrayOfByte1[i1]);
/* 244 */               i1 += 4;
/*     */             } 
/* 246 */             n += m;
/*     */           } 
/*     */         } 
/*     */       } 
/* 250 */       iWICBitmapLock.Release();
/*     */     } 
/*     */     
/* 253 */     if (!bool) {
/* 254 */       iWICBitmap.Release();
/* 255 */       iD2D1RenderTarget.Release();
/*     */     } 
/* 257 */     return arrayOfByte;
/*     */   }
/*     */   
/*     */   IDWriteGlyphRunAnalysis createAnalysis(float paramFloat1, float paramFloat2) {
/* 261 */     if (this.run.fontFace == 0L) return null; 
/* 262 */     IDWriteFactory iDWriteFactory = DWFactory.getDWriteFactory();
/*     */ 
/*     */     
/* 265 */     byte b = DWFontStrike.SUBPIXEL_Y ? 5 : 4;
/* 266 */     boolean bool = false;
/* 267 */     DWRITE_MATRIX dWRITE_MATRIX = this.strike.matrix;
/* 268 */     float f = 1.0F;
/* 269 */     return iDWriteFactory.CreateGlyphRunAnalysis(this.run, f, dWRITE_MATRIX, b, bool, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   IWICBitmap getCachedBitmap() {
/* 273 */     if (cachedBitmap == null) {
/* 274 */       cachedBitmap = createBitmap(256, 256);
/*     */     }
/* 276 */     return cachedBitmap;
/*     */   }
/*     */   
/*     */   ID2D1RenderTarget getCachedRenderingTarget() {
/* 280 */     if (cachedTarget == null) {
/* 281 */       cachedTarget = createRenderingTarget(getCachedBitmap());
/*     */     }
/* 283 */     return cachedTarget;
/*     */   }
/*     */   
/*     */   IWICBitmap createBitmap(int paramInt1, int paramInt2) {
/* 287 */     IWICImagingFactory iWICImagingFactory = DWFactory.getWICFactory();
/* 288 */     return iWICImagingFactory.CreateBitmap(paramInt1, paramInt2, 8, 1);
/*     */   }
/*     */   
/*     */   ID2D1RenderTarget createRenderingTarget(IWICBitmap paramIWICBitmap) {
/* 292 */     D2D1_RENDER_TARGET_PROPERTIES d2D1_RENDER_TARGET_PROPERTIES = new D2D1_RENDER_TARGET_PROPERTIES();
/*     */     
/* 294 */     d2D1_RENDER_TARGET_PROPERTIES.type = 0;
/* 295 */     d2D1_RENDER_TARGET_PROPERTIES.pixelFormat.format = 0;
/* 296 */     d2D1_RENDER_TARGET_PROPERTIES.pixelFormat.alphaMode = 0;
/* 297 */     d2D1_RENDER_TARGET_PROPERTIES.dpiX = 0.0F;
/* 298 */     d2D1_RENDER_TARGET_PROPERTIES.dpiY = 0.0F;
/* 299 */     d2D1_RENDER_TARGET_PROPERTIES.usage = 0;
/* 300 */     d2D1_RENDER_TARGET_PROPERTIES.minLevel = 0;
/* 301 */     ID2D1Factory iD2D1Factory = DWFactory.getD2DFactory();
/* 302 */     return iD2D1Factory.CreateWicBitmapRenderTarget(paramIWICBitmap, d2D1_RENDER_TARGET_PROPERTIES);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getGlyphCode() {
/* 307 */     return this.run.glyphIndices & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public RectBounds getBBox() {
/* 312 */     return this.strike.getBBox(this.run.glyphIndices & 0xFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getAdvance() {
/* 317 */     checkMetrics();
/* 318 */     if (this.metrics == null) return 0.0F; 
/* 319 */     float f = this.strike.getUpem();
/* 320 */     return this.metrics.advanceWidth * this.strike.getSize() / f;
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape getShape() {
/* 325 */     return (Shape)this.strike.createGlyphOutline(this.run.glyphIndices & 0xFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData() {
/* 330 */     return getPixelData(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPixelData(int paramInt) {
/* 335 */     byte[] arrayOfByte = this.pixelData[paramInt];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     if (arrayOfByte == null) {
/* 341 */       float f1 = 0.0F, f2 = 0.0F;
/* 342 */       int i = paramInt;
/* 343 */       if (i >= 6) {
/* 344 */         i -= 6;
/* 345 */         f2 = 0.66F;
/* 346 */       } else if (i >= 3) {
/* 347 */         i -= 3;
/* 348 */         f2 = 0.33F;
/*     */       } 
/* 350 */       if (i == 1) f1 = 0.33F; 
/* 351 */       if (i == 2) f1 = 0.66F; 
/* 352 */       this.pixelData[paramInt] = 
/* 353 */         arrayOfByte = isLCDGlyph() ? getLCDMask(f1, f2) : getD2DMask(f1, f2, false);
/* 354 */       this.rects[paramInt] = this.rect;
/*     */     } else {
/* 356 */       this.rect = this.rects[paramInt];
/*     */     } 
/* 358 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelXAdvance() {
/* 363 */     checkMetrics();
/* 364 */     return this.pixelXAdvance;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getPixelYAdvance() {
/* 369 */     checkMetrics();
/* 370 */     return this.pixelYAdvance;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 375 */     checkBounds();
/* 376 */     return (this.rect.right - this.rect.left) * (isLCDGlyph() ? 3 : 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 381 */     checkBounds();
/* 382 */     return this.rect.bottom - this.rect.top;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginX() {
/* 387 */     checkBounds();
/* 388 */     return this.rect.left;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOriginY() {
/* 393 */     checkBounds();
/* 394 */     return this.rect.top;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLCDGlyph() {
/* 399 */     return (this.strike.getAAMode() == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\DWGlyph.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */