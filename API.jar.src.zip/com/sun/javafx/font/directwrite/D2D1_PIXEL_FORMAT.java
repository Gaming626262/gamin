package com.sun.javafx.font.directwrite;

class D2D1_PIXEL_FORMAT {
  int format;
  
  int alphaMode;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\D2D1_PIXEL_FORMAT.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */