package com.sun.javafx.font.directwrite;

public class RECT {
  public int left;
  
  public int top;
  
  public int right;
  
  public int bottom;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\RECT.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */