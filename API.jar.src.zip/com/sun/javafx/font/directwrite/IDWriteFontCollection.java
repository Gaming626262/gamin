/*    */ package com.sun.javafx.font.directwrite;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IDWriteFontCollection
/*    */   extends IUnknown
/*    */ {
/*    */   IDWriteFontCollection(long paramLong) {
/* 30 */     super(paramLong);
/*    */   }
/*    */   
/*    */   int GetFontFamilyCount() {
/* 34 */     return OS.GetFontFamilyCount(this.ptr);
/*    */   }
/*    */   
/*    */   IDWriteFontFamily GetFontFamily(int paramInt) {
/* 38 */     long l = OS.GetFontFamily(this.ptr, paramInt);
/* 39 */     return (l != 0L) ? new IDWriteFontFamily(l) : null;
/*    */   }
/*    */   
/*    */   int FindFamilyName(String paramString) {
/* 43 */     return OS.FindFamilyName(this.ptr, (paramString + "\000").toCharArray());
/*    */   }
/*    */   
/*    */   IDWriteFont GetFontFromFontFace(IDWriteFontFace paramIDWriteFontFace) {
/* 47 */     long l = OS.GetFontFromFontFace(this.ptr, paramIDWriteFontFace.ptr);
/* 48 */     return (l != 0L) ? new IDWriteFont(l) : null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\directwrite\IDWriteFontCollection.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */