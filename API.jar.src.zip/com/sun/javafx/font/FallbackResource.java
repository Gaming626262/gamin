/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FallbackResource
/*     */   implements CompositeFontResource
/*     */ {
/*     */   private ArrayList<String> linkedFontFiles;
/*     */   private ArrayList<String> linkedFontNames;
/*     */   private FontResource[] fallbacks;
/*     */   private FontResource[] nativeFallbacks;
/*     */   private boolean isBold;
/*     */   private boolean isItalic;
/*     */   private int aaMode;
/*     */   private CompositeGlyphMapper mapper;
/*  53 */   Map<FontStrikeDesc, WeakReference<FontStrike>> strikeMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<FontStrikeDesc, WeakReference<FontStrike>> getStrikeMap() {
/*  58 */     return this.strikeMap;
/*     */   }
/*     */   
/*     */   FallbackResource(boolean paramBoolean1, boolean paramBoolean2, int paramInt) {
/*  62 */     this.isBold = paramBoolean1;
/*  63 */     this.isItalic = paramBoolean2;
/*  64 */     this.aaMode = paramInt;
/*     */   }
/*     */   
/*  67 */   static FallbackResource[] greyFallBackResource = new FallbackResource[4];
/*  68 */   static FallbackResource[] lcdFallBackResource = new FallbackResource[4];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static FallbackResource getFallbackResource(boolean paramBoolean1, boolean paramBoolean2, int paramInt) {
/*  74 */     FallbackResource[] arrayOfFallbackResource = (paramInt == 0) ? greyFallBackResource : lcdFallBackResource;
/*  75 */     boolean bool = paramBoolean1 ? true : false;
/*  76 */     if (paramBoolean2) {
/*  77 */       bool += true;
/*     */     }
/*  79 */     FallbackResource fallbackResource = arrayOfFallbackResource[bool];
/*  80 */     if (fallbackResource == null) {
/*  81 */       fallbackResource = new FallbackResource(paramBoolean1, paramBoolean2, paramInt);
/*  82 */       arrayOfFallbackResource[bool] = fallbackResource;
/*     */     } 
/*  84 */     return fallbackResource;
/*     */   }
/*     */   
/*     */   public int getDefaultAAMode() {
/*  88 */     return this.aaMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String throwException() {
/*  97 */     throw new UnsupportedOperationException("Not supported");
/*     */   }
/*     */   
/*     */   public String getFullName() {
/* 101 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getPSName() {
/* 105 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getFamilyName() {
/* 109 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getStyleName() {
/* 113 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getLocaleFullName() {
/* 117 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getLocaleFamilyName() {
/* 121 */     return throwException();
/*     */   }
/*     */   
/*     */   public String getLocaleStyleName() {
/* 125 */     return throwException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBold() {
/* 130 */     throw new UnsupportedOperationException("Not supported");
/*     */   }
/*     */   
/*     */   public boolean isItalic() {
/* 134 */     throw new UnsupportedOperationException("Not supported");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFeatures() {
/* 139 */     throw new UnsupportedOperationException("Not supported");
/*     */   }
/*     */   
/*     */   public String getFileName() {
/* 143 */     return throwException();
/*     */   }
/*     */   
/*     */   public Object getPeer() {
/* 147 */     return null;
/*     */   }
/*     */   
/*     */   public void setPeer(Object paramObject) {
/* 151 */     throwException();
/*     */   }
/*     */   
/*     */   public boolean isEmbeddedFont() {
/* 155 */     return false;
/*     */   }
/*     */   
/*     */   public CharToGlyphMapper getGlyphMapper() {
/* 159 */     if (this.mapper == null) {
/* 160 */       this.mapper = new CompositeGlyphMapper(this);
/*     */     }
/* 162 */     return this.mapper;
/*     */   }
/*     */   public int getSlotForFont(String paramString) {
/*     */     FontResource[] arrayOfFontResource;
/* 166 */     getLinkedFonts();
/* 167 */     byte b = 0;
/* 168 */     for (String str : this.linkedFontNames) {
/* 169 */       if (paramString.equalsIgnoreCase(str)) {
/* 170 */         return b;
/*     */       }
/* 172 */       b++;
/*     */     } 
/* 174 */     if (this.nativeFallbacks != null) {
/* 175 */       for (FontResource fontResource1 : this.nativeFallbacks) {
/* 176 */         if (paramString.equalsIgnoreCase(fontResource1.getFullName())) {
/* 177 */           return b;
/*     */         }
/* 179 */         b++;
/*     */       } 
/*     */     }
/*     */     
/* 183 */     if (b >= 126) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       if (PrismFontFactory.debugFonts) {
/* 190 */         System.err.println("\tToo many font fallbacks!");
/*     */       }
/* 192 */       return -1;
/*     */     } 
/* 194 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/* 195 */     FontResource fontResource = prismFontFactory.getFontResource(paramString, null, false);
/* 196 */     if (fontResource == null) {
/* 197 */       if (PrismFontFactory.debugFonts) {
/* 198 */         System.err.println("\t Font name not supported \"" + paramString + "\".");
/*     */       }
/* 200 */       return -1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (this.nativeFallbacks == null) {
/* 206 */       arrayOfFontResource = new FontResource[1];
/*     */     } else {
/* 208 */       arrayOfFontResource = new FontResource[this.nativeFallbacks.length + 1];
/* 209 */       System.arraycopy(this.nativeFallbacks, 0, arrayOfFontResource, 0, this.nativeFallbacks.length);
/*     */     } 
/* 211 */     arrayOfFontResource[arrayOfFontResource.length - 1] = fontResource;
/* 212 */     this.nativeFallbacks = arrayOfFontResource;
/* 213 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getLinkedFonts() {
/* 220 */     if (this.fallbacks == null) {
/* 221 */       if (PrismFontFactory.isLinux) {
/*     */         
/* 223 */         FontConfigManager.FcCompFont fcCompFont = FontConfigManager.getFontConfigFont("sans", this.isBold, this.isItalic);
/*     */         
/* 225 */         this.linkedFontFiles = FontConfigManager.getFileNames(fcCompFont, false);
/* 226 */         this.linkedFontNames = FontConfigManager.getFontNames(fcCompFont, false);
/* 227 */         this.fallbacks = new FontResource[this.linkedFontFiles.size()];
/*     */       } else {
/*     */         ArrayList[] arrayOfArrayList;
/* 230 */         if (PrismFontFactory.isMacOSX) {
/*     */           
/* 232 */           arrayOfArrayList = (ArrayList[])PrismFontFactory.getLinkedFonts("Arial Unicode MS", true);
/*     */         } else {
/*     */           
/* 235 */           arrayOfArrayList = (ArrayList[])PrismFontFactory.getLinkedFonts("Tahoma", true);
/*     */         } 
/* 237 */         this.linkedFontFiles = arrayOfArrayList[0];
/* 238 */         this.linkedFontNames = arrayOfArrayList[1];
/* 239 */         this.fallbacks = new FontResource[this.linkedFontFiles.size()];
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public int getNumSlots() {
/* 245 */     getLinkedFonts();
/* 246 */     int i = this.linkedFontFiles.size();
/* 247 */     if (this.nativeFallbacks != null) {
/* 248 */       i += this.nativeFallbacks.length;
/*     */     }
/* 250 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] getGlyphBoundingBox(int paramInt, float paramFloat, float[] paramArrayOffloat) {
/* 255 */     int i = paramInt >>> 24;
/* 256 */     int j = paramInt & 0xFFFFFF;
/* 257 */     FontResource fontResource = getSlotResource(i);
/* 258 */     return fontResource.getGlyphBoundingBox(j, paramFloat, paramArrayOffloat);
/*     */   }
/*     */   
/*     */   public float getAdvance(int paramInt, float paramFloat) {
/* 262 */     int i = paramInt >>> 24;
/* 263 */     int j = paramInt & 0xFFFFFF;
/* 264 */     FontResource fontResource = getSlotResource(i);
/* 265 */     return fontResource.getAdvance(j, paramFloat);
/*     */   }
/*     */   
/*     */   public synchronized FontResource getSlotResource(int paramInt) {
/* 269 */     getLinkedFonts();
/* 270 */     if (paramInt >= this.fallbacks.length) {
/* 271 */       paramInt -= this.fallbacks.length;
/* 272 */       if (this.nativeFallbacks == null || paramInt >= this.nativeFallbacks.length) {
/* 273 */         return null;
/*     */       }
/* 275 */       return this.nativeFallbacks[paramInt];
/*     */     } 
/* 277 */     if (this.fallbacks[paramInt] == null) {
/* 278 */       String str1 = this.linkedFontFiles.get(paramInt);
/* 279 */       String str2 = this.linkedFontNames.get(paramInt);
/* 280 */       this.fallbacks[paramInt] = 
/* 281 */         PrismFontFactory.getFontFactory()
/* 282 */         .getFontResource(str2, str1, false);
/*     */     } 
/* 284 */     return this.fallbacks[paramInt];
/*     */   }
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform) {
/* 288 */     return getStrike(paramFloat, paramBaseTransform, getDefaultAAMode());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FontStrike getStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt) {
/* 294 */     FontStrikeDesc fontStrikeDesc = new FontStrikeDesc(paramFloat, paramBaseTransform, paramInt);
/* 295 */     WeakReference<CompositeStrike> weakReference = (WeakReference)this.strikeMap.get(fontStrikeDesc);
/* 296 */     CompositeStrike compositeStrike = null;
/*     */     
/* 298 */     if (weakReference != null) {
/* 299 */       compositeStrike = weakReference.get();
/*     */     }
/* 301 */     if (compositeStrike == null) {
/* 302 */       compositeStrike = new CompositeStrike(this, paramFloat, paramBaseTransform, paramInt, fontStrikeDesc);
/* 303 */       if (compositeStrike.disposer != null) {
/* 304 */         weakReference = Disposer.addRecord(compositeStrike, compositeStrike.disposer);
/*     */       } else {
/* 306 */         weakReference = new WeakReference<>(compositeStrike);
/*     */       } 
/* 308 */       this.strikeMap.put(fontStrikeDesc, weakReference);
/*     */     } 
/* 310 */     return compositeStrike;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\FallbackResource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */