/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ import com.sun.javafx.font.PrismFontFactory;
/*    */ import com.sun.javafx.font.PrismFontFile;
/*    */ import com.sun.javafx.text.GlyphLayout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CTFactory
/*    */   extends PrismFontFactory
/*    */ {
/*    */   public static PrismFontFactory getFactory() {
/* 35 */     return new CTFactory();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected PrismFontFile createFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/* 45 */     return new CTFontFile(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public GlyphLayout createGlyphLayout() {
/* 51 */     return new CTGlyphLayout();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean registerEmbeddedFont(String paramString) {
/* 56 */     boolean bool = CTFontFile.registerFont(paramString);
/* 57 */     if (debugFonts) {
/* 58 */       if (bool) {
/* 59 */         System.err.println("[CoreText] Font registration succeeded:" + paramString);
/*    */       } else {
/* 61 */         System.err.println("[CoreText] Font registration failed:" + paramString);
/*    */       } 
/*    */     }
/* 64 */     return bool;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\coretext\CTFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */