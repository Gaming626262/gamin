package com.sun.javafx.font.coretext;

class CGPoint {
  double x;
  
  double y;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\coretext\CGPoint.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */