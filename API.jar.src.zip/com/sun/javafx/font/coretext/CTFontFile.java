/*     */ package com.sun.javafx.font.coretext;
/*     */ 
/*     */ import com.sun.javafx.font.Disposer;
/*     */ import com.sun.javafx.font.DisposerRecord;
/*     */ import com.sun.javafx.font.FontStrikeDesc;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.font.PrismFontStrike;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CTFontFile
/*     */   extends PrismFontFile
/*     */ {
/*     */   private final long cgFontRef;
/*  40 */   private static final CGAffineTransform tx = new CGAffineTransform();
/*     */   static {
/*  42 */     tx.a = 1.0D;
/*  43 */     tx.d = -1.0D;
/*     */   }
/*     */   
/*     */   private static class SelfDisposerRecord implements DisposerRecord {
/*     */     private long cgFontRef;
/*     */     
/*     */     SelfDisposerRecord(long param1Long) {
/*  50 */       this.cgFontRef = param1Long;
/*     */     }
/*     */ 
/*     */     
/*     */     public synchronized void dispose() {
/*  55 */       if (this.cgFontRef != 0L) {
/*  56 */         OS.CFRelease(this.cgFontRef);
/*  57 */         this.cgFontRef = 0L;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   CTFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  64 */     super(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */     
/*  66 */     if (paramBoolean2) {
/*  67 */       this.cgFontRef = createCGFontForEmbeddedFont();
/*  68 */       Disposer.addRecord(this, new SelfDisposerRecord(this.cgFontRef));
/*     */     } else {
/*  70 */       this.cgFontRef = 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean registerFont(String paramString) {
/*  75 */     if (paramString == null) return false; 
/*  76 */     long l1 = OS.kCFAllocatorDefault();
/*  77 */     boolean bool = false;
/*  78 */     long l2 = OS.CFStringCreate(paramString);
/*  79 */     if (l2 != 0L) {
/*  80 */       boolean bool1 = false;
/*  81 */       long l = OS.CFURLCreateWithFileSystemPath(l1, l2, bool1, false);
/*  82 */       if (l != 0L) {
/*  83 */         boolean bool2 = true;
/*  84 */         bool = OS.CTFontManagerRegisterFontsForURL(l, bool2, 0L);
/*  85 */         OS.CFRelease(l);
/*     */       } 
/*  87 */       OS.CFRelease(l2);
/*     */     } 
/*  89 */     return bool;
/*     */   }
/*     */   
/*     */   private long createCGFontForEmbeddedFont() {
/*  93 */     long l1 = 0L;
/*  94 */     long l2 = OS.CFStringCreate(getFileName());
/*  95 */     if (l2 != 0L) {
/*  96 */       long l = OS.CFURLCreateWithFileSystemPath(
/*  97 */           OS.kCFAllocatorDefault(), l2, 0L, false);
/*     */       
/*  99 */       if (l != 0L) {
/* 100 */         long l3 = OS.CGDataProviderCreateWithURL(l);
/* 101 */         if (l3 != 0L) {
/* 102 */           l1 = OS.CGFontCreateWithDataProvider(l3);
/* 103 */           OS.CFRelease(l3);
/*     */         } 
/* 105 */         OS.CFRelease(l);
/*     */       } 
/* 107 */       OS.CFRelease(l2);
/*     */     } 
/* 109 */     return l1;
/*     */   }
/*     */   
/*     */   long getCGFontRef() {
/* 113 */     return this.cgFontRef;
/*     */   }
/*     */   
/*     */   CGRect getBBox(int paramInt, float paramFloat) {
/* 117 */     CTFontStrike cTFontStrike = (CTFontStrike)getStrike(paramFloat, BaseTransform.IDENTITY_TRANSFORM);
/* 118 */     long l1 = cTFontStrike.getFontRef();
/* 119 */     if (l1 == 0L) return null; 
/* 120 */     long l2 = OS.CTFontCreatePathForGlyph(l1, (short)paramInt, tx);
/* 121 */     if (l2 == 0L) return null; 
/* 122 */     CGRect cGRect = OS.CGPathGetPathBoundingBox(l2);
/* 123 */     OS.CGPathRelease(l2);
/* 124 */     return cGRect;
/*     */   }
/*     */   
/*     */   Path2D getGlyphOutline(int paramInt, float paramFloat) {
/* 128 */     CTFontStrike cTFontStrike = (CTFontStrike)getStrike(paramFloat, BaseTransform.IDENTITY_TRANSFORM);
/* 129 */     long l1 = cTFontStrike.getFontRef();
/* 130 */     if (l1 == 0L) return null; 
/* 131 */     long l2 = OS.CTFontCreatePathForGlyph(l1, (short)paramInt, tx);
/* 132 */     if (l2 == 0L) return null; 
/* 133 */     Path2D path2D = OS.CGPathApply(l2);
/* 134 */     OS.CGPathRelease(l2);
/* 135 */     return path2D;
/*     */   }
/*     */   
/*     */   protected int[] createGlyphBoundingBox(int paramInt) {
/* 139 */     float f1 = 12.0F;
/* 140 */     CTFontStrike cTFontStrike = (CTFontStrike)getStrike(f1, BaseTransform.IDENTITY_TRANSFORM);
/*     */ 
/*     */     
/* 143 */     long l1 = cTFontStrike.getFontRef();
/* 144 */     if (l1 == 0L) return null; 
/* 145 */     int[] arrayOfInt = new int[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (!isCFF()) {
/* 155 */       short s = getIndexToLocFormat();
/* 156 */       if (OS.CTFontGetBoundingRectForGlyphUsingTables(l1, (short)paramInt, s, arrayOfInt)) {
/* 157 */         return arrayOfInt;
/*     */       }
/*     */     } 
/*     */     
/* 161 */     long l2 = OS.CTFontCreatePathForGlyph(l1, (short)paramInt, null);
/* 162 */     if (l2 == 0L) return null; 
/* 163 */     CGRect cGRect = OS.CGPathGetPathBoundingBox(l2);
/* 164 */     OS.CGPathRelease(l2);
/* 165 */     float f2 = getUnitsPerEm() / f1;
/* 166 */     arrayOfInt[0] = (int)Math.round(cGRect.origin.x * f2);
/* 167 */     arrayOfInt[1] = (int)Math.round(cGRect.origin.y * f2);
/* 168 */     arrayOfInt[2] = (int)Math.round((cGRect.origin.x + cGRect.size.width) * f2);
/* 169 */     arrayOfInt[3] = (int)Math.round((cGRect.origin.y + cGRect.size.height) * f2);
/* 170 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontStrike<CTFontFile> createStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/* 176 */     return new CTFontStrike(this, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\coretext\CTFontFile.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */