/*    */ package com.sun.javafx.font.coretext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CGRect
/*    */ {
/* 29 */   CGPoint origin = new CGPoint();
/* 30 */   CGSize size = new CGSize();
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\coretext\CGRect.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */