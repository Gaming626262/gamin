package com.sun.javafx.font;

import com.sun.javafx.geom.RectBounds;
import com.sun.javafx.geom.Shape;

public interface Glyph {
  int getGlyphCode();
  
  RectBounds getBBox();
  
  float getAdvance();
  
  Shape getShape();
  
  byte[] getPixelData();
  
  byte[] getPixelData(int paramInt);
  
  float getPixelXAdvance();
  
  float getPixelYAdvance();
  
  boolean isLCDGlyph();
  
  int getWidth();
  
  int getHeight();
  
  int getOriginX();
  
  int getOriginY();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\Glyph.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */