/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontConfigManager
/*     */ {
/*     */   static boolean debugFonts = false;
/*     */   static boolean useFontConfig = true;
/*     */   static boolean fontConfigFailed = false;
/*     */   static boolean useEmbeddedFontSupport = false;
/*     */   
/*     */   static {
/*  48 */     Void void_ = AccessController.<Void>doPrivileged(() -> {
/*     */           String str1 = System.getProperty("prism.debugfonts", "");
/*     */           debugFonts = "true".equals(str1);
/*     */           String str2 = System.getProperty("prism.useFontConfig", "true");
/*     */           useFontConfig = "true".equals(str2);
/*     */           String str3 = System.getProperty("prism.embeddedfonts", "");
/*     */           useEmbeddedFontSupport = "true".equals(str3);
/*     */           return null;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FontConfigFont
/*     */   {
/*     */     public String familyName;
/*     */ 
/*     */     
/*     */     public String styleStr;
/*     */ 
/*     */     
/*     */     public String fullName;
/*     */ 
/*     */     
/*     */     public String fontFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class FcCompFont
/*     */   {
/*     */     public String fcName;
/*     */     
/*     */     public String fcFamily;
/*     */     
/*     */     public int style;
/*     */     
/*     */     public FontConfigManager.FontConfigFont firstFont;
/*     */     
/*     */     public FontConfigManager.FontConfigFont[] allFonts;
/*     */   }
/*     */   
/*  89 */   private static final String[] fontConfigNames = new String[] { "sans:regular:roman", "sans:bold:roman", "sans:regular:italic", "sans:bold:italic", "serif:regular:roman", "serif:bold:roman", "serif:regular:italic", "serif:bold:italic", "monospace:regular:roman", "monospace:bold:roman", "monospace:regular:italic", "monospace:bold:italic" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static FcCompFont[] fontConfigFonts;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String defaultFontFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] getFontConfigNames() {
/* 115 */     return fontConfigNames;
/*     */   }
/*     */   
/*     */   private static String getFCLocaleStr() {
/* 119 */     Locale locale = Locale.getDefault();
/* 120 */     String str1 = locale.getLanguage();
/* 121 */     String str2 = locale.getCountry();
/* 122 */     if (!str2.equals("")) {
/* 123 */       str1 = str1 + "-" + str1;
/*     */     }
/* 125 */     return str1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized void initFontConfigLogFonts() {
/*     */     boolean bool;
/* 137 */     if (fontConfigFonts != null || fontConfigFailed) {
/*     */       return;
/*     */     }
/*     */     
/* 141 */     long l = 0L;
/* 142 */     if (debugFonts) {
/* 143 */       l = System.nanoTime();
/*     */     }
/*     */     
/* 146 */     String[] arrayOfString = getFontConfigNames();
/* 147 */     FcCompFont[] arrayOfFcCompFont = new FcCompFont[arrayOfString.length];
/*     */     byte b1;
/* 149 */     for (b1 = 0; b1 < arrayOfFcCompFont.length; b1++) {
/* 150 */       arrayOfFcCompFont[b1] = new FcCompFont();
/* 151 */       (arrayOfFcCompFont[b1]).fcName = arrayOfString[b1];
/* 152 */       int i = (arrayOfFcCompFont[b1]).fcName.indexOf(':');
/* 153 */       (arrayOfFcCompFont[b1]).fcFamily = (arrayOfFcCompFont[b1]).fcName.substring(0, i);
/* 154 */       (arrayOfFcCompFont[b1]).style = b1 % 4;
/*     */     } 
/*     */     
/* 157 */     b1 = 0;
/* 158 */     if (useFontConfig) {
/* 159 */       bool = getFontConfig(getFCLocaleStr(), arrayOfFcCompFont, true);
/*     */     }
/* 161 */     else if (debugFonts) {
/* 162 */       System.err.println("Not using FontConfig");
/*     */     } 
/*     */ 
/*     */     
/* 166 */     if (useEmbeddedFontSupport || !bool)
/*     */     {
/*     */       
/* 169 */       EmbeddedFontSupport.initLogicalFonts(arrayOfFcCompFont);
/*     */     }
/* 171 */     FontConfigFont fontConfigFont = null;
/*     */     byte b2;
/* 173 */     for (b2 = 0; b2 < arrayOfFcCompFont.length; b2++) {
/* 174 */       FcCompFont fcCompFont = arrayOfFcCompFont[b2];
/* 175 */       if (fcCompFont.firstFont == null) {
/* 176 */         if (debugFonts) {
/* 177 */           System.err.println("Fontconfig returned no font for " + (arrayOfFcCompFont[b2]).fcName);
/*     */         }
/*     */         
/* 180 */         fontConfigFailed = true;
/* 181 */       } else if (fontConfigFont == null) {
/* 182 */         fontConfigFont = fcCompFont.firstFont;
/* 183 */         defaultFontFile = fontConfigFont.fontFile;
/*     */       } 
/*     */     } 
/*     */     
/* 187 */     if (fontConfigFont == null) {
/* 188 */       fontConfigFailed = true;
/* 189 */       System.err.println("Error: JavaFX detected no fonts! Please refer to release notes for proper font configuration");
/*     */       return;
/*     */     } 
/* 192 */     if (fontConfigFailed) {
/* 193 */       for (b2 = 0; b2 < arrayOfFcCompFont.length; b2++) {
/* 194 */         if ((arrayOfFcCompFont[b2]).firstFont == null) {
/* 195 */           (arrayOfFcCompFont[b2]).firstFont = fontConfigFont;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 200 */     fontConfigFonts = arrayOfFcCompFont;
/*     */     
/* 202 */     if (debugFonts) {
/*     */       
/* 204 */       long l1 = System.nanoTime();
/* 205 */       System.err.println("Time spent accessing fontconfig=" + (l1 - l) / 1000000L + "ms.");
/*     */ 
/*     */       
/* 208 */       for (byte b = 0; b < fontConfigFonts.length; b++) {
/* 209 */         FcCompFont fcCompFont = fontConfigFonts[b];
/* 210 */         System.err.println("FC font " + fcCompFont.fcName + " maps to " + fcCompFont.firstFont.fullName + " in file " + fcCompFont.firstFont.fontFile);
/*     */ 
/*     */         
/* 213 */         if (fcCompFont.allFonts != null) {
/* 214 */           for (byte b3 = 0; b3 < fcCompFont.allFonts.length; b3++) {
/* 215 */             FontConfigFont fontConfigFont1 = fcCompFont.allFonts[b3];
/* 216 */             System.err.println(" " + b3 + ") Family=" + fontConfigFont1.familyName + ", Style=" + fontConfigFont1.styleStr + ", Fullname=" + fontConfigFont1.fullName + ", File=" + fontConfigFont1.fontFile);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void populateMaps(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale) {
/* 239 */     boolean bool = false;
/* 240 */     if (useFontConfig && !fontConfigFailed) {
/* 241 */       bool = populateMapsNative(paramHashMap1, paramHashMap2, paramHashMap, paramLocale);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 246 */     if (fontConfigFailed || useEmbeddedFontSupport || !bool)
/*     */     {
/*     */       
/* 249 */       EmbeddedFontSupport.populateMaps(paramHashMap1, paramHashMap2, paramHashMap, paramLocale);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String mapFxToFcLogicalFamilyName(String paramString) {
/* 256 */     if (paramString.equals("serif"))
/* 257 */       return "serif"; 
/* 258 */     if (paramString.equals("monospaced")) {
/* 259 */       return "monospace";
/*     */     }
/* 261 */     return "sans";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FcCompFont getFontConfigFont(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 268 */     initFontConfigLogFonts();
/*     */     
/* 270 */     if (fontConfigFonts == null) {
/* 271 */       return null;
/*     */     }
/*     */     
/* 274 */     String str = mapFxToFcLogicalFamilyName(paramString.toLowerCase());
/* 275 */     boolean bool = paramBoolean1 ? true : false;
/* 276 */     if (paramBoolean2) {
/* 277 */       bool += true;
/*     */     }
/*     */     
/* 280 */     FcCompFont fcCompFont = null;
/* 281 */     for (byte b = 0; b < fontConfigFonts.length; b++) {
/* 282 */       if (str.equals((fontConfigFonts[b]).fcFamily) && bool == (fontConfigFonts[b]).style) {
/*     */         
/* 284 */         fcCompFont = fontConfigFonts[b];
/*     */         break;
/*     */       } 
/*     */     } 
/* 288 */     if (fcCompFont == null) {
/* 289 */       fcCompFont = fontConfigFonts[0];
/*     */     }
/*     */     
/* 292 */     if (debugFonts) {
/* 293 */       System.err.println("FC name=" + str + " style=" + bool + " uses " + fcCompFont.firstFont.fullName + " in file: " + fcCompFont.firstFont.fontFile);
/*     */     }
/*     */ 
/*     */     
/* 297 */     return fcCompFont;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getDefaultFontPath() {
/* 302 */     if (fontConfigFonts == null && !fontConfigFailed)
/*     */     {
/* 304 */       getFontConfigFont("System", false, false);
/*     */     }
/* 306 */     return defaultFontFile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getFileNames(FcCompFont paramFcCompFont, boolean paramBoolean) {
/* 312 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 314 */     if (paramFcCompFont.allFonts != null) {
/* 315 */       byte b1 = paramBoolean ? 1 : 0;
/* 316 */       for (byte b2 = b1; b2 < paramFcCompFont.allFonts.length; b2++) {
/* 317 */         arrayList.add((paramFcCompFont.allFonts[b2]).fontFile);
/*     */       }
/*     */     } 
/* 320 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> getFontNames(FcCompFont paramFcCompFont, boolean paramBoolean) {
/* 326 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/* 328 */     if (paramFcCompFont.allFonts != null) {
/* 329 */       byte b1 = paramBoolean ? 1 : 0;
/* 330 */       for (byte b2 = b1; b2 < paramFcCompFont.allFonts.length; b2++) {
/* 331 */         arrayList.add((paramFcCompFont.allFonts[b2]).fullName);
/*     */       }
/*     */     } 
/* 334 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   private static native boolean getFontConfig(String paramString, FcCompFont[] paramArrayOfFcCompFont, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   private static native boolean populateMapsNative(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale);
/*     */ 
/*     */   
/*     */   private static class EmbeddedFontSupport
/*     */   {
/* 346 */     private static String fontDirProp = null;
/*     */     
/*     */     private static String fontDir;
/*     */     private static boolean fontDirFromJRE = false;
/*     */     
/*     */     static {
/* 352 */       Void void_ = AccessController.<Void>doPrivileged(() -> {
/*     */             initEmbeddedFonts();
/*     */             return null;
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private static void initEmbeddedFonts() {
/* 361 */       fontDirProp = System.getProperty("prism.fontdir");
/* 362 */       if (fontDirProp != null) {
/* 363 */         fontDir = fontDirProp;
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 368 */           String str = System.getProperty("java.home");
/* 369 */           if (str == null) {
/*     */             return;
/*     */           }
/* 372 */           File file = new File(str, "lib/fonts");
/* 373 */           if (file.exists()) {
/* 374 */             fontDirFromJRE = true;
/* 375 */             fontDir = file.getPath();
/*     */           } 
/* 377 */           if (FontConfigManager.debugFonts) {
/* 378 */             System.err.println("Fallback fontDir is " + file + " exists = " + file
/*     */                 
/* 380 */                 .exists());
/*     */           }
/* 382 */         } catch (Exception exception) {
/* 383 */           if (FontConfigManager.debugFonts) {
/* 384 */             exception.printStackTrace();
/*     */           }
/* 386 */           fontDir = "/";
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private static String getStyleStr(int param1Int) {
/* 392 */       switch (param1Int) { case 0:
/* 393 */           return "regular";
/* 394 */         case 1: return "bold";
/* 395 */         case 2: return "italic";
/* 396 */         case 3: return "bolditalic"; }
/* 397 */        return "regular";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean exists(File param1File) {
/* 404 */       return ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(param1File.exists()))).booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 411 */     static String[] jreFontsProperties = new String[] { "sans.regular.0.font", "Lucida Sans Regular", "sans.regular.0.file", "LucidaSansRegular.ttf", "sans.bold.0.font", "Lucida Sans Bold", "sans.bold.0.file", "LucidaSansDemiBold.ttf", "monospace.regular.0.font", "Lucida Typewriter Regular", "monospace.regular.0.file", "LucidaTypewriterRegular.ttf", "monospace.bold.0.font", "Lucida Typewriter Bold", "monospace.bold.0.file", "LucidaTypewriterBold.ttf", "serif.regular.0.font", "Lucida Bright", "serif.regular.0.file", "LucidaBrightRegular.ttf", "serif.bold.0.font", "Lucida Bright Demibold", "serif.bold.0.file", "LucidaBrightDemiBold.ttf", "serif.italic.0.font", "Lucida Bright Italic", "serif.italic.0.file", "LucidaBrightItalic.ttf", "serif.bolditalic.0.font", "Lucida Bright Demibold Italic", "serif.bolditalic.0.file", "LucidaBrightDemiItalic.ttf" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static void initLogicalFonts(FontConfigManager.FcCompFont[] param1ArrayOfFcCompFont) {
/* 453 */       Properties properties = new Properties();
/*     */       try {
/* 455 */         File file = new File(fontDir, "logicalfonts.properties");
/* 456 */         if (file.exists()) {
/* 457 */           FileInputStream fileInputStream = new FileInputStream(file);
/* 458 */           properties.load(fileInputStream);
/* 459 */           fileInputStream.close();
/* 460 */         } else if (fontDirFromJRE) {
/*     */ 
/*     */ 
/*     */           
/* 464 */           for (byte b1 = 0; b1 < jreFontsProperties.length; b1 += 2) {
/* 465 */             properties.setProperty(jreFontsProperties[b1], jreFontsProperties[b1 + 1]);
/*     */           }
/* 467 */           if (FontConfigManager.debugFonts) {
/* 468 */             System.err.println("Using fallback implied logicalfonts.properties");
/*     */           }
/*     */         } 
/* 471 */       } catch (IOException iOException) {
/* 472 */         if (FontConfigManager.debugFonts) {
/* 473 */           System.err.println(iOException);
/*     */           return;
/*     */         } 
/*     */       } 
/* 477 */       for (byte b = 0; b < param1ArrayOfFcCompFont.length; b++) {
/* 478 */         String str1 = (param1ArrayOfFcCompFont[b]).fcFamily;
/* 479 */         String str2 = getStyleStr((param1ArrayOfFcCompFont[b]).style);
/* 480 */         String str3 = str1 + "." + str1 + ".";
/* 481 */         ArrayList<FontConfigManager.FontConfigFont> arrayList = new ArrayList();
/*     */         
/* 483 */         byte b1 = 0;
/*     */         while (true) {
/* 485 */           String str4 = properties.getProperty(str3 + str3 + ".file");
/* 486 */           String str5 = properties.getProperty(str3 + str3 + ".font");
/* 487 */           b1++;
/* 488 */           if (str4 == null) {
/*     */             break;
/*     */           }
/* 491 */           File file = new File(fontDir, str4);
/* 492 */           if (!exists(file)) {
/* 493 */             if (FontConfigManager.debugFonts) {
/* 494 */               System.out.println("Failed to find logical font file " + file);
/*     */             }
/*     */             continue;
/*     */           } 
/* 498 */           FontConfigManager.FontConfigFont fontConfigFont = new FontConfigManager.FontConfigFont();
/* 499 */           fontConfigFont.fontFile = file.getPath();
/* 500 */           fontConfigFont.fullName = str5;
/* 501 */           fontConfigFont.familyName = null;
/* 502 */           fontConfigFont.styleStr = null;
/* 503 */           if ((param1ArrayOfFcCompFont[b]).firstFont == null) {
/* 504 */             (param1ArrayOfFcCompFont[b]).firstFont = fontConfigFont;
/*     */           }
/* 506 */           arrayList.add(fontConfigFont);
/*     */         } 
/* 508 */         if (arrayList.size() > 0) {
/* 509 */           (param1ArrayOfFcCompFont[b]).allFonts = new FontConfigManager.FontConfigFont[arrayList.size()];
/* 510 */           arrayList.toArray((param1ArrayOfFcCompFont[b]).allFonts);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static void populateMaps(HashMap<String, String> param1HashMap1, HashMap<String, String> param1HashMap2, HashMap<String, ArrayList<String>> param1HashMap, Locale param1Locale) {
/* 547 */       Properties properties = new Properties();
/*     */       
/* 549 */       Void void_ = AccessController.<Void>doPrivileged(() -> {
/*     */             try {
/*     */               String str = fontDir + "/allfonts.properties";
/*     */               
/*     */               FileInputStream fileInputStream = new FileInputStream(str);
/*     */               param1Properties.load(fileInputStream);
/*     */               fileInputStream.close();
/* 556 */             } catch (IOException iOException) {
/*     */               param1Properties.clear();
/*     */               
/*     */               if (FontConfigManager.debugFonts) {
/*     */                 System.err.println(iOException);
/*     */                 
/*     */                 System.err.println("Fall back to opening the files");
/*     */               } 
/*     */             } 
/*     */             return null;
/*     */           });
/* 567 */       if (!properties.isEmpty()) {
/* 568 */         int i = Integer.MAX_VALUE;
/*     */         try {
/* 570 */           i = Integer.parseInt(properties.getProperty("maxFont", ""));
/* 571 */         } catch (NumberFormatException numberFormatException) {}
/*     */         
/* 573 */         if (i <= 0) {
/* 574 */           i = Integer.MAX_VALUE;
/*     */         }
/* 576 */         for (byte b = 0; b < i; b++) {
/* 577 */           String str1 = properties.getProperty("family." + b);
/* 578 */           String str2 = properties.getProperty("font." + b);
/* 579 */           String str3 = properties.getProperty("file." + b);
/* 580 */           if (str3 == null) {
/*     */             break;
/*     */           }
/* 583 */           File file = new File(fontDir, str3);
/* 584 */           if (exists(file))
/*     */           {
/*     */             
/* 587 */             if (str1 != null && str2 != null) {
/*     */ 
/*     */               
/* 590 */               String str4 = str2.toLowerCase(Locale.ENGLISH);
/* 591 */               String str5 = str1.toLowerCase(Locale.ENGLISH);
/* 592 */               param1HashMap1.put(str4, file.getPath());
/* 593 */               param1HashMap2.put(str4, str1);
/*     */               
/* 595 */               ArrayList<String> arrayList = param1HashMap.get(str5);
/* 596 */               if (arrayList == null) {
/* 597 */                 arrayList = new ArrayList(4);
/* 598 */                 param1HashMap.put(str5, arrayList);
/*     */               } 
/* 600 */               arrayList.add(str2);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\FontConfigManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */