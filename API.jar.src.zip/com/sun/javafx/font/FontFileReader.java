/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontFileReader
/*     */   implements FontConstants
/*     */ {
/*     */   String filename;
/*     */   long filesize;
/*     */   RandomAccessFile raFile;
/*     */   private static final int READBUFFERSIZE = 1024;
/*     */   private byte[] readBuffer;
/*     */   private int readBufferLen;
/*     */   private int readBufferStart;
/*     */   
/*     */   public FontFileReader(String paramString) {
/*  44 */     this.filename = paramString;
/*     */   }
/*     */   
/*     */   public String getFilename() {
/*  48 */     return this.filename;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean openFile() throws PrivilegedActionException {
/*  59 */     if (this.raFile != null) {
/*  60 */       return false;
/*     */     }
/*  62 */     this.raFile = AccessController.<RandomAccessFile>doPrivileged(() -> {
/*     */           
/*     */           try {
/*     */             return new RandomAccessFile(this.filename, "r");
/*  66 */           } catch (FileNotFoundException fileNotFoundException) {
/*     */             return null;
/*     */           } 
/*     */         });
/*     */     
/*  71 */     if (this.raFile != null) {
/*     */       try {
/*  73 */         this.filesize = this.raFile.length();
/*  74 */         return true;
/*  75 */       } catch (IOException iOException) {}
/*     */     }
/*     */     
/*  78 */     return false;
/*     */   }
/*     */   
/*     */   public synchronized void closeFile() throws IOException {
/*  82 */     if (this.raFile != null) {
/*  83 */       this.raFile.close();
/*  84 */       this.raFile = null;
/*  85 */       this.readBuffer = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized long getLength() {
/*  90 */     return this.filesize;
/*     */   }
/*     */   
/*     */   public synchronized void reset() throws IOException {
/*  94 */     if (this.raFile != null) {
/*  95 */       this.raFile.seek(0L);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class Buffer
/*     */   {
/*     */     byte[] data;
/*     */ 
/*     */     
/*     */     int pos;
/*     */     
/*     */     int orig;
/*     */ 
/*     */     
/*     */     Buffer(byte[] param1ArrayOfbyte, int param1Int) {
/* 112 */       this.orig = this.pos = param1Int;
/* 113 */       this.data = param1ArrayOfbyte;
/*     */     }
/*     */     
/*     */     int getInt(int param1Int) {
/* 117 */       param1Int += this.orig;
/* 118 */       int i = this.data[param1Int++] & 0xFF;
/* 119 */       i <<= 8;
/* 120 */       i |= this.data[param1Int++] & 0xFF;
/* 121 */       i <<= 8;
/* 122 */       i |= this.data[param1Int++] & 0xFF;
/* 123 */       i <<= 8;
/* 124 */       i |= this.data[param1Int++] & 0xFF;
/* 125 */       return i;
/*     */     }
/*     */     
/*     */     int getInt() {
/* 129 */       int i = this.data[this.pos++] & 0xFF;
/* 130 */       i <<= 8;
/* 131 */       i |= this.data[this.pos++] & 0xFF;
/* 132 */       i <<= 8;
/* 133 */       i |= this.data[this.pos++] & 0xFF;
/* 134 */       i <<= 8;
/* 135 */       i |= this.data[this.pos++] & 0xFF;
/* 136 */       return i;
/*     */     }
/*     */     
/*     */     short getShort(int param1Int) {
/* 140 */       param1Int += this.orig;
/* 141 */       int i = this.data[param1Int++] & 0xFF;
/* 142 */       i <<= 8;
/* 143 */       i |= this.data[param1Int++] & 0xFF;
/* 144 */       return (short)i;
/*     */     }
/*     */     
/*     */     short getShort() {
/* 148 */       int i = this.data[this.pos++] & 0xFF;
/* 149 */       i <<= 8;
/* 150 */       i |= this.data[this.pos++] & 0xFF;
/* 151 */       return (short)i;
/*     */     }
/*     */     
/*     */     char getChar(int param1Int) {
/* 155 */       param1Int += this.orig;
/* 156 */       int i = this.data[param1Int++] & 0xFF;
/* 157 */       i <<= 8;
/* 158 */       i |= this.data[param1Int++] & 0xFF;
/* 159 */       return (char)i;
/*     */     }
/*     */     
/*     */     char getChar() {
/* 163 */       int i = this.data[this.pos++] & 0xFF;
/* 164 */       i <<= 8;
/* 165 */       i |= this.data[this.pos++] & 0xFF;
/* 166 */       return (char)i;
/*     */     }
/*     */     
/*     */     void position(int param1Int) {
/* 170 */       this.pos = this.orig + param1Int;
/*     */     }
/*     */     
/*     */     int capacity() {
/* 174 */       return this.data.length - this.orig;
/*     */     }
/*     */     
/*     */     byte get() {
/* 178 */       return this.data[this.pos++];
/*     */     }
/*     */     
/*     */     byte get(int param1Int) {
/* 182 */       param1Int += this.orig;
/* 183 */       return this.data[param1Int];
/*     */     }
/*     */     
/*     */     void skip(int param1Int) {
/* 187 */       this.pos += param1Int;
/*     */     }
/*     */     
/*     */     void get(int param1Int1, byte[] param1ArrayOfbyte, int param1Int2, int param1Int3) {
/* 191 */       System.arraycopy(this.data, this.orig + param1Int1, param1ArrayOfbyte, param1Int2, param1Int3);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized int readFromFile(byte[] paramArrayOfbyte, long paramLong, int paramInt) {
/*     */     try {
/* 205 */       this.raFile.seek(paramLong);
/*     */       
/* 207 */       return this.raFile.read(paramArrayOfbyte, 0, paramInt);
/*     */     }
/* 209 */     catch (IOException iOException) {
/* 210 */       if (PrismFontFactory.debugFonts) {
/* 211 */         iOException.printStackTrace();
/*     */       }
/* 213 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Buffer readBlock(int paramInt1, int paramInt2) {
/* 234 */     if (this.readBuffer == null) {
/* 235 */       this.readBuffer = new byte[1024];
/* 236 */       this.readBufferLen = 0;
/*     */     } 
/*     */     
/* 239 */     if (paramInt2 <= 1024) {
/* 240 */       if (this.readBufferStart <= paramInt1 && this.readBufferStart + this.readBufferLen >= paramInt1 + paramInt2)
/*     */       {
/*     */         
/* 243 */         return new Buffer(this.readBuffer, paramInt1 - this.readBufferStart);
/*     */       }
/* 245 */       this.readBufferStart = paramInt1;
/* 246 */       this
/* 247 */         .readBufferLen = ((paramInt1 + 1024) > this.filesize) ? ((int)this.filesize - paramInt1) : 1024;
/* 248 */       readFromFile(this.readBuffer, this.readBufferStart, this.readBufferLen);
/* 249 */       return new Buffer(this.readBuffer, 0);
/*     */     } 
/*     */     
/* 252 */     byte[] arrayOfByte = new byte[paramInt2];
/* 253 */     readFromFile(arrayOfByte, paramInt1, paramInt2);
/* 254 */     return new Buffer(arrayOfByte, 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\FontFileReader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */