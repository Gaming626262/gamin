/*    */ package com.sun.javafx.font;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CompositeStrikeDisposer
/*    */   implements DisposerRecord
/*    */ {
/*    */   FontResource fontResource;
/*    */   FontStrikeDesc desc;
/*    */   boolean disposed = false;
/*    */   
/*    */   public CompositeStrikeDisposer(FontResource paramFontResource, FontStrikeDesc paramFontStrikeDesc) {
/* 40 */     this.fontResource = paramFontResource;
/* 41 */     this.desc = paramFontStrikeDesc;
/*    */   }
/*    */   
/*    */   public synchronized void dispose() {
/* 45 */     if (!this.disposed) {
/*    */ 
/*    */ 
/*    */       
/* 49 */       WeakReference<Object> weakReference = (WeakReference)this.fontResource.getStrikeMap().get(this.desc);
/* 50 */       if (weakReference != null) {
/* 51 */         Object object = weakReference.get();
/* 52 */         if (object == null) {
/* 53 */           this.fontResource.getStrikeMap().remove(this.desc);
/*    */         }
/*    */       } 
/*    */       
/* 57 */       this.disposed = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\CompositeStrikeDisposer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */