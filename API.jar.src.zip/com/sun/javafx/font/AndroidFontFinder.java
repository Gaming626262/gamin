/*     */ package com.sun.javafx.font;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AndroidFontFinder
/*     */ {
/*     */   private static final String SYSTEM_FONT_NAME = "sans serif";
/*     */   private static final float SYSTEM_FONT_SIZE = 16.0F;
/*     */   static final String fontDescriptor_2_X_Path = "/com/sun/javafx/font/android_system_fonts.xml";
/*     */   static final String fontDescriptor_4_X_Path = "/system/etc/system_fonts.xml";
/*     */   static final String systemFontsDir = "/system/fonts";
/*     */   
/*     */   static {
/*  67 */     Void void_ = AccessController.<Void>doPrivileged(() -> {
/*     */           NativeLibLoader.loadLibrary("javafx_font");
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   public static String getSystemFont() {
/*  74 */     return "sans serif";
/*     */   }
/*     */   
/*     */   public static float getSystemFontSize() {
/*  78 */     return 16.0F;
/*     */   }
/*     */   
/*     */   public static String getSystemFontsDir() {
/*  82 */     return "/system/fonts";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parse_2_X_SystemDefaultFonts(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap) {
/*  91 */     InputStream inputStream = AndroidFontFinder.class.getResourceAsStream("/com/sun/javafx/font/android_system_fonts.xml");
/*  92 */     if (inputStream == null) {
/*  93 */       System.err
/*  94 */         .println("Resource not found: /com/sun/javafx/font/android_system_fonts.xml");
/*  95 */       return false;
/*     */     } 
/*  97 */     return parseSystemDefaultFonts(inputStream, paramHashMap1, paramHashMap2, paramHashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parse_4_X_SystemDefaultFonts(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap) {
/* 105 */     File file = new File("/system/etc/system_fonts.xml");
/*     */     try {
/* 107 */       return parseSystemDefaultFonts(new FileInputStream(file), paramHashMap1, paramHashMap2, paramHashMap);
/*     */     
/*     */     }
/* 110 */     catch (FileNotFoundException fileNotFoundException) {
/* 111 */       System.err.println("File not found: /system/etc/system_fonts.xml");
/*     */       
/* 113 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean parseSystemDefaultFonts(InputStream paramInputStream, final HashMap<String, String> fontToFileMap, final HashMap<String, String> fontToFamilyNameMap, final HashMap<String, ArrayList<String>> familyToFontListMap) {
/*     */     try {
/* 123 */       SAXParserFactory sAXParserFactory = SAXParserFactory.newInstance();
/* 124 */       SAXParser sAXParser = sAXParserFactory.newSAXParser();
/*     */       
/* 126 */       DefaultHandler defaultHandler = new DefaultHandler()
/*     */         {
/*     */           private static final char DASH = '-';
/*     */           private static final String FAMILY = "family";
/*     */           private static final String FILE = "file";
/*     */           private static final String FILESET = "fileset";
/*     */           private static final String NAME = "name";
/*     */           private static final String NAMESET = "nameset";
/*     */           private static final char SPACE = ' ';
/* 135 */           final List<String> filesets = new ArrayList<>();
/*     */           
/*     */           boolean inFamily = false;
/*     */           
/*     */           boolean inFile = false;
/*     */           boolean inFileset = false;
/*     */           boolean inName = false;
/*     */           boolean inNameset = false;
/* 143 */           private final List<String> namesets = new ArrayList<>();
/* 144 */           private final String[] styles = new String[] { "regular", "bold", "italic", "bold italic" };
/*     */ 
/*     */ 
/*     */           
/*     */           public void characters(char[] param1ArrayOfchar, int param1Int1, int param1Int2) throws SAXException {
/* 149 */             if (this.inName) {
/*     */               
/* 151 */               String str = (new String(param1ArrayOfchar, param1Int1, param1Int2)).toLowerCase();
/* 152 */               this.namesets.add(str);
/* 153 */             } else if (this.inFile) {
/* 154 */               String str = new String(param1ArrayOfchar, param1Int1, param1Int2);
/* 155 */               this.filesets.add(str);
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/*     */           public void endElement(String param1String1, String param1String2, String param1String3) throws SAXException {
/* 161 */             if (param1String3.equalsIgnoreCase("family")) {
/* 162 */               for (String str1 : this.namesets) {
/* 163 */                 byte b = 0;
/* 164 */                 String str2 = str1.replace('-', ' ');
/* 165 */                 for (String str3 : this.filesets) {
/* 166 */                   String str4 = str2 + " " + str2;
/* 167 */                   String str5 = "/system/fonts" + File.separator + str3;
/*     */                   
/* 169 */                   File file = new File(str5);
/* 170 */                   if (!file.exists() || !file.canRead()) {
/*     */                     continue;
/*     */                   }
/* 173 */                   fontToFileMap.put(str4, str5);
/* 174 */                   fontToFamilyNameMap.put(str4, str2);
/*     */                   
/* 176 */                   ArrayList<String> arrayList = (ArrayList)familyToFontListMap.get(str2);
/* 177 */                   if (arrayList == null) {
/* 178 */                     arrayList = new ArrayList();
/* 179 */                     familyToFontListMap.put(str2, arrayList);
/*     */                   } 
/* 181 */                   arrayList.add(str4);
/* 182 */                   b++;
/*     */                 } 
/*     */               } 
/* 185 */               this.inFamily = false;
/* 186 */             } else if (param1String3.equalsIgnoreCase("nameset")) {
/* 187 */               this.inNameset = false;
/* 188 */             } else if (param1String3.equalsIgnoreCase("fileset")) {
/* 189 */               this.inFileset = false;
/* 190 */             } else if (param1String3.equalsIgnoreCase("name")) {
/* 191 */               this.inName = false;
/* 192 */             } else if (param1String3.equalsIgnoreCase("file")) {
/* 193 */               this.inFile = false;
/*     */             } 
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void startElement(String param1String1, String param1String2, String param1String3, Attributes param1Attributes) throws SAXException {
/* 201 */             if (param1String3.equalsIgnoreCase("family")) {
/* 202 */               this.inFamily = true;
/* 203 */               this.namesets.clear();
/* 204 */               this.filesets.clear();
/* 205 */             } else if (param1String3.equalsIgnoreCase("nameset")) {
/* 206 */               this.inNameset = true;
/* 207 */             } else if (param1String3.equalsIgnoreCase("fileset")) {
/* 208 */               this.inFileset = true;
/* 209 */             } else if (param1String3.equalsIgnoreCase("name")) {
/* 210 */               this.inName = true;
/* 211 */             } else if (param1String3.equalsIgnoreCase("file")) {
/* 212 */               this.inFile = true;
/*     */             } 
/*     */           }
/*     */         };
/*     */       
/* 217 */       sAXParser.parse(paramInputStream, defaultHandler);
/* 218 */       return true;
/*     */     }
/* 220 */     catch (IOException iOException) {
/* 221 */       System.err.println("Failed to load default fonts descriptor: /system/etc/system_fonts.xml");
/*     */     }
/* 223 */     catch (Exception exception) {
/* 224 */       System.err.println("Failed parsing default fonts descriptor;");
/* 225 */       exception.printStackTrace();
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void populateFontFileNameMap(HashMap<String, String> paramHashMap1, HashMap<String, String> paramHashMap2, HashMap<String, ArrayList<String>> paramHashMap, Locale paramLocale) {
/* 236 */     if (paramHashMap1 == null || paramHashMap2 == null || paramHashMap == null) {
/*     */       return;
/*     */     }
/*     */     
/* 240 */     if (paramLocale == null) {
/* 241 */       paramLocale = Locale.ENGLISH;
/*     */     }
/*     */     
/* 244 */     boolean bool = parse_4_X_SystemDefaultFonts(paramHashMap1, paramHashMap2, paramHashMap);
/*     */     
/* 246 */     if (!bool)
/* 247 */       parse_2_X_SystemDefaultFonts(paramHashMap1, paramHashMap2, paramHashMap); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\AndroidFontFinder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */