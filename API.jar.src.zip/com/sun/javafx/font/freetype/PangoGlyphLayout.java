/*     */ package com.sun.javafx.font.freetype;
/*     */ 
/*     */ import com.sun.javafx.font.CompositeFontResource;
/*     */ import com.sun.javafx.font.FontResource;
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PangoGlyphLayout
/*     */   extends GlyphLayout
/*     */ {
/*  45 */   private static final long fontmap = OSPango.pango_ft2_font_map_new();
/*     */ 
/*     */   
/*     */   private int getSlot(PGFont paramPGFont, PangoGlyphString paramPangoGlyphString) {
/*  49 */     CompositeFontResource compositeFontResource = (CompositeFontResource)paramPGFont.getFontResource();
/*  50 */     long l1 = paramPangoGlyphString.font;
/*  51 */     long l2 = OSPango.pango_font_describe(l1);
/*  52 */     String str1 = OSPango.pango_font_description_get_family(l2);
/*  53 */     int i = OSPango.pango_font_description_get_style(l2);
/*  54 */     int j = OSPango.pango_font_description_get_weight(l2);
/*  55 */     OSPango.pango_font_description_free(l2);
/*  56 */     boolean bool1 = (j == 700) ? true : false;
/*  57 */     boolean bool2 = (i != 0) ? true : false;
/*     */     
/*  59 */     PrismFontFactory prismFontFactory = PrismFontFactory.getFontFactory();
/*  60 */     PGFont pGFont = prismFontFactory.createFont(str1, bool1, bool2, paramPGFont
/*  61 */         .getSize());
/*  62 */     String str2 = pGFont.getFullName();
/*  63 */     String str3 = compositeFontResource.getSlotResource(0).getFullName();
/*     */     
/*  65 */     int k = 0;
/*  66 */     if (!str2.equalsIgnoreCase(str3)) {
/*  67 */       k = compositeFontResource.getSlotForFont(str2);
/*  68 */       if (PrismFontFactory.debugFonts) {
/*  69 */         System.err.println("\tFallback font= " + str2 + " slot=" + (k >> 24));
/*     */       }
/*     */     } 
/*  72 */     return k;
/*     */   }
/*     */   
/*     */   private boolean check(long paramLong1, String paramString, long paramLong2, long paramLong3, long paramLong4) {
/*  76 */     if (paramLong1 != 0L) return false; 
/*  77 */     if (paramString != null && PrismFontFactory.debugFonts) {
/*  78 */       System.err.println(paramString);
/*     */     }
/*     */     
/*  81 */     if (paramLong4 != 0L) OSPango.pango_attr_list_unref(paramLong4); 
/*  82 */     if (paramLong3 != 0L) OSPango.pango_font_description_free(paramLong3); 
/*  83 */     if (paramLong2 != 0L) OSPango.g_object_unref(paramLong2); 
/*  84 */     return true;
/*     */   }
/*     */   
/*  87 */   private Map<TextRun, Long> runUtf8 = new LinkedHashMap<>();
/*     */   
/*     */   public void layout(TextRun paramTextRun, PGFont paramPGFont, FontStrike paramFontStrike, char[] paramArrayOfchar) {
/*  90 */     FontResource fontResource = paramPGFont.getFontResource();
/*  91 */     boolean bool = fontResource instanceof CompositeFontResource;
/*  92 */     if (bool) {
/*  93 */       fontResource = ((CompositeFontResource)fontResource).getSlotResource(0);
/*     */     }
/*  95 */     if (check(fontmap, "Failed allocating PangoFontMap.", 0L, 0L, 0L)) {
/*     */       return;
/*     */     }
/*  98 */     long l1 = OSPango.pango_font_map_create_context(fontmap);
/*  99 */     if (check(l1, "Failed allocating PangoContext.", 0L, 0L, 0L)) {
/*     */       return;
/*     */     }
/* 102 */     boolean bool1 = ((paramTextRun.getLevel() & 0x1) != 0) ? true : false;
/* 103 */     if (bool1) {
/* 104 */       OSPango.pango_context_set_base_dir(l1, 1);
/*     */     }
/* 106 */     float f = paramPGFont.getSize();
/* 107 */     boolean bool2 = fontResource.isItalic() ? true : false;
/* 108 */     char c = fontResource.isBold() ? 'ʼ' : 'Ɛ';
/* 109 */     long l2 = OSPango.pango_font_description_new();
/* 110 */     if (check(l2, "Failed allocating FontDescription.", l1, 0L, 0L)) {
/*     */       return;
/*     */     }
/* 113 */     OSPango.pango_font_description_set_family(l2, fontResource.getFamilyName());
/* 114 */     OSPango.pango_font_description_set_absolute_size(l2, (f * 1024.0F));
/* 115 */     OSPango.pango_font_description_set_stretch(l2, 4);
/* 116 */     OSPango.pango_font_description_set_style(l2, bool2);
/* 117 */     OSPango.pango_font_description_set_weight(l2, c);
/* 118 */     long l3 = OSPango.pango_attr_list_new();
/* 119 */     if (check(l3, "Failed allocating PangoAttributeList.", l1, l2, 0L)) {
/*     */       return;
/*     */     }
/* 122 */     long l4 = OSPango.pango_attr_font_desc_new(l2);
/* 123 */     if (check(l4, "Failed allocating PangoAttribute.", l1, l2, l3)) {
/*     */       return;
/*     */     }
/* 126 */     OSPango.pango_attr_list_insert(l3, l4);
/* 127 */     if (!bool) {
/* 128 */       l4 = OSPango.pango_attr_fallback_new(false);
/* 129 */       OSPango.pango_attr_list_insert(l3, l4);
/*     */     } 
/*     */     
/* 132 */     Long long_ = this.runUtf8.get(paramTextRun);
/* 133 */     if (long_ == null) {
/* 134 */       char[] arrayOfChar = Arrays.copyOfRange(paramArrayOfchar, paramTextRun.getStart(), paramTextRun.getEnd());
/* 135 */       long_ = Long.valueOf(OSPango.g_utf16_to_utf8(arrayOfChar));
/* 136 */       if (check(long_.longValue(), "Failed allocating UTF-8 buffer.", l1, l2, l3)) {
/*     */         return;
/*     */       }
/* 139 */       this.runUtf8.put(paramTextRun, long_);
/*     */     } 
/*     */ 
/*     */     
/* 143 */     long l5 = OSPango.g_utf8_strlen(long_.longValue(), -1L);
/* 144 */     long l6 = OSPango.g_utf8_offset_to_pointer(long_.longValue(), l5);
/* 145 */     long l7 = OSPango.pango_itemize(l1, long_.longValue(), 0, (int)(l6 - long_.longValue()), l3, 0L);
/*     */     
/* 147 */     if (l7 != 0L) {
/*     */       
/* 149 */       int i = OSPango.g_list_length(l7);
/* 150 */       PangoGlyphString[] arrayOfPangoGlyphString = new PangoGlyphString[i]; int j;
/* 151 */       for (j = 0; j < i; j++) {
/* 152 */         long l = OSPango.g_list_nth_data(l7, j);
/* 153 */         if (l != 0L) {
/* 154 */           arrayOfPangoGlyphString[j] = OSPango.pango_shape(long_.longValue(), l);
/* 155 */           OSPango.pango_item_free(l);
/*     */         } 
/*     */       } 
/* 158 */       OSPango.g_list_free(l7);
/*     */       
/* 160 */       j = 0;
/* 161 */       for (PangoGlyphString pangoGlyphString : arrayOfPangoGlyphString) {
/* 162 */         if (pangoGlyphString != null) {
/* 163 */           j += pangoGlyphString.num_glyphs;
/*     */         }
/*     */       } 
/* 166 */       int[] arrayOfInt1 = new int[j];
/* 167 */       float[] arrayOfFloat = new float[j * 2 + 2];
/* 168 */       int[] arrayOfInt2 = new int[j];
/* 169 */       int k = 0;
/* 170 */       int m = bool1 ? paramTextRun.getLength() : 0;
/* 171 */       int n = 0;
/* 172 */       for (PangoGlyphString pangoGlyphString : arrayOfPangoGlyphString) {
/* 173 */         if (pangoGlyphString != null) {
/* 174 */           byte b1 = bool ? getSlot(paramPGFont, pangoGlyphString) : 0;
/* 175 */           if (bool1) m -= pangoGlyphString.num_chars; 
/* 176 */           for (byte b2 = 0; b2 < pangoGlyphString.num_glyphs; b2++) {
/* 177 */             int i1 = k + b2;
/* 178 */             if (b1 != -1) {
/* 179 */               int i2 = pangoGlyphString.glyphs[b2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 185 */               if (0 <= i2 && i2 <= 16777215) {
/* 186 */                 arrayOfInt1[i1] = b1 << 24 | i2;
/*     */               }
/*     */             } 
/* 189 */             if (f != 0.0F) {
/* 190 */               n += pangoGlyphString.widths[b2];
/* 191 */               arrayOfFloat[2 + (i1 << 1)] = n / 1024.0F;
/*     */             } 
/* 193 */             arrayOfInt2[i1] = pangoGlyphString.log_clusters[b2] + m;
/*     */           } 
/* 195 */           if (!bool1) m += pangoGlyphString.num_chars; 
/* 196 */           k += pangoGlyphString.num_glyphs;
/*     */         } 
/*     */       } 
/* 199 */       paramTextRun.shape(j, arrayOfInt1, arrayOfFloat, arrayOfInt2);
/*     */     } 
/*     */     
/* 202 */     check(0L, null, l1, l2, l3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 207 */     super.dispose();
/* 208 */     for (Long long_ : this.runUtf8.values()) {
/* 209 */       OSPango.g_free(long_.longValue());
/*     */     }
/* 211 */     this.runUtf8.clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\PangoGlyphLayout.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */