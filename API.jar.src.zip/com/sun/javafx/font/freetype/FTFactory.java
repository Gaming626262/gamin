/*     */ package com.sun.javafx.font.freetype;
/*     */ 
/*     */ import com.sun.javafx.font.FontStrike;
/*     */ import com.sun.javafx.font.PGFont;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.text.GlyphLayout;
/*     */ import com.sun.javafx.text.TextRun;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FTFactory
/*     */   extends PrismFontFactory
/*     */ {
/*     */   static boolean LCD_SUPPORT;
/*     */   
/*     */   public static PrismFontFactory getFactory() {
/*  40 */     FTFactory fTFactory = null;
/*  41 */     long[] arrayOfLong = new long[1];
/*  42 */     int i = OSFreetype.FT_Init_FreeType(arrayOfLong);
/*  43 */     long l = arrayOfLong[0];
/*  44 */     int[] arrayOfInt1 = new int[1], arrayOfInt2 = new int[1], arrayOfInt3 = new int[1];
/*  45 */     if (i == 0) {
/*  46 */       fTFactory = new FTFactory();
/*  47 */       OSFreetype.FT_Library_Version(l, arrayOfInt1, arrayOfInt2, arrayOfInt3);
/*     */ 
/*     */       
/*  50 */       i = OSFreetype.FT_Library_SetLcdFilter(l, 1);
/*  51 */       LCD_SUPPORT = (i == 0);
/*  52 */       OSFreetype.FT_Done_FreeType(l);
/*     */     } 
/*  54 */     if (PrismFontFactory.debugFonts) {
/*  55 */       if (fTFactory != null) {
/*  56 */         String str1 = "" + arrayOfInt1[0] + "." + arrayOfInt1[0] + "." + arrayOfInt2[0];
/*  57 */         System.err.println("Freetype2 Loaded (version " + str1 + ")");
/*  58 */         String str2 = LCD_SUPPORT ? "Enabled" : "Disabled";
/*  59 */         System.err.println("LCD support " + str2);
/*     */       } else {
/*  61 */         System.err.println("Freetype2 Failed (error " + i + ")");
/*     */       } 
/*     */     }
/*  64 */     return fTFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontFile createFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  75 */     return new FTFontFile(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public GlyphLayout createGlyphLayout() {
/*  81 */     if (OSFreetype.isPangoEnabled()) {
/*  82 */       return new PangoGlyphLayout();
/*     */     }
/*  84 */     if (OSFreetype.isHarfbuzzEnabled()) {
/*  85 */       return new HBGlyphLayout();
/*     */     }
/*  87 */     return new StubGlyphLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLCDTextSupported() {
/*  92 */     return (LCD_SUPPORT && super.isLCDTextSupported());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean registerEmbeddedFont(String paramString) {
/*  97 */     long[] arrayOfLong = new long[1];
/*  98 */     int i = OSFreetype.FT_Init_FreeType(arrayOfLong);
/*  99 */     if (i != 0) return false; 
/* 100 */     long l = arrayOfLong[0];
/* 101 */     byte[] arrayOfByte = (paramString + "\000").getBytes();
/* 102 */     i = OSFreetype.FT_New_Face(l, arrayOfByte, 0L, arrayOfLong);
/* 103 */     if (i != 0) {
/* 104 */       long l1 = arrayOfLong[0];
/* 105 */       OSFreetype.FT_Done_Face(l1);
/*     */     } 
/* 107 */     OSFreetype.FT_Done_FreeType(l);
/* 108 */     if (i != 0) return false; 
/* 109 */     if (OSFreetype.isPangoEnabled()) {
/* 110 */       return OSPango.FcConfigAppFontAddFile(0L, paramString);
/*     */     }
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   private static class StubGlyphLayout extends GlyphLayout {
/*     */     public void layout(TextRun param1TextRun, PGFont param1PGFont, FontStrike param1FontStrike, char[] param1ArrayOfchar) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\FTFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */