/*    */ package com.sun.javafx.font.freetype;
/*    */ 
/*    */ import com.sun.javafx.font.DisposerRecord;
/*    */ import com.sun.javafx.font.FontStrikeDesc;
/*    */ import com.sun.javafx.font.Glyph;
/*    */ import com.sun.javafx.font.PrismFontFactory;
/*    */ import com.sun.javafx.font.PrismFontStrike;
/*    */ import com.sun.javafx.geom.Path2D;
/*    */ import com.sun.javafx.geom.transform.BaseTransform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FTFontStrike
/*    */   extends PrismFontStrike<FTFontFile>
/*    */ {
/*    */   FT_Matrix matrix;
/*    */   
/*    */   protected FTFontStrike(FTFontFile paramFTFontFile, float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/* 42 */     super(paramFTFontFile, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/* 43 */     float f = PrismFontFactory.getFontSizeLimit();
/* 44 */     if (paramBaseTransform.isTranslateOrIdentity()) {
/* 45 */       this.drawShapes = (paramFloat > f);
/*    */     } else {
/* 47 */       BaseTransform baseTransform = getTransform();
/* 48 */       this.matrix = new FT_Matrix();
/*    */       
/* 50 */       this.matrix.xx = (int)(baseTransform.getMxx() * 65536.0D);
/* 51 */       this.matrix.yx = (int)(-baseTransform.getMyx() * 65536.0D);
/* 52 */       this.matrix.xy = (int)(-baseTransform.getMxy() * 65536.0D);
/* 53 */       this.matrix.yy = (int)(baseTransform.getMyy() * 65536.0D);
/*    */       
/* 55 */       if (Math.abs(baseTransform.getMxx() * paramFloat) > f || 
/* 56 */         Math.abs(baseTransform.getMyx() * paramFloat) > f || 
/* 57 */         Math.abs(baseTransform.getMxy() * paramFloat) > f || 
/* 58 */         Math.abs(baseTransform.getMyy() * paramFloat) > f)
/*    */       {
/* 60 */         this.drawShapes = true;
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected DisposerRecord createDisposer(FontStrikeDesc paramFontStrikeDesc) {
/* 67 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Glyph createGlyph(int paramInt) {
/* 72 */     return new FTGlyph(this, paramInt, this.drawShapes);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Path2D createGlyphOutline(int paramInt) {
/* 77 */     FTFontFile fTFontFile = (FTFontFile)getFontResource();
/* 78 */     return fTFontFile.createGlyphOutline(paramInt, getSize());
/*    */   }
/*    */   
/*    */   void initGlyph(FTGlyph paramFTGlyph) {
/* 82 */     FTFontFile fTFontFile = (FTFontFile)getFontResource();
/* 83 */     fTFontFile.initGlyph(paramFTGlyph, this);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\FTFontStrike.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */