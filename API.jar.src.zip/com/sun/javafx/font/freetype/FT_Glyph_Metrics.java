package com.sun.javafx.font.freetype;

class FT_Glyph_Metrics {
  long width;
  
  long height;
  
  long horiBearingX;
  
  long horiBearingY;
  
  long horiAdvance;
  
  long vertBearingX;
  
  long vertBearingY;
  
  long vertAdvance;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\FT_Glyph_Metrics.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */