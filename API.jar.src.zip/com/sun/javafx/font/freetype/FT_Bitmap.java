package com.sun.javafx.font.freetype;

class FT_Bitmap {
  int rows;
  
  int width;
  
  int pitch;
  
  long buffer;
  
  short num_grays;
  
  byte pixel_mode;
  
  char palette_mode;
  
  long palette;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\FT_Bitmap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */