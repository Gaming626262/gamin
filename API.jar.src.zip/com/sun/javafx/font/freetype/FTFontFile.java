/*     */ package com.sun.javafx.font.freetype;
/*     */ 
/*     */ import com.sun.javafx.font.Disposer;
/*     */ import com.sun.javafx.font.FontStrikeDesc;
/*     */ import com.sun.javafx.font.PrismFontFactory;
/*     */ import com.sun.javafx.font.PrismFontFile;
/*     */ import com.sun.javafx.font.PrismFontStrike;
/*     */ import com.sun.javafx.geom.Path2D;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FTFontFile
/*     */   extends PrismFontFile
/*     */ {
/*     */   private long library;
/*     */   private long face;
/*     */   private FTDisposer disposer;
/*     */   
/*     */   FTFontFile(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
/*  57 */     super(paramString1, paramString2, paramInt, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
/*  58 */     init();
/*     */   }
/*     */   
/*     */   private synchronized void init() throws Exception {
/*  62 */     long[] arrayOfLong = new long[1];
/*  63 */     int i = OSFreetype.FT_Init_FreeType(arrayOfLong);
/*  64 */     if (i != 0) {
/*  65 */       throw new Exception("FT_Init_FreeType Failed error " + i);
/*     */     }
/*  67 */     this.library = arrayOfLong[0];
/*  68 */     if (FTFactory.LCD_SUPPORT) {
/*  69 */       OSFreetype.FT_Library_SetLcdFilter(this.library, 1);
/*     */     }
/*     */     
/*  72 */     String str = getFileName();
/*  73 */     int j = getFontIndex();
/*     */     
/*  75 */     byte[] arrayOfByte = (str + "\000").getBytes();
/*  76 */     i = OSFreetype.FT_New_Face(this.library, arrayOfByte, j, arrayOfLong);
/*  77 */     if (i != 0) {
/*  78 */       throw new Exception("FT_New_Face Failed error " + i + " Font File " + str + " Font Index " + j);
/*     */     }
/*     */ 
/*     */     
/*  82 */     this.face = arrayOfLong[0];
/*     */     
/*  84 */     if (!isRegistered()) {
/*  85 */       this.disposer = new FTDisposer(this.library, this.face);
/*  86 */       Disposer.addRecord(this, this.disposer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrismFontStrike<?> createStrike(float paramFloat, BaseTransform paramBaseTransform, int paramInt, FontStrikeDesc paramFontStrikeDesc) {
/*  93 */     return new FTFontStrike(this, paramFloat, paramBaseTransform, paramInt, paramFontStrikeDesc);
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized int[] createGlyphBoundingBox(int paramInt) {
/*  98 */     boolean bool = true;
/*  99 */     OSFreetype.FT_Load_Glyph(this.face, paramInt, bool);
/* 100 */     int[] arrayOfInt = new int[4];
/* 101 */     FT_GlyphSlotRec fT_GlyphSlotRec = OSFreetype.getGlyphSlot(this.face);
/* 102 */     if (fT_GlyphSlotRec != null && fT_GlyphSlotRec.metrics != null) {
/* 103 */       FT_Glyph_Metrics fT_Glyph_Metrics = fT_GlyphSlotRec.metrics;
/* 104 */       arrayOfInt[0] = (int)fT_Glyph_Metrics.horiBearingX;
/* 105 */       arrayOfInt[1] = (int)(fT_Glyph_Metrics.horiBearingY - fT_Glyph_Metrics.height);
/* 106 */       arrayOfInt[2] = (int)(fT_Glyph_Metrics.horiBearingX + fT_Glyph_Metrics.width);
/* 107 */       arrayOfInt[3] = (int)fT_Glyph_Metrics.horiBearingY;
/*     */     } 
/* 109 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   synchronized Path2D createGlyphOutline(int paramInt, float paramFloat) {
/* 113 */     int i = (int)(paramFloat * 64.0F);
/* 114 */     OSFreetype.FT_Set_Char_Size(this.face, 0L, i, 72, 72);
/* 115 */     char c = 'ࠊ';
/* 116 */     OSFreetype.FT_Load_Glyph(this.face, paramInt, c);
/* 117 */     return OSFreetype.FT_Outline_Decompose(this.face);
/*     */   }
/*     */   synchronized void initGlyph(FTGlyph paramFTGlyph, FTFontStrike paramFTFontStrike) {
/*     */     byte[] arrayOfByte;
/* 121 */     float f = paramFTFontStrike.getSize();
/* 122 */     if (f == 0.0F) {
/* 123 */       paramFTGlyph.buffer = new byte[0];
/* 124 */       paramFTGlyph.bitmap = new FT_Bitmap();
/*     */       return;
/*     */     } 
/* 127 */     int i = (int)(f * 64.0F);
/* 128 */     OSFreetype.FT_Set_Char_Size(this.face, 0L, i, 72, 72);
/*     */     
/* 130 */     boolean bool = (paramFTFontStrike.getAAMode() == 1 && FTFactory.LCD_SUPPORT) ? true : false;
/*     */ 
/*     */     
/* 133 */     int j = 14;
/* 134 */     FT_Matrix fT_Matrix = paramFTFontStrike.matrix;
/* 135 */     if (fT_Matrix != null) {
/* 136 */       OSFreetype.FT_Set_Transform(this.face, fT_Matrix, 0L, 0L);
/*     */     } else {
/* 138 */       j |= 0x800;
/*     */     } 
/* 140 */     if (bool) {
/* 141 */       j |= 0x30000;
/*     */     } else {
/* 143 */       j |= 0x0;
/*     */     } 
/*     */     
/* 146 */     int k = paramFTGlyph.getGlyphCode();
/* 147 */     int m = OSFreetype.FT_Load_Glyph(this.face, k, j);
/* 148 */     if (m != 0) {
/* 149 */       if (PrismFontFactory.debugFonts) {
/* 150 */         System.err.println("FT_Load_Glyph failed " + m + " glyph code " + k + " load falgs " + j);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 157 */     FT_GlyphSlotRec fT_GlyphSlotRec = OSFreetype.getGlyphSlot(this.face);
/* 158 */     if (fT_GlyphSlotRec == null)
/* 159 */       return;  FT_Bitmap fT_Bitmap = fT_GlyphSlotRec.bitmap;
/* 160 */     if (fT_Bitmap == null)
/* 161 */       return;  byte b = fT_Bitmap.pixel_mode;
/* 162 */     int n = fT_Bitmap.width;
/* 163 */     int i1 = fT_Bitmap.rows;
/* 164 */     int i2 = fT_Bitmap.pitch;
/* 165 */     if (b != 2 && b != 5) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       if (PrismFontFactory.debugFonts) {
/* 173 */         System.err.println("Unexpected pixel mode: " + b + " glyph code " + k + " load falgs " + j);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 180 */     if (n != 0 && i1 != 0) {
/* 181 */       arrayOfByte = OSFreetype.getBitmapData(this.face);
/* 182 */       if (arrayOfByte != null && i2 != n) {
/*     */         
/* 184 */         byte[] arrayOfByte1 = new byte[n * i1];
/* 185 */         int i3 = 0, i4 = 0;
/* 186 */         for (byte b1 = 0; b1 < i1; b1++) {
/* 187 */           for (byte b2 = 0; b2 < n; b2++) {
/* 188 */             arrayOfByte1[i4 + b2] = arrayOfByte[i3 + b2];
/*     */           }
/* 190 */           i4 += n;
/* 191 */           i3 += i2;
/*     */         } 
/* 193 */         arrayOfByte = arrayOfByte1;
/*     */       } 
/*     */     } else {
/*     */       
/* 197 */       arrayOfByte = new byte[0];
/*     */     } 
/*     */     
/* 200 */     paramFTGlyph.buffer = arrayOfByte;
/* 201 */     paramFTGlyph.bitmap = fT_Bitmap;
/* 202 */     paramFTGlyph.bitmap_left = fT_GlyphSlotRec.bitmap_left;
/* 203 */     paramFTGlyph.bitmap_top = fT_GlyphSlotRec.bitmap_top;
/* 204 */     paramFTGlyph.advanceX = (float)fT_GlyphSlotRec.advance_x / 64.0F;
/* 205 */     paramFTGlyph.advanceY = (float)fT_GlyphSlotRec.advance_y / 64.0F;
/* 206 */     paramFTGlyph.userAdvance = (float)fT_GlyphSlotRec.linearHoriAdvance / 65536.0F;
/* 207 */     paramFTGlyph.lcd = bool;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\font\freetype\FTFontFile.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */