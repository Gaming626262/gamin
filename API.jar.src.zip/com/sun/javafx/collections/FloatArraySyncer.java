package com.sun.javafx.collections;

public interface FloatArraySyncer {
  float[] syncTo(float[] paramArrayOffloat, int[] paramArrayOfint);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\FloatArraySyncer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */