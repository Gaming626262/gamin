/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VetoableListDecorator<E>
/*     */   implements ObservableList<E>
/*     */ {
/*     */   private final ObservableList<E> list;
/*     */   private int modCount;
/*     */   private ListListenerHelper<E> helper;
/*     */   
/*     */   public VetoableListDecorator(ObservableList<E> paramObservableList) {
/*  74 */     this.list = paramObservableList;
/*  75 */     this.list.addListener(paramChange -> ListListenerHelper.fireValueChangedEvent(this.helper, new SourceAdapterChange<>(this, paramChange)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(ListChangeListener<? super E> paramListChangeListener) {
/*  83 */     this.helper = ListListenerHelper.addListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(ListChangeListener<? super E> paramListChangeListener) {
/*  88 */     this.helper = ListListenerHelper.removeListener(this.helper, paramListChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/*  93 */     this.helper = ListListenerHelper.addListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/*  98 */     this.helper = ListListenerHelper.removeListener(this.helper, paramInvalidationListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 103 */     return addAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 108 */     return setAll(Arrays.asList(paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 113 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { 0, size() });
/*     */     try {
/* 115 */       this.modCount++;
/* 116 */       return this.list.setAll(paramCollection);
/* 117 */     } catch (Exception exception) {
/* 118 */       this.modCount--;
/* 119 */       throw exception;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeFromList(List<E> paramList, int paramInt, Collection<?> paramCollection, boolean paramBoolean) {
/* 124 */     int[] arrayOfInt = new int[2];
/* 125 */     byte b = -1;
/* 126 */     for (byte b1 = 0; b1 < paramList.size(); b1++) {
/* 127 */       E e = paramList.get(b1);
/* 128 */       if (paramCollection.contains(e) ^ paramBoolean) {
/* 129 */         if (b == -1) {
/* 130 */           arrayOfInt[b + 1] = paramInt + b1;
/* 131 */           arrayOfInt[b + 2] = paramInt + b1 + 1;
/* 132 */           b += 2;
/*     */         }
/* 134 */         else if (arrayOfInt[b - 1] == paramInt + b1) {
/* 135 */           arrayOfInt[b - 1] = paramInt + b1 + 1;
/*     */         } else {
/* 137 */           int[] arrayOfInt1 = new int[arrayOfInt.length + 2];
/* 138 */           System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/* 139 */           arrayOfInt = arrayOfInt1;
/* 140 */           arrayOfInt[b + 1] = paramInt + b1;
/* 141 */           arrayOfInt[b + 2] = paramInt + b1 + 1;
/* 142 */           b += 2;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 147 */     if (b != -1) {
/* 148 */       onProposedChange(Collections.emptyList(), arrayOfInt);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 154 */     return removeAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 159 */     return retainAll(Arrays.asList((Object[])paramVarArgs));
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 164 */     onProposedChange(Collections.emptyList(), new int[] { paramInt1, paramInt2 });
/*     */     try {
/* 166 */       this.modCount++;
/* 167 */       this.list.remove(paramInt1, paramInt2);
/* 168 */     } catch (Exception exception) {
/* 169 */       this.modCount--;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 175 */     return this.list.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 180 */     return this.list.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 185 */     return this.list.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 190 */     return new VetoableIteratorDecorator(new ModCountAccessorImpl(), this.list.iterator(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 195 */     return this.list.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 200 */     return (T[])this.list.toArray((Object[])paramArrayOfT);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E paramE) {
/* 205 */     onProposedChange(Collections.singletonList(paramE), new int[] { size(), size() });
/*     */     try {
/* 207 */       this.modCount++;
/* 208 */       this.list.add(paramE);
/* 209 */       return true;
/* 210 */     } catch (Exception exception) {
/* 211 */       this.modCount--;
/* 212 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 218 */     int i = this.list.indexOf(paramObject);
/* 219 */     if (i != -1) {
/* 220 */       remove(i);
/* 221 */       return true;
/*     */     } 
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 228 */     return this.list.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 233 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { size(), size() });
/*     */     try {
/* 235 */       this.modCount++;
/* 236 */       boolean bool = this.list.addAll(paramCollection);
/* 237 */       if (!bool)
/* 238 */         this.modCount--; 
/* 239 */       return bool;
/* 240 */     } catch (Exception exception) {
/* 241 */       this.modCount--;
/* 242 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 248 */     onProposedChange(Collections.unmodifiableList(new ArrayList<>(paramCollection)), new int[] { paramInt, paramInt });
/*     */     try {
/* 250 */       this.modCount++;
/* 251 */       boolean bool = this.list.addAll(paramInt, paramCollection);
/* 252 */       if (!bool)
/* 253 */         this.modCount--; 
/* 254 */       return bool;
/* 255 */     } catch (Exception exception) {
/* 256 */       this.modCount--;
/* 257 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 263 */     removeFromList((List<E>)this, 0, paramCollection, false);
/*     */     try {
/* 265 */       this.modCount++;
/* 266 */       boolean bool = this.list.removeAll(paramCollection);
/* 267 */       if (!bool)
/* 268 */         this.modCount--; 
/* 269 */       return bool;
/* 270 */     } catch (Exception exception) {
/* 271 */       this.modCount--;
/* 272 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 278 */     removeFromList((List<E>)this, 0, paramCollection, true);
/*     */     try {
/* 280 */       this.modCount++;
/* 281 */       boolean bool = this.list.retainAll(paramCollection);
/* 282 */       if (!bool)
/* 283 */         this.modCount--; 
/* 284 */       return bool;
/* 285 */     } catch (Exception exception) {
/* 286 */       this.modCount--;
/* 287 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 293 */     onProposedChange(Collections.emptyList(), new int[] { 0, size() });
/*     */     try {
/* 295 */       this.modCount++;
/* 296 */       this.list.clear();
/* 297 */     } catch (Exception exception) {
/* 298 */       this.modCount--;
/* 299 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 305 */     return (E)this.list.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 310 */     onProposedChange(Collections.singletonList(paramE), new int[] { paramInt, paramInt + 1 });
/* 311 */     return (E)this.list.set(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 316 */     onProposedChange(Collections.singletonList(paramE), new int[] { paramInt, paramInt });
/*     */     try {
/* 318 */       this.modCount++;
/* 319 */       this.list.add(paramInt, paramE);
/* 320 */     } catch (Exception exception) {
/* 321 */       this.modCount--;
/* 322 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int paramInt) {
/* 328 */     onProposedChange(Collections.emptyList(), new int[] { paramInt, paramInt + 1 });
/*     */     try {
/* 330 */       this.modCount++;
/* 331 */       return (E)this.list.remove(paramInt);
/*     */     }
/* 333 */     catch (Exception exception) {
/* 334 */       this.modCount--;
/* 335 */       throw exception;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 341 */     return this.list.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 346 */     return this.list.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 351 */     return new VetoableListIteratorDecorator(new ModCountAccessorImpl(), this.list.listIterator(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int paramInt) {
/* 356 */     return new VetoableListIteratorDecorator(new ModCountAccessorImpl(), this.list.listIterator(paramInt), paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int paramInt1, int paramInt2) {
/* 361 */     return new VetoableSubListDecorator(new ModCountAccessorImpl(), this.list.subList(paramInt1, paramInt2), paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 366 */     return this.list.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 371 */     return this.list.equals(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 376 */     return this.list.hashCode();
/*     */   }
/*     */   
/*     */   protected abstract void onProposedChange(List<E> paramList, int... paramVarArgs);
/*     */   
/*     */   private class VetoableSubListDecorator implements List<E> { private final List<E> subList;
/*     */     private final int offset;
/*     */     private final VetoableListDecorator.ModCountAccessor modCountAccessor;
/*     */     private int modCount;
/*     */     
/*     */     public VetoableSubListDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, List<E> param1List, int param1Int) {
/* 387 */       this.modCountAccessor = param1ModCountAccessor;
/* 388 */       this.modCount = param1ModCountAccessor.get();
/* 389 */       this.subList = param1List;
/* 390 */       this.offset = param1Int;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int size() {
/* 396 */       checkForComodification();
/* 397 */       return this.subList.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 402 */       checkForComodification();
/* 403 */       return this.subList.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object param1Object) {
/* 408 */       checkForComodification();
/* 409 */       return this.subList.contains(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public Iterator<E> iterator() {
/* 414 */       checkForComodification();
/* 415 */       return new VetoableListDecorator.VetoableIteratorDecorator(new ModCountAccessorImplSub(), this.subList.iterator(), this.offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object[] toArray() {
/* 420 */       checkForComodification();
/* 421 */       return this.subList.toArray();
/*     */     }
/*     */ 
/*     */     
/*     */     public <T> T[] toArray(T[] param1ArrayOfT) {
/* 426 */       checkForComodification();
/* 427 */       return this.subList.toArray(param1ArrayOfT);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(E param1E) {
/* 432 */       checkForComodification();
/* 433 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + size(), this.offset + size() });
/*     */       try {
/* 435 */         incrementModCount();
/* 436 */         this.subList.add(param1E);
/* 437 */       } catch (Exception exception) {
/* 438 */         decrementModCount();
/* 439 */         throw exception;
/*     */       } 
/* 441 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean remove(Object param1Object) {
/* 446 */       checkForComodification();
/* 447 */       int i = indexOf(param1Object);
/* 448 */       if (i != -1) {
/* 449 */         remove(i);
/* 450 */         return true;
/*     */       } 
/* 452 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsAll(Collection<?> param1Collection) {
/* 457 */       checkForComodification();
/* 458 */       return this.subList.containsAll(param1Collection);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends E> param1Collection) {
/* 463 */       checkForComodification();
/* 464 */       VetoableListDecorator.this.onProposedChange(Collections.unmodifiableList(new ArrayList(param1Collection)), new int[] { this.offset + size(), this.offset + size() });
/*     */       try {
/* 466 */         incrementModCount();
/* 467 */         boolean bool = this.subList.addAll(param1Collection);
/* 468 */         if (!bool)
/* 469 */           decrementModCount(); 
/* 470 */         return bool;
/* 471 */       } catch (Exception exception) {
/* 472 */         decrementModCount();
/* 473 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(int param1Int, Collection<? extends E> param1Collection) {
/* 479 */       checkForComodification();
/* 480 */       VetoableListDecorator.this.onProposedChange(Collections.unmodifiableList(new ArrayList(param1Collection)), new int[] { this.offset + param1Int, this.offset + param1Int });
/*     */       try {
/* 482 */         incrementModCount();
/* 483 */         boolean bool = this.subList.addAll(param1Int, param1Collection);
/* 484 */         if (!bool)
/* 485 */           decrementModCount(); 
/* 486 */         return bool;
/* 487 */       } catch (Exception exception) {
/* 488 */         decrementModCount();
/* 489 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean removeAll(Collection<?> param1Collection) {
/* 495 */       checkForComodification();
/* 496 */       VetoableListDecorator.this.removeFromList(this, this.offset, param1Collection, false);
/*     */       try {
/* 498 */         incrementModCount();
/* 499 */         boolean bool = this.subList.removeAll(param1Collection);
/* 500 */         if (!bool)
/* 501 */           decrementModCount(); 
/* 502 */         return bool;
/* 503 */       } catch (Exception exception) {
/* 504 */         decrementModCount();
/* 505 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean retainAll(Collection<?> param1Collection) {
/* 511 */       checkForComodification();
/* 512 */       VetoableListDecorator.this.removeFromList(this, this.offset, param1Collection, true);
/*     */       try {
/* 514 */         incrementModCount();
/* 515 */         boolean bool = this.subList.retainAll(param1Collection);
/* 516 */         if (!bool)
/* 517 */           decrementModCount(); 
/* 518 */         return bool;
/* 519 */       } catch (Exception exception) {
/* 520 */         decrementModCount();
/* 521 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 527 */       checkForComodification();
/* 528 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset, this.offset + size() });
/*     */       try {
/* 530 */         incrementModCount();
/* 531 */         this.subList.clear();
/* 532 */       } catch (Exception exception) {
/* 533 */         decrementModCount();
/* 534 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public E get(int param1Int) {
/* 540 */       checkForComodification();
/* 541 */       return this.subList.get(param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public E set(int param1Int, E param1E) {
/* 546 */       checkForComodification();
/* 547 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + param1Int, this.offset + param1Int + 1 });
/* 548 */       return this.subList.set(param1Int, param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(int param1Int, E param1E) {
/* 553 */       checkForComodification();
/* 554 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + param1Int, this.offset + param1Int });
/*     */       try {
/* 556 */         incrementModCount();
/* 557 */         this.subList.add(param1Int, param1E);
/* 558 */       } catch (Exception exception) {
/* 559 */         decrementModCount();
/* 560 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public E remove(int param1Int) {
/* 566 */       checkForComodification();
/* 567 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset + param1Int, this.offset + param1Int + 1 });
/*     */       try {
/* 569 */         incrementModCount();
/* 570 */         return this.subList.remove(param1Int);
/*     */       }
/* 572 */       catch (Exception exception) {
/* 573 */         decrementModCount();
/* 574 */         throw exception;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int indexOf(Object param1Object) {
/* 581 */       checkForComodification();
/* 582 */       return this.subList.indexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int lastIndexOf(Object param1Object) {
/* 587 */       checkForComodification();
/* 588 */       return this.subList.lastIndexOf(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator() {
/* 593 */       checkForComodification();
/* 594 */       return new VetoableListDecorator.VetoableListIteratorDecorator(new ModCountAccessorImplSub(), this.subList
/* 595 */           .listIterator(), this.offset);
/*     */     }
/*     */ 
/*     */     
/*     */     public ListIterator<E> listIterator(int param1Int) {
/* 600 */       checkForComodification();
/* 601 */       return new VetoableListDecorator.VetoableListIteratorDecorator(new ModCountAccessorImplSub(), this.subList
/* 602 */           .listIterator(param1Int), this.offset + param1Int);
/*     */     }
/*     */ 
/*     */     
/*     */     public List<E> subList(int param1Int1, int param1Int2) {
/* 607 */       checkForComodification();
/* 608 */       return new VetoableSubListDecorator(new ModCountAccessorImplSub(), this.subList
/* 609 */           .subList(param1Int1, param1Int2), this.offset + param1Int1);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 614 */       checkForComodification();
/* 615 */       return this.subList.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 620 */       checkForComodification();
/* 621 */       return this.subList.equals(param1Object);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 626 */       checkForComodification();
/* 627 */       return this.subList.hashCode();
/*     */     }
/*     */     
/*     */     private void checkForComodification() {
/* 631 */       if (this.modCount != this.modCountAccessor.get()) {
/* 632 */         throw new ConcurrentModificationException();
/*     */       }
/*     */     }
/*     */     
/*     */     private void incrementModCount() {
/* 637 */       this.modCount = this.modCountAccessor.incrementAndGet();
/*     */     }
/*     */     
/*     */     private void decrementModCount() {
/* 641 */       this.modCount = this.modCountAccessor.decrementAndGet();
/*     */     }
/*     */     
/*     */     private class ModCountAccessorImplSub
/*     */       implements VetoableListDecorator.ModCountAccessor
/*     */     {
/*     */       public int get() {
/* 648 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount;
/*     */       }
/*     */ 
/*     */       
/*     */       public int incrementAndGet() {
/* 653 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount = VetoableListDecorator.VetoableSubListDecorator.this.modCountAccessor.incrementAndGet();
/*     */       }
/*     */       
/*     */       public int decrementAndGet()
/*     */       {
/* 658 */         return VetoableListDecorator.VetoableSubListDecorator.this.modCount = VetoableListDecorator.VetoableSubListDecorator.this.modCountAccessor.decrementAndGet(); } } } private class ModCountAccessorImplSub implements ModCountAccessor { public int decrementAndGet() { return this.this$1.modCount = this.this$1.modCountAccessor.decrementAndGet(); }
/*     */     
/*     */     public int get() {
/*     */       return this.this$1.modCount;
/*     */     }
/*     */     public int incrementAndGet() {
/*     */       return this.this$1.modCount = this.this$1.modCountAccessor.incrementAndGet();
/*     */     } }
/*     */   private class VetoableIteratorDecorator implements Iterator<E> { private final Iterator<E> it; private final VetoableListDecorator.ModCountAccessor modCountAccessor;
/*     */     private int modCount;
/*     */     protected final int offset;
/*     */     protected int cursor;
/*     */     protected int lastReturned;
/*     */     
/*     */     public VetoableIteratorDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, Iterator<E> param1Iterator, int param1Int) {
/* 673 */       this.modCountAccessor = param1ModCountAccessor;
/* 674 */       this.modCount = param1ModCountAccessor.get();
/* 675 */       this.it = param1Iterator;
/* 676 */       this.offset = param1Int;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 681 */       checkForComodification();
/* 682 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public E next() {
/* 687 */       checkForComodification();
/* 688 */       E e = this.it.next();
/* 689 */       this.lastReturned = this.cursor++;
/* 690 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 695 */       checkForComodification();
/* 696 */       if (this.lastReturned == -1) {
/* 697 */         throw new IllegalStateException();
/*     */       }
/* 699 */       VetoableListDecorator.this.onProposedChange(Collections.emptyList(), new int[] { this.offset + this.lastReturned, this.offset + this.lastReturned + 1 });
/*     */       try {
/* 701 */         incrementModCount();
/* 702 */         this.it.remove();
/* 703 */       } catch (Exception exception) {
/* 704 */         decrementModCount();
/* 705 */         throw exception;
/*     */       } 
/* 707 */       this.lastReturned = -1;
/* 708 */       this.cursor--;
/*     */     }
/*     */     
/*     */     protected void checkForComodification() {
/* 712 */       if (this.modCount != this.modCountAccessor.get()) {
/* 713 */         throw new ConcurrentModificationException();
/*     */       }
/*     */     }
/*     */     
/*     */     protected void incrementModCount() {
/* 718 */       this.modCount = this.modCountAccessor.incrementAndGet();
/*     */     }
/*     */     
/*     */     protected void decrementModCount() {
/* 722 */       this.modCount = this.modCountAccessor.decrementAndGet();
/*     */     } }
/*     */ 
/*     */   
/*     */   private class VetoableListIteratorDecorator
/*     */     extends VetoableIteratorDecorator implements ListIterator<E> {
/*     */     private final ListIterator<E> lit;
/*     */     
/*     */     public VetoableListIteratorDecorator(VetoableListDecorator.ModCountAccessor param1ModCountAccessor, ListIterator<E> param1ListIterator, int param1Int) {
/* 731 */       super(param1ModCountAccessor, param1ListIterator, param1Int);
/* 732 */       this.lit = param1ListIterator;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasPrevious() {
/* 737 */       checkForComodification();
/* 738 */       return this.lit.hasPrevious();
/*     */     }
/*     */ 
/*     */     
/*     */     public E previous() {
/* 743 */       checkForComodification();
/* 744 */       E e = this.lit.previous();
/* 745 */       this.lastReturned = --this.cursor;
/* 746 */       return e;
/*     */     }
/*     */ 
/*     */     
/*     */     public int nextIndex() {
/* 751 */       checkForComodification();
/* 752 */       return this.lit.nextIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     public int previousIndex() {
/* 757 */       checkForComodification();
/* 758 */       return this.lit.previousIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(E param1E) {
/* 763 */       checkForComodification();
/* 764 */       if (this.lastReturned == -1) {
/* 765 */         throw new IllegalStateException();
/*     */       }
/* 767 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + this.lastReturned, this.offset + this.lastReturned + 1 });
/* 768 */       this.lit.set(param1E);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(E param1E) {
/* 773 */       checkForComodification();
/* 774 */       VetoableListDecorator.this.onProposedChange(Collections.singletonList(param1E), new int[] { this.offset + this.cursor, this.offset + this.cursor });
/*     */       try {
/* 776 */         incrementModCount();
/* 777 */         this.lit.add(param1E);
/* 778 */       } catch (Exception exception) {
/* 779 */         decrementModCount();
/* 780 */         throw exception;
/*     */       } 
/* 782 */       this.cursor++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ModCountAccessorImpl
/*     */     implements ModCountAccessor
/*     */   {
/*     */     public int get() {
/* 793 */       return VetoableListDecorator.this.modCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public int incrementAndGet() {
/* 798 */       return ++VetoableListDecorator.this.modCount;
/*     */     }
/*     */ 
/*     */     
/*     */     public int decrementAndGet() {
/* 803 */       return --VetoableListDecorator.this.modCount;
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface ModCountAccessor {
/*     */     int get();
/*     */     
/*     */     int incrementAndGet();
/*     */     
/*     */     int decrementAndGet();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\VetoableListDecorator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */