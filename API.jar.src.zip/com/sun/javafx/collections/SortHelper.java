/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortHelper
/*     */ {
/*     */   private int[] permutation;
/*     */   private int[] reversePermutation;
/*     */   private static final int INSERTIONSORT_THRESHOLD = 7;
/*     */   
/*     */   public <T extends Comparable<? super T>> int[] sort(List<T> paramList) {
/*  45 */     Comparable[] arrayOfComparable = (Comparable[])Array.newInstance(Comparable.class, paramList.size());
/*     */     try {
/*  47 */       arrayOfComparable = paramList.<Comparable>toArray(arrayOfComparable);
/*  48 */     } catch (ArrayStoreException arrayStoreException) {
/*     */       
/*  50 */       throw new ClassCastException();
/*     */     } 
/*  52 */     int[] arrayOfInt = sort(arrayOfComparable);
/*  53 */     ListIterator<T> listIterator = paramList.listIterator();
/*  54 */     for (byte b = 0; b < arrayOfComparable.length; b++) {
/*  55 */       listIterator.next();
/*  56 */       listIterator.set((T)arrayOfComparable[b]);
/*     */     } 
/*  58 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   public <T> int[] sort(List<T> paramList, Comparator<? super T> paramComparator) {
/*  62 */     Object[] arrayOfObject = paramList.toArray();
/*  63 */     int[] arrayOfInt = sort(arrayOfObject, (Comparator)paramComparator);
/*  64 */     ListIterator<T> listIterator = paramList.listIterator();
/*  65 */     for (byte b = 0; b < arrayOfObject.length; b++) {
/*  66 */       listIterator.next();
/*  67 */       listIterator.set((T)arrayOfObject[b]);
/*     */     } 
/*  69 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   public <T extends Comparable<? super T>> int[] sort(T[] paramArrayOfT) {
/*  73 */     return sort(paramArrayOfT, (Comparator<? super T>)null);
/*     */   }
/*     */   
/*     */   public <T> int[] sort(T[] paramArrayOfT, Comparator<? super T> paramComparator) {
/*  77 */     Object[] arrayOfObject = (Object[])paramArrayOfT.clone();
/*  78 */     int[] arrayOfInt = initPermutation(paramArrayOfT.length);
/*  79 */     if (paramComparator == null) {
/*  80 */       mergeSort(arrayOfObject, (Object[])paramArrayOfT, 0, paramArrayOfT.length, 0);
/*     */     } else {
/*  82 */       mergeSort(arrayOfObject, (Object[])paramArrayOfT, 0, paramArrayOfT.length, 0, paramComparator);
/*  83 */     }  this.reversePermutation = null;
/*  84 */     this.permutation = null;
/*  85 */     return arrayOfInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> int[] sort(T[] paramArrayOfT, int paramInt1, int paramInt2, Comparator<? super T> paramComparator) {
/*  90 */     rangeCheck(paramArrayOfT.length, paramInt1, paramInt2);
/*  91 */     Object[] arrayOfObject = copyOfRange((Object[])paramArrayOfT, paramInt1, paramInt2);
/*  92 */     int[] arrayOfInt = initPermutation(paramArrayOfT.length);
/*  93 */     if (paramComparator == null) {
/*  94 */       mergeSort(arrayOfObject, (Object[])paramArrayOfT, paramInt1, paramInt2, -paramInt1);
/*     */     } else {
/*  96 */       mergeSort(arrayOfObject, (Object[])paramArrayOfT, paramInt1, paramInt2, -paramInt1, paramComparator);
/*  97 */     }  this.reversePermutation = null;
/*  98 */     this.permutation = null;
/*  99 */     return Arrays.copyOfRange(arrayOfInt, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int[] sort(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 103 */     rangeCheck(paramArrayOfint.length, paramInt1, paramInt2);
/* 104 */     int[] arrayOfInt1 = copyOfRange(paramArrayOfint, paramInt1, paramInt2);
/* 105 */     int[] arrayOfInt2 = initPermutation(paramArrayOfint.length);
/* 106 */     mergeSort(arrayOfInt1, paramArrayOfint, paramInt1, paramInt2, -paramInt1);
/* 107 */     this.reversePermutation = null;
/* 108 */     this.permutation = null;
/* 109 */     return Arrays.copyOfRange(arrayOfInt2, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   private static void rangeCheck(int paramInt1, int paramInt2, int paramInt3) {
/* 113 */     if (paramInt2 > paramInt3) {
/* 114 */       throw new IllegalArgumentException("fromIndex(" + paramInt2 + ") > toIndex(" + paramInt3 + ")");
/*     */     }
/* 116 */     if (paramInt2 < 0)
/* 117 */       throw new ArrayIndexOutOfBoundsException(paramInt2); 
/* 118 */     if (paramInt3 > paramInt1) {
/* 119 */       throw new ArrayIndexOutOfBoundsException(paramInt3);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int[] copyOfRange(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 124 */     int i = paramInt2 - paramInt1;
/* 125 */     if (i < 0)
/* 126 */       throw new IllegalArgumentException("" + paramInt1 + " > " + paramInt1); 
/* 127 */     int[] arrayOfInt = new int[i];
/* 128 */     System.arraycopy(paramArrayOfint, paramInt1, arrayOfInt, 0, 
/* 129 */         Math.min(paramArrayOfint.length - paramInt1, i));
/* 130 */     return arrayOfInt;
/*     */   }
/*     */   
/*     */   private static <T> T[] copyOfRange(T[] paramArrayOfT, int paramInt1, int paramInt2) {
/* 134 */     return copyOfRange(paramArrayOfT, paramInt1, paramInt2, (Class)paramArrayOfT.getClass());
/*     */   }
/*     */   
/*     */   private static <T, U> T[] copyOfRange(U[] paramArrayOfU, int paramInt1, int paramInt2, Class<? extends T[]> paramClass) {
/* 138 */     int i = paramInt2 - paramInt1;
/* 139 */     if (i < 0) {
/* 140 */       throw new IllegalArgumentException("" + paramInt1 + " > " + paramInt1);
/*     */     }
/*     */     
/* 143 */     Object[] arrayOfObject = (paramClass == Object[].class) ? new Object[i] : (Object[])Array.newInstance(paramClass.getComponentType(), i);
/* 144 */     System.arraycopy(paramArrayOfU, paramInt1, arrayOfObject, 0, 
/* 145 */         Math.min(paramArrayOfU.length - paramInt1, i));
/* 146 */     return (T[])arrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeSort(int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt1, int paramInt2, int paramInt3) {
/* 157 */     int i = paramInt2 - paramInt1;
/*     */ 
/*     */     
/* 160 */     if (i < 7) {
/* 161 */       for (int i3 = paramInt1; i3 < paramInt2; i3++) {
/* 162 */         for (int i4 = i3; i4 > paramInt1 && 
/* 163 */           Integer.valueOf(paramArrayOfint2[i4 - 1]).compareTo(Integer.valueOf(paramArrayOfint2[i4])) > 0; i4--) {
/* 164 */           swap(paramArrayOfint2, i4, i4 - 1);
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/* 169 */     int j = paramInt1;
/* 170 */     int k = paramInt2;
/* 171 */     paramInt1 += paramInt3;
/* 172 */     paramInt2 += paramInt3;
/* 173 */     int m = paramInt1 + paramInt2 >>> 1;
/* 174 */     mergeSort(paramArrayOfint2, paramArrayOfint1, paramInt1, m, -paramInt3);
/* 175 */     mergeSort(paramArrayOfint2, paramArrayOfint1, m, paramInt2, -paramInt3);
/*     */ 
/*     */ 
/*     */     
/* 179 */     if (Integer.valueOf(paramArrayOfint1[m - 1]).compareTo(Integer.valueOf(paramArrayOfint1[m])) <= 0) {
/* 180 */       System.arraycopy(paramArrayOfint1, paramInt1, paramArrayOfint2, j, i);
/*     */       
/*     */       return;
/*     */     } 
/*     */     int n, i1, i2;
/* 185 */     for (n = j, i1 = paramInt1, i2 = m; n < k; n++) {
/* 186 */       if (i2 >= paramInt2 || (i1 < m && Integer.valueOf(paramArrayOfint1[i1]).compareTo(Integer.valueOf(paramArrayOfint1[i2])) <= 0)) {
/* 187 */         paramArrayOfint2[n] = paramArrayOfint1[i1];
/* 188 */         this.permutation[this.reversePermutation[i1++]] = n;
/*     */       } else {
/* 190 */         paramArrayOfint2[n] = paramArrayOfint1[i2];
/* 191 */         this.permutation[this.reversePermutation[i2++]] = n;
/*     */       } 
/*     */     } 
/*     */     
/* 195 */     for (n = j; n < k; n++) {
/* 196 */       this.reversePermutation[this.permutation[n]] = n;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeSort(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, int paramInt1, int paramInt2, int paramInt3) {
/* 208 */     int i = paramInt2 - paramInt1;
/*     */ 
/*     */     
/* 211 */     if (i < 7) {
/* 212 */       for (int i3 = paramInt1; i3 < paramInt2; i3++) {
/* 213 */         for (int i4 = i3; i4 > paramInt1 && ((Comparable<Object>)paramArrayOfObject2[i4 - 1])
/* 214 */           .compareTo(paramArrayOfObject2[i4]) > 0; i4--) {
/* 215 */           swap(paramArrayOfObject2, i4, i4 - 1);
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/* 220 */     int j = paramInt1;
/* 221 */     int k = paramInt2;
/* 222 */     paramInt1 += paramInt3;
/* 223 */     paramInt2 += paramInt3;
/* 224 */     int m = paramInt1 + paramInt2 >>> 1;
/* 225 */     mergeSort(paramArrayOfObject2, paramArrayOfObject1, paramInt1, m, -paramInt3);
/* 226 */     mergeSort(paramArrayOfObject2, paramArrayOfObject1, m, paramInt2, -paramInt3);
/*     */ 
/*     */ 
/*     */     
/* 230 */     if (((Comparable<Object>)paramArrayOfObject1[m - 1]).compareTo(paramArrayOfObject1[m]) <= 0) {
/* 231 */       System.arraycopy(paramArrayOfObject1, paramInt1, paramArrayOfObject2, j, i);
/*     */       
/*     */       return;
/*     */     } 
/*     */     int n, i1, i2;
/* 236 */     for (n = j, i1 = paramInt1, i2 = m; n < k; n++) {
/* 237 */       if (i2 >= paramInt2 || (i1 < m && ((Comparable<Object>)paramArrayOfObject1[i1]).compareTo(paramArrayOfObject1[i2]) <= 0)) {
/* 238 */         paramArrayOfObject2[n] = paramArrayOfObject1[i1];
/* 239 */         this.permutation[this.reversePermutation[i1++]] = n;
/*     */       } else {
/* 241 */         paramArrayOfObject2[n] = paramArrayOfObject1[i2];
/* 242 */         this.permutation[this.reversePermutation[i2++]] = n;
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     for (n = j; n < k; n++) {
/* 247 */       this.reversePermutation[this.permutation[n]] = n;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeSort(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, int paramInt1, int paramInt2, int paramInt3, Comparator<Object> paramComparator) {
/* 255 */     int i = paramInt2 - paramInt1;
/*     */ 
/*     */     
/* 258 */     if (i < 7) {
/* 259 */       for (int i3 = paramInt1; i3 < paramInt2; i3++) {
/* 260 */         for (int i4 = i3; i4 > paramInt1 && paramComparator.compare(paramArrayOfObject2[i4 - 1], paramArrayOfObject2[i4]) > 0; i4--) {
/* 261 */           swap(paramArrayOfObject2, i4, i4 - 1);
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/* 266 */     int j = paramInt1;
/* 267 */     int k = paramInt2;
/* 268 */     paramInt1 += paramInt3;
/* 269 */     paramInt2 += paramInt3;
/* 270 */     int m = paramInt1 + paramInt2 >>> 1;
/* 271 */     mergeSort(paramArrayOfObject2, paramArrayOfObject1, paramInt1, m, -paramInt3, paramComparator);
/* 272 */     mergeSort(paramArrayOfObject2, paramArrayOfObject1, m, paramInt2, -paramInt3, paramComparator);
/*     */ 
/*     */ 
/*     */     
/* 276 */     if (paramComparator.compare(paramArrayOfObject1[m - 1], paramArrayOfObject1[m]) <= 0) {
/* 277 */       System.arraycopy(paramArrayOfObject1, paramInt1, paramArrayOfObject2, j, i);
/*     */       
/*     */       return;
/*     */     } 
/*     */     int n, i1, i2;
/* 282 */     for (n = j, i1 = paramInt1, i2 = m; n < k; n++) {
/* 283 */       if (i2 >= paramInt2 || (i1 < m && paramComparator.compare(paramArrayOfObject1[i1], paramArrayOfObject1[i2]) <= 0)) {
/* 284 */         paramArrayOfObject2[n] = paramArrayOfObject1[i1];
/* 285 */         this.permutation[this.reversePermutation[i1++]] = n;
/*     */       } else {
/* 287 */         paramArrayOfObject2[n] = paramArrayOfObject1[i2];
/* 288 */         this.permutation[this.reversePermutation[i2++]] = n;
/*     */       } 
/*     */     } 
/*     */     
/* 292 */     for (n = j; n < k; n++) {
/* 293 */       this.reversePermutation[this.permutation[n]] = n;
/*     */     }
/*     */   }
/*     */   
/*     */   private void swap(int[] paramArrayOfint, int paramInt1, int paramInt2) {
/* 298 */     int i = paramArrayOfint[paramInt1];
/* 299 */     paramArrayOfint[paramInt1] = paramArrayOfint[paramInt2];
/* 300 */     paramArrayOfint[paramInt2] = i;
/* 301 */     this.permutation[this.reversePermutation[paramInt1]] = paramInt2;
/* 302 */     this.permutation[this.reversePermutation[paramInt2]] = paramInt1;
/* 303 */     int j = this.reversePermutation[paramInt1];
/* 304 */     this.reversePermutation[paramInt1] = this.reversePermutation[paramInt2];
/* 305 */     this.reversePermutation[paramInt2] = j;
/*     */   }
/*     */   
/*     */   private void swap(Object[] paramArrayOfObject, int paramInt1, int paramInt2) {
/* 309 */     Object object = paramArrayOfObject[paramInt1];
/* 310 */     paramArrayOfObject[paramInt1] = paramArrayOfObject[paramInt2];
/* 311 */     paramArrayOfObject[paramInt2] = object;
/* 312 */     this.permutation[this.reversePermutation[paramInt1]] = paramInt2;
/* 313 */     this.permutation[this.reversePermutation[paramInt2]] = paramInt1;
/* 314 */     int i = this.reversePermutation[paramInt1];
/* 315 */     this.reversePermutation[paramInt1] = this.reversePermutation[paramInt2];
/* 316 */     this.reversePermutation[paramInt2] = i;
/*     */   }
/*     */   
/*     */   private int[] initPermutation(int paramInt) {
/* 320 */     this.permutation = new int[paramInt];
/* 321 */     this.reversePermutation = new int[paramInt];
/* 322 */     for (byte b = 0; b < paramInt; b++) {
/* 323 */       this.reversePermutation[b] = b; this.permutation[b] = b;
/*     */     } 
/* 325 */     return this.permutation;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\SortHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */