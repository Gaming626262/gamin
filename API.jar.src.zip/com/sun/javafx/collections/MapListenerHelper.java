/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelperBase;
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.MapChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MapListenerHelper<K, V>
/*     */   extends ExpressionHelperBase
/*     */ {
/*     */   public static <K, V> MapListenerHelper<K, V> addListener(MapListenerHelper<K, V> paramMapListenerHelper, InvalidationListener paramInvalidationListener) {
/*  43 */     if (paramInvalidationListener == null) {
/*  44 */       throw new NullPointerException();
/*     */     }
/*  46 */     return (paramMapListenerHelper == null) ? new SingleInvalidation<>(paramInvalidationListener) : paramMapListenerHelper.addListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <K, V> MapListenerHelper<K, V> removeListener(MapListenerHelper<K, V> paramMapListenerHelper, InvalidationListener paramInvalidationListener) {
/*  50 */     if (paramInvalidationListener == null) {
/*  51 */       throw new NullPointerException();
/*     */     }
/*  53 */     return (paramMapListenerHelper == null) ? null : paramMapListenerHelper.removeListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <K, V> MapListenerHelper<K, V> addListener(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/*  57 */     if (paramMapChangeListener == null) {
/*  58 */       throw new NullPointerException();
/*     */     }
/*  60 */     return (paramMapListenerHelper == null) ? new SingleChange<>(paramMapChangeListener) : paramMapListenerHelper.addListener(paramMapChangeListener);
/*     */   }
/*     */   
/*     */   public static <K, V> MapListenerHelper<K, V> removeListener(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener<? super K, ? super V> paramMapChangeListener) {
/*  64 */     if (paramMapChangeListener == null) {
/*  65 */       throw new NullPointerException();
/*     */     }
/*  67 */     return (paramMapListenerHelper == null) ? null : paramMapListenerHelper.removeListener(paramMapChangeListener);
/*     */   }
/*     */   
/*     */   public static <K, V> void fireValueChangedEvent(MapListenerHelper<K, V> paramMapListenerHelper, MapChangeListener.Change<? extends K, ? extends V> paramChange) {
/*  71 */     if (paramMapListenerHelper != null) {
/*  72 */       paramMapListenerHelper.fireValueChangedEvent(paramChange);
/*     */     }
/*     */   }
/*     */   
/*     */   public static <K, V> boolean hasListeners(MapListenerHelper<K, V> paramMapListenerHelper) {
/*  77 */     return (paramMapListenerHelper != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract MapListenerHelper<K, V> addListener(InvalidationListener paramInvalidationListener);
/*     */ 
/*     */   
/*     */   protected abstract MapListenerHelper<K, V> removeListener(InvalidationListener paramInvalidationListener);
/*     */ 
/*     */   
/*     */   protected abstract MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
/*     */   
/*     */   protected abstract MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> paramMapChangeListener);
/*     */   
/*     */   protected abstract void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> paramChange);
/*     */   
/*     */   private static class SingleInvalidation<K, V>
/*     */     extends MapListenerHelper<K, V>
/*     */   {
/*     */     private final InvalidationListener listener;
/*     */     
/*     */     private SingleInvalidation(InvalidationListener param1InvalidationListener) {
/*  99 */       this.listener = param1InvalidationListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> addListener(InvalidationListener param1InvalidationListener) {
/* 104 */       return new MapListenerHelper.Generic<>(this.listener, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(InvalidationListener param1InvalidationListener) {
/* 109 */       return param1InvalidationListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 114 */       return new MapListenerHelper.Generic<>(this.listener, param1MapChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 119 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/*     */       try {
/* 125 */         this.listener.invalidated((Observable)param1Change.getMap());
/* 126 */       } catch (Exception exception) {
/* 127 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleChange<K, V>
/*     */     extends MapListenerHelper<K, V> {
/*     */     private final MapChangeListener<? super K, ? super V> listener;
/*     */     
/*     */     private SingleChange(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 137 */       this.listener = param1MapChangeListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> addListener(InvalidationListener param1InvalidationListener) {
/* 142 */       return new MapListenerHelper.Generic<>(param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(InvalidationListener param1InvalidationListener) {
/* 147 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 152 */       return new MapListenerHelper.Generic<>(this.listener, param1MapChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 157 */       return param1MapChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/*     */       try {
/* 163 */         this.listener.onChanged(param1Change);
/* 164 */       } catch (Exception exception) {
/* 165 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Generic<K, V>
/*     */     extends MapListenerHelper<K, V> {
/*     */     private InvalidationListener[] invalidationListeners;
/*     */     private MapChangeListener<? super K, ? super V>[] changeListeners;
/*     */     private int invalidationSize;
/*     */     private int changeSize;
/*     */     private boolean locked;
/*     */     
/*     */     private Generic(InvalidationListener param1InvalidationListener1, InvalidationListener param1InvalidationListener2) {
/* 179 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener1, param1InvalidationListener2 };
/* 180 */       this.invalidationSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(MapChangeListener<? super K, ? super V> param1MapChangeListener1, MapChangeListener<? super K, ? super V> param1MapChangeListener2) {
/* 184 */       this.changeListeners = (MapChangeListener<? super K, ? super V>[])new MapChangeListener[] { param1MapChangeListener1, param1MapChangeListener2 };
/* 185 */       this.changeSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(InvalidationListener param1InvalidationListener, MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 189 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 190 */       this.invalidationSize = 1;
/* 191 */       this.changeListeners = (MapChangeListener<? super K, ? super V>[])new MapChangeListener[] { param1MapChangeListener };
/* 192 */       this.changeSize = 1;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Generic<K, V> addListener(InvalidationListener param1InvalidationListener) {
/* 197 */       if (this.invalidationListeners == null) {
/* 198 */         this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 199 */         this.invalidationSize = 1;
/*     */       } else {
/* 201 */         int i = this.invalidationListeners.length;
/* 202 */         if (this.locked) {
/* 203 */           int j = (this.invalidationSize < i) ? i : (i * 3 / 2 + 1);
/* 204 */           this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/* 205 */         } else if (this.invalidationSize == i) {
/* 206 */           this.invalidationSize = trim(this.invalidationSize, (Object[])this.invalidationListeners);
/* 207 */           if (this.invalidationSize == i) {
/* 208 */             int j = i * 3 / 2 + 1;
/* 209 */             this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/*     */           } 
/*     */         } 
/* 212 */         this.invalidationListeners[this.invalidationSize++] = param1InvalidationListener;
/*     */       } 
/* 214 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(InvalidationListener param1InvalidationListener) {
/* 219 */       if (this.invalidationListeners != null) {
/* 220 */         for (byte b = 0; b < this.invalidationSize; b++) {
/* 221 */           if (param1InvalidationListener.equals(this.invalidationListeners[b])) {
/* 222 */             if (this.invalidationSize == 1) {
/* 223 */               if (this.changeSize == 1) {
/* 224 */                 return new MapListenerHelper.SingleChange<>(this.changeListeners[0]);
/*     */               }
/* 226 */               this.invalidationListeners = null;
/* 227 */               this.invalidationSize = 0; break;
/* 228 */             }  if (this.invalidationSize == 2 && this.changeSize == 0) {
/* 229 */               return new MapListenerHelper.SingleInvalidation<>(this.invalidationListeners[1 - b]);
/*     */             }
/* 231 */             int i = this.invalidationSize - b - 1;
/* 232 */             InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 233 */             if (this.locked) {
/* 234 */               this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
/* 235 */               System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, b);
/*     */             } 
/* 237 */             if (i > 0) {
/* 238 */               System.arraycopy(arrayOfInvalidationListener, b + 1, this.invalidationListeners, b, i);
/*     */             }
/* 240 */             this.invalidationSize--;
/* 241 */             if (!this.locked) {
/* 242 */               this.invalidationListeners[this.invalidationSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 249 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> addListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 254 */       if (this.changeListeners == null) {
/* 255 */         this.changeListeners = (MapChangeListener<? super K, ? super V>[])new MapChangeListener[] { param1MapChangeListener };
/* 256 */         this.changeSize = 1;
/*     */       } else {
/* 258 */         int i = this.changeListeners.length;
/* 259 */         if (this.locked) {
/* 260 */           int j = (this.changeSize < i) ? i : (i * 3 / 2 + 1);
/* 261 */           this.changeListeners = Arrays.<MapChangeListener<? super K, ? super V>>copyOf(this.changeListeners, j);
/* 262 */         } else if (this.changeSize == i) {
/* 263 */           this.changeSize = trim(this.changeSize, (Object[])this.changeListeners);
/* 264 */           if (this.changeSize == i) {
/* 265 */             int j = i * 3 / 2 + 1;
/* 266 */             this.changeListeners = Arrays.<MapChangeListener<? super K, ? super V>>copyOf(this.changeListeners, j);
/*     */           } 
/*     */         } 
/* 269 */         this.changeListeners[this.changeSize++] = param1MapChangeListener;
/*     */       } 
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MapListenerHelper<K, V> removeListener(MapChangeListener<? super K, ? super V> param1MapChangeListener) {
/* 276 */       if (this.changeListeners != null) {
/* 277 */         for (byte b = 0; b < this.changeSize; b++) {
/* 278 */           if (param1MapChangeListener.equals(this.changeListeners[b])) {
/* 279 */             if (this.changeSize == 1) {
/* 280 */               if (this.invalidationSize == 1) {
/* 281 */                 return new MapListenerHelper.SingleInvalidation<>(this.invalidationListeners[0]);
/*     */               }
/* 283 */               this.changeListeners = null;
/* 284 */               this.changeSize = 0; break;
/* 285 */             }  if (this.changeSize == 2 && this.invalidationSize == 0) {
/* 286 */               return new MapListenerHelper.SingleChange<>(this.changeListeners[1 - b]);
/*     */             }
/* 288 */             int i = this.changeSize - b - 1;
/* 289 */             MapChangeListener<? super K, ? super V>[] arrayOfMapChangeListener = this.changeListeners;
/* 290 */             if (this.locked) {
/* 291 */               this.changeListeners = (MapChangeListener<? super K, ? super V>[])new MapChangeListener[this.changeListeners.length];
/* 292 */               System.arraycopy(arrayOfMapChangeListener, 0, this.changeListeners, 0, b);
/*     */             } 
/* 294 */             if (i > 0) {
/* 295 */               System.arraycopy(arrayOfMapChangeListener, b + 1, this.changeListeners, b, i);
/*     */             }
/* 297 */             this.changeSize--;
/* 298 */             if (!this.locked) {
/* 299 */               this.changeListeners[this.changeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 306 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/* 311 */       InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 312 */       int i = this.invalidationSize;
/* 313 */       MapChangeListener<? super K, ? super V>[] arrayOfMapChangeListener = this.changeListeners;
/* 314 */       int j = this.changeSize;
/*     */       
/*     */       try {
/* 317 */         this.locked = true; byte b;
/* 318 */         for (b = 0; b < i; b++) {
/*     */           try {
/* 320 */             arrayOfInvalidationListener[b].invalidated((Observable)param1Change.getMap());
/* 321 */           } catch (Exception exception) {
/* 322 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/* 325 */         for (b = 0; b < j; b++) {
/*     */           try {
/* 327 */             arrayOfMapChangeListener[b].onChanged(param1Change);
/* 328 */           } catch (Exception exception) {
/* 329 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 333 */         this.locked = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\MapListenerHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */