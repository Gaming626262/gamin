/*    */ package com.sun.javafx.collections;
/*    */ 
/*    */ import java.util.IdentityHashMap;
/*    */ import javafx.beans.InvalidationListener;
/*    */ import javafx.beans.Observable;
/*    */ import javafx.collections.ObservableListBase;
/*    */ import javafx.util.Callback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ElementObserver<E>
/*    */ {
/*    */   private Callback<E, Observable[]> extractor;
/*    */   private final Callback<E, InvalidationListener> listenerGenerator;
/*    */   private final ObservableListBase<E> list;
/*    */   
/*    */   private static class ElementsMapElement
/*    */   {
/*    */     InvalidationListener listener;
/*    */     int counter;
/*    */     
/*    */     public ElementsMapElement(InvalidationListener param1InvalidationListener) {
/* 43 */       this.listener = param1InvalidationListener;
/* 44 */       this.counter = 1;
/*    */     }
/*    */     
/*    */     public void increment() {
/* 48 */       this.counter++;
/*    */     }
/*    */     
/*    */     public int decrement() {
/* 52 */       return --this.counter;
/*    */     }
/*    */     
/*    */     private InvalidationListener getListener() {
/* 56 */       return this.listener;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   private IdentityHashMap<E, ElementsMapElement> elementsMap = new IdentityHashMap<>();
/*    */ 
/*    */   
/*    */   ElementObserver(Callback<E, Observable[]> paramCallback, Callback<E, InvalidationListener> paramCallback1, ObservableListBase<E> paramObservableListBase) {
/* 67 */     this.extractor = paramCallback;
/* 68 */     this.listenerGenerator = paramCallback1;
/* 69 */     this.list = paramObservableListBase;
/*    */   }
/*    */ 
/*    */   
/*    */   void attachListener(E paramE) {
/* 74 */     if (this.elementsMap != null && paramE != null) {
/* 75 */       if (this.elementsMap.containsKey(paramE)) {
/* 76 */         ((ElementsMapElement)this.elementsMap.get(paramE)).increment();
/*    */       } else {
/* 78 */         InvalidationListener invalidationListener = (InvalidationListener)this.listenerGenerator.call(paramE);
/* 79 */         for (Observable observable : (Observable[])this.extractor.call(paramE)) {
/* 80 */           observable.addListener(invalidationListener);
/*    */         }
/* 82 */         this.elementsMap.put(paramE, new ElementsMapElement(invalidationListener));
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   void detachListener(E paramE) {
/* 88 */     if (this.elementsMap != null && paramE != null) {
/* 89 */       ElementsMapElement elementsMapElement = this.elementsMap.get(paramE);
/* 90 */       for (Observable observable : (Observable[])this.extractor.call(paramE)) {
/* 91 */         observable.removeListener(elementsMapElement.getListener());
/*    */       }
/* 93 */       if (elementsMapElement.decrement() == 0)
/* 94 */         this.elementsMap.remove(paramE); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\ElementObserver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */