/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.BitSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.RandomAccess;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ModifiableObservableListBase;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableListBase;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObservableListWrapper<E>
/*     */   extends ModifiableObservableListBase<E>
/*     */   implements ObservableList<E>, SortableList<E>, RandomAccess
/*     */ {
/*     */   private final List<E> backingList;
/*     */   private final ElementObserver elementObserver;
/*     */   private SortHelper helper;
/*     */   
/*     */   public ObservableListWrapper(List<E> paramList) {
/*  53 */     this.backingList = paramList;
/*  54 */     this.elementObserver = null;
/*     */   }
/*     */   
/*     */   public ObservableListWrapper(List<E> paramList, Callback<E, Observable[]> paramCallback) {
/*  58 */     this.backingList = paramList;
/*  59 */     this.elementObserver = new ElementObserver<>(paramCallback, new Callback<E, InvalidationListener>()
/*     */         {
/*     */           public InvalidationListener call(final E e)
/*     */           {
/*  63 */             return new InvalidationListener()
/*     */               {
/*     */                 public void invalidated(Observable param2Observable)
/*     */                 {
/*  67 */                   ObservableListWrapper.this.beginChange();
/*  68 */                   byte b = 0;
/*  69 */                   int i = ObservableListWrapper.this.size();
/*  70 */                   for (; b < i; b++) {
/*  71 */                     if (ObservableListWrapper.this.get(b) == e) {
/*  72 */                       ObservableListWrapper.this.nextUpdate(b);
/*     */                     }
/*     */                   } 
/*  75 */                   ObservableListWrapper.this.endChange();
/*     */                 }
/*     */               };
/*     */           }
/*     */         }(ObservableListBase<E>)this);
/*  80 */     int i = this.backingList.size();
/*  81 */     for (byte b = 0; b < i; b++) {
/*  82 */       this.elementObserver.attachListener(this.backingList.get(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/*  89 */     return this.backingList.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  94 */     return this.backingList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doAdd(int paramInt, E paramE) {
/*  99 */     if (this.elementObserver != null)
/* 100 */       this.elementObserver.attachListener(paramE); 
/* 101 */     this.backingList.add(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   protected E doSet(int paramInt, E paramE) {
/* 106 */     E e = this.backingList.set(paramInt, paramE);
/* 107 */     if (this.elementObserver != null) {
/* 108 */       this.elementObserver.detachListener(e);
/* 109 */       this.elementObserver.attachListener(paramE);
/*     */     } 
/* 111 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   protected E doRemove(int paramInt) {
/* 116 */     E e = this.backingList.remove(paramInt);
/* 117 */     if (this.elementObserver != null)
/* 118 */       this.elementObserver.detachListener(e); 
/* 119 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 124 */     return this.backingList.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 129 */     return this.backingList.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 134 */     return this.backingList.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 139 */     return this.backingList.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 144 */     if (this.elementObserver != null) {
/* 145 */       int i = size();
/* 146 */       for (byte b = 0; b < i; b++) {
/* 147 */         this.elementObserver.detachListener(get(b));
/*     */       }
/*     */     } 
/* 150 */     if (hasListeners()) {
/* 151 */       beginChange();
/* 152 */       nextRemove(0, this);
/*     */     } 
/* 154 */     this.backingList.clear();
/* 155 */     this.modCount++;
/* 156 */     if (hasListeners()) {
/* 157 */       endChange();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 163 */     beginChange();
/* 164 */     for (int i = paramInt1; i < paramInt2; i++) {
/* 165 */       remove(paramInt1);
/*     */     }
/* 167 */     endChange();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 172 */     beginChange();
/* 173 */     BitSet bitSet = new BitSet(paramCollection.size()); int i;
/* 174 */     for (i = 0; i < size(); i++) {
/* 175 */       if (paramCollection.contains(get(i))) {
/* 176 */         bitSet.set(i);
/*     */       }
/*     */     } 
/* 179 */     if (!bitSet.isEmpty()) {
/* 180 */       i = size();
/* 181 */       while ((i = bitSet.previousSetBit(i - 1)) >= 0) {
/* 182 */         remove(i);
/*     */       }
/*     */     } 
/* 185 */     endChange();
/* 186 */     return !bitSet.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 191 */     beginChange();
/* 192 */     BitSet bitSet = new BitSet(paramCollection.size()); int i;
/* 193 */     for (i = 0; i < size(); i++) {
/* 194 */       if (!paramCollection.contains(get(i))) {
/* 195 */         bitSet.set(i);
/*     */       }
/*     */     } 
/* 198 */     if (!bitSet.isEmpty()) {
/* 199 */       i = size();
/* 200 */       while ((i = bitSet.previousSetBit(i - 1)) >= 0) {
/* 201 */         remove(i);
/*     */       }
/*     */     } 
/* 204 */     endChange();
/* 205 */     return !bitSet.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sort() {
/* 213 */     if (this.backingList.isEmpty()) {
/*     */       return;
/*     */     }
/* 216 */     int[] arrayOfInt = getSortHelper().sort(this.backingList);
/* 217 */     fireChange(new NonIterableChange.SimplePermutationChange(0, size(), arrayOfInt, this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sort(Comparator<? super E> paramComparator) {
/* 222 */     if (this.backingList.isEmpty()) {
/*     */       return;
/*     */     }
/* 225 */     int[] arrayOfInt = getSortHelper().sort(this.backingList, paramComparator);
/* 226 */     fireChange(new NonIterableChange.SimplePermutationChange(0, size(), arrayOfInt, this));
/*     */   }
/*     */   
/*     */   private SortHelper getSortHelper() {
/* 230 */     if (this.helper == null) {
/* 231 */       this.helper = new SortHelper();
/*     */     }
/* 233 */     return this.helper;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\ObservableListWrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */