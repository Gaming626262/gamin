/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableListBase;
/*     */ import javafx.collections.WeakListChangeListener;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ElementObservableListDecorator<E>
/*     */   extends ObservableListBase<E>
/*     */   implements ObservableList<E>
/*     */ {
/*     */   private final ObservableList<E> decoratedList;
/*     */   private final ListChangeListener<E> listener;
/*     */   private ElementObserver<E> observer;
/*     */   
/*     */   public ElementObservableListDecorator(ObservableList<E> paramObservableList, Callback<E, Observable[]> paramCallback) {
/*  51 */     this.observer = new ElementObserver<>(paramCallback, new Callback<E, InvalidationListener>()
/*     */         {
/*     */           public InvalidationListener call(final E e)
/*     */           {
/*  55 */             return new InvalidationListener()
/*     */               {
/*     */                 public void invalidated(Observable param2Observable)
/*     */                 {
/*  59 */                   ElementObservableListDecorator.this.beginChange();
/*  60 */                   byte b = 0;
/*  61 */                   if (ElementObservableListDecorator.this.decoratedList instanceof java.util.RandomAccess) {
/*  62 */                     int i = ElementObservableListDecorator.this.size();
/*  63 */                     for (; b < i; b++) {
/*  64 */                       if (ElementObservableListDecorator.this.get(b) == e) {
/*  65 */                         ElementObservableListDecorator.this.nextUpdate(b);
/*     */                       }
/*     */                     } 
/*     */                   } else {
/*  69 */                     for (Iterator iterator = ElementObservableListDecorator.this.iterator(); iterator.hasNext(); ) {
/*  70 */                       if (iterator.next() == e) {
/*  71 */                         ElementObservableListDecorator.this.nextUpdate(b);
/*     */                       }
/*  73 */                       b++;
/*     */                     } 
/*     */                   } 
/*  76 */                   ElementObservableListDecorator.this.endChange();
/*     */                 }
/*     */               };
/*     */           }
/*     */         }this);
/*  81 */     this.decoratedList = paramObservableList;
/*  82 */     int i = this.decoratedList.size();
/*  83 */     for (byte b = 0; b < i; b++) {
/*  84 */       this.observer.attachListener((E)this.decoratedList.get(b));
/*     */     }
/*  86 */     this.listener = new ListChangeListener<E>()
/*     */       {
/*     */         public void onChanged(ListChangeListener.Change<? extends E> param1Change)
/*     */         {
/*  90 */           while (param1Change.next()) {
/*  91 */             if (param1Change.wasAdded() || param1Change.wasRemoved()) {
/*  92 */               int i = param1Change.getRemovedSize();
/*  93 */               List list = param1Change.getRemoved(); int j;
/*  94 */               for (j = 0; j < i; j++) {
/*  95 */                 ElementObservableListDecorator.this.observer.detachListener(list.get(j));
/*     */               }
/*  97 */               if (ElementObservableListDecorator.this.decoratedList instanceof java.util.RandomAccess) {
/*  98 */                 j = param1Change.getTo();
/*  99 */                 for (int k = param1Change.getFrom(); k < j; k++)
/* 100 */                   ElementObservableListDecorator.this.observer.attachListener(ElementObservableListDecorator.this.decoratedList.get(k)); 
/*     */                 continue;
/*     */               } 
/* 103 */               for (Object object : param1Change.getAddedSubList()) {
/* 104 */                 ElementObservableListDecorator.this.observer.attachListener(object);
/*     */               }
/*     */             } 
/*     */           } 
/*     */           
/* 109 */           param1Change.reset();
/* 110 */           ElementObservableListDecorator.this.fireChange(param1Change);
/*     */         }
/*     */       };
/* 113 */     this.decoratedList.addListener((ListChangeListener)new WeakListChangeListener(this.listener));
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(T[] paramArrayOfT) {
/* 118 */     return (T[])this.decoratedList.toArray((Object[])paramArrayOfT);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 123 */     return this.decoratedList.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<E> subList(int paramInt1, int paramInt2) {
/* 128 */     return this.decoratedList.subList(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 133 */     return this.decoratedList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public E set(int paramInt, E paramE) {
/* 138 */     return (E)this.decoratedList.set(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 143 */     return this.decoratedList.retainAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 148 */     return this.decoratedList.removeAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public E remove(int paramInt) {
/* 153 */     return (E)this.decoratedList.remove(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 158 */     return this.decoratedList.remove(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(int paramInt) {
/* 163 */     return this.decoratedList.listIterator(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator() {
/* 168 */     return this.decoratedList.listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/* 173 */     return this.decoratedList.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 178 */     return this.decoratedList.iterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 183 */     return this.decoratedList.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/* 188 */     return this.decoratedList.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/* 193 */     return (E)this.decoratedList.get(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 198 */     return this.decoratedList.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 203 */     return this.decoratedList.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 208 */     this.decoratedList.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/* 213 */     return this.decoratedList.addAll(paramInt, paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends E> paramCollection) {
/* 218 */     return this.decoratedList.addAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int paramInt, E paramE) {
/* 223 */     this.decoratedList.add(paramInt, paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(E paramE) {
/* 228 */     return this.decoratedList.add(paramE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(Collection<? extends E> paramCollection) {
/* 233 */     return this.decoratedList.setAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setAll(E... paramVarArgs) {
/* 238 */     return this.decoratedList.setAll((Object[])paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(E... paramVarArgs) {
/* 243 */     return this.decoratedList.retainAll((Object[])paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(E... paramVarArgs) {
/* 248 */     return this.decoratedList.removeAll((Object[])paramVarArgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int paramInt1, int paramInt2) {
/* 253 */     this.decoratedList.remove(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(E... paramVarArgs) {
/* 258 */     return this.decoratedList.addAll((Object[])paramVarArgs);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\ElementObservableListDecorator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */