/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ModifiableObservableListBase;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObservableSequentialListWrapper<E>
/*     */   extends ModifiableObservableListBase<E>
/*     */   implements ObservableList<E>, SortableList<E>
/*     */ {
/*     */   private final List<E> backingList;
/*     */   private final ElementObserver elementObserver;
/*     */   private SortHelper helper;
/*     */   
/*     */   public ObservableSequentialListWrapper(List<E> paramList) {
/*  45 */     this.backingList = paramList;
/*  46 */     this.elementObserver = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObservableSequentialListWrapper(List<E> paramList, Callback<E, Observable[]> paramCallback) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial <init> : ()V
/*     */     //   4: aload_0
/*     */     //   5: aload_1
/*     */     //   6: putfield backingList : Ljava/util/List;
/*     */     //   9: aload_0
/*     */     //   10: new com/sun/javafx/collections/ElementObserver
/*     */     //   13: dup
/*     */     //   14: aload_2
/*     */     //   15: new com/sun/javafx/collections/ObservableSequentialListWrapper$1
/*     */     //   18: dup
/*     */     //   19: aload_0
/*     */     //   20: invokespecial <init> : (Lcom/sun/javafx/collections/ObservableSequentialListWrapper;)V
/*     */     //   23: aload_0
/*     */     //   24: invokespecial <init> : (Ljavafx/util/Callback;Ljavafx/util/Callback;Ljavafx/collections/ObservableListBase;)V
/*     */     //   27: putfield elementObserver : Lcom/sun/javafx/collections/ElementObserver;
/*     */     //   30: aload_0
/*     */     //   31: getfield backingList : Ljava/util/List;
/*     */     //   34: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   39: astore_3
/*     */     //   40: aload_3
/*     */     //   41: invokeinterface hasNext : ()Z
/*     */     //   46: ifeq -> 69
/*     */     //   49: aload_3
/*     */     //   50: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   55: astore #4
/*     */     //   57: aload_0
/*     */     //   58: getfield elementObserver : Lcom/sun/javafx/collections/ElementObserver;
/*     */     //   61: aload #4
/*     */     //   63: invokevirtual attachListener : (Ljava/lang/Object;)V
/*     */     //   66: goto -> 40
/*     */     //   69: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #49	-> 0
/*     */     //   #50	-> 4
/*     */     //   #51	-> 9
/*     */     //   #72	-> 30
/*     */     //   #73	-> 57
/*     */     //   #74	-> 66
/*     */     //   #75	-> 69
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/*  79 */     return this.backingList.contains(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/*  84 */     return this.backingList.containsAll(paramCollection);
/*     */   }
/*     */ 
/*     */   
/*     */   public int indexOf(Object paramObject) {
/*  89 */     return this.backingList.indexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public int lastIndexOf(Object paramObject) {
/*  94 */     return this.backingList.lastIndexOf(paramObject);
/*     */   }
/*     */ 
/*     */   
/*     */   public ListIterator<E> listIterator(final int index) {
/*  99 */     return new ListIterator<E>()
/*     */       {
/* 101 */         private final ListIterator<E> backingIt = ObservableSequentialListWrapper.this.backingList.listIterator(index);
/*     */         
/*     */         private E lastReturned;
/*     */         
/*     */         public boolean hasNext() {
/* 106 */           return this.backingIt.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public E next() {
/* 111 */           return this.lastReturned = this.backingIt.next();
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean hasPrevious() {
/* 116 */           return this.backingIt.hasPrevious();
/*     */         }
/*     */ 
/*     */         
/*     */         public E previous() {
/* 121 */           return this.lastReturned = this.backingIt.previous();
/*     */         }
/*     */ 
/*     */         
/*     */         public int nextIndex() {
/* 126 */           return this.backingIt.nextIndex();
/*     */         }
/*     */ 
/*     */         
/*     */         public int previousIndex() {
/* 131 */           return this.backingIt.previousIndex();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 136 */           ObservableSequentialListWrapper.this.beginChange();
/* 137 */           int i = previousIndex();
/* 138 */           this.backingIt.remove();
/* 139 */           ObservableSequentialListWrapper.this.nextRemove(i, this.lastReturned);
/* 140 */           ObservableSequentialListWrapper.this.endChange();
/*     */         }
/*     */ 
/*     */         
/*     */         public void set(E param1E) {
/* 145 */           ObservableSequentialListWrapper.this.beginChange();
/* 146 */           int i = previousIndex();
/* 147 */           this.backingIt.set(param1E);
/* 148 */           ObservableSequentialListWrapper.this.nextSet(i, this.lastReturned);
/* 149 */           ObservableSequentialListWrapper.this.endChange();
/*     */         }
/*     */ 
/*     */         
/*     */         public void add(E param1E) {
/* 154 */           ObservableSequentialListWrapper.this.beginChange();
/* 155 */           int i = nextIndex();
/* 156 */           this.backingIt.add(param1E);
/* 157 */           ObservableSequentialListWrapper.this.nextAdd(i, i + 1);
/* 158 */           ObservableSequentialListWrapper.this.endChange();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<E> iterator() {
/* 165 */     return listIterator();
/*     */   }
/*     */ 
/*     */   
/*     */   public E get(int paramInt) {
/*     */     try {
/* 171 */       return this.backingList.listIterator(paramInt).next();
/* 172 */     } catch (NoSuchElementException noSuchElementException) {
/* 173 */       throw new IndexOutOfBoundsException("Index: " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int paramInt, Collection<? extends E> paramCollection) {
/*     */     try {
/* 180 */       beginChange();
/* 181 */       boolean bool = false;
/* 182 */       ListIterator<E> listIterator = listIterator(paramInt);
/* 183 */       Iterator<? extends E> iterator = paramCollection.iterator();
/* 184 */       while (iterator.hasNext()) {
/* 185 */         listIterator.add(iterator.next());
/* 186 */         bool = true;
/*     */       } 
/* 188 */       endChange();
/* 189 */       return bool;
/* 190 */     } catch (NoSuchElementException noSuchElementException) {
/* 191 */       throw new IndexOutOfBoundsException("Index: " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 197 */     return this.backingList.size();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doAdd(int paramInt, E paramE) {
/*     */     try {
/* 203 */       this.backingList.listIterator(paramInt).add(paramE);
/* 204 */     } catch (NoSuchElementException noSuchElementException) {
/* 205 */       throw new IndexOutOfBoundsException("Index: " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected E doSet(int paramInt, E paramE) {
/*     */     try {
/* 212 */       ListIterator<E> listIterator = this.backingList.listIterator(paramInt);
/* 213 */       E e = listIterator.next();
/* 214 */       listIterator.set(paramE);
/* 215 */       return e;
/* 216 */     } catch (NoSuchElementException noSuchElementException) {
/* 217 */       throw new IndexOutOfBoundsException("Index: " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected E doRemove(int paramInt) {
/*     */     try {
/* 224 */       ListIterator<E> listIterator = this.backingList.listIterator(paramInt);
/* 225 */       E e = listIterator.next();
/* 226 */       listIterator.remove();
/* 227 */       return e;
/* 228 */     } catch (NoSuchElementException noSuchElementException) {
/* 229 */       throw new IndexOutOfBoundsException("Index: " + paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void sort() {
/* 236 */     if (this.backingList.isEmpty()) {
/*     */       return;
/*     */     }
/* 239 */     int[] arrayOfInt = getSortHelper().sort(this.backingList);
/* 240 */     fireChange(new NonIterableChange.SimplePermutationChange(0, size(), arrayOfInt, this));
/*     */   }
/*     */ 
/*     */   
/*     */   public void sort(Comparator<? super E> paramComparator) {
/* 245 */     if (this.backingList.isEmpty()) {
/*     */       return;
/*     */     }
/* 248 */     int[] arrayOfInt = getSortHelper().sort(this.backingList, paramComparator);
/* 249 */     fireChange(new NonIterableChange.SimplePermutationChange(0, size(), arrayOfInt, this));
/*     */   }
/*     */   
/*     */   private SortHelper getSortHelper() {
/* 253 */     if (this.helper == null) {
/* 254 */       this.helper = new SortHelper();
/*     */     }
/* 256 */     return this.helper;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\ObservableSequentialListWrapper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */