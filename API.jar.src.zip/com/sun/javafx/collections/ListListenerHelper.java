/*     */ package com.sun.javafx.collections;
/*     */ 
/*     */ import com.sun.javafx.binding.ExpressionHelperBase;
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.collections.ListChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListListenerHelper<E>
/*     */   extends ExpressionHelperBase
/*     */ {
/*     */   public static <E> ListListenerHelper<E> addListener(ListListenerHelper<E> paramListListenerHelper, InvalidationListener paramInvalidationListener) {
/*  43 */     if (paramInvalidationListener == null) {
/*  44 */       throw new NullPointerException();
/*     */     }
/*  46 */     return (paramListListenerHelper == null) ? new SingleInvalidation<>(paramInvalidationListener) : paramListListenerHelper.addListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <E> ListListenerHelper<E> removeListener(ListListenerHelper<E> paramListListenerHelper, InvalidationListener paramInvalidationListener) {
/*  50 */     if (paramInvalidationListener == null) {
/*  51 */       throw new NullPointerException();
/*     */     }
/*  53 */     return (paramListListenerHelper == null) ? null : paramListListenerHelper.removeListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <E> ListListenerHelper<E> addListener(ListListenerHelper<E> paramListListenerHelper, ListChangeListener<? super E> paramListChangeListener) {
/*  57 */     if (paramListChangeListener == null) {
/*  58 */       throw new NullPointerException();
/*     */     }
/*  60 */     return (paramListListenerHelper == null) ? new SingleChange<>(paramListChangeListener) : paramListListenerHelper.addListener(paramListChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> ListListenerHelper<E> removeListener(ListListenerHelper<E> paramListListenerHelper, ListChangeListener<? super E> paramListChangeListener) {
/*  64 */     if (paramListChangeListener == null) {
/*  65 */       throw new NullPointerException();
/*     */     }
/*  67 */     return (paramListListenerHelper == null) ? null : paramListListenerHelper.removeListener(paramListChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> void fireValueChangedEvent(ListListenerHelper<E> paramListListenerHelper, ListChangeListener.Change<? extends E> paramChange) {
/*  71 */     if (paramListListenerHelper != null) {
/*  72 */       paramChange.reset();
/*  73 */       paramListListenerHelper.fireValueChangedEvent(paramChange);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static <E> boolean hasListeners(ListListenerHelper<E> paramListListenerHelper) {
/*  78 */     return (paramListListenerHelper != null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract ListListenerHelper<E> addListener(InvalidationListener paramInvalidationListener);
/*     */ 
/*     */   
/*     */   protected abstract ListListenerHelper<E> removeListener(InvalidationListener paramInvalidationListener);
/*     */ 
/*     */   
/*     */   protected abstract ListListenerHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   protected abstract ListListenerHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   protected abstract void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange);
/*     */   
/*     */   private static class SingleInvalidation<E>
/*     */     extends ListListenerHelper<E>
/*     */   {
/*     */     private final InvalidationListener listener;
/*     */     
/*     */     private SingleInvalidation(InvalidationListener param1InvalidationListener) {
/* 100 */       this.listener = param1InvalidationListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 105 */       return new ListListenerHelper.Generic<>(this.listener, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 110 */       return param1InvalidationListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 115 */       return new ListListenerHelper.Generic<>(this.listener, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 120 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/*     */       try {
/* 126 */         this.listener.invalidated((Observable)param1Change.getList());
/* 127 */       } catch (Exception exception) {
/* 128 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleChange<E>
/*     */     extends ListListenerHelper<E> {
/*     */     private final ListChangeListener<? super E> listener;
/*     */     
/*     */     private SingleChange(ListChangeListener<? super E> param1ListChangeListener) {
/* 138 */       this.listener = param1ListChangeListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 143 */       return new ListListenerHelper.Generic<>(param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 148 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 153 */       return new ListListenerHelper.Generic<>(this.listener, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 158 */       return param1ListChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/*     */       try {
/* 164 */         this.listener.onChanged(param1Change);
/* 165 */       } catch (Exception exception) {
/* 166 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Generic<E>
/*     */     extends ListListenerHelper<E> {
/*     */     private InvalidationListener[] invalidationListeners;
/*     */     private ListChangeListener<? super E>[] changeListeners;
/*     */     private int invalidationSize;
/*     */     private int changeSize;
/*     */     private boolean locked;
/*     */     
/*     */     private Generic(InvalidationListener param1InvalidationListener1, InvalidationListener param1InvalidationListener2) {
/* 180 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener1, param1InvalidationListener2 };
/* 181 */       this.invalidationSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(ListChangeListener<? super E> param1ListChangeListener1, ListChangeListener<? super E> param1ListChangeListener2) {
/* 185 */       this.changeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener1, param1ListChangeListener2 };
/* 186 */       this.changeSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(InvalidationListener param1InvalidationListener, ListChangeListener<? super E> param1ListChangeListener) {
/* 190 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 191 */       this.invalidationSize = 1;
/* 192 */       this.changeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener };
/* 193 */       this.changeSize = 1;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Generic<E> addListener(InvalidationListener param1InvalidationListener) {
/* 198 */       if (this.invalidationListeners == null) {
/* 199 */         this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 200 */         this.invalidationSize = 1;
/*     */       } else {
/* 202 */         int i = this.invalidationListeners.length;
/* 203 */         if (this.locked) {
/* 204 */           int j = (this.invalidationSize < i) ? i : (i * 3 / 2 + 1);
/* 205 */           this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/* 206 */         } else if (this.invalidationSize == i) {
/* 207 */           this.invalidationSize = trim(this.invalidationSize, (Object[])this.invalidationListeners);
/* 208 */           if (this.invalidationSize == i) {
/* 209 */             int j = i * 3 / 2 + 1;
/* 210 */             this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/*     */           } 
/*     */         } 
/* 213 */         this.invalidationListeners[this.invalidationSize++] = param1InvalidationListener;
/*     */       } 
/* 215 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 220 */       if (this.invalidationListeners != null) {
/* 221 */         for (byte b = 0; b < this.invalidationSize; b++) {
/* 222 */           if (param1InvalidationListener.equals(this.invalidationListeners[b])) {
/* 223 */             if (this.invalidationSize == 1) {
/* 224 */               if (this.changeSize == 1) {
/* 225 */                 return new ListListenerHelper.SingleChange<>(this.changeListeners[0]);
/*     */               }
/* 227 */               this.invalidationListeners = null;
/* 228 */               this.invalidationSize = 0; break;
/* 229 */             }  if (this.invalidationSize == 2 && this.changeSize == 0) {
/* 230 */               return new ListListenerHelper.SingleInvalidation<>(this.invalidationListeners[1 - b]);
/*     */             }
/* 232 */             int i = this.invalidationSize - b - 1;
/* 233 */             InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 234 */             if (this.locked) {
/* 235 */               this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
/* 236 */               System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, b);
/*     */             } 
/* 238 */             if (i > 0) {
/* 239 */               System.arraycopy(arrayOfInvalidationListener, b + 1, this.invalidationListeners, b, i);
/*     */             }
/* 241 */             this.invalidationSize--;
/* 242 */             if (!this.locked) {
/* 243 */               this.invalidationListeners[this.invalidationSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 250 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 255 */       if (this.changeListeners == null) {
/* 256 */         this.changeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener };
/* 257 */         this.changeSize = 1;
/*     */       } else {
/* 259 */         int i = this.changeListeners.length;
/* 260 */         if (this.locked) {
/* 261 */           int j = (this.changeSize < i) ? i : (i * 3 / 2 + 1);
/* 262 */           this.changeListeners = Arrays.<ListChangeListener<? super E>>copyOf(this.changeListeners, j);
/* 263 */         } else if (this.changeSize == i) {
/* 264 */           this.changeSize = trim(this.changeSize, (Object[])this.changeListeners);
/* 265 */           if (this.changeSize == i) {
/* 266 */             int j = i * 3 / 2 + 1;
/* 267 */             this.changeListeners = Arrays.<ListChangeListener<? super E>>copyOf(this.changeListeners, j);
/*     */           } 
/*     */         } 
/* 270 */         this.changeListeners[this.changeSize++] = param1ListChangeListener;
/*     */       } 
/* 272 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListListenerHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 277 */       if (this.changeListeners != null) {
/* 278 */         for (byte b = 0; b < this.changeSize; b++) {
/* 279 */           if (param1ListChangeListener.equals(this.changeListeners[b])) {
/* 280 */             if (this.changeSize == 1) {
/* 281 */               if (this.invalidationSize == 1) {
/* 282 */                 return new ListListenerHelper.SingleInvalidation<>(this.invalidationListeners[0]);
/*     */               }
/* 284 */               this.changeListeners = null;
/* 285 */               this.changeSize = 0; break;
/* 286 */             }  if (this.changeSize == 2 && this.invalidationSize == 0) {
/* 287 */               return new ListListenerHelper.SingleChange<>(this.changeListeners[1 - b]);
/*     */             }
/* 289 */             int i = this.changeSize - b - 1;
/* 290 */             ListChangeListener<? super E>[] arrayOfListChangeListener = this.changeListeners;
/* 291 */             if (this.locked) {
/* 292 */               this.changeListeners = (ListChangeListener<? super E>[])new ListChangeListener[this.changeListeners.length];
/* 293 */               System.arraycopy(arrayOfListChangeListener, 0, this.changeListeners, 0, b);
/*     */             } 
/* 295 */             if (i > 0) {
/* 296 */               System.arraycopy(arrayOfListChangeListener, b + 1, this.changeListeners, b, i);
/*     */             }
/* 298 */             this.changeSize--;
/* 299 */             if (!this.locked) {
/* 300 */               this.changeListeners[this.changeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 307 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/* 312 */       InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 313 */       int i = this.invalidationSize;
/* 314 */       ListChangeListener<? super E>[] arrayOfListChangeListener = this.changeListeners;
/* 315 */       int j = this.changeSize;
/*     */       
/*     */       try {
/* 318 */         this.locked = true; byte b;
/* 319 */         for (b = 0; b < i; b++) {
/*     */           try {
/* 321 */             arrayOfInvalidationListener[b].invalidated((Observable)param1Change.getList());
/* 322 */           } catch (Exception exception) {
/* 323 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/* 326 */         for (b = 0; b < j; b++) {
/* 327 */           param1Change.reset();
/*     */           try {
/* 329 */             arrayOfListChangeListener[b].onChanged(param1Change);
/* 330 */           } catch (Exception exception) {
/* 331 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 335 */         this.locked = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\ListListenerHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */