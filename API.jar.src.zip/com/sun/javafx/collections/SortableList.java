package com.sun.javafx.collections;

import java.util.Comparator;
import java.util.List;

public interface SortableList<E> extends List<E> {
  void sort();
  
  void sort(Comparator<? super E> paramComparator);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\collections\SortableList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */