/*     */ package com.sun.javafx.application;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.javafx.stage.StageHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.security.AccessController;
/*     */ import java.text.Normalizer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Base64;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ import javafx.application.Application;
/*     */ import javafx.application.Preloader;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LauncherImpl
/*     */ {
/*     */   public static final String LAUNCH_MODE_CLASS = "LM_CLASS";
/*     */   public static final String LAUNCH_MODE_JAR = "LM_JAR";
/*     */   public static final String LAUNCH_MODE_MODULE = "LM_MODULE";
/*     */   private static final boolean trace = false;
/*  85 */   private static final boolean verbose = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.verbose")))).booleanValue();
/*     */   
/*     */   private static final String MF_MAIN_CLASS = "Main-Class";
/*     */   
/*     */   private static final String MF_JAVAFX_MAIN = "JavaFX-Application-Class";
/*     */   
/*     */   private static final String MF_JAVAFX_PRELOADER = "JavaFX-Preloader-Class";
/*     */   
/*     */   private static final String MF_JAVAFX_CLASS_PATH = "JavaFX-Class-Path";
/*     */   
/*     */   private static final String MF_JAVAFX_ARGUMENT_PREFIX = "JavaFX-Argument-";
/*     */   
/*     */   private static final String MF_JAVAFX_PARAMETER_NAME_PREFIX = "JavaFX-Parameter-Name-";
/*     */   private static final String MF_JAVAFX_PARAMETER_VALUE_PREFIX = "JavaFX-Parameter-Value-";
/*     */   private static final boolean simulateSlowProgress = false;
/* 100 */   private static AtomicBoolean launchCalled = new AtomicBoolean(false);
/*     */ 
/*     */   
/* 103 */   private static final AtomicBoolean toolkitStarted = new AtomicBoolean(false);
/*     */ 
/*     */   
/* 106 */   private static volatile RuntimeException launchException = null;
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static Preloader currentPreloader = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private static Class<? extends Preloader> savedPreloaderClass = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static ClassLoader savedMainCcl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchApplication(Class<? extends Application> paramClass, String[] paramArrayOfString) {
/* 136 */     Class<? extends Preloader> clazz = savedPreloaderClass;
/*     */     
/* 138 */     if (clazz == null) {
/*     */       
/* 140 */       String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.preloader"));
/*     */       
/* 142 */       if (str != null) {
/*     */         try {
/* 144 */           clazz = (Class)Class.forName(str, false, paramClass
/* 145 */               .getClassLoader());
/* 146 */         } catch (Exception exception) {
/* 147 */           System.err.printf("Could not load preloader class '" + str + "', continuing without preloader.", new Object[0]);
/*     */           
/* 149 */           exception.printStackTrace();
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 154 */     launchApplication(paramClass, clazz, paramArrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchApplication(Class<? extends Application> paramClass, Class<? extends Preloader> paramClass1, String[] paramArrayOfString) {
/* 172 */     if (Application.isEventThread()) {
/* 173 */       throw new IllegalStateException("Application launch must not be called on the JavaFX Application Thread");
/*     */     }
/* 175 */     if (launchCalled.getAndSet(true)) {
/* 176 */       throw new IllegalStateException("Application launch must not be called more than once");
/*     */     }
/*     */     
/* 179 */     if (!Application.class.isAssignableFrom(paramClass)) {
/* 180 */       throw new IllegalArgumentException("Error: " + paramClass.getName() + " is not a subclass of javafx.application.Application");
/*     */     }
/*     */ 
/*     */     
/* 184 */     if (paramClass1 != null && !Preloader.class.isAssignableFrom(paramClass1)) {
/* 185 */       throw new IllegalArgumentException("Error: " + paramClass1.getName() + " is not a subclass of javafx.application.Preloader");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     CountDownLatch countDownLatch = new CountDownLatch(1);
/* 194 */     Thread thread = new Thread(() -> {
/*     */           try {
/*     */             launchApplication1(paramClass1, paramClass2, paramArrayOfString);
/* 197 */           } catch (RuntimeException runtimeException) {
/*     */             launchException = runtimeException;
/* 199 */           } catch (Exception exception) {
/*     */             
/*     */             launchException = new RuntimeException("Application launch exception", exception);
/* 202 */           } catch (Error error) {
/*     */             launchException = new RuntimeException("Application launch error", error);
/*     */           } finally {
/*     */             paramCountDownLatch.countDown();
/*     */           } 
/*     */         });
/*     */     
/* 209 */     thread.setName("JavaFX-Launcher");
/* 210 */     thread.start();
/*     */ 
/*     */     
/*     */     try {
/* 214 */       countDownLatch.await();
/* 215 */     } catch (InterruptedException interruptedException) {
/* 216 */       throw new RuntimeException("Unexpected exception: ", interruptedException);
/*     */     } 
/*     */     
/* 219 */     if (launchException != null) {
/* 220 */       throw launchException;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchApplication(String paramString1, String paramString2, String[] paramArrayOfString) {
/* 241 */     if (verbose) {
/* 242 */       System.err.println("JavaFX launchApplication method: launchMode=" + paramString2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 251 */     String str1 = null;
/* 252 */     String str2 = null;
/* 253 */     String[] arrayOfString = paramArrayOfString;
/* 254 */     ClassLoader classLoader = null;
/* 255 */     ModuleAccess moduleAccess = null;
/*     */     
/* 257 */     if (paramString2.equals("LM_JAR")) {
/* 258 */       Attributes attributes = getJarAttributes(paramString1);
/* 259 */       if (attributes == null) {
/* 260 */         abort(null, "Can't get manifest attributes from jar", new Object[0]);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 266 */       String str = attributes.getValue("JavaFX-Class-Path");
/* 267 */       if (str != null) {
/* 268 */         if (str.trim().length() == 0) {
/* 269 */           str = null;
/*     */         } else {
/* 271 */           if (verbose) {
/* 272 */             System.err.println("WARNING: Application jar uses deprecated JavaFX-Class-Path attribute. Please use Class-Path instead.");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 281 */           classLoader = setupJavaFXClassLoader(new File(paramString1), str);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 286 */       if (paramArrayOfString.length == 0) {
/* 287 */         arrayOfString = getAppArguments(attributes);
/*     */       }
/*     */ 
/*     */       
/* 291 */       str1 = attributes.getValue("JavaFX-Application-Class");
/* 292 */       if (str1 == null) {
/*     */         
/* 294 */         str1 = attributes.getValue("Main-Class");
/* 295 */         if (str1 == null)
/*     */         {
/* 297 */           abort(null, "JavaFX jar manifest requires a valid JavaFX-Appliation-Class or Main-Class entry", new Object[0]);
/*     */         }
/*     */       } 
/* 300 */       str1 = str1.trim();
/*     */ 
/*     */       
/* 303 */       str2 = attributes.getValue("JavaFX-Preloader-Class");
/* 304 */       if (str2 != null) {
/* 305 */         str2 = str2.trim();
/*     */       }
/* 307 */     } else if (paramString2.equals("LM_CLASS")) {
/* 308 */       str1 = paramString1;
/* 309 */     } else if (paramString2.equals("LM_MODULE")) {
/*     */       String str;
/* 311 */       int i = paramString1.indexOf('/');
/*     */       
/* 313 */       if (i == -1) {
/* 314 */         str = paramString1;
/* 315 */         str1 = null;
/*     */       } else {
/* 317 */         str = paramString1.substring(0, i);
/* 318 */         str1 = paramString1.substring(i + 1);
/*     */       } 
/*     */       
/* 321 */       moduleAccess = ModuleAccess.load(str);
/*     */ 
/*     */       
/* 324 */       if (str1 == null) {
/* 325 */         Optional<String> optional = moduleAccess.getDescriptor().mainClass();
/* 326 */         if (!optional.isPresent()) {
/* 327 */           abort(null, "Module %1$s does not have a MainClass attribute, use -m <module>/<main-class>", new Object[] { str });
/*     */         }
/*     */         
/* 330 */         str1 = optional.get();
/*     */       } 
/*     */     } else {
/* 333 */       abort(new IllegalArgumentException("The launchMode argument must be one of LM_CLASS, LM_JAR or LM_MODULE"), "Invalid launch mode: %1$s", new Object[] { paramString2 });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     if (str2 == null) {
/* 340 */       str2 = System.getProperty("javafx.preloader");
/*     */     }
/*     */     
/* 343 */     if (str1 == null) {
/* 344 */       abort(null, "No main JavaFX class to launch", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 348 */     if (classLoader != null) {
/*     */       
/*     */       try {
/* 351 */         Class<?> clazz = classLoader.loadClass(LauncherImpl.class.getName());
/*     */ 
/*     */         
/* 354 */         Method method = clazz.getMethod("launchApplicationWithArgs", new Class[] { ModuleAccess.class, String.class, String.class, (new String[0])
/* 355 */               .getClass() });
/*     */ 
/*     */         
/* 358 */         Thread.currentThread().setContextClassLoader(classLoader);
/* 359 */         method.invoke(null, new Object[] { null, str1, str2, arrayOfString });
/* 360 */       } catch (Exception exception) {
/* 361 */         abort(exception, "Exception while launching application", new Object[0]);
/*     */       } 
/*     */     } else {
/* 364 */       launchApplicationWithArgs(moduleAccess, str1, str2, arrayOfString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> loadClass(ModuleAccess paramModuleAccess, String paramString) {
/* 372 */     Class<?> clazz = null;
/* 373 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     if (paramModuleAccess != null) {
/* 380 */       clazz = paramModuleAccess.classForName(paramString);
/*     */     } else {
/*     */       try {
/* 383 */         clazz = Class.forName(paramString, true, classLoader);
/* 384 */       } catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {}
/*     */     } 
/*     */     
/* 387 */     if (clazz == null && System.getProperty("os.name", "").contains("OS X") && 
/* 388 */       Normalizer.isNormalized(paramString, Normalizer.Form.NFD)) {
/*     */ 
/*     */       
/* 391 */       String str = Normalizer.normalize(paramString, Normalizer.Form.NFC);
/*     */       
/* 393 */       if (paramModuleAccess != null) {
/* 394 */         clazz = paramModuleAccess.classForName(str);
/*     */       } else {
/*     */         try {
/* 397 */           clazz = Class.forName(str, true, classLoader);
/* 398 */         } catch (ClassNotFoundException|NoClassDefFoundError classNotFoundException) {}
/*     */       } 
/*     */     } 
/*     */     
/* 402 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void launchApplicationWithArgs(ModuleAccess paramModuleAccess, String paramString1, String paramString2, String[] paramArrayOfString) {
/*     */     try {
/* 410 */       startToolkit();
/* 411 */     } catch (InterruptedException interruptedException) {
/* 412 */       abort(interruptedException, "Toolkit initialization error", new Object[] { paramString1 });
/*     */     } 
/*     */ 
/*     */     
/* 416 */     Class<? extends Preloader> clazz1 = null;
/* 417 */     Class<?> clazz2 = null;
/*     */     
/* 419 */     AtomicReference<Class<?>> atomicReference1 = new AtomicReference();
/* 420 */     AtomicReference<Class<?>> atomicReference2 = new AtomicReference();
/* 421 */     PlatformImpl.runAndWait(() -> {
/*     */           Class<?> clazz = loadClass(paramModuleAccess, paramString1);
/*     */           
/*     */           if (clazz == null) {
/*     */             if (paramModuleAccess != null) {
/*     */               abort(null, "Missing JavaFX application class %1$s in module %2$s", new Object[] { paramString1, paramModuleAccess.getName() });
/*     */             } else {
/*     */               abort(null, "Missing JavaFX application class %1$s", new Object[] { paramString1 });
/*     */             } 
/*     */           }
/*     */           
/*     */           paramAtomicReference1.set(clazz);
/*     */           
/*     */           if (paramString2 != null) {
/*     */             clazz = loadClass(null, paramString2);
/*     */             
/*     */             if (clazz == null) {
/*     */               abort(null, "Missing JavaFX preloader class %1$s", new Object[] { paramString2 });
/*     */             }
/*     */             
/*     */             if (!Preloader.class.isAssignableFrom(clazz)) {
/*     */               abort(null, "JavaFX preloader class %1$s does not extend javafx.application.Preloader", new Object[] { clazz.getName() });
/*     */             }
/*     */             paramAtomicReference2.set(clazz.asSubclass(Preloader.class));
/*     */           } 
/*     */         });
/* 447 */     clazz1 = (Class)atomicReference2.get();
/* 448 */     clazz2 = atomicReference1.get();
/*     */ 
/*     */ 
/*     */     
/* 452 */     savedPreloaderClass = clazz1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 457 */     NoSuchMethodException noSuchMethodException = null;
/*     */     try {
/* 459 */       Method method = clazz2.getMethod("main", new Class[] { (new String[0])
/* 460 */             .getClass() });
/* 461 */       if (verbose) {
/* 462 */         System.err.println("Calling main(String[]) method");
/*     */       }
/* 464 */       savedMainCcl = Thread.currentThread().getContextClassLoader();
/* 465 */       method.invoke(null, new Object[] { paramArrayOfString });
/*     */       return;
/* 467 */     } catch (NoSuchMethodException|IllegalAccessException noSuchMethodException1) {
/* 468 */       noSuchMethodException = noSuchMethodException1;
/* 469 */       savedPreloaderClass = null;
/* 470 */       if (verbose) {
/* 471 */         System.err.println("WARNING: Cannot access application main method: " + noSuchMethodException1);
/*     */       }
/* 473 */     } catch (InvocationTargetException invocationTargetException) {
/* 474 */       invocationTargetException.printStackTrace();
/* 475 */       abort(null, "Exception running application %1$s", new Object[] { clazz2.getName() });
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 480 */     if (!Application.class.isAssignableFrom(clazz2)) {
/* 481 */       abort(noSuchMethodException, "JavaFX application class %1$s does not extend javafx.application.Application", new Object[] { clazz2.getName() });
/*     */     }
/* 483 */     Class<? extends Application> clazz = clazz2.asSubclass(Application.class);
/*     */     
/* 485 */     if (verbose) {
/* 486 */       System.err.println("Launching application directly");
/*     */     }
/* 488 */     launchApplication(clazz, clazz1, paramArrayOfString);
/*     */   }
/*     */   
/*     */   private static URL fileToURL(File paramFile) throws IOException {
/* 492 */     return paramFile.getCanonicalFile().toURI().toURL();
/*     */   }
/*     */   
/*     */   private static ClassLoader setupJavaFXClassLoader(File paramFile, String paramString) {
/*     */     try {
/* 497 */       File file = paramFile.getParentFile();
/* 498 */       ArrayList<URL> arrayList = new ArrayList();
/*     */ 
/*     */ 
/*     */       
/* 502 */       String str = paramString;
/* 503 */       if (str != null)
/*     */       {
/*     */         
/* 506 */         while (str.length() > 0) {
/* 507 */           int i = str.indexOf(" ");
/* 508 */           if (i < 0) {
/* 509 */             String str1 = str;
/*     */             
/* 511 */             File file1 = (file == null) ? new File(str1) : new File(file, str1);
/* 512 */             if (file1.exists()) {
/* 513 */               arrayList.add(fileToURL(file1)); break;
/* 514 */             }  if (verbose) {
/* 515 */               System.err.println("Class Path entry \"" + str1 + "\" does not exist, ignoring");
/*     */             }
/*     */             break;
/*     */           } 
/* 519 */           if (i > 0) {
/* 520 */             String str1 = str.substring(0, i);
/*     */             
/* 522 */             File file1 = (file == null) ? new File(str1) : new File(file, str1);
/* 523 */             if (file1.exists()) {
/* 524 */               arrayList.add(fileToURL(file1));
/* 525 */             } else if (verbose) {
/* 526 */               System.err.println("Class Path entry \"" + str1 + "\" does not exist, ignoring");
/*     */             } 
/*     */           } 
/*     */           
/* 530 */           str = str.substring(i + 1);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 535 */       if (!arrayList.isEmpty()) {
/* 536 */         ArrayList<URL> arrayList1 = new ArrayList();
/*     */ 
/*     */ 
/*     */         
/* 540 */         str = System.getProperty("java.class.path");
/* 541 */         if (str != null) {
/* 542 */           while (str.length() > 0) {
/* 543 */             int i = str.indexOf(File.pathSeparatorChar);
/* 544 */             if (i < 0) {
/* 545 */               String str1 = str;
/* 546 */               arrayList1.add(fileToURL(new File(str1))); break;
/*     */             } 
/* 548 */             if (i > 0) {
/* 549 */               String str1 = str.substring(0, i);
/* 550 */               arrayList1.add(fileToURL(new File(str1)));
/*     */             } 
/* 552 */             str = str.substring(i + 1);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 557 */         arrayList1.addAll(arrayList);
/*     */         
/* 559 */         URL[] arrayOfURL = arrayList1.<URL>toArray(new URL[0]);
/* 560 */         if (verbose) {
/* 561 */           System.err.println("===== URL list");
/* 562 */           for (byte b = 0; b < arrayOfURL.length; b++) {
/* 563 */             System.err.println("" + arrayOfURL[b]);
/*     */           }
/* 565 */           System.err.println("=====");
/*     */         } 
/* 567 */         return new URLClassLoader(arrayOfURL, ClassLoader.getPlatformClassLoader());
/*     */       } 
/* 569 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     return null;
/*     */   }
/*     */   
/*     */   private static String decodeBase64(String paramString) throws IOException {
/* 579 */     return new String(Base64.getDecoder().decode(paramString));
/*     */   }
/*     */   
/*     */   private static String[] getAppArguments(Attributes paramAttributes) {
/* 583 */     LinkedList<String> linkedList = new LinkedList();
/*     */     
/*     */     try {
/* 586 */       byte b = 1;
/* 587 */       String str1 = "JavaFX-Argument-";
/* 588 */       while (paramAttributes.getValue(str1 + str1) != null) {
/* 589 */         linkedList.add(decodeBase64(paramAttributes.getValue(str1 + str1)));
/* 590 */         b++;
/*     */       } 
/*     */       
/* 593 */       String str2 = "JavaFX-Parameter-Name-";
/* 594 */       String str3 = "JavaFX-Parameter-Value-";
/* 595 */       b = 1;
/* 596 */       while (paramAttributes.getValue(str2 + str2) != null) {
/* 597 */         String str4 = decodeBase64(paramAttributes.getValue(str2 + str2));
/* 598 */         String str5 = null;
/* 599 */         if (paramAttributes.getValue(str3 + str3) != null) {
/* 600 */           str5 = decodeBase64(paramAttributes.getValue(str3 + str3));
/*     */         }
/* 602 */         linkedList.add("--" + str4 + "=" + ((str5 != null) ? str5 : ""));
/* 603 */         b++;
/*     */       } 
/* 605 */     } catch (IOException iOException) {
/* 606 */       if (verbose) {
/* 607 */         System.err.println("Failed to extract application parameters");
/*     */       }
/* 609 */       iOException.printStackTrace();
/*     */     } 
/*     */     
/* 612 */     return linkedList.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void abort(Throwable paramThrowable, String paramString, Object... paramVarArgs) {
/* 617 */     String str = String.format(paramString, paramVarArgs);
/* 618 */     if (str != null) {
/* 619 */       System.err.println(str);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     System.exit(1);
/*     */   }
/*     */   
/*     */   private static Attributes getJarAttributes(String paramString) {
/* 633 */     JarFile jarFile = null;
/*     */     try {
/* 635 */       jarFile = new JarFile(paramString);
/* 636 */       Manifest manifest = jarFile.getManifest();
/* 637 */       if (manifest == null) {
/* 638 */         abort(null, "No manifest in jar file %1$s", new Object[] { paramString });
/*     */       }
/* 640 */       return manifest.getMainAttributes();
/* 641 */     } catch (IOException iOException) {
/* 642 */       abort(iOException, "Error launching jar file %1%s", new Object[] { paramString });
/*     */     } finally {
/*     */       try {
/* 645 */         jarFile.close();
/* 646 */       } catch (IOException iOException) {}
/*     */     } 
/* 648 */     return null;
/*     */   }
/*     */   
/*     */   private static void startToolkit() throws InterruptedException {
/* 652 */     if (toolkitStarted.getAndSet(true)) {
/*     */       return;
/*     */     }
/*     */     
/* 656 */     CountDownLatch countDownLatch = new CountDownLatch(1);
/*     */ 
/*     */     
/* 659 */     PlatformImpl.startup(() -> paramCountDownLatch.countDown());
/*     */ 
/*     */     
/* 662 */     countDownLatch.await();
/*     */   }
/*     */   
/*     */   private static volatile boolean error = false;
/* 666 */   private static volatile Throwable pConstructorError = null;
/* 667 */   private static volatile Throwable pInitError = null;
/* 668 */   private static volatile Throwable pStartError = null;
/* 669 */   private static volatile Throwable pStopError = null;
/* 670 */   private static volatile Throwable constructorError = null;
/* 671 */   private static volatile Throwable initError = null;
/* 672 */   private static volatile Throwable startError = null;
/* 673 */   private static volatile Throwable stopError = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void launchApplication1(Class<? extends Application> paramClass, Class<? extends Preloader> paramClass1, String[] paramArrayOfString) throws Exception {
/* 679 */     startToolkit();
/*     */     
/* 681 */     if (savedMainCcl != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 689 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 690 */       if (classLoader != null && classLoader != savedMainCcl) {
/* 691 */         PlatformImpl.runLater(() -> Thread.currentThread().setContextClassLoader(paramClassLoader));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 697 */     final AtomicBoolean pStartCalled = new AtomicBoolean(false);
/* 698 */     final AtomicBoolean startCalled = new AtomicBoolean(false);
/* 699 */     final AtomicBoolean exitCalled = new AtomicBoolean(false);
/* 700 */     AtomicBoolean atomicBoolean4 = new AtomicBoolean(false);
/* 701 */     final CountDownLatch shutdownLatch = new CountDownLatch(1);
/* 702 */     final CountDownLatch pShutdownLatch = new CountDownLatch(1);
/*     */     
/* 704 */     PlatformImpl.FinishListener finishListener = new PlatformImpl.FinishListener() {
/*     */         public void idle(boolean param1Boolean) {
/* 706 */           if (!param1Boolean) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/* 711 */           if (startCalled.get()) {
/* 712 */             shutdownLatch.countDown();
/* 713 */           } else if (pStartCalled.get()) {
/* 714 */             pShutdownLatch.countDown();
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void exitCalled() {
/* 720 */           exitCalled.set(true);
/* 721 */           shutdownLatch.countDown();
/*     */         }
/*     */       };
/* 724 */     PlatformImpl.addListener(finishListener);
/*     */     
/*     */     try {
/* 727 */       AtomicReference<Preloader> atomicReference = new AtomicReference();
/* 728 */       if (paramClass1 != null)
/*     */       {
/*     */ 
/*     */         
/* 732 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 Constructor<Preloader> constructor = paramClass.getConstructor(new Class[0]);
/*     */                 
/*     */                 paramAtomicReference.set(constructor.newInstance(new Object[0]));
/*     */                 ParametersImpl.registerParameters((Application)paramAtomicReference.get(), new ParametersImpl(paramArrayOfString));
/* 738 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Preloader constructor");
/*     */                 pConstructorError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       }
/* 745 */       currentPreloader = atomicReference.get();
/*     */ 
/*     */       
/* 748 */       if (currentPreloader != null && !error && !atomicBoolean3.get()) {
/*     */         
/*     */         try {
/* 751 */           currentPreloader.init();
/* 752 */         } catch (Throwable throwable) {
/* 753 */           System.err.println("Exception in Preloader init method");
/* 754 */           pInitError = throwable;
/* 755 */           error = true;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 760 */       if (currentPreloader != null && !error && !atomicBoolean3.get()) {
/*     */         
/* 762 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramAtomicBoolean.set(true);
/*     */                 
/*     */                 Stage stage = new Stage();
/*     */                 
/*     */                 StageHelper.setPrimary(stage, true);
/*     */                 currentPreloader.start(stage);
/* 770 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Preloader start method");
/*     */                 
/*     */                 pStartError = throwable;
/*     */                 
/*     */                 error = true;
/*     */               } 
/*     */             });
/* 778 */         if (!error && !atomicBoolean3.get()) {
/* 779 */           notifyProgress(currentPreloader, 0.0D);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 786 */       AtomicReference<Application> atomicReference1 = new AtomicReference();
/* 787 */       if (!error && !atomicBoolean3.get()) {
/* 788 */         if (currentPreloader != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 795 */           notifyProgress(currentPreloader, 1.0D);
/* 796 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_LOAD, null);
/*     */         } 
/*     */ 
/*     */         
/* 800 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 Constructor<Application> constructor = paramClass.getConstructor(new Class[0]);
/*     */                 
/*     */                 paramAtomicReference.set(constructor.newInstance(new Object[0]));
/*     */                 ParametersImpl.registerParameters(paramAtomicReference.get(), new ParametersImpl(paramArrayOfString));
/*     */                 PlatformImpl.setApplicationName(paramClass);
/* 807 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application constructor");
/*     */                 constructorError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       } 
/* 814 */       Application application = atomicReference1.get();
/*     */ 
/*     */       
/* 817 */       if (!error && !atomicBoolean3.get()) {
/* 818 */         if (currentPreloader != null) {
/* 819 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_INIT, application);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 825 */           application.init();
/* 826 */         } catch (Throwable throwable) {
/* 827 */           System.err.println("Exception in Application init method");
/* 828 */           initError = throwable;
/* 829 */           error = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 834 */       if (!error && !atomicBoolean3.get()) {
/* 835 */         if (currentPreloader != null) {
/* 836 */           notifyStateChange(currentPreloader, Preloader.StateChangeNotification.Type.BEFORE_START, application);
/*     */         }
/*     */ 
/*     */         
/* 840 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramAtomicBoolean.set(true);
/*     */                 
/*     */                 Stage stage = new Stage();
/*     */                 
/*     */                 StageHelper.setPrimary(stage, true);
/*     */                 paramApplication.start(stage);
/* 848 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application start method");
/*     */                 
/*     */                 startError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       } 
/* 856 */       if (!error) {
/* 857 */         countDownLatch1.await();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 862 */       if (atomicBoolean2.get())
/*     */       {
/* 864 */         PlatformImpl.runAndWait(() -> {
/*     */               try {
/*     */                 paramApplication.stop();
/* 867 */               } catch (Throwable throwable) {
/*     */                 System.err.println("Exception in Application stop method");
/*     */                 
/*     */                 stopError = throwable;
/*     */                 error = true;
/*     */               } 
/*     */             });
/*     */       }
/* 875 */       if (error) {
/* 876 */         if (pConstructorError != null) {
/* 877 */           throw new RuntimeException("Unable to construct Preloader instance: " + paramClass, pConstructorError);
/*     */         }
/* 879 */         if (pInitError != null) {
/* 880 */           throw new RuntimeException("Exception in Preloader init method", pInitError);
/*     */         }
/* 882 */         if (pStartError != null) {
/* 883 */           throw new RuntimeException("Exception in Preloader start method", pStartError);
/*     */         }
/* 885 */         if (pStopError != null) {
/* 886 */           throw new RuntimeException("Exception in Preloader stop method", pStopError);
/*     */         }
/* 888 */         if (constructorError != null) {
/* 889 */           String str = "Unable to construct Application instance: " + paramClass;
/* 890 */           if (!notifyError(str, constructorError)) {
/* 891 */             throw new RuntimeException(str, constructorError);
/*     */           }
/* 893 */         } else if (initError != null) {
/* 894 */           String str = "Exception in Application init method";
/* 895 */           if (!notifyError(str, initError)) {
/* 896 */             throw new RuntimeException(str, initError);
/*     */           }
/* 898 */         } else if (startError != null) {
/* 899 */           String str = "Exception in Application start method";
/* 900 */           if (!notifyError(str, startError)) {
/* 901 */             throw new RuntimeException(str, startError);
/*     */           }
/* 903 */         } else if (stopError != null) {
/* 904 */           String str = "Exception in Application stop method";
/* 905 */           if (!notifyError(str, stopError)) {
/* 906 */             throw new RuntimeException(str, stopError);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 911 */       PlatformImpl.removeListener(finishListener);
/* 912 */       PlatformImpl.tkExit();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void notifyStateChange(Preloader paramPreloader, Preloader.StateChangeNotification.Type paramType, Application paramApplication) {
/* 920 */     PlatformImpl.runAndWait(() -> paramPreloader.handleStateChangeNotification(new Preloader.StateChangeNotification(paramType, paramApplication)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void notifyProgress(Preloader paramPreloader, double paramDouble) {
/* 925 */     PlatformImpl.runAndWait(() -> paramPreloader.handleProgressNotification(new Preloader.ProgressNotification(paramDouble)));
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean notifyError(String paramString, Throwable paramThrowable) {
/* 930 */     AtomicBoolean atomicBoolean = new AtomicBoolean(false);
/* 931 */     PlatformImpl.runAndWait(() -> {
/*     */           if (currentPreloader != null) {
/*     */             try {
/*     */               Preloader.ErrorNotification errorNotification = new Preloader.ErrorNotification(null, paramString, paramThrowable);
/*     */               boolean bool = currentPreloader.handleErrorNotification(errorNotification);
/*     */               paramAtomicBoolean.set(bool);
/* 937 */             } catch (Throwable throwable) {
/*     */               throwable.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 943 */     return atomicBoolean.get();
/*     */   }
/*     */   
/*     */   private static void notifyCurrentPreloader(Preloader.PreloaderNotification paramPreloaderNotification) {
/* 947 */     PlatformImpl.runAndWait(() -> {
/*     */           if (currentPreloader != null) {
/*     */             currentPreloader.handleApplicationNotification(paramPreloaderNotification);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public static void notifyPreloader(Application paramApplication, Preloader.PreloaderNotification paramPreloaderNotification) {
/* 955 */     if (launchCalled.get()) {
/*     */       
/* 957 */       notifyCurrentPreloader(paramPreloaderNotification);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private LauncherImpl() {
/* 965 */     throw new InternalError();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\application\LauncherImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */