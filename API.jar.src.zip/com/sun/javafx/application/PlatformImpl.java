/*      */ package com.sun.javafx.application;
/*      */ 
/*      */ import com.sun.glass.ui.Application;
/*      */ import com.sun.javafx.FXPermissions;
/*      */ import com.sun.javafx.PlatformUtil;
/*      */ import com.sun.javafx.css.StyleManager;
/*      */ import com.sun.javafx.tk.TKListener;
/*      */ import com.sun.javafx.tk.TKStage;
/*      */ import com.sun.javafx.tk.Toolkit;
/*      */ import com.sun.javafx.util.Logging;
/*      */ import com.sun.javafx.util.ModuleHelper;
/*      */ import com.sun.javafx.util.Utils;
/*      */ import java.lang.module.ModuleDescriptor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.CopyOnWriteArraySet;
/*      */ import java.util.concurrent.CountDownLatch;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.function.Function;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.stream.Stream;
/*      */ import javafx.application.ConditionalFeature;
/*      */ import javafx.beans.property.BooleanProperty;
/*      */ import javafx.beans.property.SimpleBooleanProperty;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.util.FXPermission;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PlatformImpl
/*      */ {
/*   65 */   private static AtomicBoolean initialized = new AtomicBoolean(false);
/*   66 */   private static AtomicBoolean platformExit = new AtomicBoolean(false);
/*   67 */   private static AtomicBoolean toolkitExit = new AtomicBoolean(false);
/*   68 */   private static CountDownLatch startupLatch = new CountDownLatch(1);
/*   69 */   private static AtomicBoolean listenersRegistered = new AtomicBoolean(false);
/*   70 */   private static TKListener toolkitListener = null;
/*      */   private static volatile boolean implicitExit = true;
/*      */   private static boolean taskbarApplication = true;
/*      */   private static boolean contextual2DNavigation;
/*   74 */   private static AtomicInteger pendingRunnables = new AtomicInteger(0);
/*   75 */   private static AtomicInteger numWindows = new AtomicInteger(0);
/*      */   private static volatile boolean firstWindowShown = false;
/*      */   private static volatile boolean lastWindowClosed = false;
/*   78 */   private static AtomicBoolean reallyIdle = new AtomicBoolean(false);
/*   79 */   private static Set<FinishListener> finishListeners = new CopyOnWriteArraySet<>();
/*      */   
/*   81 */   private static final Object runLaterLock = new Object();
/*      */   private static Boolean isGraphicsSupported;
/*      */   private static Boolean isControlsSupported;
/*      */   private static Boolean isMediaSupported;
/*      */   private static Boolean isWebSupported;
/*      */   private static Boolean isSWTSupported;
/*      */   private static Boolean isSwingSupported;
/*      */   private static Boolean isFXMLSupported;
/*      */   private static Boolean hasTwoLevelFocus;
/*      */   private static Boolean hasVirtualKeyboard;
/*      */   private static Boolean hasTouch;
/*      */   private static Boolean hasMultiTouch;
/*      */   private static Boolean hasPointer;
/*      */   private static boolean isThreadMerged = false;
/*   95 */   private static String applicationType = "";
/*   96 */   private static BooleanProperty accessibilityActive = (BooleanProperty)new SimpleBooleanProperty();
/*   97 */   private static CountDownLatch allNestedLoopsExitedLatch = new CountDownLatch(1);
/*      */ 
/*      */ 
/*      */   
/*  101 */   private static final boolean verbose = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.verbose")))).booleanValue();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   private static final boolean DEBUG = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("com.sun.javafx.application.debug")))).booleanValue();
/*      */ 
/*      */ 
/*      */   
/*  110 */   private static final FXPermission FXCANVAS_PERMISSION = new FXPermission("accessFXCanvasInternals");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setTaskbarApplication(boolean paramBoolean) {
/*  120 */     taskbarApplication = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isTaskbarApplication() {
/*  129 */     return taskbarApplication;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setApplicationName(Class paramClass) {
/*  142 */     runLater(() -> Application.GetApplication().setName(paramClass.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isContextual2DNavigation() {
/*  152 */     return contextual2DNavigation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void startup(Runnable paramRunnable) {
/*  163 */     startup(paramRunnable, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void startup(Runnable paramRunnable, boolean paramBoolean) {
/*  181 */     if (platformExit.get()) {
/*  182 */       throw new IllegalStateException("Platform.exit has been called");
/*      */     }
/*      */     
/*  185 */     if (initialized.getAndSet(true)) {
/*  186 */       if (paramBoolean) {
/*  187 */         throw new IllegalStateException("Toolkit already initialized");
/*      */       }
/*      */ 
/*      */       
/*  191 */       runLater(paramRunnable);
/*      */       
/*      */       return;
/*      */     } 
/*  195 */     Module module = PlatformImpl.class.getModule();
/*  196 */     ModuleDescriptor moduleDescriptor = module.getDescriptor();
/*  197 */     if (!module.isNamed() || 
/*  198 */       !"javafx.graphics".equals(module.getName()) || moduleDescriptor == null || moduleDescriptor
/*      */       
/*  200 */       .isAutomatic() || moduleDescriptor
/*  201 */       .isOpen()) {
/*      */       
/*  203 */       String str = "Unsupported JavaFX configuration: classes were loaded from '" + module + "'";
/*      */       
/*  205 */       if (moduleDescriptor != null) {
/*  206 */         str = str + ", isAutomatic: " + str;
/*  207 */         str = str + ", isOpen: " + str;
/*      */       } 
/*  209 */       Logging.getJavaFXLogger().warning(str);
/*      */     } 
/*      */ 
/*      */     
/*  213 */     Void void_ = AccessController.<Void>doPrivileged(() -> {
/*      */           applicationType = System.getProperty("com.sun.javafx.application.type");
/*      */           
/*      */           if (applicationType == null) {
/*      */             applicationType = "";
/*      */           }
/*      */           
/*      */           contextual2DNavigation = Boolean.getBoolean("com.sun.javafx.isContextual2DNavigation");
/*      */           String str = System.getProperty("com.sun.javafx.twoLevelFocus");
/*      */           if (str != null) {
/*      */             hasTwoLevelFocus = Boolean.valueOf(str);
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.virtualKeyboard");
/*      */           if (str != null) {
/*      */             if (str.equalsIgnoreCase("none")) {
/*      */               hasVirtualKeyboard = Boolean.valueOf(false);
/*      */             } else if (str.equalsIgnoreCase("javafx")) {
/*      */               hasVirtualKeyboard = Boolean.valueOf(true);
/*      */             } else if (str.equalsIgnoreCase("native")) {
/*      */               hasVirtualKeyboard = Boolean.valueOf(true);
/*      */             } 
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.touch");
/*      */           if (str != null) {
/*      */             hasTouch = Boolean.valueOf(str);
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.multiTouch");
/*      */           if (str != null) {
/*      */             hasMultiTouch = Boolean.valueOf(str);
/*      */           }
/*      */           str = System.getProperty("com.sun.javafx.pointer");
/*      */           if (str != null) {
/*      */             hasPointer = Boolean.valueOf(str);
/*      */           }
/*      */           str = System.getProperty("javafx.embed.singleThread");
/*      */           if (str != null) {
/*      */             isThreadMerged = Boolean.valueOf(str).booleanValue();
/*      */             if (isThreadMerged && !isSupported(ConditionalFeature.SWING)) {
/*      */               isThreadMerged = false;
/*      */               if (verbose) {
/*      */                 System.err.println("WARNING: javafx.embed.singleThread ignored (javafx.swing module not found)");
/*      */               }
/*      */             } 
/*      */           } 
/*      */           return null;
/*      */         });
/*  259 */     if (DEBUG) {
/*  260 */       System.err.println("PlatformImpl::startup : applicationType = " + applicationType);
/*      */     }
/*      */     
/*  263 */     if ("FXCanvas".equals(applicationType)) {
/*  264 */       initFXCanvas();
/*      */     }
/*      */     
/*  267 */     if (!taskbarApplication)
/*      */     {
/*  269 */       Void void_1 = AccessController.<Void>doPrivileged(() -> {
/*      */             System.setProperty("glass.taskbarApplication", "false");
/*      */ 
/*      */             
/*      */             return null;
/*      */           });
/*      */     }
/*      */     
/*  277 */     toolkitListener = new TKListener() {
/*      */         public void changedTopLevelWindows(List<TKStage> param1List) {
/*  279 */           PlatformImpl.numWindows.set(param1List.size());
/*  280 */           PlatformImpl.checkIdle();
/*      */         }
/*      */ 
/*      */         
/*      */         public void exitedLastNestedLoop() {
/*  285 */           if (PlatformImpl.platformExit.get()) {
/*  286 */             PlatformImpl.allNestedLoopsExitedLatch.countDown();
/*      */           }
/*  288 */           PlatformImpl.checkIdle();
/*      */         }
/*      */       };
/*  291 */     Toolkit.getToolkit().addTkListener(toolkitListener);
/*      */     
/*  293 */     Toolkit.getToolkit().startup(() -> {
/*      */           startupLatch.countDown();
/*      */           
/*      */           paramRunnable.run();
/*      */         });
/*      */     
/*  299 */     if (isThreadMerged) {
/*  300 */       installFwEventQueue();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initDeviceDetailsFXCanvas() {
/*  310 */     long l = ((Long)AccessController.<Long>doPrivileged(() -> Long.getLong("javafx.embed.eventProc", 0L))).longValue();
/*      */     
/*  312 */     if (l != 0L) {
/*      */ 
/*      */       
/*  315 */       Map<Object, Object> map = Application.getDeviceDetails();
/*  316 */       if (map == null) {
/*  317 */         map = new HashMap<>();
/*  318 */         Application.setDeviceDetails(map);
/*      */       } 
/*  320 */       if (map.get("javafx.embed.eventProc") == null) {
/*  321 */         map.put("javafx.embed.eventProc", Long.valueOf(l));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static void addExportsToFXCanvas(Class<?> paramClass) {
/*  328 */     String[] arrayOfString = { "com.sun.glass.ui", "com.sun.javafx.cursor", "com.sun.javafx.embed", "com.sun.javafx.stage", "com.sun.javafx.tk" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  336 */     if (DEBUG) {
/*  337 */       System.err.println("addExportsToFXCanvas: class = " + paramClass);
/*      */     }
/*  339 */     Object object1 = ModuleHelper.getModule(PlatformImpl.class);
/*  340 */     Object object2 = ModuleHelper.getModule(paramClass);
/*  341 */     for (String str : arrayOfString) {
/*  342 */       if (DEBUG) {
/*  343 */         System.err.println("add export of " + str + " from " + object1 + " to " + object2);
/*      */       }
/*      */       
/*  346 */       ModuleHelper.addExports(object1, str, object2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initFXCanvas() {
/*  354 */     SecurityManager securityManager = System.getSecurityManager();
/*  355 */     if (securityManager != null) {
/*      */       try {
/*  357 */         securityManager.checkPermission((Permission)FXCANVAS_PERMISSION);
/*  358 */       } catch (SecurityException securityException) {
/*  359 */         System.err.println("FXCanvas: no permission to access JavaFX internals");
/*  360 */         securityException.printStackTrace();
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/*      */     
/*  366 */     Predicate predicate = paramStackFrame -> 
/*  367 */       (!paramStackFrame.getClassName().startsWith("javafx.application.") && !paramStackFrame.getClassName().startsWith("com.sun.javafx.application."));
/*      */ 
/*      */ 
/*      */     
/*  371 */     StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*      */     
/*  373 */     Optional<StackWalker.StackFrame> optional = stackWalker.<Optional>walk(paramStream -> paramStream.filter(paramPredicate).findFirst());
/*      */ 
/*      */     
/*  376 */     if (optional.isPresent()) {
/*  377 */       Class<?> clazz = ((StackWalker.StackFrame)optional.get()).getDeclaringClass();
/*  378 */       if (DEBUG) {
/*  379 */         System.err.println("callerClassName = " + clazz);
/*      */       }
/*      */ 
/*      */       
/*  383 */       if ("javafx.embed.swt.FXCanvas".equals(clazz.getName())) {
/*  384 */         initDeviceDetailsFXCanvas();
/*  385 */         addExportsToFXCanvas(clazz);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void installFwEventQueue() {
/*  391 */     invokeSwingFXUtilsMethod("installFwEventQueue");
/*      */   }
/*      */   
/*      */   private static void removeFwEventQueue() {
/*  395 */     invokeSwingFXUtilsMethod("removeFwEventQueue");
/*      */   }
/*      */ 
/*      */   
/*      */   private static void invokeSwingFXUtilsMethod(String paramString) {
/*      */     try {
/*  401 */       Class<?> clazz = Class.forName("com.sun.javafx.embed.swing.SwingFXUtilsImpl");
/*  402 */       Method method = clazz.getDeclaredMethod(paramString, new Class[0]);
/*      */       
/*  404 */       waitForStart();
/*  405 */       method.invoke(null, new Object[0]);
/*      */     }
/*  407 */     catch (ClassNotFoundException|NoSuchMethodException|IllegalAccessException classNotFoundException) {
/*  408 */       throw new RuntimeException("Property javafx.embed.singleThread is not supported");
/*  409 */     } catch (InvocationTargetException invocationTargetException) {
/*  410 */       throw new RuntimeException(invocationTargetException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void waitForStart() {
/*  418 */     if (startupLatch.getCount() > 0L) {
/*      */       try {
/*  420 */         startupLatch.await();
/*  421 */       } catch (InterruptedException interruptedException) {
/*  422 */         interruptedException.printStackTrace();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean isFxApplicationThread() {
/*  428 */     return Toolkit.getToolkit().isFxUserThread();
/*      */   }
/*      */   
/*      */   public static void runLater(Runnable paramRunnable) {
/*  432 */     runLater(paramRunnable, false);
/*      */   }
/*      */   
/*      */   private static void runLater(Runnable paramRunnable, boolean paramBoolean) {
/*  436 */     if (!initialized.get()) {
/*  437 */       throw new IllegalStateException("Toolkit not initialized");
/*      */     }
/*      */     
/*  440 */     pendingRunnables.incrementAndGet();
/*  441 */     waitForStart();
/*      */     
/*  443 */     synchronized (runLaterLock) {
/*  444 */       if (!paramBoolean && toolkitExit.get()) {
/*      */         
/*  446 */         pendingRunnables.decrementAndGet();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  451 */       AccessControlContext accessControlContext = AccessController.getContext();
/*      */       
/*  453 */       Toolkit.getToolkit().defer(() -> {
/*      */             try {
/*      */               Void void_ = AccessController.<Void>doPrivileged((), paramAccessControlContext);
/*      */             } finally {
/*      */               pendingRunnables.decrementAndGet();
/*      */               checkIdle();
/*      */             } 
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void runAndWait(Runnable paramRunnable) {
/*  469 */     runAndWait(paramRunnable, false);
/*      */   }
/*      */   
/*      */   private static void runAndWait(Runnable paramRunnable, boolean paramBoolean) {
/*  473 */     if (isFxApplicationThread()) {
/*      */       try {
/*  475 */         paramRunnable.run();
/*  476 */       } catch (Throwable throwable) {
/*  477 */         System.err.println("Exception in runnable");
/*  478 */         throwable.printStackTrace();
/*      */       } 
/*      */     } else {
/*  481 */       CountDownLatch countDownLatch = new CountDownLatch(1);
/*  482 */       runLater(() -> { try { paramRunnable.run(); } finally { paramCountDownLatch.countDown(); }  }paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  490 */       if (!paramBoolean && toolkitExit.get()) {
/*  491 */         throw new IllegalStateException("Toolkit has exited");
/*      */       }
/*      */       
/*      */       try {
/*  495 */         countDownLatch.await();
/*  496 */       } catch (InterruptedException interruptedException) {
/*  497 */         interruptedException.printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setImplicitExit(boolean paramBoolean) {
/*  503 */     implicitExit = paramBoolean;
/*  504 */     checkIdle();
/*      */   }
/*      */   
/*      */   public static boolean isImplicitExit() {
/*  508 */     return implicitExit;
/*      */   }
/*      */   
/*      */   public static void addListener(FinishListener paramFinishListener) {
/*  512 */     listenersRegistered.set(true);
/*  513 */     finishListeners.add(paramFinishListener);
/*      */   }
/*      */   
/*      */   public static void removeListener(FinishListener paramFinishListener) {
/*  517 */     finishListeners.remove(paramFinishListener);
/*  518 */     listenersRegistered.set(!finishListeners.isEmpty());
/*  519 */     if (!listenersRegistered.get()) {
/*  520 */       checkIdle();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static void notifyFinishListeners(boolean paramBoolean) {
/*  526 */     if (listenersRegistered.get()) {
/*  527 */       for (FinishListener finishListener : finishListeners) {
/*  528 */         if (paramBoolean) {
/*  529 */           finishListener.exitCalled(); continue;
/*      */         } 
/*  531 */         finishListener.idle(implicitExit);
/*      */       }
/*      */     
/*  534 */     } else if (implicitExit || platformExit.get()) {
/*  535 */       tkExit();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void checkIdle() {
/*  543 */     if (!initialized.get()) {
/*      */       return;
/*      */     }
/*      */     
/*  547 */     if (!isFxApplicationThread()) {
/*      */ 
/*      */       
/*  550 */       runLater(() -> {
/*      */           
/*      */           });
/*      */       return;
/*      */     } 
/*  555 */     boolean bool = false;
/*      */     
/*  557 */     synchronized (PlatformImpl.class) {
/*  558 */       int i = numWindows.get();
/*  559 */       if (i > 0) {
/*  560 */         firstWindowShown = true;
/*  561 */         lastWindowClosed = false;
/*  562 */         reallyIdle.set(false);
/*  563 */       } else if (i == 0 && firstWindowShown) {
/*  564 */         lastWindowClosed = true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  571 */       if (lastWindowClosed && pendingRunnables.get() == 0 && (toolkitExit
/*  572 */         .get() || !Toolkit.getToolkit().isNestedLoopRunning()))
/*      */       {
/*  574 */         if (reallyIdle.getAndSet(true)) {
/*      */           
/*  576 */           bool = true;
/*  577 */           lastWindowClosed = false;
/*      */         } else {
/*      */           
/*  580 */           runLater(() -> {
/*      */               
/*      */               });
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  587 */     if (bool) {
/*  588 */       notifyFinishListeners(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  593 */   private static final CountDownLatch platformExitLatch = new CountDownLatch(1);
/*      */   static CountDownLatch test_getPlatformExitLatch() {
/*  595 */     return platformExitLatch;
/*      */   }
/*      */   
/*      */   public static void tkExit() {
/*  599 */     if (toolkitExit.getAndSet(true)) {
/*      */       return;
/*      */     }
/*      */     
/*  603 */     if (initialized.get()) {
/*  604 */       if (platformExit.get()) {
/*  605 */         runAndWait(() -> { if (Toolkit.getToolkit().isNestedLoopRunning()) { Toolkit.getToolkit().exitAllNestedEventLoops(); } else { allNestedLoopsExitedLatch.countDown(); }  }true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  614 */           allNestedLoopsExitedLatch.await();
/*  615 */         } catch (InterruptedException interruptedException) {
/*  616 */           throw new RuntimeException("Could not exit all nested event loops");
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  622 */       runAndWait(() -> Toolkit.getToolkit().exit(), true);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  627 */       if (isThreadMerged) {
/*  628 */         removeFwEventQueue();
/*      */       }
/*      */       
/*  631 */       Toolkit.getToolkit().removeTkListener(toolkitListener);
/*  632 */       toolkitListener = null;
/*  633 */       platformExitLatch.countDown();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static BooleanProperty accessibilityActiveProperty() {
/*  638 */     return accessibilityActive;
/*      */   }
/*      */   
/*      */   public static void exit() {
/*  642 */     platformExit.set(true);
/*  643 */     notifyFinishListeners(true);
/*      */   }
/*      */   
/*      */   private static Boolean checkForClass(String paramString) {
/*      */     try {
/*  648 */       Class.forName(paramString, false, PlatformImpl.class.getClassLoader());
/*  649 */       return Boolean.TRUE;
/*  650 */     } catch (ClassNotFoundException classNotFoundException) {
/*  651 */       return Boolean.FALSE;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isSupported(ConditionalFeature paramConditionalFeature) {
/*  656 */     boolean bool = isSupportedImpl(paramConditionalFeature);
/*  657 */     if (bool && paramConditionalFeature == ConditionalFeature.TRANSPARENT_WINDOW) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  663 */       SecurityManager securityManager = System.getSecurityManager();
/*  664 */       if (securityManager != null) {
/*      */         try {
/*  666 */           securityManager.checkPermission((Permission)FXPermissions.CREATE_TRANSPARENT_WINDOW_PERMISSION);
/*  667 */         } catch (SecurityException securityException) {
/*  668 */           return false;
/*      */         } 
/*      */       }
/*      */       
/*  672 */       return true;
/*      */     } 
/*      */     
/*  675 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultPlatformUserAgentStylesheet() {
/*  687 */     setPlatformUserAgentStylesheet("MODENA");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isModena = false;
/*      */ 
/*      */   
/*      */   private static boolean isCaspian = false;
/*      */ 
/*      */   
/*      */   private static String accessibilityTheme;
/*      */ 
/*      */   
/*      */   public static boolean isModena() {
/*  702 */     return isModena;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCaspian() {
/*  714 */     return isCaspian;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setPlatformUserAgentStylesheet(String paramString) {
/*  722 */     if (isFxApplicationThread()) {
/*  723 */       _setPlatformUserAgentStylesheet(paramString);
/*      */     } else {
/*  725 */       runLater(() -> _setPlatformUserAgentStylesheet(paramString));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum HighContrastScheme
/*      */   {
/*  739 */     HIGH_CONTRAST_BLACK("high.contrast.black.theme"),
/*  740 */     HIGH_CONTRAST_WHITE("high.contrast.white.theme"),
/*  741 */     HIGH_CONTRAST_1("high.contrast.1.theme"),
/*  742 */     HIGH_CONTRAST_2("high.contrast.2.theme");
/*      */     private final String themeKey;
/*      */     
/*      */     HighContrastScheme(String param1String1) {
/*  746 */       this.themeKey = param1String1;
/*      */     }
/*      */     
/*      */     public String getThemeKey() {
/*  750 */       return this.themeKey;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static String fromThemeName(Function<String, String> param1Function, String param1String) {
/*  766 */       if (param1Function == null || param1String == null) {
/*  767 */         return null;
/*      */       }
/*  769 */       for (HighContrastScheme highContrastScheme : values()) {
/*  770 */         if (param1String.equalsIgnoreCase(param1Function.apply(highContrastScheme.getThemeKey()))) {
/*  771 */           return highContrastScheme.toString();
/*      */         }
/*      */       } 
/*  774 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean setAccessibilityTheme(String paramString) {
/*  781 */     if (accessibilityTheme != null) {
/*  782 */       StyleManager.getInstance().removeUserAgentStylesheet(accessibilityTheme);
/*  783 */       accessibilityTheme = null;
/*      */     } 
/*      */     
/*  786 */     _setAccessibilityTheme(paramString);
/*      */     
/*  788 */     if (accessibilityTheme != null) {
/*  789 */       StyleManager.getInstance().addUserAgentStylesheet(accessibilityTheme);
/*  790 */       return true;
/*      */     } 
/*  792 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void _setAccessibilityTheme(String paramString) {
/*  800 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("com.sun.javafx.highContrastTheme"));
/*      */ 
/*      */     
/*  803 */     if (isCaspian()) {
/*  804 */       if (paramString != null || str != null)
/*      */       {
/*  806 */         accessibilityTheme = "com/sun/javafx/scene/control/skin/caspian/highcontrast.css";
/*      */       }
/*  808 */     } else if (isModena()) {
/*      */       
/*  810 */       if (str != null) {
/*  811 */         switch (str.toUpperCase()) {
/*      */           case "BLACKONWHITE":
/*  813 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/blackOnWhite.css";
/*      */             break;
/*      */           case "WHITEONBLACK":
/*  816 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/whiteOnBlack.css";
/*      */             break;
/*      */           case "YELLOWONBLACK":
/*  819 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/yellowOnBlack.css";
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*  824 */       } else if (paramString != null) {
/*      */         
/*  826 */         switch (HighContrastScheme.valueOf(paramString)) {
/*      */           case GRAPHICS:
/*  828 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/blackOnWhite.css";
/*      */             break;
/*      */           case CONTROLS:
/*  831 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/whiteOnBlack.css";
/*      */             break;
/*      */           case MEDIA:
/*      */           case WEB:
/*  835 */             accessibilityTheme = "com/sun/javafx/scene/control/skin/modena/yellowOnBlack.css";
/*      */             break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void _setPlatformUserAgentStylesheet(String paramString) {
/*  845 */     isModena = isCaspian = false;
/*      */ 
/*      */     
/*  848 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.userAgentStylesheetUrl"));
/*      */ 
/*      */     
/*  851 */     if (str != null) {
/*  852 */       paramString = str;
/*      */     }
/*      */     
/*  855 */     ArrayList<String> arrayList = new ArrayList();
/*      */ 
/*      */     
/*  858 */     if ("CASPIAN".equalsIgnoreCase(paramString)) {
/*  859 */       isCaspian = true;
/*      */       
/*  861 */       arrayList.add("com/sun/javafx/scene/control/skin/caspian/caspian.css");
/*      */       
/*  863 */       if (isSupported(ConditionalFeature.INPUT_TOUCH)) {
/*  864 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/embedded.css");
/*  865 */         if (Utils.isQVGAScreen()) {
/*  866 */           arrayList.add("com/sun/javafx/scene/control/skin/caspian/embedded-qvga.css");
/*      */         }
/*  868 */         if (PlatformUtil.isAndroid()) {
/*  869 */           arrayList.add("com/sun/javafx/scene/control/skin/caspian/android.css");
/*      */         }
/*  871 */         if (PlatformUtil.isIOS()) {
/*  872 */           arrayList.add("com/sun/javafx/scene/control/skin/caspian/ios.css");
/*      */         }
/*      */       } 
/*      */       
/*  876 */       if (isSupported(ConditionalFeature.TWO_LEVEL_FOCUS)) {
/*  877 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/two-level-focus.css");
/*      */       }
/*      */       
/*  880 */       if (isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)) {
/*  881 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/fxvk.css");
/*      */       }
/*      */       
/*  884 */       if (!isSupported(ConditionalFeature.TRANSPARENT_WINDOW)) {
/*  885 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/caspian-no-transparency.css");
/*      */       }
/*      */     }
/*  888 */     else if ("MODENA".equalsIgnoreCase(paramString)) {
/*  889 */       isModena = true;
/*      */       
/*  891 */       arrayList.add("com/sun/javafx/scene/control/skin/modena/modena.css");
/*      */       
/*  893 */       if (isSupported(ConditionalFeature.INPUT_TOUCH)) {
/*  894 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/touch.css");
/*      */       }
/*      */       
/*  897 */       if (PlatformUtil.isEmbedded()) {
/*  898 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/modena-embedded-performance.css");
/*      */       }
/*  900 */       if (PlatformUtil.isAndroid()) {
/*  901 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/android.css");
/*      */       }
/*  903 */       if (PlatformUtil.isIOS()) {
/*  904 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/ios.css");
/*      */       }
/*      */       
/*  907 */       if (isSupported(ConditionalFeature.TWO_LEVEL_FOCUS)) {
/*  908 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/two-level-focus.css");
/*      */       }
/*      */       
/*  911 */       if (isSupported(ConditionalFeature.VIRTUAL_KEYBOARD)) {
/*  912 */         arrayList.add("com/sun/javafx/scene/control/skin/caspian/fxvk.css");
/*      */       }
/*      */       
/*  915 */       if (!isSupported(ConditionalFeature.TRANSPARENT_WINDOW)) {
/*  916 */         arrayList.add("com/sun/javafx/scene/control/skin/modena/modena-no-transparency.css");
/*      */       }
/*      */     } else {
/*      */       
/*  920 */       arrayList.add(paramString);
/*      */     } 
/*      */ 
/*      */     
/*  924 */     _setAccessibilityTheme(Toolkit.getToolkit().getThemeName());
/*  925 */     if (accessibilityTheme != null) {
/*  926 */       arrayList.add(accessibilityTheme);
/*      */     }
/*      */ 
/*      */     
/*  930 */     Object object = AccessController.doPrivileged(() -> {
/*      */           StyleManager.getInstance().setUserAgentStylesheets(paramList);
/*      */           return null;
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addNoTransparencyStylesheetToScene(Scene paramScene) {
/*  939 */     if (isCaspian()) {
/*  940 */       AccessController.doPrivileged(() -> {
/*      */             StyleManager.getInstance().addUserAgentStylesheet(paramScene, "com/sun/javafx/scene/control/skin/caspian/caspian-no-transparency.css");
/*      */             
/*      */             return null;
/*      */           });
/*  945 */     } else if (isModena()) {
/*  946 */       AccessController.doPrivileged(() -> {
/*      */             StyleManager.getInstance().addUserAgentStylesheet(paramScene, "com/sun/javafx/scene/control/skin/modena/modena-no-transparency.css");
/*      */             return null;
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isSupportedImpl(ConditionalFeature paramConditionalFeature) {
/*  955 */     switch (paramConditionalFeature) {
/*      */       case GRAPHICS:
/*  957 */         if (isGraphicsSupported == null) {
/*  958 */           isGraphicsSupported = checkForClass("javafx.stage.Stage");
/*      */         }
/*  960 */         return isGraphicsSupported.booleanValue();
/*      */       case CONTROLS:
/*  962 */         if (isControlsSupported == null) {
/*  963 */           isControlsSupported = checkForClass("javafx.scene.control.Control");
/*      */         }
/*      */         
/*  966 */         return isControlsSupported.booleanValue();
/*      */       case MEDIA:
/*  968 */         if (isMediaSupported == null) {
/*  969 */           isMediaSupported = checkForClass("javafx.scene.media.MediaView");
/*      */           
/*  971 */           if (isMediaSupported.booleanValue() && PlatformUtil.isEmbedded())
/*      */           {
/*  973 */             Void void_ = AccessController.<Void>doPrivileged(() -> {
/*      */                   String str = System.getProperty("com.sun.javafx.experimental.embedded.media", "false");
/*      */                   
/*      */                   isMediaSupported = Boolean.valueOf(str);
/*      */                   
/*      */                   return null;
/*      */                 });
/*      */           }
/*      */         } 
/*      */         
/*  983 */         return isMediaSupported.booleanValue();
/*      */       case WEB:
/*  985 */         if (isWebSupported == null) {
/*  986 */           isWebSupported = checkForClass("javafx.scene.web.WebView");
/*  987 */           if (isWebSupported.booleanValue() && PlatformUtil.isEmbedded())
/*      */           {
/*  989 */             Void void_ = AccessController.<Void>doPrivileged(() -> {
/*      */                   String str = System.getProperty("com.sun.javafx.experimental.embedded.web", "false");
/*      */                   
/*      */                   isWebSupported = Boolean.valueOf(str);
/*      */                   
/*      */                   return null;
/*      */                 });
/*      */           }
/*      */         } 
/*      */         
/*  999 */         return isWebSupported.booleanValue();
/*      */       case SWT:
/* 1001 */         if (isSWTSupported == null) {
/* 1002 */           isSWTSupported = checkForClass("javafx.embed.swt.FXCanvas");
/*      */         }
/* 1004 */         return isSWTSupported.booleanValue();
/*      */       case SWING:
/* 1006 */         if (isSwingSupported == null)
/*      */         {
/*      */           
/* 1009 */           isSwingSupported = Boolean.valueOf((checkForClass("javax.swing.JComponent").booleanValue() && 
/* 1010 */               checkForClass("javafx.embed.swing.JFXPanel").booleanValue()));
/*      */         }
/* 1012 */         return isSwingSupported.booleanValue();
/*      */       case FXML:
/* 1014 */         if (isFXMLSupported == null) {
/* 1015 */           isFXMLSupported = Boolean.valueOf((checkForClass("javafx.fxml.FXMLLoader").booleanValue() && 
/* 1016 */               checkForClass("javax.xml.stream.XMLInputFactory").booleanValue()));
/*      */         }
/* 1018 */         return isFXMLSupported.booleanValue();
/*      */       case TWO_LEVEL_FOCUS:
/* 1020 */         if (hasTwoLevelFocus == null) {
/* 1021 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */         }
/* 1023 */         return hasTwoLevelFocus.booleanValue();
/*      */       case VIRTUAL_KEYBOARD:
/* 1025 */         if (hasVirtualKeyboard == null) {
/* 1026 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */         }
/* 1028 */         return hasVirtualKeyboard.booleanValue();
/*      */       case INPUT_TOUCH:
/* 1030 */         if (hasTouch == null) {
/* 1031 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */         }
/* 1033 */         return hasTouch.booleanValue();
/*      */       case INPUT_MULTITOUCH:
/* 1035 */         if (hasMultiTouch == null) {
/* 1036 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */         }
/* 1038 */         return hasMultiTouch.booleanValue();
/*      */       case INPUT_POINTER:
/* 1040 */         if (hasPointer == null) {
/* 1041 */           return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */         }
/* 1043 */         return hasPointer.booleanValue();
/*      */     } 
/* 1045 */     return Toolkit.getToolkit().isSupported(paramConditionalFeature);
/*      */   }
/*      */   
/*      */   public static interface FinishListener {
/*      */     void idle(boolean param1Boolean);
/*      */     
/*      */     void exitCalled();
/*      */   }
/*      */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\application\PlatformImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */