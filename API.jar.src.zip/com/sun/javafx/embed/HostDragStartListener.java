package com.sun.javafx.embed;

import javafx.scene.input.TransferMode;

public interface HostDragStartListener {
  void dragStarted(EmbeddedSceneDSInterface paramEmbeddedSceneDSInterface, TransferMode paramTransferMode);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\HostDragStartListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */