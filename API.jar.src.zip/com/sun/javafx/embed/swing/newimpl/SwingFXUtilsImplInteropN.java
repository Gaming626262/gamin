/*    */ package com.sun.javafx.embed.swing.newimpl;
/*    */ 
/*    */ import com.sun.javafx.application.PlatformImpl;
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import java.awt.EventQueue;
/*    */ import java.awt.SecondaryLoop;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import javafx.application.Platform;
/*    */ import jdk.swing.interop.DispatcherWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SwingFXUtilsImplInteropN
/*    */ {
/*    */   private static class FwSecondaryLoop
/*    */     implements SecondaryLoop
/*    */   {
/* 40 */     private final AtomicBoolean isRunning = new AtomicBoolean(false);
/*    */ 
/*    */     
/*    */     public boolean enter() {
/* 44 */       if (this.isRunning.compareAndSet(false, true)) {
/* 45 */         PlatformImpl.runAndWait(() -> Toolkit.getToolkit().enterNestedEventLoop(this));
/*    */ 
/*    */         
/* 48 */         return true;
/*    */       } 
/* 50 */       return false;
/*    */     }
/*    */ 
/*    */     
/*    */     public boolean exit() {
/* 55 */       if (this.isRunning.compareAndSet(true, false)) {
/* 56 */         PlatformImpl.runAndWait(() -> Toolkit.getToolkit().exitNestedEventLoop(this, null));
/*    */ 
/*    */         
/* 59 */         return true;
/*    */       } 
/* 61 */       return false;
/*    */     }
/*    */   }
/*    */   
/*    */   private static class FXDispatcher
/*    */     extends DispatcherWrapper
/*    */   {
/*    */     public boolean isDispatchThread() {
/* 69 */       return Platform.isFxApplicationThread();
/*    */     }
/*    */ 
/*    */     
/*    */     public void scheduleDispatch(Runnable param1Runnable) {
/* 74 */       Platform.runLater(param1Runnable);
/*    */     }
/*    */ 
/*    */     
/*    */     public SecondaryLoop createSecondaryLoop() {
/* 79 */       return new SwingFXUtilsImplInteropN.FwSecondaryLoop();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setFwDispatcher(EventQueue paramEventQueue) {
/* 84 */     DispatcherWrapper.setFwDispatcher(paramEventQueue, new FXDispatcher());
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\newimpl\SwingFXUtilsImplInteropN.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */