/*     */ package com.sun.javafx.embed.swing.newimpl;
/*     */ 
/*     */ import com.sun.javafx.embed.swing.CachingTransferable;
/*     */ import com.sun.javafx.embed.swing.FXDnD;
/*     */ import com.sun.javafx.embed.swing.SwingDnD;
/*     */ import com.sun.javafx.embed.swing.SwingEvents;
/*     */ import com.sun.javafx.embed.swing.SwingNodeHelper;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Point;
/*     */ import java.awt.SecondaryLoop;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.dnd.DragGestureEvent;
/*     */ import java.awt.dnd.DragGestureListener;
/*     */ import java.awt.dnd.DragSource;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.DropTargetContext;
/*     */ import java.awt.dnd.DropTargetDragEvent;
/*     */ import java.awt.dnd.DropTargetDropEvent;
/*     */ import java.awt.dnd.InvalidDnDOperationException;
/*     */ import java.awt.dnd.MouseDragGestureRecognizer;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javafx.application.Platform;
/*     */ import javafx.embed.swing.SwingNode;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.Clipboard;
/*     */ import javafx.scene.input.DataFormat;
/*     */ import javafx.scene.input.DragEvent;
/*     */ import javafx.scene.input.Dragboard;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.input.TransferMode;
/*     */ import jdk.swing.interop.DragSourceContextWrapper;
/*     */ import jdk.swing.interop.DropTargetContextWrapper;
/*     */ import jdk.swing.interop.LightweightFrameWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FXDnDInteropN
/*     */ {
/*     */   private WeakReference<SwingNode> nodeRef;
/*     */   private boolean isDragSourceListenerInstalled;
/*     */   private MouseEvent pressEvent;
/*     */   private long pressTime;
/*     */   private volatile SecondaryLoop loop;
/*     */   private final Map<Component, FXDragGestureRecognizer> recognizers;
/*     */   private final EventHandler<MouseEvent> onMousePressHandler;
/*     */   private volatile FXDragSourceContextPeer activeDSContextPeer;
/*     */   private final EventHandler<MouseEvent> onDragStartHandler;
/*     */   private final EventHandler<DragEvent> onDragDoneHandler;
/*     */   private boolean isDropTargetListenerInstalled;
/*     */   private volatile FXDropTargetContextPeer activeDTContextPeer;
/*     */   private final Map<Component, DropTarget> dropTargets;
/*     */   private final EventHandler<DragEvent> onDragEnteredHandler;
/*     */   
/*     */   public FXDnDInteropN() {
/* 114 */     this.nodeRef = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     this.isDragSourceListenerInstalled = false;
/*     */ 
/*     */     
/* 168 */     this.pressEvent = null;
/* 169 */     this.pressTime = 0L;
/*     */ 
/*     */ 
/*     */     
/* 173 */     this.recognizers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     this.onMousePressHandler = (paramMouseEvent -> {
/*     */         this.pressEvent = paramMouseEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         this.pressTime = System.currentTimeMillis();
/*     */       });
/*     */ 
/*     */ 
/*     */     
/* 267 */     this.onDragStartHandler = (paramMouseEvent -> {
/*     */         this.activeDSContextPeer = null;
/*     */         
/*     */         MouseEvent mouseEvent = getInitialGestureEvent();
/*     */         
/*     */         SwingNodeHelper.runOnEDTAndWait(this, ());
/*     */         
/*     */         if (this.activeDSContextPeer == null) {
/*     */           return;
/*     */         }
/*     */         
/*     */         paramMouseEvent.consume();
/*     */         
/*     */         SwingNode swingNode = getNode();
/*     */         
/*     */         if (swingNode != null) {
/*     */           Dragboard dragboard = swingNode.startDragAndDrop((TransferMode[])SwingDnD.dropActionsToTransferModes(this.activeDSContextPeer.sourceActions).toArray((Object[])new TransferMode[1]));
/*     */           
/*     */           HashMap<Object, Object> hashMap = new HashMap<>();
/*     */           
/*     */           for (String str : this.activeDSContextPeer.transferable.getMimeTypes()) {
/*     */             DataFormat dataFormat = DataFormat.lookupMimeType(str);
/*     */             
/*     */             if (dataFormat != null) {
/*     */               hashMap.put(dataFormat, this.activeDSContextPeer.transferable.getData(str));
/*     */             }
/*     */           } 
/*     */           boolean bool = dragboard.setContent(hashMap);
/*     */           if (!bool) {
/*     */             if (!FXDnD.fxAppThreadIsDispatchThread) {
/*     */               this.loop.exit();
/*     */             }
/*     */           }
/*     */         } 
/*     */       });
/* 302 */     this.onDragDoneHandler = (paramDragEvent -> {
/*     */         paramDragEvent.consume();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (!FXDnD.fxAppThreadIsDispatchThread) {
/*     */           this.loop.exit();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (this.activeDSContextPeer != null) {
/*     */           TransferMode transferMode = paramDragEvent.getTransferMode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           this.activeDSContextPeer.dragDone((transferMode == null) ? 0 : SwingDnD.transferModeToDropAction(transferMode), (int)paramDragEvent.getX(), (int)paramDragEvent.getY());
/*     */         } 
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     this.isDropTargetListenerInstalled = false;
/* 381 */     this.activeDTContextPeer = null;
/* 382 */     this.dropTargets = new HashMap<>();
/*     */     
/* 384 */     this.onDragEnteredHandler = (paramDragEvent -> {
/*     */         if (this.activeDTContextPeer == null) {
/*     */           this.activeDTContextPeer = new FXDropTargetContextPeer();
/*     */         }
/*     */         int i = this.activeDTContextPeer.postDropTargetEvent(paramDragEvent);
/*     */         if (i != 0) {
/*     */           paramDragEvent.consume();
/*     */         }
/*     */       });
/* 393 */     this.onDragExitedHandler = (paramDragEvent -> {
/*     */         if (this.activeDTContextPeer == null) {
/*     */           this.activeDTContextPeer = new FXDropTargetContextPeer();
/*     */         }
/*     */         
/*     */         this.activeDTContextPeer.postDropTargetEvent(paramDragEvent);
/*     */         this.activeDTContextPeer = null;
/*     */       });
/* 401 */     this.onDragOverHandler = (paramDragEvent -> {
/*     */         if (this.activeDTContextPeer == null) {
/*     */           this.activeDTContextPeer = new FXDropTargetContextPeer();
/*     */         }
/*     */ 
/*     */         
/*     */         int i = this.activeDTContextPeer.postDropTargetEvent(paramDragEvent);
/*     */ 
/*     */         
/*     */         if (i != 0) {
/*     */           paramDragEvent.acceptTransferModes((TransferMode[])SwingDnD.dropActionsToTransferModes(i).toArray((Object[])new TransferMode[1]));
/*     */           
/*     */           paramDragEvent.consume();
/*     */         } 
/*     */       });
/*     */     
/* 417 */     this.onDragDroppedHandler = (paramDragEvent -> { if (this.activeDTContextPeer == null) this.activeDTContextPeer = new FXDropTargetContextPeer();  int i = this.activeDTContextPeer.postDropTargetEvent(paramDragEvent); if (i != 0) { paramDragEvent.setDropCompleted(this.activeDTContextPeer.success); paramDragEvent.consume(); }  this.activeDTContextPeer = null; });
/*     */   }
/*     */   private final EventHandler<DragEvent> onDragExitedHandler;
/*     */   private final EventHandler<DragEvent> onDragOverHandler;
/*     */   private final EventHandler<DragEvent> onDragDroppedHandler;
/*     */   public Component findComponentAt(Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.findComponentAt(lightweightFrameWrapper, paramInt1, paramInt2, false); }
/*     */   public boolean isCompEqual(Component paramComponent, Object paramObject) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.isCompEqual(paramComponent, lightweightFrameWrapper); }
/*     */   public int convertModifiersToDropAction(int paramInt1, int paramInt2) { return DragSourceContextWrapper.convertModifiersToDropAction(paramInt1, paramInt2); }
/*     */   public Object createDragSourceContext(DragGestureEvent paramDragGestureEvent) throws InvalidDnDOperationException { return new FXDragSourceContextPeer(paramDragGestureEvent); }
/*     */   public <T extends java.awt.dnd.DragGestureRecognizer> T createDragGestureRecognizer(DragSource paramDragSource, Component paramComponent, int paramInt, DragGestureListener paramDragGestureListener) { return (T)new FXDragGestureRecognizer(paramDragSource, paramComponent, paramInt, paramDragGestureListener); }
/*     */   private void runOnFxThread(Runnable paramRunnable) { if (Platform.isFxApplicationThread()) { paramRunnable.run(); } else { Platform.runLater(paramRunnable); }  }
/*     */   public SwingNode getNode() { return this.nodeRef.get(); }
/*     */   public void setNode(SwingNode paramSwingNode) { this.nodeRef = new WeakReference<>(paramSwingNode); }
/*     */   private class ComponentMapper<T> {
/*     */     public int x;
/*     */     public int y;
/*     */     public T object = null;
/*     */     private ComponentMapper(Map<Component, T> param1Map, int param1Int1, int param1Int2) { this.x = param1Int1; this.y = param1Int2; SwingNode swingNode = FXDnDInteropN.this.getNode(); if (swingNode != null) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)SwingNodeHelper.getLightweightFrame(swingNode); Component component = lightweightFrameWrapper.findComponentAt(lightweightFrameWrapper, this.x, this.y, false); if (component == null) return;  synchronized (component.getTreeLock()) { do { this.object = param1Map.get(component); } while (this.object == null && (component = component.getParent()) != null); if (this.object != null) while (lightweightFrameWrapper.isCompEqual(component, lightweightFrameWrapper) && component != null) { this.x -= component.getX(); this.y -= component.getY(); component = component.getParent(); }   }  }  } }
/*     */   public <T> ComponentMapper<T> mapComponent(Map<Component, T> paramMap, int paramInt1, int paramInt2) { return new ComponentMapper<>(paramMap, paramInt1, paramInt2); }
/*     */   private class FXDragGestureRecognizer extends MouseDragGestureRecognizer {
/*     */     FXDragGestureRecognizer(DragSource param1DragSource, Component param1Component, int param1Int, DragGestureListener param1DragGestureListener) { super(param1DragSource, param1Component, param1Int, param1DragGestureListener); if (param1Component != null) FXDnDInteropN.this.recognizers.put(param1Component, this);  }
/*     */     public void setComponent(Component param1Component) { Component component = getComponent(); if (component != null) FXDnDInteropN.this.recognizers.remove(component);  super.setComponent(param1Component); if (param1Component != null) FXDnDInteropN.this.recognizers.put(param1Component, this);  } protected void registerListeners() { FXDnDInteropN.this.runOnFxThread(() -> { if (!FXDnDInteropN.this.isDragSourceListenerInstalled) { SwingNode swingNode = FXDnDInteropN.this.getNode(); if (swingNode != null) { swingNode.addEventHandler(MouseEvent.MOUSE_PRESSED, FXDnDInteropN.this.onMousePressHandler); swingNode.addEventHandler(MouseEvent.DRAG_DETECTED, FXDnDInteropN.this.onDragStartHandler); swingNode.addEventHandler(DragEvent.DRAG_DONE, FXDnDInteropN.this.onDragDoneHandler); }  FXDnDInteropN.this.isDragSourceListenerInstalled = true; }  }); } protected void unregisterListeners() { FXDnDInteropN.this.runOnFxThread(() -> { if (FXDnDInteropN.this.isDragSourceListenerInstalled) { SwingNode swingNode = FXDnDInteropN.this.getNode(); if (swingNode != null) { swingNode.removeEventHandler(MouseEvent.MOUSE_PRESSED, FXDnDInteropN.this.onMousePressHandler); swingNode.removeEventHandler(MouseEvent.DRAG_DETECTED, FXDnDInteropN.this.onDragStartHandler); swingNode.removeEventHandler(DragEvent.DRAG_DONE, FXDnDInteropN.this.onDragDoneHandler); }  FXDnDInteropN.this.isDragSourceListenerInstalled = false; }  }); } private void fireEvent(int param1Int1, int param1Int2, long param1Long, int param1Int3) { appendEvent(new MouseEvent(getComponent(), 501, param1Long, param1Int3, param1Int1, param1Int2, 0, false)); int i = DragSourceContextWrapper.convertModifiersToDropAction(param1Int3, getSourceActions()); fireDragGestureRecognized(i, new Point(param1Int1, param1Int2)); }
/*     */   } private void fireEvent(int paramInt1, int paramInt2, long paramLong, int paramInt3) { ComponentMapper<FXDragGestureRecognizer> componentMapper = mapComponent(this.recognizers, paramInt1, paramInt2); FXDragGestureRecognizer fXDragGestureRecognizer = (FXDragGestureRecognizer)componentMapper.object; if (fXDragGestureRecognizer != null) { fXDragGestureRecognizer.fireEvent(componentMapper.x, componentMapper.y, paramLong, paramInt3); } else { SwingNodeHelper.leaveFXNestedLoop(this); }  } private MouseEvent getInitialGestureEvent() { return this.pressEvent; } private final class FXDragSourceContextPeer extends DragSourceContextWrapper {
/*     */     private volatile int sourceActions = 0; private final CachingTransferable transferable = new CachingTransferable(); public void startSecondaryEventLoop() { Toolkit.getToolkit().enterNestedEventLoop(this); } public void quitSecondaryEventLoop() { assert !Platform.isFxApplicationThread(); Platform.runLater(() -> Toolkit.getToolkit().exitNestedEventLoop(this, null)); } protected void setNativeCursor(Cursor param1Cursor, int param1Int) {} private void dragDone(int param1Int1, int param1Int2, int param1Int3) { dragDropFinished((param1Int1 != 0), param1Int1, param1Int2, param1Int3); } FXDragSourceContextPeer(DragGestureEvent param1DragGestureEvent) { super(param1DragGestureEvent); } protected void startDrag(Transferable param1Transferable, long[] param1ArrayOflong, Map param1Map) { FXDnDInteropN.this.activeDSContextPeer = this; this.transferable.updateData(param1Transferable, true); this.sourceActions = getDragSourceContext().getSourceActions(); if (!FXDnD.fxAppThreadIsDispatchThread) { FXDnDInteropN.this.loop = Toolkit.getDefaultToolkit().getSystemEventQueue().createSecondaryLoop(); SwingNodeHelper.leaveFXNestedLoop(FXDnDInteropN.this); if (!FXDnDInteropN.this.loop.enter()); }  }
/* 441 */   } private final class FXDropTargetContextPeer extends DropTargetContextWrapper { private int targetActions = 0;
/* 442 */     private int currentAction = 0;
/* 443 */     private DropTarget dt = null;
/* 444 */     private DropTargetContext ctx = null;
/*     */     
/* 446 */     private final CachingTransferable transferable = new CachingTransferable();
/*     */     
/*     */     private boolean success = false;
/*     */     
/* 450 */     private int dropAction = 0;
/*     */     
/* 452 */     public synchronized void setTargetActions(int param1Int) { this.targetActions = param1Int; } public synchronized int getTargetActions() {
/* 453 */       return this.targetActions;
/*     */     } public synchronized DropTarget getDropTarget() {
/* 455 */       return this.dt;
/*     */     } public synchronized boolean isTransferableJVMLocal() {
/* 457 */       return false;
/*     */     }
/* 459 */     public synchronized DataFlavor[] getTransferDataFlavors() { return this.transferable.getTransferDataFlavors(); } public synchronized Transferable getTransferable() {
/* 460 */       return (Transferable)this.transferable;
/*     */     }
/* 462 */     public synchronized void acceptDrag(int param1Int) { this.currentAction = param1Int; } public synchronized void rejectDrag() {
/* 463 */       this.currentAction = 0;
/*     */     }
/* 465 */     public synchronized void acceptDrop(int param1Int) { this.dropAction = param1Int; } public synchronized void rejectDrop() {
/* 466 */       this.dropAction = 0;
/*     */     } public synchronized void dropComplete(boolean param1Boolean) {
/* 468 */       this.success = param1Boolean;
/*     */     }
/*     */ 
/*     */     
/*     */     private int postDropTargetEvent(DragEvent param1DragEvent) {
/* 473 */       FXDnDInteropN.ComponentMapper<DropTarget> componentMapper = FXDnDInteropN.this.mapComponent(FXDnDInteropN.this.dropTargets, (int)param1DragEvent.getX(), (int)param1DragEvent.getY());
/*     */       
/* 475 */       EventType eventType = param1DragEvent.getEventType();
/*     */       
/* 477 */       Dragboard dragboard = param1DragEvent.getDragboard();
/* 478 */       this.transferable.updateData((Clipboard)dragboard, DragEvent.DRAG_DROPPED.equals(eventType));
/*     */       
/* 480 */       int i = SwingDnD.transferModesToDropActions(dragboard.getTransferModes());
/*     */       
/* 482 */       boolean bool = (param1DragEvent.getTransferMode() == null) ? false : SwingDnD.transferModeToDropAction(param1DragEvent.getTransferMode());
/*     */ 
/*     */       
/* 485 */       DropTarget dropTarget = (componentMapper.object != null) ? (DropTarget)componentMapper.object : this.dt;
/*     */       
/* 487 */       SwingNodeHelper.runOnEDTAndWait(FXDnDInteropN.this, () -> {
/*     */             if (param1DropTarget != this.dt) {
/*     */               if (this.ctx != null) {
/*     */                 reset(this.ctx);
/*     */               }
/*     */ 
/*     */               
/*     */               this.ctx = null;
/*     */ 
/*     */               
/*     */               this.currentAction = this.dropAction = 0;
/*     */             } 
/*     */ 
/*     */             
/*     */             if (param1DropTarget != null) {
/*     */               if (this.ctx == null) {
/*     */                 this.ctx = param1DropTarget.getDropTargetContext();
/*     */ 
/*     */                 
/*     */                 setDropTargetContext(this.ctx, this);
/*     */               } 
/*     */ 
/*     */               
/*     */               DropTarget dropTarget = param1DropTarget;
/*     */ 
/*     */               
/*     */               if (DragEvent.DRAG_DROPPED.equals(param1EventType)) {
/*     */                 DropTargetDropEvent dropTargetDropEvent = new DropTargetDropEvent(this.ctx, new Point(param1ComponentMapper.x, param1ComponentMapper.y), param1Int1, param1Int2);
/*     */ 
/*     */                 
/*     */                 dropTarget.drop(dropTargetDropEvent);
/*     */               } else {
/*     */                 DropTargetDragEvent dropTargetDragEvent = new DropTargetDragEvent(this.ctx, new Point(param1ComponentMapper.x, param1ComponentMapper.y), param1Int1, param1Int2);
/*     */ 
/*     */                 
/*     */                 if (DragEvent.DRAG_OVER.equals(param1EventType)) {
/*     */                   dropTarget.dragOver(dropTargetDragEvent);
/*     */                 } else if (DragEvent.DRAG_ENTERED.equals(param1EventType)) {
/*     */                   dropTarget.dragEnter(dropTargetDragEvent);
/*     */                 } else if (DragEvent.DRAG_EXITED.equals(param1EventType)) {
/*     */                   dropTarget.dragExit(dropTargetDragEvent);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*     */             this.dt = (DropTarget)param1ComponentMapper.object;
/*     */ 
/*     */             
/*     */             if (this.dt == null) {
/*     */               this.ctx = null;
/*     */               
/*     */               this.currentAction = this.dropAction = 0;
/*     */             } 
/*     */             
/*     */             if (DragEvent.DRAG_DROPPED.equals(param1EventType) || DragEvent.DRAG_EXITED.equals(param1EventType)) {
/*     */               this.ctx = null;
/*     */             }
/*     */             
/*     */             SwingNodeHelper.leaveFXNestedLoop(FXDnDInteropN.this);
/*     */           });
/*     */       
/* 549 */       if (DragEvent.DRAG_DROPPED.equals(eventType)) return this.dropAction;
/*     */       
/* 551 */       return this.currentAction;
/*     */     } }
/*     */ 
/*     */   
/*     */   public void addDropTarget(DropTarget paramDropTarget, SwingNode paramSwingNode) {
/* 556 */     this.dropTargets.put(paramDropTarget.getComponent(), paramDropTarget);
/* 557 */     Platform.runLater(() -> {
/*     */           if (!this.isDropTargetListenerInstalled) {
/*     */             paramSwingNode.addEventHandler(DragEvent.DRAG_ENTERED, this.onDragEnteredHandler);
/*     */             paramSwingNode.addEventHandler(DragEvent.DRAG_EXITED, this.onDragExitedHandler);
/*     */             paramSwingNode.addEventHandler(DragEvent.DRAG_OVER, this.onDragOverHandler);
/*     */             paramSwingNode.addEventHandler(DragEvent.DRAG_DROPPED, this.onDragDroppedHandler);
/*     */             this.isDropTargetListenerInstalled = true;
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeDropTarget(DropTarget paramDropTarget, SwingNode paramSwingNode) {
/* 570 */     this.dropTargets.remove(paramDropTarget.getComponent());
/* 571 */     Platform.runLater(() -> {
/*     */           if (this.isDropTargetListenerInstalled && this.dropTargets.isEmpty()) {
/*     */             paramSwingNode.removeEventHandler(DragEvent.DRAG_ENTERED, this.onDragEnteredHandler);
/*     */             paramSwingNode.removeEventHandler(DragEvent.DRAG_EXITED, this.onDragExitedHandler);
/*     */             paramSwingNode.removeEventHandler(DragEvent.DRAG_OVER, this.onDragOverHandler);
/*     */             paramSwingNode.removeEventHandler(DragEvent.DRAG_DROPPED, this.onDragDroppedHandler);
/*     */             this.isDropTargetListenerInstalled = false;
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\newimpl\FXDnDInteropN.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */