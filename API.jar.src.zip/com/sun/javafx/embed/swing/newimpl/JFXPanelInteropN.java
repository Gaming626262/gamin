/*    */ package com.sun.javafx.embed.swing.newimpl;
/*    */ 
/*    */ import java.awt.AWTEvent;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.Window;
/*    */ import javafx.embed.swing.JFXPanel;
/*    */ import jdk.swing.interop.SwingInterOpUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JFXPanelInteropN
/*    */ {
/*    */   public void postEvent(JFXPanel paramJFXPanel, AWTEvent paramAWTEvent) {
/* 36 */     SwingInterOpUtils.postEvent(paramJFXPanel, paramAWTEvent);
/*    */   }
/*    */   
/*    */   public boolean isUngrabEvent(AWTEvent paramAWTEvent) {
/* 40 */     return SwingInterOpUtils.isUngrabEvent(paramAWTEvent);
/*    */   }
/*    */   
/*    */   public long getMask() {
/* 44 */     return -2147483632L;
/*    */   }
/*    */   
/*    */   public void grab(Toolkit paramToolkit, Window paramWindow) {
/* 48 */     SwingInterOpUtils.grab(paramToolkit, paramWindow);
/*    */   }
/*    */   
/*    */   public void ungrab(Toolkit paramToolkit, Window paramWindow) {
/* 52 */     SwingInterOpUtils.ungrab(paramToolkit, paramWindow);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\newimpl\JFXPanelInteropN.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */