/*     */ package com.sun.javafx.embed.swing.newimpl;
/*     */ 
/*     */ import com.sun.javafx.PlatformUtil;
/*     */ import com.sun.javafx.embed.swing.DisposerRecord;
/*     */ import com.sun.javafx.embed.swing.FXDnD;
/*     */ import com.sun.javafx.embed.swing.SwingCursors;
/*     */ import com.sun.javafx.embed.swing.SwingNodeHelper;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.stage.WindowHelper;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.dnd.DragGestureEvent;
/*     */ import java.awt.dnd.DragGestureListener;
/*     */ import java.awt.dnd.DragSource;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.InvalidDnDOperationException;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.WindowFocusListener;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Method;
/*     */ import javafx.embed.swing.SwingNode;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javax.swing.JComponent;
/*     */ import jdk.swing.interop.DragSourceContextWrapper;
/*     */ import jdk.swing.interop.LightweightContentWrapper;
/*     */ import jdk.swing.interop.LightweightFrameWrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingNodeInteropN
/*     */ {
/*     */   private volatile LightweightFrameWrapper lwFrame;
/*     */   private static OptionalMethod<LightweightFrameWrapper> jlfNotifyDisplayChanged;
/*  67 */   private static Class lwFrameWrapperClass = null;
/*     */   private static final OptionalMethod<LightweightFrameWrapper> jlfSetHostBounds;
/*     */   
/*     */   static
/*     */   {
/*  72 */     jlfNotifyDisplayChanged = new OptionalMethod<>(LightweightFrameWrapper.class, "notifyDisplayChanged", new Class[] { double.class, double.class });
/*     */     
/*  74 */     if (!jlfNotifyDisplayChanged.isSupported()) {
/*  75 */       jlfNotifyDisplayChanged = new OptionalMethod<>(LightweightFrameWrapper.class, "notifyDisplayChanged", new Class[] { int.class });
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  80 */       lwFrameWrapperClass = Class.forName("jdk.swing.interop.LightweightFrameWrapper");
/*  81 */     } catch (Throwable throwable) {}
/*     */     
/*  83 */     Utils.loadNativeSwingLibrary();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     jlfSetHostBounds = new OptionalMethod<>(LightweightFrameWrapper.class, "setHostBounds", new Class[] { int.class, int.class, int.class, int.class }); }
/*     */   public LightweightFrameWrapper createLightweightFrame() { this.lwFrame = new LightweightFrameWrapper(); return this.lwFrame; }
/*     */   public LightweightFrameWrapper getLightweightFrame() { return this.lwFrame; }
/*     */   public MouseEvent createMouseEvent(Object paramObject, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean, int paramInt8) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.createMouseEvent(lightweightFrameWrapper, paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean, paramInt8); }
/*     */   public MouseWheelEvent createMouseWheelEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.createMouseWheelEvent(lightweightFrameWrapper, paramInt1, paramInt2, paramInt3, paramInt4); }
/* 221 */   public KeyEvent createKeyEvent(Object paramObject, int paramInt1, long paramLong, int paramInt2, int paramInt3, char paramChar) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.createKeyEvent(lightweightFrameWrapper, paramInt1, paramLong, paramInt2, paramInt3, paramChar); } public AWTEvent createUngrabEvent(Object paramObject) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return lightweightFrameWrapper.createUngrabEvent(lightweightFrameWrapper); } public void overrideNativeWindowHandle(Object paramObject, long paramLong, Runnable paramRunnable) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; overrideNativeWindowHandle(lwFrameWrapperClass, lightweightFrameWrapper, paramLong, paramRunnable); } public void emulateActivation(Object paramObject, boolean paramBoolean) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject;
/* 222 */     lightweightFrameWrapper.emulateActivation(paramBoolean); }
/*     */   public void notifyDisplayChanged(Object paramObject, double paramDouble1, double paramDouble2) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; if (jlfNotifyDisplayChanged.isIntegerApi()) { jlfNotifyDisplayChanged.invoke(lightweightFrameWrapper, new Object[] { Integer.valueOf((int)Math.round(paramDouble1)) }); } else { jlfNotifyDisplayChanged.invoke(lightweightFrameWrapper, new Object[] { Double.valueOf(paramDouble1), Double.valueOf(paramDouble2) }); }  }
/*     */   public void setHostBounds(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; jlfSetHostBounds.invoke(lightweightFrameWrapper, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) }); }
/*     */   public void setContent(Object paramObject1, Object paramObject2) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject1; LightweightContentWrapper lightweightContentWrapper = (LightweightContentWrapper)paramObject2; lightweightFrameWrapper.setContent(lightweightContentWrapper); } public void setVisible(Object paramObject, boolean paramBoolean) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; lightweightFrameWrapper.setVisible(paramBoolean); } public void setBounds(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; lightweightFrameWrapper.setBounds(paramInt1, paramInt2, paramInt3, paramInt4); } public LightweightContentWrapper createSwingNodeContent(JComponent paramJComponent, SwingNode paramSwingNode) { return new SwingNodeContent(paramJComponent, paramSwingNode); } public DisposerRecord createSwingNodeDisposer(Object paramObject) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject; return new SwingNodeDisposer(lightweightFrameWrapper); } private static final class OptionalMethod<T> {
/* 226 */     private final Method method; private final boolean isIntegerAPI; OptionalMethod(Class<T> param1Class, String param1String, Class<?>... param1VarArgs) { Method method; try { method = param1Class.getMethod(param1String, param1VarArgs); } catch (NoSuchMethodException noSuchMethodException) { method = null; } catch (Throwable throwable) { throw new RuntimeException("Error when calling " + param1Class.getName() + ".getMethod('" + param1String + "').", throwable); }  this.method = method; this.isIntegerAPI = (param1VarArgs != null && param1VarArgs.length > 0 && param1VarArgs[0] == int.class); } public boolean isSupported() { return (this.method != null); } public boolean isIntegerApi() { return this.isIntegerAPI; } public Object invoke(T param1T, Object... param1VarArgs) { if (this.method != null) try { return this.method.invoke(param1T, param1VarArgs); } catch (Throwable throwable) { throw new RuntimeException("Error when calling " + param1T.getClass().getName() + "." + this.method.getName() + "().", throwable); }   return null; } } public void disposeFrame(Object paramObject) { LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject;
/* 227 */     lightweightFrameWrapper.dispose(); }
/*     */ 
/*     */   
/*     */   public void addWindowFocusListener(Object paramObject, WindowFocusListener paramWindowFocusListener) {
/* 231 */     LightweightFrameWrapper lightweightFrameWrapper = (LightweightFrameWrapper)paramObject;
/* 232 */     lightweightFrameWrapper.addWindowFocusListener(paramWindowFocusListener);
/*     */   }
/*     */   private static native void overrideNativeWindowHandle(Class paramClass, LightweightFrameWrapper paramLightweightFrameWrapper, long paramLong, Runnable paramRunnable);
/*     */   
/*     */   private static class SwingNodeDisposer implements DisposerRecord { LightweightFrameWrapper lwFrame;
/*     */     
/*     */     SwingNodeDisposer(LightweightFrameWrapper param1LightweightFrameWrapper) {
/* 239 */       this.lwFrame = param1LightweightFrameWrapper;
/*     */     }
/*     */     public void dispose() {
/* 242 */       if (this.lwFrame != null) {
/* 243 */         this.lwFrame.dispose();
/* 244 */         this.lwFrame = null;
/*     */       } 
/*     */     } }
/*     */ 
/*     */   
/*     */   private static class SwingNodeContent extends LightweightContentWrapper {
/*     */     private JComponent comp;
/*     */     private volatile FXDnD dnd;
/*     */     private WeakReference<SwingNode> swingNodeRef;
/*     */     
/*     */     SwingNodeContent(JComponent param1JComponent, SwingNode param1SwingNode) {
/* 255 */       this.comp = param1JComponent;
/* 256 */       this.swingNodeRef = new WeakReference<>(param1SwingNode);
/*     */     }
/*     */     
/*     */     public JComponent getComponent() {
/* 260 */       return this.comp;
/*     */     }
/*     */     
/*     */     public void paintLock() {
/* 264 */       SwingNode swingNode = this.swingNodeRef.get();
/* 265 */       if (swingNode != null) {
/* 266 */         SwingNodeHelper.getPaintLock(swingNode).lock();
/*     */       }
/*     */     }
/*     */     
/*     */     public void paintUnlock() {
/* 271 */       SwingNode swingNode = this.swingNodeRef.get();
/* 272 */       if (swingNode != null) {
/* 273 */         SwingNodeHelper.getPaintLock(swingNode).unlock();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public void imageBufferReset(int[] param1ArrayOfint, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
/* 279 */       imageBufferReset(param1ArrayOfint, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5, 1);
/*     */     }
/*     */     
/*     */     public void imageBufferReset(int[] param1ArrayOfint, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/* 283 */       SwingNode swingNode = this.swingNodeRef.get();
/* 284 */       if (swingNode != null) {
/* 285 */         SwingNodeHelper.setImageBuffer(swingNode, param1ArrayOfint, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5, param1Int6, param1Int6);
/*     */       }
/*     */     }
/*     */     
/*     */     public void imageBufferReset(int[] param1ArrayOfint, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, double param1Double1, double param1Double2) {
/* 290 */       SwingNode swingNode = this.swingNodeRef.get();
/* 291 */       if (swingNode != null) {
/* 292 */         SwingNodeHelper.setImageBuffer(swingNode, param1ArrayOfint, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5, param1Double1, param1Double2);
/*     */       }
/*     */     }
/*     */     
/*     */     public void imageReshaped(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 297 */       SwingNode swingNode = this.swingNodeRef.get();
/* 298 */       if (swingNode != null) {
/* 299 */         SwingNodeHelper.setImageBounds(swingNode, param1Int1, param1Int2, param1Int3, param1Int4);
/*     */       }
/*     */     }
/*     */     
/*     */     public void imageUpdated(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 304 */       SwingNode swingNode = this.swingNodeRef.get();
/* 305 */       if (swingNode != null) {
/* 306 */         SwingNodeHelper.repaintDirtyRegion(swingNode, param1Int1, param1Int2, param1Int3, param1Int4);
/*     */       }
/*     */     }
/*     */     
/*     */     public void focusGrabbed() {
/* 311 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             if (PlatformUtil.isLinux()) {
/*     */               return;
/*     */             }
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               Scene scene = swingNode.getScene();
/*     */               if (scene != null && scene.getWindow() != null && WindowHelper.getPeer(scene.getWindow()) != null) {
/*     */                 WindowHelper.getPeer(scene.getWindow()).grabFocus();
/*     */                 SwingNodeHelper.setGrabbed(swingNode, true);
/*     */               } 
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void focusUngrabbed() {
/* 330 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               Scene scene = swingNode.getScene();
/*     */               SwingNodeHelper.ungrabFocus(swingNode, false);
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     public void preferredSizeChanged(int param1Int1, int param1Int2) {
/* 340 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               SwingNodeHelper.setSwingPrefWidth(swingNode, param1Int1);
/*     */               SwingNodeHelper.setSwingPrefHeight(swingNode, param1Int2);
/*     */               NodeHelper.notifyLayoutBoundsChanged((Node)swingNode);
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     public void maximumSizeChanged(int param1Int1, int param1Int2) {
/* 351 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               SwingNodeHelper.setSwingMaxWidth(swingNode, param1Int1);
/*     */               SwingNodeHelper.setSwingMaxHeight(swingNode, param1Int2);
/*     */               NodeHelper.notifyLayoutBoundsChanged((Node)swingNode);
/*     */             } 
/*     */           });
/*     */     }
/*     */     
/*     */     public void minimumSizeChanged(int param1Int1, int param1Int2) {
/* 362 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               SwingNodeHelper.setSwingMinWidth(swingNode, param1Int1);
/*     */               SwingNodeHelper.setSwingMinHeight(swingNode, param1Int2);
/*     */               NodeHelper.notifyLayoutBoundsChanged((Node)swingNode);
/*     */             } 
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     public void setCursor(Cursor param1Cursor) {
/* 374 */       SwingNodeHelper.runOnFxThread(() -> {
/*     */             SwingNode swingNode = this.swingNodeRef.get();
/*     */             if (swingNode != null) {
/*     */               swingNode.setCursor(SwingCursors.embedCursorToCursor(param1Cursor));
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */     
/*     */     private void initDnD() {
/* 384 */       synchronized (this) {
/* 385 */         if (this.dnd == null) {
/* 386 */           SwingNode swingNode = this.swingNodeRef.get();
/* 387 */           if (swingNode != null) {
/* 388 */             this.dnd = new FXDnD(swingNode);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized <T extends java.awt.dnd.DragGestureRecognizer> T createDragGestureRecognizer(Class<T> param1Class, DragSource param1DragSource, Component param1Component, int param1Int, DragGestureListener param1DragGestureListener) {
/* 400 */       initDnD();
/* 401 */       return (T)this.dnd.createDragGestureRecognizer(param1Class, param1DragSource, param1Component, param1Int, param1DragGestureListener);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DragSourceContextWrapper createDragSourceContext(DragGestureEvent param1DragGestureEvent) throws InvalidDnDOperationException {
/* 407 */       initDnD();
/* 408 */       return (DragSourceContextWrapper)this.dnd.createDragSourceContext(param1DragGestureEvent);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addDropTarget(DropTarget param1DropTarget) {
/* 413 */       initDnD();
/* 414 */       this.dnd.addDropTarget(param1DropTarget);
/*     */     }
/*     */ 
/*     */     
/*     */     public void removeDropTarget(DropTarget param1DropTarget) {
/* 419 */       initDnD();
/* 420 */       this.dnd.removeDropTarget(param1DropTarget);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\newimpl\SwingNodeInteropN.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */