/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import com.sun.javafx.geom.BaseBounds;
/*     */ import com.sun.javafx.geom.transform.BaseTransform;
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.sg.prism.NGNode;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.javafx.util.Utils;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import javafx.application.Platform;
/*     */ import javafx.embed.swing.SwingNode;
/*     */ import javafx.scene.Node;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingNodeHelper
/*     */   extends NodeHelper
/*     */ {
/*  51 */   private static final SwingNodeHelper theInstance = new SwingNodeHelper(); static {
/*  52 */     Utils.forceInit(SwingNode.class);
/*     */   }
/*     */   private static SwingNodeAccessor swingNodeAccessor;
/*     */   private static SwingNodeHelper getInstance() {
/*  56 */     return theInstance;
/*     */   }
/*     */   
/*     */   public static void initHelper(SwingNode paramSwingNode) {
/*  60 */     setHelper((Node)paramSwingNode, getInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   protected NGNode createPeerImpl(Node paramNode) {
/*  65 */     return swingNodeAccessor.doCreatePeer(paramNode);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updatePeerImpl(Node paramNode) {
/*  70 */     super.updatePeerImpl(paramNode);
/*  71 */     swingNodeAccessor.doUpdatePeer(paramNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseBounds computeGeomBoundsImpl(Node paramNode, BaseBounds paramBaseBounds, BaseTransform paramBaseTransform) {
/*  77 */     return swingNodeAccessor.doComputeGeomBounds(paramNode, paramBaseBounds, paramBaseTransform);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean computeContainsImpl(Node paramNode, double paramDouble1, double paramDouble2) {
/*  82 */     return swingNodeAccessor.doComputeContains(paramNode, paramDouble1, paramDouble2);
/*     */   }
/*     */   
/*     */   public static Object getLightweightFrame(SwingNode paramSwingNode) {
/*  86 */     return swingNodeAccessor.getLightweightFrame(paramSwingNode);
/*     */   }
/*     */   
/*     */   public static ReentrantLock getPaintLock(SwingNode paramSwingNode) {
/*  90 */     return swingNodeAccessor.getPaintLock(paramSwingNode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setImageBuffer(SwingNode paramSwingNode, int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, double paramDouble1, double paramDouble2) {
/*  97 */     swingNodeAccessor.setImageBuffer(paramSwingNode, paramArrayOfint, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramDouble1, paramDouble2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setImageBounds(SwingNode paramSwingNode, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 103 */     swingNodeAccessor.setImageBounds(paramSwingNode, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void repaintDirtyRegion(SwingNode paramSwingNode, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 108 */     swingNodeAccessor.repaintDirtyRegion(paramSwingNode, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void ungrabFocus(SwingNode paramSwingNode, boolean paramBoolean) {
/* 113 */     swingNodeAccessor.ungrabFocus(paramSwingNode, paramBoolean);
/*     */   }
/*     */   
/*     */   public static void setSwingPrefWidth(SwingNode paramSwingNode, int paramInt) {
/* 117 */     swingNodeAccessor.setSwingPrefWidth(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setSwingPrefHeight(SwingNode paramSwingNode, int paramInt) {
/* 121 */     swingNodeAccessor.setSwingPrefHeight(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setSwingMaxWidth(SwingNode paramSwingNode, int paramInt) {
/* 125 */     swingNodeAccessor.setSwingMaxWidth(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setSwingMaxHeight(SwingNode paramSwingNode, int paramInt) {
/* 129 */     swingNodeAccessor.setSwingMaxHeight(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setSwingMinWidth(SwingNode paramSwingNode, int paramInt) {
/* 133 */     swingNodeAccessor.setSwingMinWidth(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setSwingMinHeight(SwingNode paramSwingNode, int paramInt) {
/* 137 */     swingNodeAccessor.setSwingMinHeight(paramSwingNode, paramInt);
/*     */   }
/*     */   
/*     */   public static void setGrabbed(SwingNode paramSwingNode, boolean paramBoolean) {
/* 141 */     swingNodeAccessor.setGrabbed(paramSwingNode, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runOnFxThread(Runnable paramRunnable) {
/* 153 */     if (Platform.isFxApplicationThread()) {
/* 154 */       paramRunnable.run();
/*     */     } else {
/* 156 */       Platform.runLater(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runOnEDT(Runnable paramRunnable) {
/* 169 */     if (SwingUtilities.isEventDispatchThread()) {
/* 170 */       paramRunnable.run();
/*     */     } else {
/* 172 */       SwingUtilities.invokeLater(paramRunnable);
/*     */     } 
/*     */   }
/*     */   
/* 176 */   private static final Set<Object> eventLoopKeys = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runOnEDTAndWait(Object paramObject, Runnable paramRunnable) {
/* 186 */     Toolkit.getToolkit().checkFxUserThread();
/*     */     
/* 188 */     if (SwingUtilities.isEventDispatchThread()) {
/* 189 */       paramRunnable.run();
/*     */     } else {
/* 191 */       eventLoopKeys.add(paramObject);
/* 192 */       SwingUtilities.invokeLater(paramRunnable);
/* 193 */       Toolkit.getToolkit().enterNestedEventLoop(paramObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void leaveFXNestedLoop(Object paramObject) {
/* 204 */     if (!eventLoopKeys.contains(paramObject))
/*     */       return; 
/* 206 */     if (Platform.isFxApplicationThread()) {
/* 207 */       Toolkit.getToolkit().exitNestedEventLoop(paramObject, null);
/*     */     } else {
/* 209 */       Platform.runLater(() -> Toolkit.getToolkit().exitNestedEventLoop(paramObject, null));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 214 */     eventLoopKeys.remove(paramObject);
/*     */   }
/*     */   
/*     */   public static void setSwingNodeAccessor(SwingNodeAccessor paramSwingNodeAccessor) {
/* 218 */     if (swingNodeAccessor != null) {
/* 219 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 222 */     swingNodeAccessor = paramSwingNodeAccessor;
/*     */   }
/*     */   
/*     */   public static interface SwingNodeAccessor {
/*     */     NGNode doCreatePeer(Node param1Node);
/*     */     
/*     */     void doUpdatePeer(Node param1Node);
/*     */     
/*     */     BaseBounds doComputeGeomBounds(Node param1Node, BaseBounds param1BaseBounds, BaseTransform param1BaseTransform);
/*     */     
/*     */     boolean doComputeContains(Node param1Node, double param1Double1, double param1Double2);
/*     */     
/*     */     Object getLightweightFrame(SwingNode param1SwingNode);
/*     */     
/*     */     ReentrantLock getPaintLock(SwingNode param1SwingNode);
/*     */     
/*     */     void setImageBuffer(SwingNode param1SwingNode, int[] param1ArrayOfint, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, double param1Double1, double param1Double2);
/*     */     
/*     */     void setImageBounds(SwingNode param1SwingNode, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
/*     */     
/*     */     void repaintDirtyRegion(SwingNode param1SwingNode, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
/*     */     
/*     */     void ungrabFocus(SwingNode param1SwingNode, boolean param1Boolean);
/*     */     
/*     */     void setSwingPrefWidth(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setSwingPrefHeight(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setSwingMaxWidth(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setSwingMaxHeight(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setSwingMinWidth(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setSwingMinHeight(SwingNode param1SwingNode, int param1Int);
/*     */     
/*     */     void setGrabbed(SwingNode param1SwingNode, boolean param1Boolean);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\SwingNodeHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */