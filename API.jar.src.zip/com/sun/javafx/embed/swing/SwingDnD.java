/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import com.sun.javafx.embed.EmbeddedSceneDSInterface;
/*     */ import com.sun.javafx.embed.EmbeddedSceneDTInterface;
/*     */ import com.sun.javafx.embed.EmbeddedSceneInterface;
/*     */ import com.sun.javafx.embed.HostDragStartListener;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.awt.Point;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.dnd.DragGestureEvent;
/*     */ import java.awt.dnd.DragGestureRecognizer;
/*     */ import java.awt.dnd.DragSource;
/*     */ import java.awt.dnd.DragSourceAdapter;
/*     */ import java.awt.dnd.DragSourceDropEvent;
/*     */ import java.awt.dnd.DragSourceListener;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.DropTargetAdapter;
/*     */ import java.awt.dnd.DropTargetDragEvent;
/*     */ import java.awt.dnd.DropTargetDropEvent;
/*     */ import java.awt.dnd.DropTargetEvent;
/*     */ import java.awt.dnd.InvalidDnDOperationException;
/*     */ import java.awt.event.InputEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javafx.scene.input.TransferMode;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SwingDnD
/*     */ {
/*  70 */   private final Transferable dndTransferable = new DnDTransferable();
/*     */ 
/*     */   
/*     */   private final DragSource dragSource;
/*     */ 
/*     */   
/*     */   private final DragSourceListener dragSourceListener;
/*     */   
/*     */   private SwingDragSource swingDragSource;
/*     */   
/*     */   private EmbeddedSceneDTInterface fxDropTarget;
/*     */   
/*     */   private EmbeddedSceneDSInterface fxDragSource;
/*     */   
/*     */   private MouseEvent me;
/*     */ 
/*     */   
/*     */   public SwingDnD(final JComponent comp, final EmbeddedSceneInterface embeddedScene) {
/*  88 */     comp.addMouseListener(new MouseAdapter()
/*     */         {
/*     */           public void mouseClicked(MouseEvent param1MouseEvent) {
/*  91 */             SwingDnD.this.storeMouseEvent(param1MouseEvent);
/*     */           }
/*     */           
/*     */           public void mouseDragged(MouseEvent param1MouseEvent) {
/*  95 */             SwingDnD.this.storeMouseEvent(param1MouseEvent);
/*     */           }
/*     */           
/*     */           public void mousePressed(MouseEvent param1MouseEvent) {
/*  99 */             SwingDnD.this.storeMouseEvent(param1MouseEvent);
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent param1MouseEvent) {
/* 103 */             SwingDnD.this.storeMouseEvent(param1MouseEvent);
/*     */           }
/*     */         });
/*     */     
/* 107 */     this.dragSource = new DragSource();
/* 108 */     this.dragSourceListener = new DragSourceAdapter()
/*     */       {
/*     */         public void dragDropEnd(DragSourceDropEvent param1DragSourceDropEvent) {
/* 111 */           assert SwingDnD.this.fxDragSource != null;
/*     */           try {
/* 113 */             SwingDnD.this.fxDragSource.dragDropEnd(SwingDnD.dropActionToTransferMode(param1DragSourceDropEvent.getDropAction()));
/*     */           } finally {
/* 115 */             SwingDnD.this.fxDragSource = null;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 120 */     DropTargetAdapter dropTargetAdapter = new DropTargetAdapter()
/*     */       {
/*     */         private TransferMode lastTransferMode;
/*     */ 
/*     */         
/*     */         public void dragEnter(DropTargetDragEvent param1DropTargetDragEvent) {
/* 126 */           if (SwingDnD.this.swingDragSource != null || SwingDnD.this.fxDropTarget != null) {
/*     */             return;
/*     */           }
/*     */           
/* 130 */           assert SwingDnD.this.swingDragSource == null;
/* 131 */           SwingDnD.this.swingDragSource = new SwingDragSource();
/* 132 */           SwingDnD.this.swingDragSource.updateContents(param1DropTargetDragEvent, false);
/*     */           
/* 134 */           assert SwingDnD.this.fxDropTarget == null;
/*     */ 
/*     */ 
/*     */           
/* 138 */           SwingDnD.this.fxDropTarget = embeddedScene.createDropTarget();
/*     */           
/* 140 */           Point point1 = param1DropTargetDragEvent.getLocation();
/* 141 */           Point point2 = new Point(point1);
/* 142 */           SwingUtilities.convertPointToScreen(point2, comp);
/* 143 */           this.lastTransferMode = SwingDnD.this.fxDropTarget.handleDragEnter(point1.x, point1.y, point2.x, point2.y, 
/*     */               
/* 145 */               SwingDnD.dropActionToTransferMode(param1DropTargetDragEvent.getDropAction()), SwingDnD.this.swingDragSource);
/* 146 */           SwingDnD.this.applyDragResult(this.lastTransferMode, param1DropTargetDragEvent);
/*     */         }
/*     */ 
/*     */         
/*     */         public void dragExit(DropTargetEvent param1DropTargetEvent) {
/* 151 */           assert SwingDnD.this.swingDragSource != null;
/* 152 */           assert SwingDnD.this.fxDropTarget != null;
/*     */           try {
/* 154 */             SwingDnD.this.fxDropTarget.handleDragLeave();
/*     */           } finally {
/* 156 */             SwingDnD.this.endDnD();
/* 157 */             this.lastTransferMode = null;
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void dragOver(DropTargetDragEvent param1DropTargetDragEvent) {
/* 163 */           assert SwingDnD.this.swingDragSource != null;
/* 164 */           SwingDnD.this.swingDragSource.updateContents(param1DropTargetDragEvent, false);
/*     */           
/* 166 */           assert SwingDnD.this.fxDropTarget != null;
/* 167 */           Point point1 = param1DropTargetDragEvent.getLocation();
/* 168 */           Point point2 = new Point(point1);
/* 169 */           SwingUtilities.convertPointToScreen(point2, comp);
/* 170 */           this.lastTransferMode = SwingDnD.this.fxDropTarget.handleDragOver(point1.x, point1.y, point2.x, point2.y, 
/*     */               
/* 172 */               SwingDnD.dropActionToTransferMode(param1DropTargetDragEvent.getDropAction()));
/* 173 */           SwingDnD.this.applyDragResult(this.lastTransferMode, param1DropTargetDragEvent);
/*     */         }
/*     */ 
/*     */         
/*     */         public void drop(DropTargetDropEvent param1DropTargetDropEvent) {
/* 178 */           assert SwingDnD.this.swingDragSource != null;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 183 */           SwingDnD.this.applyDropResult(this.lastTransferMode, param1DropTargetDropEvent);
/* 184 */           SwingDnD.this.swingDragSource.updateContents(param1DropTargetDropEvent, true);
/*     */           
/* 186 */           Point point1 = param1DropTargetDropEvent.getLocation();
/* 187 */           Point point2 = new Point(point1);
/* 188 */           SwingUtilities.convertPointToScreen(point2, comp);
/*     */           
/* 190 */           assert SwingDnD.this.fxDropTarget != null;
/*     */           try {
/* 192 */             this.lastTransferMode = SwingDnD.this.fxDropTarget.handleDragDrop(point1.x, point1.y, point2.x, point2.y, 
/*     */                 
/* 194 */                 SwingDnD.dropActionToTransferMode(param1DropTargetDropEvent.getDropAction()));
/*     */             try {
/* 196 */               SwingDnD.this.applyDropResult(this.lastTransferMode, param1DropTargetDropEvent);
/* 197 */             } catch (InvalidDnDOperationException invalidDnDOperationException) {}
/*     */ 
/*     */           
/*     */           }
/*     */           finally {
/*     */ 
/*     */ 
/*     */             
/* 205 */             param1DropTargetDropEvent.dropComplete((this.lastTransferMode != null));
/* 206 */             SwingDnD.this.endDnD();
/* 207 */             this.lastTransferMode = null;
/*     */           } 
/*     */         }
/*     */       };
/* 211 */     comp.setDropTarget(new DropTarget(comp, 1073741827, dropTargetAdapter));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addNotify() {
/* 217 */     this.dragSource.addDragSourceListener(this.dragSourceListener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeNotify() {
/* 223 */     this.dragSource.removeDragSourceListener(this.dragSourceListener);
/*     */   }
/*     */   
/*     */   public HostDragStartListener getDragStartListener() {
/* 227 */     return (paramEmbeddedSceneDSInterface, paramTransferMode) -> {
/*     */         assert Toolkit.getToolkit().isFxUserThread();
/*     */         assert paramEmbeddedSceneDSInterface != null;
/*     */         SwingUtilities.invokeLater(());
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startDrag(final MouseEvent e, Transferable paramTransferable, final Set<TransferMode> sa, TransferMode paramTransferMode) {
/* 250 */     assert sa.contains(paramTransferMode);
/*     */     final class StubDragGestureRecognizer
/*     */       extends DragGestureRecognizer
/*     */     {
/*     */       StubDragGestureRecognizer(DragSource param1DragSource1) {
/* 255 */         super(param1DragSource1, param1MouseEvent.getComponent());
/* 256 */         setSourceActions(SwingDnD.transferModesToDropActions(sa));
/* 257 */         appendEvent(e);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       protected void registerListeners() {}
/*     */ 
/*     */       
/*     */       protected void unregisterListeners() {}
/*     */     };
/* 267 */     Point point = new Point(e.getX(), e.getY());
/* 268 */     int i = transferModeToDropAction(paramTransferMode);
/* 269 */     StubDragGestureRecognizer stubDragGestureRecognizer = new StubDragGestureRecognizer(this.dragSource);
/*     */     
/* 271 */     List<InputEvent> list = Arrays.asList(new InputEvent[] { stubDragGestureRecognizer.getTriggerEvent() });
/* 272 */     DragGestureEvent dragGestureEvent = new DragGestureEvent(stubDragGestureRecognizer, i, point, list);
/* 273 */     dragGestureEvent.startDrag(null, paramTransferable);
/*     */   }
/*     */   
/*     */   private void endDnD() {
/* 277 */     assert this.swingDragSource != null;
/* 278 */     assert this.fxDropTarget != null;
/* 279 */     this.fxDropTarget = null;
/* 280 */     this.swingDragSource = null;
/*     */   }
/*     */   
/*     */   private void storeMouseEvent(MouseEvent paramMouseEvent) {
/* 284 */     this.me = paramMouseEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyDragResult(TransferMode paramTransferMode, DropTargetDragEvent paramDropTargetDragEvent) {
/* 290 */     if (paramTransferMode == null) {
/* 291 */       paramDropTargetDragEvent.rejectDrag();
/*     */     } else {
/* 293 */       paramDropTargetDragEvent.acceptDrag(transferModeToDropAction(paramTransferMode));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyDropResult(TransferMode paramTransferMode, DropTargetDropEvent paramDropTargetDropEvent) {
/* 300 */     if (paramTransferMode == null) {
/* 301 */       paramDropTargetDropEvent.rejectDrop();
/*     */     } else {
/* 303 */       paramDropTargetDropEvent.acceptDrop(transferModeToDropAction(paramTransferMode));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static TransferMode dropActionToTransferMode(int paramInt) {
/* 308 */     switch (paramInt) {
/*     */       case 1:
/* 310 */         return TransferMode.COPY;
/*     */       case 2:
/* 312 */         return TransferMode.MOVE;
/*     */       case 1073741824:
/* 314 */         return TransferMode.LINK;
/*     */       case 0:
/* 316 */         return null;
/*     */     } 
/* 318 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */   
/*     */   public static int transferModeToDropAction(TransferMode paramTransferMode) {
/* 323 */     switch (paramTransferMode) {
/*     */       case COPY:
/* 325 */         return 1;
/*     */       case MOVE:
/* 327 */         return 2;
/*     */       case LINK:
/* 329 */         return 1073741824;
/*     */     } 
/* 331 */     throw new IllegalArgumentException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<TransferMode> dropActionsToTransferModes(int paramInt) {
/* 338 */     EnumSet<TransferMode> enumSet = EnumSet.noneOf(TransferMode.class);
/* 339 */     if ((paramInt & 0x1) != 0) {
/* 340 */       enumSet.add(TransferMode.COPY);
/*     */     }
/* 342 */     if ((paramInt & 0x2) != 0) {
/* 343 */       enumSet.add(TransferMode.MOVE);
/*     */     }
/* 345 */     if ((paramInt & 0x40000000) != 0) {
/* 346 */       enumSet.add(TransferMode.LINK);
/*     */     }
/* 348 */     return Collections.unmodifiableSet(enumSet);
/*     */   }
/*     */   
/*     */   public static int transferModesToDropActions(Set<TransferMode> paramSet) {
/* 352 */     int i = 0;
/* 353 */     for (TransferMode transferMode : paramSet) {
/* 354 */       i |= transferModeToDropAction(transferMode);
/*     */     }
/* 356 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class DnDTransferable
/*     */     implements Transferable
/*     */   {
/*     */     public Object getTransferData(DataFlavor param1DataFlavor) throws UnsupportedEncodingException {
/* 367 */       assert SwingDnD.this.fxDragSource != null;
/* 368 */       assert SwingUtilities.isEventDispatchThread();
/*     */       
/* 370 */       String str = DataFlavorUtils.getFxMimeType(param1DataFlavor);
/* 371 */       return DataFlavorUtils.adjustFxData(param1DataFlavor, SwingDnD.this.fxDragSource
/* 372 */           .getData(str));
/*     */     }
/*     */ 
/*     */     
/*     */     public DataFlavor[] getTransferDataFlavors() {
/* 377 */       assert SwingDnD.this.fxDragSource != null;
/* 378 */       assert SwingUtilities.isEventDispatchThread();
/*     */       
/* 380 */       String[] arrayOfString = SwingDnD.this.fxDragSource.getMimeTypes();
/*     */       
/* 382 */       ArrayList<DataFlavor> arrayList = new ArrayList(arrayOfString.length);
/*     */       
/* 384 */       for (String str : arrayOfString) {
/* 385 */         DataFlavor dataFlavor = null;
/*     */         try {
/* 387 */           dataFlavor = new DataFlavor(str);
/* 388 */         } catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */         
/* 392 */         arrayList.add(dataFlavor);
/*     */       } 
/* 394 */       return arrayList.<DataFlavor>toArray(new DataFlavor[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isDataFlavorSupported(DataFlavor param1DataFlavor) {
/* 399 */       assert SwingDnD.this.fxDragSource != null;
/* 400 */       assert SwingUtilities.isEventDispatchThread();
/*     */       
/* 402 */       return SwingDnD.this.fxDragSource.isMimeTypeAvailable(
/* 403 */           DataFlavorUtils.getFxMimeType(param1DataFlavor));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\SwingDnD.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */