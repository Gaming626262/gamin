/*    */ package com.sun.javafx.embed.swing;
/*    */ 
/*    */ import com.sun.javafx.embed.EmbeddedSceneDSInterface;
/*    */ import com.sun.javafx.tk.Toolkit;
/*    */ import java.awt.dnd.DropTargetDragEvent;
/*    */ import java.awt.dnd.DropTargetDropEvent;
/*    */ import java.util.Set;
/*    */ import javafx.scene.input.TransferMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SwingDragSource
/*    */   extends CachingTransferable
/*    */   implements EmbeddedSceneDSInterface
/*    */ {
/*    */   private int sourceActions;
/*    */   
/*    */   void updateContents(DropTargetDragEvent paramDropTargetDragEvent, boolean paramBoolean) {
/* 46 */     this.sourceActions = paramDropTargetDragEvent.getSourceActions();
/* 47 */     updateData(paramDropTargetDragEvent.getTransferable(), paramBoolean);
/*    */   }
/*    */   
/*    */   void updateContents(DropTargetDropEvent paramDropTargetDropEvent, boolean paramBoolean) {
/* 51 */     this.sourceActions = paramDropTargetDropEvent.getSourceActions();
/* 52 */     updateData(paramDropTargetDropEvent.getTransferable(), paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public Set<TransferMode> getSupportedActions() {
/* 57 */     assert Toolkit.getToolkit().isFxUserThread();
/* 58 */     return SwingDnD.dropActionsToTransferModes(this.sourceActions);
/*    */   }
/*    */ 
/*    */   
/*    */   public void dragDropEnd(TransferMode paramTransferMode) {
/* 63 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\SwingDragSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */