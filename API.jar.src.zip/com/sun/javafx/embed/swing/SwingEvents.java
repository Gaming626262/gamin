/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.input.ScrollEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingEvents
/*     */ {
/*     */   public static int mouseIDToEmbedMouseType(int paramInt) {
/*  43 */     switch (paramInt) {
/*     */       case 501:
/*  45 */         return 0;
/*     */       case 502:
/*  47 */         return 1;
/*     */       case 500:
/*  49 */         return 2;
/*     */       case 503:
/*  51 */         return 5;
/*     */       case 506:
/*  53 */         return 6;
/*     */       case 504:
/*  55 */         return 3;
/*     */       case 505:
/*  57 */         return 4;
/*     */     } 
/*  59 */     return 0;
/*     */   }
/*     */   
/*     */   public static int mouseButtonToEmbedMouseButton(int paramInt1, int paramInt2) {
/*  63 */     byte b = 0;
/*  64 */     switch (paramInt1) {
/*     */       case 1:
/*  66 */         b = 1;
/*     */         break;
/*     */       case 2:
/*  69 */         b = 4;
/*     */         break;
/*     */       case 3:
/*  72 */         b = 2;
/*     */         break;
/*     */       case 4:
/*  75 */         b = 8;
/*     */         break;
/*     */       case 5:
/*  78 */         b = 16;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  84 */     if ((paramInt2 & 0x400) != 0) {
/*  85 */       b = 1;
/*  86 */     } else if ((paramInt2 & 0x800) != 0) {
/*  87 */       b = 4;
/*  88 */     } else if ((paramInt2 & 0x1000) != 0) {
/*  89 */       b = 2;
/*  90 */     } else if ((paramInt2 & MouseEvent.getMaskForButton(4)) != 0) {
/*  91 */       b = 8;
/*  92 */     } else if ((paramInt2 & MouseEvent.getMaskForButton(5)) != 0) {
/*  93 */       b = 16;
/*     */     } 
/*  95 */     return b;
/*     */   }
/*     */   
/*     */   public static int getWheelRotation(MouseEvent paramMouseEvent) {
/*  99 */     if (paramMouseEvent instanceof MouseWheelEvent) {
/* 100 */       return ((MouseWheelEvent)paramMouseEvent).getWheelRotation();
/*     */     }
/* 102 */     return 0;
/*     */   }
/*     */   
/*     */   public static int keyIDToEmbedKeyType(int paramInt) {
/* 106 */     switch (paramInt) {
/*     */       case 401:
/* 108 */         return 0;
/*     */       case 402:
/* 110 */         return 1;
/*     */       case 400:
/* 112 */         return 2;
/*     */     } 
/* 114 */     return 0;
/*     */   }
/*     */   
/*     */   public static int keyModifiersToEmbedKeyModifiers(int paramInt) {
/* 118 */     int i = 0;
/* 119 */     if ((paramInt & 0x40) != 0) {
/* 120 */       i |= 0x1;
/*     */     }
/* 122 */     if ((paramInt & 0x80) != 0) {
/* 123 */       i |= 0x2;
/*     */     }
/* 125 */     if ((paramInt & 0x200) != 0) {
/* 126 */       i |= 0x4;
/*     */     }
/* 128 */     if ((paramInt & 0x100) != 0) {
/* 129 */       i |= 0x8;
/*     */     }
/* 131 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public static char keyCharToEmbedKeyChar(char paramChar) {
/* 136 */     return (paramChar == '\n') ? '\r' : paramChar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int fxMouseEventTypeToMouseID(MouseEvent paramMouseEvent) {
/* 142 */     EventType eventType = paramMouseEvent.getEventType();
/* 143 */     if (eventType == MouseEvent.MOUSE_MOVED) {
/* 144 */       return 503;
/*     */     }
/* 146 */     if (eventType == MouseEvent.MOUSE_PRESSED) {
/* 147 */       return 501;
/*     */     }
/* 149 */     if (eventType == MouseEvent.MOUSE_RELEASED) {
/* 150 */       return 502;
/*     */     }
/* 152 */     if (eventType == MouseEvent.MOUSE_CLICKED) {
/* 153 */       return 500;
/*     */     }
/* 155 */     if (eventType == MouseEvent.MOUSE_ENTERED) {
/* 156 */       return 504;
/*     */     }
/* 158 */     if (eventType == MouseEvent.MOUSE_EXITED) {
/* 159 */       return 505;
/*     */     }
/* 161 */     if (eventType == MouseEvent.MOUSE_DRAGGED) {
/* 162 */       return 506;
/*     */     }
/* 164 */     if (eventType == MouseEvent.DRAG_DETECTED) {
/* 165 */       return -1;
/*     */     }
/* 167 */     throw new RuntimeException("Unknown MouseEvent type: " + eventType);
/*     */   }
/*     */   
/*     */   public static int fxMouseModsToMouseMods(MouseEvent paramMouseEvent) {
/* 171 */     int i = 0;
/* 172 */     if (paramMouseEvent.isAltDown()) {
/* 173 */       i |= 0x200;
/*     */     }
/* 175 */     if (paramMouseEvent.isControlDown()) {
/* 176 */       i |= 0x80;
/*     */     }
/* 178 */     if (paramMouseEvent.isMetaDown()) {
/* 179 */       i |= 0x100;
/*     */     }
/* 181 */     if (paramMouseEvent.isShiftDown()) {
/* 182 */       i |= 0x40;
/*     */     }
/* 184 */     if (paramMouseEvent.isPrimaryButtonDown()) {
/* 185 */       i |= 0x400;
/*     */     }
/* 187 */     if (paramMouseEvent.isSecondaryButtonDown()) {
/* 188 */       i |= 0x1000;
/*     */     }
/* 190 */     if (paramMouseEvent.isMiddleButtonDown()) {
/* 191 */       i |= 0x800;
/*     */     }
/* 193 */     if (paramMouseEvent.isBackButtonDown()) {
/* 194 */       i |= MouseEvent.getMaskForButton(4);
/*     */     }
/* 196 */     if (paramMouseEvent.isForwardButtonDown()) {
/* 197 */       i |= MouseEvent.getMaskForButton(5);
/*     */     }
/* 199 */     return i;
/*     */   }
/*     */   
/*     */   public static int fxMouseButtonToMouseButton(MouseEvent paramMouseEvent) {
/* 203 */     switch (paramMouseEvent.getButton()) {
/*     */       case PRIMARY:
/* 205 */         return 1;
/*     */       case SECONDARY:
/* 207 */         return 3;
/*     */       case MIDDLE:
/* 209 */         return 2;
/*     */       case BACK:
/* 211 */         return 4;
/*     */       case FORWARD:
/* 213 */         return 5;
/*     */     } 
/* 215 */     return 0;
/*     */   }
/*     */   
/*     */   public static int fxKeyEventTypeToKeyID(KeyEvent paramKeyEvent) {
/* 219 */     EventType eventType = paramKeyEvent.getEventType();
/* 220 */     if (eventType == KeyEvent.KEY_PRESSED) {
/* 221 */       return 401;
/*     */     }
/* 223 */     if (eventType == KeyEvent.KEY_RELEASED) {
/* 224 */       return 402;
/*     */     }
/* 226 */     if (eventType == KeyEvent.KEY_TYPED) {
/* 227 */       return 400;
/*     */     }
/* 229 */     throw new RuntimeException("Unknown KeyEvent type: " + eventType);
/*     */   }
/*     */   
/*     */   public static int fxKeyModsToKeyMods(KeyEvent paramKeyEvent) {
/* 233 */     int i = 0;
/* 234 */     if (paramKeyEvent.isAltDown()) {
/* 235 */       i |= 0x200;
/*     */     }
/* 237 */     if (paramKeyEvent.isControlDown()) {
/* 238 */       i |= 0x80;
/*     */     }
/* 240 */     if (paramKeyEvent.isMetaDown()) {
/* 241 */       i |= 0x100;
/*     */     }
/* 243 */     if (paramKeyEvent.isShiftDown()) {
/* 244 */       i |= 0x40;
/*     */     }
/* 246 */     return i;
/*     */   }
/*     */   
/*     */   public static int fxScrollModsToMouseWheelMods(ScrollEvent paramScrollEvent) {
/* 250 */     int i = 0;
/* 251 */     if (paramScrollEvent.isAltDown()) {
/* 252 */       i |= 0x200;
/*     */     }
/* 254 */     if (paramScrollEvent.isControlDown()) {
/* 255 */       i |= 0x80;
/*     */     }
/* 257 */     if (paramScrollEvent.isMetaDown()) {
/* 258 */       i |= 0x100;
/*     */     }
/* 260 */     if (paramScrollEvent.isShiftDown()) {
/* 261 */       i |= 0x40;
/*     */     }
/* 263 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\SwingEvents.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */