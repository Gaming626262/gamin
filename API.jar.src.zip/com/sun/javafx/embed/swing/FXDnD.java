/*    */ package com.sun.javafx.embed.swing;
/*    */ 
/*    */ import com.sun.javafx.embed.swing.newimpl.FXDnDInteropN;
/*    */ import java.awt.Component;
/*    */ import java.awt.dnd.DragGestureEvent;
/*    */ import java.awt.dnd.DragGestureListener;
/*    */ import java.awt.dnd.DragSource;
/*    */ import java.awt.dnd.DropTarget;
/*    */ import java.awt.dnd.InvalidDnDOperationException;
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ import javafx.embed.swing.SwingNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FXDnD
/*    */ {
/*    */   public static boolean fxAppThreadIsDispatchThread;
/*    */   private FXDnDInteropN fxdndiop;
/*    */   
/*    */   static {
/* 50 */     Object object = AccessController.doPrivileged(new PrivilegedAction()
/*    */         {
/*    */           public Object run() {
/* 53 */             FXDnD.fxAppThreadIsDispatchThread = "true".equals(System.getProperty("javafx.embed.singleThread"));
/* 54 */             return null;
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public FXDnD(SwingNode paramSwingNode) {
/* 61 */     this.fxdndiop = new FXDnDInteropN();
/* 62 */     this.fxdndiop.setNode(paramSwingNode);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object createDragSourceContext(DragGestureEvent paramDragGestureEvent) throws InvalidDnDOperationException {
/* 67 */     return this.fxdndiop.createDragSourceContext(paramDragGestureEvent);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T extends java.awt.dnd.DragGestureRecognizer> T createDragGestureRecognizer(Class<T> paramClass, DragSource paramDragSource, Component paramComponent, int paramInt, DragGestureListener paramDragGestureListener) {
/* 75 */     return (T)this.fxdndiop.createDragGestureRecognizer(paramDragSource, paramComponent, paramInt, paramDragGestureListener);
/*    */   }
/*    */   
/*    */   public void addDropTarget(DropTarget paramDropTarget) {
/* 79 */     SwingNode swingNode = this.fxdndiop.getNode();
/* 80 */     if (swingNode != null) {
/* 81 */       this.fxdndiop.addDropTarget(paramDropTarget, swingNode);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeDropTarget(DropTarget paramDropTarget) {
/* 86 */     SwingNode swingNode = this.fxdndiop.getNode();
/* 87 */     if (swingNode != null)
/* 88 */       this.fxdndiop.removeDropTarget(paramDropTarget, swingNode); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\FXDnD.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */