/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javafx.scene.input.Clipboard;
/*     */ import javafx.scene.input.DataFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CachingTransferable
/*     */   implements Transferable
/*     */ {
/*     */   public Object getTransferData(DataFlavor paramDataFlavor) throws UnsupportedEncodingException {
/*  48 */     String str = DataFlavorUtils.getFxMimeType(paramDataFlavor);
/*  49 */     return DataFlavorUtils.adjustFxData(paramDataFlavor, 
/*  50 */         getData(str));
/*     */   }
/*     */ 
/*     */   
/*     */   public DataFlavor[] getTransferDataFlavors() {
/*  55 */     String[] arrayOfString = getMimeTypes();
/*  56 */     return DataFlavorUtils.getDataFlavors(arrayOfString);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDataFlavorSupported(DataFlavor paramDataFlavor) {
/*  61 */     return isMimeTypeAvailable(
/*  62 */         DataFlavorUtils.getFxMimeType(paramDataFlavor));
/*     */   }
/*     */   
/*  65 */   private Map<String, Object> mimeType2Data = Collections.EMPTY_MAP;
/*     */ 
/*     */   
/*     */   public void updateData(Transferable paramTransferable, boolean paramBoolean) {
/*  69 */     Map<String, DataFlavor> map = DataFlavorUtils.adjustSwingDataFlavors(paramTransferable
/*  70 */         .getTransferDataFlavors());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  96 */       this.mimeType2Data = DataFlavorUtils.readAllData(paramTransferable, map, paramBoolean);
/*     */     }
/*  98 */     catch (Exception exception) {
/*  99 */       this.mimeType2Data = Collections.EMPTY_MAP;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updateData(Clipboard paramClipboard, boolean paramBoolean) {
/* 104 */     this.mimeType2Data = new HashMap<>();
/* 105 */     for (DataFormat dataFormat : paramClipboard.getContentTypes()) {
/* 106 */       this.mimeType2Data.put(DataFlavorUtils.getMimeType(dataFormat), 
/* 107 */           paramBoolean ? paramClipboard.getContent(dataFormat) : null);
/*     */     }
/*     */   }
/*     */   
/*     */   public Object getData(String paramString) {
/* 112 */     return this.mimeType2Data.get(paramString);
/*     */   }
/*     */   
/*     */   public String[] getMimeTypes() {
/* 116 */     return (String[])this.mimeType2Data.keySet().toArray((Object[])new String[0]);
/*     */   }
/*     */   
/*     */   public boolean isMimeTypeAvailable(String paramString) {
/* 120 */     return Arrays.<String>asList(getMimeTypes()).contains(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\CachingTransferable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */