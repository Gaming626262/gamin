/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.scene.input.DataFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DataFlavorUtils
/*     */ {
/*     */   static String getFxMimeType(DataFlavor paramDataFlavor) {
/*  50 */     return paramDataFlavor.getPrimaryType() + "/" + paramDataFlavor.getPrimaryType();
/*     */   }
/*     */   
/*     */   static DataFlavor[] getDataFlavors(String[] paramArrayOfString) {
/*  54 */     ArrayList<DataFlavor> arrayList = new ArrayList(paramArrayOfString.length);
/*     */     
/*  56 */     for (String str : paramArrayOfString) {
/*  57 */       DataFlavor dataFlavor = null;
/*     */       try {
/*  59 */         dataFlavor = new DataFlavor(str);
/*  60 */       } catch (ClassNotFoundException|IllegalArgumentException classNotFoundException) {}
/*     */ 
/*     */       
/*  63 */       arrayList.add(dataFlavor);
/*     */     } 
/*  65 */     return arrayList.<DataFlavor>toArray(new DataFlavor[0]);
/*     */   }
/*     */   
/*     */   static DataFlavor getDataFlavor(DataFormat paramDataFormat) {
/*  69 */     DataFlavor[] arrayOfDataFlavor = getDataFlavors((String[])paramDataFormat.getIdentifiers().toArray((Object[])new String[1]));
/*     */ 
/*     */     
/*  72 */     return (arrayOfDataFlavor.length == 0) ? null : arrayOfDataFlavor[0];
/*     */   }
/*     */ 
/*     */   
/*     */   static String getMimeType(DataFormat paramDataFormat) {
/*  77 */     Iterator<String> iterator = paramDataFormat.getIdentifiers().iterator(); if (iterator.hasNext()) return iterator.next(); 
/*  78 */     return null;
/*     */   }
/*     */   
/*     */   static DataFormat getDataFormat(DataFlavor paramDataFlavor) {
/*  82 */     String str = getFxMimeType(paramDataFlavor);
/*  83 */     DataFormat dataFormat = DataFormat.lookupMimeType(str);
/*  84 */     if (dataFormat == null) {
/*  85 */       dataFormat = new DataFormat(new String[] { str });
/*     */     }
/*  87 */     return dataFormat;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ByteBufferInputStream
/*     */     extends InputStream
/*     */   {
/*     */     private final ByteBuffer bb;
/*     */ 
/*     */     
/*     */     private ByteBufferInputStream(ByteBuffer param1ByteBuffer) {
/*  98 */       this.bb = param1ByteBuffer;
/*     */     } public int available() {
/* 100 */       return this.bb.remaining();
/*     */     }
/*     */     public int read() throws IOException {
/* 103 */       if (!this.bb.hasRemaining()) return -1; 
/* 104 */       return this.bb.get() & 0xFF;
/*     */     }
/*     */     
/*     */     public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 108 */       if (!this.bb.hasRemaining()) return -1; 
/* 109 */       param1Int2 = Math.min(param1Int2, this.bb.remaining());
/* 110 */       this.bb.get(param1ArrayOfbyte, param1Int1, param1Int2);
/* 111 */       return param1Int2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object adjustFxData(DataFlavor paramDataFlavor, Object paramObject) throws UnsupportedEncodingException {
/* 119 */     if (paramObject instanceof String) {
/* 120 */       if (paramDataFlavor.isRepresentationClassInputStream()) {
/* 121 */         String str = paramDataFlavor.getParameter("charset");
/* 122 */         return new ByteArrayInputStream((str != null) ? (
/* 123 */             (String)paramObject).getBytes(str) : (
/* 124 */             (String)paramObject).getBytes());
/*     */       } 
/* 126 */       if (paramDataFlavor.isRepresentationClassByteBuffer());
/*     */     } 
/*     */ 
/*     */     
/* 130 */     if (paramObject instanceof ByteBuffer && 
/* 131 */       paramDataFlavor.isRepresentationClassInputStream()) {
/* 132 */       return new ByteBufferInputStream((ByteBuffer)paramObject);
/*     */     }
/*     */     
/* 135 */     return paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object adjustSwingData(DataFlavor paramDataFlavor, String paramString, Object paramObject) {
/* 142 */     if (paramObject == null) {
/* 143 */       return paramObject;
/*     */     }
/*     */     
/* 146 */     if (paramDataFlavor.isFlavorJavaFileListType()) {
/*     */       
/* 148 */       List list = (List)paramObject;
/* 149 */       String[] arrayOfString = new String[list.size()];
/* 150 */       byte b = 0;
/* 151 */       for (File file : list) {
/* 152 */         arrayOfString[b++] = file.getPath();
/*     */       }
/* 154 */       return arrayOfString;
/*     */     } 
/* 156 */     DataFormat dataFormat = DataFormat.lookupMimeType(paramString);
/* 157 */     if (DataFormat.PLAIN_TEXT.equals(dataFormat)) {
/* 158 */       if (paramDataFlavor.isFlavorTextType()) {
/* 159 */         if (paramObject instanceof InputStream) {
/* 160 */           InputStream inputStream = (InputStream)paramObject;
/*     */           
/* 162 */           ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 163 */           byte[] arrayOfByte = new byte[64];
/*     */           try {
/* 165 */             int i = inputStream.read(arrayOfByte);
/* 166 */             while (i != -1) {
/* 167 */               byteArrayOutputStream.write(arrayOfByte, 0, i);
/* 168 */               i = inputStream.read(arrayOfByte);
/*     */             } 
/* 170 */             byteArrayOutputStream.close();
/* 171 */             return new String(byteArrayOutputStream.toByteArray());
/* 172 */           } catch (Exception exception) {}
/*     */         }
/*     */       
/*     */       }
/* 176 */       else if (paramObject != null) {
/* 177 */         return paramObject.toString();
/*     */       } 
/*     */     }
/* 180 */     return paramObject;
/*     */   }
/*     */ 
/*     */   
/*     */   static Map<String, DataFlavor> adjustSwingDataFlavors(DataFlavor[] paramArrayOfDataFlavor) {
/* 185 */     HashMap<Object, Object> hashMap1 = new HashMap<>(paramArrayOfDataFlavor.length);
/*     */     
/* 187 */     for (DataFlavor dataFlavor : paramArrayOfDataFlavor) {
/* 188 */       String str = getFxMimeType(dataFlavor);
/* 189 */       if (hashMap1.containsKey(str)) {
/* 190 */         Set<DataFlavor> set = (Set)hashMap1.get(str);
/*     */         
/*     */         try {
/* 193 */           set.add(dataFlavor);
/* 194 */         } catch (UnsupportedOperationException unsupportedOperationException) {}
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 199 */         Set<DataFlavor> set = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 204 */         if (dataFlavor.isFlavorTextType()) {
/* 205 */           set.add(DataFlavor.stringFlavor);
/* 206 */           set = Collections.unmodifiableSet(set);
/*     */         } else {
/*     */           
/* 209 */           set.add(dataFlavor);
/*     */         } 
/*     */         
/* 212 */         hashMap1.put(str, set);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 217 */     HashMap<Object, Object> hashMap2 = new HashMap<>();
/* 218 */     for (String str : hashMap1.keySet()) {
/*     */       
/* 220 */       DataFlavor[] arrayOfDataFlavor = (DataFlavor[])((Set)hashMap1.get(str)).toArray((Object[])new DataFlavor[0]);
/* 221 */       if (arrayOfDataFlavor.length == 1) {
/* 222 */         hashMap2.put(str, arrayOfDataFlavor[0]);
/*     */         continue;
/*     */       } 
/* 225 */       hashMap2.put(str, arrayOfDataFlavor[0]);
/*     */     } 
/*     */ 
/*     */     
/* 229 */     return (Map)hashMap2;
/*     */   }
/*     */   
/*     */   private static Object readData(Transferable paramTransferable, DataFlavor paramDataFlavor) {
/* 233 */     Object object = null;
/*     */     try {
/* 235 */       object = paramTransferable.getTransferData(paramDataFlavor);
/* 236 */     } catch (UnsupportedFlavorException unsupportedFlavorException) {
/*     */       
/* 238 */       unsupportedFlavorException.printStackTrace(System.err);
/* 239 */     } catch (IOException iOException) {
/*     */       
/* 241 */       iOException.printStackTrace(System.err);
/*     */     } 
/* 243 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Map<String, Object> readAllData(Transferable paramTransferable, Map<String, DataFlavor> paramMap, boolean paramBoolean) {
/* 256 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 257 */     for (DataFlavor dataFlavor : paramTransferable.getTransferDataFlavors()) {
/* 258 */       Object object = paramBoolean ? readData(paramTransferable, dataFlavor) : null;
/* 259 */       if (object != null || !paramBoolean) {
/* 260 */         String str = getFxMimeType(dataFlavor);
/* 261 */         object = adjustSwingData(dataFlavor, str, object);
/* 262 */         hashMap.put(str, object);
/*     */       } 
/*     */     } 
/* 265 */     for (Map.Entry<String, DataFlavor> entry : paramMap.entrySet()) {
/* 266 */       String str = (String)entry.getKey();
/* 267 */       DataFlavor dataFlavor = (DataFlavor)entry.getValue();
/* 268 */       Object object = paramBoolean ? readData(paramTransferable, dataFlavor) : null;
/* 269 */       if (object != null || !paramBoolean) {
/* 270 */         object = adjustSwingData(dataFlavor, str, object);
/* 271 */         hashMap.put(entry.getKey(), object);
/*     */       } 
/*     */     } 
/* 274 */     return (Map)hashMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\DataFlavorUtils.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */