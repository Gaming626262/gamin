/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Disposer
/*     */   implements Runnable
/*     */ {
/*  47 */   private static final ReferenceQueue queue = new ReferenceQueue();
/*  48 */   private static final Hashtable records = new Hashtable<>();
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static Disposer disposerInstance = new Disposer();
/*     */   static {
/*  54 */     ThreadGroup threadGroup = Thread.currentThread().getThreadGroup();
/*     */     
/*  56 */     Object object = AccessController.doPrivileged(new PrivilegedAction<Object>()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public Object run()
/*     */           {
/*  63 */             ThreadGroup threadGroup1 = Thread.currentThread().getThreadGroup();
/*  64 */             ThreadGroup threadGroup2 = threadGroup1;
/*  65 */             while (threadGroup2 != null) {
/*  66 */               threadGroup1 = threadGroup2; threadGroup2 = threadGroup1.getParent();
/*  67 */             }  Thread thread = new Thread(threadGroup1, Disposer.disposerInstance, "SwingNode Disposer");
/*     */             
/*  69 */             thread.setContextClassLoader(null);
/*  70 */             thread.setDaemon(true);
/*  71 */             thread.setPriority(10);
/*  72 */             thread.start();
/*  73 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WeakReference addRecord(Object paramObject, DisposerRecord paramDisposerRecord) {
/*  86 */     WeakReference weakReference = new WeakReference(paramObject, queue);
/*  87 */     records.put(weakReference, paramDisposerRecord);
/*  88 */     return weakReference;
/*     */   }
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/*     */         while (true)
/*  94 */         { Reference reference = queue.remove();
/*  95 */           reference.clear();
/*  96 */           DisposerRecord disposerRecord = (DisposerRecord)records.remove(reference);
/*  97 */           disposerRecord.dispose();
/*  98 */           reference = null;
/*  99 */           disposerRecord = null; }  break;
/* 100 */       } catch (Exception exception) {
/* 101 */         System.out.println("Exception while removing reference: " + exception);
/* 102 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\Disposer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */