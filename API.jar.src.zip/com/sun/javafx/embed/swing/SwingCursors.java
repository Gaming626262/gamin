/*     */ package com.sun.javafx.embed.swing;
/*     */ 
/*     */ import com.sun.javafx.cursor.CursorFrame;
/*     */ import com.sun.javafx.cursor.CursorType;
/*     */ import com.sun.javafx.cursor.ImageCursorFrame;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javafx.embed.swing.SwingFXUtils;
/*     */ import javafx.scene.Cursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingCursors
/*     */ {
/*     */   private static Cursor createCustomCursor(ImageCursorFrame paramImageCursorFrame) {
/*  45 */     Toolkit toolkit = Toolkit.getDefaultToolkit();
/*     */     
/*  47 */     double d1 = paramImageCursorFrame.getWidth();
/*  48 */     double d2 = paramImageCursorFrame.getHeight();
/*  49 */     Dimension dimension = toolkit.getBestCursorSize((int)d1, (int)d2);
/*     */     
/*  51 */     double d3 = paramImageCursorFrame.getHotspotX() * dimension.getWidth() / d1;
/*  52 */     double d4 = paramImageCursorFrame.getHotspotY() * dimension.getHeight() / d2;
/*  53 */     Point point = new Point((int)d3, (int)d4);
/*     */     
/*  55 */     BufferedImage bufferedImage = SwingFXUtils.fromFXImage(
/*  56 */         Toolkit.getImageAccessor().fromPlatformImage(paramImageCursorFrame.getPlatformImage()), null);
/*  57 */     return toolkit.createCustomCursor(bufferedImage, point, null);
/*     */   }
/*     */   
/*     */   public static Cursor embedCursorToCursor(CursorFrame paramCursorFrame) {
/*  61 */     switch (paramCursorFrame.getCursorType()) {
/*     */       case DEFAULT:
/*  63 */         return Cursor.getPredefinedCursor(0);
/*     */       case CROSSHAIR:
/*  65 */         return Cursor.getPredefinedCursor(1);
/*     */       case TEXT:
/*  67 */         return Cursor.getPredefinedCursor(2);
/*     */       case WAIT:
/*  69 */         return Cursor.getPredefinedCursor(3);
/*     */       case SW_RESIZE:
/*  71 */         return Cursor.getPredefinedCursor(4);
/*     */       case SE_RESIZE:
/*  73 */         return Cursor.getPredefinedCursor(5);
/*     */       case NW_RESIZE:
/*  75 */         return Cursor.getPredefinedCursor(6);
/*     */       case NE_RESIZE:
/*  77 */         return Cursor.getPredefinedCursor(7);
/*     */       case N_RESIZE:
/*     */       case V_RESIZE:
/*  80 */         return Cursor.getPredefinedCursor(8);
/*     */       case S_RESIZE:
/*  82 */         return Cursor.getPredefinedCursor(9);
/*     */       case W_RESIZE:
/*     */       case H_RESIZE:
/*  85 */         return Cursor.getPredefinedCursor(10);
/*     */       case E_RESIZE:
/*  87 */         return Cursor.getPredefinedCursor(11);
/*     */       case OPEN_HAND:
/*     */       case CLOSED_HAND:
/*     */       case HAND:
/*  91 */         return Cursor.getPredefinedCursor(12);
/*     */       case MOVE:
/*  93 */         return Cursor.getPredefinedCursor(13);
/*     */       
/*     */       case DISAPPEAR:
/*  96 */         return Cursor.getPredefinedCursor(0);
/*     */       case NONE:
/*  98 */         return null;
/*     */       case IMAGE:
/* 100 */         return createCustomCursor((ImageCursorFrame)paramCursorFrame);
/*     */     } 
/*     */     
/* 103 */     return Cursor.getPredefinedCursor(0);
/*     */   }
/*     */   
/*     */   public static Cursor embedCursorToCursor(Cursor paramCursor) {
/* 107 */     if (paramCursor == null) {
/* 108 */       return Cursor.DEFAULT;
/*     */     }
/*     */     
/* 111 */     switch (paramCursor.getType()) {
/*     */       case 0:
/* 113 */         return Cursor.DEFAULT;
/*     */       case 1:
/* 115 */         return Cursor.CROSSHAIR;
/*     */       case 11:
/* 117 */         return Cursor.E_RESIZE;
/*     */       case 12:
/* 119 */         return Cursor.HAND;
/*     */       case 13:
/* 121 */         return Cursor.MOVE;
/*     */       case 8:
/* 123 */         return Cursor.N_RESIZE;
/*     */       case 7:
/* 125 */         return Cursor.NE_RESIZE;
/*     */       case 6:
/* 127 */         return Cursor.NW_RESIZE;
/*     */       case 9:
/* 129 */         return Cursor.S_RESIZE;
/*     */       case 5:
/* 131 */         return Cursor.SE_RESIZE;
/*     */       case 4:
/* 133 */         return Cursor.SW_RESIZE;
/*     */       case 2:
/* 135 */         return Cursor.TEXT;
/*     */       case 10:
/* 137 */         return Cursor.W_RESIZE;
/*     */       case 3:
/* 139 */         return Cursor.WAIT;
/*     */     } 
/* 141 */     return Cursor.DEFAULT;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\SwingCursors.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */