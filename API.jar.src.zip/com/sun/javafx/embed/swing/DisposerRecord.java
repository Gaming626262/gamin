package com.sun.javafx.embed.swing;

public interface DisposerRecord {
  void dispose();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\swing\DisposerRecord.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */