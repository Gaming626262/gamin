/*     */ package com.sun.javafx.embed;
/*     */ 
/*     */ import com.sun.javafx.tk.FocusCause;
/*     */ import javafx.event.EventType;
/*     */ import javafx.scene.input.KeyEvent;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.input.RotateEvent;
/*     */ import javafx.scene.input.ScrollEvent;
/*     */ import javafx.scene.input.SwipeEvent;
/*     */ import javafx.scene.input.ZoomEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractEvents
/*     */ {
/*     */   public static final int MOUSEEVENT_PRESSED = 0;
/*     */   public static final int MOUSEEVENT_RELEASED = 1;
/*     */   public static final int MOUSEEVENT_CLICKED = 2;
/*     */   public static final int MOUSEEVENT_ENTERED = 3;
/*     */   public static final int MOUSEEVENT_EXITED = 4;
/*     */   public static final int MOUSEEVENT_MOVED = 5;
/*     */   public static final int MOUSEEVENT_DRAGGED = 6;
/*     */   public static final int MOUSEEVENT_VERTICAL_WHEEL = 7;
/*     */   public static final int MOUSEEVENT_HORIZONTAL_WHEEL = 8;
/*     */   public static final int MOUSEEVENT_NONE_BUTTON = 0;
/*     */   public static final int MOUSEEVENT_PRIMARY_BUTTON = 1;
/*     */   public static final int MOUSEEVENT_SECONDARY_BUTTON = 2;
/*     */   public static final int MOUSEEVENT_MIDDLE_BUTTON = 4;
/*     */   public static final int MOUSEEVENT_BACK_BUTTON = 8;
/*     */   public static final int MOUSEEVENT_FORWARD_BUTTON = 16;
/*     */   public static final int KEYEVENT_PRESSED = 0;
/*     */   public static final int KEYEVENT_RELEASED = 1;
/*     */   public static final int KEYEVENT_TYPED = 2;
/*     */   public static final int ZOOMEVENT_STARTED = 0;
/*     */   public static final int ZOOMEVENT_ZOOM = 1;
/*     */   public static final int ZOOMEVENT_FINISHED = 2;
/*     */   public static final int ROTATEEVENT_STARTED = 0;
/*     */   public static final int ROTATEEVENT_ROTATE = 1;
/*     */   public static final int ROTATEEVENT_FINISHED = 2;
/*     */   public static final int SCROLLEVENT_STARTED = 0;
/*     */   public static final int SCROLLEVENT_SCROLL = 1;
/*     */   public static final int SCROLLEVENT_FINISHED = 2;
/*     */   public static final int SWIPEEVENT_DOWN = 0;
/*     */   public static final int SWIPEEVENT_UP = 1;
/*     */   public static final int SWIPEEVENT_LEFT = 2;
/*     */   public static final int SWIPEEVENT_RIGHT = 3;
/*     */   public static final int FOCUSEVENT_ACTIVATED = 0;
/*     */   public static final int FOCUSEVENT_TRAVERSED_FORWARD = 1;
/*     */   public static final int FOCUSEVENT_TRAVERSED_BACKWARD = 2;
/*     */   public static final int FOCUSEVENT_DEACTIVATED = 3;
/*     */   public static final int MODIFIER_SHIFT = 1;
/*     */   public static final int MODIFIER_CONTROL = 2;
/*     */   public static final int MODIFIER_ALT = 4;
/*     */   public static final int MODIFIER_META = 8;
/*     */   
/*     */   public static EventType<MouseEvent> mouseIDToFXEventID(int paramInt) {
/*  95 */     switch (paramInt) {
/*     */       case 0:
/*  97 */         return MouseEvent.MOUSE_PRESSED;
/*     */       case 1:
/*  99 */         return MouseEvent.MOUSE_RELEASED;
/*     */       case 2:
/* 101 */         return MouseEvent.MOUSE_CLICKED;
/*     */       case 3:
/* 103 */         return MouseEvent.MOUSE_ENTERED;
/*     */       case 4:
/* 105 */         return MouseEvent.MOUSE_EXITED;
/*     */       case 5:
/* 107 */         return MouseEvent.MOUSE_MOVED;
/*     */       case 6:
/* 109 */         return MouseEvent.MOUSE_DRAGGED;
/*     */     } 
/*     */     
/* 112 */     return MouseEvent.MOUSE_MOVED;
/*     */   }
/*     */   
/*     */   public static MouseButton mouseButtonToFXMouseButton(int paramInt) {
/* 116 */     switch (paramInt) {
/*     */       case 1:
/* 118 */         return MouseButton.PRIMARY;
/*     */       case 2:
/* 120 */         return MouseButton.SECONDARY;
/*     */       case 4:
/* 122 */         return MouseButton.MIDDLE;
/*     */       case 8:
/* 124 */         return MouseButton.BACK;
/*     */       case 16:
/* 126 */         return MouseButton.FORWARD;
/*     */     } 
/*     */     
/* 129 */     return MouseButton.NONE;
/*     */   }
/*     */   
/*     */   public static EventType<KeyEvent> keyIDToFXEventType(int paramInt) {
/* 133 */     switch (paramInt) {
/*     */       case 0:
/* 135 */         return KeyEvent.KEY_PRESSED;
/*     */       case 1:
/* 137 */         return KeyEvent.KEY_RELEASED;
/*     */       case 2:
/* 139 */         return KeyEvent.KEY_TYPED;
/*     */     } 
/*     */     
/* 142 */     return KeyEvent.KEY_TYPED;
/*     */   }
/*     */   
/*     */   public static EventType<ZoomEvent> zoomIDToFXEventType(int paramInt) {
/* 146 */     switch (paramInt) {
/*     */       case 0:
/* 148 */         return ZoomEvent.ZOOM_STARTED;
/*     */       case 1:
/* 150 */         return ZoomEvent.ZOOM;
/*     */       case 2:
/* 152 */         return ZoomEvent.ZOOM_FINISHED;
/*     */     } 
/*     */     
/* 155 */     return ZoomEvent.ZOOM;
/*     */   }
/*     */   
/*     */   public static EventType<RotateEvent> rotateIDToFXEventType(int paramInt) {
/* 159 */     switch (paramInt) {
/*     */       case 0:
/* 161 */         return RotateEvent.ROTATION_STARTED;
/*     */       case 1:
/* 163 */         return RotateEvent.ROTATE;
/*     */       case 2:
/* 165 */         return RotateEvent.ROTATION_FINISHED;
/*     */     } 
/*     */     
/* 168 */     return RotateEvent.ROTATE;
/*     */   }
/*     */   
/*     */   public static EventType<SwipeEvent> swipeIDToFXEventType(int paramInt) {
/* 172 */     switch (paramInt) {
/*     */       case 1:
/* 174 */         return SwipeEvent.SWIPE_UP;
/*     */       case 0:
/* 176 */         return SwipeEvent.SWIPE_DOWN;
/*     */       case 2:
/* 178 */         return SwipeEvent.SWIPE_LEFT;
/*     */       case 3:
/* 180 */         return SwipeEvent.SWIPE_RIGHT;
/*     */     } 
/*     */     
/* 183 */     return SwipeEvent.SWIPE_DOWN;
/*     */   }
/*     */   
/*     */   public static EventType<ScrollEvent> scrollIDToFXEventType(int paramInt) {
/* 187 */     switch (paramInt) {
/*     */       case 0:
/* 189 */         return ScrollEvent.SCROLL_STARTED;
/*     */       case 2:
/* 191 */         return ScrollEvent.SCROLL_FINISHED;
/*     */       case 1:
/*     */       case 7:
/*     */       case 8:
/* 195 */         return ScrollEvent.SCROLL;
/*     */     } 
/*     */     
/* 198 */     return ScrollEvent.SCROLL;
/*     */   }
/*     */   
/*     */   public static FocusCause focusCauseToPeerFocusCause(int paramInt) {
/* 202 */     switch (paramInt) {
/*     */       case 0:
/* 204 */         return FocusCause.ACTIVATED;
/*     */       case 1:
/* 206 */         return FocusCause.TRAVERSED_FORWARD;
/*     */       case 2:
/* 208 */         return FocusCause.TRAVERSED_BACKWARD;
/*     */       case 3:
/* 210 */         return FocusCause.DEACTIVATED;
/*     */     } 
/*     */     
/* 213 */     return FocusCause.ACTIVATED;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\embed\AbstractEvents.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */