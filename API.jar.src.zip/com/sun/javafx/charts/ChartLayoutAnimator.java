/*     */ package com.sun.javafx.charts;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javafx.animation.Animation;
/*     */ import javafx.animation.AnimationTimer;
/*     */ import javafx.animation.KeyFrame;
/*     */ import javafx.animation.SequentialTransition;
/*     */ import javafx.animation.Timeline;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.chart.Axis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ChartLayoutAnimator
/*     */   extends AnimationTimer
/*     */   implements EventHandler<ActionEvent>
/*     */ {
/*     */   private Parent nodeToLayout;
/*  47 */   private final Map<Object, Animation> activeTimeLines = new HashMap<>();
/*     */   private final boolean isAxis;
/*     */   
/*     */   public ChartLayoutAnimator(Parent paramParent) {
/*  51 */     this.nodeToLayout = paramParent;
/*  52 */     this.isAxis = paramParent instanceof Axis;
/*     */   }
/*     */   
/*     */   public void handle(long paramLong) {
/*  56 */     if (this.isAxis) {
/*  57 */       ((Axis)this.nodeToLayout).requestAxisLayout();
/*     */     } else {
/*  59 */       this.nodeToLayout.requestLayout();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handle(ActionEvent paramActionEvent) {
/*  64 */     this.activeTimeLines.remove(paramActionEvent.getSource());
/*  65 */     if (this.activeTimeLines.isEmpty()) stop();
/*     */     
/*  67 */     handle(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(Object paramObject) {
/*  76 */     Animation animation = this.activeTimeLines.remove(paramObject);
/*  77 */     if (animation != null) animation.stop(); 
/*  78 */     if (this.activeTimeLines.isEmpty()) stop();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object animate(KeyFrame... paramVarArgs) {
/*  88 */     Timeline timeline = new Timeline();
/*  89 */     timeline.setAutoReverse(false);
/*  90 */     timeline.setCycleCount(1);
/*  91 */     timeline.getKeyFrames().addAll((Object[])paramVarArgs);
/*  92 */     timeline.setOnFinished(this);
/*     */     
/*  94 */     if (this.activeTimeLines.isEmpty()) start();
/*     */     
/*  96 */     this.activeTimeLines.put(timeline, timeline);
/*     */     
/*  98 */     timeline.play();
/*  99 */     return timeline;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object animate(Animation paramAnimation) {
/* 109 */     SequentialTransition sequentialTransition = new SequentialTransition();
/* 110 */     sequentialTransition.getChildren().add(paramAnimation);
/* 111 */     sequentialTransition.setOnFinished(this);
/*     */     
/* 113 */     if (this.activeTimeLines.isEmpty()) start();
/*     */     
/* 115 */     this.activeTimeLines.put(sequentialTransition, sequentialTransition);
/*     */     
/* 117 */     sequentialTransition.play();
/* 118 */     return sequentialTransition;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\charts\ChartLayoutAnimator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */