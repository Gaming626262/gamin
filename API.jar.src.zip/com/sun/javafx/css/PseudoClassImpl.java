/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ import javafx.css.PseudoClass;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PseudoClassImpl
/*    */   extends PseudoClass
/*    */ {
/*    */   private final String pseudoClassName;
/*    */   private final int index;
/*    */   
/*    */   PseudoClassImpl(String paramString, int paramInt) {
/* 42 */     this.pseudoClassName = paramString;
/* 43 */     this.index = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getPseudoClassName() {
/* 52 */     return this.pseudoClassName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     return this.pseudoClassName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getIndex() {
/* 68 */     return this.index;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\PseudoClassImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */