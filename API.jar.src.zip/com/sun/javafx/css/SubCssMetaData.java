/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ import javafx.css.CssMetaData;
/*    */ import javafx.css.StyleConverter;
/*    */ import javafx.css.Styleable;
/*    */ import javafx.css.StyleableProperty;
/*    */ import javafx.scene.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubCssMetaData<T>
/*    */   extends CssMetaData<Node, T>
/*    */ {
/*    */   public SubCssMetaData(String paramString, StyleConverter paramStyleConverter, T paramT) {
/* 38 */     super(paramString, paramStyleConverter, paramT);
/*    */   }
/*    */   
/*    */   public SubCssMetaData(String paramString, StyleConverter paramStyleConverter) {
/* 42 */     super(paramString, paramStyleConverter);
/*    */   }
/*    */   
/* 45 */   public boolean isSettable(Node paramNode) { return false; } public StyleableProperty<T> getStyleableProperty(Node paramNode) {
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\SubCssMetaData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */