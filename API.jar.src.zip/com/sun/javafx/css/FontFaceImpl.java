/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.css.FontFace;
/*     */ import javafx.css.StyleConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontFaceImpl
/*     */   extends FontFace
/*     */ {
/*     */   private final Map<String, String> descriptors;
/*     */   private final List<FontFaceSrc> sources;
/*     */   
/*     */   public enum FontFaceSrcType
/*     */   {
/*  44 */     URL, LOCAL, REFERENCE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FontFaceImpl(Map<String, String> paramMap, List<FontFaceSrc> paramList) {
/*  50 */     this.descriptors = paramMap;
/*  51 */     this.sources = paramList;
/*     */   }
/*     */   
/*     */   public Map<String, String> getDescriptors() {
/*  55 */     return this.descriptors;
/*     */   }
/*     */   
/*     */   public List<FontFaceSrc> getSources() {
/*  59 */     return this.sources;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  63 */     StringBuilder stringBuilder = new StringBuilder("@font-face { ");
/*  64 */     for (Map.Entry<String, String> entry : this.descriptors.entrySet()) {
/*  65 */       stringBuilder.append((String)entry.getKey());
/*  66 */       stringBuilder.append(" : ");
/*  67 */       stringBuilder.append((String)entry.getValue());
/*  68 */       stringBuilder.append("; ");
/*     */     } 
/*  70 */     stringBuilder.append("src : ");
/*  71 */     for (FontFaceSrc fontFaceSrc : this.sources) {
/*  72 */       stringBuilder.append(fontFaceSrc.getType());
/*  73 */       stringBuilder.append(" \"");
/*  74 */       stringBuilder.append(fontFaceSrc.getSrc());
/*  75 */       stringBuilder.append("\", ");
/*     */     } 
/*  77 */     stringBuilder.append("; ");
/*  78 */     stringBuilder.append(" }");
/*  79 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public final void writeBinary(DataOutputStream paramDataOutputStream, StyleConverter.StringStore paramStringStore) throws IOException {
/*  84 */     Set<Map.Entry<K, V>> set = (getDescriptors() != null) ? (Set)getDescriptors().entrySet() : null;
/*  85 */     byte b1 = (set != null) ? set.size() : 0;
/*  86 */     paramDataOutputStream.writeShort(b1);
/*  87 */     if (set != null) {
/*  88 */       for (Map.Entry<K, V> entry : set) {
/*  89 */         int i = paramStringStore.addString((String)entry.getKey());
/*  90 */         paramDataOutputStream.writeInt(i);
/*  91 */         i = paramStringStore.addString((String)entry.getValue());
/*  92 */         paramDataOutputStream.writeInt(i);
/*     */       } 
/*     */     }
/*     */     
/*  96 */     List<FontFaceSrc> list = getSources();
/*  97 */     b1 = (list != null) ? list.size() : 0;
/*  98 */     paramDataOutputStream.writeShort(b1);
/*  99 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 100 */       FontFaceSrc fontFaceSrc = list.get(b2);
/* 101 */       fontFaceSrc.writeBinary(paramDataOutputStream, paramStringStore);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final FontFaceImpl readBinary(int paramInt, DataInputStream paramDataInputStream, String[] paramArrayOfString) throws IOException {
/* 108 */     short s = paramDataInputStream.readShort();
/* 109 */     HashMap<Object, Object> hashMap = new HashMap<>(s);
/* 110 */     for (byte b1 = 0; b1 < s; b1++) {
/* 111 */       int i = paramDataInputStream.readInt();
/* 112 */       String str1 = paramArrayOfString[i];
/* 113 */       i = paramDataInputStream.readInt();
/* 114 */       String str2 = paramArrayOfString[i];
/* 115 */       hashMap.put(str1, str2);
/*     */     } 
/*     */     
/* 118 */     s = paramDataInputStream.readShort();
/* 119 */     ArrayList<FontFaceSrc> arrayList = new ArrayList(s);
/* 120 */     for (byte b2 = 0; b2 < s; b2++) {
/* 121 */       FontFaceSrc fontFaceSrc = FontFaceSrc.readBinary(paramInt, paramDataInputStream, paramArrayOfString);
/* 122 */       arrayList.add(fontFaceSrc);
/*     */     } 
/*     */     
/* 125 */     return new FontFaceImpl((Map)hashMap, arrayList);
/*     */   }
/*     */   
/*     */   public static class FontFaceSrc {
/*     */     private final FontFaceImpl.FontFaceSrcType type;
/*     */     private final String src;
/*     */     private final String format;
/*     */     
/*     */     public FontFaceSrc(FontFaceImpl.FontFaceSrcType param1FontFaceSrcType, String param1String1, String param1String2) {
/* 134 */       this.type = param1FontFaceSrcType;
/* 135 */       this.src = param1String1;
/* 136 */       this.format = param1String2;
/*     */     }
/*     */     
/*     */     public FontFaceSrc(FontFaceImpl.FontFaceSrcType param1FontFaceSrcType, String param1String) {
/* 140 */       this.type = param1FontFaceSrcType;
/* 141 */       this.src = param1String;
/* 142 */       this.format = null;
/*     */     }
/*     */     
/*     */     public FontFaceImpl.FontFaceSrcType getType() {
/* 146 */       return this.type;
/*     */     }
/*     */     
/*     */     public String getSrc() {
/* 150 */       return this.src;
/*     */     }
/*     */     
/*     */     public String getFormat() {
/* 154 */       return this.format;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     final void writeBinary(DataOutputStream param1DataOutputStream, StyleConverter.StringStore param1StringStore) throws IOException {
/* 160 */       param1DataOutputStream.writeInt(param1StringStore.addString(this.type.name()));
/* 161 */       param1DataOutputStream.writeInt(param1StringStore.addString(this.src));
/* 162 */       param1DataOutputStream.writeInt(param1StringStore.addString(this.format));
/*     */     }
/*     */ 
/*     */     
/*     */     static final FontFaceSrc readBinary(int param1Int, DataInputStream param1DataInputStream, String[] param1ArrayOfString) throws IOException {
/* 167 */       int i = param1DataInputStream.readInt();
/* 168 */       FontFaceImpl.FontFaceSrcType fontFaceSrcType = (param1ArrayOfString[i] != null) ? FontFaceImpl.FontFaceSrcType.valueOf(param1ArrayOfString[i]) : null;
/*     */       
/* 170 */       i = param1DataInputStream.readInt();
/* 171 */       String str1 = param1ArrayOfString[i];
/*     */       
/* 173 */       i = param1DataInputStream.readInt();
/* 174 */       String str2 = param1ArrayOfString[i];
/*     */       
/* 176 */       return new FontFaceSrc(fontFaceSrcType, str1, str2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\FontFaceImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */