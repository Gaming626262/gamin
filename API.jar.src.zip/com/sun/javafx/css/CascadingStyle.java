/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.Set;
/*     */ import javafx.css.Declaration;
/*     */ import javafx.css.Match;
/*     */ import javafx.css.ParsedValue;
/*     */ import javafx.css.PseudoClass;
/*     */ import javafx.css.Rule;
/*     */ import javafx.css.Selector;
/*     */ import javafx.css.Style;
/*     */ import javafx.css.StyleOrigin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CascadingStyle
/*     */   implements Comparable<CascadingStyle>
/*     */ {
/*     */   private final Style style;
/*     */   private final Set<PseudoClass> pseudoClasses;
/*     */   private final int specificity;
/*     */   private final int ordinal;
/*     */   private final boolean skinProp;
/*     */   
/*     */   public Style getStyle() {
/*  48 */     return this.style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CascadingStyle(Style paramStyle, Set<PseudoClass> paramSet, int paramInt1, int paramInt2) {
/*  68 */     this.style = paramStyle;
/*  69 */     this.pseudoClasses = paramSet;
/*  70 */     this.specificity = paramInt1;
/*  71 */     this.ordinal = paramInt2;
/*  72 */     this.skinProp = "-fx-skin".equals(paramStyle.getDeclaration().getProperty());
/*     */   }
/*     */   
/*     */   public CascadingStyle(Declaration paramDeclaration, Match paramMatch, int paramInt) {
/*  76 */     this(new Style(paramMatch.getSelector(), paramDeclaration), (Set<PseudoClass>)paramMatch
/*  77 */         .getPseudoClasses(), paramMatch
/*  78 */         .getSpecificity(), paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty() {
/*  84 */     return this.style.getDeclaration().getProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Selector getSelector() {
/*  89 */     return this.style.getSelector();
/*     */   }
/*     */ 
/*     */   
/*     */   public Rule getRule() {
/*  94 */     return this.style.getDeclaration().getRule();
/*     */   }
/*     */ 
/*     */   
/*     */   public StyleOrigin getOrigin() {
/*  99 */     return getRule().getOrigin();
/*     */   }
/*     */ 
/*     */   
/*     */   public ParsedValue getParsedValue() {
/* 104 */     return this.style.getDeclaration().getParsedValue();
/*     */   }
/*     */   public String toString() {
/* 107 */     return getProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 115 */     if (paramObject == null) {
/* 116 */       return false;
/*     */     }
/* 118 */     if (getClass() != paramObject.getClass()) {
/* 119 */       return false;
/*     */     }
/* 121 */     CascadingStyle cascadingStyle = (CascadingStyle)paramObject;
/*     */     
/* 123 */     String str1 = getProperty();
/* 124 */     String str2 = cascadingStyle.getProperty();
/* 125 */     if ((str1 == null) ? (str2 != null) : !str1.equals(str2)) {
/* 126 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 130 */     if ((this.pseudoClasses == null) ? (cascadingStyle.pseudoClasses != null) : !this.pseudoClasses.containsAll(cascadingStyle.pseudoClasses)) {
/* 131 */       return false;
/*     */     }
/*     */     
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 143 */     int i = 7;
/* 144 */     String str = getProperty();
/* 145 */     i = 47 * i + ((str != null) ? str.hashCode() : 0);
/* 146 */     i = 47 * i + ((this.pseudoClasses != null) ? this.pseudoClasses.hashCode() : 0);
/* 147 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(CascadingStyle paramCascadingStyle) {
/* 162 */     Declaration declaration1 = this.style.getDeclaration();
/* 163 */     boolean bool1 = (declaration1 != null) ? declaration1.isImportant() : false;
/* 164 */     Rule rule1 = (declaration1 != null) ? declaration1.getRule() : null;
/* 165 */     StyleOrigin styleOrigin1 = (rule1 != null) ? rule1.getOrigin() : null;
/*     */     
/* 167 */     Declaration declaration2 = paramCascadingStyle.style.getDeclaration();
/* 168 */     boolean bool2 = (declaration2 != null) ? declaration2.isImportant() : false;
/* 169 */     Rule rule2 = (declaration2 != null) ? declaration2.getRule() : null;
/* 170 */     StyleOrigin styleOrigin2 = (rule2 != null) ? rule2.getOrigin() : null;
/*     */     
/* 172 */     int i = 0;
/*     */     
/* 174 */     if (this.skinProp && !paramCascadingStyle.skinProp)
/* 175 */     { i = 1; }
/* 176 */     else if (bool1 != bool2)
/* 177 */     { i = bool1 ? -1 : 1; }
/* 178 */     else if (styleOrigin1 != styleOrigin2)
/* 179 */     { if (styleOrigin1 == null) { i = -1; }
/* 180 */       else if (styleOrigin2 == null) { i = 1; }
/* 181 */       else { i = styleOrigin2.compareTo((Enum)styleOrigin1); }
/*     */        }
/* 183 */     else { i = paramCascadingStyle.specificity - this.specificity; }
/*     */ 
/*     */     
/* 186 */     if (i == 0) i = paramCascadingStyle.ordinal - this.ordinal; 
/* 187 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\CascadingStyle.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */