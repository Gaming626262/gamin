/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javafx.css.CompoundSelector;
/*     */ import javafx.css.Selector;
/*     */ import javafx.css.SimpleSelector;
/*     */ import javafx.css.StyleClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SelectorPartitioning
/*     */ {
/*     */   private static final class PartitionKey<K>
/*     */   {
/*     */     private final K key;
/*     */     
/*     */     private PartitionKey(K param1K) {
/*  58 */       this.key = param1K;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*  63 */       if (param1Object == null) {
/*  64 */         return false;
/*     */       }
/*  66 */       if (getClass() != param1Object.getClass()) {
/*  67 */         return false;
/*     */       }
/*  69 */       PartitionKey partitionKey = (PartitionKey)param1Object;
/*  70 */       if (this.key != partitionKey.key && (this.key == null || !this.key.equals(partitionKey.key))) {
/*  71 */         return false;
/*     */       }
/*  73 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  78 */       int i = 7;
/*  79 */       i = 71 * i + ((this.key != null) ? this.key.hashCode() : 0);
/*  80 */       return i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Partition
/*     */   {
/*     */     private final SelectorPartitioning.PartitionKey key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<SelectorPartitioning.PartitionKey, SelectorPartitioning.Slot> slots;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private List<Selector> selectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Partition(SelectorPartitioning.PartitionKey param1PartitionKey) {
/* 111 */       this.key = param1PartitionKey;
/* 112 */       this.slots = new HashMap<>();
/*     */     }
/*     */     
/*     */     private void addSelector(Selector param1Selector) {
/* 116 */       if (this.selectors == null) {
/* 117 */         this.selectors = new ArrayList<>();
/*     */       }
/* 119 */       this.selectors.add(param1Selector);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SelectorPartitioning.Slot partition(SelectorPartitioning.PartitionKey param1PartitionKey, Map<SelectorPartitioning.PartitionKey, Partition> param1Map) {
/* 128 */       SelectorPartitioning.Slot slot = this.slots.get(param1PartitionKey);
/* 129 */       if (slot == null) {
/* 130 */         Partition partition = SelectorPartitioning.getPartition(param1PartitionKey, param1Map);
/* 131 */         slot = new SelectorPartitioning.Slot(partition);
/* 132 */         this.slots.put(param1PartitionKey, slot);
/*     */       } 
/* 134 */       return slot;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Slot
/*     */   {
/*     */     private final SelectorPartitioning.Partition partition;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<SelectorPartitioning.PartitionKey, Slot> referents;
/*     */ 
/*     */     
/*     */     private List<Selector> selectors;
/*     */ 
/*     */ 
/*     */     
/*     */     private Slot(SelectorPartitioning.Partition param1Partition) {
/* 155 */       this.partition = param1Partition;
/* 156 */       this.referents = new HashMap<>();
/*     */     }
/*     */     
/*     */     private void addSelector(Selector param1Selector) {
/* 160 */       if (this.selectors == null) {
/* 161 */         this.selectors = new ArrayList<>();
/*     */       }
/* 163 */       this.selectors.add(param1Selector);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Slot partition(SelectorPartitioning.PartitionKey param1PartitionKey, Map<SelectorPartitioning.PartitionKey, SelectorPartitioning.Partition> param1Map) {
/* 171 */       Slot slot = this.referents.get(param1PartitionKey);
/* 172 */       if (slot == null) {
/*     */         
/* 174 */         SelectorPartitioning.Partition partition = SelectorPartitioning.getPartition(param1PartitionKey, param1Map);
/* 175 */         slot = new Slot(partition);
/* 176 */         this.referents.put(param1PartitionKey, slot);
/*     */       } 
/*     */       
/* 179 */       return slot;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 185 */   private final Map<PartitionKey, Partition> idMap = new HashMap<>();
/*     */ 
/*     */   
/* 188 */   private final Map<PartitionKey, Partition> typeMap = new HashMap<>();
/*     */ 
/*     */   
/* 191 */   private final Map<PartitionKey, Partition> styleClassMap = new HashMap<>();
/*     */   
/*     */   private int ordinal;
/*     */   
/*     */   private static final int ID_BIT = 4;
/*     */   
/*     */   private static final int TYPE_BIT = 2;
/*     */   private static final int STYLECLASS_BIT = 1;
/*     */   
/*     */   public void reset() {
/* 201 */     this.idMap.clear();
/* 202 */     this.typeMap.clear();
/* 203 */     this.styleClassMap.clear();
/* 204 */     this.ordinal = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Partition getPartition(PartitionKey paramPartitionKey, Map<PartitionKey, Partition> paramMap) {
/* 214 */     Partition partition = paramMap.get(paramPartitionKey);
/* 215 */     if (partition == null) {
/* 216 */       partition = new Partition(paramPartitionKey);
/* 217 */       paramMap.put(paramPartitionKey, partition);
/*     */     } 
/* 219 */     return partition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   private static final PartitionKey WILDCARD = new PartitionKey<>("*");
/*     */   
/*     */   private static final Comparator<Selector> COMPARATOR;
/*     */   
/*     */   public void partition(Selector paramSelector) {
/* 234 */     SimpleSelector simpleSelector = null;
/* 235 */     if (paramSelector instanceof CompoundSelector) {
/* 236 */       List<SimpleSelector> list = ((CompoundSelector)paramSelector).getSelectors();
/* 237 */       int j = list.size() - 1;
/* 238 */       simpleSelector = list.get(j);
/*     */     } else {
/* 240 */       simpleSelector = (SimpleSelector)paramSelector;
/*     */     } 
/*     */     
/* 243 */     String str1 = simpleSelector.getId();
/*     */     
/* 245 */     boolean bool1 = (str1 != null && !str1.isEmpty()) ? true : false;
/*     */ 
/*     */     
/* 248 */     PartitionKey partitionKey1 = bool1 ? new PartitionKey<>(str1) : null;
/*     */     
/* 250 */     String str2 = simpleSelector.getName();
/*     */     
/* 252 */     boolean bool2 = (str2 != null && !str2.isEmpty()) ? true : false;
/*     */ 
/*     */     
/* 255 */     PartitionKey partitionKey2 = bool2 ? new PartitionKey<>(str2) : null;
/*     */     
/* 257 */     Set set = simpleSelector.getStyleClassSet();
/*     */     
/* 259 */     boolean bool3 = (set != null && set.size() > 0) ? true : false;
/*     */ 
/*     */     
/* 262 */     PartitionKey partitionKey3 = bool3 ? new PartitionKey<>(set) : null;
/*     */ 
/*     */     
/* 265 */     int i = (bool1 ? 4 : 0) | (bool2 ? 2 : 0) | (bool3 ? 1 : 0);
/*     */     
/* 267 */     Partition partition = null;
/* 268 */     Slot slot = null;
/*     */     
/* 270 */     paramSelector.setOrdinal(this.ordinal++);
/*     */     
/* 272 */     switch (i) {
/*     */       
/*     */       case 6:
/*     */       case 7:
/* 276 */         partition = getPartition(partitionKey1, this.idMap);
/* 277 */         slot = partition.partition(partitionKey2, this.typeMap);
/* 278 */         if ((i & 0x1) == 1) {
/* 279 */           slot = slot.partition(partitionKey3, this.styleClassMap);
/*     */         }
/* 281 */         slot.addSelector(paramSelector);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 287 */         partition = getPartition(partitionKey2, this.typeMap);
/* 288 */         if ((i & 0x1) == 1) {
/* 289 */           slot = partition.partition(partitionKey3, this.styleClassMap);
/* 290 */           slot.addSelector(paramSelector);
/*     */         } else {
/* 292 */           partition.addSelector(paramSelector);
/*     */         } 
/*     */         return;
/*     */     } 
/*     */     assert false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Selector> match(String paramString1, String paramString2, Set<StyleClass> paramSet) {
/* 310 */     boolean bool1 = (paramString1 != null && !paramString1.isEmpty()) ? true : false;
/*     */ 
/*     */     
/* 313 */     PartitionKey partitionKey1 = bool1 ? new PartitionKey<>(paramString1) : null;
/*     */ 
/*     */     
/* 316 */     boolean bool2 = (paramString2 != null && !paramString2.isEmpty()) ? true : false;
/*     */ 
/*     */     
/* 319 */     PartitionKey partitionKey2 = bool2 ? new PartitionKey<>(paramString2) : null;
/*     */ 
/*     */     
/* 322 */     boolean bool3 = (paramSet != null && paramSet.size() > 0) ? true : false;
/*     */ 
/*     */     
/* 325 */     PartitionKey partitionKey3 = bool3 ? new PartitionKey<>(paramSet) : null;
/*     */ 
/*     */     
/* 328 */     int i = (bool1 ? 4 : 0) | (bool2 ? 2 : 0) | (bool3 ? 1 : 0);
/*     */     
/* 330 */     Partition partition = null;
/* 331 */     Slot slot = null;
/* 332 */     ArrayList<Selector> arrayList = new ArrayList();
/*     */     
/* 334 */     while (i != 0) {
/*     */       PartitionKey partitionKey;
/* 336 */       switch (i) {
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 7:
/* 341 */           partition = this.idMap.get(partitionKey1);
/* 342 */           if (partition != null) {
/* 343 */             if (partition.selectors != null) {
/* 344 */               arrayList.addAll(partition.selectors);
/*     */             }
/*     */ 
/*     */             
/* 348 */             PartitionKey partitionKey4 = partitionKey2;
/*     */             do {
/* 350 */               slot = partition.slots.get(partitionKey4);
/* 351 */               if (slot != null) {
/*     */                 
/* 353 */                 if (slot.selectors != null) {
/* 354 */                   arrayList.addAll(slot.selectors);
/*     */                 }
/* 356 */                 if ((i & 0x1) == 1) {
/* 357 */                   Set set = (Set)partitionKey3.key;
/* 358 */                   for (Slot slot1 : slot.referents.values()) {
/* 359 */                     if (slot1.selectors == null || slot1.selectors.isEmpty())
/* 360 */                       continue;  Set<?> set1 = (Set)slot1.partition.key.key;
/* 361 */                     if (set.containsAll(set1)) {
/* 362 */                       arrayList.addAll(slot1.selectors);
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */ 
/*     */               
/* 369 */               partitionKey4 = !WILDCARD.equals(partitionKey4) ? WILDCARD : null;
/*     */             }
/* 371 */             while (partitionKey4 != null);
/*     */           } 
/*     */           
/* 374 */           i -= 4;
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/*     */         case 5:
/* 382 */           i -= 4;
/*     */           continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 3:
/* 391 */           partitionKey = partitionKey2;
/*     */           do {
/* 393 */             partition = this.typeMap.get(partitionKey);
/* 394 */             if (partition != null) {
/* 395 */               if (partition.selectors != null) {
/* 396 */                 arrayList.addAll(partition.selectors);
/*     */               }
/* 398 */               if ((i & 0x1) == 1) {
/* 399 */                 Set set = (Set)partitionKey3.key;
/* 400 */                 for (Slot slot1 : partition.slots.values()) {
/* 401 */                   if (slot1.selectors == null || slot1.selectors.isEmpty())
/* 402 */                     continue;  Set<?> set1 = (Set)slot1.partition.key.key;
/* 403 */                   if (set.containsAll(set1)) {
/* 404 */                     arrayList.addAll(slot1.selectors);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/* 410 */             partitionKey = !WILDCARD.equals(partitionKey) ? WILDCARD : null;
/*     */           }
/* 412 */           while (partitionKey != null);
/*     */           
/* 414 */           i -= 2;
/*     */           continue;
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 420 */           i--;
/*     */           continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       assert false;
/*     */     } 
/* 428 */     Collections.sort(arrayList, COMPARATOR);
/* 429 */     return arrayList;
/*     */   }
/*     */   static {
/* 432 */     COMPARATOR = ((paramSelector1, paramSelector2) -> paramSelector1.getOrdinal() - paramSelector2.getOrdinal());
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\SelectorPartitioning.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */