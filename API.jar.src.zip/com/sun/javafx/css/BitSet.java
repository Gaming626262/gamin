/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import com.sun.javafx.collections.SetListenerHelper;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.collections.SetChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BitSet<T>
/*     */   implements ObservableSet<T>
/*     */ {
/*     */   private SetListenerHelper<T> listenerHelper;
/*  46 */   private long[] bits = EMPTY_SET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  54 */     int i = 0;
/*  55 */     if (this.bits.length > 0) {
/*  56 */       for (byte b = 0; b < this.bits.length; b++) {
/*  57 */         long l = this.bits[b];
/*  58 */         if (l != 0L) {
/*  59 */           i += Long.bitCount(l);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  64 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  71 */     if (this.bits.length > 0) {
/*  72 */       for (byte b = 0; b < this.bits.length; b++) {
/*  73 */         long l = this.bits[b];
/*  74 */         if (l != 0L) {
/*  75 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<T> iterator() {
/*  90 */     return new Iterator<T>() {
/*  91 */         int next = -1;
/*  92 */         int element = 0;
/*  93 */         int index = -1;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/*  97 */           if (BitSet.this.bits == null || BitSet.this.bits.length == 0) {
/*  98 */             return false;
/*     */           }
/*     */           
/* 101 */           boolean bool = false;
/*     */           
/*     */           do {
/* 104 */             if (++this.next >= 64) {
/* 105 */               if (++this.element < BitSet.this.bits.length) {
/* 106 */                 this.next = 0;
/*     */               } else {
/* 108 */                 return false;
/*     */               } 
/*     */             }
/*     */             
/* 112 */             long l = 1L << this.next;
/* 113 */             bool = ((l & BitSet.this.bits[this.element]) == l) ? true : false;
/*     */           }
/* 115 */           while (!bool);
/*     */           
/* 117 */           if (bool) {
/* 118 */             this.index = 64 * this.element + this.next;
/*     */           }
/* 120 */           return bool;
/*     */         }
/*     */ 
/*     */         
/*     */         public T next() {
/*     */           try {
/* 126 */             return BitSet.this.getT(this.index);
/* 127 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 128 */             throw new NoSuchElementException("[" + this.element + "][" + this.next + "]");
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/*     */           try {
/* 135 */             Object object = BitSet.this.getT(this.index);
/* 136 */             BitSet.this.remove(object);
/* 137 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 138 */             throw new NoSuchElementException("[" + this.element + "][" + this.next + "]");
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(T paramT) {
/* 148 */     if (paramT == null)
/*     */     {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     int i = getIndex(paramT) / 64;
/* 154 */     long l1 = 1L << getIndex(paramT) % 64;
/*     */ 
/*     */     
/* 157 */     if (i >= this.bits.length) {
/* 158 */       long[] arrayOfLong = new long[i + 1];
/* 159 */       System.arraycopy(this.bits, 0, arrayOfLong, 0, this.bits.length);
/* 160 */       this.bits = arrayOfLong;
/*     */     } 
/*     */     
/* 163 */     long l2 = this.bits[i];
/* 164 */     this.bits[i] = l2 | l1;
/*     */ 
/*     */     
/* 167 */     boolean bool = (this.bits[i] != l2) ? true : false;
/* 168 */     if (bool && SetListenerHelper.hasListeners(this.listenerHelper)) {
/* 169 */       notifyObservers(paramT, false);
/*     */     }
/* 171 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(Object paramObject) {
/* 178 */     if (paramObject == null)
/*     */     {
/* 180 */       return false;
/*     */     }
/*     */     
/* 183 */     T t = cast(paramObject);
/*     */     
/* 185 */     int i = getIndex(t) / 64;
/* 186 */     long l1 = 1L << getIndex(t) % 64;
/*     */     
/* 188 */     if (i >= this.bits.length)
/*     */     {
/* 190 */       return false;
/*     */     }
/*     */     
/* 193 */     long l2 = this.bits[i];
/* 194 */     this.bits[i] = l2 & (l1 ^ 0xFFFFFFFFFFFFFFFFL);
/*     */ 
/*     */     
/* 197 */     boolean bool = (this.bits[i] != l2) ? true : false;
/* 198 */     if (bool) {
/* 199 */       if (SetListenerHelper.hasListeners(this.listenerHelper)) {
/* 200 */         notifyObservers(t, true);
/*     */       }
/*     */ 
/*     */       
/* 204 */       int j = 1;
/* 205 */       for (byte b = 0; b < this.bits.length && j; b++) {
/* 206 */         j &= (this.bits[b] == 0L) ? 1 : 0;
/*     */       }
/* 208 */       if (j != 0) this.bits = EMPTY_SET; 
/*     */     } 
/* 210 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(Object paramObject) {
/* 217 */     if (paramObject == null) {
/* 218 */       return false;
/*     */     }
/*     */     
/* 221 */     T t = cast(paramObject);
/*     */     
/* 223 */     int i = getIndex(t) / 64;
/* 224 */     long l = 1L << getIndex(t) % 64;
/*     */     
/* 226 */     return (i < this.bits.length && (this.bits[i] & l) == l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> paramCollection) {
/* 233 */     if (paramCollection == null || getClass() != paramCollection.getClass())
/*     */     {
/* 235 */       return false;
/*     */     }
/*     */     
/* 238 */     BitSet bitSet = (BitSet)paramCollection;
/*     */ 
/*     */     
/* 241 */     if (this.bits.length == 0 && bitSet.bits.length == 0) {
/* 242 */       return true;
/*     */     }
/*     */     
/* 245 */     if (this.bits.length < bitSet.bits.length)
/* 246 */       return false; 
/*     */     byte b;
/*     */     int i;
/* 249 */     for (b = 0, i = bitSet.bits.length; b < i; b++) {
/* 250 */       if ((this.bits[b] & bitSet.bits[b]) != bitSet.bits[b]) {
/* 251 */         return false;
/*     */       }
/*     */     } 
/* 254 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends T> paramCollection) {
/* 262 */     if (paramCollection == null || getClass() != paramCollection.getClass())
/*     */     {
/* 264 */       return false;
/*     */     }
/*     */     
/* 267 */     int i = 0;
/*     */     
/* 269 */     BitSet bitSet = (BitSet)paramCollection;
/*     */     
/* 271 */     long[] arrayOfLong1 = this.bits;
/* 272 */     long[] arrayOfLong2 = bitSet.bits;
/*     */     
/* 274 */     int j = arrayOfLong1.length;
/* 275 */     int k = arrayOfLong2.length;
/*     */     
/* 277 */     int m = (j < k) ? k : j;
/*     */     
/* 279 */     long[] arrayOfLong3 = (m > 0) ? new long[m] : EMPTY_SET;
/*     */     byte b;
/* 281 */     for (b = 0; b < m; b++) {
/*     */       
/* 283 */       if (b < arrayOfLong1.length && b < arrayOfLong2.length) {
/* 284 */         arrayOfLong3[b] = arrayOfLong1[b] | arrayOfLong2[b];
/* 285 */         i |= (arrayOfLong3[b] != arrayOfLong1[b]) ? 1 : 0;
/* 286 */       } else if (b < arrayOfLong1.length) {
/* 287 */         arrayOfLong3[b] = arrayOfLong1[b];
/* 288 */         i |= 0x0;
/*     */       } else {
/* 290 */         arrayOfLong3[b] = arrayOfLong2[b];
/* 291 */         i = 1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 296 */     if (i != 0) {
/*     */       
/* 298 */       if (SetListenerHelper.hasListeners(this.listenerHelper))
/*     */       {
/* 300 */         for (b = 0; b < m; b++) {
/*     */           
/* 302 */           long l = 0L;
/*     */           
/* 304 */           if (b < arrayOfLong1.length && b < arrayOfLong2.length)
/* 305 */           { l = (arrayOfLong1[b] ^ 0xFFFFFFFFFFFFFFFFL) & arrayOfLong2[b]; }
/* 306 */           else { if (b < arrayOfLong1.length) {
/*     */               continue;
/*     */             }
/*     */             
/* 310 */             l = arrayOfLong2[b]; }
/*     */ 
/*     */           
/* 313 */           for (byte b1 = 0; b1 < 64; b1++) {
/* 314 */             long l1 = 1L << b1;
/* 315 */             if ((l1 & l) == l1) {
/* 316 */               T t = getT(b * 64 + b1);
/* 317 */               notifyObservers(t, false);
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */       }
/* 323 */       this.bits = arrayOfLong3;
/*     */     } 
/*     */     
/* 326 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> paramCollection) {
/* 334 */     if (paramCollection == null || getClass() != paramCollection.getClass()) {
/* 335 */       clear();
/* 336 */       return true;
/*     */     } 
/*     */     
/* 339 */     int i = 0;
/*     */     
/* 341 */     BitSet bitSet = (BitSet)paramCollection;
/*     */     
/* 343 */     long[] arrayOfLong1 = this.bits;
/* 344 */     long[] arrayOfLong2 = bitSet.bits;
/*     */     
/* 346 */     int j = arrayOfLong1.length;
/* 347 */     int k = arrayOfLong2.length;
/*     */     
/* 349 */     int m = (j < k) ? j : k;
/*     */     
/* 351 */     long[] arrayOfLong3 = (m > 0) ? new long[m] : EMPTY_SET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 360 */     i |= (arrayOfLong1.length > m) ? 1 : 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 371 */     int n = 1;
/*     */     byte b;
/* 373 */     for (b = 0; b < m; b++) {
/* 374 */       arrayOfLong3[b] = arrayOfLong1[b] & arrayOfLong2[b];
/* 375 */       i |= (arrayOfLong3[b] != arrayOfLong1[b]) ? 1 : 0;
/* 376 */       n &= (arrayOfLong3[b] == 0L) ? 1 : 0;
/*     */     } 
/*     */     
/* 379 */     if (i != 0) {
/*     */       
/* 381 */       if (SetListenerHelper.hasListeners(this.listenerHelper))
/*     */       {
/* 383 */         for (b = 0; b < arrayOfLong1.length; b++) {
/*     */           
/* 385 */           long l = 0L;
/*     */           
/* 387 */           if (b < arrayOfLong2.length) {
/* 388 */             l = arrayOfLong1[b] & (arrayOfLong2[b] ^ 0xFFFFFFFFFFFFFFFFL);
/*     */           }
/*     */           else {
/*     */             
/* 392 */             l = arrayOfLong1[b];
/*     */           } 
/*     */           
/* 395 */           for (byte b1 = 0; b1 < 64; b1++) {
/* 396 */             long l1 = 1L << b1;
/* 397 */             if ((l1 & l) == l1) {
/* 398 */               T t = getT(b * 64 + b1);
/* 399 */               notifyObservers(t, true);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 405 */       this.bits = (n == 0) ? arrayOfLong3 : EMPTY_SET;
/*     */     } 
/*     */     
/* 408 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> paramCollection) {
/* 416 */     if (paramCollection == null || getClass() != paramCollection.getClass())
/*     */     {
/* 418 */       return false;
/*     */     }
/*     */     
/* 421 */     int i = 0;
/*     */     
/* 423 */     BitSet bitSet = (BitSet)paramCollection;
/*     */     
/* 425 */     long[] arrayOfLong1 = this.bits;
/* 426 */     long[] arrayOfLong2 = bitSet.bits;
/*     */     
/* 428 */     int j = arrayOfLong1.length;
/* 429 */     int k = arrayOfLong2.length;
/*     */     
/* 431 */     int m = (j < k) ? j : k;
/*     */     
/* 433 */     long[] arrayOfLong3 = (m > 0) ? new long[m] : EMPTY_SET;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 444 */     int n = 1;
/*     */     byte b;
/* 446 */     for (b = 0; b < m; b++) {
/* 447 */       arrayOfLong3[b] = arrayOfLong1[b] & (arrayOfLong2[b] ^ 0xFFFFFFFFFFFFFFFFL);
/* 448 */       i |= (arrayOfLong3[b] != arrayOfLong1[b]) ? 1 : 0;
/* 449 */       n &= (arrayOfLong3[b] == 0L) ? 1 : 0;
/*     */     } 
/*     */     
/* 452 */     if (i != 0) {
/*     */       
/* 454 */       if (SetListenerHelper.hasListeners(this.listenerHelper))
/*     */       {
/* 456 */         for (b = 0; b < m; b++) {
/*     */           
/* 458 */           long l = arrayOfLong1[b] & arrayOfLong2[b];
/*     */           
/* 460 */           for (byte b1 = 0; b1 < 64; b1++) {
/* 461 */             long l1 = 1L << b1;
/* 462 */             if ((l1 & l) == l1) {
/* 463 */               T t = getT(b * 64 + b1);
/* 464 */               notifyObservers(t, true);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 470 */       this.bits = (n == 0) ? arrayOfLong3 : EMPTY_SET;
/*     */     } 
/*     */     
/* 473 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 480 */     for (byte b = 0; b < this.bits.length; b++) {
/*     */       
/* 482 */       long l = this.bits[b];
/*     */       
/* 484 */       for (byte b1 = 0; b1 < 64; b1++) {
/* 485 */         long l1 = 1L << b1;
/* 486 */         if ((l1 & l) == l1) {
/* 487 */           T t = getT(b * 64 + b1);
/* 488 */           notifyObservers(t, true);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 493 */     this.bits = EMPTY_SET;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 498 */     int i = 7;
/* 499 */     if (this.bits.length > 0) {
/* 500 */       for (byte b = 0; b < this.bits.length; b++) {
/* 501 */         long l = this.bits[b];
/* 502 */         i = 71 * i + (int)(l ^ l >>> 32L);
/*     */       } 
/*     */     }
/* 505 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 511 */     if (this == paramObject) {
/* 512 */       return true;
/*     */     }
/*     */     
/* 515 */     if (paramObject == null || getClass() != paramObject.getClass()) {
/* 516 */       return false;
/*     */     }
/*     */     
/* 519 */     BitSet bitSet = (BitSet)paramObject;
/*     */     
/* 521 */     byte b1 = (this.bits != null) ? this.bits.length : 0;
/* 522 */     byte b2 = (bitSet.bits != null) ? bitSet.bits.length : 0;
/*     */     
/* 524 */     if (b1 != b2) return false;
/*     */     
/* 526 */     for (byte b3 = 0; b3 < b1; b3++) {
/* 527 */       long l1 = this.bits[b3];
/* 528 */       long l2 = bitSet.bits[b3];
/* 529 */       if (l1 != l2) {
/* 530 */         return false;
/*     */       }
/*     */     } 
/* 533 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T getT(int paramInt);
/*     */ 
/*     */   
/*     */   protected abstract int getIndex(T paramT);
/*     */ 
/*     */   
/*     */   protected abstract T cast(Object paramObject);
/*     */ 
/*     */   
/*     */   protected long[] getBits() {
/* 548 */     return this.bits;
/*     */   }
/*     */   
/* 551 */   private static final long[] EMPTY_SET = new long[0];
/*     */ 
/*     */   
/*     */   private class Change
/*     */     extends SetChangeListener.Change<T>
/*     */   {
/*     */     private static final boolean ELEMENT_ADDED = false;
/*     */     
/*     */     private static final boolean ELEMENT_REMOVED = true;
/*     */     
/*     */     private final T element;
/*     */     
/*     */     private final boolean removed;
/*     */ 
/*     */     
/*     */     public Change(T param1T, boolean param1Boolean) {
/* 567 */       super(FXCollections.unmodifiableObservableSet(BitSet.this));
/* 568 */       this.element = param1T;
/* 569 */       this.removed = param1Boolean;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasAdded() {
/* 574 */       return (this.removed != true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasRemoved() {
/* 579 */       return this.removed;
/*     */     }
/*     */ 
/*     */     
/*     */     public T getElementAdded() {
/* 584 */       return this.removed ? null : this.element;
/*     */     }
/*     */ 
/*     */     
/*     */     public T getElementRemoved() {
/* 589 */       return this.removed ? this.element : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(SetChangeListener<? super T> paramSetChangeListener) {
/* 596 */     if (paramSetChangeListener != null) {
/* 597 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, paramSetChangeListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(SetChangeListener<? super T> paramSetChangeListener) {
/* 603 */     if (paramSetChangeListener != null) {
/* 604 */       SetListenerHelper.removeListener(this.listenerHelper, paramSetChangeListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addListener(InvalidationListener paramInvalidationListener) {
/* 610 */     if (paramInvalidationListener != null) {
/* 611 */       this.listenerHelper = SetListenerHelper.addListener(this.listenerHelper, paramInvalidationListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeListener(InvalidationListener paramInvalidationListener) {
/* 617 */     if (paramInvalidationListener != null) {
/* 618 */       SetListenerHelper.removeListener(this.listenerHelper, paramInvalidationListener);
/*     */     }
/*     */   }
/*     */   
/*     */   private void notifyObservers(T paramT, boolean paramBoolean) {
/* 623 */     if (paramT != null && SetListenerHelper.hasListeners(this.listenerHelper)) {
/* 624 */       Change change = new Change(paramT, paramBoolean);
/* 625 */       SetListenerHelper.fireValueChangedEvent(this.listenerHelper, change);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\BitSet.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */