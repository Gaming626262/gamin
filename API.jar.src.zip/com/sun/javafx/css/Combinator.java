/*    */ package com.sun.javafx.css;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum Combinator
/*    */ {
/* 30 */   CHILD { public String toString() {
/* 31 */       return ">";
/*    */     } },
/* 33 */   DESCENDANT { public String toString() {
/* 34 */       return " ";
/*    */     } }
/*    */   ;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\Combinator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */