/*      */ package com.sun.javafx.css;
/*      */ 
/*      */ import com.sun.javafx.logging.PlatformLogger;
/*      */ import com.sun.javafx.scene.NodeHelper;
/*      */ import com.sun.javafx.scene.ParentHelper;
/*      */ import com.sun.javafx.util.DataURI;
/*      */ import com.sun.javafx.util.Logging;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.FilePermission;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.ref.Reference;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.IllegalCharsetNameException;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessControlException;
/*      */ import java.security.AccessController;
/*      */ import java.security.DigestInputStream;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.PermissionCollection;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import javafx.application.Application;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ListChangeListener;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.css.CssParser;
/*      */ import javafx.css.FontFace;
/*      */ import javafx.css.PseudoClass;
/*      */ import javafx.css.Rule;
/*      */ import javafx.css.Selector;
/*      */ import javafx.css.StyleClass;
/*      */ import javafx.css.StyleConverter;
/*      */ import javafx.css.StyleOrigin;
/*      */ import javafx.css.Styleable;
/*      */ import javafx.css.Stylesheet;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Parent;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.SubScene;
/*      */ import javafx.scene.image.Image;
/*      */ import javafx.scene.layout.Region;
/*      */ import javafx.scene.text.Font;
/*      */ import javafx.stage.Window;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class StyleManager
/*      */ {
/*  146 */   private static final Object styleLock = new Object();
/*      */   private static PlatformLogger LOGGER;
/*      */   
/*      */   private static PlatformLogger getLogger() {
/*  150 */     if (LOGGER == null) {
/*  151 */       LOGGER = Logging.getCSSLogger();
/*      */     }
/*  153 */     return LOGGER;
/*      */   }
/*      */   
/*      */   private static class InstanceHolder {
/*  157 */     static final StyleManager INSTANCE = new StyleManager();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static StyleManager getInstance() {
/*  163 */     return InstanceHolder.INSTANCE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StyleManager() {
/*  250 */     this.userAgentStylesheetContainers = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  257 */     this.platformUserAgentStylesheetContainers = new ArrayList<>();
/*      */     
/*  259 */     this.hasDefaultUserAgentStylesheet = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  432 */     this.stylesheetContainerMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  843 */     this.imageCache = new ImageCache();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1678 */     this.key = null;
/*      */ 
/*      */     
/* 1681 */     this.weakRegionUserAgentStylesheetMap = new WeakHashMap<>();
/*      */   } public static final Map<Parent, CacheContainer> cacheContainerMap = new WeakHashMap<>(); public final List<StylesheetContainer> userAgentStylesheetContainers; public final List<StylesheetContainer> platformUserAgentStylesheetContainers; public boolean hasDefaultUserAgentStylesheet; public final Map<String, StylesheetContainer> stylesheetContainerMap; private final ImageCache imageCache; private static final String skinPrefix = "com/sun/javafx/scene/control/skin/"; private static final String skinUtilsClassName = "com.sun.javafx.scene.control.skin.Utils"; private Key key; private final WeakHashMap<Region, String> weakRegionUserAgentStylesheetMap; CacheContainer getCacheContainer(Styleable paramStyleable, SubScene paramSubScene) { if (paramStyleable == null && paramSubScene == null) return null;  Parent parent = null; if (paramSubScene != null) { parent = paramSubScene.getRoot(); } else if (paramStyleable instanceof Node) { Node node = (Node)paramStyleable; Scene scene = node.getScene(); if (scene != null) parent = scene.getRoot();  } else if (paramStyleable instanceof Window) { Scene scene = ((Window)paramStyleable).getScene(); if (scene != null) parent = scene.getRoot();  }  if (parent == null) return null;  synchronized (styleLock) { CacheContainer cacheContainer = cacheContainerMap.get(parent); if (cacheContainer == null) { cacheContainer = new CacheContainer(); cacheContainerMap.put(parent, cacheContainer); }  return cacheContainer; }  } public StyleCache getSharedCache(Styleable paramStyleable, SubScene paramSubScene, StyleCache.Key paramKey) { CacheContainer cacheContainer = getCacheContainer(paramStyleable, paramSubScene); if (cacheContainer == null) return null;  Map<StyleCache.Key, StyleCache> map = cacheContainer.getStyleCache(); if (map == null) return null;  StyleCache styleCache = map.get(paramKey); if (styleCache == null) { styleCache = new StyleCache(); map.put(new StyleCache.Key(paramKey), styleCache); }  return styleCache; } public StyleMap getStyleMap(Styleable paramStyleable, SubScene paramSubScene, int paramInt) { if (paramInt == -1) return StyleMap.EMPTY_MAP;  CacheContainer cacheContainer = getCacheContainer(paramStyleable, paramSubScene); if (cacheContainer == null) return StyleMap.EMPTY_MAP;  return cacheContainer.getStyleMap(paramInt); } static class StylesheetContainer {
/*      */     final String fname; final Stylesheet stylesheet; final SelectorPartitioning selectorPartitioning; final StyleManager.RefList<Parent> parentUsers; final int hash; final byte[] checksum; boolean checksumInvalid = false; StylesheetContainer(String param1String, Stylesheet param1Stylesheet) { this(param1String, param1Stylesheet, (param1Stylesheet != null) ? StyleManager.calculateCheckSum(param1Stylesheet.getUrl()) : new byte[0]); } StylesheetContainer(String param1String, Stylesheet param1Stylesheet, byte[] param1ArrayOfbyte) { this.fname = param1String; this.hash = (param1String != null) ? param1String.hashCode() : 127; this.stylesheet = param1Stylesheet; if (param1Stylesheet != null) { this.selectorPartitioning = new SelectorPartitioning(); List<Rule> list = param1Stylesheet.getRules(); byte b1 = (list == null || list.isEmpty()) ? 0 : list.size(); for (byte b2 = 0; b2 < b1; b2++) { Rule rule = list.get(b2); ObservableList<Selector> observableList = rule.getSelectors(); byte b3 = (observableList == null || observableList.isEmpty()) ? 0 : observableList.size(); for (byte b4 = 0; b4 < b3; b4++) { Selector selector = observableList.get(b4); this.selectorPartitioning.partition(selector); }  }  } else { this.selectorPartitioning = null; }  this.parentUsers = new StyleManager.RefList<>(); this.checksum = param1ArrayOfbyte; } void invalidateChecksum() { this.checksumInvalid = (this.checksum.length > 0); } public int hashCode() { return this.hash; } public boolean equals(Object param1Object) { if (param1Object == null) return false;  if (getClass() != param1Object.getClass()) return false;  StylesheetContainer stylesheetContainer = (StylesheetContainer)param1Object; if ((this.fname == null) ? (stylesheetContainer.fname != null) : !this.fname.equals(stylesheetContainer.fname)) return false;  return true; } public String toString() { return this.fname; } } static class RefList<K> {
/*      */     final List<Reference<K>> list; RefList() { this.list = new ArrayList<>(); } void add(K param1K) { for (int i = this.list.size() - 1; 0 <= i; i--) { Reference<Object> reference = (Reference)this.list.get(i); K k = (K)reference.get(); if (k == null) { this.list.remove(i); } else if (k == param1K) { return; }  }  this.list.add(new WeakReference<>(param1K)); } void remove(K param1K) { for (int i = this.list.size() - 1; 0 <= i; i--) { Reference<Object> reference = (Reference)this.list.get(i); K k = (K)reference.get(); if (k == null) { this.list.remove(i); } else if (k == param1K) { this.list.remove(i); return; }  }  } boolean contains(K param1K) { for (int i = this.list.size() - 1; 0 <= i; i--) { Reference<Object> reference = (Reference)this.list.get(i); K k = (K)reference.get(); if (k == param1K) return true;  }  return false; } } public void forget(Scene paramScene) { if (paramScene == null) return;  forget(paramScene.getRoot()); synchronized (styleLock) { String str = null; if (paramScene.getUserAgentStylesheet() != null && !(str = paramScene.getUserAgentStylesheet().trim()).isEmpty()) for (int i = this.userAgentStylesheetContainers.size() - 1; 0 <= i; i--) { StylesheetContainer stylesheetContainer = this.userAgentStylesheetContainers.get(i); if (str.equals(stylesheetContainer.fname)) { stylesheetContainer.parentUsers.remove(paramScene.getRoot()); if (stylesheetContainer.parentUsers.list.size() == 0) this.userAgentStylesheetContainers.remove(i);  }  }   Set<Map.Entry<String, StylesheetContainer>> set = this.stylesheetContainerMap.entrySet(); Iterator<Map.Entry<String, StylesheetContainer>> iterator = set.iterator(); while (iterator.hasNext()) { Map.Entry entry = iterator.next(); StylesheetContainer stylesheetContainer = (StylesheetContainer)entry.getValue(); Iterator<Reference<Parent>> iterator1 = stylesheetContainer.parentUsers.list.iterator(); while (iterator1.hasNext()) { Reference<Parent> reference = iterator1.next(); Parent parent = reference.get(); if (parent == null || parent.getScene() == paramScene || parent.getScene() == null) { reference.clear(); iterator1.remove(); }  }  if (stylesheetContainer.parentUsers.list.isEmpty()) iterator.remove();  }  }  } public void stylesheetsChanged(Scene paramScene, ListChangeListener.Change<String> paramChange) { synchronized (styleLock) { Set<Map.Entry<Parent, CacheContainer>> set = cacheContainerMap.entrySet(); for (Map.Entry<Parent, CacheContainer> entry : set) { Parent parent = (Parent)entry.getKey(); CacheContainer cacheContainer = (CacheContainer)entry.getValue(); if (parent.getScene() == paramScene) cacheContainer.clearCache();  }  paramChange.reset(); while (paramChange.next()) { if (paramChange.wasRemoved()) for (String str : paramChange.getRemoved()) { stylesheetRemoved(paramScene, str); StylesheetContainer stylesheetContainer = this.stylesheetContainerMap.get(str); if (stylesheetContainer != null) stylesheetContainer.invalidateChecksum();  }   }  }  } private void stylesheetRemoved(Scene paramScene, String paramString) { stylesheetRemoved(paramScene.getRoot(), paramString); }
/*      */   public void forget(Parent paramParent) { if (paramParent == null) return;  synchronized (styleLock) { CacheContainer cacheContainer = cacheContainerMap.remove(paramParent); if (cacheContainer != null) cacheContainer.clearCache();  ObservableList observableList = paramParent.getStylesheets(); if (observableList != null && !observableList.isEmpty()) for (String str : observableList) stylesheetRemoved(paramParent, str);   Iterator<Map.Entry> iterator = this.stylesheetContainerMap.entrySet().iterator(); while (iterator.hasNext()) { Map.Entry entry = iterator.next(); StylesheetContainer stylesheetContainer = (StylesheetContainer)entry.getValue(); stylesheetContainer.parentUsers.remove(paramParent); if (stylesheetContainer.parentUsers.list.isEmpty()) { iterator.remove(); if (stylesheetContainer.selectorPartitioning != null) stylesheetContainer.selectorPartitioning.reset();  String str = stylesheetContainer.fname; this.imageCache.cleanUpImageCache(str); }  }  }  }
/*      */   public void stylesheetsChanged(Parent paramParent, ListChangeListener.Change<String> paramChange) { synchronized (styleLock) { paramChange.reset(); while (paramChange.next()) { if (paramChange.wasRemoved()) for (String str : paramChange.getRemoved()) { stylesheetRemoved(paramParent, str); StylesheetContainer stylesheetContainer = this.stylesheetContainerMap.get(str); if (stylesheetContainer != null) stylesheetContainer.invalidateChecksum();  }   }  }  }
/*      */   private void stylesheetRemoved(Parent paramParent, String paramString) { synchronized (styleLock) { StylesheetContainer stylesheetContainer = this.stylesheetContainerMap.get(paramString); if (stylesheetContainer == null) return;  stylesheetContainer.parentUsers.remove(paramParent); if (stylesheetContainer.parentUsers.list.isEmpty()) removeStylesheetContainer(stylesheetContainer);  }  }
/* 1688 */   public StyleMap findMatchingStyles(Node paramNode, SubScene paramSubScene, Set<PseudoClass>[] paramArrayOfSet) { Scene scene = paramNode.getScene();
/* 1689 */     if (scene == null) {
/* 1690 */       return StyleMap.EMPTY_MAP;
/*      */     }
/*      */     
/* 1693 */     CacheContainer cacheContainer = getCacheContainer((Styleable)paramNode, paramSubScene);
/* 1694 */     if (cacheContainer == null) {
/* 1695 */       assert false : paramNode.toString();
/* 1696 */       return StyleMap.EMPTY_MAP;
/*      */     } 
/*      */     
/* 1699 */     synchronized (styleLock)
/*      */     
/*      */     { 
/* 1702 */       Parent parent2, parent1 = (paramNode instanceof Parent) ? (Parent)paramNode : paramNode.getParent();
/*      */ 
/*      */       
/* 1705 */       List<StylesheetContainer> list1 = gatherParentStylesheets(parent1);
/*      */       
/* 1707 */       boolean bool1 = !list1.isEmpty() ? true : false;
/*      */       
/* 1709 */       List<StylesheetContainer> list2 = gatherSceneStylesheets(scene);
/*      */       
/* 1711 */       boolean bool2 = !list2.isEmpty() ? true : false;
/*      */       
/* 1713 */       String str1 = paramNode.getStyle();
/* 1714 */       boolean bool3 = (str1 != null && !str1.trim().isEmpty()) ? true : false;
/*      */       
/* 1716 */       String str2 = scene.getUserAgentStylesheet();
/*      */       
/* 1718 */       boolean bool4 = (str2 != null && !str2.trim().isEmpty()) ? true : false;
/*      */ 
/*      */       
/* 1721 */       String str3 = (paramSubScene != null) ? paramSubScene.getUserAgentStylesheet() : null;
/*      */       
/* 1723 */       boolean bool5 = (str3 != null && !str3.trim().isEmpty()) ? true : false;
/*      */       
/* 1725 */       String str4 = null;
/*      */       
/* 1727 */       Node node = paramNode;
/* 1728 */       while (node != null) {
/* 1729 */         if (node instanceof Region) {
/* 1730 */           str4 = this.weakRegionUserAgentStylesheetMap.computeIfAbsent((Region)node, Region::getUserAgentStylesheet);
/*      */ 
/*      */           
/* 1733 */           if (str4 != null) {
/*      */             break;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 1739 */         parent2 = node.getParent();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1744 */       boolean bool6 = (str4 != null && !str4.trim().isEmpty()) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1751 */       if (!bool3 && !bool1 && !bool2 && !bool4 && !bool5 && !bool6 && this.platformUserAgentStylesheetContainers
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1757 */         .isEmpty()) {
/* 1758 */         return StyleMap.EMPTY_MAP;
/*      */       }
/*      */       
/* 1761 */       String str5 = paramNode.getTypeSelector();
/* 1762 */       String str6 = paramNode.getId();
/* 1763 */       ObservableList<String> observableList = paramNode.getStyleClass();
/*      */       
/* 1765 */       if (this.key == null) {
/* 1766 */         this.key = new Key();
/*      */       }
/*      */       
/* 1769 */       this.key.className = str5;
/* 1770 */       this.key.id = str6; byte b; int i;
/* 1771 */       for (b = 0, i = observableList.size(); b < i; b++) {
/*      */         
/* 1773 */         String str = observableList.get(b);
/* 1774 */         if (str != null && !str.isEmpty())
/*      */         {
/* 1776 */           this.key.styleClasses.add(StyleClassSet.getStyleClass(str));
/*      */         }
/*      */       } 
/* 1779 */       Map<Key, Cache> map = cacheContainer.getCacheMap(list1, str4);
/* 1780 */       Cache cache = map.get(this.key);
/*      */       
/* 1782 */       if (cache != null) {
/*      */         
/* 1784 */         this.key.styleClasses.clear();
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1792 */         ArrayList<Selector> arrayList = new ArrayList();
/*      */ 
/*      */         
/* 1795 */         if (bool5 || bool4) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1800 */           String str = bool5 ? paramSubScene.getUserAgentStylesheet().trim() : scene.getUserAgentStylesheet().trim();
/*      */ 
/*      */           
/* 1803 */           StylesheetContainer stylesheetContainer = null; byte b1; int j;
/* 1804 */           for (b1 = 0, j = this.userAgentStylesheetContainers.size(); b1 < j; b1++) {
/* 1805 */             stylesheetContainer = this.userAgentStylesheetContainers.get(b1);
/* 1806 */             if (str.equals(stylesheetContainer.fname)) {
/*      */               break;
/*      */             }
/* 1809 */             stylesheetContainer = null;
/*      */           } 
/*      */           
/* 1812 */           if (stylesheetContainer == null) {
/* 1813 */             Stylesheet stylesheet = loadStylesheet(str);
/* 1814 */             if (stylesheet != null) {
/* 1815 */               stylesheet.setOrigin(StyleOrigin.USER_AGENT);
/*      */             }
/* 1817 */             stylesheetContainer = new StylesheetContainer(str, stylesheet);
/* 1818 */             this.userAgentStylesheetContainers.add(stylesheetContainer);
/*      */           } 
/*      */           
/* 1821 */           if (stylesheetContainer.selectorPartitioning != null)
/*      */           {
/* 1823 */             Parent parent = bool5 ? paramSubScene.getRoot() : scene.getRoot();
/* 1824 */             stylesheetContainer.parentUsers.add(parent);
/*      */ 
/*      */             
/* 1827 */             List<Selector> list = stylesheetContainer.selectorPartitioning.match(str6, str5, (Set<StyleClass>)this.key.styleClasses);
/* 1828 */             arrayList.addAll(list);
/*      */           }
/*      */         
/* 1831 */         } else if (!this.platformUserAgentStylesheetContainers.isEmpty()) {
/* 1832 */           byte b1; int j; for (b1 = 0, j = this.platformUserAgentStylesheetContainers.size(); b1 < j; b1++) {
/* 1833 */             StylesheetContainer stylesheetContainer = this.platformUserAgentStylesheetContainers.get(b1);
/* 1834 */             if (stylesheetContainer != null && stylesheetContainer.selectorPartitioning != null) {
/*      */               
/* 1836 */               List<Selector> list = stylesheetContainer.selectorPartitioning.match(str6, str5, (Set<StyleClass>)this.key.styleClasses);
/* 1837 */               arrayList.addAll(list);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 1842 */         if (bool6) {
/*      */           
/* 1844 */           StylesheetContainer stylesheetContainer = null; byte b1; int j;
/* 1845 */           for (b1 = 0, j = this.userAgentStylesheetContainers.size(); b1 < j; b1++) {
/* 1846 */             stylesheetContainer = this.userAgentStylesheetContainers.get(b1);
/* 1847 */             if (str4.equals(stylesheetContainer.fname)) {
/*      */               break;
/*      */             }
/* 1850 */             stylesheetContainer = null;
/*      */           } 
/*      */           
/* 1853 */           if (stylesheetContainer == null) {
/* 1854 */             Stylesheet stylesheet = loadStylesheet(str4);
/* 1855 */             if (stylesheet != null) {
/* 1856 */               stylesheet.setOrigin(StyleOrigin.USER_AGENT);
/*      */             }
/* 1858 */             stylesheetContainer = new StylesheetContainer(str4, stylesheet);
/* 1859 */             this.userAgentStylesheetContainers.add(stylesheetContainer);
/*      */           } 
/*      */           
/* 1862 */           if (stylesheetContainer.selectorPartitioning != null) {
/*      */ 
/*      */             
/* 1865 */             stylesheetContainer.parentUsers.add(parent2);
/*      */ 
/*      */             
/* 1868 */             List<Selector> list = stylesheetContainer.selectorPartitioning.match(str6, str5, (Set<StyleClass>)this.key.styleClasses);
/* 1869 */             arrayList.addAll(list);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1876 */         if (!list2.isEmpty()) {
/* 1877 */           byte b1; int j; for (b1 = 0, j = list2.size(); b1 < j; b1++) {
/* 1878 */             StylesheetContainer stylesheetContainer = list2.get(b1);
/* 1879 */             if (stylesheetContainer != null && stylesheetContainer.selectorPartitioning != null) {
/*      */               
/* 1881 */               List<Selector> list = stylesheetContainer.selectorPartitioning.match(str6, str5, (Set<StyleClass>)this.key.styleClasses);
/* 1882 */               arrayList.addAll(list);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1888 */         if (bool1) {
/* 1889 */           byte b1 = (list1 == null) ? 0 : list1.size();
/* 1890 */           for (byte b2 = 0; b2 < b1; b2++) {
/* 1891 */             StylesheetContainer stylesheetContainer = list1.get(b2);
/* 1892 */             if (stylesheetContainer.selectorPartitioning != null) {
/*      */               
/* 1894 */               List<Selector> list = stylesheetContainer.selectorPartitioning.match(str6, str5, (Set<StyleClass>)this.key.styleClasses);
/* 1895 */               arrayList.addAll(list);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1901 */         cache = new Cache(arrayList);
/* 1902 */         map.put(this.key, cache);
/*      */ 
/*      */         
/* 1905 */         this.key = null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1911 */       return cache.getStyleMap(cacheContainer, paramNode, paramArrayOfSet, bool3); }  }
/*      */   public void forget(SubScene paramSubScene) { if (paramSubScene == null) return;  Parent parent = paramSubScene.getRoot(); if (parent == null) return;  forget(parent); synchronized (styleLock) { String str = null; if (paramSubScene.getUserAgentStylesheet() != null && !(str = paramSubScene.getUserAgentStylesheet().trim()).isEmpty()) { Iterator<StylesheetContainer> iterator1 = this.userAgentStylesheetContainers.iterator(); while (iterator1.hasNext()) { StylesheetContainer stylesheetContainer = iterator1.next(); if (str.equals(stylesheetContainer.fname)) { stylesheetContainer.parentUsers.remove(paramSubScene.getRoot()); if (stylesheetContainer.parentUsers.list.size() == 0) iterator1.remove();  }  }  }  ArrayList arrayList = new ArrayList(this.stylesheetContainerMap.values()); Iterator<StylesheetContainer> iterator = arrayList.iterator(); while (iterator.hasNext()) { StylesheetContainer stylesheetContainer = iterator.next(); Iterator<Reference<Parent>> iterator1 = stylesheetContainer.parentUsers.list.iterator(); while (iterator1.hasNext()) { Reference<Parent> reference = iterator1.next(); Parent parent1 = reference.get(); if (parent1 != null) { Parent parent2 = parent1; while (parent2 != null) { if (parent == parent2.getParent()) { reference.clear(); iterator1.remove(); forget(parent1); break; }  parent2 = parent2.getParent(); }  }  }  }  }  }
/*      */   private void removeStylesheetContainer(StylesheetContainer paramStylesheetContainer) { if (paramStylesheetContainer == null) return;  synchronized (styleLock) { String str = paramStylesheetContainer.fname; this.stylesheetContainerMap.remove(str); if (paramStylesheetContainer.selectorPartitioning != null) paramStylesheetContainer.selectorPartitioning.reset();  for (Map.Entry<Parent, CacheContainer> entry : cacheContainerMap.entrySet()) { CacheContainer cacheContainer = (CacheContainer)entry.getValue(); if (cacheContainer == null || cacheContainer.cacheMap == null || cacheContainer.cacheMap.isEmpty()) continue;  ArrayList<List> arrayList = new ArrayList(); for (Map.Entry<List<String>, Map<Key, Cache>> entry1 : cacheContainer.cacheMap.entrySet()) { List list1 = (List)entry1.getKey(); if ((list1 != null) ? list1.contains(str) : (str == null)) arrayList.add(list1);  }  if (!arrayList.isEmpty()) for (List list1 : arrayList) { Map map = cacheContainer.cacheMap.remove(list1); if (map != null) map.clear();  }   }  this.imageCache.cleanUpImageCache(str); List<Reference<Parent>> list = paramStylesheetContainer.parentUsers.list; for (int i = list.size() - 1; 0 <= i; i--) { Reference<Parent> reference = list.remove(i); Parent parent = reference.get(); reference.clear(); if (parent != null && parent.getScene() != null) NodeHelper.reapplyCSS((Node)parent);  }  }  }
/*      */   private static final class ImageCache {
/*      */     private Map<String, SoftReference<Image>> imageCache = new HashMap<>();
/*      */     Image getCachedImage(String param1String) { synchronized (StyleManager.styleLock) { Image image = null; if (this.imageCache.containsKey(param1String)) image = ((SoftReference<Image>)this.imageCache.get(param1String)).get();  if (image == null) try { image = new Image(param1String); if (image.isError()) { PlatformLogger platformLogger = StyleManager.getLogger(); if (platformLogger != null && platformLogger.isLoggable(PlatformLogger.Level.WARNING)) { DataURI dataURI = DataURI.tryParse(param1String); if (dataURI != null) { platformLogger.warning("Error loading image: " + dataURI); } else { platformLogger.warning("Error loading image: " + param1String); }  }  image = null; }  this.imageCache.put(param1String, new SoftReference<>(image)); } catch (IllegalArgumentException|NullPointerException illegalArgumentException) { PlatformLogger platformLogger = StyleManager.getLogger(); if (platformLogger != null && platformLogger.isLoggable(PlatformLogger.Level.WARNING)) platformLogger.warning(illegalArgumentException.getLocalizedMessage());  }   return image; }  }
/*      */     void cleanUpImageCache(String param1String) { synchronized (StyleManager.styleLock) { if (param1String == null || this.imageCache.isEmpty()) return;  String str1 = param1String.trim(); if (str1.isEmpty())
/*      */           return;  int i = str1.lastIndexOf('/'); String str2 = (i > 0) ? str1.substring(0, i) : str1; int j = str2.length(); String[] arrayOfString = new String[this.imageCache.size()]; byte b1 = 0; Set<Map.Entry<String, SoftReference<Image>>> set = this.imageCache.entrySet(); for (Map.Entry<String, SoftReference<Image>> entry : set) { String str3 = (String)entry.getKey(); if (((SoftReference)entry.getValue()).get() == null) { arrayOfString[b1++] = str3; continue; }  i = str3.lastIndexOf('/'); String str4 = (i > 0) ? str3.substring(0, i) : str3; int k = str4.length(); boolean bool = (k > j) ? str4.startsWith(str2) : str2.startsWith(str4); if (bool)
/*      */             arrayOfString[b1++] = str3;  }  for (byte b2 = 0; b2 < b1; b2++)
/*      */           this.imageCache.remove(arrayOfString[b2]);  }  } }
/*      */   public Image getCachedImage(String paramString) { return this.imageCache.getCachedImage(paramString); } private static URL getURL(String paramString) { if (paramString == null || paramString.trim().isEmpty())
/*      */       return null;  try { URI uRI = new URI(paramString.trim()); if (!uRI.isAbsolute()) { if (paramString.startsWith("com/sun/javafx/scene/control/skin/") && (paramString.endsWith(".css") || paramString.endsWith(".bss")))
/* 1923 */           try { ClassLoader classLoader1 = StyleManager.class.getClassLoader(); Class<?> clazz = Class.forName("com.sun.javafx.scene.control.skin.Utils", true, classLoader1); Method method = clazz.getMethod("getResource", new Class[] { String.class }); return (URL)method.invoke(null, new Object[] { paramString.substring("com/sun/javafx/scene/control/skin/".length()) }); } catch (ClassNotFoundException|NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException classNotFoundException) { classNotFoundException.printStackTrace(); return null; }   ClassLoader classLoader = Thread.currentThread().getContextClassLoader(); String str = uRI.getPath(); URL uRL = null; if (str.startsWith("/")) { uRL = classLoader.getResource(str.substring(1)); } else { uRL = classLoader.getResource(str); }  return uRL; }  return uRI.toURL(); } catch (MalformedURLException malformedURLException) { return null; } catch (URISyntaxException uRISyntaxException) { return null; }  } private static ObservableList<CssParser.ParseError> errors = null;
/*      */   static byte[] calculateCheckSum(String paramString) { if (paramString == null || paramString.isEmpty()) return new byte[0];  try { URL uRL = getURL(paramString); if (uRL != null && "file".equals(uRL.getProtocol())) { InputStream inputStream = uRL.openStream(); try { DigestInputStream digestInputStream = new DigestInputStream(inputStream, MessageDigest.getInstance("MD5")); try { digestInputStream.getMessageDigest().reset(); byte[] arrayOfByte1 = new byte[4096]; while (digestInputStream.read(arrayOfByte1) != -1); byte[] arrayOfByte2 = digestInputStream.getMessageDigest().digest(); digestInputStream.close(); if (inputStream != null) inputStream.close();  return arrayOfByte2; } catch (Throwable throwable) { try { digestInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { if (inputStream != null) try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  }  } catch (IllegalArgumentException|java.security.NoSuchAlgorithmException|IOException|SecurityException illegalArgumentException) {} return new byte[0]; }
/*      */   public static Stylesheet loadStylesheet(String paramString) { try { return loadStylesheetUnPrivileged(paramString); } catch (AccessControlException accessControlException) { System.err.println("WARNING: security exception trying to load: " + paramString); if (paramString.length() < 7 && paramString.indexOf("!/") < paramString.length() - 7) return null;  try { URI uRI = new URI(paramString); if ("jar".equals(uRI.getScheme())) { URI uRI1 = AccessController.<URI>doPrivileged(() -> StyleManager.class.getProtectionDomain().getCodeSource().getLocation().toURI()); String str1 = uRI1.getSchemeSpecificPart(); String str2 = uRI.getSchemeSpecificPart(); String str3 = str2.substring(str2.indexOf('/'), str2.indexOf("!/")); if (str1.equals(str3)) { String str = paramString.substring(paramString.indexOf("!/") + 2); if (paramString.endsWith(".css") || paramString.endsWith(".bss")) { FilePermission filePermission = new FilePermission(str1, "read"); PermissionCollection permissionCollection = filePermission.newPermissionCollection(); permissionCollection.add(filePermission); AccessControlContext accessControlContext = new AccessControlContext(new ProtectionDomain[] { new ProtectionDomain(null, permissionCollection) }); JarFile jarFile = null; try { jarFile = AccessController.<JarFile>doPrivileged(() -> new JarFile(paramString), accessControlContext); } catch (PrivilegedActionException privilegedActionException) { return null; }  if (jarFile != null) { JarEntry jarEntry = jarFile.getJarEntry(str); if (jarEntry != null) return AccessController.<Stylesheet>doPrivileged(() -> loadStylesheetUnPrivileged(paramString), accessControlContext);  }  }  }  }  return null; } catch (URISyntaxException uRISyntaxException) { return null; } catch (PrivilegedActionException privilegedActionException) { return null; }  }  }
/*      */   private static Stylesheet loadStylesheetUnPrivileged(String paramString) { synchronized (styleLock) { Boolean bool = AccessController.<Boolean>doPrivileged(() -> { String str = System.getProperty("binary.css"); return Boolean.valueOf((!paramString.endsWith(".bss") && str != null) ? (!Boolean.valueOf(str).booleanValue()) : Boolean.FALSE.booleanValue()); }); try { String str = bool.booleanValue() ? ".css" : ".bss"; URL uRL = null; Stylesheet stylesheet = null; if (!paramString.endsWith(".css") && !paramString.endsWith(".bss")) { uRL = getURL(paramString); } else { String str1 = paramString.substring(0, paramString.length() - 4); uRL = getURL(str1 + str1); if (uRL == null) if ((bool = Boolean.valueOf(!bool.booleanValue())).booleanValue()) uRL = getURL(str1 + ".css");   if (uRL != null && !bool.booleanValue()) { try { stylesheet = Stylesheet.loadBinary(uRL); } catch (IOException iOException) {} if (stylesheet == null) uRL = getURL(paramString);  }  }  if (stylesheet == null) { DataURI dataURI = null; if (uRL != null) { stylesheet = (new CssParser()).parse(uRL); } else { dataURI = DataURI.tryParse(paramString); }  if (dataURI != null) { boolean bool1 = ("text".equalsIgnoreCase(dataURI.getMimeType()) && ("css".equalsIgnoreCase(dataURI.getMimeSubtype()) || "plain".equalsIgnoreCase(dataURI.getMimeSubtype()))) ? true : false; boolean bool2 = ("application".equalsIgnoreCase(dataURI.getMimeType()) && "octet-stream".equalsIgnoreCase(dataURI.getMimeSubtype())) ? true : false; if (bool1) { Charset charset; String str1 = (String)dataURI.getParameters().get("charset"); try { charset = (str1 != null) ? Charset.forName(str1) : Charset.defaultCharset(); } catch (IllegalCharsetNameException|java.nio.charset.UnsupportedCharsetException illegalCharsetNameException) { String str3 = String.format("Unsupported charset \"%s\" in stylesheet URI \"%s\"", new Object[] { str1, dataURI }); if (errors != null) errors.add(new CssParser.ParseError(str3));  if (getLogger().isLoggable(PlatformLogger.Level.WARNING)) getLogger().warning(str3);  return null; }  String str2 = new String(dataURI.getData(), charset); stylesheet = (new CssParser()).parse(str2); } else if (bool2) { ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(dataURI.getData()); try { stylesheet = Stylesheet.loadBinary(byteArrayInputStream); byteArrayInputStream.close(); } catch (Throwable throwable) { try { byteArrayInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } else { String str1 = String.format("Unexpected MIME type \"%s/%s\" in stylesheet URI \"%s\"", new Object[] { dataURI.getMimeType(), dataURI.getMimeSubtype(), dataURI }); if (errors != null) errors.add(new CssParser.ParseError(str1));  if (getLogger().isLoggable(PlatformLogger.Level.WARNING)) getLogger().warning(str1);  return null; }  }  }  if (stylesheet == null) { if (errors != null) { CssParser.ParseError parseError = new CssParser.ParseError("Resource \"" + paramString + "\" not found."); errors.add(parseError); }  if (getLogger().isLoggable(PlatformLogger.Level.WARNING)) getLogger().warning(String.format("Resource \"%s\" not found.", new Object[] { paramString }));  }  if (stylesheet != null) for (FontFace fontFace : stylesheet.getFontFaces()) { if (fontFace instanceof FontFaceImpl) for (FontFaceImpl.FontFaceSrc fontFaceSrc : ((FontFaceImpl)fontFace).getSources()) { if (fontFaceSrc.getType() == FontFaceImpl.FontFaceSrcType.URL) { Font font = Font.loadFont(fontFaceSrc.getSrc(), 10.0D); if (font == null) getLogger().info("Could not load @font-face font [" + fontFaceSrc.getSrc() + "]");  }  }   }   return stylesheet; } catch (FileNotFoundException fileNotFoundException) { if (errors != null) { CssParser.ParseError parseError = new CssParser.ParseError("Stylesheet \"" + paramString + "\" not found."); errors.add(parseError); }  if (getLogger().isLoggable(PlatformLogger.Level.INFO)) getLogger().info("Could not find stylesheet: " + paramString);  } catch (IOException iOException) { DataURI dataURI = DataURI.tryParse(paramString); String str = (dataURI != null) ? dataURI.toString() : paramString; if (errors != null) errors.add(new CssParser.ParseError("Could not load stylesheet: " + str));  if (getLogger().isLoggable(PlatformLogger.Level.INFO)) getLogger().info("Could not load stylesheet: " + str);  }  return null; }  }
/*      */   public void setUserAgentStylesheets(List<String> paramList) { if (paramList == null || paramList.size() == 0) return;  synchronized (styleLock) { if (paramList.size() == this.platformUserAgentStylesheetContainers.size()) { boolean bool1 = true; byte b1; int j; for (b1 = 0, j = paramList.size(); b1 < j && bool1; b1++) { String str1 = paramList.get(b1); String str2 = (str1 != null) ? str1.trim() : null; if (str2 == null || str2.isEmpty()) break;  StylesheetContainer stylesheetContainer = this.platformUserAgentStylesheetContainers.get(b1); if (bool1 = str2.equals(stylesheetContainer.fname)) { String str = stylesheetContainer.stylesheet.getUrl(); byte[] arrayOfByte = calculateCheckSum(str); bool1 = Arrays.equals(arrayOfByte, stylesheetContainer.checksum); }  }  if (bool1) return;  }  boolean bool = false; byte b; int i; for (b = 0, i = paramList.size(); b < i; b++) { String str1 = paramList.get(b); String str2 = (str1 != null) ? str1.trim() : null; if (str2 != null && !str2.isEmpty()) { if (!bool) { this.platformUserAgentStylesheetContainers.clear(); bool = true; }  if (b == 0) { _setDefaultUserAgentStylesheet(str2); } else { _addUserAgentStylesheet(str2); }  }  }  if (bool) userAgentStylesheetsChanged();  }  }
/*      */   public void addUserAgentStylesheet(String paramString) { addUserAgentStylesheet((Scene)null, paramString); }
/*      */   public void addUserAgentStylesheet(Scene paramScene, String paramString) { String str = (paramString != null) ? paramString.trim() : null; if (str == null || str.isEmpty()) return;  synchronized (styleLock) { if (_addUserAgentStylesheet(str)) userAgentStylesheetsChanged();  }  }
/*      */   private boolean _addUserAgentStylesheet(String paramString) { synchronized (styleLock) { byte b; int i; for (b = 0, i = this.platformUserAgentStylesheetContainers.size(); b < i; b++) { StylesheetContainer stylesheetContainer = this.platformUserAgentStylesheetContainers.get(b); if (paramString.equals(stylesheetContainer.fname)) return false;  }  Stylesheet stylesheet = loadStylesheet(paramString); if (stylesheet == null) return false;  stylesheet.setOrigin(StyleOrigin.USER_AGENT); this.platformUserAgentStylesheetContainers.add(new StylesheetContainer(paramString, stylesheet)); return true; }  }
/*      */   public void addUserAgentStylesheet(Scene paramScene, Stylesheet paramStylesheet) { if (paramStylesheet == null) throw new IllegalArgumentException("null arg ua_stylesheet");  String str1 = paramStylesheet.getUrl(); String str2 = (str1 != null) ? str1.trim() : ""; synchronized (styleLock) { byte b; int i; for (b = 0, i = this.platformUserAgentStylesheetContainers.size(); b < i; b++) { StylesheetContainer stylesheetContainer = this.platformUserAgentStylesheetContainers.get(b); if (str2.equals(stylesheetContainer.fname)) return;  }  this.platformUserAgentStylesheetContainers.add(new StylesheetContainer(str2, paramStylesheet)); if (paramStylesheet != null) paramStylesheet.setOrigin(StyleOrigin.USER_AGENT);  userAgentStylesheetsChanged(); }  }
/*      */   public void setDefaultUserAgentStylesheet(String paramString) { setDefaultUserAgentStylesheet(null, paramString); }
/*      */   public void setDefaultUserAgentStylesheet(Scene paramScene, String paramString) { String str = (paramString != null) ? paramString.trim() : null; if (str == null || str.isEmpty()) return;  synchronized (styleLock) { if (_setDefaultUserAgentStylesheet(str)) userAgentStylesheetsChanged();  }  }
/*      */   private boolean _setDefaultUserAgentStylesheet(String paramString) { synchronized (styleLock) { byte b; int i; for (b = 0, i = this.platformUserAgentStylesheetContainers.size(); b < i; b++) { StylesheetContainer stylesheetContainer1 = this.platformUserAgentStylesheetContainers.get(b); if (paramString.equals(stylesheetContainer1.fname)) { if (b > 0) { this.platformUserAgentStylesheetContainers.remove(b); if (this.hasDefaultUserAgentStylesheet) { this.platformUserAgentStylesheetContainers.set(0, stylesheetContainer1); } else { this.platformUserAgentStylesheetContainers.add(0, stylesheetContainer1); }  }  return (b > 0); }  }  Stylesheet stylesheet = loadStylesheet(paramString); if (stylesheet == null) return false;  stylesheet.setOrigin(StyleOrigin.USER_AGENT); StylesheetContainer stylesheetContainer = new StylesheetContainer(paramString, stylesheet); if (this.platformUserAgentStylesheetContainers.size() == 0) { this.platformUserAgentStylesheetContainers.add(stylesheetContainer); } else if (this.hasDefaultUserAgentStylesheet) { this.platformUserAgentStylesheetContainers.set(0, stylesheetContainer); } else { this.platformUserAgentStylesheetContainers.add(0, stylesheetContainer); }  this.hasDefaultUserAgentStylesheet = true; return true; }  }
/*      */   public void removeUserAgentStylesheet(String paramString) { String str = (paramString != null) ? paramString.trim() : null; if (str == null || str.isEmpty()) return;  synchronized (styleLock) { boolean bool = false; for (int i = this.platformUserAgentStylesheetContainers.size() - 1; i >= 0; i--) { if (!str.equals(Application.getUserAgentStylesheet())) { StylesheetContainer stylesheetContainer = this.platformUserAgentStylesheetContainers.get(i); if (str.equals(stylesheetContainer.fname)) { this.platformUserAgentStylesheetContainers.remove(i); bool = true; }  }  }  if (bool) userAgentStylesheetsChanged();  }  }
/* 1936 */   public void setDefaultUserAgentStylesheet(Stylesheet paramStylesheet) { if (paramStylesheet == null) return;  String str1 = paramStylesheet.getUrl(); String str2 = (str1 != null) ? str1.trim() : ""; synchronized (styleLock) { byte b; int i; for (b = 0, i = this.platformUserAgentStylesheetContainers.size(); b < i; b++) { StylesheetContainer stylesheetContainer1 = this.platformUserAgentStylesheetContainers.get(b); if (str2.equals(stylesheetContainer1.fname)) { if (b > 0) { this.platformUserAgentStylesheetContainers.remove(b); if (this.hasDefaultUserAgentStylesheet) { this.platformUserAgentStylesheetContainers.set(0, stylesheetContainer1); } else { this.platformUserAgentStylesheetContainers.add(0, stylesheetContainer1); }  }  return; }  }  StylesheetContainer stylesheetContainer = new StylesheetContainer(str2, paramStylesheet); if (this.platformUserAgentStylesheetContainers.size() == 0) { this.platformUserAgentStylesheetContainers.add(stylesheetContainer); } else if (this.hasDefaultUserAgentStylesheet) { this.platformUserAgentStylesheetContainers.set(0, stylesheetContainer); } else { this.platformUserAgentStylesheetContainers.add(0, stylesheetContainer); }  this.hasDefaultUserAgentStylesheet = true; paramStylesheet.setOrigin(StyleOrigin.USER_AGENT); userAgentStylesheetsChanged(); }  } private void userAgentStylesheetsChanged() { ArrayList<Parent> arrayList = new ArrayList(); synchronized (styleLock) { for (CacheContainer cacheContainer : cacheContainerMap.values()) cacheContainer.clearCache();  StyleConverter.clearCache(); for (Parent parent : cacheContainerMap.keySet()) { if (parent == null) continue;  arrayList.add(parent); }  }  for (Parent parent : arrayList) NodeHelper.reapplyCSS((Node)parent);  } private List<StylesheetContainer> processStylesheets(List<String> paramList, Parent paramParent) { synchronized (styleLock) { ArrayList<StylesheetContainer> arrayList = new ArrayList(); byte b; int i; for (b = 0, i = paramList.size(); b < i; b++) { String str = paramList.get(b); StylesheetContainer stylesheetContainer = null; if (this.stylesheetContainerMap.containsKey(str)) { stylesheetContainer = this.stylesheetContainerMap.get(str); if (!arrayList.contains(stylesheetContainer)) { if (stylesheetContainer.checksumInvalid) { byte[] arrayOfByte = calculateCheckSum(str); if (!Arrays.equals(arrayOfByte, stylesheetContainer.checksum)) { removeStylesheetContainer(stylesheetContainer); Stylesheet stylesheet = loadStylesheet(str); stylesheetContainer = new StylesheetContainer(str, stylesheet, arrayOfByte); this.stylesheetContainerMap.put(str, stylesheetContainer); } else { stylesheetContainer.checksumInvalid = false; }  }  arrayList.add(stylesheetContainer); }  stylesheetContainer.parentUsers.add(paramParent); } else { Stylesheet stylesheet = loadStylesheet(str); stylesheetContainer = new StylesheetContainer(str, stylesheet); stylesheetContainer.parentUsers.add(paramParent); this.stylesheetContainerMap.put(str, stylesheetContainer); arrayList.add(stylesheetContainer); }  }  return arrayList; }  } private List<StylesheetContainer> gatherParentStylesheets(Parent paramParent) { if (paramParent == null) return Collections.emptyList();  List<String> list = ParentHelper.getAllParentStylesheets(paramParent); if (list == null || list.isEmpty()) return Collections.emptyList();  synchronized (styleLock) { return processStylesheets(list, paramParent); }  } private List<StylesheetContainer> gatherSceneStylesheets(Scene paramScene) { if (paramScene == null) return Collections.emptyList();  ObservableList observableList = paramScene.getStylesheets(); if (observableList == null || observableList.isEmpty()) return Collections.emptyList();  synchronized (styleLock) { return processStylesheets((List<String>)observableList, paramScene.getRoot()); }  } private static List<String> cacheMapKey; public static ObservableList<CssParser.ParseError> errorsProperty() { if (errors == null) {
/* 1937 */       errors = FXCollections.observableArrayList();
/*      */     }
/* 1939 */     return errors; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ObservableList<CssParser.ParseError> getErrors() {
/* 1951 */     return errors;
/*      */   }
/*      */ 
/*      */   
/*      */   static class CacheContainer
/*      */   {
/*      */     private Map<StyleCache.Key, StyleCache> styleCache;
/*      */     
/*      */     private Map<List<String>, Map<StyleManager.Key, StyleManager.Cache>> cacheMap;
/*      */     
/*      */     private List<StyleMap> styleMapList;
/*      */     
/*      */     private Map<String, Selector> inlineStylesCache;
/*      */ 
/*      */     
/*      */     private Map<StyleCache.Key, StyleCache> getStyleCache() {
/* 1967 */       if (this.styleCache == null) this.styleCache = new HashMap<>(); 
/* 1968 */       return this.styleCache;
/*      */     }
/*      */ 
/*      */     
/*      */     private Map<StyleManager.Key, StyleManager.Cache> getCacheMap(List<StyleManager.StylesheetContainer> param1List, String param1String) {
/* 1973 */       if (this.cacheMap == null) {
/* 1974 */         this.cacheMap = new HashMap<>();
/*      */       }
/*      */       
/* 1977 */       synchronized (StyleManager.styleLock) {
/* 1978 */         if ((param1List == null || param1List.isEmpty()) && (param1String == null || param1String
/* 1979 */           .isEmpty())) {
/*      */           
/* 1981 */           Map<Object, Object> map1 = (Map)this.cacheMap.get(null);
/* 1982 */           if (map1 == null) {
/* 1983 */             map1 = new HashMap<>();
/* 1984 */             this.cacheMap.put(null, map1);
/*      */           } 
/* 1986 */           return (Map)map1;
/*      */         } 
/*      */ 
/*      */         
/* 1990 */         int i = param1List.size();
/* 1991 */         if (StyleManager.cacheMapKey == null) {
/* 1992 */           StyleManager.cacheMapKey = new ArrayList<>(i);
/*      */         }
/* 1994 */         for (byte b = 0; b < i; b++) {
/* 1995 */           StyleManager.StylesheetContainer stylesheetContainer = param1List.get(b);
/* 1996 */           if (stylesheetContainer != null && stylesheetContainer.fname != null && !stylesheetContainer.fname.isEmpty())
/* 1997 */             StyleManager.cacheMapKey.add(stylesheetContainer.fname); 
/*      */         } 
/* 1999 */         if (param1String != null) {
/* 2000 */           StyleManager.cacheMapKey.add(param1String);
/*      */         }
/* 2002 */         Map<Object, Object> map = (Map)this.cacheMap.get(StyleManager.cacheMapKey);
/* 2003 */         if (map == null) {
/* 2004 */           map = new HashMap<>();
/* 2005 */           this.cacheMap.put(StyleManager.cacheMapKey, map);
/*      */           
/* 2007 */           StyleManager.cacheMapKey = null;
/*      */         } else {
/*      */           
/* 2010 */           StyleManager.cacheMapKey.clear();
/*      */         } 
/* 2012 */         return (Map)map;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private List<StyleMap> getStyleMapList() {
/* 2020 */       if (this.styleMapList == null) this.styleMapList = new ArrayList<>(); 
/* 2021 */       return this.styleMapList;
/*      */     }
/*      */     
/*      */     private int nextSmapId() {
/* 2025 */       this.styleMapId = this.baseStyleMapId + getStyleMapList().size();
/* 2026 */       return this.styleMapId;
/*      */     }
/*      */     
/*      */     private void addStyleMap(StyleMap param1StyleMap) {
/* 2030 */       getStyleMapList().add(param1StyleMap);
/*      */     }
/*      */ 
/*      */     
/*      */     public StyleMap getStyleMap(int param1Int) {
/* 2035 */       int i = param1Int - this.baseStyleMapId;
/*      */       
/* 2037 */       if (0 <= i && i < getStyleMapList().size()) {
/* 2038 */         return getStyleMapList().get(i);
/*      */       }
/*      */       
/* 2041 */       return StyleMap.EMPTY_MAP;
/*      */     }
/*      */ 
/*      */     
/*      */     private void clearCache() {
/* 2046 */       if (this.cacheMap != null) this.cacheMap.clear(); 
/* 2047 */       if (this.styleCache != null) this.styleCache.clear(); 
/* 2048 */       if (this.styleMapList != null) this.styleMapList.clear();
/*      */       
/* 2050 */       this.baseStyleMapId = this.styleMapId;
/*      */       
/* 2052 */       if (this.baseStyleMapId > 1879048185) {
/* 2053 */         this.baseStyleMapId = this.styleMapId = 0;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Selector getInlineStyleSelector(String param1String) {
/* 2063 */       if (param1String == null || param1String.trim().isEmpty()) return null;
/*      */       
/* 2065 */       if (this.inlineStylesCache != null && this.inlineStylesCache.containsKey(param1String))
/*      */       {
/* 2067 */         return this.inlineStylesCache.get(param1String);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2074 */       if (this.inlineStylesCache == null) {
/* 2075 */         this.inlineStylesCache = new HashMap<>();
/*      */       }
/*      */ 
/*      */       
/* 2079 */       Stylesheet stylesheet = (new CssParser()).parse("*{" + param1String + "}");
/*      */       
/* 2081 */       if (stylesheet != null) {
/*      */         
/* 2083 */         stylesheet.setOrigin(StyleOrigin.INLINE);
/*      */         
/* 2085 */         List<Rule> list = stylesheet.getRules();
/* 2086 */         Rule rule = (list != null && !list.isEmpty()) ? list.get(0) : null;
/*      */ 
/*      */         
/* 2089 */         ObservableList<Selector> observableList = (rule != null) ? rule.getSelectors() : null;
/* 2090 */         Selector selector = (observableList != null && !observableList.isEmpty()) ? observableList.get(0) : null;
/*      */ 
/*      */         
/* 2093 */         if (selector != null) {
/* 2094 */           selector.setOrdinal(-1);
/*      */           
/* 2096 */           this.inlineStylesCache.put(param1String, selector);
/* 2097 */           return selector;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2105 */       this.inlineStylesCache.put(param1String, null);
/* 2106 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2127 */     private int styleMapId = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2133 */     private int baseStyleMapId = 0;
/*      */   }
/*      */   
/*      */   private static class Cache
/*      */   {
/*      */     private final List<Selector> selectors;
/*      */     private final Map<Key, Integer> cache;
/*      */     
/*      */     private static class Key
/*      */     {
/*      */       final long[] key;
/*      */       final String inlineStyle;
/*      */       
/*      */       Key(long[] param2ArrayOflong, String param2String) {
/* 2147 */         this.key = param2ArrayOflong;
/*      */         
/* 2149 */         this.inlineStyle = (param2String != null && param2String.trim().isEmpty()) ? null : param2String;
/*      */       }
/*      */       
/*      */       public String toString() {
/* 2153 */         return Arrays.toString(this.key) + Arrays.toString(this.key);
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 2158 */         int i = 3;
/* 2159 */         i = 17 * i + Arrays.hashCode(this.key);
/* 2160 */         if (this.inlineStyle != null) i = 17 * i + this.inlineStyle.hashCode(); 
/* 2161 */         return i;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(Object param2Object) {
/* 2166 */         if (param2Object == null) {
/* 2167 */           return false;
/*      */         }
/* 2169 */         if (getClass() != param2Object.getClass()) {
/* 2170 */           return false;
/*      */         }
/* 2172 */         Key key = (Key)param2Object;
/* 2173 */         if ((this.inlineStyle == null) ? (key.inlineStyle != null) : !this.inlineStyle.equals(key.inlineStyle)) {
/* 2174 */           return false;
/*      */         }
/* 2176 */         if (!Arrays.equals(this.key, key.key)) {
/* 2177 */           return false;
/*      */         }
/* 2179 */         return true;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Cache(List<Selector> param1List) {
/* 2193 */       this.selectors = param1List;
/* 2194 */       this.cache = new HashMap<>();
/*      */     }
/*      */     
/*      */     private StyleMap getStyleMap(StyleManager.CacheContainer param1CacheContainer, Node param1Node, Set<PseudoClass>[] param1ArrayOfSet, boolean param1Boolean)
/*      */     {
/* 2199 */       if ((this.selectors == null || this.selectors.isEmpty()) && !param1Boolean) {
/* 2200 */         return StyleMap.EMPTY_MAP;
/*      */       }
/*      */       
/* 2203 */       int i = this.selectors.size();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2216 */       long[] arrayOfLong = new long[i / 64 + 1];
/* 2217 */       boolean bool = true;
/*      */       
/* 2219 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 2221 */         Selector selector = this.selectors.get(b);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2241 */         if (selector.applies((Styleable)param1Node, (Set[])param1ArrayOfSet, 0)) {
/* 2242 */           int k = b / 64;
/* 2243 */           long l = arrayOfLong[k] | 1L << b;
/* 2244 */           arrayOfLong[k] = l;
/* 2245 */           bool = false;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2250 */       if (bool && !param1Boolean) {
/* 2251 */         return StyleMap.EMPTY_MAP;
/*      */       }
/*      */       
/* 2254 */       String str = param1Node.getStyle();
/* 2255 */       Key key = new Key(arrayOfLong, str);
/*      */       
/* 2257 */       if (this.cache.containsKey(key)) {
/* 2258 */         Integer integer = this.cache.get(key);
/* 2259 */         return (integer != null) ? 
/* 2260 */           param1CacheContainer.getStyleMap(integer.intValue()) : 
/* 2261 */           StyleMap.EMPTY_MAP;
/*      */       } 
/*      */ 
/*      */       
/* 2265 */       ArrayList<Selector> arrayList = new ArrayList();
/*      */       
/* 2267 */       if (param1Boolean) {
/* 2268 */         Selector selector = param1CacheContainer.getInlineStyleSelector(str);
/* 2269 */         if (selector != null) arrayList.add(selector); 
/*      */       } 
/*      */       int j;
/* 2272 */       for (j = 0; j < arrayOfLong.length; j++) {
/*      */         
/* 2274 */         if (arrayOfLong[j] != 0L) {
/*      */           
/* 2276 */           int k = j * 64;
/*      */           
/* 2278 */           for (byte b1 = 0; b1 < 64; b1++) {
/*      */ 
/*      */             
/* 2281 */             long l = 1L << b1;
/* 2282 */             if ((l & arrayOfLong[j]) == l) {
/*      */               
/* 2284 */               Selector selector = this.selectors.get(k + b1);
/* 2285 */               arrayList.add(selector);
/*      */             } 
/*      */           } 
/*      */         } 
/* 2289 */       }  j = param1CacheContainer.nextSmapId();
/* 2290 */       this.cache.put(key, Integer.valueOf(j));
/*      */       
/* 2292 */       StyleMap styleMap = new StyleMap(j, arrayList);
/* 2293 */       param1CacheContainer.addStyleMap(styleMap);
/* 2294 */       return styleMap;
/*      */     } } private static class Key { final long[] key; final String inlineStyle; Key(long[] param1ArrayOflong, String param1String) { this.key = param1ArrayOflong;
/*      */       this.inlineStyle = (param1String != null && param1String.trim().isEmpty()) ? null : param1String; } public String toString() { return Arrays.toString(this.key) + Arrays.toString(this.key); }
/*      */     public int hashCode() { int i = 3;
/*      */       i = 17 * i + Arrays.hashCode(this.key);
/*      */       if (this.inlineStyle != null)
/*      */         i = 17 * i + this.inlineStyle.hashCode(); 
/*      */       return i; }
/*      */     public boolean equals(Object param1Object) { if (param1Object == null)
/*      */         return false; 
/*      */       if (getClass() != param1Object.getClass())
/*      */         return false; 
/*      */       Key key = (Key)param1Object;
/*      */       if ((this.inlineStyle == null) ? (key.inlineStyle != null) : !this.inlineStyle.equals(key.inlineStyle))
/*      */         return false; 
/*      */       if (!Arrays.equals(this.key, key.key))
/*      */         return false; 
/*      */       return true; } }
/*      */   private static class Key { String className; String id; final StyleClassSet styleClasses;
/* 2313 */     private Key() { this.styleClasses = new StyleClassSet(); }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 2318 */       if (this == param1Object) {
/* 2319 */         return true;
/*      */       }
/* 2321 */       if (param1Object instanceof Key) {
/* 2322 */         Key key = (Key)param1Object;
/*      */         
/* 2324 */         if ((this.className == null) ? (key.className != null) : !this.className.equals(key.className)) {
/* 2325 */           return false;
/*      */         }
/*      */         
/* 2328 */         if ((this.id == null) ? (key.id != null) : !this.id.equals(key.id)) {
/* 2329 */           return false;
/*      */         }
/*      */         
/* 2332 */         return this.styleClasses.equals(key.styleClasses);
/*      */       } 
/* 2334 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/* 2339 */       int i = 7;
/* 2340 */       i = 29 * i + ((this.className != null) ? this.className.hashCode() : 0);
/* 2341 */       i = 29 * i + ((this.id != null) ? this.id.hashCode() : 0);
/* 2342 */       i = 29 * i + this.styleClasses.hashCode();
/* 2343 */       return i;
/*      */     } }
/*      */ 
/*      */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\StyleManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */