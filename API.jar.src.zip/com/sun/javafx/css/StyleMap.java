/*     */ package com.sun.javafx.css;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javafx.css.Declaration;
/*     */ import javafx.css.Match;
/*     */ import javafx.css.Rule;
/*     */ import javafx.css.Selector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StyleMap
/*     */ {
/*  46 */   public static final StyleMap EMPTY_MAP = new StyleMap(-1, 
/*  47 */       Collections.emptyList()); private static final Comparator<CascadingStyle> cascadingStyleComparator;
/*     */   private final int id;
/*     */   
/*     */   public StyleMap(int paramInt, List<Selector> paramList) {
/*  51 */     this.id = paramInt;
/*  52 */     this.selectors = paramList;
/*     */   }
/*     */   private List<Selector> selectors; private Map<String, List<CascadingStyle>> cascadingStyles;
/*     */   public int getId() {
/*  56 */     return this.id;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  60 */     if (this.selectors != null) return this.selectors.isEmpty(); 
/*  61 */     if (this.cascadingStyles != null) return this.cascadingStyles.isEmpty(); 
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, List<CascadingStyle>> getCascadingStyles() {
/*  67 */     if (this.cascadingStyles == null) {
/*     */       
/*  69 */       if (this.selectors == null || this.selectors.isEmpty()) {
/*  70 */         this.cascadingStyles = Collections.emptyMap();
/*  71 */         return this.cascadingStyles;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  80 */       ArrayList<CascadingStyle> arrayList = new ArrayList();
/*     */       
/*  82 */       byte b1 = 0; int i, j;
/*  83 */       for (i = 0, j = this.selectors.size(); i < j; i++) {
/*     */         
/*  85 */         Selector selector = this.selectors.get(i);
/*     */         
/*  87 */         Match match = selector.createMatch();
/*     */         
/*  89 */         Rule rule = selector.getRule(); byte b;
/*     */         int k;
/*  91 */         for (b = 0, k = rule.getDeclarations().size(); b < k; b++) {
/*  92 */           Declaration declaration = (Declaration)rule.getDeclarations().get(b);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  97 */           CascadingStyle cascadingStyle1 = new CascadingStyle(declaration, match, b1++);
/*     */           
/*  99 */           arrayList.add(cascadingStyle1);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 104 */       if (arrayList.isEmpty()) {
/* 105 */         this.cascadingStyles = Collections.emptyMap();
/* 106 */         return this.cascadingStyles;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 111 */       Collections.sort(arrayList, cascadingStyleComparator);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       i = arrayList.size();
/* 117 */       this.cascadingStyles = new HashMap<>(i);
/*     */       
/* 119 */       CascadingStyle cascadingStyle = arrayList.get(0);
/* 120 */       String str = cascadingStyle.getProperty();
/*     */ 
/*     */       
/* 123 */       for (byte b2 = 0; b2 < i; ) {
/*     */         
/* 125 */         List list = this.cascadingStyles.get(str);
/* 126 */         if (list == null) {
/*     */           
/* 128 */           byte b = b2;
/* 129 */           String str1 = str;
/*     */           
/* 131 */           while (++b < i) {
/* 132 */             cascadingStyle = arrayList.get(b);
/* 133 */             str = cascadingStyle.getProperty();
/* 134 */             if (!str.equals(str1))
/*     */               break; 
/*     */           } 
/* 137 */           this.cascadingStyles.put(str1, arrayList.subList(b2, b));
/*     */           
/* 139 */           b2 = b;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/*     */         assert false;
/*     */       } 
/*     */       
/* 148 */       this.selectors.clear();
/* 149 */       this.selectors = null;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     return this.cascadingStyles;
/*     */   }
/*     */   static {
/* 156 */     cascadingStyleComparator = ((paramCascadingStyle1, paramCascadingStyle2) -> {
/*     */         String str1 = paramCascadingStyle1.getProperty();
/*     */         String str2 = paramCascadingStyle2.getProperty();
/*     */         int i = str1.compareTo(str2);
/*     */         return (i != 0) ? i : paramCascadingStyle1.compareTo(paramCascadingStyle2);
/*     */       });
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\css\StyleMap.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */