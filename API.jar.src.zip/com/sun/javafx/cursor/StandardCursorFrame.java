/*    */ package com.sun.javafx.cursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StandardCursorFrame
/*    */   extends CursorFrame
/*    */ {
/*    */   private CursorType cursorType;
/*    */   
/*    */   public StandardCursorFrame(CursorType paramCursorType) {
/* 32 */     this.cursorType = paramCursorType;
/*    */   }
/*    */ 
/*    */   
/*    */   public CursorType getCursorType() {
/* 37 */     return this.cursorType;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\cursor\StandardCursorFrame.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */