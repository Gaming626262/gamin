/*    */ package com.sun.javafx.cursor;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CursorFrame
/*    */ {
/*    */   private Class<?> firstPlatformCursorClass;
/*    */   private Object firstPlatformCursor;
/*    */   private Map<Class<?>, Object> otherPlatformCursors;
/*    */   
/*    */   public abstract CursorType getCursorType();
/*    */   
/*    */   public <T> T getPlatformCursor(Class<T> paramClass) {
/* 45 */     if (this.firstPlatformCursorClass == paramClass) {
/* 46 */       return (T)this.firstPlatformCursor;
/*    */     }
/*    */     
/* 49 */     if (this.otherPlatformCursors != null) {
/* 50 */       return (T)this.otherPlatformCursors.get(paramClass);
/*    */     }
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> void setPlatforCursor(Class<T> paramClass, T paramT) {
/* 59 */     if (this.firstPlatformCursorClass == null || this.firstPlatformCursorClass == paramClass) {
/*    */ 
/*    */       
/* 62 */       this.firstPlatformCursorClass = paramClass;
/* 63 */       this.firstPlatformCursor = paramT;
/*    */       
/*    */       return;
/*    */     } 
/* 67 */     if (this.otherPlatformCursors == null) {
/* 68 */       this.otherPlatformCursors = new HashMap<>();
/*    */     }
/*    */     
/* 71 */     this.otherPlatformCursors.put(paramClass, paramT);
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\cursor\CursorFrame.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */