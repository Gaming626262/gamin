/*    */ package com.sun.javafx.cursor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CursorType
/*    */ {
/* 29 */   DEFAULT,
/* 30 */   CROSSHAIR,
/* 31 */   TEXT,
/* 32 */   WAIT,
/* 33 */   SW_RESIZE,
/* 34 */   SE_RESIZE,
/* 35 */   NW_RESIZE,
/* 36 */   NE_RESIZE,
/* 37 */   N_RESIZE,
/* 38 */   S_RESIZE,
/* 39 */   W_RESIZE,
/* 40 */   E_RESIZE,
/* 41 */   OPEN_HAND,
/* 42 */   CLOSED_HAND,
/* 43 */   HAND,
/* 44 */   MOVE,
/* 45 */   DISAPPEAR,
/* 46 */   H_RESIZE,
/* 47 */   V_RESIZE,
/* 48 */   NONE,
/* 49 */   IMAGE;
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\cursor\CursorType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */