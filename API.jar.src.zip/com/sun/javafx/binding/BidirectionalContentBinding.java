/*     */ package com.sun.javafx.binding;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import javafx.beans.WeakListener;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.MapChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.collections.ObservableMap;
/*     */ import javafx.collections.ObservableSet;
/*     */ import javafx.collections.SetChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BidirectionalContentBinding
/*     */ {
/*     */   private static void checkParameters(Object paramObject1, Object paramObject2) {
/*  40 */     if (paramObject1 == null || paramObject2 == null) {
/*  41 */       throw new NullPointerException("Both parameters must be specified.");
/*     */     }
/*  43 */     if (paramObject1 == paramObject2) {
/*  44 */       throw new IllegalArgumentException("Cannot bind object to itself");
/*     */     }
/*     */   }
/*     */   
/*     */   public static <E> Object bind(ObservableList<E> paramObservableList1, ObservableList<E> paramObservableList2) {
/*  49 */     checkParameters(paramObservableList1, paramObservableList2);
/*  50 */     ListContentBinding<E> listContentBinding = new ListContentBinding<>(paramObservableList1, paramObservableList2);
/*  51 */     paramObservableList1.setAll((Collection)paramObservableList2);
/*  52 */     paramObservableList1.addListener(listContentBinding);
/*  53 */     paramObservableList2.addListener(listContentBinding);
/*  54 */     return listContentBinding;
/*     */   }
/*     */   
/*     */   public static <E> Object bind(ObservableSet<E> paramObservableSet1, ObservableSet<E> paramObservableSet2) {
/*  58 */     checkParameters(paramObservableSet1, paramObservableSet2);
/*  59 */     SetContentBinding<E> setContentBinding = new SetContentBinding<>(paramObservableSet1, paramObservableSet2);
/*  60 */     paramObservableSet1.clear();
/*  61 */     paramObservableSet1.addAll((Collection)paramObservableSet2);
/*  62 */     paramObservableSet1.addListener(setContentBinding);
/*  63 */     paramObservableSet2.addListener(setContentBinding);
/*  64 */     return setContentBinding;
/*     */   }
/*     */   
/*     */   public static <K, V> Object bind(ObservableMap<K, V> paramObservableMap1, ObservableMap<K, V> paramObservableMap2) {
/*  68 */     checkParameters(paramObservableMap1, paramObservableMap2);
/*  69 */     MapContentBinding<K, V> mapContentBinding = new MapContentBinding<>(paramObservableMap1, paramObservableMap2);
/*  70 */     paramObservableMap1.clear();
/*  71 */     paramObservableMap1.putAll((Map)paramObservableMap2);
/*  72 */     paramObservableMap1.addListener(mapContentBinding);
/*  73 */     paramObservableMap2.addListener(mapContentBinding);
/*  74 */     return mapContentBinding;
/*     */   }
/*     */   
/*     */   public static void unbind(Object paramObject1, Object paramObject2) {
/*  78 */     checkParameters(paramObject1, paramObject2);
/*  79 */     if (paramObject1 instanceof ObservableList && paramObject2 instanceof ObservableList) {
/*  80 */       ObservableList<?> observableList1 = (ObservableList)paramObject1;
/*  81 */       ObservableList<?> observableList2 = (ObservableList)paramObject2;
/*  82 */       ListContentBinding listContentBinding = new ListContentBinding(observableList1, observableList2);
/*  83 */       observableList1.removeListener(listContentBinding);
/*  84 */       observableList2.removeListener(listContentBinding);
/*  85 */     } else if (paramObject1 instanceof ObservableSet && paramObject2 instanceof ObservableSet) {
/*  86 */       ObservableSet<?> observableSet1 = (ObservableSet)paramObject1;
/*  87 */       ObservableSet<?> observableSet2 = (ObservableSet)paramObject2;
/*  88 */       SetContentBinding setContentBinding = new SetContentBinding(observableSet1, observableSet2);
/*  89 */       observableSet1.removeListener(setContentBinding);
/*  90 */       observableSet2.removeListener(setContentBinding);
/*  91 */     } else if (paramObject1 instanceof ObservableMap && paramObject2 instanceof ObservableMap) {
/*  92 */       ObservableMap<?, ?> observableMap1 = (ObservableMap)paramObject1;
/*  93 */       ObservableMap<?, ?> observableMap2 = (ObservableMap)paramObject2;
/*  94 */       MapContentBinding<Object, Object> mapContentBinding = new MapContentBinding<>(observableMap1, observableMap2);
/*  95 */       observableMap1.removeListener(mapContentBinding);
/*  96 */       observableMap2.removeListener(mapContentBinding);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ListContentBinding<E>
/*     */     implements ListChangeListener<E>, WeakListener
/*     */   {
/*     */     private final WeakReference<ObservableList<E>> propertyRef1;
/*     */     private final WeakReference<ObservableList<E>> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     public ListContentBinding(ObservableList<E> param1ObservableList1, ObservableList<E> param1ObservableList2) {
/* 109 */       this.propertyRef1 = new WeakReference<>(param1ObservableList1);
/* 110 */       this.propertyRef2 = new WeakReference<>(param1ObservableList2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(ListChangeListener.Change<? extends E> param1Change) {
/* 115 */       if (!this.updating) {
/* 116 */         ObservableList observableList1 = this.propertyRef1.get();
/* 117 */         ObservableList observableList2 = this.propertyRef2.get();
/* 118 */         if (observableList1 == null || observableList2 == null) {
/* 119 */           if (observableList1 != null) {
/* 120 */             observableList1.removeListener(this);
/*     */           }
/* 122 */           if (observableList2 != null) {
/* 123 */             observableList2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 127 */             this.updating = true;
/* 128 */             ObservableList observableList = (observableList1 == param1Change.getList()) ? observableList2 : observableList1;
/* 129 */             while (param1Change.next()) {
/* 130 */               if (param1Change.wasPermutated()) {
/* 131 */                 observableList.remove(param1Change.getFrom(), param1Change.getTo());
/* 132 */                 observableList.addAll(param1Change.getFrom(), param1Change.getList().subList(param1Change.getFrom(), param1Change.getTo())); continue;
/*     */               } 
/* 134 */               if (param1Change.wasRemoved()) {
/* 135 */                 observableList.remove(param1Change.getFrom(), param1Change.getFrom() + param1Change.getRemovedSize());
/*     */               }
/* 137 */               if (param1Change.wasAdded()) {
/* 138 */                 observableList.addAll(param1Change.getFrom(), param1Change.getAddedSubList());
/*     */               }
/*     */             } 
/*     */           } finally {
/*     */             
/* 143 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 151 */       return (this.propertyRef1.get() == null || this.propertyRef2.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 156 */       ObservableList observableList1 = this.propertyRef1.get();
/* 157 */       ObservableList observableList2 = this.propertyRef2.get();
/* 158 */       byte b1 = (observableList1 == null) ? 0 : observableList1.hashCode();
/* 159 */       byte b2 = (observableList2 == null) ? 0 : observableList2.hashCode();
/* 160 */       return b1 * b2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 165 */       if (this == param1Object) {
/* 166 */         return true;
/*     */       }
/*     */       
/* 169 */       Object object1 = this.propertyRef1.get();
/* 170 */       Object object2 = this.propertyRef2.get();
/* 171 */       if (object1 == null || object2 == null) {
/* 172 */         return false;
/*     */       }
/*     */       
/* 175 */       if (param1Object instanceof ListContentBinding) {
/* 176 */         ListContentBinding listContentBinding = (ListContentBinding)param1Object;
/* 177 */         Object object3 = listContentBinding.propertyRef1.get();
/* 178 */         Object object4 = listContentBinding.propertyRef2.get();
/* 179 */         if (object3 == null || object4 == null) {
/* 180 */           return false;
/*     */         }
/*     */         
/* 183 */         if (object1 == object3 && object2 == object4) {
/* 184 */           return true;
/*     */         }
/* 186 */         if (object1 == object4 && object2 == object3) {
/* 187 */           return true;
/*     */         }
/*     */       } 
/* 190 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SetContentBinding<E>
/*     */     implements SetChangeListener<E>, WeakListener
/*     */   {
/*     */     private final WeakReference<ObservableSet<E>> propertyRef1;
/*     */     private final WeakReference<ObservableSet<E>> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     public SetContentBinding(ObservableSet<E> param1ObservableSet1, ObservableSet<E> param1ObservableSet2) {
/* 203 */       this.propertyRef1 = new WeakReference<>(param1ObservableSet1);
/* 204 */       this.propertyRef2 = new WeakReference<>(param1ObservableSet2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(SetChangeListener.Change<? extends E> param1Change) {
/* 209 */       if (!this.updating) {
/* 210 */         ObservableSet observableSet1 = this.propertyRef1.get();
/* 211 */         ObservableSet observableSet2 = this.propertyRef2.get();
/* 212 */         if (observableSet1 == null || observableSet2 == null) {
/* 213 */           if (observableSet1 != null) {
/* 214 */             observableSet1.removeListener(this);
/*     */           }
/* 216 */           if (observableSet2 != null) {
/* 217 */             observableSet2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 221 */             this.updating = true;
/* 222 */             ObservableSet<Object> observableSet = (observableSet1 == param1Change.getSet()) ? observableSet2 : observableSet1;
/* 223 */             if (param1Change.wasRemoved()) {
/* 224 */               observableSet.remove(param1Change.getElementRemoved());
/*     */             } else {
/* 226 */               observableSet.add(param1Change.getElementAdded());
/*     */             } 
/*     */           } finally {
/* 229 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 237 */       return (this.propertyRef1.get() == null || this.propertyRef2.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 242 */       ObservableSet observableSet1 = this.propertyRef1.get();
/* 243 */       ObservableSet observableSet2 = this.propertyRef2.get();
/* 244 */       byte b1 = (observableSet1 == null) ? 0 : observableSet1.hashCode();
/* 245 */       byte b2 = (observableSet2 == null) ? 0 : observableSet2.hashCode();
/* 246 */       return b1 * b2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 251 */       if (this == param1Object) {
/* 252 */         return true;
/*     */       }
/*     */       
/* 255 */       Object object1 = this.propertyRef1.get();
/* 256 */       Object object2 = this.propertyRef2.get();
/* 257 */       if (object1 == null || object2 == null) {
/* 258 */         return false;
/*     */       }
/*     */       
/* 261 */       if (param1Object instanceof SetContentBinding) {
/* 262 */         SetContentBinding setContentBinding = (SetContentBinding)param1Object;
/* 263 */         Object object3 = setContentBinding.propertyRef1.get();
/* 264 */         Object object4 = setContentBinding.propertyRef2.get();
/* 265 */         if (object3 == null || object4 == null) {
/* 266 */           return false;
/*     */         }
/*     */         
/* 269 */         if (object1 == object3 && object2 == object4) {
/* 270 */           return true;
/*     */         }
/* 272 */         if (object1 == object4 && object2 == object3) {
/* 273 */           return true;
/*     */         }
/*     */       } 
/* 276 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class MapContentBinding<K, V>
/*     */     implements MapChangeListener<K, V>, WeakListener
/*     */   {
/*     */     private final WeakReference<ObservableMap<K, V>> propertyRef1;
/*     */     private final WeakReference<ObservableMap<K, V>> propertyRef2;
/*     */     private boolean updating = false;
/*     */     
/*     */     public MapContentBinding(ObservableMap<K, V> param1ObservableMap1, ObservableMap<K, V> param1ObservableMap2) {
/* 289 */       this.propertyRef1 = new WeakReference<>(param1ObservableMap1);
/* 290 */       this.propertyRef2 = new WeakReference<>(param1ObservableMap2);
/*     */     }
/*     */ 
/*     */     
/*     */     public void onChanged(MapChangeListener.Change<? extends K, ? extends V> param1Change) {
/* 295 */       if (!this.updating) {
/* 296 */         ObservableMap observableMap1 = this.propertyRef1.get();
/* 297 */         ObservableMap observableMap2 = this.propertyRef2.get();
/* 298 */         if (observableMap1 == null || observableMap2 == null) {
/* 299 */           if (observableMap1 != null) {
/* 300 */             observableMap1.removeListener(this);
/*     */           }
/* 302 */           if (observableMap2 != null) {
/* 303 */             observableMap2.removeListener(this);
/*     */           }
/*     */         } else {
/*     */           try {
/* 307 */             this.updating = true;
/* 308 */             ObservableMap<Object, Object> observableMap = (observableMap1 == param1Change.getMap()) ? observableMap2 : observableMap1;
/* 309 */             if (param1Change.wasRemoved()) {
/* 310 */               observableMap.remove(param1Change.getKey());
/*     */             }
/* 312 */             if (param1Change.wasAdded()) {
/* 313 */               observableMap.put(param1Change.getKey(), param1Change.getValueAdded());
/*     */             }
/*     */           } finally {
/* 316 */             this.updating = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean wasGarbageCollected() {
/* 324 */       return (this.propertyRef1.get() == null || this.propertyRef2.get() == null);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 329 */       ObservableMap observableMap1 = this.propertyRef1.get();
/* 330 */       ObservableMap observableMap2 = this.propertyRef2.get();
/* 331 */       byte b1 = (observableMap1 == null) ? 0 : observableMap1.hashCode();
/* 332 */       byte b2 = (observableMap2 == null) ? 0 : observableMap2.hashCode();
/* 333 */       return b1 * b2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object param1Object) {
/* 338 */       if (this == param1Object) {
/* 339 */         return true;
/*     */       }
/*     */       
/* 342 */       Object object1 = this.propertyRef1.get();
/* 343 */       Object object2 = this.propertyRef2.get();
/* 344 */       if (object1 == null || object2 == null) {
/* 345 */         return false;
/*     */       }
/*     */       
/* 348 */       if (param1Object instanceof MapContentBinding) {
/* 349 */         MapContentBinding mapContentBinding = (MapContentBinding)param1Object;
/* 350 */         Object object3 = mapContentBinding.propertyRef1.get();
/* 351 */         Object object4 = mapContentBinding.propertyRef2.get();
/* 352 */         if (object3 == null || object4 == null) {
/* 353 */           return false;
/*     */         }
/*     */         
/* 356 */         if (object1 == object3 && object2 == object4) {
/* 357 */           return true;
/*     */         }
/* 359 */         if (object1 == object4 && object2 == object3) {
/* 360 */           return true;
/*     */         }
/*     */       } 
/* 363 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\binding\BidirectionalContentBinding.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */