/*     */ package com.sun.javafx.binding;
/*     */ 
/*     */ import com.sun.javafx.collections.NonIterableChange;
/*     */ import com.sun.javafx.collections.SourceAdapterChange;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableListValue;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ObservableList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListExpressionHelper<E>
/*     */   extends ExpressionHelperBase
/*     */ {
/*     */   protected final ObservableListValue<E> observable;
/*     */   
/*     */   public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, InvalidationListener paramInvalidationListener) {
/*  59 */     if (paramObservableListValue == null || paramInvalidationListener == null) {
/*  60 */       throw new NullPointerException();
/*     */     }
/*  62 */     paramObservableListValue.getValue();
/*  63 */     return (paramListExpressionHelper == null) ? new SingleInvalidation<>(paramObservableListValue, paramInvalidationListener) : paramListExpressionHelper.addListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, InvalidationListener paramInvalidationListener) {
/*  67 */     if (paramInvalidationListener == null) {
/*  68 */       throw new NullPointerException();
/*     */     }
/*  70 */     return (paramListExpressionHelper == null) ? null : paramListExpressionHelper.removeListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, ChangeListener<? super ObservableList<E>> paramChangeListener) {
/*  74 */     if (paramObservableListValue == null || paramChangeListener == null) {
/*  75 */       throw new NullPointerException();
/*     */     }
/*  77 */     return (paramListExpressionHelper == null) ? new SingleChange<>(paramObservableListValue, paramChangeListener) : paramListExpressionHelper.addListener(paramChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, ChangeListener<? super ObservableList<E>> paramChangeListener) {
/*  81 */     if (paramChangeListener == null) {
/*  82 */       throw new NullPointerException();
/*     */     }
/*  84 */     return (paramListExpressionHelper == null) ? null : paramListExpressionHelper.removeListener(paramChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> ListExpressionHelper<E> addListener(ListExpressionHelper<E> paramListExpressionHelper, ObservableListValue<E> paramObservableListValue, ListChangeListener<? super E> paramListChangeListener) {
/*  88 */     if (paramObservableListValue == null || paramListChangeListener == null) {
/*  89 */       throw new NullPointerException();
/*     */     }
/*  91 */     return (paramListExpressionHelper == null) ? new SingleListChange<>(paramObservableListValue, paramListChangeListener) : paramListExpressionHelper.addListener(paramListChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> ListExpressionHelper<E> removeListener(ListExpressionHelper<E> paramListExpressionHelper, ListChangeListener<? super E> paramListChangeListener) {
/*  95 */     if (paramListChangeListener == null) {
/*  96 */       throw new NullPointerException();
/*     */     }
/*  98 */     return (paramListExpressionHelper == null) ? null : paramListExpressionHelper.removeListener(paramListChangeListener);
/*     */   }
/*     */   
/*     */   public static <E> void fireValueChangedEvent(ListExpressionHelper<E> paramListExpressionHelper) {
/* 102 */     if (paramListExpressionHelper != null) {
/* 103 */       paramListExpressionHelper.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */   
/*     */   public static <E> void fireValueChangedEvent(ListExpressionHelper<E> paramListExpressionHelper, ListChangeListener.Change<? extends E> paramChange) {
/* 108 */     if (paramListExpressionHelper != null) {
/* 109 */       paramListExpressionHelper.fireValueChangedEvent(paramChange);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ListExpressionHelper(ObservableListValue<E> paramObservableListValue) {
/* 119 */     this.observable = paramObservableListValue;
/*     */   }
/*     */   
/*     */   protected abstract ListExpressionHelper<E> addListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ListExpressionHelper<E> removeListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> paramChangeListener);
/*     */   
/*     */   protected abstract ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> paramChangeListener);
/*     */   
/*     */   protected abstract ListExpressionHelper<E> addListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   protected abstract ListExpressionHelper<E> removeListener(ListChangeListener<? super E> paramListChangeListener);
/*     */   
/*     */   protected abstract void fireValueChangedEvent();
/*     */   
/*     */   protected abstract void fireValueChangedEvent(ListChangeListener.Change<? extends E> paramChange);
/*     */   
/*     */   private static class SingleInvalidation<E> extends ListExpressionHelper<E> {
/*     */     private final InvalidationListener listener;
/*     */     
/*     */     private SingleInvalidation(ObservableListValue<E> param1ObservableListValue, InvalidationListener param1InvalidationListener) {
/* 142 */       super(param1ObservableListValue);
/* 143 */       this.listener = param1InvalidationListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 148 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 153 */       return param1InvalidationListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 158 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1ChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 163 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 168 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 173 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 178 */       this.listener.invalidated((Observable)this.observable);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/* 183 */       this.listener.invalidated((Observable)this.observable);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleChange<E>
/*     */     extends ListExpressionHelper<E> {
/*     */     private final ChangeListener<? super ObservableList<E>> listener;
/*     */     private ObservableList<E> currentValue;
/*     */     
/*     */     private SingleChange(ObservableListValue<E> param1ObservableListValue, ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 193 */       super(param1ObservableListValue);
/* 194 */       this.listener = param1ChangeListener;
/* 195 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 200 */       return new ListExpressionHelper.Generic<>(this.observable, param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 210 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1ChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 215 */       return param1ChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 220 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 225 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 230 */       ObservableList<E> observableList = this.currentValue;
/* 231 */       this.currentValue = (ObservableList<E>)this.observable.getValue();
/* 232 */       if (this.currentValue != observableList) {
/* 233 */         this.listener.changed((ObservableValue)this.observable, observableList, this.currentValue);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/* 239 */       this.listener.changed((ObservableValue)this.observable, this.currentValue, this.currentValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleListChange<E>
/*     */     extends ListExpressionHelper<E> {
/*     */     private final ListChangeListener<? super E> listener;
/*     */     private ObservableList<E> currentValue;
/*     */     
/*     */     private SingleListChange(ObservableListValue<E> param1ObservableListValue, ListChangeListener<? super E> param1ListChangeListener) {
/* 249 */       super(param1ObservableListValue);
/* 250 */       this.listener = param1ListChangeListener;
/* 251 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 256 */       return new ListExpressionHelper.Generic<>(this.observable, param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 266 */       return new ListExpressionHelper.Generic<>(this.observable, param1ChangeListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 271 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 276 */       return new ListExpressionHelper.Generic<>(this.observable, this.listener, param1ListChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 281 */       return param1ListChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 286 */       ObservableList<E> observableList = this.currentValue;
/* 287 */       this.currentValue = (ObservableList<E>)this.observable.getValue();
/* 288 */       if (this.currentValue != observableList) {
/* 289 */         boolean bool = (this.currentValue == null) ? false : this.currentValue.size();
/*     */ 
/*     */         
/* 292 */         ObservableList observableList1 = (observableList == null) ? FXCollections.emptyObservableList() : FXCollections.unmodifiableObservableList(observableList);
/* 293 */         NonIterableChange.GenericAddRemoveChange genericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange(0, bool, (List)observableList1, (ObservableList)this.observable);
/* 294 */         this.listener.onChanged((ListChangeListener.Change)genericAddRemoveChange);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/* 300 */       this.listener.onChanged((ListChangeListener.Change)new SourceAdapterChange((ObservableList)this.observable, param1Change));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Generic<E>
/*     */     extends ListExpressionHelper<E> {
/*     */     private InvalidationListener[] invalidationListeners;
/*     */     private ChangeListener<? super ObservableList<E>>[] changeListeners;
/*     */     private ListChangeListener<? super E>[] listChangeListeners;
/*     */     private int invalidationSize;
/*     */     private int changeSize;
/*     */     private int listChangeSize;
/*     */     private boolean locked;
/*     */     private ObservableList<E> currentValue;
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, InvalidationListener param1InvalidationListener1, InvalidationListener param1InvalidationListener2) {
/* 316 */       super(param1ObservableListValue);
/* 317 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener1, param1InvalidationListener2 };
/* 318 */       this.invalidationSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, ChangeListener<? super ObservableList<E>> param1ChangeListener1, ChangeListener<? super ObservableList<E>> param1ChangeListener2) {
/* 322 */       super(param1ObservableListValue);
/* 323 */       this.changeListeners = (ChangeListener<? super ObservableList<E>>[])new ChangeListener[] { param1ChangeListener1, param1ChangeListener2 };
/* 324 */       this.changeSize = 2;
/* 325 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, ListChangeListener<? super E> param1ListChangeListener1, ListChangeListener<? super E> param1ListChangeListener2) {
/* 329 */       super(param1ObservableListValue);
/* 330 */       this.listChangeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener1, param1ListChangeListener2 };
/* 331 */       this.listChangeSize = 2;
/* 332 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, InvalidationListener param1InvalidationListener, ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 336 */       super(param1ObservableListValue);
/* 337 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 338 */       this.invalidationSize = 1;
/* 339 */       this.changeListeners = (ChangeListener<? super ObservableList<E>>[])new ChangeListener[] { param1ChangeListener };
/* 340 */       this.changeSize = 1;
/* 341 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, InvalidationListener param1InvalidationListener, ListChangeListener<? super E> param1ListChangeListener) {
/* 345 */       super(param1ObservableListValue);
/* 346 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 347 */       this.invalidationSize = 1;
/* 348 */       this.listChangeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener };
/* 349 */       this.listChangeSize = 1;
/* 350 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */     
/*     */     private Generic(ObservableListValue<E> param1ObservableListValue, ChangeListener<? super ObservableList<E>> param1ChangeListener, ListChangeListener<? super E> param1ListChangeListener) {
/* 354 */       super(param1ObservableListValue);
/* 355 */       this.changeListeners = (ChangeListener<? super ObservableList<E>>[])new ChangeListener[] { param1ChangeListener };
/* 356 */       this.changeSize = 1;
/* 357 */       this.listChangeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener };
/* 358 */       this.listChangeSize = 1;
/* 359 */       this.currentValue = (ObservableList<E>)param1ObservableListValue.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(InvalidationListener param1InvalidationListener) {
/* 364 */       if (this.invalidationListeners == null) {
/* 365 */         this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 366 */         this.invalidationSize = 1;
/*     */       } else {
/* 368 */         int i = this.invalidationListeners.length;
/* 369 */         if (this.locked) {
/* 370 */           int j = (this.invalidationSize < i) ? i : (i * 3 / 2 + 1);
/* 371 */           this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/* 372 */         } else if (this.invalidationSize == i) {
/* 373 */           this.invalidationSize = trim(this.invalidationSize, (Object[])this.invalidationListeners);
/* 374 */           if (this.invalidationSize == i) {
/* 375 */             int j = i * 3 / 2 + 1;
/* 376 */             this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/*     */           } 
/*     */         } 
/* 379 */         this.invalidationListeners[this.invalidationSize++] = param1InvalidationListener;
/*     */       } 
/* 381 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(InvalidationListener param1InvalidationListener) {
/* 386 */       if (this.invalidationListeners != null) {
/* 387 */         for (byte b = 0; b < this.invalidationSize; b++) {
/* 388 */           if (param1InvalidationListener.equals(this.invalidationListeners[b])) {
/* 389 */             if (this.invalidationSize == 1) {
/* 390 */               if (this.changeSize == 1 && this.listChangeSize == 0)
/* 391 */                 return new ListExpressionHelper.SingleChange<>(this.observable, this.changeListeners[0]); 
/* 392 */               if (this.changeSize == 0 && this.listChangeSize == 1) {
/* 393 */                 return new ListExpressionHelper.SingleListChange<>(this.observable, this.listChangeListeners[0]);
/*     */               }
/* 395 */               this.invalidationListeners = null;
/* 396 */               this.invalidationSize = 0; break;
/* 397 */             }  if (this.invalidationSize == 2 && this.changeSize == 0 && this.listChangeSize == 0) {
/* 398 */               return new ListExpressionHelper.SingleInvalidation<>(this.observable, this.invalidationListeners[1 - b]);
/*     */             }
/* 400 */             int i = this.invalidationSize - b - 1;
/* 401 */             InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 402 */             if (this.locked) {
/* 403 */               this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
/* 404 */               System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, b + 1);
/*     */             } 
/* 406 */             if (i > 0) {
/* 407 */               System.arraycopy(arrayOfInvalidationListener, b + 1, this.invalidationListeners, b, i);
/*     */             }
/* 409 */             this.invalidationSize--;
/* 410 */             if (!this.locked) {
/* 411 */               this.invalidationListeners[this.invalidationSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 418 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 423 */       if (this.changeListeners == null) {
/* 424 */         this.changeListeners = (ChangeListener<? super ObservableList<E>>[])new ChangeListener[] { param1ChangeListener };
/* 425 */         this.changeSize = 1;
/*     */       } else {
/* 427 */         int i = this.changeListeners.length;
/* 428 */         if (this.locked) {
/* 429 */           int j = (this.changeSize < i) ? i : (i * 3 / 2 + 1);
/* 430 */           this.changeListeners = Arrays.<ChangeListener<? super ObservableList<E>>>copyOf(this.changeListeners, j);
/* 431 */         } else if (this.changeSize == i) {
/* 432 */           this.changeSize = trim(this.changeSize, (Object[])this.changeListeners);
/* 433 */           if (this.changeSize == i) {
/* 434 */             int j = i * 3 / 2 + 1;
/* 435 */             this.changeListeners = Arrays.<ChangeListener<? super ObservableList<E>>>copyOf(this.changeListeners, j);
/*     */           } 
/*     */         } 
/* 438 */         this.changeListeners[this.changeSize++] = param1ChangeListener;
/*     */       } 
/* 440 */       if (this.changeSize == 1) {
/* 441 */         this.currentValue = (ObservableList<E>)this.observable.getValue();
/*     */       }
/* 443 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ChangeListener<? super ObservableList<E>> param1ChangeListener) {
/* 448 */       if (this.changeListeners != null) {
/* 449 */         for (byte b = 0; b < this.changeSize; b++) {
/* 450 */           if (param1ChangeListener.equals(this.changeListeners[b])) {
/* 451 */             if (this.changeSize == 1) {
/* 452 */               if (this.invalidationSize == 1 && this.listChangeSize == 0)
/* 453 */                 return new ListExpressionHelper.SingleInvalidation<>(this.observable, this.invalidationListeners[0]); 
/* 454 */               if (this.invalidationSize == 0 && this.listChangeSize == 1) {
/* 455 */                 return new ListExpressionHelper.SingleListChange<>(this.observable, this.listChangeListeners[0]);
/*     */               }
/* 457 */               this.changeListeners = null;
/* 458 */               this.changeSize = 0; break;
/* 459 */             }  if (this.changeSize == 2 && this.invalidationSize == 0 && this.listChangeSize == 0) {
/* 460 */               return new ListExpressionHelper.SingleChange<>(this.observable, this.changeListeners[1 - b]);
/*     */             }
/* 462 */             int i = this.changeSize - b - 1;
/* 463 */             ChangeListener<? super ObservableList<E>>[] arrayOfChangeListener = this.changeListeners;
/* 464 */             if (this.locked) {
/* 465 */               this.changeListeners = (ChangeListener<? super ObservableList<E>>[])new ChangeListener[this.changeListeners.length];
/* 466 */               System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, b + 1);
/*     */             } 
/* 468 */             if (i > 0) {
/* 469 */               System.arraycopy(arrayOfChangeListener, b + 1, this.changeListeners, b, i);
/*     */             }
/* 471 */             this.changeSize--;
/* 472 */             if (!this.locked) {
/* 473 */               this.changeListeners[this.changeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 480 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> addListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 485 */       if (this.listChangeListeners == null) {
/* 486 */         this.listChangeListeners = (ListChangeListener<? super E>[])new ListChangeListener[] { param1ListChangeListener };
/* 487 */         this.listChangeSize = 1;
/*     */       } else {
/* 489 */         int i = this.listChangeListeners.length;
/* 490 */         if (this.locked) {
/* 491 */           int j = (this.listChangeSize < i) ? i : (i * 3 / 2 + 1);
/* 492 */           this.listChangeListeners = Arrays.<ListChangeListener<? super E>>copyOf(this.listChangeListeners, j);
/* 493 */         } else if (this.listChangeSize == i) {
/* 494 */           this.listChangeSize = trim(this.listChangeSize, (Object[])this.listChangeListeners);
/* 495 */           if (this.listChangeSize == i) {
/* 496 */             int j = i * 3 / 2 + 1;
/* 497 */             this.listChangeListeners = Arrays.<ListChangeListener<? super E>>copyOf(this.listChangeListeners, j);
/*     */           } 
/*     */         } 
/* 500 */         this.listChangeListeners[this.listChangeSize++] = param1ListChangeListener;
/*     */       } 
/* 502 */       if (this.listChangeSize == 1) {
/* 503 */         this.currentValue = (ObservableList<E>)this.observable.getValue();
/*     */       }
/* 505 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ListExpressionHelper<E> removeListener(ListChangeListener<? super E> param1ListChangeListener) {
/* 510 */       if (this.listChangeListeners != null) {
/* 511 */         for (byte b = 0; b < this.listChangeSize; b++) {
/* 512 */           if (param1ListChangeListener.equals(this.listChangeListeners[b])) {
/* 513 */             if (this.listChangeSize == 1) {
/* 514 */               if (this.invalidationSize == 1 && this.changeSize == 0)
/* 515 */                 return new ListExpressionHelper.SingleInvalidation<>(this.observable, this.invalidationListeners[0]); 
/* 516 */               if (this.invalidationSize == 0 && this.changeSize == 1) {
/* 517 */                 return new ListExpressionHelper.SingleChange<>(this.observable, this.changeListeners[0]);
/*     */               }
/* 519 */               this.listChangeListeners = null;
/* 520 */               this.listChangeSize = 0; break;
/* 521 */             }  if (this.listChangeSize == 2 && this.invalidationSize == 0 && this.changeSize == 0) {
/* 522 */               return new ListExpressionHelper.SingleListChange<>(this.observable, this.listChangeListeners[1 - b]);
/*     */             }
/* 524 */             int i = this.listChangeSize - b - 1;
/* 525 */             ListChangeListener<? super E>[] arrayOfListChangeListener = this.listChangeListeners;
/* 526 */             if (this.locked) {
/* 527 */               this.listChangeListeners = (ListChangeListener<? super E>[])new ListChangeListener[this.listChangeListeners.length];
/* 528 */               System.arraycopy(arrayOfListChangeListener, 0, this.listChangeListeners, 0, b + 1);
/*     */             } 
/* 530 */             if (i > 0) {
/* 531 */               System.arraycopy(arrayOfListChangeListener, b + 1, this.listChangeListeners, b, i);
/*     */             }
/* 533 */             this.listChangeSize--;
/* 534 */             if (!this.locked) {
/* 535 */               this.listChangeListeners[this.listChangeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 542 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 547 */       if (this.changeSize == 0 && this.listChangeSize == 0) {
/* 548 */         notifyListeners(this.currentValue, (ListChangeListener.Change<E>)null, false);
/*     */       } else {
/* 550 */         ObservableList<E> observableList = this.currentValue;
/* 551 */         this.currentValue = (ObservableList<E>)this.observable.getValue();
/* 552 */         if (this.currentValue != observableList) {
/* 553 */           NonIterableChange.GenericAddRemoveChange genericAddRemoveChange = null;
/* 554 */           if (this.listChangeSize > 0) {
/* 555 */             boolean bool = (this.currentValue == null) ? false : this.currentValue.size();
/*     */ 
/*     */             
/* 558 */             ObservableList observableList1 = (observableList == null) ? FXCollections.emptyObservableList() : FXCollections.unmodifiableObservableList(observableList);
/* 559 */             genericAddRemoveChange = new NonIterableChange.GenericAddRemoveChange(0, bool, (List)observableList1, (ObservableList)this.observable);
/*     */           } 
/* 561 */           notifyListeners(observableList, (ListChangeListener.Change<E>)genericAddRemoveChange, false);
/*     */         } else {
/* 563 */           notifyListeners(this.currentValue, (ListChangeListener.Change<E>)null, true);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent(ListChangeListener.Change<? extends E> param1Change) {
/* 570 */       SourceAdapterChange sourceAdapterChange = (this.listChangeSize == 0) ? null : new SourceAdapterChange((ObservableList)this.observable, param1Change);
/* 571 */       notifyListeners(this.currentValue, (ListChangeListener.Change<E>)sourceAdapterChange, false);
/*     */     }
/*     */     
/*     */     private void notifyListeners(ObservableList<E> param1ObservableList, ListChangeListener.Change<E> param1Change, boolean param1Boolean) {
/* 575 */       InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 576 */       int i = this.invalidationSize;
/* 577 */       ChangeListener<? super ObservableList<E>>[] arrayOfChangeListener = this.changeListeners;
/* 578 */       int j = this.changeSize;
/* 579 */       ListChangeListener<? super E>[] arrayOfListChangeListener = this.listChangeListeners;
/* 580 */       int k = this.listChangeSize;
/*     */       try {
/* 582 */         this.locked = true; byte b;
/* 583 */         for (b = 0; b < i; b++) {
/* 584 */           arrayOfInvalidationListener[b].invalidated((Observable)this.observable);
/*     */         }
/* 586 */         if (!param1Boolean) {
/* 587 */           for (b = 0; b < j; b++) {
/* 588 */             arrayOfChangeListener[b].changed((ObservableValue)this.observable, param1ObservableList, this.currentValue);
/*     */           }
/* 590 */           if (param1Change != null) {
/* 591 */             for (b = 0; b < k; b++) {
/* 592 */               param1Change.reset();
/* 593 */               arrayOfListChangeListener[b].onChanged(param1Change);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } finally {
/* 598 */         this.locked = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\binding\ListExpressionHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */