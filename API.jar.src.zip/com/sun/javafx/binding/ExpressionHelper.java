/*     */ package com.sun.javafx.binding;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javafx.beans.InvalidationListener;
/*     */ import javafx.beans.Observable;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ExpressionHelper<T>
/*     */   extends ExpressionHelperBase
/*     */ {
/*     */   protected final ObservableValue<T> observable;
/*     */   
/*     */   public static <T> ExpressionHelper<T> addListener(ExpressionHelper<T> paramExpressionHelper, ObservableValue<T> paramObservableValue, InvalidationListener paramInvalidationListener) {
/*  50 */     if (paramObservableValue == null || paramInvalidationListener == null) {
/*  51 */       throw new NullPointerException();
/*     */     }
/*  53 */     paramObservableValue.getValue();
/*  54 */     return (paramExpressionHelper == null) ? new SingleInvalidation<>(paramObservableValue, paramInvalidationListener) : paramExpressionHelper.addListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <T> ExpressionHelper<T> removeListener(ExpressionHelper<T> paramExpressionHelper, InvalidationListener paramInvalidationListener) {
/*  58 */     if (paramInvalidationListener == null) {
/*  59 */       throw new NullPointerException();
/*     */     }
/*  61 */     return (paramExpressionHelper == null) ? null : paramExpressionHelper.removeListener(paramInvalidationListener);
/*     */   }
/*     */   
/*     */   public static <T> ExpressionHelper<T> addListener(ExpressionHelper<T> paramExpressionHelper, ObservableValue<T> paramObservableValue, ChangeListener<? super T> paramChangeListener) {
/*  65 */     if (paramObservableValue == null || paramChangeListener == null) {
/*  66 */       throw new NullPointerException();
/*     */     }
/*  68 */     return (paramExpressionHelper == null) ? new SingleChange<>(paramObservableValue, paramChangeListener) : paramExpressionHelper.addListener(paramChangeListener);
/*     */   }
/*     */   
/*     */   public static <T> ExpressionHelper<T> removeListener(ExpressionHelper<T> paramExpressionHelper, ChangeListener<? super T> paramChangeListener) {
/*  72 */     if (paramChangeListener == null) {
/*  73 */       throw new NullPointerException();
/*     */     }
/*  75 */     return (paramExpressionHelper == null) ? null : paramExpressionHelper.removeListener(paramChangeListener);
/*     */   }
/*     */   
/*     */   public static <T> void fireValueChangedEvent(ExpressionHelper<T> paramExpressionHelper) {
/*  79 */     if (paramExpressionHelper != null) {
/*  80 */       paramExpressionHelper.fireValueChangedEvent();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExpressionHelper(ObservableValue<T> paramObservableValue) {
/*  90 */     this.observable = paramObservableValue;
/*     */   }
/*     */   
/*     */   protected abstract ExpressionHelper<T> addListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ExpressionHelper<T> removeListener(InvalidationListener paramInvalidationListener);
/*     */   
/*     */   protected abstract ExpressionHelper<T> addListener(ChangeListener<? super T> paramChangeListener);
/*     */   
/*     */   protected abstract ExpressionHelper<T> removeListener(ChangeListener<? super T> paramChangeListener);
/*     */   
/*     */   protected abstract void fireValueChangedEvent();
/*     */   
/*     */   private static class SingleInvalidation<T>
/*     */     extends ExpressionHelper<T>
/*     */   {
/*     */     private final InvalidationListener listener;
/*     */     
/*     */     private SingleInvalidation(ObservableValue<T> param1ObservableValue, InvalidationListener param1InvalidationListener) {
/* 109 */       super(param1ObservableValue);
/* 110 */       this.listener = param1InvalidationListener;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> addListener(InvalidationListener param1InvalidationListener) {
/* 115 */       return new ExpressionHelper.Generic<>(this.observable, this.listener, param1InvalidationListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(InvalidationListener param1InvalidationListener) {
/* 120 */       return param1InvalidationListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> addListener(ChangeListener<? super T> param1ChangeListener) {
/* 125 */       return new ExpressionHelper.Generic<>(this.observable, this.listener, param1ChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(ChangeListener<? super T> param1ChangeListener) {
/* 130 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/*     */       try {
/* 136 */         this.listener.invalidated((Observable)this.observable);
/* 137 */       } catch (Exception exception) {
/* 138 */         Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private static class SingleChange<T>
/*     */     extends ExpressionHelper<T> {
/*     */     private final ChangeListener<? super T> listener;
/*     */     private T currentValue;
/*     */     
/*     */     private SingleChange(ObservableValue<T> param1ObservableValue, ChangeListener<? super T> param1ChangeListener) {
/* 149 */       super(param1ObservableValue);
/* 150 */       this.listener = param1ChangeListener;
/* 151 */       this.currentValue = (T)param1ObservableValue.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> addListener(InvalidationListener param1InvalidationListener) {
/* 156 */       return new ExpressionHelper.Generic<>(this.observable, param1InvalidationListener, this.listener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(InvalidationListener param1InvalidationListener) {
/* 161 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> addListener(ChangeListener<? super T> param1ChangeListener) {
/* 166 */       return new ExpressionHelper.Generic<>(this.observable, this.listener, param1ChangeListener);
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(ChangeListener<? super T> param1ChangeListener) {
/* 171 */       return param1ChangeListener.equals(this.listener) ? null : this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 176 */       T t = this.currentValue;
/* 177 */       this.currentValue = (T)this.observable.getValue();
/* 178 */       boolean bool = (this.currentValue == null) ? ((t != null) ? true : false) : (!this.currentValue.equals(t) ? true : false);
/* 179 */       if (bool)
/*     */         try {
/* 181 */           this.listener.changed(this.observable, t, this.currentValue);
/* 182 */         } catch (Exception exception) {
/* 183 */           Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */         }  
/*     */     }
/*     */   }
/*     */   
/*     */   private static class Generic<T>
/*     */     extends ExpressionHelper<T>
/*     */   {
/*     */     private InvalidationListener[] invalidationListeners;
/*     */     private ChangeListener<? super T>[] changeListeners;
/*     */     private int invalidationSize;
/*     */     private int changeSize;
/*     */     private boolean locked;
/*     */     private T currentValue;
/*     */     
/*     */     private Generic(ObservableValue<T> param1ObservableValue, InvalidationListener param1InvalidationListener1, InvalidationListener param1InvalidationListener2) {
/* 199 */       super(param1ObservableValue);
/* 200 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener1, param1InvalidationListener2 };
/* 201 */       this.invalidationSize = 2;
/*     */     }
/*     */     
/*     */     private Generic(ObservableValue<T> param1ObservableValue, ChangeListener<? super T> param1ChangeListener1, ChangeListener<? super T> param1ChangeListener2) {
/* 205 */       super(param1ObservableValue);
/* 206 */       this.changeListeners = (ChangeListener<? super T>[])new ChangeListener[] { param1ChangeListener1, param1ChangeListener2 };
/* 207 */       this.changeSize = 2;
/* 208 */       this.currentValue = (T)param1ObservableValue.getValue();
/*     */     }
/*     */     
/*     */     private Generic(ObservableValue<T> param1ObservableValue, InvalidationListener param1InvalidationListener, ChangeListener<? super T> param1ChangeListener) {
/* 212 */       super(param1ObservableValue);
/* 213 */       this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 214 */       this.invalidationSize = 1;
/* 215 */       this.changeListeners = (ChangeListener<? super T>[])new ChangeListener[] { param1ChangeListener };
/* 216 */       this.changeSize = 1;
/* 217 */       this.currentValue = (T)param1ObservableValue.getValue();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Generic<T> addListener(InvalidationListener param1InvalidationListener) {
/* 222 */       if (this.invalidationListeners == null) {
/* 223 */         this.invalidationListeners = new InvalidationListener[] { param1InvalidationListener };
/* 224 */         this.invalidationSize = 1;
/*     */       } else {
/* 226 */         int i = this.invalidationListeners.length;
/* 227 */         if (this.locked) {
/* 228 */           int j = (this.invalidationSize < i) ? i : (i * 3 / 2 + 1);
/* 229 */           this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/* 230 */         } else if (this.invalidationSize == i) {
/* 231 */           this.invalidationSize = trim(this.invalidationSize, (Object[])this.invalidationListeners);
/* 232 */           if (this.invalidationSize == i) {
/* 233 */             int j = i * 3 / 2 + 1;
/* 234 */             this.invalidationListeners = Arrays.<InvalidationListener>copyOf(this.invalidationListeners, j);
/*     */           } 
/*     */         } 
/* 237 */         this.invalidationListeners[this.invalidationSize++] = param1InvalidationListener;
/*     */       } 
/* 239 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(InvalidationListener param1InvalidationListener) {
/* 244 */       if (this.invalidationListeners != null) {
/* 245 */         for (byte b = 0; b < this.invalidationSize; b++) {
/* 246 */           if (param1InvalidationListener.equals(this.invalidationListeners[b])) {
/* 247 */             if (this.invalidationSize == 1) {
/* 248 */               if (this.changeSize == 1) {
/* 249 */                 return new ExpressionHelper.SingleChange<>(this.observable, this.changeListeners[0]);
/*     */               }
/* 251 */               this.invalidationListeners = null;
/* 252 */               this.invalidationSize = 0; break;
/* 253 */             }  if (this.invalidationSize == 2 && this.changeSize == 0) {
/* 254 */               return new ExpressionHelper.SingleInvalidation<>(this.observable, this.invalidationListeners[1 - b]);
/*     */             }
/* 256 */             int i = this.invalidationSize - b - 1;
/* 257 */             InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 258 */             if (this.locked) {
/* 259 */               this.invalidationListeners = new InvalidationListener[this.invalidationListeners.length];
/* 260 */               System.arraycopy(arrayOfInvalidationListener, 0, this.invalidationListeners, 0, b);
/*     */             } 
/* 262 */             if (i > 0) {
/* 263 */               System.arraycopy(arrayOfInvalidationListener, b + 1, this.invalidationListeners, b, i);
/*     */             }
/* 265 */             this.invalidationSize--;
/* 266 */             if (!this.locked) {
/* 267 */               this.invalidationListeners[this.invalidationSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 274 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> addListener(ChangeListener<? super T> param1ChangeListener) {
/* 279 */       if (this.changeListeners == null) {
/* 280 */         this.changeListeners = (ChangeListener<? super T>[])new ChangeListener[] { param1ChangeListener };
/* 281 */         this.changeSize = 1;
/*     */       } else {
/* 283 */         int i = this.changeListeners.length;
/* 284 */         if (this.locked) {
/* 285 */           int j = (this.changeSize < i) ? i : (i * 3 / 2 + 1);
/* 286 */           this.changeListeners = Arrays.<ChangeListener<? super T>>copyOf(this.changeListeners, j);
/* 287 */         } else if (this.changeSize == i) {
/* 288 */           this.changeSize = trim(this.changeSize, (Object[])this.changeListeners);
/* 289 */           if (this.changeSize == i) {
/* 290 */             int j = i * 3 / 2 + 1;
/* 291 */             this.changeListeners = Arrays.<ChangeListener<? super T>>copyOf(this.changeListeners, j);
/*     */           } 
/*     */         } 
/* 294 */         this.changeListeners[this.changeSize++] = param1ChangeListener;
/*     */       } 
/* 296 */       if (this.changeSize == 1) {
/* 297 */         this.currentValue = (T)this.observable.getValue();
/*     */       }
/* 299 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected ExpressionHelper<T> removeListener(ChangeListener<? super T> param1ChangeListener) {
/* 304 */       if (this.changeListeners != null) {
/* 305 */         for (byte b = 0; b < this.changeSize; b++) {
/* 306 */           if (param1ChangeListener.equals(this.changeListeners[b])) {
/* 307 */             if (this.changeSize == 1) {
/* 308 */               if (this.invalidationSize == 1) {
/* 309 */                 return new ExpressionHelper.SingleInvalidation<>(this.observable, this.invalidationListeners[0]);
/*     */               }
/* 311 */               this.changeListeners = null;
/* 312 */               this.changeSize = 0; break;
/* 313 */             }  if (this.changeSize == 2 && this.invalidationSize == 0) {
/* 314 */               return new ExpressionHelper.SingleChange<>(this.observable, this.changeListeners[1 - b]);
/*     */             }
/* 316 */             int i = this.changeSize - b - 1;
/* 317 */             ChangeListener<? super T>[] arrayOfChangeListener = this.changeListeners;
/* 318 */             if (this.locked) {
/* 319 */               this.changeListeners = (ChangeListener<? super T>[])new ChangeListener[this.changeListeners.length];
/* 320 */               System.arraycopy(arrayOfChangeListener, 0, this.changeListeners, 0, b);
/*     */             } 
/* 322 */             if (i > 0) {
/* 323 */               System.arraycopy(arrayOfChangeListener, b + 1, this.changeListeners, b, i);
/*     */             }
/* 325 */             this.changeSize--;
/* 326 */             if (!this.locked) {
/* 327 */               this.changeListeners[this.changeSize] = null;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 334 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void fireValueChangedEvent() {
/* 339 */       InvalidationListener[] arrayOfInvalidationListener = this.invalidationListeners;
/* 340 */       int i = this.invalidationSize;
/* 341 */       ChangeListener<? super T>[] arrayOfChangeListener = this.changeListeners;
/* 342 */       int j = this.changeSize;
/*     */       
/*     */       try {
/* 345 */         this.locked = true;
/* 346 */         for (byte b = 0; b < i; b++) {
/*     */           try {
/* 348 */             arrayOfInvalidationListener[b].invalidated((Observable)this.observable);
/* 349 */           } catch (Exception exception) {
/* 350 */             Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */           } 
/*     */         } 
/* 353 */         if (j > 0) {
/* 354 */           T t = this.currentValue;
/* 355 */           this.currentValue = (T)this.observable.getValue();
/* 356 */           boolean bool = (this.currentValue == null) ? ((t != null) ? true : false) : (!this.currentValue.equals(t) ? true : false);
/* 357 */           if (bool) {
/* 358 */             for (byte b1 = 0; b1 < j; b1++) {
/*     */               try {
/* 360 */                 arrayOfChangeListener[b1].changed(this.observable, t, this.currentValue);
/* 361 */               } catch (Exception exception) {
/* 362 */                 Thread.currentThread().getUncaughtExceptionHandler().uncaughtException(Thread.currentThread(), exception);
/*     */               } 
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } finally {
/* 368 */         this.locked = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\javafx\binding\ExpressionHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */