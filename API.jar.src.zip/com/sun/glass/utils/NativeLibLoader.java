/*     */ package com.sun.glass.utils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.security.AccessController;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeLibLoader
/*     */ {
/*  46 */   private static final HashSet<String> loaded = new HashSet<>();
/*     */   
/*     */   public static synchronized void loadLibrary(String paramString) {
/*  49 */     if (!loaded.contains(paramString)) {
/*     */       
/*  51 */       StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*     */       
/*  53 */       Class<?> clazz = stackWalker.getCallerClass();
/*  54 */       loadLibraryInternal(paramString, null, clazz);
/*  55 */       loaded.add(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static synchronized void loadLibrary(String paramString, List<String> paramList) {
/*  60 */     if (!loaded.contains(paramString)) {
/*     */       
/*  62 */       StackWalker stackWalker = AccessController.<StackWalker>doPrivileged(() -> StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE));
/*     */       
/*  64 */       Class<?> clazz = stackWalker.getCallerClass();
/*  65 */       loadLibraryInternal(paramString, paramList, clazz);
/*  66 */       loaded.add(paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean verbose = false;
/*  72 */   private static File libDir = null;
/*  73 */   private static String libPrefix = "";
/*  74 */   private static String libSuffix = "";
/*     */ 
/*     */   
/*     */   static {
/*  78 */     Object object = AccessController.doPrivileged(() -> {
/*     */           verbose = Boolean.getBoolean("javafx.verbose");
/*     */           return null;
/*     */         });
/*     */   }
/*     */   
/*     */   private static String[] initializePath(String paramString) {
/*  85 */     String str1 = System.getProperty(paramString, "");
/*  86 */     String str2 = File.pathSeparator;
/*  87 */     int i = str1.length();
/*     */ 
/*     */     
/*  90 */     int j = str1.indexOf(str2);
/*  91 */     int m = 0;
/*  92 */     while (j >= 0) {
/*  93 */       m++;
/*  94 */       j = str1.indexOf(str2, j + 1);
/*     */     } 
/*     */ 
/*     */     
/*  98 */     String[] arrayOfString = new String[m + 1];
/*     */ 
/*     */     
/* 101 */     m = j = 0;
/* 102 */     int k = str1.indexOf(str2);
/* 103 */     while (k >= 0) {
/* 104 */       if (k - j > 0) {
/* 105 */         arrayOfString[m++] = str1.substring(j, k);
/* 106 */       } else if (k - j == 0) {
/* 107 */         arrayOfString[m++] = ".";
/*     */       } 
/* 109 */       j = k + 1;
/* 110 */       k = str1.indexOf(str2, j);
/*     */     } 
/* 112 */     arrayOfString[m] = str1.substring(j, i);
/* 113 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadLibraryInternal(String paramString, List<String> paramList, Class paramClass) {
/*     */     try {
/* 131 */       loadLibraryFullPath(paramString);
/* 132 */     } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 133 */       if (verbose) {
/* 134 */         System.err.println("WARNING: " + unsatisfiedLinkError);
/*     */       }
/*     */ 
/*     */       
/* 138 */       if (loadLibraryFromResource(paramString, paramList, paramClass)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 146 */       String[] arrayOfString = initializePath("java.library.path");
/* 147 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*     */         try {
/* 149 */           String str1 = arrayOfString[b];
/* 150 */           if (!str1.endsWith(File.separator)) str1 = str1 + str1; 
/* 151 */           String str2 = System.mapLibraryName(paramString);
/* 152 */           File file = new File(str1 + str1);
/* 153 */           System.load(file.getAbsolutePath());
/* 154 */           if (verbose) {
/* 155 */             System.err.println("Loaded " + file.getAbsolutePath() + " from java.library.path");
/*     */           }
/*     */           
/*     */           return;
/* 159 */         } catch (UnsatisfiedLinkError unsatisfiedLinkError1) {}
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 166 */         System.loadLibrary(paramString);
/* 167 */         if (verbose) {
/* 168 */           System.err.println("System.loadLibrary(" + paramString + ") succeeded");
/*     */         }
/*     */       }
/* 171 */       catch (UnsatisfiedLinkError unsatisfiedLinkError1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 176 */         if ("ios".equals(System.getProperty("os.name").toLowerCase(Locale.ROOT)) && paramString
/* 177 */           .contains("-")) {
/* 178 */           paramString = paramString.replace("-", "_");
/*     */           try {
/* 180 */             System.loadLibrary(paramString);
/*     */             return;
/* 182 */           } catch (UnsatisfiedLinkError unsatisfiedLinkError2) {
/* 183 */             throw unsatisfiedLinkError2;
/*     */           } 
/*     */         } 
/*     */         
/* 187 */         throw unsatisfiedLinkError1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean loadLibraryFromResource(String paramString, List<String> paramList, Class paramClass) {
/* 197 */     return installLibraryFromResource(paramString, paramList, paramClass, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean installLibraryFromResource(String paramString, List<String> paramList, Class paramClass, boolean paramBoolean) {
/*     */     try {
/* 207 */       if (paramList != null) {
/* 208 */         for (String str1 : paramList) {
/* 209 */           boolean bool = installLibraryFromResource(str1, null, paramClass, false);
/*     */         }
/*     */       }
/* 212 */       String str = "/" + System.mapLibraryName(paramString);
/* 213 */       InputStream inputStream = paramClass.getResourceAsStream(str);
/* 214 */       if (inputStream != null) {
/* 215 */         String str1 = cacheLibrary(inputStream, str, paramClass);
/* 216 */         if (paramBoolean) {
/* 217 */           System.load(str1);
/* 218 */           if (verbose) {
/* 219 */             System.err.println("Loaded library " + str + " from resource");
/*     */           }
/* 221 */         } else if (verbose) {
/* 222 */           System.err.println("Unpacked library " + str + " from resource");
/*     */         } 
/* 224 */         return true;
/*     */       } 
/* 226 */     } catch (Throwable throwable) {
/*     */ 
/*     */       
/* 229 */       System.err.println("Loading library " + paramString + " from resource failed: " + throwable);
/* 230 */       throwable.printStackTrace();
/*     */     } 
/* 232 */     return false;
/*     */   }
/*     */   
/*     */   private static String cacheLibrary(InputStream paramInputStream, String paramString, Class paramClass) throws IOException {
/* 236 */     String str1 = System.getProperty("javafx.version", "versionless");
/* 237 */     String str2 = System.getProperty("javafx.cachedir", "");
/* 238 */     if (str2.isEmpty()) {
/* 239 */       str2 = System.getProperty("user.home") + "/.openjfx/cache/" + System.getProperty("user.home");
/*     */     }
/* 241 */     File file1 = new File(str2);
/* 242 */     boolean bool1 = true;
/* 243 */     if (file1.exists()) {
/* 244 */       if (!file1.isDirectory()) {
/* 245 */         System.err.println("Cache exists but is not a directory: " + file1);
/* 246 */         bool1 = false;
/*     */       }
/*     */     
/* 249 */     } else if (!file1.mkdirs()) {
/* 250 */       System.err.println("Can not create cache at " + file1);
/* 251 */       bool1 = false;
/*     */     } 
/*     */     
/* 254 */     if (!file1.canRead())
/*     */     {
/* 256 */       bool1 = false;
/*     */     }
/* 258 */     if (!bool1) {
/* 259 */       String str3 = System.getProperty("user.name", "anonymous");
/* 260 */       String str4 = System.getProperty("java.io.tmpdir") + "/.openjfx_" + System.getProperty("java.io.tmpdir") + "/cache/" + str3;
/* 261 */       file1 = new File(str4);
/* 262 */       if (file1.exists()) {
/* 263 */         if (!file1.isDirectory()) {
/* 264 */           throw new IOException("Cache exists but is not a directory: " + file1);
/*     */         }
/*     */       }
/* 267 */       else if (!file1.mkdirs()) {
/* 268 */         throw new IOException("Can not create cache at " + file1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 273 */     File file2 = new File(file1, paramString);
/*     */     
/* 275 */     boolean bool2 = true;
/* 276 */     if (file2.exists()) {
/*     */       byte[] arrayOfByte1;
/*     */       
/*     */       try {
/* 280 */         DigestInputStream digestInputStream = new DigestInputStream(paramInputStream, MessageDigest.getInstance("MD5"));
/* 281 */         digestInputStream.getMessageDigest().reset();
/* 282 */         byte[] arrayOfByte = new byte[4096];
/* 283 */         while (digestInputStream.read(arrayOfByte) != -1);
/* 284 */         arrayOfByte1 = digestInputStream.getMessageDigest().digest();
/* 285 */         paramInputStream.close();
/* 286 */         paramInputStream = paramClass.getResourceAsStream(paramString);
/*     */       }
/* 288 */       catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 289 */         arrayOfByte1 = new byte[1];
/*     */       } 
/* 291 */       byte[] arrayOfByte2 = calculateCheckSum(file2);
/* 292 */       if (!Arrays.equals(arrayOfByte1, arrayOfByte2)) {
/* 293 */         Files.delete(file2.toPath());
/*     */       } else {
/*     */         
/* 296 */         bool2 = false;
/*     */       } 
/*     */     } 
/* 299 */     if (bool2) {
/* 300 */       Path path = file2.toPath();
/* 301 */       Files.copy(paramInputStream, path, new java.nio.file.CopyOption[0]);
/*     */     } 
/*     */     
/* 304 */     return file2.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] calculateCheckSum(File paramFile) {
/*     */     try {
/* 311 */       FileInputStream fileInputStream = new FileInputStream(paramFile); 
/* 312 */       try { DigestInputStream digestInputStream = new DigestInputStream(fileInputStream, MessageDigest.getInstance("MD5")); 
/* 313 */         try { digestInputStream.getMessageDigest().reset();
/* 314 */           byte[] arrayOfByte1 = new byte[4096];
/* 315 */           while (digestInputStream.read(arrayOfByte1) != -1);
/* 316 */           byte[] arrayOfByte2 = digestInputStream.getMessageDigest().digest();
/* 317 */           digestInputStream.close(); fileInputStream.close(); return arrayOfByte2; } catch (Throwable throwable) { try { digestInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (Throwable throwable) { try { fileInputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */     
/* 319 */     } catch (IllegalArgumentException|NoSuchAlgorithmException|IOException|SecurityException illegalArgumentException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 325 */       return new byte[0];
/*     */     } 
/*     */   }
/*     */   
/*     */   private static File libDirForJRT() {
/* 330 */     String str1 = System.getProperty("java.home");
/*     */     
/* 332 */     if (str1 == null || str1.isEmpty()) {
/* 333 */       throw new UnsatisfiedLinkError("Cannot find java.home");
/*     */     }
/*     */ 
/*     */     
/* 337 */     String str2 = System.getProperty("os.name");
/* 338 */     String str3 = null;
/* 339 */     if (str2.startsWith("Windows")) {
/* 340 */       str3 = "bin/javafx";
/* 341 */     } else if (str2.startsWith("Mac")) {
/* 342 */       str3 = "lib";
/* 343 */     } else if (str2.startsWith("Linux")) {
/* 344 */       str3 = "lib";
/*     */     } 
/*     */ 
/*     */     
/* 348 */     return new File(str1 + "/" + str1);
/*     */   }
/*     */ 
/*     */   
/*     */   private static File libDirForJarFile(String paramString) throws Exception {
/* 353 */     String str1 = paramString.substring(4, paramString.lastIndexOf('!'));
/*     */     
/* 355 */     int i = Math.max(str1.lastIndexOf('/'), str1.lastIndexOf('\\'));
/*     */ 
/*     */     
/* 358 */     String str2 = System.getProperty("os.name");
/* 359 */     String str3 = null;
/* 360 */     if (str2.startsWith("Windows")) {
/* 361 */       str3 = "../bin";
/* 362 */     } else if (str2.startsWith("Mac")) {
/* 363 */       str3 = ".";
/* 364 */     } else if (str2.startsWith("Linux")) {
/* 365 */       str3 = ".";
/*     */     } 
/*     */ 
/*     */     
/* 369 */     String str4 = str1.substring(0, i) + "/" + str1.substring(0, i);
/*     */     
/* 371 */     return new File((new URI(str4)).getPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadLibraryFullPath(String paramString) {
/*     */     try {
/* 380 */       if (libDir == null) {
/*     */ 
/*     */         
/* 383 */         String str1 = "NativeLibLoader.class";
/* 384 */         Class<NativeLibLoader> clazz = NativeLibLoader.class;
/* 385 */         String str2 = clazz.getResource(str1).toString();
/* 386 */         if (str2.startsWith("jrt:")) {
/* 387 */           libDir = libDirForJRT();
/* 388 */         } else if (str2.startsWith("jar:file:") && str2.indexOf('!') > 0) {
/* 389 */           libDir = libDirForJarFile(str2);
/*     */         } else {
/* 391 */           throw new UnsatisfiedLinkError("Invalid URL for class: " + str2);
/*     */         } 
/*     */ 
/*     */         
/* 395 */         String str3 = System.getProperty("os.name");
/* 396 */         if (str3.startsWith("Windows")) {
/* 397 */           libPrefix = "";
/* 398 */           libSuffix = ".dll";
/* 399 */         } else if (str3.startsWith("Mac")) {
/* 400 */           libPrefix = "lib";
/* 401 */           libSuffix = ".dylib";
/* 402 */         } else if (str3.startsWith("Linux")) {
/* 403 */           libPrefix = "lib";
/* 404 */           libSuffix = ".so";
/*     */         } 
/*     */       } 
/*     */       
/* 408 */       File file = new File(libDir, libPrefix + libPrefix + paramString);
/* 409 */       String str = file.getCanonicalPath();
/*     */       try {
/* 411 */         System.load(str);
/* 412 */         if (verbose) {
/* 413 */           System.err.println("Loaded " + file.getAbsolutePath() + " from relative path");
/*     */         }
/*     */       }
/* 416 */       catch (UnsatisfiedLinkError unsatisfiedLinkError) {
/* 417 */         throw unsatisfiedLinkError;
/*     */       } 
/* 419 */     } catch (Exception exception) {
/*     */       
/* 421 */       throw (UnsatisfiedLinkError)(new UnsatisfiedLinkError()).initCause(exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\utils\NativeLibLoader.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */