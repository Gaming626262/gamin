/*      */ package com.sun.glass.ui;
/*      */ 
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.security.AccessController;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class View
/*      */ {
/*      */   public static final int GESTURE_NO_VALUE = 2147483647;
/*      */   public static final double GESTURE_NO_DOUBLE_VALUE = NaND;
/*      */   public static final byte IME_ATTR_INPUT = 0;
/*      */   public static final byte IME_ATTR_TARGET_CONVERTED = 1;
/*      */   public static final byte IME_ATTR_CONVERTED = 2;
/*      */   public static final byte IME_ATTR_TARGET_NOTCONVERTED = 3;
/*      */   public static final byte IME_ATTR_INPUT_ERROR = 4;
/*      */   static final boolean accessible;
/*      */   private volatile long ptr;
/*      */   private Window window;
/*      */   private EventHandler eventHandler;
/*      */   
/*      */   static {
/*   48 */     accessible = ((Boolean)AccessController.<Boolean>doPrivileged(() -> {
/*      */           String str = System.getProperty("glass.accessible.force");
/*      */           if (str != null) {
/*      */             return Boolean.valueOf(Boolean.parseBoolean(str));
/*      */           }
/*      */           try {
/*      */             String str1 = Platform.determinePlatform();
/*      */             String str2 = System.getProperty("os.version").replaceFirst("(\\d+)\\.\\d+.*", "$1");
/*      */             String str3 = System.getProperty("os.version").replaceFirst("\\d+\\.(\\d+).*", "$1");
/*      */             int i = Integer.parseInt(str2) * 100 + Integer.parseInt(str3);
/*   58 */             return Boolean.valueOf(((str1.equals("Mac") && i >= 1009) || (str1.equals("Win") && i >= 601)));
/*      */           }
/*   60 */           catch (Exception exception) {
/*      */             return Boolean.valueOf(false);
/*      */           } 
/*      */         })).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EventHandler
/*      */   {
/*      */     public void handleViewEvent(View param1View, long param1Long, int param1Int) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleKeyEvent(View param1View, long param1Long, int param1Int1, int param1Int2, char[] param1ArrayOfchar, int param1Int3) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleMenuEvent(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, boolean param1Boolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleMouseEvent(View param1View, long param1Long, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, boolean param1Boolean1, boolean param1Boolean2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleScrollEvent(View param1View, long param1Long, int param1Int1, int param1Int2, int param1Int3, int param1Int4, double param1Double1, double param1Double2, int param1Int5, int param1Int6, int param1Int7, int param1Int8, int param1Int9, double param1Double3, double param1Double4) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleInputMethodEvent(long param1Long, String param1String, int[] param1ArrayOfint1, int[] param1ArrayOfint2, byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public double[] getInputMethodCandidatePos(int param1Int) {
/*  119 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleDragStart(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {}
/*      */ 
/*      */     
/*      */     public void handleDragEnd(View param1View, int param1Int) {}
/*      */ 
/*      */     
/*      */     public int handleDragEnter(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  131 */       return param1Int5;
/*      */     }
/*      */ 
/*      */     
/*      */     public int handleDragOver(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  136 */       return param1Int5;
/*      */     }
/*      */ 
/*      */     
/*      */     public void handleDragLeave(View param1View, ClipboardAssistance param1ClipboardAssistance) {}
/*      */ 
/*      */     
/*      */     public int handleDragDrop(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, ClipboardAssistance param1ClipboardAssistance) {
/*  144 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleBeginTouchEvent(View param1View, long param1Long, int param1Int1, boolean param1Boolean, int param1Int2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleNextTouchEvent(View param1View, long param1Long1, int param1Int1, long param1Long2, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleEndTouchEvent(View param1View, long param1Long) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleScrollGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleZoomGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, double param1Double1, double param1Double2, double param1Double3, double param1Double4) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleRotateGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, double param1Double1, double param1Double2) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleSwipeGestureEvent(View param1View, long param1Long, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Accessible getSceneAccessible() {
/*  368 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   public static long getMultiClickTime() {
/*  373 */     Application.checkEventThread();
/*  374 */     return Application.GetApplication().staticView_getMultiClickTime();
/*      */   }
/*      */   
/*      */   public static int getMultiClickMaxX() {
/*  378 */     Application.checkEventThread();
/*  379 */     return Application.GetApplication().staticView_getMultiClickMaxX();
/*      */   }
/*      */   
/*      */   public static int getMultiClickMaxY() {
/*  383 */     Application.checkEventThread();
/*  384 */     return Application.GetApplication().staticView_getMultiClickMaxY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishInputMethodComposition(long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  399 */   private int width = -1;
/*  400 */   private int height = -1;
/*      */   
/*      */   private boolean isValid = false;
/*      */   
/*      */   private boolean isVisible = false;
/*      */   private boolean inFullscreen = false;
/*      */   
/*      */   public static final class Capability
/*      */   {
/*      */     public static final int k3dKeyValue = 0;
/*      */     public static final int kSyncKeyValue = 1;
/*      */     public static final int k3dProjectionKeyValue = 2;
/*      */     public static final int k3dProjectionAngleKeyValue = 3;
/*      */     public static final int k3dDepthKeyValue = 4;
/*      */     public static final int kHiDPIAwareKeyValue = 5;
/*  415 */     public static final Object k3dKey = Integer.valueOf(0);
/*  416 */     public static final Object kSyncKey = Integer.valueOf(1);
/*  417 */     public static final Object k3dProjectionKey = Integer.valueOf(2);
/*  418 */     public static final Object k3dProjectionAngleKey = Integer.valueOf(3);
/*  419 */     public static final Object k3dDepthKey = Integer.valueOf(4);
/*  420 */     public static final Object kHiDPIAwareKey = Integer.valueOf(5);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected View() {
/*  426 */     Application.checkEventThread();
/*  427 */     Application.GetApplication(); this.ptr = _create(Application.getDeviceDetails());
/*  428 */     if (this.ptr == 0L) {
/*  429 */       throw new RuntimeException("could not create platform view");
/*      */     }
/*      */   }
/*      */   
/*      */   private void checkNotClosed() {
/*  434 */     if (this.ptr == 0L) {
/*  435 */       throw new IllegalStateException("The view has already been closed");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  440 */     Application.checkEventThread();
/*  441 */     return (this.ptr == 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeView() {
/*  451 */     Application.checkEventThread();
/*  452 */     checkNotClosed();
/*  453 */     return _getNativeView(this.ptr);
/*      */   }
/*      */   
/*      */   public Window getWindow() {
/*  457 */     Application.checkEventThread();
/*  458 */     return this.window;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getX() {
/*  464 */     Application.checkEventThread();
/*  465 */     checkNotClosed();
/*  466 */     return _getX(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getY() {
/*  472 */     Application.checkEventThread();
/*  473 */     checkNotClosed();
/*  474 */     return _getY(this.ptr);
/*      */   }
/*      */   
/*      */   public int getWidth() {
/*  478 */     Application.checkEventThread();
/*  479 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight() {
/*  483 */     Application.checkEventThread();
/*  484 */     return this.height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setWindow(Window paramWindow) {
/*  491 */     Application.checkEventThread();
/*  492 */     checkNotClosed();
/*  493 */     this.window = paramWindow;
/*  494 */     _setParent(this.ptr, (paramWindow == null) ? 0L : paramWindow.getNativeHandle());
/*  495 */     this.isValid = (this.ptr != 0L && paramWindow != null);
/*      */   }
/*      */ 
/*      */   
/*      */   void setVisible(boolean paramBoolean) {
/*  500 */     this.isVisible = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() {
/*  505 */     Application.checkEventThread();
/*  506 */     if (this.ptr == 0L) {
/*      */       return;
/*      */     }
/*  509 */     if (isInFullscreen()) {
/*  510 */       _exitFullscreen(this.ptr, false);
/*      */     }
/*  512 */     Window window = getWindow();
/*  513 */     if (window != null) {
/*  514 */       window.setView(null);
/*      */     }
/*  516 */     this.isValid = false;
/*  517 */     _close(this.ptr);
/*  518 */     this.ptr = 0L;
/*      */   }
/*      */   
/*      */   public EventHandler getEventHandler() {
/*  522 */     Application.checkEventThread();
/*  523 */     return this.eventHandler;
/*      */   }
/*      */   
/*      */   public void setEventHandler(EventHandler paramEventHandler) {
/*  527 */     Application.checkEventThread();
/*  528 */     this.eventHandler = paramEventHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleViewEvent(long paramLong, int paramInt) {
/*  534 */     if (this.eventHandler != null) {
/*  535 */       this.eventHandler.handleViewEvent(this, paramLong, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleKeyEvent(long paramLong, int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3) {
/*  541 */     if (this.eventHandler != null) {
/*  542 */       this.eventHandler.handleKeyEvent(this, paramLong, paramInt1, paramInt2, paramArrayOfchar, paramInt3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleMouseEvent(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2) {
/*  550 */     if (this.eventHandler != null) {
/*  551 */       this.eventHandler.handleMouseEvent(this, paramLong, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean1, paramBoolean2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleMenuEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/*  558 */     if (this.eventHandler != null) {
/*  559 */       this.eventHandler.handleMenuEvent(this, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void handleBeginTouchEvent(View paramView, long paramLong, int paramInt1, boolean paramBoolean, int paramInt2) {
/*  565 */     if (this.eventHandler != null) {
/*  566 */       this.eventHandler.handleBeginTouchEvent(paramView, paramLong, paramInt1, paramBoolean, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleNextTouchEvent(View paramView, long paramLong1, int paramInt1, long paramLong2, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  574 */     if (this.eventHandler != null) {
/*  575 */       this.eventHandler.handleNextTouchEvent(paramView, paramLong1, paramInt1, paramLong2, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     }
/*      */   }
/*      */   
/*      */   public void handleEndTouchEvent(View paramView, long paramLong) {
/*  580 */     if (this.eventHandler != null) {
/*  581 */       this.eventHandler.handleEndTouchEvent(paramView, paramLong);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleScrollGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  592 */     if (this.eventHandler != null) {
/*  593 */       this.eventHandler.handleScrollGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleZoomGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/*  606 */     if (this.eventHandler != null) {
/*  607 */       this.eventHandler.handleZoomGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleRotateGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2) {
/*  620 */     if (this.eventHandler != null) {
/*  621 */       this.eventHandler.handleRotateGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleSwipeGestureEvent(View paramView, long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*  632 */     if (this.eventHandler != null) {
/*  633 */       this.eventHandler.handleSwipeGestureEvent(paramView, paramLong, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleInputMethodEvent(long paramLong, String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  642 */     if (this.eventHandler != null) {
/*  643 */       this.eventHandler.handleInputMethodEvent(paramLong, paramString, paramArrayOfint1, paramArrayOfint2, paramArrayOfbyte, paramInt1, paramInt2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableInputMethodEvents(boolean paramBoolean) {
/*  650 */     Application.checkEventThread();
/*  651 */     checkNotClosed();
/*  652 */     _enableInputMethodEvents(this.ptr, paramBoolean);
/*      */   }
/*      */   
/*      */   public void finishInputMethodComposition() {
/*  656 */     Application.checkEventThread();
/*  657 */     checkNotClosed();
/*  658 */     _finishInputMethodComposition(this.ptr);
/*      */   }
/*      */   
/*      */   private double[] getInputMethodCandidatePos(int paramInt) {
/*  662 */     if (this.eventHandler != null) {
/*  663 */       return this.eventHandler.getInputMethodCandidatePos(paramInt);
/*      */     }
/*  665 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleDragStart(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  670 */     if (this.eventHandler != null) {
/*  671 */       this.eventHandler.handleDragStart(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*      */   }
/*      */   
/*      */   private void handleDragEnd(int paramInt) {
/*  676 */     if (this.eventHandler != null) {
/*  677 */       this.eventHandler.handleDragEnd(this, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int handleDragEnter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  683 */     if (this.eventHandler != null) {
/*  684 */       return this.eventHandler.handleDragEnter(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  686 */     return paramInt5;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int handleDragOver(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  692 */     if (this.eventHandler != null) {
/*  693 */       return this.eventHandler.handleDragOver(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  695 */     return paramInt5;
/*      */   }
/*      */ 
/*      */   
/*      */   private void handleDragLeave(ClipboardAssistance paramClipboardAssistance) {
/*  700 */     if (this.eventHandler != null) {
/*  701 */       this.eventHandler.handleDragLeave(this, paramClipboardAssistance);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private int handleDragDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, ClipboardAssistance paramClipboardAssistance) {
/*  707 */     if (this.eventHandler != null) {
/*  708 */       return this.eventHandler.handleDragDrop(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramClipboardAssistance);
/*      */     }
/*  710 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void scheduleRepaint() {
/*  719 */     Application.checkEventThread();
/*  720 */     checkNotClosed();
/*  721 */     _scheduleRepaint(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void lock() {
/*  730 */     checkNotClosed();
/*  731 */     _begin(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unlock() {
/*  741 */     checkNotClosed();
/*  742 */     _end(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNativeFrameBuffer() {
/*  751 */     return _getNativeFrameBuffer(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void uploadPixels(Pixels paramPixels) {
/*  763 */     Application.checkEventThread();
/*  764 */     checkNotClosed();
/*  765 */     lock();
/*      */     try {
/*  767 */       _uploadPixels(this.ptr, paramPixels);
/*      */     } finally {
/*  769 */       unlock();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean enterFullscreen(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  778 */     Application.checkEventThread();
/*  779 */     checkNotClosed();
/*  780 */     return _enterFullscreen(this.ptr, paramBoolean1, paramBoolean2, paramBoolean3);
/*      */   }
/*      */ 
/*      */   
/*      */   public void exitFullscreen(boolean paramBoolean) {
/*  785 */     Application.checkEventThread();
/*  786 */     checkNotClosed();
/*  787 */     _exitFullscreen(this.ptr, paramBoolean);
/*      */   }
/*      */   
/*      */   public boolean isInFullscreen() {
/*  791 */     Application.checkEventThread();
/*  792 */     return this.inFullscreen;
/*      */   }
/*      */   
/*      */   public boolean toggleFullscreen(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  796 */     Application.checkEventThread();
/*  797 */     checkNotClosed();
/*  798 */     if (!this.inFullscreen) {
/*  799 */       enterFullscreen(paramBoolean1, paramBoolean2, paramBoolean3);
/*      */     } else {
/*  801 */       exitFullscreen(paramBoolean1);
/*      */     } 
/*      */     
/*  804 */     _scheduleRepaint(this.ptr);
/*      */     
/*  806 */     return this.inFullscreen;
/*      */   }
/*      */   
/*      */   public void updateLocation() {
/*  810 */     notifyView(423);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyView(int paramInt) {
/*  818 */     if (paramInt == 421) {
/*  819 */       if (this.isValid) {
/*  820 */         handleViewEvent(System.nanoTime(), paramInt);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  825 */       boolean bool = false;
/*      */       
/*  827 */       switch (paramInt) {
/*      */         case 412:
/*  829 */           this.isValid = false;
/*  830 */           bool = true;
/*      */           break;
/*      */         case 411:
/*  833 */           this.isValid = true;
/*  834 */           bool = true;
/*      */           break;
/*      */         case 431:
/*  837 */           this.inFullscreen = true;
/*  838 */           bool = true;
/*  839 */           if (getWindow() != null) {
/*  840 */             getWindow().notifyFullscreen(true);
/*      */           }
/*      */           break;
/*      */         case 432:
/*  844 */           this.inFullscreen = false;
/*  845 */           bool = true;
/*  846 */           if (getWindow() != null) {
/*  847 */             getWindow().notifyFullscreen(false);
/*      */           }
/*      */           break;
/*      */         case 422:
/*      */         case 423:
/*      */           break;
/*      */         default:
/*  854 */           System.err.println("Unknown view event type: " + paramInt);
/*      */           return;
/*      */       } 
/*      */       
/*  858 */       handleViewEvent(System.nanoTime(), paramInt);
/*      */       
/*  860 */       if (bool)
/*      */       {
/*      */         
/*  863 */         handleViewEvent(System.nanoTime(), 423);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyResize(int paramInt1, int paramInt2) {
/*  869 */     if (this.width == paramInt1 && this.height == paramInt2) {
/*      */       return;
/*      */     }
/*      */     
/*  873 */     this.width = paramInt1;
/*  874 */     this.height = paramInt2;
/*  875 */     handleViewEvent(System.nanoTime(), 422);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyRepaint(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  882 */     notifyView(421);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/*  889 */     handleMenuEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  895 */   private static WeakReference<View> lastClickedView = null;
/*      */   private static int lastClickedButton;
/*      */   private static long lastClickedTime;
/*      */   private static int lastClickedX;
/*      */   private static int lastClickedY;
/*      */   private static int clickCount;
/*      */   private static boolean dragProcessed = false;
/*      */   private ClipboardAssistance dropSourceAssistant;
/*      */   ClipboardAssistance dropTargetAssistant;
/*      */   
/*      */   protected void notifyMouse(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean1, boolean paramBoolean2) {
/*  906 */     if (this.window != null)
/*      */     {
/*  908 */       if (this.window.handleMouseEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6)) {
/*      */         return;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  914 */     long l = System.nanoTime();
/*  915 */     if (paramInt1 == 221) {
/*  916 */       View view = (lastClickedView == null) ? null : lastClickedView.get();
/*      */       
/*  918 */       if (view == this && lastClickedButton == paramInt2 && l - lastClickedTime <= 1000000L * 
/*      */         
/*  920 */         getMultiClickTime() && 
/*  921 */         Math.abs(paramInt3 - lastClickedX) <= getMultiClickMaxX() && 
/*  922 */         Math.abs(paramInt4 - lastClickedY) <= getMultiClickMaxY()) {
/*      */         
/*  924 */         clickCount++;
/*      */       } else {
/*  926 */         clickCount = 1;
/*      */         
/*  928 */         lastClickedView = new WeakReference<>(this);
/*  929 */         lastClickedButton = paramInt2;
/*  930 */         lastClickedX = paramInt3;
/*  931 */         lastClickedY = paramInt4;
/*      */       } 
/*      */       
/*  934 */       lastClickedTime = l;
/*      */     } 
/*      */     
/*  937 */     handleMouseEvent(l, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramBoolean1, paramBoolean2);
/*      */ 
/*      */     
/*  940 */     if (paramInt1 == 223) {
/*      */       
/*  942 */       if (!dragProcessed) {
/*  943 */         notifyDragStart(paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*  944 */         dragProcessed = true;
/*      */       } 
/*      */     } else {
/*  947 */       dragProcessed = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, double paramDouble1, double paramDouble2, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, double paramDouble3, double paramDouble4) {
/*  958 */     if (this.eventHandler != null) {
/*  959 */       this.eventHandler.handleScrollEvent(this, System.nanoTime(), paramInt1, paramInt2, paramInt3, paramInt4, paramDouble1, paramDouble2, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramDouble3, paramDouble4);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyKey(int paramInt1, int paramInt2, char[] paramArrayOfchar, int paramInt3) {
/*  966 */     handleKeyEvent(System.nanoTime(), paramInt1, paramInt2, paramArrayOfchar, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyInputMethod(String paramString, int[] paramArrayOfint1, int[] paramArrayOfint2, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3) {
/*  972 */     handleInputMethodEvent(System.nanoTime(), paramString, paramArrayOfint1, paramArrayOfint2, paramArrayOfbyte, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   
/*      */   protected double[] notifyInputMethodCandidatePosRequest(int paramInt) {
/*  977 */     double[] arrayOfDouble = getInputMethodCandidatePos(paramInt);
/*  978 */     if (arrayOfDouble == null) {
/*  979 */       arrayOfDouble = new double[2];
/*  980 */       arrayOfDouble[0] = 0.0D;
/*  981 */       arrayOfDouble[1] = 0.0D;
/*      */     } 
/*  983 */     return arrayOfDouble;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDragStart(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  988 */     this.dropSourceAssistant = new ClipboardAssistance("DND")
/*      */       {
/*      */         public void actionPerformed(int param1Int)
/*      */         {
/*  992 */           View.this.notifyDragEnd(param1Int);
/*      */         }
/*      */       };
/*      */     
/*  996 */     handleDragStart(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropSourceAssistant);
/*      */     
/*  998 */     if (this.dropSourceAssistant != null) {
/*  999 */       this.dropSourceAssistant.close();
/* 1000 */       this.dropSourceAssistant = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyDragEnd(int paramInt) {
/* 1005 */     handleDragEnd(paramInt);
/* 1006 */     if (this.dropSourceAssistant != null) {
/* 1007 */       this.dropSourceAssistant.close();
/* 1008 */       this.dropSourceAssistant = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int notifyDragEnter(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1015 */     this.dropTargetAssistant = new ClipboardAssistance("DND") {
/*      */         public void flush() {
/* 1017 */           throw new UnsupportedOperationException("Flush is forbidden from target!");
/*      */         }
/*      */       };
/* 1020 */     return handleDragEnter(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/*      */   }
/*      */ 
/*      */   
/*      */   protected int notifyDragOver(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1025 */     return handleDragOver(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDragLeave() {
/* 1030 */     handleDragLeave(this.dropTargetAssistant);
/* 1031 */     this.dropTargetAssistant.close();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int notifyDragDrop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1037 */     int i = handleDragDrop(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, this.dropTargetAssistant);
/* 1038 */     this.dropTargetAssistant.close();
/* 1039 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyBeginTouchEvent(int paramInt1, boolean paramBoolean, int paramInt2) {
/* 1044 */     handleBeginTouchEvent(this, System.nanoTime(), paramInt1, paramBoolean, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyNextTouchEvent(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 1050 */     handleNextTouchEvent(this, System.nanoTime(), paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */ 
/*      */   
/*      */   public void notifyEndTouchEvent() {
/* 1055 */     handleEndTouchEvent(this, System.nanoTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyScrollGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/* 1064 */     handleScrollGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyZoomGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 1075 */     handleZoomGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifyRotateGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, double paramDouble1, double paramDouble2) {
/* 1086 */     handleRotateGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramDouble1, paramDouble2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void notifySwipeGestureEvent(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/* 1096 */     handleSwipeGestureEvent(this, System.nanoTime(), paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getAccessible() {
/* 1109 */     Application.checkEventThread();
/* 1110 */     checkNotClosed();
/* 1111 */     if (accessible) {
/* 1112 */       Accessible accessible = this.eventHandler.getSceneAccessible();
/* 1113 */       if (accessible != null) {
/* 1114 */         accessible.setView(this);
/* 1115 */         return accessible.getNativeAccessible();
/*      */       } 
/*      */     } 
/* 1118 */     return 0L;
/*      */   }
/*      */   
/*      */   protected abstract void _enableInputMethodEvents(long paramLong, boolean paramBoolean);
/*      */   
/*      */   protected abstract long _create(Map paramMap);
/*      */   
/*      */   protected abstract long _getNativeView(long paramLong);
/*      */   
/*      */   protected abstract int _getX(long paramLong);
/*      */   
/*      */   protected abstract int _getY(long paramLong);
/*      */   
/*      */   protected abstract void _setParent(long paramLong1, long paramLong2);
/*      */   
/*      */   protected abstract boolean _close(long paramLong);
/*      */   
/*      */   protected abstract void _scheduleRepaint(long paramLong);
/*      */   
/*      */   protected abstract void _begin(long paramLong);
/*      */   
/*      */   protected abstract void _end(long paramLong);
/*      */   
/*      */   protected abstract int _getNativeFrameBuffer(long paramLong);
/*      */   
/*      */   protected abstract void _uploadPixels(long paramLong, Pixels paramPixels);
/*      */   
/*      */   protected abstract boolean _enterFullscreen(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
/*      */   
/*      */   protected abstract void _exitFullscreen(long paramLong, boolean paramBoolean);
/*      */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\View.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */