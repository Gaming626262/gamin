/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.javafx.scene.NodeHelper;
/*     */ import com.sun.javafx.scene.SceneHelper;
/*     */ import com.sun.javafx.tk.quantum.QuantumToolkit;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.AccessibleRole;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Accessible
/*     */ {
/*     */   private EventHandler eventHandler;
/*     */   private View view;
/*     */   
/*     */   public static abstract class EventHandler
/*     */   {
/*     */     public Object getAttribute(AccessibleAttribute param1AccessibleAttribute, Object... param1VarArgs) {
/*  49 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void executeAction(AccessibleAction param1AccessibleAction, Object... param1VarArgs) {}
/*     */ 
/*     */     
/*     */     public abstract AccessControlContext getAccessControlContext();
/*     */   }
/*     */   
/*     */   public EventHandler getEventHandler() {
/*  60 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void setEventHandler(EventHandler paramEventHandler) {
/*  64 */     this.eventHandler = paramEventHandler;
/*     */   }
/*     */   
/*     */   public void setView(View paramView) {
/*  68 */     this.view = paramView;
/*     */   }
/*     */   
/*     */   public View getView() {
/*  72 */     return this.view;
/*     */   }
/*     */   
/*     */   public void dispose() {
/*  76 */     this.eventHandler = null;
/*  77 */     this.view = null;
/*     */   }
/*     */   
/*     */   public boolean isDisposed() {
/*  81 */     return (getNativeAccessible() == 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  86 */     return getClass().getSimpleName() + " (" + getClass().getSimpleName() + ")";
/*     */   }
/*     */   
/*     */   protected boolean isIgnored() {
/*  90 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  91 */     if (accessibleRole == null) return true; 
/*  92 */     return (accessibleRole == AccessibleRole.NODE || accessibleRole == AccessibleRole.PARENT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Accessible getAccessible(Scene paramScene) {
/*  98 */     if (paramScene == null) return null; 
/*  99 */     return SceneHelper.getAccessible(paramScene);
/*     */   }
/*     */   
/*     */   protected Accessible getAccessible(Node paramNode) {
/* 103 */     if (paramNode == null) return null; 
/* 104 */     return NodeHelper.getAccessible(paramNode);
/*     */   }
/*     */   
/*     */   protected long getNativeAccessible(Node paramNode) {
/* 108 */     if (paramNode == null) return 0L; 
/* 109 */     Accessible accessible = getAccessible(paramNode);
/* 110 */     if (accessible == null) return 0L; 
/* 111 */     return accessible.getNativeAccessible();
/*     */   }
/*     */   
/*     */   protected Accessible getContainerAccessible(AccessibleRole paramAccessibleRole) {
/* 115 */     Node node = (Node)getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/* 116 */     while (node != null) {
/* 117 */       Accessible accessible = getAccessible(node);
/* 118 */       AccessibleRole accessibleRole = (AccessibleRole)accessible.getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 119 */       if (accessibleRole == paramAccessibleRole) return accessible; 
/* 120 */       node = (Node)accessible.getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/*     */     } 
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AccessControlContext getAccessControlContext() {
/* 131 */     AccessControlContext accessControlContext = null;
/*     */     try {
/* 133 */       accessControlContext = this.eventHandler.getAccessControlContext();
/* 134 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 137 */     return accessControlContext;
/*     */   }
/*     */   
/*     */   private class GetAttribute implements PrivilegedAction<Object> { AccessibleAttribute attribute;
/*     */     Object[] parameters;
/*     */     
/*     */     public Object run() {
/* 144 */       Object object = Accessible.this.eventHandler.getAttribute(this.attribute, this.parameters);
/* 145 */       if (object != null) {
/* 146 */         Class clazz = this.attribute.getReturnType();
/* 147 */         if (clazz != null) {
/*     */           try {
/* 149 */             clazz.cast(object);
/* 150 */           } catch (Exception exception) {
/*     */ 
/*     */             
/* 153 */             String str = "The expected return type for the " + this.attribute + " attribute is " + clazz.getSimpleName() + " but found " + object.getClass().getSimpleName();
/* 154 */             System.err.println(str);
/* 155 */             return null;
/*     */           } 
/*     */         }
/*     */       } 
/* 159 */       return object;
/*     */     } }
/*     */ 
/*     */   
/* 163 */   private GetAttribute getAttribute = new GetAttribute();
/*     */ 
/*     */   
/*     */   public Object getAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 167 */     AccessControlContext accessControlContext = getAccessControlContext();
/* 168 */     if (accessControlContext == null) return null; 
/* 169 */     return QuantumToolkit.runWithoutRenderLock(() -> {
/*     */           this.getAttribute.attribute = paramAccessibleAttribute;
/*     */           this.getAttribute.parameters = paramArrayOfObject;
/*     */           return AccessController.doPrivileged(this.getAttribute, paramAccessControlContext);
/*     */         });
/*     */   }
/*     */   
/*     */   private class ExecuteAction implements PrivilegedAction<Void> { AccessibleAction action;
/*     */     Object[] parameters;
/*     */     
/*     */     public Void run() {
/* 180 */       Accessible.this.eventHandler.executeAction(this.action, this.parameters);
/* 181 */       return null;
/*     */     } }
/*     */ 
/*     */   
/* 185 */   private ExecuteAction executeAction = new ExecuteAction();
/*     */ 
/*     */   
/*     */   public void executeAction(AccessibleAction paramAccessibleAction, Object... paramVarArgs) {
/* 189 */     AccessControlContext accessControlContext = getAccessControlContext();
/* 190 */     if (accessControlContext == null)
/* 191 */       return;  QuantumToolkit.runWithoutRenderLock(() -> {
/*     */           this.executeAction.action = paramAccessibleAction;
/*     */           this.executeAction.parameters = paramArrayOfObject;
/*     */           return AccessController.<Void>doPrivileged(this.executeAction, paramAccessControlContext);
/*     */         });
/*     */   }
/*     */   
/*     */   protected abstract long getNativeAccessible();
/*     */   
/*     */   public abstract void sendNotification(AccessibleAttribute paramAccessibleAttribute);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Accessible.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */