/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PlatformFactory
/*    */ {
/*    */   private static PlatformFactory instance;
/*    */   
/*    */   public static synchronized PlatformFactory getPlatformFactory() {
/* 37 */     if (instance == null) {
/*    */       try {
/* 39 */         String str1 = Platform.determinePlatform();
/* 40 */         String str2 = "com.sun.glass.ui." + str1.toLowerCase(Locale.ROOT) + "." + str1 + "PlatformFactory";
/*    */         
/* 42 */         Class<?> clazz = Class.forName(str2);
/* 43 */         instance = clazz.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/* 44 */       } catch (Exception exception) {
/* 45 */         exception.printStackTrace();
/* 46 */         System.out.println("Failed to load Glass factory class");
/*    */       } 
/*    */     }
/* 49 */     return instance;
/*    */   }
/*    */   
/*    */   public abstract Application createApplication();
/*    */   
/*    */   public abstract MenuBarDelegate createMenuBarDelegate(MenuBar paramMenuBar);
/*    */   
/*    */   public abstract MenuDelegate createMenuDelegate(Menu paramMenu);
/*    */   
/*    */   public abstract MenuItemDelegate createMenuItemDelegate(MenuItem paramMenuItem);
/*    */   
/*    */   public abstract ClipboardDelegate createClipboardDelegate();
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\PlatformFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */