/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.util.concurrent.BlockingDeque;
/*     */ import java.util.concurrent.LinkedBlockingDeque;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InvokeLaterDispatcher
/*     */   extends Thread
/*     */ {
/*  46 */   private final BlockingDeque<Runnable> deque = new LinkedBlockingDeque<>();
/*     */ 
/*     */   
/*  49 */   private final Object LOCK = new StringBuilder("InvokeLaterLock");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean nestedEventLoopEntered = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean leavingNestedEventLoop = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final InvokeLaterSubmitter invokeLaterSubmitter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvokeLaterDispatcher(InvokeLaterSubmitter paramInvokeLaterSubmitter) {
/*  71 */     super("InvokeLaterDispatcher");
/*  72 */     setDaemon(true);
/*     */     
/*  74 */     this.invokeLaterSubmitter = paramInvokeLaterSubmitter;
/*     */   }
/*     */   
/*     */   public static interface InvokeLaterSubmitter {
/*     */     void submitForLaterInvocation(Runnable param1Runnable); }
/*     */   
/*     */   private class Future implements Runnable {
/*     */     public Future(Runnable param1Runnable) {
/*  82 */       this.runnable = param1Runnable;
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean done = false;
/*     */     
/*     */     private final Runnable runnable;
/*     */     
/*     */     public boolean isDone() {
/*  91 */       return this.done;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       try {
/*  96 */         this.runnable.run();
/*     */       } finally {
/*  98 */         synchronized (InvokeLaterDispatcher.this.LOCK) {
/*  99 */           this.done = true;
/* 100 */           InvokeLaterDispatcher.this.LOCK.notifyAll();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void run() {
/*     */     try {
/*     */       while (true) {
/* 109 */         Runnable runnable = this.deque.takeFirst();
/*     */         
/* 111 */         if (this.leavingNestedEventLoop) {
/*     */ 
/*     */           
/* 114 */           this.deque.addFirst(runnable);
/* 115 */           synchronized (this.LOCK) {
/* 116 */             while (this.leavingNestedEventLoop) {
/* 117 */               this.LOCK.wait();
/*     */             }
/*     */           } 
/*     */           continue;
/*     */         } 
/* 122 */         Future future = new Future(runnable);
/* 123 */         this.invokeLaterSubmitter.submitForLaterInvocation(future);
/* 124 */         synchronized (this.LOCK) { while (true) {
/*     */             try {
/* 126 */               if (!future.isDone() && !this.nestedEventLoopEntered) {
/* 127 */                 this.LOCK.wait();
/*     */                 
/*     */                 continue;
/*     */               } 
/*     */             } finally {
/* 132 */               this.nestedEventLoopEntered = false;
/*     */             }  break;
/*     */           }  }
/*     */       
/*     */       } 
/* 137 */     } catch (InterruptedException interruptedException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void invokeAndWait(Runnable paramRunnable) {
/* 143 */     Future future = new Future(paramRunnable);
/* 144 */     this.invokeLaterSubmitter.submitForLaterInvocation(future);
/* 145 */     synchronized (this.LOCK) { while (true) {
/*     */         try {
/* 147 */           if (!future.isDone()) {
/* 148 */             this.LOCK.wait(); continue;
/*     */           } 
/* 150 */         } catch (InterruptedException interruptedException) {}
/*     */         break;
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeLater(Runnable paramRunnable) {
/* 161 */     this.deque.addLast(paramRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyEnteringNestedEventLoop() {
/* 172 */     synchronized (this.LOCK) {
/* 173 */       this.nestedEventLoopEntered = true;
/* 174 */       this.LOCK.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyLeavingNestedEventLoop() {
/* 182 */     synchronized (this.LOCK) {
/* 183 */       this.leavingNestedEventLoop = true;
/* 184 */       this.LOCK.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyLeftNestedEventLoop() {
/* 192 */     synchronized (this.LOCK) {
/* 193 */       this.leavingNestedEventLoop = false;
/* 194 */       this.LOCK.notifyAll();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\InvokeLaterDispatcher.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */