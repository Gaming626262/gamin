/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Timer
/*     */ {
/*     */   private static final double UNSET_PERIOD = -1.0D;
/*     */   private static final double SET_PERIOD = -2.0D;
/*     */   private final Runnable runnable;
/*     */   private long ptr;
/*  46 */   private double period = -1.0D;
/*     */ 
/*     */   
/*     */   protected abstract long _start(Runnable paramRunnable);
/*     */ 
/*     */   
/*     */   protected abstract long _start(Runnable paramRunnable, int paramInt);
/*     */   
/*     */   protected abstract void _stop(long paramLong);
/*     */   
/*     */   protected abstract void _pause(long paramLong);
/*     */   
/*     */   protected abstract void _resume(long paramLong);
/*     */   
/*     */   protected Timer(Runnable paramRunnable) {
/*  61 */     if (paramRunnable == null) {
/*  62 */       throw new IllegalArgumentException("runnable shouldn't be null");
/*     */     }
/*  64 */     this.runnable = paramRunnable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMinPeriod() {
/*  71 */     return Application.GetApplication().staticTimer_getMinPeriod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getMaxPeriod() {
/*  78 */     return Application.GetApplication().staticTimer_getMaxPeriod();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start(int paramInt) {
/*  88 */     if (paramInt < getMinPeriod() || paramInt > getMaxPeriod()) {
/*  89 */       throw new IllegalArgumentException("period is out of range");
/*     */     }
/*     */     
/*  92 */     if (this.ptr != 0L) {
/*  93 */       stop();
/*     */     }
/*     */     
/*  96 */     this.ptr = _start(this.runnable, paramInt);
/*  97 */     if (this.ptr == 0L) {
/*  98 */       this.period = -1.0D;
/*  99 */       throw new RuntimeException("Failed to start the timer");
/*     */     } 
/* 101 */     this.period = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/* 112 */     if (this.ptr != 0L) {
/* 113 */       stop();
/*     */     }
/*     */     
/* 116 */     this.ptr = _start(this.runnable);
/* 117 */     if (this.ptr == 0L) {
/* 118 */       this.period = -1.0D;
/* 119 */       throw new RuntimeException("Failed to start the timer");
/*     */     } 
/* 121 */     this.period = -2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void stop() {
/* 130 */     if (this.ptr != 0L) {
/* 131 */       _stop(this.ptr);
/* 132 */       this.ptr = 0L;
/* 133 */       this.period = -1.0D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void pause() {
/* 142 */     if (this.ptr != 0L) {
/* 143 */       _pause(this.ptr);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void resume() {
/* 152 */     if (this.ptr != 0L) {
/* 153 */       _resume(this.ptr);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isRunning() {
/* 163 */     return (this.period != -1.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Timer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */