package com.sun.glass.ui.delegate;

import com.sun.glass.ui.Clipboard;

public interface ClipboardDelegate {
  Clipboard createClipboard(String paramString);
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\delegate\ClipboardDelegate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */