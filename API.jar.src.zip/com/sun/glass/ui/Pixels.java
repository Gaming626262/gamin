/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.nio.Buffer;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.nio.IntBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Pixels
/*     */ {
/*     */   protected final int width;
/*     */   protected final int height;
/*     */   protected final int bytesPerComponent;
/*     */   protected final ByteBuffer bytes;
/*     */   protected final IntBuffer ints;
/*     */   private final float scalex;
/*     */   private final float scaley;
/*     */   
/*     */   public static class Format
/*     */   {
/*     */     public static final int BYTE_BGRA_PRE = 1;
/*     */     public static final int BYTE_ARGB = 2;
/*     */   }
/*     */   
/*     */   public static int getNativeFormat() {
/*  60 */     Application.checkEventThread();
/*  61 */     return Application.GetApplication().staticPixels_getNativeFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/*  88 */     this(paramInt1, paramInt2, paramByteBuffer, 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, float paramFloat1, float paramFloat2) {
/*  92 */     this.width = paramInt1;
/*  93 */     this.height = paramInt2;
/*  94 */     this.bytesPerComponent = 1;
/*  95 */     this.bytes = paramByteBuffer.slice();
/*     */     
/*  97 */     if (this.width <= 0 || this.height <= 0 || this.width > 536870911 / this.height)
/*     */     {
/*     */       
/* 100 */       throw new IllegalArgumentException("Invalid width*height");
/*     */     }
/*     */     
/* 103 */     if (this.width * this.height * 4 > this.bytes.capacity()) {
/* 104 */       throw new IllegalArgumentException("Too small byte buffer size " + this.width + "x" + this.height + " [" + this.width * this.height * 4 + "] > " + this.bytes.capacity());
/*     */     }
/*     */     
/* 107 */     this.ints = null;
/* 108 */     this.scalex = paramFloat1;
/* 109 */     this.scaley = paramFloat2;
/*     */   }
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 113 */     this(paramInt1, paramInt2, paramIntBuffer, 1.0F, 1.0F);
/*     */   }
/*     */   
/*     */   protected Pixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 117 */     this.width = paramInt1;
/* 118 */     this.height = paramInt2;
/* 119 */     this.bytesPerComponent = 4;
/* 120 */     this.ints = paramIntBuffer.slice();
/*     */     
/* 122 */     if (this.width <= 0 || this.height <= 0 || this.width > 536870911 / this.height)
/*     */     {
/*     */       
/* 125 */       throw new IllegalArgumentException("Invalid width*height");
/*     */     }
/*     */     
/* 128 */     if (this.width * this.height > this.ints.capacity()) {
/* 129 */       throw new IllegalArgumentException("Too small int buffer size " + this.width + "x" + this.height + " [" + this.width * this.height + "] > " + this.ints.capacity());
/*     */     }
/*     */     
/* 132 */     this.bytes = null;
/* 133 */     this.scalex = paramFloat1;
/* 134 */     this.scaley = paramFloat2;
/*     */   }
/*     */   
/*     */   public final float getScaleX() {
/* 138 */     Application.checkEventThread();
/* 139 */     return this.scalex;
/*     */   }
/*     */   
/*     */   public final float getScaleY() {
/* 143 */     Application.checkEventThread();
/* 144 */     return this.scaley;
/*     */   }
/*     */   
/*     */   public final float getScaleXUnsafe() {
/* 148 */     return this.scalex;
/*     */   }
/*     */   
/*     */   public final float getScaleYUnsafe() {
/* 152 */     return this.scaley;
/*     */   }
/*     */   
/*     */   public final int getWidth() {
/* 156 */     Application.checkEventThread();
/* 157 */     return this.width;
/*     */   }
/*     */   
/*     */   public final int getWidthUnsafe() {
/* 161 */     return this.width;
/*     */   }
/*     */   
/*     */   public final int getHeight() {
/* 165 */     Application.checkEventThread();
/* 166 */     return this.height;
/*     */   }
/*     */   
/*     */   public final int getHeightUnsafe() {
/* 170 */     return this.height;
/*     */   }
/*     */   
/*     */   public final int getBytesPerComponent() {
/* 174 */     Application.checkEventThread();
/* 175 */     return this.bytesPerComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Buffer getPixels() {
/* 185 */     if (this.bytes != null) {
/* 186 */       this.bytes.rewind();
/* 187 */       return this.bytes;
/* 188 */     }  if (this.ints != null) {
/* 189 */       this.ints.rewind();
/* 190 */       return this.ints;
/*     */     } 
/* 192 */     throw new RuntimeException("Unexpected Pixels state.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Buffer getBuffer() {
/* 202 */     if (this.bytes != null)
/* 203 */       return this.bytes; 
/* 204 */     if (this.ints != null) {
/* 205 */       return this.ints;
/*     */     }
/* 207 */     throw new RuntimeException("Unexpected Pixels state.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteBuffer asByteBuffer() {
/* 215 */     Application.checkEventThread();
/* 216 */     ByteBuffer byteBuffer = ByteBuffer.allocateDirect(getWidth() * getHeight() * 4);
/* 217 */     byteBuffer.order(ByteOrder.nativeOrder());
/* 218 */     byteBuffer.rewind();
/* 219 */     asByteBuffer(byteBuffer);
/* 220 */     return byteBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void asByteBuffer(ByteBuffer paramByteBuffer) {
/* 228 */     Application.checkEventThread();
/* 229 */     if (!paramByteBuffer.isDirect())
/* 230 */       throw new RuntimeException("Expected direct buffer."); 
/* 231 */     if (paramByteBuffer.remaining() < getWidth() * getHeight() * 4) {
/* 232 */       throw new RuntimeException("Too small buffer.");
/*     */     }
/* 234 */     _fillDirectByteBuffer(paramByteBuffer);
/* 235 */     paramByteBuffer.rewind();
/*     */   }
/*     */ 
/*     */   
/*     */   private void attachData(long paramLong) {
/* 240 */     if (this.ints != null) {
/* 241 */       int[] arrayOfInt = !this.ints.isDirect() ? this.ints.array() : null;
/* 242 */       _attachInt(paramLong, this.width, this.height, this.ints, arrayOfInt, (arrayOfInt != null) ? this.ints.arrayOffset() : 0);
/*     */     } 
/* 244 */     if (this.bytes != null) {
/* 245 */       byte[] arrayOfByte = !this.bytes.isDirect() ? this.bytes.array() : null;
/* 246 */       _attachByte(paramLong, this.width, this.height, this.bytes, arrayOfByte, (arrayOfByte != null) ? this.bytes.arrayOffset() : 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract void _fillDirectByteBuffer(ByteBuffer paramByteBuffer);
/*     */ 
/*     */   
/*     */   public final boolean equals(Object paramObject) {
/* 255 */     Application.checkEventThread();
/* 256 */     boolean bool = (paramObject != null && getClass().equals(paramObject.getClass())) ? true : false;
/* 257 */     if (bool) {
/* 258 */       Pixels pixels = (Pixels)paramObject;
/* 259 */       bool = (getWidth() == pixels.getWidth() && getHeight() == pixels.getHeight()) ? true : false;
/* 260 */       if (bool) {
/* 261 */         ByteBuffer byteBuffer1 = asByteBuffer();
/* 262 */         ByteBuffer byteBuffer2 = pixels.asByteBuffer();
/* 263 */         bool = (byteBuffer1.compareTo(byteBuffer2) == 0) ? true : false;
/*     */       } 
/*     */     } 
/* 266 */     return bool;
/*     */   } protected abstract void _attachInt(long paramLong, int paramInt1, int paramInt2, IntBuffer paramIntBuffer, int[] paramArrayOfint, int paramInt3);
/*     */   protected abstract void _attachByte(long paramLong, int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, byte[] paramArrayOfbyte, int paramInt3);
/*     */   public final int hashCode() {
/* 270 */     Application.checkEventThread();
/* 271 */     int i = getWidth();
/* 272 */     i = 31 * i + getHeight();
/* 273 */     i = 17 * i + asByteBuffer().hashCode();
/* 274 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Pixels.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */