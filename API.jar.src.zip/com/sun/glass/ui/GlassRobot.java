/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.javafx.image.PixelUtils;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.Objects;
/*     */ import javafx.scene.image.PixelWriter;
/*     */ import javafx.scene.image.WritableImage;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.paint.Color;
/*     */ import javafx.stage.Screen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GlassRobot
/*     */ {
/*     */   public static final int MOUSE_LEFT_BTN = 1;
/*     */   public static final int MOUSE_RIGHT_BTN = 2;
/*     */   public static final int MOUSE_MIDDLE_BTN = 4;
/*     */   public static final int MOUSE_BACK_BTN = 8;
/*     */   public static final int MOUSE_FORWARD_BTN = 16;
/*     */   
/*     */   public abstract void create();
/*     */   
/*     */   public abstract void destroy();
/*     */   
/*     */   public abstract void keyPress(KeyCode paramKeyCode);
/*     */   
/*     */   public abstract void keyRelease(KeyCode paramKeyCode);
/*     */   
/*     */   public abstract double getMouseX();
/*     */   
/*     */   public abstract double getMouseY();
/*     */   
/*     */   public abstract void mouseMove(double paramDouble1, double paramDouble2);
/*     */   
/*     */   public abstract void mousePress(MouseButton... paramVarArgs);
/*     */   
/*     */   public abstract void mouseRelease(MouseButton... paramVarArgs);
/*     */   
/*     */   public abstract void mouseWheel(int paramInt);
/*     */   
/*     */   public abstract Color getPixelColor(double paramDouble1, double paramDouble2);
/*     */   
/*     */   public void getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, boolean paramBoolean) {
/* 156 */     throw new InternalError("not implemented");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableImage getScreenCapture(WritableImage paramWritableImage, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
/* 187 */     int arrayOfInt[], k, m, i = (int)paramDouble3;
/* 188 */     int j = (int)paramDouble4;
/* 189 */     if (i <= 0) {
/* 190 */       throw new IllegalArgumentException("width must be > 0");
/*     */     }
/* 192 */     if (j <= 0) {
/* 193 */       throw new IllegalArgumentException("height must be > 0");
/*     */     }
/* 195 */     if (i >= Integer.MAX_VALUE / j) {
/* 196 */       throw new IllegalArgumentException("invalid capture size");
/*     */     }
/* 198 */     Screen screen = Screen.getPrimary();
/* 199 */     Objects.requireNonNull(screen);
/* 200 */     double d1 = screen.getOutputScaleX();
/* 201 */     double d2 = screen.getOutputScaleY();
/*     */ 
/*     */     
/* 204 */     if (d1 == 1.0D && d2 == 1.0D) {
/*     */       
/* 206 */       arrayOfInt = new int[i * j];
/* 207 */       getScreenCapture((int)paramDouble1, (int)paramDouble2, i, j, arrayOfInt, paramBoolean);
/* 208 */       k = i;
/* 209 */       m = j;
/*     */     }
/*     */     else {
/*     */       
/* 213 */       int n = (int)Math.floor(paramDouble1 * d1);
/* 214 */       int i1 = (int)Math.floor(paramDouble2 * d2);
/* 215 */       int i2 = (int)Math.ceil((paramDouble1 + paramDouble3) * d1);
/* 216 */       int i3 = (int)Math.ceil((paramDouble2 + paramDouble4) * d2);
/* 217 */       int i4 = i2 - n;
/* 218 */       int i5 = i3 - i1;
/* 219 */       if (i4 <= 0) {
/* 220 */         throw new IllegalArgumentException("invalid width");
/*     */       }
/* 222 */       if (i5 <= 0) {
/* 223 */         throw new IllegalArgumentException("invalid height");
/*     */       }
/* 225 */       if (i4 >= Integer.MAX_VALUE / i5) {
/* 226 */         throw new IllegalArgumentException("invalid capture size");
/*     */       }
/* 228 */       int[] arrayOfInt1 = new int[i4 * i5];
/* 229 */       getScreenCapture(n, i1, i4, i5, arrayOfInt1, paramBoolean);
/* 230 */       k = i4;
/* 231 */       m = i5;
/* 232 */       if (!paramBoolean) {
/* 233 */         arrayOfInt = arrayOfInt1;
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 238 */         arrayOfInt = new int[i * j];
/* 239 */         byte b1 = 0;
/* 240 */         for (byte b2 = 0; b2 < j; b2++) {
/* 241 */           double d = (paramDouble2 + b2 + 0.5D) * d2 - (i1 + 0.5F);
/* 242 */           int i6 = (int)Math.floor(d);
/* 243 */           int i7 = (int)((d - i6) * 256.0D);
/* 244 */           for (byte b = 0; b < i; b++) {
/* 245 */             double d3 = (paramDouble1 + b + 0.5D) * d1 - (n + 0.5F);
/* 246 */             int i8 = (int)Math.floor(d3);
/* 247 */             int i9 = (int)((d3 - i8) * 256.0D);
/* 248 */             arrayOfInt[b1++] = interp(arrayOfInt1, i8, i6, i4, i5, i9, i7);
/*     */           } 
/*     */         } 
/* 251 */         k = i;
/* 252 */         m = j;
/*     */       } 
/*     */     } 
/*     */     
/* 256 */     return convertFromPixels(paramWritableImage, Application.GetApplication().createPixels(k, m, IntBuffer.wrap(arrayOfInt)));
/*     */   }
/*     */   
/*     */   public static int convertToRobotMouseButton(MouseButton[] paramArrayOfMouseButton) {
/* 260 */     int i = 0;
/* 261 */     for (MouseButton mouseButton : paramArrayOfMouseButton) {
/* 262 */       switch (mouseButton) { case PRIMARY:
/* 263 */           i |= 0x1; break;
/* 264 */         case SECONDARY: i |= 0x2; break;
/* 265 */         case MIDDLE: i |= 0x4; break;
/* 266 */         case BACK: i |= 0x8; break;
/* 267 */         case FORWARD: i |= 0x10; break;
/* 268 */         default: throw new IllegalArgumentException("MouseButton: " + mouseButton + " not supported by Robot"); }
/*     */     
/*     */     } 
/* 271 */     return i;
/*     */   }
/*     */   
/*     */   public static Color convertFromIntArgb(int paramInt) {
/* 275 */     int i = paramInt >> 24 & 0xFF;
/* 276 */     int j = paramInt >> 16 & 0xFF;
/* 277 */     int k = paramInt >> 8 & 0xFF;
/* 278 */     int m = paramInt & 0xFF;
/* 279 */     return new Color(j / 255.0D, k / 255.0D, m / 255.0D, i / 255.0D);
/*     */   }
/*     */   
/*     */   protected static WritableImage convertFromPixels(WritableImage paramWritableImage, Pixels paramPixels) {
/* 283 */     Objects.requireNonNull(paramPixels);
/* 284 */     int i = paramPixels.getWidth();
/* 285 */     int j = paramPixels.getHeight();
/* 286 */     if (paramWritableImage == null || paramWritableImage.getWidth() != i || paramWritableImage.getHeight() != j) {
/* 287 */       paramWritableImage = new WritableImage(i, j);
/*     */     }
/*     */     
/* 290 */     int k = paramPixels.getBytesPerComponent();
/* 291 */     if (k == 4) {
/* 292 */       IntBuffer intBuffer = (IntBuffer)paramPixels.getPixels();
/* 293 */       writeIntBufferToImage(intBuffer, paramWritableImage);
/* 294 */     } else if (k == 1) {
/* 295 */       ByteBuffer byteBuffer = (ByteBuffer)paramPixels.getPixels();
/* 296 */       writeByteBufferToImage(byteBuffer, paramWritableImage);
/*     */     } else {
/* 298 */       throw new IllegalArgumentException("bytesPerComponent must be either 4 or 1 but was: " + k);
/*     */     } 
/*     */ 
/*     */     
/* 302 */     return paramWritableImage;
/*     */   }
/*     */   
/*     */   private static void writeIntBufferToImage(IntBuffer paramIntBuffer, WritableImage paramWritableImage) {
/* 306 */     Objects.requireNonNull(paramWritableImage);
/* 307 */     PixelWriter pixelWriter = paramWritableImage.getPixelWriter();
/* 308 */     double d1 = paramWritableImage.getWidth();
/* 309 */     double d2 = paramWritableImage.getHeight();
/*     */     
/* 311 */     for (byte b = 0; b < d2; b++) {
/* 312 */       for (byte b1 = 0; b1 < d1; b1++) {
/* 313 */         int i = paramIntBuffer.get();
/* 314 */         pixelWriter.setArgb(b1, b, i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void writeByteBufferToImage(ByteBuffer paramByteBuffer, WritableImage paramWritableImage) {
/* 320 */     Objects.requireNonNull(paramWritableImage);
/* 321 */     PixelWriter pixelWriter = paramWritableImage.getPixelWriter();
/* 322 */     double d1 = paramWritableImage.getWidth();
/* 323 */     double d2 = paramWritableImage.getHeight();
/*     */     
/* 325 */     int i = Pixels.getNativeFormat();
/*     */     
/* 327 */     for (byte b = 0; b < d2; b++) {
/* 328 */       for (byte b1 = 0; b1 < d1; b1++) {
/* 329 */         if (i == 1) {
/* 330 */           pixelWriter.setArgb(b1, b, PixelUtils.PretoNonPre(bgraPreToRgbaPre(paramByteBuffer.getInt())));
/* 331 */         } else if (i == 2) {
/* 332 */           pixelWriter.setArgb(b1, b, paramByteBuffer.getInt());
/*     */         } else {
/* 334 */           throw new IllegalArgumentException("format must be either BYTE_BGRA_PRE or BYTE_ARGB");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int bgraPreToRgbaPre(int paramInt) {
/* 341 */     return Integer.reverseBytes(paramInt);
/*     */   }
/*     */   
/*     */   private static int interp(int[] paramArrayOfint, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 345 */     int i = 256 - paramInt5;
/* 346 */     int j = 256 - paramInt6;
/* 347 */     int k = paramInt2 * paramInt3 + paramInt1;
/* 348 */     boolean bool1 = (paramInt1 < 0 || paramInt2 < 0 || paramInt1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k];
/* 349 */     if (paramInt6 == 0) {
/*     */       
/* 351 */       if (paramInt5 == 0)
/*     */       {
/* 353 */         return bool1;
/*     */       }
/* 355 */       boolean bool = (paramInt2 < 0 || paramInt1 + 1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k + 1];
/* 356 */       return interp(bool1, bool, i, paramInt5);
/* 357 */     }  if (paramInt5 == 0) {
/*     */       
/* 359 */       boolean bool = (paramInt1 < 0 || paramInt1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3];
/* 360 */       return interp(bool1, bool, j, paramInt6);
/*     */     } 
/*     */     
/* 363 */     boolean bool2 = (paramInt2 < 0 || paramInt1 + 1 >= paramInt3 || paramInt2 >= paramInt4) ? false : paramArrayOfint[k + 1];
/* 364 */     boolean bool3 = (paramInt1 < 0 || paramInt1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3];
/* 365 */     boolean bool4 = (paramInt1 + 1 >= paramInt3 || paramInt2 + 1 >= paramInt4) ? false : paramArrayOfint[k + paramInt3 + 1];
/* 366 */     return interp(interp(bool1, bool2, i, paramInt5), 
/* 367 */         interp(bool3, bool4, i, paramInt5), j, paramInt6);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static int interp(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 373 */     int i = paramInt1 >> 24 & 0xFF;
/* 374 */     int j = paramInt1 >> 16 & 0xFF;
/* 375 */     int k = paramInt1 >> 8 & 0xFF;
/* 376 */     int m = paramInt1 & 0xFF;
/* 377 */     int n = paramInt2 >> 24 & 0xFF;
/* 378 */     int i1 = paramInt2 >> 16 & 0xFF;
/* 379 */     int i2 = paramInt2 >> 8 & 0xFF;
/* 380 */     int i3 = paramInt2 & 0xFF;
/* 381 */     int i4 = i * paramInt3 + n * paramInt4 >> 8;
/* 382 */     int i5 = j * paramInt3 + i1 * paramInt4 >> 8;
/* 383 */     int i6 = k * paramInt3 + i2 * paramInt4 >> 8;
/* 384 */     int i7 = m * paramInt3 + i3 * paramInt4 >> 8;
/* 385 */     return i4 << 24 | i5 << 16 | i6 << 8 | i7;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\GlassRobot.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */