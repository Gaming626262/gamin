/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TouchInputSupport
/*     */ {
/*     */   private boolean filterTouchCoordinates;
/*     */   private Map<Long, TouchCoord> touch;
/*     */   private TouchCountListener listener;
/*     */   private int curTouchCount;
/*     */   private View curView;
/*     */   private int curModifiers;
/*     */   private boolean curIsDirect;
/*  34 */   private int touchCount = 0;
/*     */   
/*     */   public static interface TouchCountListener {
/*     */     void touchCountChanged(TouchInputSupport param1TouchInputSupport, View param1View, int param1Int, boolean param1Boolean); }
/*     */   
/*     */   private static class TouchCoord {
/*     */     private TouchCoord(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/*  41 */       this.x = param1Int1;
/*  42 */       this.y = param1Int2;
/*  43 */       this.xAbs = param1Int3;
/*  44 */       this.yAbs = param1Int4;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final int x;
/*     */ 
/*     */     
/*     */     private final int y;
/*     */ 
/*     */     
/*     */     private final int xAbs;
/*     */ 
/*     */     
/*     */     private final int yAbs;
/*     */   }
/*     */ 
/*     */   
/*     */   public TouchInputSupport(TouchCountListener paramTouchCountListener, boolean paramBoolean) {
/*  63 */     Application.checkEventThread();
/*  64 */     this.listener = paramTouchCountListener;
/*  65 */     this.filterTouchCoordinates = paramBoolean;
/*  66 */     if (paramBoolean) {
/*  67 */       this.touch = new HashMap<>();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getTouchCount() {
/*  72 */     Application.checkEventThread();
/*  73 */     return this.touchCount;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyBeginTouchEvent(View paramView, int paramInt1, boolean paramBoolean, int paramInt2) {
/*  79 */     if (this.curView != null && paramView != this.curView && this.touchCount != 0 && this.touch != null) {
/*  80 */       if (!this.curView.isClosed()) {
/*     */         
/*  82 */         this.curView.notifyBeginTouchEvent(0, true, this.touchCount);
/*  83 */         for (Map.Entry<Long, TouchCoord> entry : this.touch.entrySet()) {
/*  84 */           TouchCoord touchCoord = (TouchCoord)entry.getValue();
/*  85 */           this.curView.notifyNextTouchEvent(813, ((Long)entry.getKey()).longValue(), touchCoord.x, touchCoord.y, touchCoord.xAbs, touchCoord.yAbs);
/*     */         } 
/*  87 */         this.curView.notifyEndTouchEvent();
/*     */       } 
/*  89 */       this.touch.clear();
/*  90 */       this.touchCount = 0;
/*  91 */       if (this.listener != null) {
/*  92 */         this.listener.touchCountChanged(this, this.curView, 0, true);
/*     */       }
/*     */     } 
/*     */     
/*  96 */     this.curTouchCount = this.touchCount;
/*  97 */     this.curView = paramView;
/*  98 */     this.curModifiers = paramInt1;
/*  99 */     this.curIsDirect = paramBoolean;
/* 100 */     if (paramView != null) {
/* 101 */       paramView.notifyBeginTouchEvent(paramInt1, paramBoolean, paramInt2);
/*     */     }
/*     */   }
/*     */   
/*     */   public void notifyEndTouchEvent(View paramView) {
/* 106 */     if (paramView == null) {
/*     */       return;
/*     */     }
/*     */     
/* 110 */     paramView.notifyEndTouchEvent();
/*     */ 
/*     */     
/* 113 */     if (this.curTouchCount != 0 && this.touchCount != 0 && this.curTouchCount != this.touchCount && this.listener != null)
/*     */     {
/* 115 */       this.listener.touchCountChanged(this, this.curView, this.curModifiers, this.curIsDirect);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyNextTouchEvent(View paramView, int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 122 */     switch (paramInt1) {
/*     */       case 813:
/* 124 */         this.touchCount--;
/*     */         break;
/*     */       case 811:
/* 127 */         this.touchCount++;
/*     */         break;
/*     */       case 812:
/*     */       case 814:
/*     */         break;
/*     */       default:
/* 133 */         System.err.println("Unknown touch state: " + paramInt1);
/*     */         return;
/*     */     } 
/*     */     
/* 137 */     if (this.filterTouchCoordinates) {
/* 138 */       paramInt1 = filterTouchInputState(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     }
/*     */     
/* 141 */     if (paramView != null)
/* 142 */       paramView.notifyNextTouchEvent(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5); 
/*     */   }
/*     */   
/*     */   private int filterTouchInputState(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*     */     TouchCoord touchCoord;
/* 147 */     switch (paramInt1) {
/*     */       case 813:
/* 149 */         this.touch.remove(Long.valueOf(paramLong));
/*     */       
/*     */       case 812:
/* 152 */         touchCoord = this.touch.get(Long.valueOf(paramLong));
/* 153 */         if (paramInt2 == touchCoord.x && paramInt3 == touchCoord.y) {
/* 154 */           paramInt1 = 814;
/*     */         }
/*     */ 
/*     */       
/*     */       case 811:
/* 159 */         this.touch.put(Long.valueOf(paramLong), new TouchCoord(paramInt2, paramInt3, paramInt4, paramInt5));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 814:
/* 167 */         return paramInt1;
/*     */     } 
/*     */     System.err.println("Unknown touch state: " + paramInt1);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\TouchInputSupport.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */