/*      */ package com.sun.glass.ui;
/*      */ 
/*      */ import com.sun.prism.impl.PrismSettings;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Window
/*      */ {
/*      */   private long ptr;
/*      */   
/*      */   public static class EventHandler
/*      */   {
/*      */     public void handleWindowEvent(Window param1Window, long param1Long, int param1Int) {}
/*      */     
/*      */     public void handleScreenChangedEvent(Window param1Window, long param1Long, Screen param1Screen1, Screen param1Screen2) {}
/*      */     
/*      */     public void handleLevelEvent(int param1Int) {}
/*      */   }
/*      */   
/*   84 */   private volatile long delegatePtr = 0L;
/*      */ 
/*      */   
/*   87 */   private static final LinkedList<Window> visibleWindows = new LinkedList<>(); public static final int UNTITLED = 0; public static final int TITLED = 1; public static final int TRANSPARENT = 2; public static final int NORMAL = 0; public static final int UTILITY = 4; public static final int POPUP = 8;
/*      */   public static final int CLOSABLE = 16;
/*      */   
/*      */   public static synchronized List<Window> getWindows() {
/*   91 */     Application.checkEventThread();
/*   92 */     return Collections.unmodifiableList(visibleWindows);
/*      */   }
/*      */   public static final int MINIMIZABLE = 32; public static final int MAXIMIZABLE = 64; public static final int RIGHT_TO_LEFT = 128; public static final int UNIFIED = 256; public static final int MODAL = 512; private final Window owner; private final int styleMask; private final boolean isDecorated;
/*      */   public static List<Window> getWindowsClone() {
/*   96 */     Application.checkEventThread();
/*   97 */     return (List<Window>)visibleWindows.clone();
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void add(Window paramWindow) {
/*  102 */     visibleWindows.add(paramWindow);
/*      */   }
/*      */   
/*      */   protected static void addFirst(Window paramWindow) {
/*  106 */     visibleWindows.addFirst(paramWindow);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static void remove(Window paramWindow) {
/*  111 */     visibleWindows.remove(paramWindow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class State
/*      */   {
/*      */     public static final int NORMAL = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int MINIMIZED = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int MAXIMIZED = 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Level
/*      */   {
/*      */     private static final int _MIN = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int NORMAL = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int FLOATING = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int TOPMOST = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final int _MAX = 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldStartUndecoratedMove = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   protected View view = null;
/*  203 */   protected Screen screen = null;
/*  204 */   private MenuBar menubar = null;
/*  205 */   private String title = "";
/*  206 */   private UndecoratedMoveResizeHelper helper = null;
/*      */   
/*  208 */   private int state = 1;
/*  209 */   private int level = 1;
/*  210 */   protected int x = 0;
/*  211 */   protected int y = 0;
/*  212 */   protected int width = 0;
/*  213 */   protected int height = 0;
/*  214 */   private float alpha = 1.0F;
/*  215 */   protected float platformScaleX = 1.0F;
/*  216 */   protected float platformScaleY = 1.0F;
/*  217 */   private float outputScaleX = 1.0F;
/*  218 */   private float outputScaleY = 1.0F;
/*  219 */   private float renderScaleX = 1.0F;
/*  220 */   private float renderScaleY = 1.0F;
/*      */   
/*      */   private volatile boolean isResizable = false;
/*      */   
/*      */   private volatile boolean isVisible = false;
/*      */   
/*      */   private volatile boolean isFocused = false;
/*      */   
/*      */   private volatile boolean isFocusable = true;
/*      */   private volatile boolean isModal = false;
/*  230 */   private volatile int disableCount = 0;
/*      */   
/*  232 */   private int minimumWidth = 0, minimumHeight = 0;
/*  233 */   private int maximumWidth = Integer.MAX_VALUE; private int maximumHeight = Integer.MAX_VALUE;
/*      */   private EventHandler eventHandler;
/*      */   
/*      */   protected abstract long _createWindow(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   protected Window(Window paramWindow, Screen paramScreen, int paramInt) {
/*  239 */     Application.checkEventThread();
/*  240 */     switch (paramInt & 0x3) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */         break;
/*      */       default:
/*  246 */         throw new RuntimeException("The visual kind should be UNTITLED, TITLED, or TRANSPARENT, but not a combination of these");
/*      */     } 
/*  248 */     switch (paramInt & 0xC) {
/*      */       case 0:
/*      */       case 4:
/*      */       case 8:
/*      */         break;
/*      */       default:
/*  254 */         throw new RuntimeException("The functional type should be NORMAL, POPUP, or UTILITY, but not a combination of these");
/*      */     } 
/*      */     
/*  257 */     if ((paramInt & 0x100) != 0 && 
/*  258 */       !Application.GetApplication().supportsUnifiedWindows()) {
/*  259 */       paramInt &= 0xFFFFFEFF;
/*      */     }
/*      */     
/*  262 */     if ((paramInt & 0x2) != 0 && 
/*  263 */       !Application.GetApplication().supportsTransparentWindows()) {
/*  264 */       paramInt &= 0xFFFFFFFD;
/*      */     }
/*      */ 
/*      */     
/*  268 */     this.owner = paramWindow;
/*  269 */     this.styleMask = paramInt;
/*  270 */     this.isDecorated = ((this.styleMask & 0x1) != 0);
/*      */     
/*  272 */     this.screen = (paramScreen != null) ? paramScreen : Screen.getMainScreen();
/*  273 */     if (PrismSettings.allowHiDPIScaling) {
/*  274 */       this.platformScaleX = this.screen.getPlatformScaleX();
/*  275 */       this.platformScaleY = this.screen.getPlatformScaleY();
/*  276 */       this.outputScaleX = this.screen.getRecommendedOutputScaleX();
/*  277 */       this.outputScaleY = this.screen.getRecommendedOutputScaleY();
/*      */     } 
/*      */     
/*  280 */     this.ptr = _createWindow((paramWindow != null) ? paramWindow.getNativeHandle() : 0L, this.screen
/*  281 */         .getNativeScreen(), this.styleMask);
/*  282 */     if (this.ptr == 0L) {
/*  283 */       throw new RuntimeException("could not create platform window");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  288 */     Application.checkEventThread();
/*  289 */     return (this.ptr == 0L);
/*      */   }
/*      */   
/*      */   private void checkNotClosed() {
/*  293 */     if (this.ptr == 0L)
/*  294 */       throw new IllegalStateException("The window has already been closed"); 
/*      */   }
/*      */   
/*      */   protected abstract boolean _close(long paramLong);
/*      */   
/*      */   public void close() {
/*  300 */     Application.checkEventThread();
/*  301 */     if (this.view != null) {
/*  302 */       if (this.ptr != 0L) {
/*  303 */         _setView(this.ptr, null);
/*      */       }
/*  305 */       this.view.setWindow(null);
/*  306 */       this.view.close();
/*  307 */       this.view = null;
/*      */     } 
/*  309 */     if (this.ptr != 0L) {
/*  310 */       _close(this.ptr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeWindow() {
/*  318 */     Application.checkEventThread();
/*  319 */     checkNotClosed();
/*  320 */     return (this.delegatePtr != 0L) ? this.delegatePtr : this.ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getNativeHandle() {
/*  328 */     Application.checkEventThread();
/*  329 */     return (this.delegatePtr != 0L) ? this.delegatePtr : this.ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getRawHandle() {
/*  337 */     return this.ptr;
/*      */   }
/*      */   
/*      */   public Window getOwner() {
/*  341 */     Application.checkEventThread();
/*  342 */     return this.owner;
/*      */   }
/*      */   
/*      */   public View getView() {
/*  346 */     Application.checkEventThread();
/*  347 */     return this.view;
/*      */   }
/*      */   protected abstract boolean _setView(long paramLong, View paramView);
/*      */   protected abstract void _updateViewSize(long paramLong);
/*      */   
/*      */   public void setView(View paramView) {
/*  353 */     Application.checkEventThread();
/*  354 */     checkNotClosed();
/*  355 */     View view = getView();
/*  356 */     if (view == paramView) {
/*      */       return;
/*      */     }
/*      */     
/*  360 */     if (view != null) {
/*  361 */       view.setWindow(null);
/*      */     }
/*  363 */     if (paramView != null) {
/*  364 */       Window window = paramView.getWindow();
/*  365 */       if (window != null) {
/*  366 */         window.setView(null);
/*      */       }
/*      */     } 
/*      */     
/*  370 */     if (paramView != null && _setView(this.ptr, paramView)) {
/*  371 */       this.view = paramView;
/*  372 */       this.view.setWindow(this);
/*      */ 
/*      */ 
/*      */       
/*  376 */       _updateViewSize(this.ptr);
/*  377 */       if (!this.isDecorated) {
/*  378 */         this.helper = new UndecoratedMoveResizeHelper();
/*      */       }
/*      */     } else {
/*  381 */       _setView(this.ptr, null);
/*  382 */       this.view = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public Screen getScreen() {
/*  387 */     Application.checkEventThread();
/*  388 */     return this.screen;
/*      */   }
/*      */   
/*      */   protected void setScreen(Screen paramScreen) {
/*  392 */     Application.checkEventThread();
/*      */     
/*  394 */     Screen screen = this.screen;
/*  395 */     this.screen = paramScreen;
/*      */     
/*  397 */     if (this.eventHandler != null && ((
/*  398 */       screen == null && this.screen != null) || (screen != null && 
/*  399 */       !screen.equals(this.screen)))) {
/*  400 */       this.eventHandler.handleScreenChangedEvent(this, System.nanoTime(), screen, this.screen);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public int getStyleMask() {
/*  406 */     Application.checkEventThread();
/*  407 */     return this.styleMask;
/*      */   }
/*      */   
/*      */   public MenuBar getMenuBar() {
/*  411 */     Application.checkEventThread();
/*  412 */     return this.menubar;
/*      */   }
/*      */   protected abstract boolean _setMenubar(long paramLong1, long paramLong2);
/*      */   
/*      */   public void setMenuBar(MenuBar paramMenuBar) {
/*  417 */     Application.checkEventThread();
/*  418 */     checkNotClosed();
/*  419 */     if (_setMenubar(this.ptr, paramMenuBar.getNativeMenu())) {
/*  420 */       this.menubar = paramMenuBar;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isDecorated() {
/*  425 */     Application.checkEventThread();
/*  426 */     return this.isDecorated;
/*      */   }
/*      */   
/*      */   public boolean isMinimized() {
/*  430 */     Application.checkEventThread();
/*  431 */     return (this.state == 2);
/*      */   }
/*      */   protected abstract boolean _minimize(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public boolean minimize(boolean paramBoolean) {
/*  436 */     Application.checkEventThread();
/*  437 */     checkNotClosed();
/*  438 */     _minimize(this.ptr, paramBoolean);
/*      */     
/*  440 */     return isMinimized();
/*      */   }
/*      */   
/*      */   public boolean isMaximized() {
/*  444 */     Application.checkEventThread();
/*  445 */     return (this.state == 3);
/*      */   }
/*      */   protected abstract boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2);
/*      */   
/*      */   public boolean maximize(boolean paramBoolean) {
/*  450 */     Application.checkEventThread();
/*  451 */     checkNotClosed();
/*  452 */     _maximize(this.ptr, paramBoolean, isMaximized());
/*  453 */     return isMaximized();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyScaleChanged(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  459 */     if (!PrismSettings.allowHiDPIScaling)
/*  460 */       return;  this.platformScaleX = paramFloat1;
/*  461 */     this.platformScaleY = paramFloat2;
/*  462 */     this.outputScaleX = paramFloat3;
/*  463 */     this.outputScaleY = paramFloat4;
/*  464 */     notifyRescale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getPlatformScaleX() {
/*  473 */     return this.platformScaleX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getPlatformScaleY() {
/*  482 */     return this.platformScaleY;
/*      */   }
/*      */   
/*      */   public void setRenderScaleX(float paramFloat) {
/*  486 */     if (!PrismSettings.allowHiDPIScaling)
/*  487 */       return;  this.renderScaleX = paramFloat;
/*      */   }
/*      */   
/*      */   public void setRenderScaleY(float paramFloat) {
/*  491 */     if (!PrismSettings.allowHiDPIScaling)
/*  492 */       return;  this.renderScaleY = paramFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getRenderScaleX() {
/*  500 */     return this.renderScaleX;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final float getRenderScaleY() {
/*  508 */     return this.renderScaleY;
/*      */   }
/*      */   
/*      */   public float getOutputScaleX() {
/*  512 */     return this.outputScaleX;
/*      */   }
/*      */   
/*      */   public float getOutputScaleY() {
/*  516 */     return this.outputScaleY;
/*      */   }
/*      */   
/*      */   public int getX() {
/*  520 */     Application.checkEventThread();
/*  521 */     return this.x;
/*      */   }
/*      */   
/*      */   public int getY() {
/*  525 */     Application.checkEventThread();
/*  526 */     return this.y;
/*      */   }
/*      */   
/*      */   public int getWidth() {
/*  530 */     Application.checkEventThread();
/*  531 */     return this.width;
/*      */   }
/*      */   
/*      */   public int getHeight() {
/*  535 */     Application.checkEventThread();
/*  536 */     return this.height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setBounds(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBounds(float paramFloat1, float paramFloat2, boolean paramBoolean1, boolean paramBoolean2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) {
/*  573 */     Application.checkEventThread();
/*  574 */     checkNotClosed();
/*  575 */     float f1 = this.platformScaleX;
/*  576 */     float f2 = this.platformScaleY;
/*  577 */     int i = this.screen.getPlatformX() + Math.round((paramFloat1 - this.screen.getX()) * f1);
/*  578 */     int j = this.screen.getPlatformY() + Math.round((paramFloat2 - this.screen.getY()) * f2);
/*  579 */     int k = (int)((paramFloat3 > 0.0F) ? Math.ceil((paramFloat3 * f1)) : paramFloat3);
/*  580 */     int m = (int)((paramFloat4 > 0.0F) ? Math.ceil((paramFloat4 * f2)) : paramFloat4);
/*  581 */     int n = (int)((paramFloat5 > 0.0F) ? Math.ceil((paramFloat5 * f1)) : paramFloat5);
/*  582 */     int i1 = (int)((paramFloat6 > 0.0F) ? Math.ceil((paramFloat6 * f2)) : paramFloat6);
/*  583 */     _setBounds(this.ptr, i, j, paramBoolean1, paramBoolean2, k, m, n, i1, paramFloat7, paramFloat8);
/*      */   }
/*      */   
/*      */   public void setPosition(int paramInt1, int paramInt2) {
/*  587 */     Application.checkEventThread();
/*  588 */     checkNotClosed();
/*  589 */     _setBounds(this.ptr, paramInt1, paramInt2, true, true, 0, 0, 0, 0, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public void setSize(int paramInt1, int paramInt2) {
/*  593 */     Application.checkEventThread();
/*  594 */     checkNotClosed();
/*  595 */     _setBounds(this.ptr, 0, 0, false, false, paramInt1, paramInt2, 0, 0, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public void setContentSize(int paramInt1, int paramInt2) {
/*  599 */     Application.checkEventThread();
/*  600 */     checkNotClosed();
/*  601 */     _setBounds(this.ptr, 0, 0, false, false, 0, 0, paramInt1, paramInt2, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */   public boolean isVisible() {
/*  605 */     Application.checkEventThread();
/*  606 */     return this.isVisible;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void synthesizeViewMoveEvent() {
/*  613 */     View view = getView();
/*  614 */     if (view != null)
/*  615 */       view.notifyView(423); 
/*      */   }
/*      */   
/*      */   protected abstract boolean _setVisible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public void setVisible(boolean paramBoolean) {
/*  621 */     Application.checkEventThread();
/*  622 */     if (this.isVisible != paramBoolean)
/*  623 */       if (!paramBoolean) {
/*  624 */         if (getView() != null) {
/*  625 */           getView().setVisible(paramBoolean);
/*      */         }
/*      */         
/*  628 */         if (this.ptr != 0L) {
/*  629 */           this.isVisible = _setVisible(this.ptr, paramBoolean);
/*      */         } else {
/*  631 */           this.isVisible = paramBoolean;
/*      */         } 
/*  633 */         remove(this);
/*      */       } else {
/*  635 */         checkNotClosed();
/*  636 */         this.isVisible = _setVisible(this.ptr, paramBoolean);
/*      */         
/*  638 */         if (getView() != null) {
/*  639 */           getView().setVisible(this.isVisible);
/*      */         }
/*  641 */         add(this);
/*      */         
/*  643 */         synthesizeViewMoveEvent();
/*      */       }  
/*      */   }
/*      */   
/*      */   protected abstract boolean _setResizable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public boolean setResizable(boolean paramBoolean) {
/*  650 */     Application.checkEventThread();
/*  651 */     checkNotClosed();
/*  652 */     if (this.isResizable != paramBoolean && 
/*  653 */       _setResizable(this.ptr, paramBoolean)) {
/*  654 */       this.isResizable = paramBoolean;
/*  655 */       synthesizeViewMoveEvent();
/*      */     } 
/*      */     
/*  658 */     return this.isResizable;
/*      */   }
/*      */   
/*      */   public boolean isResizable() {
/*  662 */     Application.checkEventThread();
/*  663 */     return this.isResizable;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUnifiedWindow() {
/*  668 */     return ((this.styleMask & 0x100) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTransparentWindow() {
/*  673 */     return ((this.styleMask & 0x2) != 0);
/*      */   }
/*      */   
/*      */   public boolean isFocused() {
/*  677 */     Application.checkEventThread();
/*  678 */     return this.isFocused;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean _requestFocus(long paramLong, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requestFocus(int paramInt) {
/*  698 */     Application.checkEventThread();
/*  699 */     checkNotClosed();
/*      */     
/*  701 */     if (paramInt != 542) {
/*  702 */       throw new IllegalArgumentException("Invalid focus event ID for top-level window");
/*      */     }
/*      */     
/*  705 */     if (paramInt == 541 && !isFocused())
/*      */     {
/*  707 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  712 */     if (!this.isFocusable)
/*      */     {
/*  714 */       return false;
/*      */     }
/*      */     
/*  717 */     return _requestFocus(this.ptr, paramInt);
/*      */   }
/*      */   
/*      */   public boolean requestFocus() {
/*  721 */     Application.checkEventThread();
/*  722 */     return requestFocus(542);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setFocusable(long paramLong, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFocusable(boolean paramBoolean) {
/*  732 */     Application.checkEventThread();
/*  733 */     checkNotClosed();
/*  734 */     this.isFocusable = paramBoolean;
/*  735 */     if (isEnabled()) {
/*  736 */       _setFocusable(this.ptr, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean _grabFocus(long paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _ungrabFocus(long paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean grabFocus() {
/*  786 */     Application.checkEventThread();
/*  787 */     checkNotClosed();
/*      */     
/*  789 */     if (!isFocused()) {
/*  790 */       throw new IllegalStateException("The window must be focused when calling grabFocus()");
/*      */     }
/*      */     
/*  793 */     return _grabFocus(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ungrabFocus() {
/*  807 */     Application.checkEventThread();
/*  808 */     checkNotClosed();
/*  809 */     _ungrabFocus(this.ptr);
/*      */   }
/*      */   
/*      */   public String getTitle() {
/*  813 */     Application.checkEventThread();
/*  814 */     return this.title;
/*      */   }
/*      */   protected abstract boolean _setTitle(long paramLong, String paramString);
/*      */   
/*      */   public void setTitle(String paramString) {
/*  819 */     Application.checkEventThread();
/*  820 */     checkNotClosed();
/*  821 */     if (paramString == null) {
/*  822 */       paramString = "";
/*      */     }
/*  824 */     if (!paramString.equals(this.title) && 
/*  825 */       _setTitle(this.ptr, paramString)) {
/*  826 */       this.title = paramString;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setLevel(long paramLong, int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLevel(int paramInt) {
/*  839 */     Application.checkEventThread();
/*  840 */     checkNotClosed();
/*  841 */     if (paramInt < 1 || paramInt > 3) {
/*  842 */       throw new IllegalArgumentException("Level should be in the range [1..3]");
/*      */     }
/*  844 */     if (this.level != paramInt) {
/*  845 */       _setLevel(this.ptr, paramInt);
/*  846 */       this.level = paramInt;
/*      */     } 
/*      */   }
/*      */   
/*      */   public int getLevel() {
/*  851 */     Application.checkEventThread();
/*  852 */     return this.level;
/*      */   }
/*      */   
/*      */   private boolean isInFullscreen() {
/*  856 */     View view = getView();
/*  857 */     return (view == null) ? false : view.isInFullscreen();
/*      */   }
/*      */ 
/*      */   
/*      */   void notifyFullscreen(boolean paramBoolean) {
/*  862 */     float f = getAlpha();
/*  863 */     if (f < 1.0F) {
/*  864 */       if (paramBoolean) {
/*      */         
/*  866 */         _setAlpha(this.ptr, 1.0F);
/*      */       } else {
/*      */         
/*  869 */         setAlpha(f);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setAlpha(long paramLong, float paramFloat);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlpha(float paramFloat) {
/*  885 */     Application.checkEventThread();
/*  886 */     checkNotClosed();
/*  887 */     if (paramFloat < 0.0F || paramFloat > 1.0F) {
/*  888 */       throw new IllegalArgumentException("Alpha should be in the range [0f..1f]");
/*      */     }
/*      */     
/*  891 */     this.alpha = paramFloat;
/*      */     
/*  893 */     if (paramFloat < 1.0F && isInFullscreen()) {
/*      */       return;
/*      */     }
/*      */     
/*  897 */     _setAlpha(this.ptr, this.alpha);
/*      */   }
/*      */   
/*      */   public float getAlpha() {
/*  901 */     Application.checkEventThread();
/*  902 */     return this.alpha;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean _setBackground(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setBackground(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  919 */     Application.checkEventThread();
/*  920 */     checkNotClosed();
/*  921 */     return _setBackground(this.ptr, paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */   
/*      */   public boolean isEnabled() {
/*  925 */     Application.checkEventThread();
/*  926 */     return (this.disableCount == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setEnabled(long paramLong, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean paramBoolean) {
/*  957 */     Application.checkEventThread();
/*  958 */     checkNotClosed();
/*  959 */     if (!paramBoolean) {
/*  960 */       if (++this.disableCount > 1) {
/*      */         return;
/*      */       }
/*      */     } else {
/*      */       
/*  965 */       if (this.disableCount == 0) {
/*      */         return;
/*      */       }
/*      */       
/*  969 */       if (--this.disableCount > 0) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  976 */     _setEnabled(this.ptr, isEnabled());
/*      */   }
/*      */   
/*      */   public int getMinimumWidth() {
/*  980 */     Application.checkEventThread();
/*  981 */     return this.minimumWidth;
/*      */   }
/*      */   
/*      */   public int getMinimumHeight() {
/*  985 */     Application.checkEventThread();
/*  986 */     return this.minimumHeight;
/*      */   }
/*      */   
/*      */   public int getMaximumWidth() {
/*  990 */     Application.checkEventThread();
/*  991 */     return this.maximumWidth;
/*      */   }
/*      */   
/*      */   public int getMaximumHeight() {
/*  995 */     Application.checkEventThread();
/*  996 */     return this.maximumHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinimumSize(int paramInt1, int paramInt2) {
/* 1009 */     Application.checkEventThread();
/* 1010 */     if (paramInt1 < 0 || paramInt2 < 0) {
/* 1011 */       throw new IllegalArgumentException("The width and height must be >= 0. Got: width=" + paramInt1 + "; height=" + paramInt2);
/*      */     }
/* 1013 */     checkNotClosed();
/* 1014 */     if (_setMinimumSize(this.ptr, paramInt1, paramInt2)) {
/* 1015 */       this.minimumWidth = paramInt1;
/* 1016 */       this.minimumHeight = paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaximumSize(int paramInt1, int paramInt2) {
/* 1030 */     Application.checkEventThread();
/* 1031 */     if (paramInt1 < 0 || paramInt2 < 0) {
/* 1032 */       throw new IllegalArgumentException("The width and height must be >= 0. Got: width=" + paramInt1 + "; height=" + paramInt2);
/*      */     }
/* 1034 */     checkNotClosed();
/* 1035 */     if (_setMaximumSize(this.ptr, 
/*      */         
/* 1037 */         (paramInt1 == Integer.MAX_VALUE) ? -1 : paramInt1, 
/* 1038 */         (paramInt2 == Integer.MAX_VALUE) ? -1 : paramInt2)) {
/*      */       
/* 1040 */       this.maximumWidth = paramInt1;
/* 1041 */       this.maximumHeight = paramInt2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setIcon(long paramLong, Pixels paramPixels);
/*      */ 
/*      */   
/*      */   public void setIcon(Pixels paramPixels) {
/* 1051 */     Application.checkEventThread();
/* 1052 */     checkNotClosed();
/* 1053 */     _setIcon(this.ptr, paramPixels);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _setCursor(long paramLong, Cursor paramCursor);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(Cursor paramCursor) {
/* 1065 */     Application.checkEventThread();
/* 1066 */     _setCursor(this.ptr, paramCursor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _toFront(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public void toFront() {
/* 1076 */     Application.checkEventThread();
/* 1077 */     checkNotClosed();
/* 1078 */     _toFront(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _toBack(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public void toBack() {
/* 1089 */     Application.checkEventThread();
/* 1090 */     checkNotClosed();
/* 1091 */     _toBack(this.ptr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _enterModal(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterModal() {
/* 1102 */     checkNotClosed();
/* 1103 */     if (!this.isModal) {
/* 1104 */       this.isModal = true;
/* 1105 */       _enterModal(this.ptr);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void _enterModalWithWindow(long paramLong1, long paramLong2);
/*      */ 
/*      */   
/*      */   public void enterModal(Window paramWindow) {
/* 1115 */     checkNotClosed();
/* 1116 */     if (!this.isModal) {
/* 1117 */       this.isModal = true;
/* 1118 */       _enterModalWithWindow(this.ptr, paramWindow.getNativeHandle());
/*      */     } 
/*      */   }
/*      */   protected abstract void _exitModal(long paramLong);
/*      */   
/*      */   public void exitModal() {
/* 1124 */     checkNotClosed();
/* 1125 */     if (this.isModal == true) {
/* 1126 */       _exitModal(this.ptr);
/* 1127 */       this.isModal = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isModal() {
/* 1132 */     return this.isModal;
/*      */   }
/*      */   
/*      */   public EventHandler getEventHandler() {
/* 1136 */     Application.checkEventThread();
/* 1137 */     return this.eventHandler;
/*      */   }
/*      */   
/*      */   public void setEventHandler(EventHandler paramEventHandler) {
/* 1141 */     Application.checkEventThread();
/* 1142 */     this.eventHandler = paramEventHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShouldStartUndecoratedMove(boolean paramBoolean) {
/* 1150 */     Application.checkEventThread();
/* 1151 */     this.shouldStartUndecoratedMove = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyClose() {
/* 1158 */     handleWindowEvent(System.nanoTime(), 521);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void notifyDestroy() {
/* 1163 */     if (this.ptr == 0L) {
/*      */       return;
/*      */     }
/*      */     
/* 1167 */     handleWindowEvent(System.nanoTime(), 522);
/*      */     
/* 1169 */     this.ptr = 0L;
/*      */ 
/*      */     
/* 1172 */     setVisible(false);
/*      */   }
/*      */   
/*      */   protected void notifyMove(int paramInt1, int paramInt2) {
/* 1176 */     this.x = paramInt1;
/* 1177 */     this.y = paramInt2;
/* 1178 */     handleWindowEvent(System.nanoTime(), 512);
/*      */   }
/*      */   
/*      */   protected void notifyRescale() {
/* 1182 */     handleWindowEvent(System.nanoTime(), 513);
/*      */   }
/*      */   
/*      */   protected void notifyMoveToAnotherScreen(Screen paramScreen) {
/* 1186 */     setScreen(paramScreen);
/*      */   }
/*      */   
/*      */   protected void setState(int paramInt) {
/* 1190 */     this.state = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyResize(int paramInt1, int paramInt2, int paramInt3) {
/* 1201 */     if (paramInt1 == 531) {
/* 1202 */       this.state = 2;
/*      */     } else {
/* 1204 */       if (paramInt1 == 532) {
/* 1205 */         this.state = 3;
/*      */       } else {
/* 1207 */         this.state = 1;
/*      */       } 
/* 1209 */       this.width = paramInt2;
/* 1210 */       this.height = paramInt3;
/*      */ 
/*      */       
/* 1213 */       if (this.helper != null) {
/* 1214 */         this.helper.updateRectangles();
/*      */       }
/*      */     } 
/* 1217 */     handleWindowEvent(System.nanoTime(), paramInt1);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1222 */     if (paramInt1 == 532 || paramInt1 == 533) {
/* 1223 */       handleWindowEvent(System.nanoTime(), 511);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void notifyFocus(int paramInt) {
/* 1228 */     boolean bool = (paramInt != 541);
/*      */     
/* 1230 */     if (this.isFocused != bool) {
/* 1231 */       this.isFocused = bool;
/* 1232 */       handleWindowEvent(System.nanoTime(), paramInt);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void notifyFocusDisabled() {
/* 1237 */     handleWindowEvent(System.nanoTime(), 545);
/*      */   }
/*      */   
/*      */   protected void notifyFocusUngrab() {
/* 1241 */     handleWindowEvent(System.nanoTime(), 546);
/*      */   }
/*      */   
/*      */   protected void notifyDelegatePtr(long paramLong) {
/* 1245 */     this.delegatePtr = paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleWindowEvent(long paramLong, int paramInt) {
/* 1252 */     if (this.eventHandler != null) {
/* 1253 */       this.eventHandler.handleWindowEvent(this, paramLong, paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUndecoratedMoveRectangle(int paramInt) {
/* 1267 */     Application.checkEventThread();
/* 1268 */     if (this.isDecorated == true) {
/*      */       
/* 1270 */       System.err.println("Glass Window.setUndecoratedMoveRectangle is only valid for Undecorated Window. In the future this will be hard error.");
/* 1271 */       Thread.dumpStack();
/*      */       
/*      */       return;
/*      */     } 
/* 1275 */     if (this.helper != null) {
/* 1276 */       this.helper.setMoveRectangle(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldStartUndecoratedMove(int paramInt1, int paramInt2) {
/* 1285 */     Application.checkEventThread();
/* 1286 */     if (this.shouldStartUndecoratedMove == true) {
/* 1287 */       return true;
/*      */     }
/* 1289 */     if (this.isDecorated == true) {
/* 1290 */       return false;
/*      */     }
/*      */     
/* 1293 */     if (this.helper != null) {
/* 1294 */       return this.helper.shouldStartMove(paramInt1, paramInt2);
/*      */     }
/* 1296 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUndecoratedResizeRectangle(int paramInt) {
/* 1307 */     Application.checkEventThread();
/* 1308 */     if (this.isDecorated == true || !this.isResizable) {
/*      */       
/* 1310 */       System.err.println("Glass Window.setUndecoratedResizeRectangle is only valid for Undecorated Resizable Window. In the future this will be hard error.");
/* 1311 */       Thread.dumpStack();
/*      */       
/*      */       return;
/*      */     } 
/* 1315 */     if (this.helper != null) {
/* 1316 */       this.helper.setResizeRectangle(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean shouldStartUndecoratedResize(int paramInt1, int paramInt2) {
/* 1326 */     Application.checkEventThread();
/* 1327 */     if (this.isDecorated == true || !this.isResizable) {
/* 1328 */       return false;
/*      */     }
/*      */     
/* 1331 */     if (this.helper != null) {
/* 1332 */       return this.helper.shouldStartResize(paramInt1, paramInt2);
/*      */     }
/* 1334 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean handleMouseEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 1347 */     if (!this.isDecorated) {
/* 1348 */       return this.helper.handleMouseEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*      */     }
/* 1350 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1355 */     Application.checkEventThread();
/*      */     
/* 1357 */     return "Window:\n    ptr: " + getNativeWindow() + "\n    screen ptr: " + (
/* 1358 */       (this.screen != null) ? (String)Long.valueOf(this.screen.getNativeScreen()) : "null") + "\n    isDecorated: " + 
/* 1359 */       isDecorated() + "\n    title: " + 
/* 1360 */       getTitle() + "\n    visible: " + 
/* 1361 */       isVisible() + "\n    focused: " + 
/* 1362 */       isFocused() + "\n    modal: " + 
/* 1363 */       isModal() + "\n    state: " + this.state + "\n    x: " + 
/*      */       
/* 1365 */       getX() + ", y: " + getY() + ", w: " + getWidth() + ", h: " + getHeight() + "\n";
/*      */   }
/*      */   private static class TrackingRectangle { int size; int x; int y;
/*      */     int width;
/*      */     int height;
/*      */     
/*      */     private TrackingRectangle() {
/* 1372 */       this.size = 0;
/* 1373 */       this.x = 0; this.y = 0; this.width = 0; this.height = 0;
/*      */     } boolean contains(int param1Int1, int param1Int2) {
/* 1375 */       return (this.size > 0 && param1Int1 >= this.x && param1Int1 < this.x + this.width && param1Int2 >= this.y && param1Int2 < this.y + this.height);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyLevelChanged(int paramInt) {
/* 1382 */     this.level = paramInt;
/* 1383 */     if (this.eventHandler != null)
/* 1384 */       this.eventHandler.handleLevelEvent(paramInt); 
/*      */   }
/*      */   
/*      */   private class UndecoratedMoveResizeHelper
/*      */   {
/* 1389 */     Window.TrackingRectangle moveRect = null;
/* 1390 */     Window.TrackingRectangle resizeRect = null; boolean inMove = false;
/*      */     boolean inResize = false;
/*      */     int startMouseX;
/*      */     int startMouseY;
/*      */     int startX;
/*      */     int startY;
/*      */     int startWidth;
/*      */     int startHeight;
/*      */     
/*      */     UndecoratedMoveResizeHelper() {
/* 1400 */       this.moveRect = new Window.TrackingRectangle();
/* 1401 */       this.resizeRect = new Window.TrackingRectangle();
/*      */     }
/*      */     
/*      */     void setMoveRectangle(int param1Int) {
/* 1405 */       this.moveRect.size = param1Int;
/*      */       
/* 1407 */       this.moveRect.x = 0;
/* 1408 */       this.moveRect.y = 0;
/* 1409 */       this.moveRect.width = Window.this.getWidth();
/* 1410 */       this.moveRect.height = this.moveRect.size;
/*      */     }
/*      */     
/*      */     boolean shouldStartMove(int param1Int1, int param1Int2) {
/* 1414 */       return this.moveRect.contains(param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     boolean inMove() {
/* 1418 */       return this.inMove;
/*      */     }
/*      */     
/*      */     void startMove(int param1Int1, int param1Int2) {
/* 1422 */       this.inMove = true;
/*      */       
/* 1424 */       this.startMouseX = param1Int1;
/* 1425 */       this.startMouseY = param1Int2;
/*      */       
/* 1427 */       this.startX = Window.this.getX();
/* 1428 */       this.startY = Window.this.getY();
/*      */     }
/*      */     
/*      */     void deltaMove(int param1Int1, int param1Int2) {
/* 1432 */       int i = param1Int1 - this.startMouseX;
/* 1433 */       int j = param1Int2 - this.startMouseY;
/*      */       
/* 1435 */       Window.this.setPosition(this.startX + i, this.startY + j);
/*      */     }
/*      */     
/*      */     void stopMove() {
/* 1439 */       this.inMove = false;
/*      */     }
/*      */     
/*      */     void setResizeRectangle(int param1Int) {
/* 1443 */       this.resizeRect.size = param1Int;
/*      */ 
/*      */       
/* 1446 */       this.resizeRect.x = Window.this.getWidth() - this.resizeRect.size;
/* 1447 */       this.resizeRect.y = Window.this.getHeight() - this.resizeRect.size;
/* 1448 */       this.resizeRect.width = this.resizeRect.size;
/* 1449 */       this.resizeRect.height = this.resizeRect.size;
/*      */     }
/*      */     
/*      */     boolean shouldStartResize(int param1Int1, int param1Int2) {
/* 1453 */       return this.resizeRect.contains(param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     boolean inResize() {
/* 1457 */       return this.inResize;
/*      */     }
/*      */     
/*      */     void startResize(int param1Int1, int param1Int2) {
/* 1461 */       this.inResize = true;
/*      */       
/* 1463 */       this.startMouseX = param1Int1;
/* 1464 */       this.startMouseY = param1Int2;
/*      */       
/* 1466 */       this.startWidth = Window.this.getWidth();
/* 1467 */       this.startHeight = Window.this.getHeight();
/*      */     }
/*      */     
/*      */     void deltaResize(int param1Int1, int param1Int2) {
/* 1471 */       int i = param1Int1 - this.startMouseX;
/* 1472 */       int j = param1Int2 - this.startMouseY;
/*      */       
/* 1474 */       Window.this.setSize(this.startWidth + i, this.startHeight + j);
/*      */     }
/*      */     
/*      */     protected void stopResize() {
/* 1478 */       this.inResize = false;
/*      */     }
/*      */     
/*      */     void updateRectangles() {
/* 1482 */       if (this.moveRect.size > 0) {
/* 1483 */         setMoveRectangle(this.moveRect.size);
/*      */       }
/* 1485 */       if (this.resizeRect.size > 0)
/* 1486 */         setResizeRectangle(this.resizeRect.size); 
/*      */     }
/*      */     
/*      */     boolean handleMouseEvent(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
/*      */       boolean bool;
/* 1491 */       switch (param1Int1) {
/*      */         case 221:
/* 1493 */           if (param1Int2 == 212) {
/* 1494 */             if (Window.this.shouldStartUndecoratedMove(param1Int3, param1Int4) == true) {
/* 1495 */               startMove(param1Int5, param1Int6);
/* 1496 */               return true;
/* 1497 */             }  if (Window.this.shouldStartUndecoratedResize(param1Int3, param1Int4) == true) {
/* 1498 */               startResize(param1Int5, param1Int6);
/* 1499 */               return true;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 223:
/*      */         case 224:
/* 1506 */           if (inMove() == true) {
/* 1507 */             deltaMove(param1Int5, param1Int6);
/* 1508 */             return true;
/* 1509 */           }  if (inResize() == true) {
/* 1510 */             deltaResize(param1Int5, param1Int6);
/* 1511 */             return true;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 222:
/* 1516 */           bool = (inMove() || inResize()) ? true : false;
/* 1517 */           stopResize();
/* 1518 */           stopMove();
/* 1519 */           return bool;
/*      */       } 
/* 1521 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void requestInput(String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14) {
/* 1541 */     Application.checkEventThread();
/* 1542 */     _requestInput(this.ptr, paramString, paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, paramDouble8, paramDouble9, paramDouble10, paramDouble11, paramDouble12, paramDouble13, paramDouble14);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseInput() {
/* 1553 */     Application.checkEventThread();
/* 1554 */     _releaseInput(this.ptr);
/*      */   }
/*      */   
/*      */   protected abstract void _requestInput(long paramLong, String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14);
/*      */   
/*      */   protected abstract void _releaseInput(long paramLong);
/*      */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Window.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */