/*    */ package com.sun.glass.ui;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.util.Locale;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Platform
/*    */ {
/*    */   public static final String MAC = "Mac";
/*    */   public static final String WINDOWS = "Win";
/*    */   public static final String GTK = "Gtk";
/*    */   public static final String IOS = "Ios";
/*    */   public static final String UNKNOWN = "unknown";
/* 39 */   private static String type = null;
/*    */   
/*    */   public static synchronized String determinePlatform() {
/* 42 */     if (type == null) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 47 */       String str1 = AccessController.<String>doPrivileged(() -> System.getProperty("glass.platform"));
/*    */       
/* 49 */       if (str1 != null) {
/* 50 */         if (str1.equals("macosx")) {
/* 51 */           type = "Mac";
/* 52 */         } else if (str1.equals("windows")) {
/* 53 */           type = "Win";
/* 54 */         } else if (str1.equals("linux")) {
/* 55 */           type = "Gtk";
/* 56 */         } else if (str1.equals("gtk")) {
/* 57 */           type = "Gtk";
/* 58 */         } else if (str1.equals("ios")) {
/* 59 */           type = "Ios";
/*    */         } else {
/* 61 */           type = str1;
/* 62 */         }  return type;
/*    */       } 
/*    */       
/* 65 */       String str2 = System.getProperty("os.name");
/* 66 */       String str3 = str2.toLowerCase(Locale.ROOT);
/* 67 */       if (str3.startsWith("mac") || str3.startsWith("darwin")) {
/* 68 */         type = "Mac";
/* 69 */       } else if (str3.startsWith("wind")) {
/* 70 */         type = "Win";
/* 71 */       } else if (str3.startsWith("linux")) {
/* 72 */         type = "Gtk";
/* 73 */       } else if (str3.startsWith("ios")) {
/* 74 */         type = "Ios";
/*    */       } 
/*    */     } 
/*    */     
/* 78 */     return type;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Platform.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */