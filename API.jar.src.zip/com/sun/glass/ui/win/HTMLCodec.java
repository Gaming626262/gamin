/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HTMLCodec
/*     */   extends InputStream
/*     */ {
/*     */   public static final String ENCODING = "UTF-8";
/*     */   public static final String VERSION = "Version:";
/*     */   public static final String START_HTML = "StartHTML:";
/*     */   public static final String END_HTML = "EndHTML:";
/*     */   public static final String START_FRAGMENT = "StartFragment:";
/*     */   public static final String END_FRAGMENT = "EndFragment:";
/*     */   public static final String START_SELECTION = "StartSelection:";
/*     */   public static final String END_SELECTION = "EndSelection:";
/*     */   public static final String START_FRAGMENT_CMT = "<!--StartFragment-->";
/*     */   public static final String END_FRAGMENT_CMT = "<!--EndFragment-->";
/*     */   public static final String SOURCE_URL = "SourceURL:";
/*     */   public static final String DEF_SOURCE_URL = "about:blank";
/*     */   public static final String EOLN = "\r\n";
/*     */   private static final String VERSION_NUM = "1.0";
/*     */   private static final int PADDED_WIDTH = 10;
/*     */   private final BufferedInputStream bufferedStream;
/*     */   
/*     */   private static String toPaddedString(int paramInt1, int paramInt2) {
/* 114 */     String str = "" + paramInt1;
/* 115 */     int i = str.length();
/* 116 */     if (paramInt1 >= 0 && i < paramInt2) {
/* 117 */       char[] arrayOfChar = new char[paramInt2 - i];
/* 118 */       Arrays.fill(arrayOfChar, '0');
/* 119 */       StringBuffer stringBuffer = new StringBuffer(paramInt2);
/* 120 */       stringBuffer.append(arrayOfChar);
/* 121 */       stringBuffer.append(str);
/* 122 */       str = stringBuffer.toString();
/*     */     } 
/* 124 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] convertToHTMLFormat(byte[] paramArrayOfbyte) {
/* 156 */     String str1 = "";
/* 157 */     String str2 = "";
/*     */ 
/*     */ 
/*     */     
/* 161 */     String str3 = new String(paramArrayOfbyte);
/* 162 */     String str4 = str3.toUpperCase();
/* 163 */     if (-1 == str4.indexOf("<HTML")) {
/* 164 */       str1 = "<HTML>";
/* 165 */       str2 = "</HTML>";
/* 166 */       if (-1 == str4.indexOf("<BODY")) {
/* 167 */         str1 = str1 + "<BODY>";
/* 168 */         str2 = "</BODY>" + str2;
/*     */       } 
/*     */     } 
/* 171 */     str1 = str1 + "<!--StartFragment-->";
/* 172 */     str2 = "<!--EndFragment-->" + str2;
/*     */ 
/*     */     
/* 175 */     str3 = "about:blank";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 182 */     int i = "Version:".length() + "1.0".length() + "\r\n".length() + "StartHTML:".length() + 10 + "\r\n".length() + "EndHTML:".length() + 10 + "\r\n".length() + "StartFragment:".length() + 10 + "\r\n".length() + "EndFragment:".length() + 10 + "\r\n".length() + "SourceURL:".length() + str3.length() + "\r\n".length();
/*     */     
/* 184 */     int j = i + str1.length();
/* 185 */     int k = j + paramArrayOfbyte.length - 1;
/* 186 */     int m = k + str2.length();
/*     */ 
/*     */ 
/*     */     
/* 190 */     StringBuilder stringBuilder = new StringBuilder(j + "<!--StartFragment-->".length());
/*     */ 
/*     */     
/* 193 */     stringBuilder.append("Version:");
/* 194 */     stringBuilder.append("1.0");
/* 195 */     stringBuilder.append("\r\n");
/*     */     
/* 197 */     stringBuilder.append("StartHTML:");
/* 198 */     stringBuilder.append(toPaddedString(i, 10));
/* 199 */     stringBuilder.append("\r\n");
/*     */     
/* 201 */     stringBuilder.append("EndHTML:");
/* 202 */     stringBuilder.append(toPaddedString(m, 10));
/* 203 */     stringBuilder.append("\r\n");
/*     */     
/* 205 */     stringBuilder.append("StartFragment:");
/* 206 */     stringBuilder.append(toPaddedString(j, 10));
/* 207 */     stringBuilder.append("\r\n");
/*     */     
/* 209 */     stringBuilder.append("EndFragment:");
/* 210 */     stringBuilder.append(toPaddedString(k, 10));
/* 211 */     stringBuilder.append("\r\n");
/*     */     
/* 213 */     stringBuilder.append("SourceURL:");
/* 214 */     stringBuilder.append(str3);
/* 215 */     stringBuilder.append("\r\n");
/*     */ 
/*     */     
/* 218 */     stringBuilder.append(str1);
/*     */     
/* 220 */     byte[] arrayOfByte1 = null, arrayOfByte2 = null;
/*     */     
/*     */     try {
/* 223 */       arrayOfByte1 = stringBuilder.toString().getBytes("UTF-8");
/* 224 */       arrayOfByte2 = str2.getBytes("UTF-8");
/* 225 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 226 */       return null;
/*     */     } 
/*     */     
/* 229 */     byte[] arrayOfByte3 = new byte[arrayOfByte1.length + paramArrayOfbyte.length + arrayOfByte2.length];
/*     */ 
/*     */     
/* 232 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte3, 0, arrayOfByte1.length);
/* 233 */     System.arraycopy(paramArrayOfbyte, 0, arrayOfByte3, arrayOfByte1.length, paramArrayOfbyte.length - 1);
/*     */     
/* 235 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte3, arrayOfByte1.length + paramArrayOfbyte.length - 1, arrayOfByte2.length);
/*     */ 
/*     */     
/* 238 */     arrayOfByte3[arrayOfByte3.length - 1] = 0;
/*     */     
/* 240 */     return arrayOfByte3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean descriptionParsed = false;
/*     */   
/*     */   private boolean closed = false;
/*     */   
/*     */   public static final int BYTE_BUFFER_LEN = 8192;
/*     */   
/*     */   public static final int CHAR_BUFFER_LEN = 2730;
/*     */   
/*     */   private static final String FAILURE_MSG = "Unable to parse HTML description: ";
/*     */   
/*     */   private static final String INVALID_MSG = " invalid";
/*     */   
/*     */   private long iHTMLStart;
/*     */   
/*     */   private long iHTMLEnd;
/*     */   
/*     */   private long iFragStart;
/*     */   
/*     */   private long iFragEnd;
/*     */   
/*     */   private long iSelStart;
/*     */   
/*     */   private long iSelEnd;
/*     */   
/*     */   private String stBaseURL;
/*     */   
/*     */   private String stVersion;
/*     */   
/*     */   private long iStartOffset;
/*     */   
/*     */   private long iEndOffset;
/*     */   
/*     */   private long iReadCount;
/*     */   
/*     */   private EHTMLReadMode readMode;
/*     */ 
/*     */   
/*     */   public HTMLCodec(InputStream paramInputStream, EHTMLReadMode paramEHTMLReadMode) throws IOException {
/* 283 */     this.bufferedStream = new BufferedInputStream(paramInputStream, 8192);
/* 284 */     this.readMode = paramEHTMLReadMode;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String getBaseURL() throws IOException {
/* 289 */     if (!this.descriptionParsed) {
/* 290 */       parseDescription();
/*     */     }
/* 292 */     return this.stBaseURL;
/*     */   }
/*     */   
/*     */   public synchronized String getVersion() throws IOException {
/* 296 */     if (!this.descriptionParsed) {
/* 297 */       parseDescription();
/*     */     }
/* 299 */     return this.stVersion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDescription() throws IOException {
/* 308 */     this.stBaseURL = null;
/* 309 */     this.stVersion = null;
/*     */ 
/*     */ 
/*     */     
/* 313 */     this.iHTMLEnd = this.iHTMLStart = this.iFragEnd = this.iFragStart = this.iSelEnd = this.iSelStart = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 320 */     this.bufferedStream.mark(8192);
/* 321 */     String[] arrayOfString = { "Version:", "StartHTML:", "EndHTML:", "StartFragment:", "EndFragment:", "StartSelection:", "EndSelection:", "SourceURL:" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 333 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.bufferedStream, "UTF-8"), 2730);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     long l1 = 0L;
/* 341 */     long l2 = "\r\n".length();
/* 342 */     int i = arrayOfString.length;
/* 343 */     boolean bool = true;
/*     */     int j;
/* 345 */     for (j = 0; j < i; j++) {
/* 346 */       String str = bufferedReader.readLine();
/* 347 */       if (null == str) {
/*     */         break;
/*     */       }
/*     */       
/* 351 */       while (j < i) {
/* 352 */         if (!str.startsWith(arrayOfString[j])) {
/*     */           j++; continue;
/*     */         } 
/* 355 */         l1 += str.length() + l2;
/* 356 */         String str1 = str.substring(arrayOfString[j].length()).trim();
/* 357 */         if (null != str1) {
/*     */           try {
/* 359 */             switch (j) {
/*     */               case 0:
/* 361 */                 this.stVersion = str1;
/*     */                 break;
/*     */               case 1:
/* 364 */                 this.iHTMLStart = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 2:
/* 367 */                 this.iHTMLEnd = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 3:
/* 370 */                 this.iFragStart = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 4:
/* 373 */                 this.iFragEnd = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 5:
/* 376 */                 this.iSelStart = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 6:
/* 379 */                 this.iSelEnd = Integer.parseInt(str1);
/*     */                 break;
/*     */               case 7:
/* 382 */                 this.stBaseURL = str1;
/*     */                 break;
/*     */             } 
/* 385 */           } catch (NumberFormatException numberFormatException) {
/* 386 */             throw new IOException("Unable to parse HTML description: " + arrayOfString[j] + " value " + numberFormatException + " invalid");
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 394 */     if (-1L == this.iHTMLStart)
/* 395 */       this.iHTMLStart = l1; 
/* 396 */     if (-1L == this.iFragStart)
/* 397 */       this.iFragStart = this.iHTMLStart; 
/* 398 */     if (-1L == this.iFragEnd)
/* 399 */       this.iFragEnd = this.iHTMLEnd; 
/* 400 */     if (-1L == this.iSelStart)
/* 401 */       this.iSelStart = this.iFragStart; 
/* 402 */     if (-1L == this.iSelEnd) {
/* 403 */       this.iSelEnd = this.iFragEnd;
/*     */     }
/*     */     
/* 406 */     switch (this.readMode) {
/*     */       case HTML_READ_ALL:
/* 408 */         this.iStartOffset = this.iHTMLStart;
/* 409 */         this.iEndOffset = this.iHTMLEnd;
/*     */         break;
/*     */       case HTML_READ_FRAGMENT:
/* 412 */         this.iStartOffset = this.iFragStart;
/* 413 */         this.iEndOffset = this.iFragEnd;
/*     */         break;
/*     */       
/*     */       default:
/* 417 */         this.iStartOffset = this.iSelStart;
/* 418 */         this.iEndOffset = this.iSelEnd;
/*     */         break;
/*     */     } 
/*     */     
/* 422 */     this.bufferedStream.reset();
/* 423 */     if (-1L == this.iStartOffset) {
/* 424 */       throw new IOException("Unable to parse HTML description: invalid HTML format.");
/*     */     }
/*     */     
/* 427 */     j = 0;
/* 428 */     while (j < this.iStartOffset) {
/* 429 */       j = (int)(j + this.bufferedStream.skip(this.iStartOffset - j));
/*     */     }
/*     */     
/* 432 */     this.iReadCount = j;
/*     */     
/* 434 */     if (this.iStartOffset != this.iReadCount) {
/* 435 */       throw new IOException("Unable to parse HTML description: Byte stream ends in description.");
/*     */     }
/* 437 */     this.descriptionParsed = true;
/*     */   }
/*     */   
/*     */   public synchronized int read() throws IOException {
/* 441 */     if (this.closed) {
/* 442 */       throw new IOException("Stream closed");
/*     */     }
/*     */     
/* 445 */     if (!this.descriptionParsed) {
/* 446 */       parseDescription();
/*     */     }
/* 448 */     if (-1L != this.iEndOffset && this.iReadCount >= this.iEndOffset) {
/* 449 */       return -1;
/*     */     }
/*     */     
/* 452 */     int i = this.bufferedStream.read();
/* 453 */     if (i == -1) {
/* 454 */       return -1;
/*     */     }
/* 456 */     this.iReadCount++;
/* 457 */     return i;
/*     */   }
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 461 */     if (!this.closed) {
/* 462 */       this.closed = true;
/* 463 */       this.bufferedStream.close();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\HTMLCodec.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */