/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.GlassRobot;
/*     */ import javafx.scene.input.KeyCode;
/*     */ import javafx.scene.input.MouseButton;
/*     */ import javafx.scene.paint.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinRobot
/*     */   extends GlassRobot
/*     */ {
/*     */   public void create() {}
/*     */   
/*     */   public void destroy() {}
/*     */   
/*     */   protected native void _keyPress(int paramInt);
/*     */   
/*     */   public void keyPress(KeyCode paramKeyCode) {
/*  52 */     Application.checkEventThread();
/*  53 */     _keyPress(paramKeyCode.getCode());
/*     */   }
/*     */   
/*     */   protected native void _keyRelease(int paramInt);
/*     */   
/*     */   public void keyRelease(KeyCode paramKeyCode) {
/*  59 */     Application.checkEventThread();
/*  60 */     _keyRelease(paramKeyCode.getCode());
/*     */   }
/*     */ 
/*     */   
/*     */   protected native void _mouseMove(int paramInt1, int paramInt2);
/*     */   
/*     */   public void mouseMove(double paramDouble1, double paramDouble2) {
/*  67 */     Application.checkEventThread();
/*  68 */     _mouseMove((int)paramDouble1, (int)paramDouble2);
/*     */   }
/*     */   
/*     */   protected native void _mousePress(int paramInt);
/*     */   
/*     */   public void mousePress(MouseButton... paramVarArgs) {
/*  74 */     Application.checkEventThread();
/*  75 */     _mousePress(GlassRobot.convertToRobotMouseButton(paramVarArgs));
/*     */   }
/*     */   
/*     */   protected native void _mouseRelease(int paramInt);
/*     */   
/*     */   public void mouseRelease(MouseButton... paramVarArgs) {
/*  81 */     Application.checkEventThread();
/*  82 */     _mouseRelease(GlassRobot.convertToRobotMouseButton(paramVarArgs));
/*     */   }
/*     */   
/*     */   protected native void _mouseWheel(int paramInt);
/*     */   
/*     */   public void mouseWheel(int paramInt) {
/*  88 */     Application.checkEventThread();
/*  89 */     _mouseWheel(paramInt);
/*     */   }
/*     */   
/*     */   protected native float _getMouseX();
/*     */   
/*     */   public double getMouseX() {
/*  95 */     Application.checkEventThread();
/*  96 */     return _getMouseX();
/*     */   }
/*     */   
/*     */   protected native float _getMouseY();
/*     */   
/*     */   public double getMouseY() {
/* 102 */     Application.checkEventThread();
/* 103 */     return _getMouseY();
/*     */   }
/*     */   
/*     */   protected native int _getPixelColor(int paramInt1, int paramInt2);
/*     */   
/*     */   public Color getPixelColor(double paramDouble1, double paramDouble2) {
/* 109 */     Application.checkEventThread();
/* 110 */     return GlassRobot.convertFromIntArgb(_getPixelColor((int)paramDouble1, (int)paramDouble2));
/*     */   }
/*     */   
/*     */   protected native void _getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint);
/*     */   
/*     */   public void getScreenCapture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, boolean paramBoolean) {
/* 116 */     Application.checkEventThread();
/* 117 */     _getScreenCapture(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinRobot.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */