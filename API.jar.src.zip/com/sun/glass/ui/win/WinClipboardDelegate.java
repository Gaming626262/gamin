/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Clipboard;
/*    */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class WinClipboardDelegate
/*    */   implements ClipboardDelegate
/*    */ {
/*    */   public Clipboard createClipboard(String paramString) {
/* 32 */     if ("SYSTEM".equals(paramString))
/* 33 */       return (Clipboard)new WinSystemClipboard(paramString); 
/* 34 */     if ("DND".equals(paramString)) {
/* 35 */       return (Clipboard)new WinDnDClipboard(paramString);
/*    */     }
/* 37 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinClipboardDelegate.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */