/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import java.text.BreakIterator;
/*     */ import javafx.geometry.Bounds;
/*     */ import javafx.scene.AccessibleAction;
/*     */ import javafx.scene.AccessibleAttribute;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.FontWeight;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WinTextRangeProvider
/*     */ {
/*     */   private static final int TextPatternRangeEndpoint_Start = 0;
/*     */   private static final int TextPatternRangeEndpoint_End = 1;
/*     */   private static final int TextUnit_Character = 0;
/*     */   private static final int TextUnit_Format = 1;
/*     */   private static final int TextUnit_Word = 2;
/*     */   private static final int TextUnit_Line = 3;
/*     */   private static final int TextUnit_Paragraph = 4;
/*     */   private static final int TextUnit_Page = 5;
/*     */   private static final int TextUnit_Document = 6;
/*     */   private static final int UIA_FontNameAttributeId = 40005;
/*     */   private static final int UIA_FontSizeAttributeId = 40006;
/*     */   private static final int UIA_FontWeightAttributeId = 40007;
/*     */   private static final int UIA_IsHiddenAttributeId = 40013;
/*     */   private static final int UIA_IsItalicAttributeId = 40014;
/*     */   private static final int UIA_IsReadOnlyAttributeId = 40015;
/*     */   
/*     */   static {
/*  44 */     _initIDs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static int idCount = 1;
/*     */   
/*     */   private int id;
/*     */   
/*     */   private int start;
/*     */   
/*     */   private int end;
/*     */   
/*     */   private WinAccessible accessible;
/*     */   private long peer;
/*     */   
/*     */   WinTextRangeProvider(WinAccessible paramWinAccessible) {
/*  80 */     this.accessible = paramWinAccessible;
/*  81 */     this.peer = _createTextRangeProvider(paramWinAccessible.getNativeAccessible());
/*  82 */     this.id = idCount++;
/*     */   }
/*     */   
/*     */   long getNativeProvider() {
/*  86 */     return this.peer;
/*     */   }
/*     */   
/*     */   void dispose() {
/*  90 */     _destroyTextRangeProvider(this.peer);
/*  91 */     this.peer = 0L;
/*     */   }
/*     */   
/*     */   private void validateRange(String paramString) {
/*  95 */     if (paramString == null) {
/*  96 */       this.start = this.end = 0;
/*     */       
/*     */       return;
/*     */     } 
/* 100 */     int i = paramString.length();
/* 101 */     this.start = Math.max(0, Math.min(this.start, i));
/* 102 */     this.end = Math.max(this.start, Math.min(this.end, i));
/*     */   }
/*     */   
/*     */   void setRange(int paramInt1, int paramInt2) {
/* 106 */     this.start = paramInt1;
/* 107 */     this.end = paramInt2;
/*     */   }
/*     */   
/*     */   int getStart() {
/* 111 */     return this.start;
/*     */   }
/*     */   
/*     */   int getEnd() {
/* 115 */     return this.end;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 119 */     return "Range(start: " + this.start + ", end: " + this.end + ", id: " + this.id + ")";
/*     */   }
/*     */   
/*     */   private Object getAttribute(AccessibleAttribute paramAccessibleAttribute, Object... paramVarArgs) {
/* 123 */     return this.accessible.getAttribute(paramAccessibleAttribute, paramVarArgs);
/*     */   }
/*     */   
/*     */   private boolean isWordStart(BreakIterator paramBreakIterator, String paramString, int paramInt) {
/* 127 */     if (paramInt == 0) return true; 
/* 128 */     if (paramInt >= paramString.length()) return true; 
/* 129 */     if (paramInt == -1) return true; 
/* 130 */     return (paramBreakIterator.isBoundary(paramInt) && Character.isLetterOrDigit(paramString.charAt(paramInt)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long Clone() {
/* 137 */     WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this.accessible);
/* 138 */     winTextRangeProvider.setRange(this.start, this.end);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     return winTextRangeProvider.getNativeProvider();
/*     */   }
/*     */   
/*     */   private boolean Compare(WinTextRangeProvider paramWinTextRangeProvider) {
/* 148 */     if (paramWinTextRangeProvider == null) return false; 
/* 149 */     return (this.accessible == paramWinTextRangeProvider.accessible && this.start == paramWinTextRangeProvider.start && this.end == paramWinTextRangeProvider.end);
/*     */   }
/*     */   
/*     */   private int CompareEndpoints(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2) {
/* 153 */     int i = (paramInt1 == 0) ? this.start : this.end;
/* 154 */     int j = (paramInt2 == 0) ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
/* 155 */     return i - j; } private void ExpandToEnclosingUnit(int paramInt) { BreakIterator breakIterator1; Integer integer1, integer2;
/*     */     BreakIterator breakIterator2;
/*     */     Integer integer3;
/*     */     int j;
/* 159 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 160 */     if (str == null)
/* 161 */       return;  int i = str.length();
/* 162 */     if (i == 0)
/* 163 */       return;  validateRange(str);
/*     */     
/* 165 */     switch (paramInt) {
/*     */       case 0:
/* 167 */         if (this.start == i) this.start--; 
/* 168 */         this.end = this.start + 1;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 173 */         breakIterator1 = BreakIterator.getWordInstance();
/* 174 */         breakIterator1.setText(str);
/* 175 */         if (!isWordStart(breakIterator1, str, this.start)) {
/* 176 */           int k = breakIterator1.preceding(this.start);
/* 177 */           while (!isWordStart(breakIterator1, str, k)) {
/* 178 */             k = breakIterator1.previous();
/*     */           }
/* 180 */           this.start = (k != -1) ? k : 0;
/*     */         } 
/* 182 */         if (!isWordStart(breakIterator1, str, this.end)) {
/* 183 */           int k = breakIterator1.following(this.end);
/* 184 */           while (!isWordStart(breakIterator1, str, k)) {
/* 185 */             k = breakIterator1.next();
/*     */           }
/* 187 */           this.end = (k != -1) ? k : i;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 192 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 193 */         integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 194 */         integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 195 */         if (integer1 == null || integer3 == null || integer2 == null) {
/*     */           
/* 197 */           this.start = 0;
/* 198 */           this.end = i;
/*     */           break;
/*     */         } 
/* 201 */         this.start = integer2.intValue();
/* 202 */         this.end = integer3.intValue();
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 208 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 209 */         if (integer1 == null) {
/*     */           
/* 211 */           this.start = 0;
/* 212 */           this.end = i;
/*     */           break;
/*     */         } 
/* 215 */         breakIterator2 = BreakIterator.getSentenceInstance();
/* 216 */         breakIterator2.setText(str);
/* 217 */         if (!breakIterator2.isBoundary(this.start)) {
/* 218 */           int k = breakIterator2.preceding(this.start);
/* 219 */           this.start = (k != -1) ? k : 0;
/*     */         } 
/* 221 */         j = breakIterator2.following(this.start);
/* 222 */         this.end = (j != -1) ? j : i;
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 228 */         this.start = 0;
/* 229 */         this.end = i;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 235 */     validateRange(str); }
/*     */ 
/*     */   
/*     */   private long FindAttribute(int paramInt, WinVariant paramWinVariant, boolean paramBoolean) {
/* 239 */     System.err.println("FindAttribute NOT IMPLEMENTED");
/* 240 */     return 0L;
/*     */   }
/*     */   
/*     */   private long FindText(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/* 244 */     if (paramString == null) return 0L; 
/* 245 */     String str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 246 */     if (str1 == null) return 0L; 
/* 247 */     String str2 = str1.substring(this.start, this.end);
/* 248 */     if (paramBoolean2) {
/* 249 */       str2 = str2.toLowerCase();
/* 250 */       paramString = paramString.toLowerCase();
/*     */     } 
/* 252 */     int i = -1;
/* 253 */     if (paramBoolean1) {
/* 254 */       i = str2.lastIndexOf(paramString);
/*     */     } else {
/* 256 */       i = str2.indexOf(paramString);
/*     */     } 
/* 258 */     if (i == -1) return 0L; 
/* 259 */     WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this.accessible);
/* 260 */     winTextRangeProvider.setRange(this.start + i, this.start + i + paramString.length());
/* 261 */     return winTextRangeProvider.getNativeProvider();
/*     */   }
/*     */   private WinVariant GetAttributeValue(int paramInt) {
/*     */     Font font;
/* 265 */     WinVariant winVariant = null;
/* 266 */     switch (paramInt) {
/*     */       case 40005:
/* 268 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 269 */         if (font != null) {
/* 270 */           winVariant = new WinVariant();
/* 271 */           winVariant.vt = 8;
/* 272 */           winVariant.bstrVal = font.getName();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40006:
/* 277 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 278 */         if (font != null) {
/* 279 */           winVariant = new WinVariant();
/* 280 */           winVariant.vt = 5;
/* 281 */           winVariant.dblVal = font.getSize();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40007:
/* 286 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 287 */         if (font != null) {
/* 288 */           boolean bool = font.getStyle().toLowerCase().contains("bold");
/* 289 */           winVariant = new WinVariant();
/* 290 */           winVariant.vt = 3;
/* 291 */           winVariant.lVal = bool ? FontWeight.BOLD.getWeight() : FontWeight.NORMAL.getWeight();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 40013:
/*     */       case 40015:
/* 297 */         winVariant = new WinVariant();
/* 298 */         winVariant.vt = 11;
/* 299 */         winVariant.boolVal = false;
/*     */         break;
/*     */       case 40014:
/* 302 */         font = (Font)getAttribute(AccessibleAttribute.FONT, new Object[0]);
/* 303 */         if (font != null) {
/* 304 */           boolean bool = font.getStyle().toLowerCase().contains("italic");
/* 305 */           winVariant = new WinVariant();
/* 306 */           winVariant.vt = 11;
/* 307 */           winVariant.boolVal = bool;
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 314 */     return winVariant;
/*     */   }
/*     */   
/*     */   private double[] GetBoundingRectangles() {
/* 318 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 319 */     if (str == null) return null; 
/* 320 */     int i = str.length();
/* 321 */     validateRange(str);
/*     */ 
/*     */     
/* 324 */     if (i == 0) return new double[0]; 
/* 325 */     int j = this.end;
/* 326 */     if (j > 0 && j > this.start && str.charAt(j - 1) == '\n') {
/* 327 */       j--;
/*     */     }
/* 329 */     if (j > 0 && j > this.start && str.charAt(j - 1) == '\r') {
/* 330 */       j--;
/*     */     }
/* 332 */     if (j > 0 && j > this.start && j == i) {
/* 333 */       j--;
/*     */     }
/* 335 */     Bounds[] arrayOfBounds = (Bounds[])getAttribute(AccessibleAttribute.BOUNDS_FOR_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(j) });
/* 336 */     if (arrayOfBounds != null) {
/* 337 */       double[] arrayOfDouble = new double[arrayOfBounds.length * 4];
/* 338 */       byte b1 = 0;
/* 339 */       for (byte b2 = 0; b2 < arrayOfBounds.length; b2++) {
/* 340 */         Bounds bounds = arrayOfBounds[b2];
/* 341 */         float[] arrayOfFloat = this.accessible.getPlatformBounds(
/* 342 */             (float)bounds.getMinX(), 
/* 343 */             (float)bounds.getMinY(), 
/* 344 */             (float)bounds.getWidth(), 
/* 345 */             (float)bounds.getHeight());
/*     */         
/* 347 */         arrayOfDouble[b1++] = arrayOfFloat[0];
/* 348 */         arrayOfDouble[b1++] = arrayOfFloat[1];
/* 349 */         arrayOfDouble[b1++] = arrayOfFloat[2];
/* 350 */         arrayOfDouble[b1++] = arrayOfFloat[3];
/*     */       } 
/* 352 */       return arrayOfDouble;
/*     */     } 
/* 354 */     return null;
/*     */   }
/*     */   
/*     */   private long GetEnclosingElement() {
/* 358 */     return this.accessible.getNativeAccessible();
/*     */   }
/*     */   
/*     */   private String GetText(int paramInt) {
/* 362 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 363 */     if (str == null) return null; 
/* 364 */     validateRange(str);
/* 365 */     int i = (paramInt != -1) ? Math.min(this.end, this.start + paramInt) : this.end;
/*     */     
/* 367 */     return str.substring(this.start, i); } private int Move(int paramInt1, int paramInt2) { int k; BreakIterator breakIterator2;
/*     */     Integer integer;
/*     */     BreakIterator breakIterator1;
/*     */     int m;
/* 371 */     if (paramInt2 == 0) return 0; 
/* 372 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 373 */     if (str == null) return 0; 
/* 374 */     int i = str.length();
/* 375 */     if (i == 0) return 0;
/*     */     
/* 377 */     int j = 0;
/* 378 */     switch (paramInt1) {
/*     */       case 0:
/* 380 */         k = this.start;
/* 381 */         this.start = Math.max(0, Math.min(this.start + paramInt2, i - 1));
/* 382 */         this.end = this.start + 1;
/* 383 */         j = this.start - k;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 388 */         breakIterator2 = BreakIterator.getWordInstance();
/* 389 */         breakIterator2.setText(str);
/* 390 */         m = this.start;
/* 391 */         while (!isWordStart(breakIterator2, str, m)) {
/* 392 */           m = breakIterator2.preceding(this.start);
/*     */         }
/* 394 */         while (m != -1 && j != paramInt2) {
/* 395 */           if (paramInt2 > 0) {
/* 396 */             m = breakIterator2.following(m);
/* 397 */             while (!isWordStart(breakIterator2, str, m)) {
/* 398 */               m = breakIterator2.next();
/*     */             }
/* 400 */             j++; continue;
/*     */           } 
/* 402 */           m = breakIterator2.preceding(m);
/* 403 */           while (!isWordStart(breakIterator2, str, m)) {
/* 404 */             m = breakIterator2.previous();
/*     */           }
/* 406 */           j--;
/*     */         } 
/*     */         
/* 409 */         if (j != 0) {
/* 410 */           if (m != -1) {
/* 411 */             this.start = m;
/*     */           } else {
/* 413 */             this.start = (paramInt2 > 0) ? i : 0;
/*     */           } 
/* 415 */           m = breakIterator2.following(this.start);
/* 416 */           while (!isWordStart(breakIterator2, str, m)) {
/* 417 */             m = breakIterator2.next();
/*     */           }
/* 419 */           this.end = (m != -1) ? m : i;
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 3:
/* 424 */         integer = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(this.start) });
/* 425 */         if (integer == null) return 0; 
/* 426 */         m = (paramInt2 > 0) ? 1 : -1;
/* 427 */         while (paramInt2 != j && 
/* 428 */           getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(integer.intValue() + m) }) != null) {
/* 429 */           integer = Integer.valueOf(integer.intValue() + m);
/* 430 */           j += m;
/*     */         } 
/* 432 */         if (j != 0) {
/* 433 */           Integer integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer });
/* 434 */           Integer integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer });
/* 435 */           if (integer1 == null || integer2 == null) return 0; 
/* 436 */           this.start = integer1.intValue();
/* 437 */           this.end = integer2.intValue();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 4:
/* 442 */         breakIterator1 = BreakIterator.getSentenceInstance();
/* 443 */         breakIterator1.setText(str);
/* 444 */         m = breakIterator1.isBoundary(this.start) ? this.start : breakIterator1.preceding(this.start);
/* 445 */         while (m != -1 && j != paramInt2) {
/* 446 */           if (paramInt2 > 0) {
/* 447 */             m = breakIterator1.following(m);
/* 448 */             j++; continue;
/*     */           } 
/* 450 */           m = breakIterator1.preceding(m);
/* 451 */           j--;
/*     */         } 
/*     */         
/* 454 */         if (j != 0) {
/* 455 */           this.start = (m != -1) ? m : 0;
/* 456 */           m = breakIterator1.following(this.start);
/* 457 */           this.end = (m != -1) ? m : i;
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 464 */         return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 469 */     validateRange(str);
/* 470 */     return j; } private int MoveEndpointByUnit(int paramInt1, int paramInt2, int paramInt3) { int m; BreakIterator breakIterator2; Integer integer1; BreakIterator breakIterator1;
/*     */     Integer integer2, integer3;
/*     */     byte b;
/*     */     int n;
/* 474 */     if (paramInt3 == 0) return 0; 
/* 475 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 476 */     if (str == null) return 0; 
/* 477 */     int i = str.length();
/* 478 */     validateRange(str);
/*     */     
/* 480 */     int j = 0;
/* 481 */     int k = (paramInt1 == 0) ? this.start : this.end;
/* 482 */     switch (paramInt2) {
/*     */       case 0:
/* 484 */         m = k;
/* 485 */         k = Math.max(0, Math.min(k + paramInt3, i));
/* 486 */         j = k - m;
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 491 */         breakIterator2 = BreakIterator.getWordInstance();
/* 492 */         breakIterator2.setText(str);
/* 493 */         while (k != -1 && j != paramInt3) {
/* 494 */           if (paramInt3 > 0) {
/* 495 */             k = breakIterator2.following(k);
/* 496 */             while (!isWordStart(breakIterator2, str, k)) {
/* 497 */               k = breakIterator2.next();
/*     */             }
/* 499 */             j++; continue;
/*     */           } 
/* 501 */           k = breakIterator2.preceding(k);
/* 502 */           while (!isWordStart(breakIterator2, str, k)) {
/* 503 */             k = breakIterator2.previous();
/*     */           }
/* 505 */           j--;
/*     */         } 
/*     */         
/* 508 */         if (k == -1) {
/* 509 */           k = (paramInt3 > 0) ? i : 0;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 3:
/* 514 */         integer1 = (Integer)getAttribute(AccessibleAttribute.LINE_FOR_OFFSET, new Object[] { Integer.valueOf(k) });
/* 515 */         integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 516 */         integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 517 */         if (integer1 == null || integer2 == null || integer3 == null) {
/*     */           
/* 519 */           k = (paramInt3 > 0) ? i : 0;
/*     */           break;
/*     */         } 
/* 522 */         b = (paramInt3 > 0) ? 1 : -1;
/* 523 */         n = ((paramInt3 > 0) ? integer3 : integer2).intValue();
/* 524 */         if (k != n)
/*     */         {
/* 526 */           j += b;
/*     */         }
/* 528 */         while (paramInt3 != j && 
/* 529 */           getAttribute(AccessibleAttribute.LINE_START, new Object[] { Integer.valueOf(integer1.intValue() + b) }) != null) {
/* 530 */           integer1 = Integer.valueOf(integer1.intValue() + b);
/* 531 */           j += b;
/*     */         } 
/* 533 */         if (j != 0) {
/* 534 */           integer2 = (Integer)getAttribute(AccessibleAttribute.LINE_START, new Object[] { integer1 });
/* 535 */           integer3 = (Integer)getAttribute(AccessibleAttribute.LINE_END, new Object[] { integer1 });
/* 536 */           if (integer2 == null || integer3 == null) return 0; 
/* 537 */           k = ((paramInt3 > 0) ? integer3 : integer2).intValue();
/*     */         } 
/*     */         break;
/*     */       
/*     */       case 4:
/* 542 */         breakIterator1 = BreakIterator.getSentenceInstance();
/* 543 */         breakIterator1.setText(str);
/* 544 */         while (k != -1 && j != paramInt3) {
/* 545 */           if (paramInt3 > 0) {
/* 546 */             k = breakIterator1.following(k);
/* 547 */             j++; continue;
/*     */           } 
/* 549 */           k = breakIterator1.preceding(k);
/* 550 */           j--;
/*     */         } 
/*     */         
/* 553 */         if (k == -1) {
/* 554 */           k = (paramInt3 > 0) ? i : 0;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/*     */       case 6:
/* 561 */         return 0;
/*     */     } 
/*     */     
/* 564 */     if (paramInt1 == 0) {
/* 565 */       this.start = k;
/*     */     } else {
/* 567 */       this.end = k;
/*     */     } 
/* 569 */     if (this.start > this.end) {
/* 570 */       this.start = this.end = k;
/*     */     }
/*     */ 
/*     */     
/* 574 */     validateRange(str);
/* 575 */     return j; }
/*     */ 
/*     */   
/*     */   private void MoveEndpointByRange(int paramInt1, WinTextRangeProvider paramWinTextRangeProvider, int paramInt2) {
/* 579 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 580 */     if (str == null)
/* 581 */       return;  int i = str.length();
/*     */     
/* 583 */     int j = (paramInt2 == 0) ? paramWinTextRangeProvider.start : paramWinTextRangeProvider.end;
/* 584 */     if (paramInt1 == 0) {
/* 585 */       this.start = j;
/*     */     } else {
/* 587 */       this.end = j;
/*     */     } 
/* 589 */     if (this.start > this.end) {
/* 590 */       this.start = this.end = j;
/*     */     }
/*     */ 
/*     */     
/* 594 */     validateRange(str);
/*     */   }
/*     */   
/*     */   private void Select() {
/* 598 */     this.accessible.executeAction(AccessibleAction.SET_TEXT_SELECTION, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void AddToSelection() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void RemoveFromSelection() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void ScrollIntoView(boolean paramBoolean) {
/* 612 */     this.accessible.executeAction(AccessibleAction.SHOW_TEXT_RANGE, new Object[] { Integer.valueOf(this.start), Integer.valueOf(this.end) });
/*     */   }
/*     */ 
/*     */   
/*     */   private long[] GetChildren() {
/* 617 */     return new long[0];
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native long _createTextRangeProvider(long paramLong);
/*     */   
/*     */   private native void _destroyTextRangeProvider(long paramLong);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinTextRangeProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */