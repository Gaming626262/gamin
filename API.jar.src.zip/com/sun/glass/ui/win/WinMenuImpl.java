/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.MenuItem;
/*     */ import com.sun.glass.ui.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WinMenuImpl
/*     */ {
/*     */   static {
/*  44 */     _initIDs();
/*     */   }
/*     */   
/*  47 */   private long ptr = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getHMENU() {
/*  53 */     return this.ptr;
/*     */   }
/*     */   
/*     */   boolean create() {
/*  57 */     this.ptr = _create();
/*  58 */     return (this.ptr != 0L);
/*     */   }
/*     */   
/*     */   void destroy() {
/*  62 */     if (this.ptr != 0L) {
/*  63 */       _destroy(this.ptr);
/*  64 */       this.ptr = 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean insertSubmenu(WinMenuDelegate paramWinMenuDelegate, int paramInt) {
/*  69 */     paramWinMenuDelegate.setParent(this);
/*  70 */     if (!_insertSubmenu(this.ptr, paramInt, paramWinMenuDelegate.getHMENU(), paramWinMenuDelegate
/*  71 */         .getOwner().getTitle(), paramWinMenuDelegate.getOwner().isEnabled())) {
/*  72 */       paramWinMenuDelegate.setParent((WinMenuImpl)null);
/*  73 */       return false;
/*     */     } 
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean insertItem(WinMenuItemDelegate paramWinMenuItemDelegate, int paramInt) {
/*  80 */     if (paramWinMenuItemDelegate == null) {
/*  81 */       return _insertSeparator(this.ptr, paramInt);
/*     */     }
/*     */     
/*  84 */     paramWinMenuItemDelegate.setParent(this);
/*     */     
/*  86 */     if (!_insertItem(this.ptr, paramInt, paramWinMenuItemDelegate.getCmdID(), paramWinMenuItemDelegate
/*  87 */         .getOwner().getTitle(), paramWinMenuItemDelegate
/*  88 */         .getOwner().isEnabled(), paramWinMenuItemDelegate
/*  89 */         .getOwner().isChecked(), paramWinMenuItemDelegate
/*  90 */         .getOwner().getCallback(), paramWinMenuItemDelegate
/*  91 */         .getOwner().getShortcutKey(), paramWinMenuItemDelegate
/*  92 */         .getOwner().getShortcutModifiers())) {
/*  93 */       paramWinMenuItemDelegate.setParent(null);
/*  94 */       return false;
/*     */     } 
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   boolean removeMenu(WinMenuDelegate paramWinMenuDelegate, int paramInt) {
/* 100 */     if (_removeAtPos(this.ptr, paramInt)) {
/* 101 */       paramWinMenuDelegate.setParent((WinMenuImpl)null);
/* 102 */       return true;
/*     */     } 
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   boolean removeItem(WinMenuItemDelegate paramWinMenuItemDelegate, int paramInt) {
/* 108 */     if (_removeAtPos(this.ptr, paramInt)) {
/* 109 */       if (paramWinMenuItemDelegate != null) {
/* 110 */         paramWinMenuItemDelegate.setParent(null);
/*     */       }
/* 112 */       return true;
/*     */     } 
/* 114 */     return false;
/*     */   }
/*     */   
/*     */   boolean setSubmenuTitle(WinMenuDelegate paramWinMenuDelegate, String paramString) {
/* 118 */     return _setSubmenuTitle(this.ptr, paramWinMenuDelegate.getHMENU(), paramString);
/*     */   }
/*     */   
/*     */   boolean setItemTitle(WinMenuItemDelegate paramWinMenuItemDelegate, String paramString) {
/* 122 */     return _setItemTitle(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramString);
/*     */   }
/*     */   
/*     */   boolean enableSubmenu(WinMenuDelegate paramWinMenuDelegate, boolean paramBoolean) {
/* 126 */     return _enableSubmenu(this.ptr, paramWinMenuDelegate.getHMENU(), paramBoolean);
/*     */   }
/*     */   
/*     */   boolean enableItem(WinMenuItemDelegate paramWinMenuItemDelegate, boolean paramBoolean) {
/* 130 */     return _enableItem(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean checkItem(WinMenuItemDelegate paramWinMenuItemDelegate, boolean paramBoolean) {
/* 134 */     return _checkItem(this.ptr, paramWinMenuItemDelegate.getCmdID(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean notifyCommand(Window paramWindow, int paramInt) {
/* 139 */     WinMenuItemDelegate winMenuItemDelegate = WinMenuItemDelegate.CommandIDManager.getHandler(paramInt);
/* 140 */     if (winMenuItemDelegate != null) {
/* 141 */       MenuItem.Callback callback = winMenuItemDelegate.getOwner().getCallback();
/* 142 */       if (callback != null) {
/* 143 */         callback.action();
/* 144 */         return true;
/*     */       } 
/*     */     } 
/* 147 */     return false;
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   private native long _create();
/*     */   
/*     */   private native void _destroy(long paramLong);
/*     */   
/*     */   private native boolean _insertItem(long paramLong, int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, boolean paramBoolean2, MenuItem.Callback paramCallback, int paramInt3, int paramInt4);
/*     */   
/*     */   private native boolean _insertSubmenu(long paramLong1, int paramInt, long paramLong2, String paramString, boolean paramBoolean);
/*     */   
/*     */   private native boolean _insertSeparator(long paramLong, int paramInt);
/*     */   
/*     */   private native boolean _removeAtPos(long paramLong, int paramInt);
/*     */   
/*     */   private native boolean _setItemTitle(long paramLong, int paramInt, String paramString);
/*     */   
/*     */   private native boolean _setSubmenuTitle(long paramLong1, long paramLong2, String paramString);
/*     */   
/*     */   private native boolean _enableItem(long paramLong, int paramInt, boolean paramBoolean);
/*     */   
/*     */   private native boolean _enableSubmenu(long paramLong1, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   private native boolean _checkItem(long paramLong, int paramInt, boolean paramBoolean);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinMenuImpl.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */