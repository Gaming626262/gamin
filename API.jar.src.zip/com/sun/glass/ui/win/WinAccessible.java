/*      */ package com.sun.glass.ui.win;
/*      */ 
/*      */ import com.sun.glass.ui.Accessible;
/*      */ import com.sun.glass.ui.Screen;
/*      */ import com.sun.glass.ui.View;
/*      */ import com.sun.javafx.stage.WindowHelper;
/*      */ import com.sun.javafx.tk.TKStage;
/*      */ import com.sun.javafx.tk.quantum.WindowStage;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.function.Function;
/*      */ import java.util.stream.Collectors;
/*      */ import javafx.collections.FXCollections;
/*      */ import javafx.collections.ObservableList;
/*      */ import javafx.geometry.Bounds;
/*      */ import javafx.geometry.Point2D;
/*      */ import javafx.scene.AccessibleAction;
/*      */ import javafx.scene.AccessibleAttribute;
/*      */ import javafx.scene.AccessibleRole;
/*      */ import javafx.scene.Node;
/*      */ import javafx.scene.Scene;
/*      */ import javafx.scene.input.KeyCombination;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class WinAccessible
/*      */   extends Accessible
/*      */ {
/*      */   static {
/*   72 */     _initIDs();
/*      */   }
/*      */   
/*   75 */   private static int idCount = 1;
/*      */   
/*      */   private static final int UIA_BoundingRectanglePropertyId = 30001;
/*      */   
/*      */   private static final int UIA_ProcessIdPropertyId = 30002;
/*      */   
/*      */   private static final int UIA_ControlTypePropertyId = 30003;
/*      */   
/*      */   private static final int UIA_LocalizedControlTypePropertyId = 30004;
/*      */   
/*      */   private static final int UIA_NamePropertyId = 30005;
/*      */   
/*      */   private static final int UIA_AcceleratorKeyPropertyId = 30006;
/*      */   
/*      */   private static final int UIA_AccessKeyPropertyId = 30007;
/*      */   
/*      */   private static final int UIA_HasKeyboardFocusPropertyId = 30008;
/*      */   
/*      */   private static final int UIA_IsKeyboardFocusablePropertyId = 30009;
/*      */   
/*      */   private static final int UIA_IsEnabledPropertyId = 30010;
/*      */   
/*      */   private static final int UIA_AutomationIdPropertyId = 30011;
/*      */   
/*      */   private static final int UIA_ClassNamePropertyId = 30012;
/*      */   
/*      */   private static final int UIA_HelpTextPropertyId = 30013;
/*      */   
/*      */   private static final int UIA_ClickablePointPropertyId = 30014;
/*      */   
/*      */   private static final int UIA_CulturePropertyId = 30015;
/*      */   
/*      */   private static final int UIA_IsControlElementPropertyId = 30016;
/*      */   
/*      */   private static final int UIA_IsContentElementPropertyId = 30017;
/*      */   
/*      */   private static final int UIA_LabeledByPropertyId = 30018;
/*      */   
/*      */   private static final int UIA_IsPasswordPropertyId = 30019;
/*      */   
/*      */   private static final int UIA_NativeWindowHandlePropertyId = 30020;
/*      */   
/*      */   private static final int UIA_ItemTypePropertyId = 30021;
/*      */   
/*      */   private static final int UIA_IsOffscreenPropertyId = 30022;
/*      */   
/*      */   private static final int UIA_OrientationPropertyId = 30023;
/*      */   
/*      */   private static final int UIA_FrameworkIdPropertyId = 30024;
/*      */   
/*      */   private static final int UIA_ValueValuePropertyId = 30045;
/*      */   
/*      */   private static final int UIA_RangeValueValuePropertyId = 30047;
/*      */   
/*      */   private static final int UIA_ExpandCollapseExpandCollapseStatePropertyId = 30070;
/*      */   
/*      */   private static final int UIA_ToggleToggleStatePropertyId = 30086;
/*      */   
/*      */   private static final int UIA_AriaRolePropertyId = 30101;
/*      */   
/*      */   private static final int UIA_ProviderDescriptionPropertyId = 30107;
/*      */   
/*      */   private static final int UIA_IsDialogPropertyId = 30174;
/*      */   
/*      */   private static final int UIA_InvokePatternId = 10000;
/*      */   
/*      */   private static final int UIA_SelectionPatternId = 10001;
/*      */   
/*      */   private static final int UIA_ValuePatternId = 10002;
/*      */   private static final int UIA_RangeValuePatternId = 10003;
/*      */   private static final int UIA_ScrollPatternId = 10004;
/*      */   private static final int UIA_ExpandCollapsePatternId = 10005;
/*      */   private static final int UIA_GridPatternId = 10006;
/*      */   private static final int UIA_GridItemPatternId = 10007;
/*      */   private static final int UIA_SelectionItemPatternId = 10010;
/*      */   private static final int UIA_TablePatternId = 10012;
/*      */   private static final int UIA_TableItemPatternId = 10013;
/*      */   private static final int UIA_TextPatternId = 10014;
/*      */   private static final int UIA_TogglePatternId = 10015;
/*      */   private static final int UIA_TransformPatternId = 10016;
/*      */   private static final int UIA_ScrollItemPatternId = 10017;
/*      */   private static final int UIA_ItemContainerPatternId = 10019;
/*      */   private static final int UIA_ButtonControlTypeId = 50000;
/*      */   private static final int UIA_CheckBoxControlTypeId = 50002;
/*      */   private static final int UIA_ComboBoxControlTypeId = 50003;
/*      */   private static final int UIA_EditControlTypeId = 50004;
/*      */   private static final int UIA_HyperlinkControlTypeId = 50005;
/*      */   private static final int UIA_ImageControlTypeId = 50006;
/*      */   private static final int UIA_ListItemControlTypeId = 50007;
/*      */   private static final int UIA_ListControlTypeId = 50008;
/*      */   private static final int UIA_MenuControlTypeId = 50009;
/*      */   private static final int UIA_MenuBarControlTypeId = 50010;
/*      */   private static final int UIA_MenuItemControlTypeId = 50011;
/*      */   private static final int UIA_ProgressBarControlTypeId = 50012;
/*      */   private static final int UIA_RadioButtonControlTypeId = 50013;
/*      */   private static final int UIA_ScrollBarControlTypeId = 50014;
/*      */   private static final int UIA_SliderControlTypeId = 50015;
/*      */   private static final int UIA_SpinnerControlTypeId = 50016;
/*      */   private static final int UIA_TabControlTypeId = 50018;
/*      */   private static final int UIA_TabItemControlTypeId = 50019;
/*      */   private static final int UIA_TextControlTypeId = 50020;
/*      */   private static final int UIA_ToolBarControlTypeId = 50021;
/*      */   private static final int UIA_TreeControlTypeId = 50023;
/*      */   private static final int UIA_TreeItemControlTypeId = 50024;
/*      */   private static final int UIA_GroupControlTypeId = 50026;
/*      */   private static final int UIA_ThumbControlTypeId = 50027;
/*      */   private static final int UIA_DataGridControlTypeId = 50028;
/*      */   private static final int UIA_DataItemControlTypeId = 50029;
/*      */   private static final int UIA_SplitButtonControlTypeId = 50031;
/*      */   private static final int UIA_WindowControlTypeId = 50032;
/*      */   private static final int UIA_PaneControlTypeId = 50033;
/*      */   private static final int UIA_TableControlTypeId = 50036;
/*      */   private static final int NavigateDirection_Parent = 0;
/*      */   private static final int NavigateDirection_NextSibling = 1;
/*      */   private static final int NavigateDirection_PreviousSibling = 2;
/*      */   private static final int NavigateDirection_FirstChild = 3;
/*      */   private static final int NavigateDirection_LastChild = 4;
/*      */   private static final int RowOrColumnMajor_RowMajor = 0;
/*      */   private static final int RowOrColumnMajor_ColumnMajor = 1;
/*      */   private static final int RowOrColumnMajor_Indeterminate = 2;
/*      */   private static final int UIA_MenuOpenedEventId = 20003;
/*      */   private static final int UIA_AutomationPropertyChangedEventId = 20004;
/*      */   private static final int UIA_AutomationFocusChangedEventId = 20005;
/*      */   private static final int UIA_MenuClosedEventId = 20007;
/*      */   private static final int UIA_SelectionItem_ElementRemovedFromSelectionEventId = 20011;
/*      */   private static final int UIA_SelectionItem_ElementSelectedEventId = 20012;
/*      */   private static final int UIA_Text_TextSelectionChangedEventId = 20014;
/*      */   private static final int UIA_Text_TextChangedEventId = 20015;
/*      */   private static final int UIA_MenuModeStartEventId = 20018;
/*      */   private static final int UIA_MenuModeEndEventId = 20019;
/*      */   private static final int SupportedTextSelection_None = 0;
/*      */   private static final int SupportedTextSelection_Single = 1;
/*      */   private static final int SupportedTextSelection_Multiple = 2;
/*      */   private static final int ExpandCollapseState_Collapsed = 0;
/*      */   private static final int ExpandCollapseState_Expanded = 1;
/*      */   private static final int ExpandCollapseState_PartiallyExpanded = 2;
/*      */   private static final int ExpandCollapseState_LeafNode = 3;
/*      */   private static final int ScrollAmount_LargeDecrement = 0;
/*      */   private static final int ScrollAmount_SmallDecrement = 1;
/*      */   private static final int ScrollAmount_NoAmount = 2;
/*      */   private static final int ScrollAmount_LargeIncrement = 3;
/*      */   private static final int ScrollAmount_SmallIncrement = 4;
/*      */   private static final int UIA_ScrollPatternNoScroll = -1;
/*      */   private static final int ToggleState_Off = 0;
/*      */   private static final int ToggleState_On = 1;
/*      */   private static final int ToggleState_Indeterminate = 2;
/*      */   private static final int UiaAppendRuntimeId = 3;
/*      */   private long peer;
/*      */   private int id;
/*      */   private WinTextRangeProvider documentRange;
/*      */   private WinTextRangeProvider selectionRange;
/*  226 */   private int lastIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WinAccessible() {
/*  239 */     this.peer = _createGlassAccessible();
/*  240 */     if (this.peer == 0L) {
/*  241 */       throw new RuntimeException("could not create platform accessible");
/*      */     }
/*  243 */     this.id = idCount++;
/*      */   }
/*      */ 
/*      */   
/*      */   public void dispose() {
/*  248 */     super.dispose();
/*  249 */     if (this.selectionRange != null) {
/*  250 */       this.selectionRange.dispose();
/*  251 */       this.selectionRange = null;
/*      */     } 
/*  253 */     if (this.documentRange != null) {
/*  254 */       this.documentRange.dispose();
/*  255 */       this.documentRange = null;
/*      */     } 
/*  257 */     if (this.peer != 0L) {
/*  258 */       _destroyGlassAccessible(this.peer);
/*  259 */       this.peer = 0L;
/*      */     } 
/*      */   } public void sendNotification(AccessibleAttribute paramAccessibleAttribute) {
/*      */     Node node;
/*      */     Object object;
/*      */     long l;
/*      */     Boolean bool;
/*  266 */     if (isDisposed())
/*      */       return; 
/*  268 */     switch (paramAccessibleAttribute) {
/*      */       case TABLE_ROW:
/*  270 */         if (getView() != null) {
/*      */           
/*  272 */           long l1 = GetFocus();
/*  273 */           if (l1 != 0L) {
/*  274 */             UiaRaiseAutomationEvent(l1, 20005);
/*      */           }
/*      */         } else {
/*      */           
/*  278 */           Node node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*  279 */           if (node1 != null) {
/*  280 */             UiaRaiseAutomationEvent(getNativeAccessible(node1), 20005);
/*      */           } else {
/*      */             
/*  283 */             Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  284 */             Accessible accessible = getAccessible(scene);
/*  285 */             if (accessible != null) {
/*  286 */               accessible.sendNotification(AccessibleAttribute.FOCUS_NODE);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       
/*      */       case TABLE_CELL:
/*  292 */         node = (Node)getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  293 */         l = getNativeAccessible(node);
/*  294 */         if (l != 0L) {
/*  295 */           UiaRaiseAutomationEvent(l, 20005);
/*      */         }
/*      */ 
/*      */       
/*      */       case LIST_ITEM:
/*  300 */         if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.CHECK_BOX) {
/*  301 */           notifyToggleState();
/*      */         }
/*      */ 
/*      */       
/*      */       case TAB_ITEM:
/*  306 */         object = getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  307 */         if (object == AccessibleRole.CHECK_BOX || object == AccessibleRole.TOGGLE_BUTTON) {
/*  308 */           notifyToggleState();
/*      */         } else {
/*      */           
/*  311 */           Boolean bool1 = (Boolean)getAttribute(AccessibleAttribute.SELECTED, new Object[0]);
/*  312 */           if (bool1 != null) {
/*  313 */             if (bool1.booleanValue()) {
/*  314 */               UiaRaiseAutomationEvent(this.peer, 20012);
/*      */             } else {
/*  316 */               UiaRaiseAutomationEvent(this.peer, 20011);
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */       
/*      */       case PAGE_ITEM:
/*      */         return;
/*      */       
/*      */       case TREE_ITEM:
/*  326 */         object = getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/*  327 */         if (object != null) {
/*  328 */           WinVariant winVariant1 = new WinVariant();
/*  329 */           winVariant1.vt = 5;
/*  330 */           winVariant1.dblVal = 0.0D;
/*  331 */           WinVariant winVariant2 = new WinVariant();
/*  332 */           winVariant2.vt = 5;
/*  333 */           winVariant2.dblVal = object.doubleValue();
/*  334 */           UiaRaiseAutomationPropertyChangedEvent(this.peer, 30047, winVariant1, winVariant2);
/*      */         } 
/*      */ 
/*      */       
/*      */       case TREE_TABLE_ROW:
/*      */       case TREE_TABLE_CELL:
/*  340 */         if (this.selectionRange != null) {
/*  341 */           object = getAttribute(AccessibleAttribute.SELECTION_START, new Object[0]);
/*  342 */           boolean bool1 = (object != null && object.intValue() != this.selectionRange.getStart()) ? true : false;
/*  343 */           Integer integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/*  344 */           boolean bool2 = (integer != null && integer.intValue() != this.selectionRange.getEnd()) ? true : false;
/*      */ 
/*      */ 
/*      */           
/*  348 */           if (bool1 || bool2) {
/*  349 */             UiaRaiseAutomationEvent(this.peer, 20014);
/*      */           }
/*      */         } 
/*      */       
/*      */       case CONTEXT_MENU:
/*  354 */         object = getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*  355 */         if (object != null) {
/*  356 */           WinVariant winVariant1 = new WinVariant();
/*  357 */           winVariant1.vt = 8;
/*  358 */           winVariant1.bstrVal = "";
/*  359 */           WinVariant winVariant2 = new WinVariant();
/*  360 */           winVariant2.vt = 8;
/*  361 */           winVariant2.bstrVal = (String)object;
/*  362 */           if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.SPINNER) {
/*  363 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30005, winVariant1, winVariant2);
/*      */           } else {
/*      */             
/*  366 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30045, winVariant1, winVariant2);
/*      */           } 
/*      */         } 
/*      */         
/*  370 */         if (this.selectionRange != null || this.documentRange != null) {
/*  371 */           UiaRaiseAutomationEvent(this.peer, 20015);
/*      */         }
/*      */       
/*      */       case RADIO_MENU_ITEM:
/*  375 */         bool = (Boolean)getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/*  376 */         if (bool != null) {
/*  377 */           WinVariant winVariant1 = new WinVariant();
/*  378 */           winVariant1.vt = 3;
/*  379 */           winVariant1.lVal = bool.booleanValue() ? 0 : 1;
/*  380 */           WinVariant winVariant2 = new WinVariant();
/*  381 */           winVariant2.vt = 3;
/*  382 */           winVariant2.lVal = bool.booleanValue() ? 1 : 0;
/*  383 */           if (getAttribute(AccessibleAttribute.ROLE, new Object[0]) == AccessibleRole.TREE_TABLE_ROW) {
/*  384 */             Accessible accessible = getContainer();
/*  385 */             Integer integer = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  386 */             if (accessible != null && integer != null) {
/*  387 */               Node node1 = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer, Integer.valueOf(0) });
/*  388 */               if (node1 != null) {
/*  389 */                 long l1 = ((WinAccessible)getAccessible(node1)).getNativeAccessible();
/*  390 */                 UiaRaiseAutomationPropertyChangedEvent(l1, 30070, winVariant1, winVariant2);
/*      */               } 
/*      */             } 
/*      */           } else {
/*  394 */             UiaRaiseAutomationPropertyChangedEvent(this.peer, 30070, winVariant1, winVariant2);
/*      */           } 
/*      */         } 
/*      */       
/*      */       case CHECK_MENU_ITEM:
/*      */         return;
/*      */     } 
/*      */     
/*  402 */     UiaRaiseAutomationEvent(this.peer, 20004);
/*      */   }
/*      */ 
/*      */   
/*      */   private void notifyToggleState() {
/*  407 */     int i = get_ToggleState();
/*  408 */     WinVariant winVariant1 = new WinVariant();
/*  409 */     winVariant1.vt = 3;
/*  410 */     winVariant1.lVal = i;
/*  411 */     WinVariant winVariant2 = new WinVariant();
/*  412 */     winVariant2.vt = 3;
/*  413 */     winVariant2.lVal = i;
/*  414 */     UiaRaiseAutomationPropertyChangedEvent(this.peer, 30086, winVariant1, winVariant2);
/*      */   }
/*      */ 
/*      */   
/*      */   protected long getNativeAccessible() {
/*  419 */     return this.peer;
/*      */   }
/*      */   
/*      */   private Accessible getContainer() {
/*  423 */     if (isDisposed()) return null; 
/*  424 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  425 */     if (accessibleRole != null) {
/*  426 */       switch (accessibleRole) { case TABLE_ROW:
/*      */         case TABLE_CELL:
/*  428 */           return getContainerAccessible(AccessibleRole.TABLE_VIEW);
/*  429 */         case LIST_ITEM: return getContainerAccessible(AccessibleRole.LIST_VIEW);
/*  430 */         case TAB_ITEM: return getContainerAccessible(AccessibleRole.TAB_PANE);
/*  431 */         case PAGE_ITEM: return getContainerAccessible(AccessibleRole.PAGINATION);
/*  432 */         case TREE_ITEM: return getContainerAccessible(AccessibleRole.TREE_VIEW);
/*      */         case TREE_TABLE_ROW: case TREE_TABLE_CELL:
/*  434 */           return getContainerAccessible(AccessibleRole.TREE_TABLE_VIEW); }
/*      */ 
/*      */     
/*      */     }
/*  438 */     return null;
/*      */   }
/*      */   
/*      */   private int getControlType() {
/*  442 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  443 */     if (accessibleRole == null) return 50026; 
/*  444 */     switch (accessibleRole) { case CONTEXT_MENU:
/*  445 */         return 50009;
/*      */       case RADIO_MENU_ITEM: case CHECK_MENU_ITEM:
/*      */       case MENU:
/*      */       case MENU_ITEM:
/*  449 */         return 50011;
/*      */       case BUTTON: case MENU_BUTTON:
/*      */       case TOGGLE_BUTTON:
/*      */       case INCREMENT_BUTTON:
/*      */       case DECREMENT_BUTTON:
/*  454 */         return 50000;
/*  455 */       case SPLIT_MENU_BUTTON: return 50031;
/*      */       case PAGINATION: case TAB_PANE:
/*  457 */         return 50018;
/*      */       case TAB_ITEM: case PAGE_ITEM:
/*  459 */         return 50019;
/*  460 */       case SLIDER: return 50015;
/*  461 */       case PARENT: return (getView() != null) ? 50032 : 50033;
/*  462 */       case TEXT: return 50020;
/*      */       case TEXT_FIELD: case PASSWORD_FIELD:
/*      */       case TEXT_AREA:
/*  465 */         return 50004;
/*      */       case TREE_TABLE_VIEW: case TABLE_VIEW:
/*  467 */         return 50036;
/*  468 */       case LIST_VIEW: return 50008;
/*  469 */       case LIST_ITEM: return 50007;
/*      */       case TABLE_CELL: case TREE_TABLE_CELL:
/*  471 */         return 50029;
/*  472 */       case IMAGE_VIEW: return 50006;
/*  473 */       case RADIO_BUTTON: return 50013;
/*  474 */       case CHECK_BOX: return 50002;
/*  475 */       case COMBO_BOX: return 50003;
/*  476 */       case HYPERLINK: return 50005;
/*  477 */       case TREE_VIEW: return 50023;
/*  478 */       case TREE_ITEM: return 50024;
/*  479 */       case PROGRESS_INDICATOR: return 50012;
/*  480 */       case TOOL_BAR: return 50021;
/*  481 */       case TITLED_PANE: return 50026;
/*  482 */       case SCROLL_PANE: return 50033;
/*  483 */       case SCROLL_BAR: return 50014;
/*  484 */       case THUMB: return 50027;
/*  485 */       case MENU_BAR: return 50010;
/*  486 */       case DATE_PICKER: return 50033;
/*  487 */       case SPINNER: return 50016; }
/*  488 */      return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Node> getUnignoredChildren(WinAccessible paramWinAccessible) {
/*  494 */     if (paramWinAccessible == null) return (List<Node>)FXCollections.emptyObservableList();
/*      */ 
/*      */     
/*  497 */     ObservableList observableList = (ObservableList)paramWinAccessible.getAttribute(AccessibleAttribute.CHILDREN, new Object[0]);
/*  498 */     if (observableList == null) return (List<Node>)FXCollections.emptyObservableList(); 
/*  499 */     return (List<Node>)observableList.stream()
/*  500 */       .filter(Node::isVisible)
/*  501 */       .collect(Collectors.toList());
/*      */   }
/*      */ 
/*      */   
/*      */   private Accessible getRow() {
/*  506 */     Integer integer1 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/*  507 */     if (integer1 == null) return null; 
/*  508 */     if (integer1.intValue() != 0) return null; 
/*  509 */     Integer integer2 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*  510 */     if (integer2 == null) return null; 
/*  511 */     Accessible accessible = getContainer();
/*  512 */     if (accessible == null) return null; 
/*  513 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer2 });
/*  514 */     return getAccessible(node);
/*      */   }
/*      */   private void changeSelection(boolean paramBoolean1, boolean paramBoolean2) {
/*      */     Integer integer1, integer2;
/*  518 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  519 */     if (accessibleRole == null)
/*  520 */       return;  Accessible accessible = getContainer();
/*  521 */     if (accessible == null)
/*  522 */       return;  Node node = null;
/*  523 */     switch (accessibleRole) {
/*      */       case LIST_ITEM:
/*  525 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  526 */         if (integer1 != null) {
/*  527 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/*  532 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  533 */         if (integer1 != null) {
/*  534 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TABLE_CELL:
/*      */       case TREE_TABLE_CELL:
/*  540 */         integer1 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*  541 */         integer2 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/*  542 */         if (integer1 != null && integer2 != null) {
/*  543 */           node = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer1, integer2 });
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  549 */     if (node != null) {
/*  550 */       ObservableList observableList = FXCollections.observableArrayList();
/*  551 */       if (!paramBoolean2) {
/*      */         
/*  553 */         ObservableList observableList1 = (ObservableList)accessible.getAttribute(AccessibleAttribute.SELECTED_ITEMS, new Object[0]);
/*  554 */         if (observableList1 != null) {
/*  555 */           observableList.addAll((Collection)observableList1);
/*      */         }
/*      */       } 
/*  558 */       if (paramBoolean1) {
/*  559 */         observableList.add(node);
/*      */       } else {
/*  561 */         observableList.remove(node);
/*      */       } 
/*  563 */       accessible.executeAction(AccessibleAction.SET_SELECTED_ITEMS, new Object[] { observableList });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long GetPatternProvider(int paramInt) {
/*  571 */     if (isDisposed()) return 0L; 
/*  572 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  573 */     if (accessibleRole == null) return 0L; 
/*  574 */     boolean bool = false;
/*  575 */     switch (accessibleRole) {
/*      */       case MENU:
/*      */       case SPLIT_MENU_BUTTON:
/*  578 */         bool = (paramInt == 10000 || paramInt == 10005) ? true : false;
/*      */         break;
/*      */       
/*      */       case RADIO_MENU_ITEM:
/*      */       case CHECK_MENU_ITEM:
/*  583 */         bool = (paramInt == 10000 || paramInt == 10015) ? true : false;
/*      */         break;
/*      */       
/*      */       case MENU_ITEM:
/*      */       case BUTTON:
/*      */       case MENU_BUTTON:
/*      */       case INCREMENT_BUTTON:
/*      */       case DECREMENT_BUTTON:
/*      */       case HYPERLINK:
/*  592 */         bool = (paramInt == 10000) ? true : false;
/*      */         break;
/*      */       case TAB_ITEM:
/*      */       case PAGE_ITEM:
/*  596 */         bool = (paramInt == 10010) ? true : false;
/*      */         break;
/*      */       case PAGINATION:
/*      */       case TAB_PANE:
/*  600 */         bool = (paramInt == 10001) ? true : false;
/*      */         break;
/*      */       case SCROLL_PANE:
/*  603 */         bool = (paramInt == 10004) ? true : false;
/*      */         break;
/*      */       case TREE_TABLE_VIEW:
/*      */       case TABLE_VIEW:
/*  607 */         bool = (paramInt == 10001 || paramInt == 10006 || paramInt == 10012 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case TREE_TABLE_CELL:
/*  613 */         bool = (paramInt == 10010 || paramInt == 10007 || paramInt == 10013 || paramInt == 10005 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TABLE_CELL:
/*  620 */         bool = (paramInt == 10010 || paramInt == 10007 || paramInt == 10013 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case TREE_VIEW:
/*  626 */         bool = (paramInt == 10001 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/*  630 */         bool = (paramInt == 10010 || paramInt == 10005 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */       
/*      */       case LIST_VIEW:
/*  635 */         bool = (paramInt == 10001 || paramInt == 10004) ? true : false;
/*      */         break;
/*      */       
/*      */       case LIST_ITEM:
/*  639 */         bool = (paramInt == 10010 || paramInt == 10017) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TEXT_FIELD:
/*      */       case TEXT_AREA:
/*  655 */         bool = (paramInt == 10014 || paramInt == 10002) ? true : false;
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case RADIO_BUTTON:
/*  662 */         bool = (paramInt == 10010) ? true : false;
/*      */         break;
/*      */       case TOGGLE_BUTTON:
/*      */       case CHECK_BOX:
/*  666 */         bool = (paramInt == 10015) ? true : false;
/*      */         break;
/*      */       case TOOL_BAR:
/*      */       case TITLED_PANE:
/*  670 */         bool = (paramInt == 10005) ? true : false;
/*      */         break;
/*      */       case COMBO_BOX:
/*  673 */         bool = (paramInt == 10005 || paramInt == 10002) ? true : false;
/*      */         break;
/*      */       
/*      */       case SLIDER:
/*      */       case PROGRESS_INDICATOR:
/*      */       case SCROLL_BAR:
/*  679 */         bool = (paramInt == 10003) ? true : false;
/*      */         break;
/*      */     } 
/*      */     
/*  683 */     return bool ? getNativeAccessible() : 0L;
/*      */   }
/*      */   
/*      */   private long get_HostRawElementProvider() {
/*  687 */     if (isDisposed()) return 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  692 */     View view = getView();
/*  693 */     return (view != null) ? view.getNativeView() : 0L; } private WinVariant GetPropertyValue(int paramInt) { int i; String str2; KeyCombination keyCombination; String str1; Boolean bool2;
/*      */     AccessibleRole accessibleRole2;
/*      */     Boolean bool1;
/*      */     AccessibleRole accessibleRole1, accessibleRole3;
/*  697 */     if (isDisposed()) return null; 
/*  698 */     WinVariant winVariant = null;
/*  699 */     switch (paramInt) {
/*      */       case 30003:
/*  701 */         i = getControlType();
/*  702 */         if (i != 0) {
/*  703 */           winVariant = new WinVariant();
/*  704 */           winVariant.vt = 3;
/*  705 */           winVariant.lVal = i;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30007:
/*  710 */         str2 = (String)getAttribute(AccessibleAttribute.MNEMONIC, new Object[0]);
/*  711 */         if (str2 != null) {
/*  712 */           winVariant = new WinVariant();
/*  713 */           winVariant.vt = 8;
/*  714 */           winVariant.bstrVal = "Alt+" + str2.toLowerCase();
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30006:
/*  719 */         keyCombination = (KeyCombination)getAttribute(AccessibleAttribute.ACCELERATOR, new Object[0]);
/*  720 */         if (keyCombination != null) {
/*  721 */           winVariant = new WinVariant();
/*  722 */           winVariant.vt = 8;
/*      */ 
/*      */ 
/*      */           
/*  726 */           winVariant.bstrVal = keyCombination.toString().replaceAll("Shortcut", "Ctrl");
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 30005:
/*  733 */         accessibleRole3 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  734 */         if (accessibleRole3 == null) accessibleRole3 = AccessibleRole.NODE; 
/*  735 */         switch (accessibleRole3) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case TEXT_FIELD:
/*      */           case TEXT_AREA:
/*      */           case COMBO_BOX:
/*  744 */             keyCombination = null;
/*      */             break;
/*      */           case INCREMENT_BUTTON:
/*      */           case DECREMENT_BUTTON:
/*  748 */             str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*  749 */             if (str1 == null || str1.length() == 0) {
/*  750 */               if (accessibleRole3 == AccessibleRole.INCREMENT_BUTTON) {
/*  751 */                 str1 = "increment"; break;
/*      */               } 
/*  753 */               str1 = "decrement";
/*      */             } 
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/*  759 */             str1 = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */             break;
/*      */         } 
/*  762 */         if (str1 == null || str1.length() == 0) {
/*  763 */           Node node = (Node)getAttribute(AccessibleAttribute.LABELED_BY, new Object[0]);
/*  764 */           if (node != null) {
/*  765 */             str1 = (String)getAccessible(node).getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */           }
/*      */         } 
/*  768 */         if (str1 == null || str1.length() == 0) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  777 */         winVariant = new WinVariant();
/*  778 */         winVariant.vt = 8;
/*  779 */         winVariant.bstrVal = str1;
/*      */         break;
/*      */       
/*      */       case 30013:
/*  783 */         str1 = (String)getAttribute(AccessibleAttribute.HELP, new Object[0]);
/*  784 */         if (str1 != null) {
/*  785 */           winVariant = new WinVariant();
/*  786 */           winVariant.vt = 8;
/*  787 */           winVariant.bstrVal = str1;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30004:
/*  792 */         str1 = (String)getAttribute(AccessibleAttribute.ROLE_DESCRIPTION, new Object[0]);
/*  793 */         if (str1 == null) {
/*  794 */           accessibleRole3 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  795 */           if (accessibleRole3 == null) accessibleRole3 = AccessibleRole.NODE; 
/*  796 */           switch (accessibleRole3) { case TITLED_PANE:
/*  797 */               str1 = "title pane"; break;
/*  798 */             case PAGE_ITEM: str1 = "page"; break;
/*  799 */             case DIALOG: str1 = "dialog";
/*      */               break; }
/*      */         
/*      */         } 
/*  803 */         if (str1 != null) {
/*  804 */           winVariant = new WinVariant();
/*  805 */           winVariant.vt = 8;
/*  806 */           winVariant.bstrVal = str1;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 30008:
/*  811 */         bool2 = (Boolean)getAttribute(AccessibleAttribute.FOCUSED, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  819 */         if (Boolean.FALSE.equals(bool2)) {
/*  820 */           Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  821 */           if (scene != null) {
/*  822 */             Accessible accessible = getAccessible(scene);
/*  823 */             if (accessible != null) {
/*  824 */               Node node = (Node)accessible.getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/*  825 */               if (node != null) {
/*  826 */                 Node node1 = (Node)getAccessible(node).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/*  827 */                 if (getNativeAccessible(node1) == this.peer) {
/*  828 */                   bool2 = Boolean.valueOf(true);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  834 */         winVariant = new WinVariant();
/*  835 */         winVariant.vt = 11;
/*  836 */         winVariant.boolVal = (bool2 != null) ? bool2.booleanValue() : false;
/*      */         break;
/*      */       
/*      */       case 30174:
/*  840 */         accessibleRole2 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  841 */         winVariant = new WinVariant();
/*  842 */         winVariant.vt = 11;
/*  843 */         winVariant.boolVal = (accessibleRole2 == AccessibleRole.DIALOG);
/*      */         break;
/*      */       
/*      */       case 30016:
/*      */       case 30017:
/*  848 */         winVariant = new WinVariant();
/*  849 */         winVariant.vt = 11;
/*  850 */         winVariant.boolVal = (getView() != null || !isIgnored());
/*      */         break;
/*      */       
/*      */       case 30010:
/*  854 */         bool1 = (Boolean)getAttribute(AccessibleAttribute.DISABLED, new Object[0]);
/*  855 */         winVariant = new WinVariant();
/*  856 */         winVariant.vt = 11;
/*  857 */         winVariant.boolVal = (bool1 != null) ? (!bool1.booleanValue()) : true;
/*      */         break;
/*      */       
/*      */       case 30009:
/*  861 */         winVariant = new WinVariant();
/*  862 */         winVariant.vt = 11;
/*  863 */         winVariant.boolVal = true;
/*      */         break;
/*      */       
/*      */       case 30019:
/*  867 */         accessibleRole1 = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*  868 */         winVariant = new WinVariant();
/*  869 */         winVariant.vt = 11;
/*  870 */         winVariant.boolVal = (accessibleRole1 == AccessibleRole.PASSWORD_FIELD);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30011:
/*  875 */         winVariant = new WinVariant();
/*  876 */         winVariant.vt = 8;
/*  877 */         winVariant.bstrVal = "JavaFX" + this.id;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 30107:
/*  882 */         winVariant = new WinVariant();
/*  883 */         winVariant.vt = 8;
/*  884 */         winVariant.bstrVal = "JavaFXProvider";
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/*  889 */     return winVariant; }
/*      */ 
/*      */   
/*      */   private Screen getScreen() {
/*  893 */     Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  894 */     if (scene == null || scene.getWindow() == null) return null; 
/*  895 */     TKStage tKStage = WindowHelper.getPeer(scene.getWindow());
/*  896 */     if (!(tKStage instanceof WindowStage)) return null; 
/*  897 */     WindowStage windowStage = (WindowStage)tKStage;
/*  898 */     if (windowStage.getPlatformWindow() == null) return null; 
/*  899 */     return windowStage.getPlatformWindow().getScreen();
/*      */   }
/*      */   
/*      */   float[] getPlatformBounds(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/*  903 */     float[] arrayOfFloat = { paramFloat1, paramFloat2, paramFloat3, paramFloat4 };
/*  904 */     Screen screen = getScreen();
/*  905 */     if (screen == null) return arrayOfFloat; 
/*  906 */     arrayOfFloat[0] = screen.toPlatformX(paramFloat1);
/*  907 */     arrayOfFloat[1] = screen.toPlatformY(paramFloat2);
/*  908 */     arrayOfFloat[2] = (float)Math.ceil((paramFloat3 * screen.getPlatformScaleX()));
/*  909 */     arrayOfFloat[3] = (float)Math.ceil((paramFloat4 * screen.getPlatformScaleY()));
/*  910 */     return arrayOfFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private float[] get_BoundingRectangle() {
/*  917 */     if (isDisposed()) return null;
/*      */     
/*  919 */     if (getView() != null) return null;
/*      */     
/*  921 */     Bounds bounds = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/*  922 */     if (bounds != null) {
/*  923 */       return getPlatformBounds((float)bounds.getMinX(), 
/*  924 */           (float)bounds.getMinY(), 
/*  925 */           (float)bounds.getWidth(), 
/*  926 */           (float)bounds.getHeight());
/*      */     }
/*  928 */     return null;
/*      */   }
/*      */   
/*      */   private long get_FragmentRoot() {
/*  932 */     if (isDisposed()) return 0L; 
/*  933 */     Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/*  934 */     if (scene == null) return 0L; 
/*  935 */     WinAccessible winAccessible = (WinAccessible)getAccessible(scene);
/*  936 */     if (winAccessible == null || winAccessible.isDisposed()) return 0L; 
/*  937 */     return winAccessible.getNativeAccessible();
/*      */   }
/*      */   
/*      */   private long[] GetEmbeddedFragmentRoots() {
/*  941 */     if (isDisposed()) return null; 
/*  942 */     return null;
/*      */   }
/*      */   
/*      */   private int[] GetRuntimeId() {
/*  946 */     if (isDisposed()) return null;
/*      */ 
/*      */     
/*  949 */     if (getView() != null) return null; 
/*  950 */     return new int[] { 3, this.id };
/*      */   }
/*      */   private long NavigateListView(WinAccessible paramWinAccessible, int paramInt) {
/*      */     Integer integer3;
/*  954 */     Accessible accessible = paramWinAccessible.getContainer();
/*  955 */     if (accessible == null) return 0L; 
/*  956 */     Integer integer1 = (Integer)accessible.getAttribute(AccessibleAttribute.ITEM_COUNT, new Object[0]);
/*  957 */     if (integer1 == null || integer1.intValue() == 0) return 0L; 
/*  958 */     Integer integer2 = (Integer)paramWinAccessible.getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/*  959 */     if (integer2 == null) return 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  966 */     if (0 > integer2.intValue() || integer2.intValue() >= integer1.intValue()) return 0L; 
/*  967 */     switch (paramInt) { case 1:
/*  968 */         integer3 = integer2; integer2 = Integer.valueOf(integer2.intValue() + 1); break;
/*  969 */       case 2: integer3 = integer2; integer2 = Integer.valueOf(integer2.intValue() - 1); break;
/*  970 */       case 3: integer2 = Integer.valueOf(0); break;
/*  971 */       case 4: integer2 = Integer.valueOf(integer1.intValue() - 1); break; }
/*      */     
/*  973 */     if (0 > integer2.intValue() || integer2.intValue() >= integer1.intValue()) return 0L; 
/*  974 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer2 });
/*  975 */     return getNativeAccessible(node);
/*      */   } private long Navigate(int paramInt) {
/*      */     Node node2;
/*      */     List<Node> list;
/*  979 */     if (isDisposed()) return 0L; 
/*  980 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/*      */     
/*  982 */     boolean bool = (accessibleRole == AccessibleRole.TREE_ITEM) ? true : false;
/*  983 */     Node node1 = null;
/*  984 */     switch (paramInt) {
/*      */       
/*      */       case 0:
/*  987 */         if (getView() != null) return 0L;
/*      */         
/*  989 */         if (bool) {
/*  990 */           node1 = (Node)getAttribute(AccessibleAttribute.TREE_ITEM_PARENT, new Object[0]);
/*  991 */           if (node1 == null) {
/*      */             
/*  993 */             WinAccessible winAccessible = (WinAccessible)getContainer();
/*  994 */             return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */           }  break;
/*      */         } 
/*  997 */         node1 = (Node)getAttribute(AccessibleAttribute.PARENT, new Object[0]);
/*  998 */         if (node1 == null) {
/*      */           
/* 1000 */           Scene scene = (Scene)getAttribute(AccessibleAttribute.SCENE, new Object[0]);
/* 1001 */           WinAccessible winAccessible = (WinAccessible)getAccessible(scene);
/*      */           
/* 1003 */           if (winAccessible == null || winAccessible == this || winAccessible.isDisposed()) return 0L; 
/* 1004 */           return winAccessible.getNativeAccessible();
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/*      */       case 2:
/* 1011 */         if (accessibleRole == AccessibleRole.LIST_ITEM) {
/* 1012 */           return NavigateListView(this, paramInt);
/*      */         }
/*      */         
/* 1015 */         node2 = (Node)getAttribute(bool ? AccessibleAttribute.TREE_ITEM_PARENT : AccessibleAttribute.PARENT, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1020 */         if (node2 != null) {
/* 1021 */           Function<Integer, Node> function; WinAccessible winAccessible = (WinAccessible)getAccessible(node2);
/*      */           
/* 1023 */           int i = 0;
/* 1024 */           if (bool) {
/* 1025 */             Integer integer = (Integer)winAccessible.getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/* 1026 */             if (integer == null) return 0L; 
/* 1027 */             i = integer.intValue();
/* 1028 */             function = (paramInteger -> (Node)paramWinAccessible.getAttribute(AccessibleAttribute.TREE_ITEM_AT_INDEX, new Object[] { paramInteger }));
/*      */           }
/*      */           else {
/*      */             
/* 1032 */             List<Node> list1 = getUnignoredChildren(winAccessible);
/* 1033 */             if (list1 == null) return 0L; 
/* 1034 */             i = list1.size();
/* 1035 */             function = (paramInteger -> (Node)paramList.get(paramInteger.intValue()));
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1040 */           int j = winAccessible.lastIndex;
/* 1041 */           int k = -1;
/* 1042 */           if (0 <= j && j < i && getNativeAccessible(function.apply(Integer.valueOf(j))) == this.peer) {
/* 1043 */             k = j;
/*      */           } else {
/* 1045 */             for (byte b = 0; b < i; b++) {
/* 1046 */               if (getNativeAccessible(function.apply(Integer.valueOf(b))) == this.peer) {
/* 1047 */                 k = b;
/*      */                 break;
/*      */               } 
/*      */             } 
/*      */           } 
/* 1052 */           if (k != -1) {
/* 1053 */             if (paramInt == 1) {
/* 1054 */               k++;
/*      */             } else {
/* 1056 */               k--;
/*      */             } 
/* 1058 */             if (0 <= k && k < i) {
/* 1059 */               node1 = function.apply(Integer.valueOf(k));
/* 1060 */               winAccessible.lastIndex = k;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 3:
/*      */       case 4:
/* 1068 */         this.lastIndex = -1;
/* 1069 */         if (accessibleRole == AccessibleRole.LIST_VIEW)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1076 */           getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { Integer.valueOf(0) });
/*      */         }
/* 1078 */         if (accessibleRole == AccessibleRole.TREE_VIEW) {
/*      */           
/* 1080 */           this.lastIndex = 0;
/* 1081 */           node1 = (Node)getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { Integer.valueOf(0) }); break;
/* 1082 */         }  if (bool) {
/* 1083 */           Integer integer = (Integer)getAttribute(AccessibleAttribute.TREE_ITEM_COUNT, new Object[0]);
/* 1084 */           if (integer != null && integer.intValue() > 0) {
/* 1085 */             this.lastIndex = (paramInt == 3) ? 0 : (integer.intValue() - 1);
/* 1086 */             node1 = (Node)getAttribute(AccessibleAttribute.TREE_ITEM_AT_INDEX, new Object[] { Integer.valueOf(this.lastIndex) });
/*      */           }  break;
/*      */         } 
/* 1089 */         list = getUnignoredChildren(this);
/* 1090 */         if (list != null && list.size() > 0) {
/* 1091 */           this.lastIndex = (paramInt == 3) ? 0 : (list.size() - 1);
/* 1092 */           node1 = list.get(this.lastIndex);
/*      */         } 
/* 1094 */         if (node1 != null) {
/* 1095 */           accessibleRole = (AccessibleRole)getAccessible(node1).getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1096 */           if (accessibleRole == AccessibleRole.LIST_ITEM) {
/* 1097 */             WinAccessible winAccessible = (WinAccessible)getAccessible(node1);
/* 1098 */             return NavigateListView(winAccessible, paramInt);
/*      */           } 
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1105 */     return getNativeAccessible(node1);
/*      */   }
/*      */   
/*      */   private void SetFocus() {
/* 1109 */     if (isDisposed())
/* 1110 */       return;  executeAction(AccessibleAction.REQUEST_FOCUS, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long ElementProviderFromPoint(double paramDouble1, double paramDouble2) {
/* 1117 */     if (isDisposed()) return 0L; 
/* 1118 */     Node node = (Node)getAttribute(AccessibleAttribute.NODE_AT_POINT, new Object[] { new Point2D(paramDouble1, paramDouble2) });
/* 1119 */     return getNativeAccessible(node);
/*      */   }
/*      */   
/*      */   private long GetFocus() {
/* 1123 */     if (isDisposed()) return 0L; 
/* 1124 */     Node node1 = (Node)getAttribute(AccessibleAttribute.FOCUS_NODE, new Object[0]);
/* 1125 */     if (node1 == null) return 0L; 
/* 1126 */     Node node2 = (Node)getAccessible(node1).getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/* 1127 */     if (node2 != null) return getNativeAccessible(node2); 
/* 1128 */     return getNativeAccessible(node1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void AdviseEventAdded(int paramInt, long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void AdviseEventRemoved(int paramInt, long paramLong) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Invoke() {
/* 1149 */     if (isDisposed())
/* 1150 */       return;  executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */   } private long[] GetSelection() {
/*      */     ObservableList observableList;
/*      */     Node node;
/*      */     Integer integer;
/*      */     byte b;
/*      */     byte b1, b2;
/* 1157 */     if (isDisposed()) return null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1163 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1164 */     if (accessibleRole == null) return null; 
/* 1165 */     switch (accessibleRole) {
/*      */       
/*      */       case TREE_TABLE_VIEW:
/*      */       case TABLE_VIEW:
/*      */       case LIST_VIEW:
/*      */       case TREE_VIEW:
/* 1171 */         observableList = (ObservableList)getAttribute(AccessibleAttribute.SELECTED_ITEMS, new Object[0]);
/* 1172 */         if (observableList != null) {
/* 1173 */           return observableList.stream().mapToLong(paramNode -> getNativeAccessible(paramNode)).toArray();
/*      */         }
/*      */         break;
/*      */       
/*      */       case PAGINATION:
/*      */       case TAB_PANE:
/* 1179 */         node = (Node)getAttribute(AccessibleAttribute.FOCUS_ITEM, new Object[0]);
/* 1180 */         if (node != null) {
/* 1181 */           return new long[] { getNativeAccessible(node) };
/*      */         }
/*      */         break;
/*      */       
/*      */       case TEXT_FIELD:
/*      */       case TEXT_AREA:
/* 1187 */         if (this.selectionRange == null) {
/* 1188 */           this.selectionRange = new WinTextRangeProvider(this);
/*      */         }
/* 1190 */         integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_START, new Object[0]);
/* 1191 */         b = (integer != null) ? integer.intValue() : 0;
/* 1192 */         b1 = -1;
/* 1193 */         b2 = -1;
/* 1194 */         if (b) {
/* 1195 */           integer = (Integer)getAttribute(AccessibleAttribute.SELECTION_END, new Object[0]);
/* 1196 */           b1 = (integer != null) ? integer.intValue() : 0;
/* 1197 */           if (b1 >= b) {
/* 1198 */             String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1199 */             b2 = (str != null) ? str.length() : 0;
/*      */           } 
/*      */         } 
/* 1202 */         if (b2 != -1 && b1 <= b2) {
/* 1203 */           this.selectionRange.setRange(b, b1);
/*      */         } else {
/* 1205 */           this.selectionRange.setRange(0, 0);
/*      */         } 
/* 1207 */         return new long[] { this.selectionRange.getNativeProvider() };
/*      */     } 
/*      */ 
/*      */     
/* 1211 */     return null;
/*      */   }
/*      */   
/*      */   private boolean get_CanSelectMultiple() {
/* 1215 */     if (isDisposed()) return false; 
/* 1216 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1217 */     if (accessibleRole != null) {
/* 1218 */       switch (accessibleRole) {
/*      */         case TREE_TABLE_VIEW:
/*      */         case TABLE_VIEW:
/*      */         case LIST_VIEW:
/*      */         case TREE_VIEW:
/* 1223 */           return Boolean.TRUE.equals(getAttribute(AccessibleAttribute.MULTIPLE_SELECTION, new Object[0]));
/*      */       } 
/*      */     
/*      */     }
/* 1227 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_IsSelectionRequired() {
/* 1231 */     if (isDisposed()) return false;
/*      */     
/* 1233 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void SetValue(double paramDouble) {
/* 1240 */     if (isDisposed())
/* 1241 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1242 */     if (accessibleRole != null) {
/* 1243 */       switch (accessibleRole) {
/*      */         case SLIDER:
/*      */         case SCROLL_BAR:
/* 1246 */           executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf(paramDouble) });
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private double get_Value() {
/* 1254 */     if (isDisposed()) return 0.0D; 
/* 1255 */     if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) return 0.0D; 
/* 1256 */     Double double_ = (Double)getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1257 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean get_IsReadOnly() {
/* 1264 */     if (isDisposed()) return false; 
/* 1265 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1266 */     if (accessibleRole != null) {
/* 1267 */       switch (accessibleRole) { case SLIDER:
/* 1268 */           return false;
/* 1269 */         case SCROLL_BAR: return true;
/*      */         case TEXT_FIELD: case TEXT_AREA:
/*      */         case COMBO_BOX:
/* 1272 */           return Boolean.FALSE.equals(getAttribute(AccessibleAttribute.EDITABLE, new Object[0])); }
/*      */ 
/*      */     
/*      */     }
/* 1276 */     return true;
/*      */   }
/*      */   
/*      */   private double get_Maximum() {
/* 1280 */     if (isDisposed()) return 0.0D; 
/* 1281 */     Double double_ = (Double)getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1282 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */   
/*      */   private double get_Minimum() {
/* 1286 */     if (isDisposed()) return 0.0D; 
/* 1287 */     Double double_ = (Double)getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1288 */     return (double_ != null) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */   
/*      */   private double get_LargeChange() {
/* 1292 */     if (isDisposed()) return 0.0D; 
/* 1293 */     return 10.0D;
/*      */   }
/*      */   
/*      */   private double get_SmallChange() {
/* 1297 */     if (isDisposed()) return 0.0D; 
/* 1298 */     return 3.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void SetValueString(String paramString) {
/* 1305 */     if (isDisposed())
/* 1306 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1307 */     if (accessibleRole != null) {
/* 1308 */       switch (accessibleRole) {
/*      */         case TEXT_FIELD:
/*      */         case TEXT_AREA:
/* 1311 */           executeAction(AccessibleAction.SET_TEXT, new Object[] { paramString });
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private String get_ValueString() {
/* 1319 */     if (isDisposed()) return null; 
/* 1320 */     return (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Select() {
/* 1327 */     if (isDisposed())
/* 1328 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1329 */     if (accessibleRole != null) {
/* 1330 */       switch (accessibleRole) {
/*      */         case TAB_ITEM:
/*      */         case PAGE_ITEM:
/* 1333 */           executeAction(AccessibleAction.REQUEST_FOCUS, new Object[0]);
/*      */           break;
/*      */         case BUTTON:
/*      */         case TOGGLE_BUTTON:
/*      */         case INCREMENT_BUTTON:
/*      */         case DECREMENT_BUTTON:
/*      */         case RADIO_BUTTON:
/* 1340 */           executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */           break;
/*      */         case TABLE_CELL:
/*      */         case LIST_ITEM:
/*      */         case TREE_ITEM:
/*      */         case TREE_TABLE_CELL:
/* 1346 */           changeSelection(true, true);
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void AddToSelection() {
/* 1354 */     if (isDisposed())
/* 1355 */       return;  changeSelection(true, false);
/*      */   }
/*      */   
/*      */   private void RemoveFromSelection() {
/* 1359 */     if (isDisposed())
/* 1360 */       return;  changeSelection(false, false);
/*      */   }
/*      */   
/*      */   private boolean get_IsSelected() {
/* 1364 */     if (isDisposed()) return false; 
/* 1365 */     return Boolean.TRUE.equals(getAttribute(AccessibleAttribute.SELECTED, new Object[0]));
/*      */   }
/*      */   
/*      */   private long get_SelectionContainer() {
/* 1369 */     if (isDisposed()) return 0L; 
/* 1370 */     WinAccessible winAccessible = (WinAccessible)getContainer();
/* 1371 */     return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetVisibleRanges() {
/* 1378 */     if (isDisposed()) return null; 
/* 1379 */     return new long[] { get_DocumentRange() };
/*      */   }
/*      */   
/*      */   private long RangeFromChild(long paramLong) {
/* 1383 */     if (isDisposed()) return 0L; 
/* 1384 */     return 0L;
/*      */   }
/*      */   
/*      */   private long RangeFromPoint(double paramDouble1, double paramDouble2) {
/* 1388 */     if (isDisposed()) return 0L; 
/* 1389 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.OFFSET_AT_POINT, new Object[] { new Point2D(paramDouble1, paramDouble2) });
/* 1390 */     if (integer != null) {
/* 1391 */       WinTextRangeProvider winTextRangeProvider = new WinTextRangeProvider(this);
/* 1392 */       winTextRangeProvider.setRange(integer.intValue(), integer.intValue());
/* 1393 */       return winTextRangeProvider.getNativeProvider();
/*      */     } 
/* 1395 */     return 0L;
/*      */   }
/*      */   
/*      */   private long get_DocumentRange() {
/* 1399 */     if (isDisposed()) return 0L; 
/* 1400 */     if (this.documentRange == null) {
/* 1401 */       this.documentRange = new WinTextRangeProvider(this);
/*      */     }
/* 1403 */     String str = (String)getAttribute(AccessibleAttribute.TEXT, new Object[0]);
/* 1404 */     if (str == null) return 0L; 
/* 1405 */     this.documentRange.setRange(0, str.length());
/* 1406 */     return this.documentRange.getNativeProvider();
/*      */   }
/*      */   
/*      */   private int get_SupportedTextSelection() {
/* 1410 */     if (isDisposed()) return 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1415 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_ColumnCount() {
/* 1422 */     if (isDisposed()) return 0; 
/* 1423 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_COUNT, new Object[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1429 */     return (integer != null) ? integer.intValue() : 1;
/*      */   }
/*      */   
/*      */   private int get_RowCount() {
/* 1433 */     if (isDisposed()) return 0; 
/* 1434 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.ROW_COUNT, new Object[0]);
/* 1435 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private long GetItem(int paramInt1, int paramInt2) {
/* 1439 */     if (isDisposed()) return 0L; 
/* 1440 */     Node node = (Node)getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/* 1441 */     return getNativeAccessible(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_Column() {
/* 1448 */     if (isDisposed()) return 0; 
/* 1449 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1450 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private int get_ColumnSpan() {
/* 1454 */     if (isDisposed()) return 0; 
/* 1455 */     return 1;
/*      */   }
/*      */   
/*      */   private long get_ContainingGrid() {
/* 1459 */     if (isDisposed()) return 0L; 
/* 1460 */     WinAccessible winAccessible = (WinAccessible)getContainer();
/* 1461 */     return (winAccessible != null) ? winAccessible.getNativeAccessible() : 0L;
/*      */   }
/*      */   
/*      */   private int get_Row() {
/* 1465 */     if (isDisposed()) return 0; 
/* 1466 */     Integer integer = null;
/* 1467 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1468 */     if (accessibleRole != null) {
/* 1469 */       switch (accessibleRole) { case TABLE_ROW:
/*      */         case LIST_ITEM:
/*      */         case TREE_TABLE_ROW:
/* 1472 */           integer = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]); break;
/*      */         case TABLE_CELL: case TREE_TABLE_CELL:
/* 1474 */           integer = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/*      */           break; }
/*      */     
/*      */     }
/* 1478 */     return (integer != null) ? integer.intValue() : 0;
/*      */   }
/*      */   
/*      */   private int get_RowSpan() {
/* 1482 */     if (isDisposed()) return 0; 
/* 1483 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetColumnHeaders() {
/* 1490 */     if (isDisposed()) return null;
/*      */     
/* 1492 */     return null;
/*      */   }
/*      */   
/*      */   private long[] GetRowHeaders() {
/* 1496 */     if (isDisposed()) return null;
/*      */     
/* 1498 */     return null;
/*      */   }
/*      */   
/*      */   private int get_RowOrColumnMajor() {
/* 1502 */     if (isDisposed()) return 0; 
/* 1503 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long[] GetColumnHeaderItems() {
/* 1510 */     if (isDisposed()) return null; 
/* 1511 */     Integer integer = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1512 */     if (integer == null) return null; 
/* 1513 */     Accessible accessible = getContainer();
/* 1514 */     if (accessible == null) return null; 
/* 1515 */     Node node = (Node)accessible.getAttribute(AccessibleAttribute.COLUMN_AT_INDEX, new Object[] { integer });
/* 1516 */     if (node == null) return null; 
/* 1517 */     return new long[] { getNativeAccessible(node) };
/*      */   }
/*      */   
/*      */   private long[] GetRowHeaderItems() {
/* 1521 */     if (isDisposed()) return null;
/*      */     
/* 1523 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Toggle() {
/* 1530 */     if (isDisposed())
/* 1531 */       return;  executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */   }
/*      */   
/*      */   private int get_ToggleState() {
/* 1535 */     if (isDisposed()) return 0; 
/* 1536 */     if (Boolean.TRUE.equals(getAttribute(AccessibleAttribute.INDETERMINATE, new Object[0]))) {
/* 1537 */       return 2;
/*      */     }
/* 1539 */     boolean bool = Boolean.TRUE.equals(getAttribute(AccessibleAttribute.SELECTED, new Object[0]));
/* 1540 */     return bool ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void Collapse() {
/* 1547 */     if (isDisposed())
/* 1548 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1549 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1550 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1551 */       if (node != null) {
/* 1552 */         getAccessible(node).executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */       }
/*      */       return;
/*      */     } 
/* 1556 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1557 */       Accessible accessible = getRow();
/* 1558 */       if (accessible != null) accessible.executeAction(AccessibleAction.COLLAPSE, new Object[0]); 
/*      */       return;
/*      */     } 
/* 1561 */     executeAction(AccessibleAction.COLLAPSE, new Object[0]);
/*      */   }
/*      */   
/*      */   private void Expand() {
/* 1565 */     if (isDisposed())
/* 1566 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1567 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1568 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1569 */       if (node != null) {
/* 1570 */         getAccessible(node).executeAction(AccessibleAction.FIRE, new Object[0]);
/*      */       }
/*      */       return;
/*      */     } 
/* 1574 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1575 */       Accessible accessible = getRow();
/* 1576 */       if (accessible != null) accessible.executeAction(AccessibleAction.EXPAND, new Object[0]); 
/*      */       return;
/*      */     } 
/* 1579 */     executeAction(AccessibleAction.EXPAND, new Object[0]);
/*      */   }
/*      */   
/*      */   private int get_ExpandCollapseState() {
/* 1583 */     if (isDisposed()) return 0;
/*      */     
/* 1585 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1586 */     if (accessibleRole == AccessibleRole.TOOL_BAR) {
/* 1587 */       Node node = (Node)getAttribute(AccessibleAttribute.OVERFLOW_BUTTON, new Object[0]);
/* 1588 */       if (node != null) {
/* 1589 */         boolean bool1 = Boolean.TRUE.equals(getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]));
/* 1590 */         return bool1 ? 0 : 1;
/*      */       } 
/*      */     } 
/*      */     
/* 1594 */     if (accessibleRole == AccessibleRole.TREE_TABLE_CELL) {
/* 1595 */       Accessible accessible = getRow();
/* 1596 */       if (accessible == null) return 3; 
/* 1597 */       Object object1 = accessible.getAttribute(AccessibleAttribute.LEAF, new Object[0]);
/* 1598 */       if (Boolean.TRUE.equals(object1)) return 3; 
/* 1599 */       object1 = accessible.getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/* 1600 */       boolean bool1 = Boolean.TRUE.equals(object1);
/* 1601 */       return bool1 ? 1 : 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1611 */     Object object = getAttribute(AccessibleAttribute.LEAF, new Object[0]);
/* 1612 */     if (Boolean.TRUE.equals(object)) return 3;
/*      */     
/* 1614 */     object = getAttribute(AccessibleAttribute.EXPANDED, new Object[0]);
/* 1615 */     boolean bool = Boolean.TRUE.equals(object);
/* 1616 */     return bool ? 1 : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean get_CanMove() {
/* 1623 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_CanResize() {
/* 1627 */     return false;
/*      */   }
/*      */   
/*      */   private boolean get_CanRotate() {
/* 1631 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void Move(double paramDouble1, double paramDouble2) {}
/*      */ 
/*      */ 
/*      */   
/*      */   private void Resize(double paramDouble1, double paramDouble2) {}
/*      */ 
/*      */   
/*      */   private void Rotate(double paramDouble) {}
/*      */ 
/*      */   
/*      */   private void Scroll(int paramInt1, int paramInt2) {
/* 1647 */     if (isDisposed()) {
/*      */       return;
/*      */     }
/* 1650 */     if (get_VerticallyScrollable()) {
/* 1651 */       Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1652 */       Accessible accessible = getAccessible(node);
/* 1653 */       if (accessible == null)
/* 1654 */         return;  switch (paramInt2) {
/*      */         case 3:
/* 1656 */           accessible.executeAction(AccessibleAction.BLOCK_INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 4:
/* 1659 */           accessible.executeAction(AccessibleAction.INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 0:
/* 1662 */           accessible.executeAction(AccessibleAction.BLOCK_DECREMENT, new Object[0]);
/*      */           break;
/*      */         case 1:
/* 1665 */           accessible.executeAction(AccessibleAction.DECREMENT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 1672 */     if (get_HorizontallyScrollable()) {
/* 1673 */       Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1674 */       Accessible accessible = getAccessible(node);
/* 1675 */       if (accessible == null)
/* 1676 */         return;  switch (paramInt1) {
/*      */         case 3:
/* 1678 */           accessible.executeAction(AccessibleAction.BLOCK_INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 4:
/* 1681 */           accessible.executeAction(AccessibleAction.INCREMENT, new Object[0]);
/*      */           break;
/*      */         case 0:
/* 1684 */           accessible.executeAction(AccessibleAction.BLOCK_DECREMENT, new Object[0]);
/*      */           break;
/*      */         case 1:
/* 1687 */           accessible.executeAction(AccessibleAction.DECREMENT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void SetScrollPercent(double paramDouble1, double paramDouble2) {
/* 1695 */     if (isDisposed()) {
/*      */       return;
/*      */     }
/* 1698 */     if (paramDouble2 != -1.0D && get_VerticallyScrollable()) {
/* 1699 */       Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1700 */       Accessible accessible = getAccessible(node);
/* 1701 */       if (accessible == null)
/* 1702 */         return;  Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1703 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1704 */       if (double_1 != null && double_2 != null) {
/* 1705 */         accessible.executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf((double_2.doubleValue() - double_1.doubleValue()) * paramDouble2 / 100.0D + double_1.doubleValue()) });
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1710 */     if (paramDouble1 != -1.0D && get_HorizontallyScrollable()) {
/* 1711 */       Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1712 */       Accessible accessible = getAccessible(node);
/* 1713 */       if (accessible == null)
/* 1714 */         return;  Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1715 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1716 */       if (double_1 != null && double_2 != null) {
/* 1717 */         accessible.executeAction(AccessibleAction.SET_VALUE, new Object[] { Double.valueOf((double_2.doubleValue() - double_1.doubleValue()) * paramDouble1 / 100.0D + double_1.doubleValue()) });
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean get_HorizontallyScrollable() {
/* 1723 */     if (isDisposed()) return false;
/*      */     
/* 1725 */     Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1726 */     if (node == null) return false;
/*      */     
/* 1728 */     Boolean bool = (Boolean)getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]);
/* 1729 */     return Boolean.TRUE.equals(bool);
/*      */   }
/*      */   
/*      */   private double get_HorizontalScrollPercent() {
/* 1733 */     if (isDisposed()) return 0.0D;
/*      */     
/* 1735 */     if (!get_HorizontallyScrollable()) {
/* 1736 */       return -1.0D;
/*      */     }
/*      */     
/* 1739 */     Node node = (Node)getAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR, new Object[0]);
/* 1740 */     if (node != null) {
/*      */       
/* 1742 */       Accessible accessible = getAccessible(node);
/* 1743 */       Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1744 */       if (double_1 == null) return 0.0D; 
/* 1745 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1746 */       if (double_2 == null) return 0.0D; 
/* 1747 */       Double double_3 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1748 */       if (double_3 == null) return 0.0D; 
/* 1749 */       return 100.0D * (double_1.doubleValue() - double_3.doubleValue()) / (double_2.doubleValue() - double_3.doubleValue());
/*      */     } 
/*      */     
/* 1752 */     return 0.0D;
/*      */   }
/*      */   
/*      */   private double get_HorizontalViewSize() {
/* 1756 */     if (isDisposed()) return 0.0D; 
/* 1757 */     if (!get_HorizontallyScrollable()) return 100.0D; 
/* 1758 */     Node node = (Node)getAttribute(AccessibleAttribute.CONTENTS, new Object[0]);
/* 1759 */     if (node == null) return 100.0D; 
/* 1760 */     Bounds bounds1 = (Bounds)getAccessible(node).getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1761 */     if (bounds1 == null) return 0.0D; 
/* 1762 */     Bounds bounds2 = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1763 */     if (bounds2 == null) return 0.0D; 
/* 1764 */     return bounds2.getWidth() / bounds1.getWidth() * 100.0D;
/*      */   }
/*      */   
/*      */   private boolean get_VerticallyScrollable() {
/* 1768 */     if (isDisposed()) return false;
/*      */     
/* 1770 */     Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1771 */     if (node == null) return false;
/*      */     
/* 1773 */     Boolean bool = (Boolean)getAccessible(node).getAttribute(AccessibleAttribute.VISIBLE, new Object[0]);
/* 1774 */     return Boolean.TRUE.equals(bool);
/*      */   }
/*      */   
/*      */   private double get_VerticalScrollPercent() {
/* 1778 */     if (isDisposed()) return 0.0D;
/*      */     
/* 1780 */     if (!get_VerticallyScrollable()) {
/* 1781 */       return -1.0D;
/*      */     }
/*      */     
/* 1784 */     Node node = (Node)getAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR, new Object[0]);
/* 1785 */     if (node != null) {
/*      */       
/* 1787 */       Accessible accessible = getAccessible(node);
/* 1788 */       Double double_1 = (Double)accessible.getAttribute(AccessibleAttribute.VALUE, new Object[0]);
/* 1789 */       if (double_1 == null) return 0.0D; 
/* 1790 */       Double double_2 = (Double)accessible.getAttribute(AccessibleAttribute.MAX_VALUE, new Object[0]);
/* 1791 */       if (double_2 == null) return 0.0D; 
/* 1792 */       Double double_3 = (Double)accessible.getAttribute(AccessibleAttribute.MIN_VALUE, new Object[0]);
/* 1793 */       if (double_3 == null) return 0.0D; 
/* 1794 */       return 100.0D * (double_1.doubleValue() - double_3.doubleValue()) / (double_2.doubleValue() - double_3.doubleValue());
/*      */     } 
/*      */     
/* 1797 */     return 0.0D;
/*      */   }
/*      */   
/*      */   private double get_VerticalViewSize() {
/* 1801 */     if (isDisposed()) return 0.0D; 
/* 1802 */     if (!get_VerticallyScrollable()) return 100.0D;
/*      */     
/* 1804 */     double d1 = 0.0D;
/*      */     
/* 1806 */     Bounds bounds = (Bounds)getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1807 */     if (bounds == null) return 0.0D; 
/* 1808 */     double d2 = bounds.getHeight();
/*      */     
/* 1810 */     AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1811 */     if (accessibleRole == null) return 0.0D; 
/* 1812 */     if (accessibleRole == AccessibleRole.SCROLL_PANE) {
/* 1813 */       Node node = (Node)getAttribute(AccessibleAttribute.CONTENTS, new Object[0]);
/* 1814 */       if (node != null) {
/* 1815 */         Bounds bounds1 = (Bounds)getAccessible(node).getAttribute(AccessibleAttribute.BOUNDS, new Object[0]);
/* 1816 */         d1 = (bounds1 == null) ? 0.0D : bounds1.getHeight();
/*      */       } 
/*      */     } else {
/* 1819 */       Integer integer = Integer.valueOf(0);
/* 1820 */       switch (accessibleRole) {
/*      */         case LIST_VIEW:
/* 1822 */           integer = (Integer)getAttribute(AccessibleAttribute.ITEM_COUNT, new Object[0]);
/*      */           break;
/*      */         case TREE_TABLE_VIEW:
/*      */         case TABLE_VIEW:
/*      */         case TREE_VIEW:
/* 1827 */           integer = (Integer)getAttribute(AccessibleAttribute.ROW_COUNT, new Object[0]);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1838 */       d1 = (integer == null) ? 0.0D : (integer.intValue() * 24);
/*      */     } 
/*      */     
/* 1841 */     return (d1 == 0.0D) ? 0.0D : (d2 / d1 * 100.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void ScrollIntoView() {
/*      */     Integer integer1, integer2;
/* 1848 */     if (isDisposed())
/* 1849 */       return;  AccessibleRole accessibleRole = (AccessibleRole)getAttribute(AccessibleAttribute.ROLE, new Object[0]);
/* 1850 */     if (accessibleRole == null)
/* 1851 */       return;  Accessible accessible = getContainer();
/* 1852 */     if (accessible == null)
/* 1853 */       return;  Node node = null;
/* 1854 */     switch (accessibleRole) {
/*      */       case LIST_ITEM:
/* 1856 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1857 */         if (integer1 != null) {
/* 1858 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ITEM_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TREE_ITEM:
/* 1863 */         integer1 = (Integer)getAttribute(AccessibleAttribute.INDEX, new Object[0]);
/* 1864 */         if (integer1 != null) {
/* 1865 */           node = (Node)accessible.getAttribute(AccessibleAttribute.ROW_AT_INDEX, new Object[] { integer1 });
/*      */         }
/*      */         break;
/*      */       
/*      */       case TABLE_CELL:
/*      */       case TREE_TABLE_CELL:
/* 1871 */         integer1 = (Integer)getAttribute(AccessibleAttribute.ROW_INDEX, new Object[0]);
/* 1872 */         integer2 = (Integer)getAttribute(AccessibleAttribute.COLUMN_INDEX, new Object[0]);
/* 1873 */         if (integer1 != null && integer2 != null) {
/* 1874 */           node = (Node)accessible.getAttribute(AccessibleAttribute.CELL_AT_ROW_COLUMN, new Object[] { integer1, integer2 });
/*      */         }
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1880 */     if (node != null)
/* 1881 */       accessible.executeAction(AccessibleAction.SHOW_ITEM, new Object[] { node }); 
/*      */   }
/*      */   
/*      */   private static native void _initIDs();
/*      */   
/*      */   private native long _createGlassAccessible();
/*      */   
/*      */   private native void _destroyGlassAccessible(long paramLong);
/*      */   
/*      */   private static native long UiaRaiseAutomationEvent(long paramLong, int paramInt);
/*      */   
/*      */   private static native long UiaRaiseAutomationPropertyChangedEvent(long paramLong, int paramInt, WinVariant paramWinVariant1, WinVariant paramWinVariant2);
/*      */   
/*      */   private static native boolean UiaClientsAreListening();
/*      */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinAccessible.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */