/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.Cursor;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WinWindow
/*     */   extends Window
/*     */ {
/*     */   public static final int RESIZE_DISABLE = 0;
/*     */   public static final int RESIZE_AROUND_ANCHOR = 1;
/*     */   public static final int RESIZE_TO_FX_ORIGIN = 2;
/*     */   public static final long ANCHOR_NO_CAPTURE = -9223372036854775808L;
/*     */   float fxReqWidth;
/*     */   float fxReqHeight;
/*     */   int pfReqWidth;
/*     */   int pfReqHeight;
/*     */   private boolean deferredClosing;
/*     */   private boolean closingRequested;
/*     */   
/*     */   static {
/*  50 */     _initIDs();
/*     */   }
/*     */   public void setBounds(float paramFloat1, float paramFloat2, boolean paramBoolean1, boolean paramBoolean2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8) { if (paramBoolean1 || paramBoolean2 || paramFloat3 > 0.0F || paramFloat4 > 0.0F || paramFloat5 > 0.0F || paramFloat6 > 0.0F) { int n, i1; float f1, f2; int i2, i3; long l1 = _getInsets(getRawHandle()); int i = (int)(l1 >> 48L) & 0xFFFF; int j = (int)(l1 >> 32L) & 0xFFFF; int k = (int)(l1 >> 16L) & 0xFFFF; int m = (int)l1 & 0xFFFF; if (paramBoolean1 || paramBoolean2) { if (paramBoolean1) { n = this.screen.toPlatformX(paramFloat1); } else { n = this.x; paramFloat1 = this.screen.fromPlatformX(n); }  if (paramBoolean2) { i1 = this.screen.toPlatformY(paramFloat2); } else { i1 = this.y; paramFloat2 = this.screen.fromPlatformY(i1); }  } else { n = this.x; i1 = this.y; }  if (paramFloat3 > 0.0F) { f1 = paramFloat3 - (i + k) / this.platformScaleX; i2 = (int)Math.ceil((paramFloat3 * this.platformScaleX)); } else { f1 = (paramFloat5 > 0.0F) ? paramFloat5 : this.fxReqWidth; i2 = i + k + (int)Math.ceil((f1 * this.platformScaleX)); }  this.fxReqWidth = f1; if (paramFloat4 > 0.0F) { f2 = paramFloat4 - (j + m) / this.platformScaleY; i3 = (int)Math.ceil((paramFloat4 * this.platformScaleY)); } else { f2 = (paramFloat6 > 0.0F) ? paramFloat6 : this.fxReqHeight; i3 = j + m + (int)Math.ceil((f2 * this.platformScaleY)); }  this.fxReqHeight = f2; long l2 = _getAnchor(getRawHandle()); boolean bool = (l2 == Long.MIN_VALUE) ? true : true; int i4 = (int)(l2 >> 32L); int i5 = (int)l2; int[] arrayOfInt = notifyMoving(n, i1, i2, i3, paramFloat1, paramFloat2, i4, i5, bool, i, j, k, m); if (arrayOfInt != null) { n = arrayOfInt[0]; i1 = arrayOfInt[1]; i2 = arrayOfInt[2]; i3 = arrayOfInt[3]; }  if (!paramBoolean1) paramBoolean1 = (n != this.x);  if (!paramBoolean2) paramBoolean2 = (i1 != this.y);  this.pfReqWidth = (int)Math.ceil((this.fxReqWidth * this.platformScaleX)); this.pfReqHeight = (int)Math.ceil((this.fxReqHeight * this.platformScaleY)); _setBounds(getRawHandle(), n, i1, paramBoolean1, paramBoolean2, i2, i3, 0, 0, paramFloat7, paramFloat8); }  } protected int[] notifyMoving(int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11) { if (this.screen == null || !this.screen.containsPlatformRect(paramInt1, paramInt2, paramInt3, paramInt4)) { float f = (this.screen == null) ? 0.0F : this.screen.portionIntersectsPlatformRect(paramInt1, paramInt2, paramInt3, paramInt4); if (f < 0.5F) { float f1 = paramInt5 / this.platformScaleX; float f2 = paramInt6 / this.platformScaleY; Screen screen = this.screen; int i = paramInt1; int j = paramInt2; int k = paramInt3; int m = paramInt4; for (Screen screen1 : Screen.getScreens()) { int n, i1, i2, i3; if (screen1 == this.screen) continue;  if (paramInt7 == 0) { n = paramInt1; i1 = paramInt2; i2 = paramInt3; i3 = paramInt4; } else { int i4 = (int)Math.ceil((this.fxReqWidth * screen1.getPlatformScaleX())); int i5 = (int)Math.ceil((this.fxReqHeight * screen1.getPlatformScaleY())); i2 = i4 + paramInt8 + paramInt10; i3 = i5 + paramInt9 + paramInt11; if (paramInt7 == 1) { n = paramInt1 + paramInt5 - Math.round(f1 * screen1.getPlatformScaleX()); i1 = paramInt2 + paramInt6 - Math.round(f2 * screen1.getPlatformScaleY()); } else { n = screen1.toPlatformX(paramFloat1); i1 = screen1.toPlatformY(paramFloat2); }  }  float f3 = screen1.portionIntersectsPlatformRect(n, i1, i2, i3); if (this.screen == null || (f3 > 0.6F && f3 > f)) { f = f3; screen = screen1; i = n; j = i1; k = i2; m = i3; }  }  if (screen != this.screen) { notifyMoveToAnotherScreen(screen); notifyScaleChanged(screen.getPlatformScaleX(), screen.getPlatformScaleY(), screen.getRecommendedOutputScaleX(), screen.getRecommendedOutputScaleY()); if (this.view != null)
/*     */             this.view.updateLocation();  if (paramInt7 == 0)
/*  54 */             return null;  return new int[] { i, j, k, m }; }  }  }  return null; } protected WinWindow(Window paramWindow, Screen paramScreen, int paramInt) { super(paramWindow, paramScreen, paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 291 */     this.deferredClosing = false;
/* 292 */     this.closingRequested = false; }
/*     */   protected void notifyResize(int paramInt1, int paramInt2, int paramInt3) { float f1 = this.platformScaleX; float f2 = this.platformScaleY; long l = _getInsets(getRawHandle()); int i = (int)(l >> 48L) & 0xFFFF; int j = (int)(l >> 32L) & 0xFFFF; int k = (int)(l >> 16L) & 0xFFFF; int m = (int)l & 0xFFFF; int n = paramInt2 - i - k; int i1 = paramInt3 - j - m; if (n != this.pfReqWidth || f1 != this.platformScaleX) {
/*     */       this.fxReqWidth = n / this.platformScaleX; this.pfReqWidth = n;
/*     */     }  if (i1 != this.pfReqHeight || f2 != this.platformScaleY) {
/*     */       this.fxReqHeight = i1 / this.platformScaleY;
/*     */       this.pfReqHeight = i1;
/*     */     } 
/* 299 */     super.notifyResize(paramInt1, paramInt2, paramInt3); } void setDeferredClosing(boolean paramBoolean) { this.deferredClosing = paramBoolean;
/* 300 */     if (!this.deferredClosing && this.closingRequested)
/* 301 */       close();  } protected boolean _setBackground(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3) { return true; } protected void _requestInput(long paramLong, String paramString, int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8, double paramDouble9, double paramDouble10, double paramDouble11, double paramDouble12, double paramDouble13, double paramDouble14) { throw new UnsupportedOperationException("Not supported yet."); }
/*     */   protected void _releaseInput(long paramLong) {
/*     */     throw new UnsupportedOperationException("Not supported yet.");
/*     */   }
/*     */   public void close() {
/* 306 */     if (!this.deferredClosing) {
/* 307 */       super.close();
/*     */     } else {
/* 309 */       this.closingRequested = true;
/* 310 */       setVisible(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static native void _initIDs();
/*     */   
/*     */   protected native boolean _setBackground2(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3);
/*     */   
/*     */   private native long _getInsets(long paramLong);
/*     */   
/*     */   private native long _getAnchor(long paramLong);
/*     */   
/*     */   protected native long _createWindow(long paramLong1, long paramLong2, int paramInt);
/*     */   
/*     */   protected native boolean _close(long paramLong);
/*     */   
/*     */   protected native boolean _setView(long paramLong, View paramView);
/*     */   
/*     */   protected native void _updateViewSize(long paramLong);
/*     */   
/*     */   protected native boolean _setMenubar(long paramLong1, long paramLong2);
/*     */   
/*     */   protected native boolean _minimize(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _maximize(long paramLong, boolean paramBoolean1, boolean paramBoolean2);
/*     */   
/*     */   protected native void _setBounds(long paramLong, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, float paramFloat1, float paramFloat2);
/*     */   
/*     */   protected native boolean _setVisible(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setResizable(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _requestFocus(long paramLong, int paramInt);
/*     */   
/*     */   protected native void _setFocusable(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setTitle(long paramLong, String paramString);
/*     */   
/*     */   protected native void _setLevel(long paramLong, int paramInt);
/*     */   
/*     */   protected native void _setAlpha(long paramLong, float paramFloat);
/*     */   
/*     */   protected native void _setEnabled(long paramLong, boolean paramBoolean);
/*     */   
/*     */   protected native boolean _setMinimumSize(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   protected native boolean _setMaximumSize(long paramLong, int paramInt1, int paramInt2);
/*     */   
/*     */   protected native void _setIcon(long paramLong, Pixels paramPixels);
/*     */   
/*     */   protected native void _toFront(long paramLong);
/*     */   
/*     */   protected native void _toBack(long paramLong);
/*     */   
/*     */   protected native void _enterModal(long paramLong);
/*     */   
/*     */   protected native void _enterModalWithWindow(long paramLong1, long paramLong2);
/*     */   
/*     */   protected native void _exitModal(long paramLong);
/*     */   
/*     */   protected native boolean _grabFocus(long paramLong);
/*     */   
/*     */   protected native void _ungrabFocus(long paramLong);
/*     */   
/*     */   protected native void _setCursor(long paramLong, Cursor paramCursor);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinWindow.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */