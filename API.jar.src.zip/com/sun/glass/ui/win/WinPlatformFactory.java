/*    */ package com.sun.glass.ui.win;
/*    */ 
/*    */ import com.sun.glass.ui.Application;
/*    */ import com.sun.glass.ui.Menu;
/*    */ import com.sun.glass.ui.MenuBar;
/*    */ import com.sun.glass.ui.MenuItem;
/*    */ import com.sun.glass.ui.PlatformFactory;
/*    */ import com.sun.glass.ui.delegate.ClipboardDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuBarDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuDelegate;
/*    */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WinPlatformFactory
/*    */   extends PlatformFactory
/*    */ {
/*    */   public WinApplication createApplication() {
/* 39 */     return new WinApplication();
/*    */   }
/*    */   
/*    */   public MenuBarDelegate createMenuBarDelegate(MenuBar paramMenuBar) {
/* 43 */     return new WinMenuBarDelegate(paramMenuBar);
/*    */   }
/*    */   
/*    */   public MenuDelegate createMenuDelegate(Menu paramMenu) {
/* 47 */     return new WinMenuDelegate(paramMenu);
/*    */   }
/*    */   
/*    */   public MenuItemDelegate createMenuItemDelegate(MenuItem paramMenuItem) {
/* 51 */     return new WinMenuItemDelegate(paramMenuItem);
/*    */   }
/*    */   
/*    */   public ClipboardDelegate createClipboardDelegate() {
/* 55 */     return new WinClipboardDelegate();
/*    */   }
/*    */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinPlatformFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */