/*     */ package com.sun.glass.ui.win;
/*     */ 
/*     */ import com.sun.glass.ui.Accessible;
/*     */ import com.sun.glass.ui.Application;
/*     */ import com.sun.glass.ui.CommonDialogs;
/*     */ import com.sun.glass.ui.Cursor;
/*     */ import com.sun.glass.ui.GlassRobot;
/*     */ import com.sun.glass.ui.InvokeLaterDispatcher;
/*     */ import com.sun.glass.ui.Pixels;
/*     */ import com.sun.glass.ui.Screen;
/*     */ import com.sun.glass.ui.Size;
/*     */ import com.sun.glass.ui.Timer;
/*     */ import com.sun.glass.ui.View;
/*     */ import com.sun.glass.ui.Window;
/*     */ import com.sun.javafx.application.PlatformImpl;
/*     */ import com.sun.javafx.tk.Toolkit;
/*     */ import com.sun.prism.impl.PrismSettings;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Objects;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class WinApplication
/*     */   extends Application
/*     */   implements InvokeLaterDispatcher.InvokeLaterSubmitter
/*     */ {
/*     */   static float overrideUIScale;
/*     */   private static final String BASE_NAME = "com/sun/glass/ui/win/themes";
/*     */   private final InvokeLaterDispatcher invokeLaterDispatcher;
/*     */   private static boolean verbose;
/*     */   private static final int Process_DPI_Unaware = 0;
/*     */   private static final int Process_System_DPI_Aware = 1;
/*     */   private static final int Process_Per_Monitor_DPI_Aware = 2;
/*     */   
/*     */   private static boolean getBoolean(String paramString1, boolean paramBoolean, String paramString2) {
/*  48 */     String str = System.getProperty(paramString1);
/*  49 */     if (str == null) {
/*  50 */       str = System.getenv(paramString1);
/*     */     }
/*  52 */     if (str == null) {
/*  53 */       return paramBoolean;
/*     */     }
/*  55 */     Boolean bool = Boolean.valueOf(Boolean.parseBoolean(str));
/*  56 */     if (PrismSettings.verbose) {
/*  57 */       System.out.println((bool.booleanValue() ? "" : "not ") + (bool.booleanValue() ? "" : "not "));
/*     */     }
/*  59 */     return bool.booleanValue();
/*     */   }
/*     */   private static float getFloat(String paramString1, float paramFloat, String paramString2) {
/*     */     float f;
/*  63 */     String str = System.getProperty(paramString1);
/*  64 */     if (str == null) {
/*  65 */       str = System.getenv(paramString1);
/*     */     }
/*  67 */     if (str == null) {
/*  68 */       return paramFloat;
/*     */     }
/*  70 */     str = str.trim();
/*     */     
/*  72 */     if (str.endsWith("%")) {
/*  73 */       f = Integer.parseInt(str.substring(0, str.length() - 1)) / 100.0F;
/*  74 */     } else if (str.endsWith("DPI") || str.endsWith("dpi")) {
/*  75 */       f = Integer.parseInt(str.substring(0, str.length() - 3)) / 96.0F;
/*     */     } else {
/*  77 */       f = Float.parseFloat(str);
/*     */     } 
/*  79 */     if (PrismSettings.verbose) {
/*  80 */       System.out.println(paramString2 + paramString2);
/*     */     }
/*  82 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  88 */     Void void_ = AccessController.<Void>doPrivileged(new PrivilegedAction<Void>() {
/*     */           public Void run() {
/*  90 */             WinApplication.verbose = Boolean.getBoolean("javafx.verbose");
/*  91 */             if (PrismSettings.allowHiDPIScaling) {
/*  92 */               WinApplication.overrideUIScale = WinApplication.getFloat("glass.win.uiScale", -1.0F, "Forcing UI scaling factor: ");
/*     */               
/*  94 */               if (PrismSettings.verbose) {
/*  95 */                 WinApplication.getFloat("glass.win.renderScale", -1.0F, "(No longer supported) Rendering scaling factor: ");
/*     */                 
/*  97 */                 WinApplication.getFloat("glass.win.minHiDPI", 1.5F, "(No longer supported) UI scaling threshold: ");
/*     */                 
/*  99 */                 WinApplication.getBoolean("glass.win.forceIntegerRenderScale", true, "(No longer supported) force integer rendering scale");
/*     */               } 
/*     */             } else {
/*     */               
/* 103 */               WinApplication.overrideUIScale = 1.0F;
/*     */             } 
/*     */             
/* 106 */             Toolkit.loadMSWindowsLibraries();
/* 107 */             WinApplication.loadNativeLibrary();
/* 108 */             return null;
/*     */           }
/*     */         });
/* 111 */     initIDs(overrideUIScale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WinApplication() {
/* 119 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.embed.isEventThread")))).booleanValue();
/* 120 */     if (!bool) {
/* 121 */       this.invokeLaterDispatcher = new InvokeLaterDispatcher(this);
/* 122 */       this.invokeLaterDispatcher.start();
/*     */     } else {
/* 124 */       this.invokeLaterDispatcher = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getDesiredAwarenesslevel() {
/* 141 */     if (!PrismSettings.allowHiDPIScaling) {
/* 142 */       return 0;
/*     */     }
/*     */ 
/*     */     
/* 146 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("javafx.glass.winDPIawareness"));
/*     */     
/* 148 */     if (str != null) {
/* 149 */       str = str.toLowerCase();
/* 150 */       if (str.equals("aware"))
/* 151 */         return 1; 
/* 152 */       if (str.equals("permonitor")) {
/* 153 */         return 2;
/*     */       }
/* 155 */       if (!str.equals("unaware")) {
/* 156 */         System.err.println("unrecognized DPI awareness request, defaulting to unaware: " + str);
/*     */       }
/* 158 */       return 0;
/*     */     } 
/*     */     
/* 161 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runLoop(Runnable paramRunnable) {
/* 168 */     boolean bool = ((Boolean)AccessController.<Boolean>doPrivileged(() -> Boolean.valueOf(Boolean.getBoolean("javafx.embed.isEventThread")))).booleanValue();
/* 169 */     int i = getDesiredAwarenesslevel();
/*     */     
/* 171 */     ClassLoader classLoader = WinApplication.class.getClassLoader();
/* 172 */     _setClassLoader(classLoader);
/*     */     
/* 174 */     if (bool) {
/* 175 */       _init(i);
/* 176 */       setEventThread(Thread.currentThread());
/* 177 */       paramRunnable.run();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 182 */     Thread thread = AccessController.<Thread>doPrivileged(() -> new Thread((), "WindowsNativeRunloopThread"));
/*     */ 
/*     */ 
/*     */     
/* 186 */     setEventThread(thread);
/* 187 */     thread.start();
/*     */   }
/*     */   
/*     */   protected void finishTerminating() {
/* 191 */     Thread thread = getEventThread();
/* 192 */     if (thread != null) {
/* 193 */       _terminateLoop();
/* 194 */       setEventThread(null);
/*     */     } 
/* 196 */     super.finishTerminating();
/*     */   }
/*     */   
/*     */   public boolean shouldUpdateWindow() {
/* 200 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _enterNestedEventLoop() {
/* 207 */     if (this.invokeLaterDispatcher != null) {
/* 208 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/*     */     try {
/* 211 */       return _enterNestedEventLoopImpl();
/*     */     } finally {
/* 213 */       if (this.invokeLaterDispatcher != null) {
/* 214 */         this.invokeLaterDispatcher.notifyLeftNestedEventLoop();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void _leaveNestedEventLoop(Object paramObject) {
/* 220 */     if (this.invokeLaterDispatcher != null) {
/* 221 */       this.invokeLaterDispatcher.notifyLeavingNestedEventLoop();
/*     */     }
/* 223 */     _leaveNestedEventLoopImpl(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Window createWindow(Window paramWindow, Screen paramScreen, int paramInt) {
/* 229 */     return new WinWindow(paramWindow, paramScreen, paramInt);
/*     */   }
/*     */   
/*     */   public View createView() {
/* 233 */     return new WinView();
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt) {
/* 237 */     return new WinCursor(paramInt);
/*     */   }
/*     */   
/*     */   public Cursor createCursor(int paramInt1, int paramInt2, Pixels paramPixels) {
/* 241 */     return new WinCursor(paramInt1, paramInt2, paramPixels);
/*     */   }
/*     */   
/*     */   protected void staticCursor_setVisible(boolean paramBoolean) {
/* 245 */     WinCursor.setVisible_impl(paramBoolean);
/*     */   }
/*     */   
/*     */   protected Size staticCursor_getBestSize(int paramInt1, int paramInt2) {
/* 249 */     return WinCursor.getBestSize_impl(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer) {
/* 253 */     return new WinPixels(paramInt1, paramInt2, paramByteBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, float paramFloat1, float paramFloat2) {
/* 258 */     return new WinPixels(paramInt1, paramInt2, paramByteBuffer, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer) {
/* 262 */     return new WinPixels(paramInt1, paramInt2, paramIntBuffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2) {
/* 267 */     return new WinPixels(paramInt1, paramInt2, paramIntBuffer, paramFloat1, paramFloat2);
/*     */   }
/*     */   
/*     */   protected int staticPixels_getNativeFormat() {
/* 271 */     return WinPixels.getNativeFormat_impl();
/*     */   }
/*     */   
/*     */   public GlassRobot createRobot() {
/* 275 */     return new WinRobot();
/*     */   }
/*     */   
/*     */   protected double staticScreen_getVideoRefreshPeriod() {
/* 279 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Timer createTimer(Runnable paramRunnable) {
/* 285 */     return new WinTimer(paramRunnable);
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMinPeriod() {
/* 289 */     return WinTimer.getMinPeriod_impl();
/*     */   }
/*     */   
/*     */   protected int staticTimer_getMaxPeriod() {
/* 293 */     return WinTimer.getMaxPeriod_impl();
/*     */   }
/*     */   
/*     */   public Accessible createAccessible() {
/* 297 */     return new WinAccessible();
/*     */   }
/*     */ 
/*     */   
/*     */   protected CommonDialogs.FileChooserResult staticCommonDialogs_showFileChooser(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2) {
/* 302 */     if (this.invokeLaterDispatcher != null) {
/* 303 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/* 305 */     return WinCommonDialogs.showFileChooser_impl(paramWindow, paramString1, paramString2, paramString3, paramInt1, paramBoolean, paramArrayOfExtensionFilter, paramInt2);
/*     */   }
/*     */   
/*     */   protected File staticCommonDialogs_showFolderChooser(Window paramWindow, String paramString1, String paramString2) {
/* 309 */     if (this.invokeLaterDispatcher != null) {
/* 310 */       this.invokeLaterDispatcher.notifyEnteringNestedEventLoop();
/*     */     }
/* 312 */     return WinCommonDialogs.showFolderChooser_impl(paramWindow, paramString1, paramString2);
/*     */   }
/*     */   
/*     */   protected long staticView_getMultiClickTime() {
/* 316 */     return WinView.getMultiClickTime_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxX() {
/* 320 */     return WinView.getMultiClickMaxX_impl();
/*     */   }
/*     */   
/*     */   protected int staticView_getMultiClickMaxY() {
/* 324 */     return WinView.getMultiClickMaxY_impl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void submitForLaterInvocation(Runnable paramRunnable) {
/* 332 */     _submitForLaterInvocation(paramRunnable);
/*     */   }
/*     */   
/*     */   protected void _invokeLater(Runnable paramRunnable) {
/* 336 */     if (this.invokeLaterDispatcher != null) {
/* 337 */       this.invokeLaterDispatcher.invokeLater(paramRunnable);
/*     */     } else {
/* 339 */       submitForLaterInvocation(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHighContrastScheme(String paramString) {
/* 345 */     Objects.requireNonNull(ResourceBundle.getBundle("com/sun/glass/ui/win/themes")); return PlatformImpl.HighContrastScheme.fromThemeName(ResourceBundle.getBundle("com/sun/glass/ui/win/themes")::getString, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getHighContrastTheme() {
/* 350 */     checkEventThread();
/* 351 */     return getHighContrastScheme(_getHighContrastTheme());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsInputMethods() {
/* 356 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsTransparentWindows() {
/* 361 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataDirectory() {
/* 367 */     checkEventThread();
/*     */     
/* 369 */     String str = AccessController.<String>doPrivileged(() -> System.getenv("APPDATA"));
/* 370 */     if (str == null || str.length() == 0) {
/* 371 */       return super.getDataDirectory();
/*     */     }
/* 373 */     return str + str + File.separator + this.name;
/*     */   }
/*     */   
/*     */   private static native void initIDs(float paramFloat);
/*     */   
/*     */   private native long _init(int paramInt);
/*     */   
/*     */   private native void _setClassLoader(ClassLoader paramClassLoader);
/*     */   
/*     */   private native void _runLoop(Runnable paramRunnable);
/*     */   
/*     */   private native void _terminateLoop();
/*     */   
/*     */   private native Object _enterNestedEventLoopImpl();
/*     */   
/*     */   private native void _leaveNestedEventLoopImpl(Object paramObject);
/*     */   
/*     */   protected native Screen[] staticScreen_getScreens();
/*     */   
/*     */   protected native void _invokeAndWait(Runnable paramRunnable);
/*     */   
/*     */   private native void _submitForLaterInvocation(Runnable paramRunnable);
/*     */   
/*     */   private native String _getHighContrastTheme();
/*     */   
/*     */   protected native boolean _supportsUnifiedWindows();
/*     */   
/*     */   protected native int _getKeyCodeForChar(char paramChar);
/*     */   
/*     */   protected native int _isKeyLocked(int paramInt);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\win\WinApplication.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */