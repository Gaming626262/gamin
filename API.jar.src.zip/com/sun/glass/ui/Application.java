/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.glass.utils.NativeLibLoader;
/*     */ import java.io.File;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.security.AccessController;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Application
/*     */ {
/*     */   private static final String DEFAULT_NAME = "java";
/*  44 */   protected String name = "java";
/*     */   
/*     */   private EventHandler eventHandler;
/*     */ 
/*     */   
/*     */   public static class EventHandler
/*     */   {
/*     */     public void handleWillFinishLaunchingAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidFinishLaunchingAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillBecomeActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidBecomeActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillResignActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidResignActiveAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidReceiveMemoryWarning(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillHideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidHideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleWillUnhideAction(Application param1Application, long param1Long) {}
/*     */ 
/*     */     
/*     */     public void handleDidUnhideAction(Application param1Application, long param1Long) {}
/*     */     
/*     */     public void handleOpenFilesAction(Application param1Application, long param1Long, String[] param1ArrayOfString) {}
/*     */     
/*     */     public void handleQuitAction(Application param1Application, long param1Long) {}
/*     */     
/*     */     public boolean handleThemeChanged(String param1String) {
/*  88 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean initialActiveEventReceived = false;
/*  94 */   private String[] initialOpenedFiles = null;
/*     */   private static boolean loaded = false;
/*     */   private static Application application;
/*     */   private static Thread eventThread;
/*     */   private static final boolean disableThreadChecks;
/*     */   
/*     */   static {
/* 101 */     disableThreadChecks = ((Boolean)AccessController.<Boolean>doPrivileged(() -> { String str = System.getProperty("glass.disableThreadChecks", "false"); return Boolean.valueOf("true".equalsIgnoreCase(str)); })).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized void loadNativeLibrary(String paramString) {
/* 111 */     if (!loaded) {
/* 112 */       NativeLibLoader.loadLibrary(paramString);
/* 113 */       loaded = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static synchronized void loadNativeLibrary() {
/* 120 */     loadNativeLibrary("glass");
/*     */   }
/*     */   
/* 123 */   private static volatile Map deviceDetails = null;
/*     */ 
/*     */   
/*     */   private boolean terminateWhenLastWindowClosed;
/*     */ 
/*     */   
/*     */   public static void setDeviceDetails(Map paramMap) {
/* 130 */     deviceDetails = paramMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map getDeviceDetails() {
/* 135 */     return deviceDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void run(Runnable paramRunnable) {
/* 143 */     if (application != null) {
/* 144 */       throw new IllegalStateException("Application is already running");
/*     */     }
/* 146 */     application = PlatformFactory.getPlatformFactory().createApplication();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 153 */       application.runLoop(() -> {
/*     */             Screen.initScreens();
/*     */             paramRunnable.run();
/*     */           });
/* 157 */     } catch (Throwable throwable) {
/* 158 */       throwable.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finishTerminating() {
/* 168 */     application = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 183 */     checkEventThread();
/* 184 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 200 */     checkEventThread();
/* 201 */     if (paramString != null && "java".equals(this.name)) {
/* 202 */       this.name = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDataDirectory() {
/* 217 */     checkEventThread();
/*     */     
/* 219 */     String str = AccessController.<String>doPrivileged(() -> System.getProperty("user.home"));
/* 220 */     return str + str + "." + File.separator + this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyWillFinishLaunching() {
/* 227 */     EventHandler eventHandler = getEventHandler();
/* 228 */     if (eventHandler != null) {
/* 229 */       eventHandler.handleWillFinishLaunchingAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyDidFinishLaunching() {
/* 234 */     EventHandler eventHandler = getEventHandler();
/* 235 */     if (eventHandler != null) {
/* 236 */       eventHandler.handleDidFinishLaunchingAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWillBecomeActive() {
/* 241 */     EventHandler eventHandler = getEventHandler();
/* 242 */     if (eventHandler != null) {
/* 243 */       eventHandler.handleWillBecomeActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyDidBecomeActive() {
/* 248 */     this.initialActiveEventReceived = true;
/* 249 */     EventHandler eventHandler = getEventHandler();
/* 250 */     if (eventHandler != null) {
/* 251 */       eventHandler.handleDidBecomeActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWillResignActive() {
/* 256 */     EventHandler eventHandler = getEventHandler();
/* 257 */     if (eventHandler != null) {
/* 258 */       eventHandler.handleWillResignActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean notifyThemeChanged(String paramString) {
/* 263 */     EventHandler eventHandler = getEventHandler();
/* 264 */     if (eventHandler != null) {
/* 265 */       return eventHandler.handleThemeChanged(paramString);
/*     */     }
/* 267 */     return false;
/*     */   }
/*     */   
/*     */   protected void notifyDidResignActive() {
/* 271 */     EventHandler eventHandler = getEventHandler();
/* 272 */     if (eventHandler != null) {
/* 273 */       eventHandler.handleDidResignActiveAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyDidReceiveMemoryWarning() {
/* 278 */     EventHandler eventHandler = getEventHandler();
/* 279 */     if (eventHandler != null) {
/* 280 */       eventHandler.handleDidReceiveMemoryWarning(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWillHide() {
/* 285 */     EventHandler eventHandler = getEventHandler();
/* 286 */     if (eventHandler != null) {
/* 287 */       eventHandler.handleWillHideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyDidHide() {
/* 292 */     EventHandler eventHandler = getEventHandler();
/* 293 */     if (eventHandler != null) {
/* 294 */       eventHandler.handleDidHideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWillUnhide() {
/* 299 */     EventHandler eventHandler = getEventHandler();
/* 300 */     if (eventHandler != null) {
/* 301 */       eventHandler.handleWillUnhideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyDidUnhide() {
/* 306 */     EventHandler eventHandler = getEventHandler();
/* 307 */     if (eventHandler != null) {
/* 308 */       eventHandler.handleDidUnhideAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void notifyOpenFiles(String[] paramArrayOfString) {
/* 314 */     if (!this.initialActiveEventReceived && this.initialOpenedFiles == null)
/*     */     {
/* 316 */       this.initialOpenedFiles = paramArrayOfString;
/*     */     }
/* 318 */     EventHandler eventHandler = getEventHandler();
/* 319 */     if (eventHandler != null && paramArrayOfString != null) {
/* 320 */       eventHandler.handleOpenFilesAction(this, System.nanoTime(), paramArrayOfString);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void notifyWillQuit() {
/* 325 */     EventHandler eventHandler = getEventHandler();
/* 326 */     if (eventHandler != null) {
/* 327 */       eventHandler.handleQuitAction(this, System.nanoTime());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void installDefaultMenus(MenuBar paramMenuBar) {
/* 338 */     checkEventThread();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventHandler getEventHandler() {
/* 346 */     return this.eventHandler;
/*     */   }
/*     */   
/*     */   public void setEventHandler(EventHandler paramEventHandler) {
/* 350 */     checkEventThread();
/* 351 */     boolean bool = (this.eventHandler != null && this.initialOpenedFiles != null) ? true : false;
/* 352 */     this.eventHandler = paramEventHandler;
/* 353 */     if (bool == true)
/*     */     {
/* 355 */       notifyOpenFiles(this.initialOpenedFiles); } 
/*     */   }
/*     */   
/*     */   protected Application() {
/* 359 */     this.terminateWhenLastWindowClosed = true;
/*     */   } public final boolean shouldTerminateWhenLastWindowClosed() {
/* 361 */     checkEventThread();
/* 362 */     return this.terminateWhenLastWindowClosed;
/*     */   }
/*     */   public final void setTerminateWhenLastWindowClosed(boolean paramBoolean) {
/* 365 */     checkEventThread();
/* 366 */     this.terminateWhenLastWindowClosed = paramBoolean;
/*     */   }
/*     */   
/*     */   public boolean shouldUpdateWindow() {
/* 370 */     checkEventThread();
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasWindowManager() {
/* 376 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyRenderingFinished() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() {
/* 388 */     checkEventThread();
/*     */     try {
/* 390 */       LinkedList<Window> linkedList = new LinkedList<>(Window.getWindows());
/* 391 */       for (Window window : linkedList)
/*     */       {
/* 393 */         window.setVisible(false);
/*     */       }
/* 395 */       for (Window window : linkedList)
/*     */       {
/* 397 */         window.close();
/*     */       }
/* 399 */     } catch (Throwable throwable) {
/* 400 */       throwable.printStackTrace();
/*     */     } finally {
/* 402 */       finishTerminating();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Application GetApplication() {
/* 408 */     return application;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static void setEventThread(Thread paramThread) {
/* 413 */     eventThread = paramThread;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Thread getEventThread() {
/* 418 */     return eventThread;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEventThread() {
/* 425 */     return (Thread.currentThread() == eventThread);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkEventThread() {
/* 442 */     if (!disableThreadChecks && 
/* 443 */       Thread.currentThread() != eventThread)
/*     */     {
/* 445 */       throw new IllegalStateException("This operation is permitted on the event thread only; currentThread = " + 
/*     */           
/* 447 */           Thread.currentThread().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void reportException(Throwable paramThrowable) {
/* 454 */     Thread thread = Thread.currentThread();
/*     */     
/* 456 */     Thread.UncaughtExceptionHandler uncaughtExceptionHandler = thread.getUncaughtExceptionHandler();
/* 457 */     uncaughtExceptionHandler.uncaughtException(thread, paramThrowable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeAndWait(Runnable paramRunnable) {
/* 466 */     if (paramRunnable == null) {
/*     */       return;
/*     */     }
/* 469 */     if (isEventThread()) {
/* 470 */       paramRunnable.run();
/*     */     } else {
/* 472 */       GetApplication()._invokeAndWait(paramRunnable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeLater(Runnable paramRunnable) {
/* 482 */     if (paramRunnable == null) {
/*     */       return;
/*     */     }
/* 485 */     GetApplication()._invokeLater(paramRunnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 491 */   private static int nestedEventLoopCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object enterNestedEventLoop() {
/* 511 */     checkEventThread();
/*     */     
/* 513 */     nestedEventLoopCounter++;
/*     */     try {
/* 515 */       return GetApplication()._enterNestedEventLoop();
/*     */     } finally {
/* 517 */       nestedEventLoopCounter--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void leaveNestedEventLoop(Object paramObject) {
/* 538 */     checkEventThread();
/*     */     
/* 540 */     if (nestedEventLoopCounter == 0) {
/* 541 */       throw new IllegalStateException("Not in a nested event loop");
/*     */     }
/*     */     
/* 544 */     GetApplication()._leaveNestedEventLoop(paramObject);
/*     */   }
/*     */   
/*     */   public static boolean isNestedLoopRunning() {
/* 548 */     checkEventThread();
/* 549 */     return (nestedEventLoopCounter > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void menuAboutAction() {
/* 554 */     System.err.println("about");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Window createWindow(Screen paramScreen, int paramInt) {
/* 583 */     return createWindow(null, paramScreen, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Menu createMenu(String paramString) {
/* 595 */     return new Menu(paramString);
/*     */   }
/*     */   
/*     */   public final Menu createMenu(String paramString, boolean paramBoolean) {
/* 599 */     return new Menu(paramString, paramBoolean);
/*     */   }
/*     */   
/*     */   public final MenuBar createMenuBar() {
/* 603 */     return new MenuBar();
/*     */   }
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString) {
/* 607 */     return createMenuItem(paramString, null);
/*     */   }
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback) {
/* 611 */     return createMenuItem(paramString, paramCallback, 0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2) {
/* 616 */     return createMenuItem(paramString, paramCallback, paramInt1, paramInt2, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final MenuItem createMenuItem(String paramString, MenuItem.Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels) {
/* 621 */     return new MenuItem(paramString, paramCallback, paramInt1, paramInt2, paramPixels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Pixels createPixels(int paramInt1, int paramInt2, int[] paramArrayOfint, float paramFloat1, float paramFloat2) {
/* 632 */     return GetApplication().createPixels(paramInt1, paramInt2, IntBuffer.wrap(paramArrayOfint), paramFloat1, paramFloat2);
/*     */   }
/*     */ 
/*     */   
/*     */   static float getScaleFactor(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 637 */     float f = 0.0F;
/*     */     
/* 639 */     for (Screen screen : Screen.getScreens()) {
/* 640 */       int i = screen.getX(), j = screen.getY(), k = screen.getWidth(), m = screen.getHeight();
/* 641 */       if (paramInt1 < i + k && paramInt1 + paramInt3 > i && paramInt2 < j + m && paramInt2 + paramInt4 > j) {
/* 642 */         if (f < screen.getRecommendedOutputScaleX()) {
/* 643 */           f = screen.getRecommendedOutputScaleX();
/*     */         }
/* 645 */         if (f < screen.getRecommendedOutputScaleY()) {
/* 646 */           f = screen.getRecommendedOutputScaleY();
/*     */         }
/*     */       } 
/*     */     } 
/* 650 */     return (f == 0.0F) ? 1.0F : f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EventLoop createEventLoop() {
/* 664 */     return new EventLoop();
/*     */   }
/*     */   public Accessible createAccessible() {
/* 667 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHighContrastScheme(String paramString) {
/* 679 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHighContrastTheme() {
/* 687 */     checkEventThread();
/* 688 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsInputMethods() {
/* 693 */     return false;
/*     */   }
/*     */   public final boolean supportsInputMethods() {
/* 696 */     checkEventThread();
/* 697 */     return _supportsInputMethods();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean supportsTransparentWindows() {
/* 702 */     checkEventThread();
/* 703 */     return _supportsTransparentWindows();
/*     */   }
/*     */   
/*     */   public boolean hasTwoLevelFocus() {
/* 707 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasVirtualKeyboard() {
/* 711 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasTouch() {
/* 715 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasMultiTouch() {
/* 719 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasPointer() {
/* 723 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean supportsUnifiedWindows() {
/* 728 */     checkEventThread();
/* 729 */     return _supportsUnifiedWindows();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _supportsSystemMenu() {
/* 734 */     return false;
/*     */   }
/*     */   public final boolean supportsSystemMenu() {
/* 737 */     checkEventThread();
/* 738 */     return _supportsSystemMenu();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getKeyCodeForChar(char paramChar) {
/* 751 */     return application._getKeyCodeForChar(paramChar);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int _isKeyLocked(int paramInt) {
/* 756 */     return -1;
/*     */   }
/*     */   
/*     */   public final Optional<Boolean> isKeyLocked(int paramInt) {
/* 760 */     checkEventThread();
/* 761 */     int i = _isKeyLocked(paramInt);
/* 762 */     switch (i) {
/*     */       case 0:
/* 764 */         return Optional.of(Boolean.valueOf(false));
/*     */       case 1:
/* 766 */         return Optional.of(Boolean.valueOf(true));
/*     */     } 
/* 768 */     return Optional.empty();
/*     */   }
/*     */   
/*     */   protected abstract void runLoop(Runnable paramRunnable);
/*     */   
/*     */   protected abstract void _invokeAndWait(Runnable paramRunnable);
/*     */   
/*     */   protected abstract void _invokeLater(Runnable paramRunnable);
/*     */   
/*     */   protected abstract Object _enterNestedEventLoop();
/*     */   
/*     */   protected abstract void _leaveNestedEventLoop(Object paramObject);
/*     */   
/*     */   public abstract Window createWindow(Window paramWindow, Screen paramScreen, int paramInt);
/*     */   
/*     */   public abstract View createView();
/*     */   
/*     */   public abstract Cursor createCursor(int paramInt);
/*     */   
/*     */   public abstract Cursor createCursor(int paramInt1, int paramInt2, Pixels paramPixels);
/*     */   
/*     */   protected abstract void staticCursor_setVisible(boolean paramBoolean);
/*     */   
/*     */   protected abstract Size staticCursor_getBestSize(int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, ByteBuffer paramByteBuffer, float paramFloat1, float paramFloat2);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer);
/*     */   
/*     */   public abstract Pixels createPixels(int paramInt1, int paramInt2, IntBuffer paramIntBuffer, float paramFloat1, float paramFloat2);
/*     */   
/*     */   protected abstract int staticPixels_getNativeFormat();
/*     */   
/*     */   public abstract GlassRobot createRobot();
/*     */   
/*     */   protected abstract double staticScreen_getVideoRefreshPeriod();
/*     */   
/*     */   protected abstract Screen[] staticScreen_getScreens();
/*     */   
/*     */   public abstract Timer createTimer(Runnable paramRunnable);
/*     */   
/*     */   protected abstract int staticTimer_getMinPeriod();
/*     */   
/*     */   protected abstract int staticTimer_getMaxPeriod();
/*     */   
/*     */   protected abstract CommonDialogs.FileChooserResult staticCommonDialogs_showFileChooser(Window paramWindow, String paramString1, String paramString2, String paramString3, int paramInt1, boolean paramBoolean, CommonDialogs.ExtensionFilter[] paramArrayOfExtensionFilter, int paramInt2);
/*     */   
/*     */   protected abstract File staticCommonDialogs_showFolderChooser(Window paramWindow, String paramString1, String paramString2);
/*     */   
/*     */   protected abstract long staticView_getMultiClickTime();
/*     */   
/*     */   protected abstract int staticView_getMultiClickMaxX();
/*     */   
/*     */   protected abstract int staticView_getMultiClickMaxY();
/*     */   
/*     */   protected abstract boolean _supportsTransparentWindows();
/*     */   
/*     */   protected abstract boolean _supportsUnifiedWindows();
/*     */   
/*     */   protected abstract int _getKeyCodeForChar(char paramChar);
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Application.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */