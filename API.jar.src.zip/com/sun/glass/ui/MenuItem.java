/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import com.sun.glass.ui.delegate.MenuItemDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MenuItem
/*     */ {
/*  38 */   public static final MenuItem Separator = null;
/*     */   
/*     */   private final MenuItemDelegate delegate;
/*     */   
/*     */   private String title;
/*     */   private Callback callback;
/*     */   private boolean enabled;
/*     */   private boolean checked;
/*     */   private int shortcutKey;
/*     */   private int shortcutModifiers;
/*     */   
/*     */   protected MenuItem(String paramString) {
/*  50 */     this(paramString, null);
/*     */   }
/*     */   
/*     */   protected MenuItem(String paramString, Callback paramCallback) {
/*  54 */     this(paramString, paramCallback, 0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MenuItem(String paramString, Callback paramCallback, int paramInt1, int paramInt2) {
/*  59 */     this(paramString, paramCallback, paramInt1, paramInt2, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MenuItem(String paramString, Callback paramCallback, int paramInt1, int paramInt2, Pixels paramPixels) {
/*  64 */     Application.checkEventThread();
/*  65 */     this.title = paramString;
/*  66 */     this.callback = paramCallback;
/*  67 */     this.shortcutKey = paramInt1;
/*  68 */     this.shortcutModifiers = paramInt2;
/*  69 */     this.enabled = true;
/*  70 */     this.checked = false;
/*  71 */     this.delegate = PlatformFactory.getPlatformFactory().createMenuItemDelegate(this);
/*  72 */     if (!this.delegate.createMenuItem(paramString, paramCallback, paramInt1, paramInt2, paramPixels, this.enabled, this.checked))
/*     */     {
/*  74 */       throw new RuntimeException("MenuItem creation error.");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getTitle() {
/*  79 */     Application.checkEventThread();
/*  80 */     return this.title;
/*     */   }
/*     */   
/*     */   public void setTitle(String paramString) {
/*  84 */     Application.checkEventThread();
/*  85 */     if (this.delegate.setTitle(paramString)) {
/*  86 */       this.title = paramString;
/*     */     }
/*     */   }
/*     */   
/*     */   public Callback getCallback() {
/*  91 */     Application.checkEventThread();
/*  92 */     return this.callback;
/*     */   }
/*     */   
/*     */   public void setCallback(Callback paramCallback) {
/*  96 */     Application.checkEventThread();
/*  97 */     if (this.delegate.setCallback(paramCallback)) {
/*  98 */       this.callback = paramCallback;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 103 */     Application.checkEventThread();
/* 104 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/* 108 */     Application.checkEventThread();
/* 109 */     if (this.delegate.setEnabled(paramBoolean)) {
/* 110 */       this.enabled = paramBoolean;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isChecked() {
/* 115 */     Application.checkEventThread();
/* 116 */     return this.checked;
/*     */   }
/*     */   
/*     */   public void setChecked(boolean paramBoolean) {
/* 120 */     Application.checkEventThread();
/* 121 */     if (this.delegate.setChecked(paramBoolean)) {
/* 122 */       this.checked = paramBoolean;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getShortcutKey() {
/* 130 */     Application.checkEventThread();
/* 131 */     return this.shortcutKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getShortcutModifiers() {
/* 138 */     Application.checkEventThread();
/* 139 */     return this.shortcutModifiers;
/*     */   }
/*     */   
/*     */   public void setShortcut(int paramInt1, int paramInt2) {
/* 143 */     Application.checkEventThread();
/* 144 */     if (this.delegate.setShortcut(paramInt1, paramInt2)) {
/* 145 */       this.shortcutKey = paramInt1;
/* 146 */       this.shortcutModifiers = paramInt2;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean setPixels(Pixels paramPixels) {
/* 151 */     Application.checkEventThread();
/* 152 */     return this.delegate.setPixels(paramPixels);
/*     */   }
/*     */ 
/*     */   
/*     */   MenuItemDelegate getDelegate() {
/* 157 */     return this.delegate;
/*     */   }
/*     */   
/*     */   public static interface Callback {
/*     */     void action();
/*     */     
/*     */     void validate();
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\MenuItem.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */