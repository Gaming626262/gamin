package com.sun.glass.ui;

public interface DelayedCallback {
  Object providedData();
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\DelayedCallback.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */