/*     */ package com.sun.glass.ui;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Screen
/*     */ {
/*  37 */   private static volatile List<Screen> screens = null;
/*     */   private static EventHandler eventHandler;
/*     */   private volatile long ptr;
/*     */   private volatile int adapter;
/*  41 */   private static final int dpiOverride = ((Integer)AccessController.<Integer>doPrivileged(() -> Integer.getInteger("com.sun.javafx.screenDPI", 0)))
/*  42 */     .intValue(); private final int depth; private final int x; private final int y;
/*     */   private final int width;
/*     */   private final int height;
/*     */   private final int platformX;
/*     */   private final int platformY;
/*     */   private final int platformWidth;
/*     */   
/*     */   public static double getVideoRefreshPeriod() {
/*  50 */     Application.checkEventThread();
/*  51 */     return Application.GetApplication().staticScreen_getVideoRefreshPeriod();
/*     */   }
/*     */   private final int platformHeight; private final int visibleX; private final int visibleY;
/*     */   private final int visibleWidth;
/*     */   private final int visibleHeight;
/*     */   private final int resolutionX;
/*     */   
/*     */   public static Screen getMainScreen() {
/*  59 */     return getScreens().get(0);
/*     */   }
/*     */   
/*     */   private final int resolutionY;
/*     */   private final float platformScaleX;
/*     */   private final float platformScaleY;
/*     */   
/*     */   public static List<Screen> getScreens() {
/*  67 */     if (screens == null) {
/*  68 */       throw new RuntimeException("Internal graphics not initialized yet");
/*     */     }
/*     */     
/*  71 */     return screens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float outputScaleX;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final float outputScaleY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EventHandler
/*     */   {
/*     */     public void handleSettingsChanged() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Screen(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, int paramInt15, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 131 */     this.ptr = paramLong;
/*     */     
/* 133 */     this.depth = paramInt1;
/*     */     
/* 135 */     this.x = paramInt2;
/* 136 */     this.y = paramInt3;
/* 137 */     this.width = paramInt4;
/* 138 */     this.height = paramInt5;
/*     */     
/* 140 */     this.platformX = paramInt6;
/* 141 */     this.platformY = paramInt7;
/* 142 */     this.platformWidth = paramInt8;
/* 143 */     this.platformHeight = paramInt9;
/*     */     
/* 145 */     this.visibleX = paramInt10;
/* 146 */     this.visibleY = paramInt11;
/* 147 */     this.visibleWidth = paramInt12;
/* 148 */     this.visibleHeight = paramInt13;
/*     */     
/* 150 */     if (dpiOverride > 0) {
/* 151 */       this.resolutionX = this.resolutionY = dpiOverride;
/*     */     } else {
/* 153 */       this.resolutionX = paramInt14;
/* 154 */       this.resolutionY = paramInt15;
/*     */     } 
/*     */     
/* 157 */     this.platformScaleX = paramFloat1;
/* 158 */     this.platformScaleY = paramFloat2;
/* 159 */     this.outputScaleX = paramFloat3;
/* 160 */     this.outputScaleY = paramFloat4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 167 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getX() {
/* 174 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getY() {
/* 181 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 188 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 195 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformX() {
/* 202 */     return this.platformX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformY() {
/* 209 */     return this.platformY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformWidth() {
/* 216 */     return this.platformWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPlatformHeight() {
/* 223 */     return this.platformHeight;
/*     */   }
/*     */   
/*     */   public float fromPlatformX(int paramInt) {
/* 227 */     return this.x + (paramInt - this.platformX) / this.platformScaleX;
/*     */   }
/*     */   
/*     */   public float fromPlatformY(int paramInt) {
/* 231 */     return this.y + (paramInt - this.platformY) / this.platformScaleY;
/*     */   }
/*     */   
/*     */   public int toPlatformX(float paramFloat) {
/* 235 */     return this.platformX + Math.round((paramFloat - this.x) * this.platformScaleX);
/*     */   }
/*     */   
/*     */   public int toPlatformY(float paramFloat) {
/* 239 */     return this.platformY + Math.round((paramFloat - this.y) * this.platformScaleY);
/*     */   }
/*     */   
/*     */   public float portionIntersectsPlatformRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 243 */     int i = Math.max(paramInt1, this.platformX);
/* 244 */     int j = Math.max(paramInt2, this.platformY);
/* 245 */     int k = Math.min(paramInt1 + paramInt3, this.platformX + this.platformWidth);
/* 246 */     int m = Math.min(paramInt2 + paramInt4, this.platformY + this.platformHeight);
/* 247 */     if ((k -= i) <= 0) return 0.0F; 
/* 248 */     if ((m -= j) <= 0) return 0.0F; 
/* 249 */     float f = (k * m);
/* 250 */     return f / paramInt3 / paramInt4;
/*     */   }
/*     */   
/*     */   public boolean containsPlatformRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 254 */     if (!containsPlatformCoords(paramInt1, paramInt2)) return false; 
/* 255 */     if (paramInt3 <= 0 || paramInt4 <= 0) return true; 
/* 256 */     return (paramInt1 + paramInt3 <= this.platformX + this.platformWidth && paramInt2 + paramInt4 <= this.platformY + this.platformHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsPlatformCoords(int paramInt1, int paramInt2) {
/* 261 */     paramInt1 -= this.platformX;
/* 262 */     paramInt2 -= this.platformY;
/* 263 */     return (paramInt1 >= 0 && paramInt1 < this.platformWidth && paramInt2 >= 0 && paramInt2 < this.platformHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPlatformScaleX() {
/* 274 */     return this.platformScaleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getPlatformScaleY() {
/* 284 */     return this.platformScaleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRecommendedOutputScaleX() {
/* 293 */     return this.outputScaleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getRecommendedOutputScaleY() {
/* 302 */     return this.outputScaleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleX() {
/* 309 */     return this.visibleX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleY() {
/* 316 */     return this.visibleY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleWidth() {
/* 323 */     return this.visibleWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVisibleHeight() {
/* 330 */     return this.visibleHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResolutionX() {
/* 337 */     return this.resolutionX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResolutionY() {
/* 344 */     return this.resolutionY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getNativeScreen() {
/* 351 */     return this.ptr;
/*     */   }
/*     */   
/*     */   private void dispose() {
/* 355 */     this.ptr = 0L;
/*     */   }
/*     */   
/*     */   public int getAdapterOrdinal() {
/* 359 */     return this.adapter;
/*     */   }
/*     */   
/*     */   public void setAdapterOrdinal(int paramInt) {
/* 363 */     this.adapter = paramInt;
/*     */   }
/*     */   
/*     */   public static void setEventHandler(EventHandler paramEventHandler) {
/* 367 */     Application.checkEventThread();
/* 368 */     eventHandler = paramEventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notifySettingsChanged() {
/* 376 */     List<Screen> list = screens;
/*     */ 
/*     */     
/* 379 */     initScreens();
/*     */     
/* 381 */     if (eventHandler != null) {
/* 382 */       eventHandler.handleSettingsChanged();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     List<Window> list1 = Window.getWindows();
/* 390 */     for (Window window : list1) {
/* 391 */       Screen screen = window.getScreen();
/* 392 */       for (Screen screen1 : screens) {
/* 393 */         if (screen.getNativeScreen() == screen1.getNativeScreen()) {
/* 394 */           window.setScreen(screen1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 401 */     if (list != null) {
/* 402 */       for (Screen screen : list) {
/* 403 */         screen.dispose();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   static void initScreens() {
/* 409 */     Application.checkEventThread();
/* 410 */     Screen[] arrayOfScreen = Application.GetApplication().staticScreen_getScreens();
/* 411 */     if (arrayOfScreen == null) {
/* 412 */       throw new RuntimeException("Internal graphics failed to initialize");
/*     */     }
/* 414 */     screens = Collections.unmodifiableList(Arrays.asList(arrayOfScreen));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 419 */     return "Screen:\n    ptr:" + getNativeScreen() + "\n    adapter:" + 
/* 420 */       getAdapterOrdinal() + "\n    depth:" + 
/* 421 */       getDepth() + "\n    x:" + 
/* 422 */       getX() + "\n    y:" + 
/* 423 */       getY() + "\n    width:" + 
/* 424 */       getWidth() + "\n    height:" + 
/* 425 */       getHeight() + "\n    platformX:" + 
/* 426 */       getPlatformX() + "\n    platformY:" + 
/* 427 */       getPlatformY() + "\n    platformWidth:" + 
/* 428 */       getPlatformWidth() + "\n    platformHeight:" + 
/* 429 */       getPlatformHeight() + "\n    visibleX:" + 
/* 430 */       getVisibleX() + "\n    visibleY:" + 
/* 431 */       getVisibleY() + "\n    visibleWidth:" + 
/* 432 */       getVisibleWidth() + "\n    visibleHeight:" + 
/* 433 */       getVisibleHeight() + "\n    platformScaleX:" + 
/* 434 */       getPlatformScaleX() + "\n    platformScaleY:" + 
/* 435 */       getPlatformScaleY() + "\n    outputScaleX:" + 
/* 436 */       getRecommendedOutputScaleX() + "\n    outputScaleY:" + 
/* 437 */       getRecommendedOutputScaleY() + "\n    resolutionX:" + 
/* 438 */       getResolutionX() + "\n    resolutionY:" + 
/* 439 */       getResolutionY() + "\n";
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 443 */     if (this == paramObject) return true; 
/* 444 */     if (paramObject == null || getClass() != paramObject.getClass()) return false;
/*     */     
/* 446 */     Screen screen = (Screen)paramObject;
/* 447 */     return (this.ptr == screen.ptr && this.adapter == screen.adapter && this.depth == screen.depth && this.x == screen.x && this.y == screen.y && this.width == screen.width && this.height == screen.height && this.visibleX == screen.visibleX && this.visibleY == screen.visibleY && this.visibleWidth == screen.visibleWidth && this.visibleHeight == screen.visibleHeight && this.resolutionX == screen.resolutionX && this.resolutionY == screen.resolutionY && 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 460 */       Float.compare(screen.platformScaleX, this.platformScaleX) == 0 && 
/* 461 */       Float.compare(screen.platformScaleY, this.platformScaleY) == 0 && 
/* 462 */       Float.compare(screen.outputScaleX, this.outputScaleX) == 0 && 
/* 463 */       Float.compare(screen.outputScaleY, this.outputScaleY) == 0);
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 467 */     int i = 17;
/* 468 */     i = 31 * i + (int)(this.ptr ^ this.ptr >>> 32L);
/* 469 */     i = 31 * i + this.adapter;
/* 470 */     i = 31 * i + this.depth;
/* 471 */     i = 31 * i + this.x;
/* 472 */     i = 31 * i + this.y;
/* 473 */     i = 31 * i + this.width;
/* 474 */     i = 31 * i + this.height;
/* 475 */     i = 31 * i + this.visibleX;
/* 476 */     i = 31 * i + this.visibleY;
/* 477 */     i = 31 * i + this.visibleWidth;
/* 478 */     i = 31 * i + this.visibleHeight;
/* 479 */     i = 31 * i + this.resolutionX;
/* 480 */     i = 31 * i + this.resolutionY;
/* 481 */     i = 31 * i + ((this.platformScaleX != 0.0F) ? Float.floatToIntBits(this.platformScaleX) : 0);
/* 482 */     i = 31 * i + ((this.platformScaleY != 0.0F) ? Float.floatToIntBits(this.platformScaleY) : 0);
/* 483 */     i = 31 * i + ((this.outputScaleX != 0.0F) ? Float.floatToIntBits(this.outputScaleX) : 0);
/* 484 */     i = 31 * i + ((this.outputScaleY != 0.0F) ? Float.floatToIntBits(this.outputScaleY) : 0);
/* 485 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glas\\ui\Screen.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */