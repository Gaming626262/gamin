package com.sun.glass.events;

public class SwipeGesture {
  public static final int DIR_UP = 1;
  
  public static final int DIR_DOWN = 2;
  
  public static final int DIR_LEFT = 3;
  
  public static final int DIR_RIGHT = 4;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glass\events\SwipeGesture.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */