package com.sun.glass.events;

public class GestureEvent {
  public static final int GESTURE_STARTED = 1;
  
  public static final int GESTURE_PERFORMED = 2;
  
  public static final int GESTURE_FINISHED = 3;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glass\events\GestureEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */