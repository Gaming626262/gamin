package com.sun.glass.events;

public class DndEvent {
  public static final int ENTER = 611;
  
  public static final int UPDATE = 612;
  
  public static final int PERFORM = 613;
  
  public static final int EXIT = 614;
  
  public static final int END = 615;
}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glass\events\DndEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */