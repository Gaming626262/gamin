package com.sun.glass.events;

public class WheelEvent {}


/* Location:              C:\Users\Jonathan Finch\Downloads\API.jar!\com\sun\glass\events\WheelEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */